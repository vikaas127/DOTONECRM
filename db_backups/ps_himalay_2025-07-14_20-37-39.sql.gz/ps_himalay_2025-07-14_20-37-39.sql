/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.5.27-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: ps_himalay
-- ------------------------------------------------------
-- Server version	10.5.27-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `himalay_tblacc_account_history`
--

DROP TABLE IF EXISTS `himalay_tblacc_account_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblacc_account_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account` int(11) NOT NULL,
  `debit` decimal(15,2) NOT NULL DEFAULT 0.00,
  `credit` decimal(15,2) NOT NULL DEFAULT 0.00,
  `description` text DEFAULT NULL,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(45) DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `customer` int(11) DEFAULT NULL,
  `reconcile` int(11) NOT NULL DEFAULT 0,
  `split` int(11) NOT NULL DEFAULT 0,
  `item` int(11) DEFAULT NULL,
  `paid` int(1) NOT NULL DEFAULT 0,
  `date` date DEFAULT NULL,
  `tax` int(11) DEFAULT NULL,
  `payslip_type` varchar(45) DEFAULT NULL,
  `vendor` int(11) DEFAULT NULL,
  `itemable_id` int(11) DEFAULT NULL,
  `cleared` int(11) NOT NULL DEFAULT 0,
  `sub_type` varchar(45) DEFAULT NULL,
  `bill_item` int(11) NOT NULL DEFAULT 0,
  `number` varchar(100) DEFAULT NULL,
  `issue` int(11) NOT NULL DEFAULT 0,
  `added_from_reconcile` int(11) NOT NULL DEFAULT 0,
  `bank_reconcile` int(11) NOT NULL DEFAULT 0,
  `currency_rate` decimal(15,6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblacc_account_history`
--

LOCK TABLES `himalay_tblacc_account_history` WRITE;
/*!40000 ALTER TABLE `himalay_tblacc_account_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblacc_account_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblacc_account_type_details`
--

DROP TABLE IF EXISTS `himalay_tblacc_account_type_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblacc_account_type_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_type_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `note` text DEFAULT NULL,
  `statement_of_cash_flows` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=200 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblacc_account_type_details`
--

LOCK TABLES `himalay_tblacc_account_type_details` WRITE;
/*!40000 ALTER TABLE `himalay_tblacc_account_type_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblacc_account_type_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblacc_accounts`
--

DROP TABLE IF EXISTS `himalay_tblacc_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblacc_accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `key_name` varchar(255) DEFAULT NULL,
  `number` varchar(45) DEFAULT NULL,
  `parent_account` int(11) DEFAULT NULL,
  `account_type_id` int(11) NOT NULL,
  `account_detail_type_id` int(11) NOT NULL,
  `balance` decimal(15,2) DEFAULT NULL,
  `balance_as_of` date DEFAULT NULL,
  `description` text DEFAULT NULL,
  `default_account` int(11) NOT NULL DEFAULT 0,
  `active` int(11) NOT NULL DEFAULT 1,
  `access_token` text DEFAULT NULL,
  `account_id` varchar(255) DEFAULT NULL,
  `plaid_status` tinyint(5) NOT NULL DEFAULT 0 COMMENT '1=>verified, 0=>not verified',
  `plaid_account_name` varchar(255) DEFAULT NULL,
  `bank_account` text DEFAULT NULL,
  `bank_routing` text DEFAULT NULL,
  `address_line_1` text DEFAULT NULL,
  `address_line_2` text DEFAULT NULL,
  `bank_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblacc_accounts`
--

LOCK TABLES `himalay_tblacc_accounts` WRITE;
/*!40000 ALTER TABLE `himalay_tblacc_accounts` DISABLE KEYS */;
INSERT INTO `himalay_tblacc_accounts` VALUES (1,'','acc_opening_balance_equity',NULL,NULL,10,71,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `himalay_tblacc_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblacc_bank_reconciles`
--

DROP TABLE IF EXISTS `himalay_tblacc_bank_reconciles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblacc_bank_reconciles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account` int(11) NOT NULL,
  `opening_balance` decimal(15,2) NOT NULL DEFAULT 0.00,
  `beginning_balance` decimal(15,2) NOT NULL,
  `ending_balance` decimal(15,2) NOT NULL,
  `ending_date` date NOT NULL,
  `finish` int(11) NOT NULL DEFAULT 0,
  `debits_for_period` decimal(15,2) NOT NULL,
  `credits_for_period` decimal(15,2) NOT NULL,
  `dateadded` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblacc_bank_reconciles`
--

LOCK TABLES `himalay_tblacc_bank_reconciles` WRITE;
/*!40000 ALTER TABLE `himalay_tblacc_bank_reconciles` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblacc_bank_reconciles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblacc_banking_rule_details`
--

DROP TABLE IF EXISTS `himalay_tblacc_banking_rule_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblacc_banking_rule_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rule_id` int(11) NOT NULL,
  `type` varchar(45) DEFAULT NULL,
  `subtype` varchar(45) DEFAULT NULL,
  `text` varchar(255) DEFAULT NULL,
  `subtype_amount` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblacc_banking_rule_details`
--

LOCK TABLES `himalay_tblacc_banking_rule_details` WRITE;
/*!40000 ALTER TABLE `himalay_tblacc_banking_rule_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblacc_banking_rule_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblacc_banking_rules`
--

DROP TABLE IF EXISTS `himalay_tblacc_banking_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblacc_banking_rules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `transaction` varchar(45) DEFAULT NULL,
  `following` varchar(45) DEFAULT NULL,
  `then` varchar(45) DEFAULT NULL,
  `payment_account` int(11) DEFAULT NULL,
  `deposit_to` int(11) DEFAULT NULL,
  `auto_add` int(11) NOT NULL DEFAULT 0,
  `mapping_type` varchar(25) DEFAULT NULL,
  `account` int(11) DEFAULT NULL,
  `split_percentage` text DEFAULT NULL,
  `split_amount` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblacc_banking_rules`
--

LOCK TABLES `himalay_tblacc_banking_rules` WRITE;
/*!40000 ALTER TABLE `himalay_tblacc_banking_rules` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblacc_banking_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblacc_bill_mappings`
--

DROP TABLE IF EXISTS `himalay_tblacc_bill_mappings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblacc_bill_mappings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bill_id` int(11) DEFAULT NULL,
  `type` varchar(25) DEFAULT NULL,
  `account` int(11) DEFAULT NULL,
  `amount` decimal(15,2) DEFAULT NULL,
  `item_id` int(11) NOT NULL DEFAULT 0,
  `qty` decimal(15,2) NOT NULL DEFAULT 0.00,
  `cost` decimal(15,2) NOT NULL DEFAULT 0.00,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblacc_bill_mappings`
--

LOCK TABLES `himalay_tblacc_bill_mappings` WRITE;
/*!40000 ALTER TABLE `himalay_tblacc_bill_mappings` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblacc_bill_mappings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblacc_budget_details`
--

DROP TABLE IF EXISTS `himalay_tblacc_budget_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblacc_budget_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `budget_id` int(11) NOT NULL,
  `month` int(11) NOT NULL,
  `year` int(11) NOT NULL,
  `account` int(11) DEFAULT NULL,
  `amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblacc_budget_details`
--

LOCK TABLES `himalay_tblacc_budget_details` WRITE;
/*!40000 ALTER TABLE `himalay_tblacc_budget_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblacc_budget_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblacc_budgets`
--

DROP TABLE IF EXISTS `himalay_tblacc_budgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblacc_budgets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `year` int(11) NOT NULL,
  `name` varchar(200) DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  `data_source` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblacc_budgets`
--

LOCK TABLES `himalay_tblacc_budgets` WRITE;
/*!40000 ALTER TABLE `himalay_tblacc_budgets` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblacc_budgets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblacc_check_details`
--

DROP TABLE IF EXISTS `himalay_tblacc_check_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblacc_check_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `check_id` int(11) DEFAULT NULL,
  `bill` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblacc_check_details`
--

LOCK TABLES `himalay_tblacc_check_details` WRITE;
/*!40000 ALTER TABLE `himalay_tblacc_check_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblacc_check_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblacc_checks`
--

DROP TABLE IF EXISTS `himalay_tblacc_checks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblacc_checks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(25) DEFAULT NULL,
  `amount` decimal(15,2) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `memo` varchar(255) DEFAULT NULL,
  `dateadded` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `bank_account` int(11) NOT NULL,
  `number` int(11) NOT NULL,
  `signed` int(11) NOT NULL DEFAULT 0,
  `include_company_name_address` int(11) NOT NULL DEFAULT 1,
  `include_routing_account_numbers` int(11) NOT NULL DEFAULT 1,
  `bill` int(11) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `zip` varchar(15) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `issue` int(11) DEFAULT NULL,
  `include_check_number` int(11) NOT NULL DEFAULT 1,
  `include_bank_name` int(11) NOT NULL DEFAULT 1,
  `bank_name` varchar(255) DEFAULT NULL,
  `address_line_1` text DEFAULT NULL,
  `address_line_2` text DEFAULT NULL,
  `vendor_city` varchar(100) DEFAULT NULL,
  `vendor_zip` varchar(15) DEFAULT NULL,
  `vendor_state` varchar(50) DEFAULT NULL,
  `vendor_address` text DEFAULT NULL,
  `reason_for_void` text DEFAULT NULL,
  `bill_items` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblacc_checks`
--

LOCK TABLES `himalay_tblacc_checks` WRITE;
/*!40000 ALTER TABLE `himalay_tblacc_checks` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblacc_checks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblacc_checks_printed`
--

DROP TABLE IF EXISTS `himalay_tblacc_checks_printed`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblacc_checks_printed` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `check_id` int(11) DEFAULT NULL,
  `bank_account` int(11) DEFAULT NULL,
  `first_check_number` int(11) DEFAULT NULL,
  `printed_at` datetime DEFAULT NULL,
  `printed_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblacc_checks_printed`
--

LOCK TABLES `himalay_tblacc_checks_printed` WRITE;
/*!40000 ALTER TABLE `himalay_tblacc_checks_printed` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblacc_checks_printed` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblacc_expense_category_mapping_details`
--

DROP TABLE IF EXISTS `himalay_tblacc_expense_category_mapping_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblacc_expense_category_mapping_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_mapping_id` int(11) NOT NULL,
  `payment_mode_id` int(11) NOT NULL,
  `payment_account` int(11) NOT NULL DEFAULT 0,
  `deposit_to` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblacc_expense_category_mapping_details`
--

LOCK TABLES `himalay_tblacc_expense_category_mapping_details` WRITE;
/*!40000 ALTER TABLE `himalay_tblacc_expense_category_mapping_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblacc_expense_category_mapping_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblacc_expense_category_mappings`
--

DROP TABLE IF EXISTS `himalay_tblacc_expense_category_mappings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblacc_expense_category_mappings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `payment_account` int(11) NOT NULL DEFAULT 0,
  `deposit_to` int(11) NOT NULL DEFAULT 0,
  `preferred_payment_method` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblacc_expense_category_mappings`
--

LOCK TABLES `himalay_tblacc_expense_category_mappings` WRITE;
/*!40000 ALTER TABLE `himalay_tblacc_expense_category_mappings` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblacc_expense_category_mappings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblacc_income_statement_modifications`
--

DROP TABLE IF EXISTS `himalay_tblacc_income_statement_modifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblacc_income_statement_modifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `account` int(11) DEFAULT NULL,
  `active` int(11) NOT NULL DEFAULT 1,
  `account_type` int(11) DEFAULT NULL,
  `options` text DEFAULT NULL,
  `dateadded` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `type` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblacc_income_statement_modifications`
--

LOCK TABLES `himalay_tblacc_income_statement_modifications` WRITE;
/*!40000 ALTER TABLE `himalay_tblacc_income_statement_modifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblacc_income_statement_modifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblacc_item_automatics`
--

DROP TABLE IF EXISTS `himalay_tblacc_item_automatics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblacc_item_automatics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL,
  `inventory_asset_account` int(11) NOT NULL DEFAULT 0,
  `income_account` int(11) NOT NULL DEFAULT 0,
  `expense_account` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblacc_item_automatics`
--

LOCK TABLES `himalay_tblacc_item_automatics` WRITE;
/*!40000 ALTER TABLE `himalay_tblacc_item_automatics` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblacc_item_automatics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblacc_journal_entries`
--

DROP TABLE IF EXISTS `himalay_tblacc_journal_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblacc_journal_entries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `number` varchar(45) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `journal_date` date DEFAULT NULL,
  `amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `reference` varchar(100) DEFAULT NULL,
  `recurring` int(11) NOT NULL DEFAULT 0,
  `recurring_type` varchar(10) DEFAULT NULL,
  `custom_recurring` tinyint(1) NOT NULL DEFAULT 0,
  `cycles` int(11) NOT NULL DEFAULT 0,
  `total_cycles` int(11) NOT NULL DEFAULT 0,
  `is_recurring_from` int(11) DEFAULT NULL,
  `last_recurring_date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblacc_journal_entries`
--

LOCK TABLES `himalay_tblacc_journal_entries` WRITE;
/*!40000 ALTER TABLE `himalay_tblacc_journal_entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblacc_journal_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblacc_matched_transactions`
--

DROP TABLE IF EXISTS `himalay_tblacc_matched_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblacc_matched_transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_history_id` int(11) DEFAULT NULL,
  `history_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(255) DEFAULT NULL,
  `amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `company` int(11) DEFAULT NULL,
  `reconcile` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblacc_matched_transactions`
--

LOCK TABLES `himalay_tblacc_matched_transactions` WRITE;
/*!40000 ALTER TABLE `himalay_tblacc_matched_transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblacc_matched_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblacc_pay_bill_details`
--

DROP TABLE IF EXISTS `himalay_tblacc_pay_bill_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblacc_pay_bill_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pay_bill` int(11) DEFAULT NULL,
  `bill_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblacc_pay_bill_details`
--

LOCK TABLES `himalay_tblacc_pay_bill_details` WRITE;
/*!40000 ALTER TABLE `himalay_tblacc_pay_bill_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblacc_pay_bill_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblacc_pay_bill_item_paid`
--

DROP TABLE IF EXISTS `himalay_tblacc_pay_bill_item_paid`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblacc_pay_bill_item_paid` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pay_bill_id` int(11) NOT NULL DEFAULT 0,
  `item_id` int(11) DEFAULT NULL,
  `item_name` varchar(255) DEFAULT NULL,
  `item_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `amount_paid` decimal(15,2) NOT NULL DEFAULT 0.00,
  `check_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblacc_pay_bill_item_paid`
--

LOCK TABLES `himalay_tblacc_pay_bill_item_paid` WRITE;
/*!40000 ALTER TABLE `himalay_tblacc_pay_bill_item_paid` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblacc_pay_bill_item_paid` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblacc_pay_bills`
--

DROP TABLE IF EXISTS `himalay_tblacc_pay_bills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblacc_pay_bills` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `expense` int(11) DEFAULT NULL,
  `amount` decimal(15,2) DEFAULT NULL,
  `reference_no` varchar(100) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `dateadded` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `company` int(11) DEFAULT NULL,
  `account_debit` int(11) DEFAULT NULL,
  `account_credit` int(11) DEFAULT NULL,
  `bill` int(11) NOT NULL DEFAULT 0,
  `vendor` int(11) NOT NULL DEFAULT 0,
  `pay_number` int(11) DEFAULT NULL,
  `payment_method` varchar(255) DEFAULT NULL,
  `bill_items` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblacc_pay_bills`
--

LOCK TABLES `himalay_tblacc_pay_bills` WRITE;
/*!40000 ALTER TABLE `himalay_tblacc_pay_bills` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblacc_pay_bills` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblacc_payment_mode_mappings`
--

DROP TABLE IF EXISTS `himalay_tblacc_payment_mode_mappings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblacc_payment_mode_mappings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `payment_mode_id` int(11) NOT NULL,
  `payment_account` int(11) NOT NULL DEFAULT 0,
  `deposit_to` int(11) NOT NULL DEFAULT 0,
  `expense_payment_account` int(11) NOT NULL DEFAULT 0,
  `expense_deposit_to` int(11) NOT NULL DEFAULT 0,
  `credit_note_refund_payment_account` int(11) NOT NULL DEFAULT 0,
  `credit_note_refund_deposit_to` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblacc_payment_mode_mappings`
--

LOCK TABLES `himalay_tblacc_payment_mode_mappings` WRITE;
/*!40000 ALTER TABLE `himalay_tblacc_payment_mode_mappings` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblacc_payment_mode_mappings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblacc_plaid_transaction_logs`
--

DROP TABLE IF EXISTS `himalay_tblacc_plaid_transaction_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblacc_plaid_transaction_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bank_id` int(11) DEFAULT NULL,
  `last_updated` date DEFAULT NULL,
  `transaction_count` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `addedFrom` int(11) DEFAULT NULL,
  `company` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblacc_plaid_transaction_logs`
--

LOCK TABLES `himalay_tblacc_plaid_transaction_logs` WRITE;
/*!40000 ALTER TABLE `himalay_tblacc_plaid_transaction_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblacc_plaid_transaction_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblacc_print_later`
--

DROP TABLE IF EXISTS `himalay_tblacc_print_later`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblacc_print_later` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(45) DEFAULT NULL,
  `account` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblacc_print_later`
--

LOCK TABLES `himalay_tblacc_print_later` WRITE;
/*!40000 ALTER TABLE `himalay_tblacc_print_later` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblacc_print_later` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblacc_reconciles`
--

DROP TABLE IF EXISTS `himalay_tblacc_reconciles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblacc_reconciles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account` int(11) NOT NULL,
  `beginning_balance` decimal(15,2) NOT NULL,
  `ending_balance` decimal(15,2) NOT NULL,
  `ending_date` date NOT NULL,
  `expense_date` date DEFAULT NULL,
  `service_charge` decimal(15,2) DEFAULT NULL,
  `expense_account` int(11) DEFAULT NULL,
  `income_date` date DEFAULT NULL,
  `interest_earned` decimal(15,2) DEFAULT NULL,
  `income_account` int(11) DEFAULT NULL,
  `finish` int(11) NOT NULL DEFAULT 0,
  `opening_balance` int(11) NOT NULL DEFAULT 0,
  `debits_for_period` decimal(15,2) DEFAULT NULL,
  `credits_for_period` decimal(15,2) DEFAULT NULL,
  `dateadded` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblacc_reconciles`
--

LOCK TABLES `himalay_tblacc_reconciles` WRITE;
/*!40000 ALTER TABLE `himalay_tblacc_reconciles` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblacc_reconciles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblacc_tax_mappings`
--

DROP TABLE IF EXISTS `himalay_tblacc_tax_mappings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblacc_tax_mappings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tax_id` int(11) NOT NULL,
  `payment_account` int(11) NOT NULL DEFAULT 0,
  `deposit_to` int(11) NOT NULL DEFAULT 0,
  `expense_payment_account` int(11) NOT NULL DEFAULT 0,
  `expense_deposit_to` int(11) NOT NULL DEFAULT 0,
  `purchase_payment_account` int(11) NOT NULL DEFAULT 0,
  `purchase_deposit_to` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblacc_tax_mappings`
--

LOCK TABLES `himalay_tblacc_tax_mappings` WRITE;
/*!40000 ALTER TABLE `himalay_tblacc_tax_mappings` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblacc_tax_mappings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblacc_transaction_bankings`
--

DROP TABLE IF EXISTS `himalay_tblacc_transaction_bankings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblacc_transaction_bankings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `withdrawals` decimal(15,2) NOT NULL DEFAULT 0.00,
  `deposits` decimal(15,2) NOT NULL DEFAULT 0.00,
  `payee` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `transaction_id` varchar(150) DEFAULT NULL,
  `bank_id` int(11) DEFAULT NULL,
  `status` tinyint(5) NOT NULL DEFAULT 0 COMMENT '1=>posted, 2=>pending',
  `matched` int(11) NOT NULL DEFAULT 0,
  `reconcile` int(11) NOT NULL DEFAULT 0,
  `adjusted` int(11) NOT NULL DEFAULT 0,
  `is_imported` int(11) NOT NULL DEFAULT 0,
  `banking_rule` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblacc_transaction_bankings`
--

LOCK TABLES `himalay_tblacc_transaction_bankings` WRITE;
/*!40000 ALTER TABLE `himalay_tblacc_transaction_bankings` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblacc_transaction_bankings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblacc_transfers`
--

DROP TABLE IF EXISTS `himalay_tblacc_transfers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblacc_transfers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transfer_funds_from` int(11) NOT NULL,
  `transfer_funds_to` int(11) NOT NULL,
  `transfer_amount` decimal(15,2) DEFAULT NULL,
  `date` varchar(45) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblacc_transfers`
--

LOCK TABLES `himalay_tblacc_transfers` WRITE;
/*!40000 ALTER TABLE `himalay_tblacc_transfers` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblacc_transfers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblaccount_planning`
--

DROP TABLE IF EXISTS `himalay_tblaccount_planning`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblaccount_planning` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) NOT NULL,
  `vision` varchar(255) DEFAULT NULL,
  `mission` varchar(255) DEFAULT NULL,
  `lead_generation` varchar(45) DEFAULT NULL,
  `current_service_know_pmax` varchar(45) DEFAULT NULL,
  `current_service_facebook` varchar(45) DEFAULT NULL,
  `current_service_sem` varchar(45) DEFAULT NULL,
  `objectives` varchar(255) DEFAULT NULL,
  `threat` varchar(255) DEFAULT NULL,
  `opportunity` varchar(255) DEFAULT NULL,
  `criteria_to_success` varchar(255) DEFAULT NULL,
  `constraints` varchar(255) DEFAULT NULL,
  `data_tree` longtext DEFAULT NULL,
  `latest_update` date DEFAULT NULL,
  `new_update` date DEFAULT NULL,
  `product` varchar(255) DEFAULT NULL,
  `sale_channel_online` varchar(255) DEFAULT NULL,
  `sale_channel_offline` varchar(255) DEFAULT NULL,
  `revenue_next_year` varchar(255) DEFAULT NULL,
  `wallet_share` varchar(255) DEFAULT NULL,
  `client_status` varchar(255) DEFAULT NULL,
  `bcg_model` varchar(255) DEFAULT NULL,
  `margin` varchar(255) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblaccount_planning`
--

LOCK TABLES `himalay_tblaccount_planning` WRITE;
/*!40000 ALTER TABLE `himalay_tblaccount_planning` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblaccount_planning` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblaccount_planning_current_service`
--

DROP TABLE IF EXISTS `himalay_tblaccount_planning_current_service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblaccount_planning_current_service` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_planning_id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `potential` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblaccount_planning_current_service`
--

LOCK TABLES `himalay_tblaccount_planning_current_service` WRITE;
/*!40000 ALTER TABLE `himalay_tblaccount_planning_current_service` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblaccount_planning_current_service` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblaccount_planning_financial`
--

DROP TABLE IF EXISTS `himalay_tblaccount_planning_financial`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblaccount_planning_financial` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_planning_id` int(11) NOT NULL,
  `year` varchar(45) DEFAULT NULL,
  `revenue` varchar(255) DEFAULT NULL,
  `sales_spent` varchar(255) DEFAULT NULL,
  `traffic` varchar(255) DEFAULT NULL,
  `loss` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblaccount_planning_financial`
--

LOCK TABLES `himalay_tblaccount_planning_financial` WRITE;
/*!40000 ALTER TABLE `himalay_tblaccount_planning_financial` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblaccount_planning_financial` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblaccount_planning_items`
--

DROP TABLE IF EXISTS `himalay_tblaccount_planning_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblaccount_planning_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_planning_id` int(11) NOT NULL,
  `objective_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `datecreated` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblaccount_planning_items`
--

LOCK TABLES `himalay_tblaccount_planning_items` WRITE;
/*!40000 ALTER TABLE `himalay_tblaccount_planning_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblaccount_planning_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblaccount_planning_marketing_activities`
--

DROP TABLE IF EXISTS `himalay_tblaccount_planning_marketing_activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblaccount_planning_marketing_activities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_planning_id` int(11) NOT NULL,
  `item` varchar(255) DEFAULT NULL,
  `reference` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblaccount_planning_marketing_activities`
--

LOCK TABLES `himalay_tblaccount_planning_marketing_activities` WRITE;
/*!40000 ALTER TABLE `himalay_tblaccount_planning_marketing_activities` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblaccount_planning_marketing_activities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblaccount_planning_objective`
--

DROP TABLE IF EXISTS `himalay_tblaccount_planning_objective`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblaccount_planning_objective` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_planning_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `datecreated` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblaccount_planning_objective`
--

LOCK TABLES `himalay_tblaccount_planning_objective` WRITE;
/*!40000 ALTER TABLE `himalay_tblaccount_planning_objective` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblaccount_planning_objective` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblaccount_planning_service_ability_offering`
--

DROP TABLE IF EXISTS `himalay_tblaccount_planning_service_ability_offering`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblaccount_planning_service_ability_offering` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_planning_id` int(11) NOT NULL,
  `service` varchar(255) DEFAULT NULL,
  `potential` varchar(255) DEFAULT NULL,
  `scale` varchar(255) DEFAULT NULL,
  `convert` varchar(255) DEFAULT NULL,
  `prioritization` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblaccount_planning_service_ability_offering`
--

LOCK TABLES `himalay_tblaccount_planning_service_ability_offering` WRITE;
/*!40000 ALTER TABLE `himalay_tblaccount_planning_service_ability_offering` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblaccount_planning_service_ability_offering` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblaccount_planning_task`
--

DROP TABLE IF EXISTS `himalay_tblaccount_planning_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblaccount_planning_task` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL,
  `account_planning_id` int(11) DEFAULT NULL,
  `action_needed` varchar(255) NOT NULL,
  `prioritization` varchar(255) DEFAULT NULL,
  `pic` varchar(255) DEFAULT NULL,
  `deadline` date DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `objective` varchar(255) DEFAULT NULL,
  `item` varchar(255) DEFAULT NULL,
  `convert_to_task` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblaccount_planning_task`
--

LOCK TABLES `himalay_tblaccount_planning_task` WRITE;
/*!40000 ALTER TABLE `himalay_tblaccount_planning_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblaccount_planning_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblaccount_planning_team`
--

DROP TABLE IF EXISTS `himalay_tblaccount_planning_team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblaccount_planning_team` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_planning_id` int(11) NOT NULL,
  `rel_id` varchar(45) NOT NULL,
  `rel_type` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblaccount_planning_team`
--

LOCK TABLES `himalay_tblaccount_planning_team` WRITE;
/*!40000 ALTER TABLE `himalay_tblaccount_planning_team` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblaccount_planning_team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblactivity_log`
--

DROP TABLE IF EXISTS `himalay_tblactivity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblactivity_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` longtext NOT NULL,
  `date` datetime NOT NULL,
  `staffid` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `himalay_staffid` (`staffid`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblactivity_log`
--

LOCK TABLES `himalay_tblactivity_log` WRITE;
/*!40000 ALTER TABLE `himalay_tblactivity_log` DISABLE KEYS */;
INSERT INTO `himalay_tblactivity_log` VALUES (1,'New Client Created [ID: 1]','2025-07-09 13:01:16','[CRON]'),(2,'New Leads Source Added [SourceID: 3, Name: Flexstage Events]','2025-07-09 13:01:16','[CRON]'),(3,'New Leads Status Added [StatusID: 2, Name: Event Attendees]','2025-07-09 13:01:16','[CRON]'),(4,'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 110.172.155.237]','2025-07-09 13:01:58','faizan ahmad'),(5,'New Staff Member Added [ID: 2, Musheer Belal]','2025-07-09 13:03:31','faizan ahmad'),(6,'New Staff Member Added [ID: 3, Mohd  Faiz]','2025-07-09 13:04:17','faizan ahmad'),(7,'New Staff Member Added [ID: 4, Aquib Imtiyaz]','2025-07-09 13:05:15','faizan ahmad'),(8,'New Lead Added [ID: 1]','2025-07-09 13:08:10','faizan ahmad'),(9,'New Lead Added [ID: 2]','2025-07-09 13:08:31','faizan ahmad'),(10,'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 49.36.189.194]','2025-07-09 13:19:20','faizan ahmad'),(11,'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 110.172.155.237]','2025-07-09 14:03:40','faizan ahmad'),(12,'Staff Member Deleted [Name: Aquib Imtiyaz, Data Transferred To: faizan ahmad]','2025-07-09 14:04:24','faizan ahmad'),(13,'New Staff Member Added [ID: 5, Shafique Siddiqui]','2025-07-09 14:06:57','faizan ahmad'),(14,'New Staff Member Added [ID: 6, Tauseef  Alam]','2025-07-09 14:08:09','faizan ahmad'),(15,'Staff Member Updated [ID: 6, Tauseef  Alam]','2025-07-09 14:09:01','faizan ahmad'),(16,'Staff Member Updated [ID: 6, Tauseef  Alam]','2025-07-09 14:09:02','faizan ahmad'),(17,'New Staff Member Added [ID: 7, Mahfooz Khan]','2025-07-09 14:10:50','faizan ahmad'),(18,'New Staff Member Added [ID: 8, Javed Khan]','2025-07-09 14:12:28','faizan ahmad'),(19,'New Staff Member Added [ID: 9, Sameer Ahmed]','2025-07-09 14:13:50','faizan ahmad'),(20,'New Staff Member Added [ID: 10, Raj Kumar]','2025-07-09 14:15:40','faizan ahmad'),(21,'New Staff Member Added [ID: 11, Ashish Kumar]','2025-07-09 14:17:15','faizan ahmad'),(22,'New Staff Member Added [ID: 12, Dilshad Khan]','2025-07-09 14:19:02','faizan ahmad'),(23,'Non Existing User Tried to Login [Email: Faiz@himalay.com, Is Staff Member: Yes, IP: 42.105.212.56]','2025-07-09 14:22:22',NULL),(24,'User Successfully Logged In [User Id: 3, Is Staff Member: Yes, IP: 42.105.212.56]','2025-07-09 14:23:05','Mohd  Faiz'),(25,'User Successfully Logged In [User Id: 2, Is Staff Member: Yes, IP: 152.58.131.50]','2025-07-09 14:23:07','Musheer Belal'),(26,'Staff Member Updated [ID: 3, Mohd  Faiz]','2025-07-09 14:24:45','faizan ahmad'),(27,'Staff Member Updated [ID: 2, Musheer Belal]','2025-07-09 15:08:10','faizan ahmad'),(28,'User Successfully Logged In [User Id: 2, Is Staff Member: Yes, IP: 103.95.164.179]','2025-07-10 13:11:49','Musheer Belal'),(29,'Non Existing User Tried to Login [Email: dkhan54098@gmail.com, Is Staff Member: Yes, IP: 223.184.153.158]','2025-07-10 13:14:42',NULL),(30,'Failed Login Attempt [Email: dilshad@himalayply.com, Is Staff Member: Yes, IP: 223.184.153.158]','2025-07-10 13:16:09',NULL),(31,'Non Existing User Tried to Login [Email: ashish@himalyply.com, Is Staff Member: Yes, IP: 103.95.164.179]','2025-07-10 13:16:24',NULL),(32,'Non Existing User Tried to Login [Email: ashish@himalyply.com, Is Staff Member: Yes, IP: 103.95.164.179]','2025-07-10 13:17:03',NULL),(33,'Failed Login Attempt [Email: dilshad@himalayply.com, Is Staff Member: Yes, IP: 223.184.153.158]','2025-07-10 13:17:26',NULL),(34,'Non Existing User Tried to Login [Email: ashish@himalyply.com, Is Staff Member: Yes, IP: 103.95.164.179]','2025-07-10 13:17:28',NULL),(35,'Failed Login Attempt [Email: dilshad@himalayply.com, Is Staff Member: Yes, IP: 223.184.153.158]','2025-07-10 13:17:51',NULL),(36,'Failed Login Attempt [Email: dilshad@himalayply.com, Is Staff Member: Yes, IP: 223.184.153.158]','2025-07-10 13:18:07',NULL),(37,'Non Existing User Tried to Login [Email: ashish@himalyply.com, Is Staff Member: No, IP: 103.95.164.179]','2025-07-10 13:18:52',NULL),(38,'Failed Login Attempt [Email: dilshad@himalayply.com, Is Staff Member: Yes, IP: 223.184.153.158]','2025-07-10 13:19:20',NULL),(39,'Non Existing User Tried to Login [Email: ashish@himalyply.com, Is Staff Member: No, IP: 103.95.164.179]','2025-07-10 13:19:55',NULL),(40,'User Successfully Logged In [User Id: 12, Is Staff Member: Yes, IP: 223.184.153.158]','2025-07-10 13:20:04','Dilshad Khan'),(41,'Non Existing User Tried to Login [Email: ashish@himalyply.com, Is Staff Member: No, IP: 103.95.164.179]','2025-07-10 13:20:21',NULL),(42,'Non Existing User Tried to Login [Email: ashish@himalyply.com, Is Staff Member: No, IP: 103.95.164.179]','2025-07-10 13:20:40',NULL),(43,'Non Existing User Tried to Login [Email: ashish@himalyply.com, Is Staff Member: No, IP: 103.95.164.179]','2025-07-10 13:21:15',NULL),(44,'Non Existing User Tried to Login [Email: ashish@himalyply.com, Is Staff Member: No, IP: 103.95.164.179]','2025-07-10 13:21:41',NULL),(45,'Non Existing User Tried to Login [Email: ashish@himalyply.com, Is Staff Member: No, IP: 103.95.164.179]','2025-07-10 13:22:20',NULL),(46,'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 49.36.189.194]','2025-07-10 18:15:47','faizan ahmad'),(47,'Failed Login Attempt [Email: dilshad@himalayply.com, Is Staff Member: Yes, IP: 106.205.68.112]','2025-07-11 09:23:10',NULL),(48,'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 49.36.189.194]','2025-07-11 14:55:33','faizan ahmad');
/*!40000 ALTER TABLE `himalay_tblactivity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblaffiliate_m_affiliates`
--

DROP TABLE IF EXISTS `himalay_tblaffiliate_m_affiliates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblaffiliate_m_affiliates` (
  `affiliate_id` int(11) NOT NULL AUTO_INCREMENT,
  `affiliate_slug` varchar(255) NOT NULL,
  `group_id` varchar(255) DEFAULT NULL,
  `contact_id` int(11) NOT NULL,
  `total_earnings` decimal(10,2) DEFAULT 0.00,
  `balance` decimal(10,2) DEFAULT 0.00,
  `status` varchar(255) DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`affiliate_id`),
  UNIQUE KEY `unique_himalay_tbl_contact_id` (`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblaffiliate_m_affiliates`
--

LOCK TABLES `himalay_tblaffiliate_m_affiliates` WRITE;
/*!40000 ALTER TABLE `himalay_tblaffiliate_m_affiliates` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblaffiliate_m_affiliates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblaffiliate_m_commissions`
--

DROP TABLE IF EXISTS `himalay_tblaffiliate_m_commissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblaffiliate_m_commissions` (
  `commission_id` int(11) NOT NULL AUTO_INCREMENT,
  `referral_id` int(11) NOT NULL,
  `affiliate_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `payment_id` int(11) DEFAULT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `rule_info` varchar(255) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`commission_id`),
  KEY `fk_himalay_tbl_commission_referral_id` (`referral_id`),
  KEY `fk_himalay_tbl_commission_affiliate_id` (`affiliate_id`),
  CONSTRAINT `fk_himalay_tbl_commission_affiliate_id` FOREIGN KEY (`affiliate_id`) REFERENCES `himalay_tblaffiliate_m_affiliates` (`affiliate_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_himalay_tbl_commission_referral_id` FOREIGN KEY (`referral_id`) REFERENCES `himalay_tblaffiliate_m_referrals` (`referral_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblaffiliate_m_commissions`
--

LOCK TABLES `himalay_tblaffiliate_m_commissions` WRITE;
/*!40000 ALTER TABLE `himalay_tblaffiliate_m_commissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblaffiliate_m_commissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblaffiliate_m_payouts`
--

DROP TABLE IF EXISTS `himalay_tblaffiliate_m_payouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblaffiliate_m_payouts` (
  `payout_id` int(11) NOT NULL AUTO_INCREMENT,
  `affiliate_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `note_for_affiliate` text DEFAULT NULL,
  `note_for_admin` text DEFAULT NULL,
  `payout_method` varchar(255) NOT NULL,
  `status` varchar(255) DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`payout_id`),
  KEY `fk_himalay_tbl_afm_payout_affiliate_id` (`affiliate_id`),
  CONSTRAINT `fk_himalay_tbl_afm_payout_affiliate_id` FOREIGN KEY (`affiliate_id`) REFERENCES `himalay_tblaffiliate_m_affiliates` (`affiliate_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblaffiliate_m_payouts`
--

LOCK TABLES `himalay_tblaffiliate_m_payouts` WRITE;
/*!40000 ALTER TABLE `himalay_tblaffiliate_m_payouts` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblaffiliate_m_payouts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblaffiliate_m_referrals`
--

DROP TABLE IF EXISTS `himalay_tblaffiliate_m_referrals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblaffiliate_m_referrals` (
  `referral_id` int(11) NOT NULL AUTO_INCREMENT,
  `affiliate_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `ua` text DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`referral_id`),
  UNIQUE KEY `unique_himalay_tbl_client_id` (`client_id`),
  KEY `fk_himalay_tbl_referral_affiliate_id` (`affiliate_id`),
  CONSTRAINT `fk_himalay_tbl_referral_affiliate_id` FOREIGN KEY (`affiliate_id`) REFERENCES `himalay_tblaffiliate_m_affiliates` (`affiliate_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblaffiliate_m_referrals`
--

LOCK TABLES `himalay_tblaffiliate_m_referrals` WRITE;
/*!40000 ALTER TABLE `himalay_tblaffiliate_m_referrals` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblaffiliate_m_referrals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblaffiliate_m_tracking`
--

DROP TABLE IF EXISTS `himalay_tblaffiliate_m_tracking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblaffiliate_m_tracking` (
  `tracking_id` int(11) NOT NULL AUTO_INCREMENT,
  `affiliate_slug` varchar(255) NOT NULL,
  `rel_type` varchar(255) NOT NULL,
  `rel_id` int(11) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phonenumber` varchar(255) DEFAULT NULL,
  `metadata` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`tracking_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblaffiliate_m_tracking`
--

LOCK TABLES `himalay_tblaffiliate_m_tracking` WRITE;
/*!40000 ALTER TABLE `himalay_tblaffiliate_m_tracking` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblaffiliate_m_tracking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblannouncements`
--

DROP TABLE IF EXISTS `himalay_tblannouncements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblannouncements` (
  `announcementid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `message` mediumtext DEFAULT NULL,
  `showtousers` int(11) NOT NULL,
  `showtostaff` int(11) NOT NULL,
  `showname` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  `userid` varchar(100) NOT NULL,
  PRIMARY KEY (`announcementid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblannouncements`
--

LOCK TABLES `himalay_tblannouncements` WRITE;
/*!40000 ALTER TABLE `himalay_tblannouncements` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblannouncements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblappointly_appointment_types`
--

DROP TABLE IF EXISTS `himalay_tblappointly_appointment_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblappointly_appointment_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(191) NOT NULL,
  `color` varchar(191) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblappointly_appointment_types`
--

LOCK TABLES `himalay_tblappointly_appointment_types` WRITE;
/*!40000 ALTER TABLE `himalay_tblappointly_appointment_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblappointly_appointment_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblappointly_appointments`
--

DROP TABLE IF EXISTS `himalay_tblappointly_appointments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblappointly_appointments` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `google_event_id` varchar(191) DEFAULT NULL,
  `google_calendar_link` varchar(191) DEFAULT NULL,
  `google_meet_link` varchar(191) DEFAULT NULL,
  `google_added_by_id` int(11) DEFAULT NULL,
  `outlook_event_id` varchar(191) DEFAULT NULL,
  `outlook_calendar_link` varchar(255) DEFAULT NULL,
  `outlook_added_by_id` int(11) DEFAULT NULL,
  `subject` varchar(191) NOT NULL,
  `description` text DEFAULT NULL,
  `email` varchar(191) DEFAULT NULL,
  `name` varchar(191) DEFAULT NULL,
  `phone` varchar(191) DEFAULT NULL,
  `address` varchar(191) DEFAULT NULL,
  `notes` longtext DEFAULT NULL,
  `contact_id` int(11) DEFAULT NULL,
  `by_sms` tinyint(1) DEFAULT NULL,
  `by_email` tinyint(1) DEFAULT NULL,
  `hash` varchar(191) DEFAULT NULL,
  `notification_date` datetime DEFAULT NULL,
  `external_notification_date` datetime DEFAULT NULL,
  `date` date NOT NULL,
  `start_hour` varchar(191) NOT NULL,
  `approved` tinyint(1) NOT NULL DEFAULT 0,
  `created_by` int(11) DEFAULT NULL,
  `reminder_before` int(11) DEFAULT NULL,
  `reminder_before_type` varchar(10) DEFAULT NULL,
  `finished` tinyint(1) NOT NULL DEFAULT 0,
  `cancelled` tinyint(1) NOT NULL DEFAULT 0,
  `cancel_notes` text DEFAULT NULL,
  `source` varchar(191) DEFAULT NULL,
  `type_id` int(11) NOT NULL DEFAULT 0,
  `feedback` smallint(6) DEFAULT NULL,
  `feedback_comment` text DEFAULT NULL,
  `recurring` int(11) NOT NULL DEFAULT 0,
  `recurring_type` varchar(10) DEFAULT NULL,
  `repeat_every` int(11) DEFAULT NULL,
  `custom_recurring` tinyint(4) NOT NULL,
  `cycles` int(11) NOT NULL DEFAULT 0,
  `total_cycles` int(11) NOT NULL DEFAULT 0,
  `last_recurring_date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblappointly_appointments`
--

LOCK TABLES `himalay_tblappointly_appointments` WRITE;
/*!40000 ALTER TABLE `himalay_tblappointly_appointments` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblappointly_appointments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblappointly_attendees`
--

DROP TABLE IF EXISTS `himalay_tblappointly_attendees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblappointly_attendees` (
  `staff_id` int(11) NOT NULL,
  `appointment_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblappointly_attendees`
--

LOCK TABLES `himalay_tblappointly_attendees` WRITE;
/*!40000 ALTER TABLE `himalay_tblappointly_attendees` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblappointly_attendees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblappointly_callbacks`
--

DROP TABLE IF EXISTS `himalay_tblappointly_callbacks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblappointly_callbacks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `call_type` varchar(191) NOT NULL,
  `phone_number` varchar(191) NOT NULL,
  `timezone` varchar(191) NOT NULL,
  `firstname` varchar(191) NOT NULL,
  `lastname` varchar(191) NOT NULL,
  `status` varchar(191) NOT NULL DEFAULT '1',
  `message` text NOT NULL,
  `email` varchar(191) NOT NULL,
  `date_start` datetime NOT NULL,
  `date_end` datetime NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblappointly_callbacks`
--

LOCK TABLES `himalay_tblappointly_callbacks` WRITE;
/*!40000 ALTER TABLE `himalay_tblappointly_callbacks` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblappointly_callbacks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblappointly_callbacks_assignees`
--

DROP TABLE IF EXISTS `himalay_tblappointly_callbacks_assignees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblappointly_callbacks_assignees` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `callbackid` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblappointly_callbacks_assignees`
--

LOCK TABLES `himalay_tblappointly_callbacks_assignees` WRITE;
/*!40000 ALTER TABLE `himalay_tblappointly_callbacks_assignees` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblappointly_callbacks_assignees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblappointly_google`
--

DROP TABLE IF EXISTS `himalay_tblappointly_google`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblappointly_google` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `access_token` varchar(191) NOT NULL,
  `refresh_token` varchar(191) NOT NULL,
  `expires_in` varchar(191) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblappointly_google`
--

LOCK TABLES `himalay_tblappointly_google` WRITE;
/*!40000 ALTER TABLE `himalay_tblappointly_google` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblappointly_google` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblbonus_discipline`
--

DROP TABLE IF EXISTS `himalay_tblbonus_discipline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblbonus_discipline` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `id_criteria` varchar(200) DEFAULT NULL,
  `type` int(3) NOT NULL,
  `apply_for` varchar(50) DEFAULT NULL,
  `from_time` datetime DEFAULT NULL,
  `lever_bonus` int(11) DEFAULT NULL,
  `approver` int(11) DEFAULT NULL,
  `url_file` longtext DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `id_admin` int(3) DEFAULT NULL,
  `status` int(3) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblbonus_discipline`
--

LOCK TABLES `himalay_tblbonus_discipline` WRITE;
/*!40000 ALTER TABLE `himalay_tblbonus_discipline` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblbonus_discipline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblbonus_discipline_detail`
--

DROP TABLE IF EXISTS `himalay_tblbonus_discipline_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblbonus_discipline_detail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_bonus_discipline` int(11) NOT NULL,
  `from_time` datetime DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `department_id` longtext DEFAULT NULL,
  `lever_bonus` int(11) DEFAULT NULL,
  `formality` varchar(50) DEFAULT NULL,
  `formality_value` varchar(100) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblbonus_discipline_detail`
--

LOCK TABLES `himalay_tblbonus_discipline_detail` WRITE;
/*!40000 ALTER TABLE `himalay_tblbonus_discipline_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblbonus_discipline_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblcd_care`
--

DROP TABLE IF EXISTS `himalay_tblcd_care`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblcd_care` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `candidate` int(11) NOT NULL,
  `care_time` datetime NOT NULL,
  `care_result` text NOT NULL,
  `description` text DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  `add_time` datetime DEFAULT NULL,
  `type` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblcd_care`
--

LOCK TABLES `himalay_tblcd_care` WRITE;
/*!40000 ALTER TABLE `himalay_tblcd_care` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblcd_care` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblcd_family_infor`
--

DROP TABLE IF EXISTS `himalay_tblcd_family_infor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblcd_family_infor` (
  `fi_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `candidate` int(11) NOT NULL,
  `relationship` varchar(100) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `fi_birthday` date DEFAULT NULL,
  `job` varchar(200) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `phone` int(15) DEFAULT NULL,
  PRIMARY KEY (`fi_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblcd_family_infor`
--

LOCK TABLES `himalay_tblcd_family_infor` WRITE;
/*!40000 ALTER TABLE `himalay_tblcd_family_infor` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblcd_family_infor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblcd_interview`
--

DROP TABLE IF EXISTS `himalay_tblcd_interview`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblcd_interview` (
  `in_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `candidate` int(11) NOT NULL,
  `interview` int(11) NOT NULL,
  `cd_from_hours` datetime DEFAULT NULL,
  `cd_to_hours` datetime DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`in_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblcd_interview`
--

LOCK TABLES `himalay_tblcd_interview` WRITE;
/*!40000 ALTER TABLE `himalay_tblcd_interview` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblcd_interview` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblcd_literacy`
--

DROP TABLE IF EXISTS `himalay_tblcd_literacy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblcd_literacy` (
  `li_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `candidate` int(11) NOT NULL,
  `literacy_from_date` date DEFAULT NULL,
  `literacy_to_date` date DEFAULT NULL,
  `diploma` varchar(200) DEFAULT NULL,
  `training_places` varchar(200) DEFAULT NULL,
  `specialized` varchar(200) DEFAULT NULL,
  `training_form` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`li_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblcd_literacy`
--

LOCK TABLES `himalay_tblcd_literacy` WRITE;
/*!40000 ALTER TABLE `himalay_tblcd_literacy` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblcd_literacy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblcd_skill`
--

DROP TABLE IF EXISTS `himalay_tblcd_skill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblcd_skill` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `candidate` int(11) NOT NULL,
  `skill_name` text DEFAULT NULL,
  `skill_description` text DEFAULT NULL,
  PRIMARY KEY (`id`,`candidate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblcd_skill`
--

LOCK TABLES `himalay_tblcd_skill` WRITE;
/*!40000 ALTER TABLE `himalay_tblcd_skill` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblcd_skill` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblcd_work_experience`
--

DROP TABLE IF EXISTS `himalay_tblcd_work_experience`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblcd_work_experience` (
  `we_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `candidate` int(11) NOT NULL,
  `from_date` date DEFAULT NULL,
  `to_date` date DEFAULT NULL,
  `company` varchar(200) DEFAULT NULL,
  `position` varchar(200) DEFAULT NULL,
  `contact_person` varchar(200) DEFAULT NULL,
  `salary` varchar(200) DEFAULT NULL,
  `reason_quitwork` varchar(200) DEFAULT NULL,
  `job_description` text DEFAULT NULL,
  PRIMARY KEY (`we_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblcd_work_experience`
--

LOCK TABLES `himalay_tblcd_work_experience` WRITE;
/*!40000 ALTER TABLE `himalay_tblcd_work_experience` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblcd_work_experience` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblcheck_in_out`
--

DROP TABLE IF EXISTS `himalay_tblcheck_in_out`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblcheck_in_out` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `type_check` int(11) DEFAULT NULL,
  `type` varchar(5) NOT NULL DEFAULT 'W',
  `route_point_id` int(11) DEFAULT NULL,
  `workplace_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblcheck_in_out`
--

LOCK TABLES `himalay_tblcheck_in_out` WRITE;
/*!40000 ALTER TABLE `himalay_tblcheck_in_out` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblcheck_in_out` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblchecklist`
--

DROP TABLE IF EXISTS `himalay_tblchecklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblchecklist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `group_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblchecklist`
--

LOCK TABLES `himalay_tblchecklist` WRITE;
/*!40000 ALTER TABLE `himalay_tblchecklist` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblchecklist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblchecklist_allocation`
--

DROP TABLE IF EXISTS `himalay_tblchecklist_allocation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblchecklist_allocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `group_id` int(11) DEFAULT NULL,
  `staffid` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblchecklist_allocation`
--

LOCK TABLES `himalay_tblchecklist_allocation` WRITE;
/*!40000 ALTER TABLE `himalay_tblchecklist_allocation` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblchecklist_allocation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblclients`
--

DROP TABLE IF EXISTS `himalay_tblclients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblclients` (
  `userid` int(11) NOT NULL AUTO_INCREMENT,
  `company` varchar(191) DEFAULT NULL,
  `vat` varchar(50) DEFAULT NULL,
  `phonenumber` varchar(30) DEFAULT NULL,
  `country` int(11) NOT NULL DEFAULT 0,
  `city` varchar(100) DEFAULT NULL,
  `zip` varchar(15) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `address` varchar(191) DEFAULT NULL,
  `website` varchar(150) DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `active` int(11) NOT NULL DEFAULT 1,
  `leadid` int(11) DEFAULT NULL,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT 0,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT 0,
  `longitude` varchar(191) DEFAULT NULL,
  `latitude` varchar(191) DEFAULT NULL,
  `default_language` varchar(40) DEFAULT NULL,
  `default_currency` int(11) NOT NULL DEFAULT 0,
  `show_primary_contact` int(11) NOT NULL DEFAULT 0,
  `stripe_id` varchar(40) DEFAULT NULL,
  `registration_confirmed` int(11) NOT NULL DEFAULT 1,
  `addedfrom` int(11) NOT NULL DEFAULT 0,
  `balance` decimal(15,2) DEFAULT NULL,
  `balance_as_of` date DEFAULT NULL,
  `loy_point` decimal(10,0) DEFAULT 0,
  `sector` varchar(255) DEFAULT NULL,
  `industry` varchar(255) DEFAULT NULL,
  `continue_from_date` date DEFAULT NULL,
  PRIMARY KEY (`userid`),
  KEY `country` (`country`),
  KEY `leadid` (`leadid`),
  KEY `company` (`company`),
  KEY `active` (`active`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblclients`
--

LOCK TABLES `himalay_tblclients` WRITE;
/*!40000 ALTER TABLE `himalay_tblclients` DISABLE KEYS */;
INSERT INTO `himalay_tblclients` VALUES (1,'Flexstage Event Records',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'2025-07-09 13:01:16',1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,0,0,NULL,1,0,NULL,NULL,0,NULL,NULL,NULL);
/*!40000 ALTER TABLE `himalay_tblclients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblconsent_purposes`
--

DROP TABLE IF EXISTS `himalay_tblconsent_purposes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblconsent_purposes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `last_updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblconsent_purposes`
--

LOCK TABLES `himalay_tblconsent_purposes` WRITE;
/*!40000 ALTER TABLE `himalay_tblconsent_purposes` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblconsent_purposes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblconsents`
--

DROP TABLE IF EXISTS `himalay_tblconsents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblconsents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action` varchar(10) NOT NULL,
  `date` datetime NOT NULL,
  `ip` varchar(40) NOT NULL,
  `contact_id` int(11) NOT NULL DEFAULT 0,
  `lead_id` int(11) NOT NULL DEFAULT 0,
  `description` mediumtext DEFAULT NULL,
  `opt_in_purpose_description` mediumtext DEFAULT NULL,
  `purpose_id` int(11) NOT NULL,
  `staff_name` varchar(100) DEFAULT NULL,
  `candidate_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `purpose_id` (`purpose_id`),
  KEY `contact_id` (`contact_id`),
  KEY `lead_id` (`lead_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblconsents`
--

LOCK TABLES `himalay_tblconsents` WRITE;
/*!40000 ALTER TABLE `himalay_tblconsents` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblconsents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblcontact_permissions`
--

DROP TABLE IF EXISTS `himalay_tblcontact_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblcontact_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permission_id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblcontact_permissions`
--

LOCK TABLES `himalay_tblcontact_permissions` WRITE;
/*!40000 ALTER TABLE `himalay_tblcontact_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblcontact_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblcontacts`
--

DROP TABLE IF EXISTS `himalay_tblcontacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblcontacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `is_primary` int(11) NOT NULL DEFAULT 1,
  `firstname` varchar(191) NOT NULL,
  `lastname` varchar(191) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phonenumber` varchar(100) NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `new_pass_key` varchar(32) DEFAULT NULL,
  `new_pass_key_requested` datetime DEFAULT NULL,
  `email_verified_at` datetime DEFAULT NULL,
  `email_verification_key` varchar(32) DEFAULT NULL,
  `email_verification_sent_at` datetime DEFAULT NULL,
  `last_ip` varchar(40) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_password_change` datetime DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `profile_image` varchar(191) DEFAULT NULL,
  `direction` varchar(3) DEFAULT NULL,
  `invoice_emails` tinyint(1) NOT NULL DEFAULT 1,
  `estimate_emails` tinyint(1) NOT NULL DEFAULT 1,
  `credit_note_emails` tinyint(1) NOT NULL DEFAULT 1,
  `contract_emails` tinyint(1) NOT NULL DEFAULT 1,
  `task_emails` tinyint(1) NOT NULL DEFAULT 1,
  `project_emails` tinyint(1) NOT NULL DEFAULT 1,
  `ticket_emails` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `firstname` (`firstname`),
  KEY `lastname` (`lastname`),
  KEY `email` (`email`),
  KEY `is_primary` (`is_primary`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblcontacts`
--

LOCK TABLES `himalay_tblcontacts` WRITE;
/*!40000 ALTER TABLE `himalay_tblcontacts` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblcontacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblcontract_comments`
--

DROP TABLE IF EXISTS `himalay_tblcontract_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblcontract_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` longtext DEFAULT NULL,
  `contract_id` int(11) NOT NULL,
  `staffid` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblcontract_comments`
--

LOCK TABLES `himalay_tblcontract_comments` WRITE;
/*!40000 ALTER TABLE `himalay_tblcontract_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblcontract_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblcontract_renewals`
--

DROP TABLE IF EXISTS `himalay_tblcontract_renewals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblcontract_renewals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contractid` int(11) NOT NULL,
  `old_start_date` date NOT NULL,
  `new_start_date` date NOT NULL,
  `old_end_date` date DEFAULT NULL,
  `new_end_date` date DEFAULT NULL,
  `old_value` decimal(15,2) DEFAULT NULL,
  `new_value` decimal(15,2) DEFAULT NULL,
  `date_renewed` datetime NOT NULL,
  `renewed_by` varchar(100) NOT NULL,
  `renewed_by_staff_id` int(11) NOT NULL DEFAULT 0,
  `is_on_old_expiry_notified` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblcontract_renewals`
--

LOCK TABLES `himalay_tblcontract_renewals` WRITE;
/*!40000 ALTER TABLE `himalay_tblcontract_renewals` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblcontract_renewals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblcontracts`
--

DROP TABLE IF EXISTS `himalay_tblcontracts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblcontracts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` longtext DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `subject` varchar(191) DEFAULT NULL,
  `client` int(11) NOT NULL,
  `datestart` date DEFAULT NULL,
  `dateend` date DEFAULT NULL,
  `contract_type` int(11) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  `isexpirynotified` int(11) NOT NULL DEFAULT 0,
  `contract_value` decimal(15,2) DEFAULT NULL,
  `trash` tinyint(1) DEFAULT 0,
  `not_visible_to_client` tinyint(1) NOT NULL DEFAULT 0,
  `hash` varchar(32) DEFAULT NULL,
  `signed` tinyint(1) NOT NULL DEFAULT 0,
  `signature` varchar(40) DEFAULT NULL,
  `marked_as_signed` tinyint(1) NOT NULL DEFAULT 0,
  `acceptance_firstname` varchar(50) DEFAULT NULL,
  `acceptance_lastname` varchar(50) DEFAULT NULL,
  `acceptance_email` varchar(100) DEFAULT NULL,
  `acceptance_date` datetime DEFAULT NULL,
  `acceptance_ip` varchar(40) DEFAULT NULL,
  `short_link` varchar(100) DEFAULT NULL,
  `last_sent_at` datetime DEFAULT NULL,
  `contacts_sent_to` mediumtext DEFAULT NULL,
  `last_sign_reminder_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `client` (`client`),
  KEY `contract_type` (`contract_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblcontracts`
--

LOCK TABLES `himalay_tblcontracts` WRITE;
/*!40000 ALTER TABLE `himalay_tblcontracts` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblcontracts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblcontracts_types`
--

DROP TABLE IF EXISTS `himalay_tblcontracts_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblcontracts_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblcontracts_types`
--

LOCK TABLES `himalay_tblcontracts_types` WRITE;
/*!40000 ALTER TABLE `himalay_tblcontracts_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblcontracts_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblcountries`
--

DROP TABLE IF EXISTS `himalay_tblcountries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblcountries` (
  `country_id` int(11) NOT NULL AUTO_INCREMENT,
  `iso2` char(2) DEFAULT NULL,
  `short_name` varchar(80) NOT NULL DEFAULT '',
  `long_name` varchar(80) NOT NULL DEFAULT '',
  `iso3` char(3) DEFAULT NULL,
  `numcode` varchar(6) DEFAULT NULL,
  `un_member` varchar(12) DEFAULT NULL,
  `calling_code` varchar(8) DEFAULT NULL,
  `cctld` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`country_id`)
) ENGINE=InnoDB AUTO_INCREMENT=251 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblcountries`
--

LOCK TABLES `himalay_tblcountries` WRITE;
/*!40000 ALTER TABLE `himalay_tblcountries` DISABLE KEYS */;
INSERT INTO `himalay_tblcountries` VALUES (1,'AF','Afghanistan','Islamic Republic of Afghanistan','AFG','004','yes','93','.af'),(2,'AX','Aland Islands','&Aring;land Islands','ALA','248','no','358','.ax'),(3,'AL','Albania','Republic of Albania','ALB','008','yes','355','.al'),(4,'DZ','Algeria','People\'s Democratic Republic of Algeria','DZA','012','yes','213','.dz'),(5,'AS','American Samoa','American Samoa','ASM','016','no','1+684','.as'),(6,'AD','Andorra','Principality of Andorra','AND','020','yes','376','.ad'),(7,'AO','Angola','Republic of Angola','AGO','024','yes','244','.ao'),(8,'AI','Anguilla','Anguilla','AIA','660','no','1+264','.ai'),(9,'AQ','Antarctica','Antarctica','ATA','010','no','672','.aq'),(10,'AG','Antigua and Barbuda','Antigua and Barbuda','ATG','028','yes','1+268','.ag'),(11,'AR','Argentina','Argentine Republic','ARG','032','yes','54','.ar'),(12,'AM','Armenia','Republic of Armenia','ARM','051','yes','374','.am'),(13,'AW','Aruba','Aruba','ABW','533','no','297','.aw'),(14,'AU','Australia','Commonwealth of Australia','AUS','036','yes','61','.au'),(15,'AT','Austria','Republic of Austria','AUT','040','yes','43','.at'),(16,'AZ','Azerbaijan','Republic of Azerbaijan','AZE','031','yes','994','.az'),(17,'BS','Bahamas','Commonwealth of The Bahamas','BHS','044','yes','1+242','.bs'),(18,'BH','Bahrain','Kingdom of Bahrain','BHR','048','yes','973','.bh'),(19,'BD','Bangladesh','People\'s Republic of Bangladesh','BGD','050','yes','880','.bd'),(20,'BB','Barbados','Barbados','BRB','052','yes','1+246','.bb'),(21,'BY','Belarus','Republic of Belarus','BLR','112','yes','375','.by'),(22,'BE','Belgium','Kingdom of Belgium','BEL','056','yes','32','.be'),(23,'BZ','Belize','Belize','BLZ','084','yes','501','.bz'),(24,'BJ','Benin','Republic of Benin','BEN','204','yes','229','.bj'),(25,'BM','Bermuda','Bermuda Islands','BMU','060','no','1+441','.bm'),(26,'BT','Bhutan','Kingdom of Bhutan','BTN','064','yes','975','.bt'),(27,'BO','Bolivia','Plurinational State of Bolivia','BOL','068','yes','591','.bo'),(28,'BQ','Bonaire, Sint Eustatius and Saba','Bonaire, Sint Eustatius and Saba','BES','535','no','599','.bq'),(29,'BA','Bosnia and Herzegovina','Bosnia and Herzegovina','BIH','070','yes','387','.ba'),(30,'BW','Botswana','Republic of Botswana','BWA','072','yes','267','.bw'),(31,'BV','Bouvet Island','Bouvet Island','BVT','074','no','NONE','.bv'),(32,'BR','Brazil','Federative Republic of Brazil','BRA','076','yes','55','.br'),(33,'IO','British Indian Ocean Territory','British Indian Ocean Territory','IOT','086','no','246','.io'),(34,'BN','Brunei','Brunei Darussalam','BRN','096','yes','673','.bn'),(35,'BG','Bulgaria','Republic of Bulgaria','BGR','100','yes','359','.bg'),(36,'BF','Burkina Faso','Burkina Faso','BFA','854','yes','226','.bf'),(37,'BI','Burundi','Republic of Burundi','BDI','108','yes','257','.bi'),(38,'KH','Cambodia','Kingdom of Cambodia','KHM','116','yes','855','.kh'),(39,'CM','Cameroon','Republic of Cameroon','CMR','120','yes','237','.cm'),(40,'CA','Canada','Canada','CAN','124','yes','1','.ca'),(41,'CV','Cape Verde','Republic of Cape Verde','CPV','132','yes','238','.cv'),(42,'KY','Cayman Islands','The Cayman Islands','CYM','136','no','1+345','.ky'),(43,'CF','Central African Republic','Central African Republic','CAF','140','yes','236','.cf'),(44,'TD','Chad','Republic of Chad','TCD','148','yes','235','.td'),(45,'CL','Chile','Republic of Chile','CHL','152','yes','56','.cl'),(46,'CN','China','People\'s Republic of China','CHN','156','yes','86','.cn'),(47,'CX','Christmas Island','Christmas Island','CXR','162','no','61','.cx'),(48,'CC','Cocos (Keeling) Islands','Cocos (Keeling) Islands','CCK','166','no','61','.cc'),(49,'CO','Colombia','Republic of Colombia','COL','170','yes','57','.co'),(50,'KM','Comoros','Union of the Comoros','COM','174','yes','269','.km'),(51,'CG','Congo','Republic of the Congo','COG','178','yes','242','.cg'),(52,'CK','Cook Islands','Cook Islands','COK','184','some','682','.ck'),(53,'CR','Costa Rica','Republic of Costa Rica','CRI','188','yes','506','.cr'),(54,'CI','Cote d\'ivoire (Ivory Coast)','Republic of C&ocirc;te D\'Ivoire (Ivory Coast)','CIV','384','yes','225','.ci'),(55,'HR','Croatia','Republic of Croatia','HRV','191','yes','385','.hr'),(56,'CU','Cuba','Republic of Cuba','CUB','192','yes','53','.cu'),(57,'CW','Curacao','Cura&ccedil;ao','CUW','531','no','599','.cw'),(58,'CY','Cyprus','Republic of Cyprus','CYP','196','yes','357','.cy'),(59,'CZ','Czech Republic','Czech Republic','CZE','203','yes','420','.cz'),(60,'CD','Democratic Republic of the Congo','Democratic Republic of the Congo','COD','180','yes','243','.cd'),(61,'DK','Denmark','Kingdom of Denmark','DNK','208','yes','45','.dk'),(62,'DJ','Djibouti','Republic of Djibouti','DJI','262','yes','253','.dj'),(63,'DM','Dominica','Commonwealth of Dominica','DMA','212','yes','1+767','.dm'),(64,'DO','Dominican Republic','Dominican Republic','DOM','214','yes','1+809, 8','.do'),(65,'EC','Ecuador','Republic of Ecuador','ECU','218','yes','593','.ec'),(66,'EG','Egypt','Arab Republic of Egypt','EGY','818','yes','20','.eg'),(67,'SV','El Salvador','Republic of El Salvador','SLV','222','yes','503','.sv'),(68,'GQ','Equatorial Guinea','Republic of Equatorial Guinea','GNQ','226','yes','240','.gq'),(69,'ER','Eritrea','State of Eritrea','ERI','232','yes','291','.er'),(70,'EE','Estonia','Republic of Estonia','EST','233','yes','372','.ee'),(71,'ET','Ethiopia','Federal Democratic Republic of Ethiopia','ETH','231','yes','251','.et'),(72,'FK','Falkland Islands (Malvinas)','The Falkland Islands (Malvinas)','FLK','238','no','500','.fk'),(73,'FO','Faroe Islands','The Faroe Islands','FRO','234','no','298','.fo'),(74,'FJ','Fiji','Republic of Fiji','FJI','242','yes','679','.fj'),(75,'FI','Finland','Republic of Finland','FIN','246','yes','358','.fi'),(76,'FR','France','French Republic','FRA','250','yes','33','.fr'),(77,'GF','French Guiana','French Guiana','GUF','254','no','594','.gf'),(78,'PF','French Polynesia','French Polynesia','PYF','258','no','689','.pf'),(79,'TF','French Southern Territories','French Southern Territories','ATF','260','no',NULL,'.tf'),(80,'GA','Gabon','Gabonese Republic','GAB','266','yes','241','.ga'),(81,'GM','Gambia','Republic of The Gambia','GMB','270','yes','220','.gm'),(82,'GE','Georgia','Georgia','GEO','268','yes','995','.ge'),(83,'DE','Germany','Federal Republic of Germany','DEU','276','yes','49','.de'),(84,'GH','Ghana','Republic of Ghana','GHA','288','yes','233','.gh'),(85,'GI','Gibraltar','Gibraltar','GIB','292','no','350','.gi'),(86,'GR','Greece','Hellenic Republic','GRC','300','yes','30','.gr'),(87,'GL','Greenland','Greenland','GRL','304','no','299','.gl'),(88,'GD','Grenada','Grenada','GRD','308','yes','1+473','.gd'),(89,'GP','Guadaloupe','Guadeloupe','GLP','312','no','590','.gp'),(90,'GU','Guam','Guam','GUM','316','no','1+671','.gu'),(91,'GT','Guatemala','Republic of Guatemala','GTM','320','yes','502','.gt'),(92,'GG','Guernsey','Guernsey','GGY','831','no','44','.gg'),(93,'GN','Guinea','Republic of Guinea','GIN','324','yes','224','.gn'),(94,'GW','Guinea-Bissau','Republic of Guinea-Bissau','GNB','624','yes','245','.gw'),(95,'GY','Guyana','Co-operative Republic of Guyana','GUY','328','yes','592','.gy'),(96,'HT','Haiti','Republic of Haiti','HTI','332','yes','509','.ht'),(97,'HM','Heard Island and McDonald Islands','Heard Island and McDonald Islands','HMD','334','no','NONE','.hm'),(98,'HN','Honduras','Republic of Honduras','HND','340','yes','504','.hn'),(99,'HK','Hong Kong','Hong Kong','HKG','344','no','852','.hk'),(100,'HU','Hungary','Hungary','HUN','348','yes','36','.hu'),(101,'IS','Iceland','Republic of Iceland','ISL','352','yes','354','.is'),(102,'IN','India','Republic of India','IND','356','yes','91','.in'),(103,'ID','Indonesia','Republic of Indonesia','IDN','360','yes','62','.id'),(104,'IR','Iran','Islamic Republic of Iran','IRN','364','yes','98','.ir'),(105,'IQ','Iraq','Republic of Iraq','IRQ','368','yes','964','.iq'),(106,'IE','Ireland','Ireland','IRL','372','yes','353','.ie'),(107,'IM','Isle of Man','Isle of Man','IMN','833','no','44','.im'),(108,'IL','Israel','State of Israel','ISR','376','yes','972','.il'),(109,'IT','Italy','Italian Republic','ITA','380','yes','39','.jm'),(110,'JM','Jamaica','Jamaica','JAM','388','yes','1+876','.jm'),(111,'JP','Japan','Japan','JPN','392','yes','81','.jp'),(112,'JE','Jersey','The Bailiwick of Jersey','JEY','832','no','44','.je'),(113,'JO','Jordan','Hashemite Kingdom of Jordan','JOR','400','yes','962','.jo'),(114,'KZ','Kazakhstan','Republic of Kazakhstan','KAZ','398','yes','7','.kz'),(115,'KE','Kenya','Republic of Kenya','KEN','404','yes','254','.ke'),(116,'KI','Kiribati','Republic of Kiribati','KIR','296','yes','686','.ki'),(117,'XK','Kosovo','Republic of Kosovo','---','---','some','381',''),(118,'KW','Kuwait','State of Kuwait','KWT','414','yes','965','.kw'),(119,'KG','Kyrgyzstan','Kyrgyz Republic','KGZ','417','yes','996','.kg'),(120,'LA','Laos','Lao People\'s Democratic Republic','LAO','418','yes','856','.la'),(121,'LV','Latvia','Republic of Latvia','LVA','428','yes','371','.lv'),(122,'LB','Lebanon','Republic of Lebanon','LBN','422','yes','961','.lb'),(123,'LS','Lesotho','Kingdom of Lesotho','LSO','426','yes','266','.ls'),(124,'LR','Liberia','Republic of Liberia','LBR','430','yes','231','.lr'),(125,'LY','Libya','Libya','LBY','434','yes','218','.ly'),(126,'LI','Liechtenstein','Principality of Liechtenstein','LIE','438','yes','423','.li'),(127,'LT','Lithuania','Republic of Lithuania','LTU','440','yes','370','.lt'),(128,'LU','Luxembourg','Grand Duchy of Luxembourg','LUX','442','yes','352','.lu'),(129,'MO','Macao','The Macao Special Administrative Region','MAC','446','no','853','.mo'),(130,'MK','North Macedonia','Republic of North Macedonia','MKD','807','yes','389','.mk'),(131,'MG','Madagascar','Republic of Madagascar','MDG','450','yes','261','.mg'),(132,'MW','Malawi','Republic of Malawi','MWI','454','yes','265','.mw'),(133,'MY','Malaysia','Malaysia','MYS','458','yes','60','.my'),(134,'MV','Maldives','Republic of Maldives','MDV','462','yes','960','.mv'),(135,'ML','Mali','Republic of Mali','MLI','466','yes','223','.ml'),(136,'MT','Malta','Republic of Malta','MLT','470','yes','356','.mt'),(137,'MH','Marshall Islands','Republic of the Marshall Islands','MHL','584','yes','692','.mh'),(138,'MQ','Martinique','Martinique','MTQ','474','no','596','.mq'),(139,'MR','Mauritania','Islamic Republic of Mauritania','MRT','478','yes','222','.mr'),(140,'MU','Mauritius','Republic of Mauritius','MUS','480','yes','230','.mu'),(141,'YT','Mayotte','Mayotte','MYT','175','no','262','.yt'),(142,'MX','Mexico','United Mexican States','MEX','484','yes','52','.mx'),(143,'FM','Micronesia','Federated States of Micronesia','FSM','583','yes','691','.fm'),(144,'MD','Moldava','Republic of Moldova','MDA','498','yes','373','.md'),(145,'MC','Monaco','Principality of Monaco','MCO','492','yes','377','.mc'),(146,'MN','Mongolia','Mongolia','MNG','496','yes','976','.mn'),(147,'ME','Montenegro','Montenegro','MNE','499','yes','382','.me'),(148,'MS','Montserrat','Montserrat','MSR','500','no','1+664','.ms'),(149,'MA','Morocco','Kingdom of Morocco','MAR','504','yes','212','.ma'),(150,'MZ','Mozambique','Republic of Mozambique','MOZ','508','yes','258','.mz'),(151,'MM','Myanmar (Burma)','Republic of the Union of Myanmar','MMR','104','yes','95','.mm'),(152,'NA','Namibia','Republic of Namibia','NAM','516','yes','264','.na'),(153,'NR','Nauru','Republic of Nauru','NRU','520','yes','674','.nr'),(154,'NP','Nepal','Federal Democratic Republic of Nepal','NPL','524','yes','977','.np'),(155,'NL','Netherlands','Kingdom of the Netherlands','NLD','528','yes','31','.nl'),(156,'NC','New Caledonia','New Caledonia','NCL','540','no','687','.nc'),(157,'NZ','New Zealand','New Zealand','NZL','554','yes','64','.nz'),(158,'NI','Nicaragua','Republic of Nicaragua','NIC','558','yes','505','.ni'),(159,'NE','Niger','Republic of Niger','NER','562','yes','227','.ne'),(160,'NG','Nigeria','Federal Republic of Nigeria','NGA','566','yes','234','.ng'),(161,'NU','Niue','Niue','NIU','570','some','683','.nu'),(162,'NF','Norfolk Island','Norfolk Island','NFK','574','no','672','.nf'),(163,'KP','North Korea','Democratic People\'s Republic of Korea','PRK','408','yes','850','.kp'),(164,'MP','Northern Mariana Islands','Northern Mariana Islands','MNP','580','no','1+670','.mp'),(165,'NO','Norway','Kingdom of Norway','NOR','578','yes','47','.no'),(166,'OM','Oman','Sultanate of Oman','OMN','512','yes','968','.om'),(167,'PK','Pakistan','Islamic Republic of Pakistan','PAK','586','yes','92','.pk'),(168,'PW','Palau','Republic of Palau','PLW','585','yes','680','.pw'),(169,'PS','Palestine','State of Palestine (or Occupied Palestinian Territory)','PSE','275','some','970','.ps'),(170,'PA','Panama','Republic of Panama','PAN','591','yes','507','.pa'),(171,'PG','Papua New Guinea','Independent State of Papua New Guinea','PNG','598','yes','675','.pg'),(172,'PY','Paraguay','Republic of Paraguay','PRY','600','yes','595','.py'),(173,'PE','Peru','Republic of Peru','PER','604','yes','51','.pe'),(174,'PH','Philippines','Republic of the Philippines','PHL','608','yes','63','.ph'),(175,'PN','Pitcairn','Pitcairn','PCN','612','no','NONE','.pn'),(176,'PL','Poland','Republic of Poland','POL','616','yes','48','.pl'),(177,'PT','Portugal','Portuguese Republic','PRT','620','yes','351','.pt'),(178,'PR','Puerto Rico','Commonwealth of Puerto Rico','PRI','630','no','1+939','.pr'),(179,'QA','Qatar','State of Qatar','QAT','634','yes','974','.qa'),(180,'RE','Reunion','R&eacute;union','REU','638','no','262','.re'),(181,'RO','Romania','Romania','ROU','642','yes','40','.ro'),(182,'RU','Russia','Russian Federation','RUS','643','yes','7','.ru'),(183,'RW','Rwanda','Republic of Rwanda','RWA','646','yes','250','.rw'),(184,'BL','Saint Barthelemy','Saint Barth&eacute;lemy','BLM','652','no','590','.bl'),(185,'SH','Saint Helena','Saint Helena, Ascension and Tristan da Cunha','SHN','654','no','290','.sh'),(186,'KN','Saint Kitts and Nevis','Federation of Saint Christopher and Nevis','KNA','659','yes','1+869','.kn'),(187,'LC','Saint Lucia','Saint Lucia','LCA','662','yes','1+758','.lc'),(188,'MF','Saint Martin','Saint Martin','MAF','663','no','590','.mf'),(189,'PM','Saint Pierre and Miquelon','Saint Pierre and Miquelon','SPM','666','no','508','.pm'),(190,'VC','Saint Vincent and the Grenadines','Saint Vincent and the Grenadines','VCT','670','yes','1+784','.vc'),(191,'WS','Samoa','Independent State of Samoa','WSM','882','yes','685','.ws'),(192,'SM','San Marino','Republic of San Marino','SMR','674','yes','378','.sm'),(193,'ST','Sao Tome and Principe','Democratic Republic of S&atilde;o Tom&eacute; and Pr&iacute;ncipe','STP','678','yes','239','.st'),(194,'SA','Saudi Arabia','Kingdom of Saudi Arabia','SAU','682','yes','966','.sa'),(195,'SN','Senegal','Republic of Senegal','SEN','686','yes','221','.sn'),(196,'RS','Serbia','Republic of Serbia','SRB','688','yes','381','.rs'),(197,'SC','Seychelles','Republic of Seychelles','SYC','690','yes','248','.sc'),(198,'SL','Sierra Leone','Republic of Sierra Leone','SLE','694','yes','232','.sl'),(199,'SG','Singapore','Republic of Singapore','SGP','702','yes','65','.sg'),(200,'SX','Sint Maarten','Sint Maarten','SXM','534','no','1+721','.sx'),(201,'SK','Slovakia','Slovak Republic','SVK','703','yes','421','.sk'),(202,'SI','Slovenia','Republic of Slovenia','SVN','705','yes','386','.si'),(203,'SB','Solomon Islands','Solomon Islands','SLB','090','yes','677','.sb'),(204,'SO','Somalia','Somali Republic','SOM','706','yes','252','.so'),(205,'ZA','South Africa','Republic of South Africa','ZAF','710','yes','27','.za'),(206,'GS','South Georgia and the South Sandwich Islands','South Georgia and the South Sandwich Islands','SGS','239','no','500','.gs'),(207,'KR','South Korea','Republic of Korea','KOR','410','yes','82','.kr'),(208,'SS','South Sudan','Republic of South Sudan','SSD','728','yes','211','.ss'),(209,'ES','Spain','Kingdom of Spain','ESP','724','yes','34','.es'),(210,'LK','Sri Lanka','Democratic Socialist Republic of Sri Lanka','LKA','144','yes','94','.lk'),(211,'SD','Sudan','Republic of the Sudan','SDN','729','yes','249','.sd'),(212,'SR','Suriname','Republic of Suriname','SUR','740','yes','597','.sr'),(213,'SJ','Svalbard and Jan Mayen','Svalbard and Jan Mayen','SJM','744','no','47','.sj'),(214,'SZ','Swaziland','Kingdom of Swaziland','SWZ','748','yes','268','.sz'),(215,'SE','Sweden','Kingdom of Sweden','SWE','752','yes','46','.se'),(216,'CH','Switzerland','Swiss Confederation','CHE','756','yes','41','.ch'),(217,'SY','Syria','Syrian Arab Republic','SYR','760','yes','963','.sy'),(218,'TW','Taiwan','Republic of China (Taiwan)','TWN','158','former','886','.tw'),(219,'TJ','Tajikistan','Republic of Tajikistan','TJK','762','yes','992','.tj'),(220,'TZ','Tanzania','United Republic of Tanzania','TZA','834','yes','255','.tz'),(221,'TH','Thailand','Kingdom of Thailand','THA','764','yes','66','.th'),(222,'TL','Timor-Leste (East Timor)','Democratic Republic of Timor-Leste','TLS','626','yes','670','.tl'),(223,'TG','Togo','Togolese Republic','TGO','768','yes','228','.tg'),(224,'TK','Tokelau','Tokelau','TKL','772','no','690','.tk'),(225,'TO','Tonga','Kingdom of Tonga','TON','776','yes','676','.to'),(226,'TT','Trinidad and Tobago','Republic of Trinidad and Tobago','TTO','780','yes','1+868','.tt'),(227,'TN','Tunisia','Republic of Tunisia','TUN','788','yes','216','.tn'),(228,'TR','Turkey','Republic of Turkey','TUR','792','yes','90','.tr'),(229,'TM','Turkmenistan','Turkmenistan','TKM','795','yes','993','.tm'),(230,'TC','Turks and Caicos Islands','Turks and Caicos Islands','TCA','796','no','1+649','.tc'),(231,'TV','Tuvalu','Tuvalu','TUV','798','yes','688','.tv'),(232,'UG','Uganda','Republic of Uganda','UGA','800','yes','256','.ug'),(233,'UA','Ukraine','Ukraine','UKR','804','yes','380','.ua'),(234,'AE','United Arab Emirates','United Arab Emirates','ARE','784','yes','971','.ae'),(235,'GB','United Kingdom','United Kingdom of Great Britain and Nothern Ireland','GBR','826','yes','44','.uk'),(236,'US','United States','United States of America','USA','840','yes','1','.us'),(237,'UM','United States Minor Outlying Islands','United States Minor Outlying Islands','UMI','581','no','NONE','NONE'),(238,'UY','Uruguay','Eastern Republic of Uruguay','URY','858','yes','598','.uy'),(239,'UZ','Uzbekistan','Republic of Uzbekistan','UZB','860','yes','998','.uz'),(240,'VU','Vanuatu','Republic of Vanuatu','VUT','548','yes','678','.vu'),(241,'VA','Vatican City','State of the Vatican City','VAT','336','no','39','.va'),(242,'VE','Venezuela','Bolivarian Republic of Venezuela','VEN','862','yes','58','.ve'),(243,'VN','Vietnam','Socialist Republic of Vietnam','VNM','704','yes','84','.vn'),(244,'VG','Virgin Islands, British','British Virgin Islands','VGB','092','no','1+284','.vg'),(245,'VI','Virgin Islands, US','Virgin Islands of the United States','VIR','850','no','1+340','.vi'),(246,'WF','Wallis and Futuna','Wallis and Futuna','WLF','876','no','681','.wf'),(247,'EH','Western Sahara','Western Sahara','ESH','732','no','212','.eh'),(248,'YE','Yemen','Republic of Yemen','YEM','887','yes','967','.ye'),(249,'ZM','Zambia','Republic of Zambia','ZMB','894','yes','260','.zm'),(250,'ZW','Zimbabwe','Republic of Zimbabwe','ZWE','716','yes','263','.zw');
/*!40000 ALTER TABLE `himalay_tblcountries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblcreditnote_refunds`
--

DROP TABLE IF EXISTS `himalay_tblcreditnote_refunds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblcreditnote_refunds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `credit_note_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `refunded_on` date NOT NULL,
  `payment_mode` varchar(40) NOT NULL,
  `note` mediumtext DEFAULT NULL,
  `amount` decimal(15,2) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblcreditnote_refunds`
--

LOCK TABLES `himalay_tblcreditnote_refunds` WRITE;
/*!40000 ALTER TABLE `himalay_tblcreditnote_refunds` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblcreditnote_refunds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblcreditnotes`
--

DROP TABLE IF EXISTS `himalay_tblcreditnotes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblcreditnotes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clientid` int(11) NOT NULL,
  `deleted_customer_name` varchar(100) DEFAULT NULL,
  `number` int(11) NOT NULL,
  `prefix` varchar(50) DEFAULT NULL,
  `number_format` int(11) NOT NULL DEFAULT 1,
  `datecreated` datetime NOT NULL,
  `date` date NOT NULL,
  `adminnote` mediumtext DEFAULT NULL,
  `terms` mediumtext DEFAULT NULL,
  `clientnote` mediumtext DEFAULT NULL,
  `currency` int(11) NOT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `total_tax` decimal(15,2) NOT NULL DEFAULT 0.00,
  `total` decimal(15,2) NOT NULL,
  `adjustment` decimal(15,2) DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `project_id` int(11) NOT NULL DEFAULT 0,
  `discount_percent` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `discount_type` varchar(30) NOT NULL,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT NULL,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT NULL,
  `include_shipping` tinyint(1) NOT NULL,
  `show_shipping_on_credit_note` tinyint(1) NOT NULL DEFAULT 1,
  `show_quantity_as` int(11) NOT NULL DEFAULT 1,
  `reference_no` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `currency` (`currency`),
  KEY `clientid` (`clientid`),
  KEY `project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblcreditnotes`
--

LOCK TABLES `himalay_tblcreditnotes` WRITE;
/*!40000 ALTER TABLE `himalay_tblcreditnotes` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblcreditnotes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblcredits`
--

DROP TABLE IF EXISTS `himalay_tblcredits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblcredits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) NOT NULL,
  `credit_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `date_applied` datetime NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblcredits`
--

LOCK TABLES `himalay_tblcredits` WRITE;
/*!40000 ALTER TABLE `himalay_tblcredits` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblcredits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblcurrencies`
--

DROP TABLE IF EXISTS `himalay_tblcurrencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblcurrencies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `decimal_separator` varchar(5) DEFAULT NULL,
  `thousand_separator` varchar(5) DEFAULT NULL,
  `placement` varchar(10) DEFAULT NULL,
  `isdefault` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblcurrencies`
--

LOCK TABLES `himalay_tblcurrencies` WRITE;
/*!40000 ALTER TABLE `himalay_tblcurrencies` DISABLE KEYS */;
INSERT INTO `himalay_tblcurrencies` VALUES (1,'$','USD','.',',','before',0),(3,'?','INR','.',',','before',1);
/*!40000 ALTER TABLE `himalay_tblcurrencies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblcurrency_rate_logs`
--

DROP TABLE IF EXISTS `himalay_tblcurrency_rate_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblcurrency_rate_logs` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `from_currency_id` int(11) DEFAULT NULL,
  `from_currency_name` varchar(100) DEFAULT NULL,
  `from_currency_rate` decimal(15,6) NOT NULL DEFAULT 0.000000,
  `to_currency_id` int(11) DEFAULT NULL,
  `to_currency_name` varchar(100) DEFAULT NULL,
  `to_currency_rate` decimal(15,6) NOT NULL DEFAULT 0.000000,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblcurrency_rate_logs`
--

LOCK TABLES `himalay_tblcurrency_rate_logs` WRITE;
/*!40000 ALTER TABLE `himalay_tblcurrency_rate_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblcurrency_rate_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblcurrency_rates`
--

DROP TABLE IF EXISTS `himalay_tblcurrency_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblcurrency_rates` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `from_currency_id` int(11) DEFAULT NULL,
  `from_currency_name` varchar(100) DEFAULT NULL,
  `from_currency_rate` decimal(15,6) NOT NULL DEFAULT 0.000000,
  `to_currency_id` int(11) DEFAULT NULL,
  `to_currency_name` varchar(100) DEFAULT NULL,
  `to_currency_rate` decimal(15,6) NOT NULL DEFAULT 0.000000,
  `date_updated` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblcurrency_rates`
--

LOCK TABLES `himalay_tblcurrency_rates` WRITE;
/*!40000 ALTER TABLE `himalay_tblcurrency_rates` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblcurrency_rates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblcustomer_admins`
--

DROP TABLE IF EXISTS `himalay_tblcustomer_admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblcustomer_admins` (
  `staff_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `date_assigned` mediumtext NOT NULL,
  KEY `customer_id` (`customer_id`),
  KEY `himalay_staff_id` (`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblcustomer_admins`
--

LOCK TABLES `himalay_tblcustomer_admins` WRITE;
/*!40000 ALTER TABLE `himalay_tblcustomer_admins` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblcustomer_admins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblcustomer_groups`
--

DROP TABLE IF EXISTS `himalay_tblcustomer_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblcustomer_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupid` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `groupid` (`groupid`),
  KEY `customer_id` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblcustomer_groups`
--

LOCK TABLES `himalay_tblcustomer_groups` WRITE;
/*!40000 ALTER TABLE `himalay_tblcustomer_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblcustomer_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblcustomers_groups`
--

DROP TABLE IF EXISTS `himalay_tblcustomers_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblcustomers_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblcustomers_groups`
--

LOCK TABLES `himalay_tblcustomers_groups` WRITE;
/*!40000 ALTER TABLE `himalay_tblcustomers_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblcustomers_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblcustomfields`
--

DROP TABLE IF EXISTS `himalay_tblcustomfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblcustomfields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldto` varchar(30) DEFAULT NULL,
  `name` varchar(150) NOT NULL,
  `slug` varchar(150) NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT 0,
  `type` varchar(20) NOT NULL,
  `options` longtext DEFAULT NULL,
  `display_inline` tinyint(1) NOT NULL DEFAULT 0,
  `field_order` int(11) DEFAULT 0,
  `active` int(11) NOT NULL DEFAULT 1,
  `show_on_pdf` int(11) NOT NULL DEFAULT 0,
  `show_on_ticket_form` tinyint(1) NOT NULL DEFAULT 0,
  `only_admin` tinyint(1) NOT NULL DEFAULT 0,
  `show_on_table` tinyint(1) NOT NULL DEFAULT 0,
  `show_on_client_portal` int(11) NOT NULL DEFAULT 0,
  `disalow_client_to_edit` int(11) NOT NULL DEFAULT 0,
  `bs_column` int(11) NOT NULL DEFAULT 12,
  `default_value` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblcustomfields`
--

LOCK TABLES `himalay_tblcustomfields` WRITE;
/*!40000 ALTER TABLE `himalay_tblcustomfields` DISABLE KEYS */;
INSERT INTO `himalay_tblcustomfields` VALUES (1,'tasks','Estimate hour','tasks_estimate_hour',0,'number','',0,0,1,0,0,0,0,0,0,12,NULL);
/*!40000 ALTER TABLE `himalay_tblcustomfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblcustomfieldsvalues`
--

DROP TABLE IF EXISTS `himalay_tblcustomfieldsvalues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblcustomfieldsvalues` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `relid` int(11) NOT NULL,
  `fieldid` int(11) NOT NULL,
  `fieldto` varchar(15) NOT NULL,
  `value` mediumtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `relid` (`relid`),
  KEY `fieldto` (`fieldto`),
  KEY `fieldid` (`fieldid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblcustomfieldsvalues`
--

LOCK TABLES `himalay_tblcustomfieldsvalues` WRITE;
/*!40000 ALTER TABLE `himalay_tblcustomfieldsvalues` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblcustomfieldsvalues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblday_off`
--

DROP TABLE IF EXISTS `himalay_tblday_off`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblday_off` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `off_reason` varchar(255) NOT NULL,
  `off_type` varchar(100) NOT NULL,
  `break_date` date NOT NULL,
  `timekeeping` varchar(45) DEFAULT NULL,
  `department` varchar(45) DEFAULT NULL,
  `position` varchar(45) DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  `repeat_by_year` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblday_off`
--

LOCK TABLES `himalay_tblday_off` WRITE;
/*!40000 ALTER TABLE `himalay_tblday_off` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblday_off` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tbldepartments`
--

DROP TABLE IF EXISTS `himalay_tbldepartments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tbldepartments` (
  `departmentid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `imap_username` varchar(191) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `email_from_header` tinyint(1) NOT NULL DEFAULT 0,
  `host` varchar(150) DEFAULT NULL,
  `password` longtext DEFAULT NULL,
  `encryption` varchar(3) DEFAULT NULL,
  `folder` varchar(191) NOT NULL DEFAULT 'INBOX',
  `delete_after_import` int(11) NOT NULL DEFAULT 0,
  `calendar_id` longtext DEFAULT NULL,
  `hidefromclient` tinyint(1) NOT NULL DEFAULT 0,
  `manager_id` int(11) DEFAULT 0,
  `parent_id` int(11) DEFAULT 0,
  PRIMARY KEY (`departmentid`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tbldepartments`
--

LOCK TABLES `himalay_tbldepartments` WRITE;
/*!40000 ALTER TABLE `himalay_tbldepartments` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tbldepartments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tbldismissed_announcements`
--

DROP TABLE IF EXISTS `himalay_tbldismissed_announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tbldismissed_announcements` (
  `dismissedannouncementid` int(11) NOT NULL AUTO_INCREMENT,
  `announcementid` int(11) NOT NULL,
  `staff` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  PRIMARY KEY (`dismissedannouncementid`),
  KEY `announcementid` (`announcementid`),
  KEY `himalay_staff` (`staff`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tbldismissed_announcements`
--

LOCK TABLES `himalay_tbldismissed_announcements` WRITE;
/*!40000 ALTER TABLE `himalay_tbldismissed_announcements` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tbldismissed_announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblemaillists`
--

DROP TABLE IF EXISTS `himalay_tblemaillists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblemaillists` (
  `listid` int(11) NOT NULL AUTO_INCREMENT,
  `name` mediumtext NOT NULL,
  `creator` varchar(100) NOT NULL,
  `datecreated` datetime NOT NULL,
  PRIMARY KEY (`listid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblemaillists`
--

LOCK TABLES `himalay_tblemaillists` WRITE;
/*!40000 ALTER TABLE `himalay_tblemaillists` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblemaillists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblemailtemplates`
--

DROP TABLE IF EXISTS `himalay_tblemailtemplates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblemailtemplates` (
  `emailtemplateid` int(11) NOT NULL AUTO_INCREMENT,
  `type` longtext NOT NULL,
  `slug` varchar(100) NOT NULL,
  `language` varchar(40) DEFAULT NULL,
  `name` longtext NOT NULL,
  `subject` longtext NOT NULL,
  `message` longtext NOT NULL,
  `fromname` longtext NOT NULL,
  `fromemail` varchar(100) DEFAULT NULL,
  `plaintext` int(11) NOT NULL DEFAULT 0,
  `active` tinyint(4) NOT NULL DEFAULT 0,
  `order` int(11) NOT NULL,
  PRIMARY KEY (`emailtemplateid`)
) ENGINE=InnoDB AUTO_INCREMENT=135 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblemailtemplates`
--

LOCK TABLES `himalay_tblemailtemplates` WRITE;
/*!40000 ALTER TABLE `himalay_tblemailtemplates` DISABLE KEYS */;
INSERT INTO `himalay_tblemailtemplates` VALUES (1,'client','new-client-created','english','New Contact Added/Registered (Welcome Email)','Welcome aboard','Dear {contact_firstname} {contact_lastname}<br /><br />Thank you for registering on the <strong>{companyname}</strong> CRM System.<br /><br />We just wanted to say welcome.<br /><br />Please contact us if you need any help.<br /><br />Click here to view your profile: <a href=\"{crm_url}\">{crm_url}</a><br /><br />Kind Regards, <br />{email_signature}<br /><br />(This is an automated email, so please don\'t reply to this email address)','{companyname} | CRM','',0,1,0),(2,'invoice','invoice-send-to-client','english','Send Invoice to Customer','Invoice with number {invoice_number} created','<span style=\"font-size: 12pt;\">Dear {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">We have prepared the following invoice for you: <strong># {invoice_number}</strong></span><br /><br /><span style=\"font-size: 12pt;\"><strong>Invoice status</strong>: {invoice_status}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the invoice on the following link: <a href=\"{invoice_link}\">{invoice_number}</a></span><br /><br /><span style=\"font-size: 12pt;\">Please contact us for more information.</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(3,'ticket','new-ticket-opened-admin','english','New Ticket Opened (Opened by Staff, Sent to Customer)','New Support Ticket Opened','<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">New support ticket has been opened.</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject:</strong> {ticket_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Department:</strong> {ticket_department}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority:</strong> {ticket_priority}<br /></span><br /><span style=\"font-size: 12pt;\"><strong>Ticket message:</strong></span><br /><span style=\"font-size: 12pt;\">{ticket_message}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_public_url}\">#{ticket_id}</a><br /><br />Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(4,'ticket','ticket-reply','english','Ticket Reply (Sent to Customer)','New Ticket Reply','<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">You have a new ticket reply to ticket <a href=\"{ticket_public_url}\">#{ticket_id}</a></span><br /><br /><span style=\"font-size: 12pt;\"><strong>Ticket Subject:</strong> {ticket_subject}<br /></span><br /><span style=\"font-size: 12pt;\"><strong>Ticket message:</strong></span><br /><span style=\"font-size: 12pt;\">{ticket_message}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_public_url}\">#{ticket_id}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(5,'ticket','ticket-autoresponse','english','New Ticket Opened - Autoresponse','New Support Ticket Opened','<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">Thank you for contacting our support team. A support ticket has now been opened for your request. You will be notified when a response is made by email.</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject:</strong> {ticket_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Department</strong>: {ticket_department}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority:</strong> {ticket_priority}</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Ticket message:</strong></span><br /><span style=\"font-size: 12pt;\">{ticket_message}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_public_url}\">#{ticket_id}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(6,'invoice','invoice-payment-recorded','english','Invoice Payment Recorded (Sent to Customer)','Invoice Payment Recorded','<span style=\"font-size: 12pt;\">Hello {contact_firstname}&nbsp;{contact_lastname}<br /><br /></span>Thank you for the payment. Find the payment details below:<br /><br />-------------------------------------------------<br /><br />Amount:&nbsp;<strong>{payment_total}<br /></strong>Date:&nbsp;<strong>{payment_date}</strong><br />Invoice number:&nbsp;<span style=\"font-size: 12pt;\"><strong># {invoice_number}<br /><br /></strong></span>-------------------------------------------------<br /><br />You can always view the invoice for this payment at the following link:&nbsp;<a href=\"{invoice_link}\"><span style=\"font-size: 12pt;\">{invoice_number}</span></a><br /><br />We are looking forward working with you.<br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(7,'invoice','invoice-overdue-notice','english','Invoice Overdue Notice','Invoice Overdue Notice - {invoice_number}','<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">This is an overdue notice for invoice <strong># {invoice_number}</strong></span><br /><br /><span style=\"font-size: 12pt;\">This invoice was due: {invoice_duedate}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the invoice on the following link: <a href=\"{invoice_link}\">{invoice_number}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(8,'invoice','invoice-already-send','english','Invoice Already Sent to Customer','Invoice # {invoice_number} ','<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">At your request, here is the invoice with number <strong># {invoice_number}</strong></span><br /><br /><span style=\"font-size: 12pt;\">You can view the invoice on the following link: <a href=\"{invoice_link}\">{invoice_number}</a></span><br /><br /><span style=\"font-size: 12pt;\">Please contact us for more information.</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(9,'ticket','new-ticket-created-staff','english','New Ticket Created (Opened by Customer, Sent to Staff Members)','New Ticket Created','<p><span style=\"font-size: 12pt;\">A new support ticket has been opened.</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject</strong>: {ticket_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Department</strong>: {ticket_department}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority</strong>: {ticket_priority}<br /></span><br /><span style=\"font-size: 12pt;\"><strong>Ticket message:</strong></span><br /><span style=\"font-size: 12pt;\">{ticket_message}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_url}\">#{ticket_id}</a></span><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span></p>','{companyname} | CRM','',0,1,0),(10,'estimate','estimate-send-to-client','english','Send Estimate to Customer','Estimate # {estimate_number} created','<span style=\"font-size: 12pt;\">Dear {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">Please find the attached estimate <strong># {estimate_number}</strong></span><br /><br /><span style=\"font-size: 12pt;\"><strong>Estimate status:</strong> {estimate_status}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the estimate on the following link: <a href=\"{estimate_link}\">{estimate_number}</a></span><br /><br /><span style=\"font-size: 12pt;\">We look forward to your communication.</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}<br /></span>','{companyname} | CRM','',0,1,0),(11,'ticket','ticket-reply-to-admin','english','Ticket Reply (Sent to Staff)','New Support Ticket Reply','<span style=\"font-size: 12pt;\">A new support ticket reply from {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject</strong>: {ticket_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Department</strong>: {ticket_department}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority</strong>: {ticket_priority}</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Ticket message:</strong></span><br /><span style=\"font-size: 12pt;\">{ticket_message}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_url}\">#{ticket_id}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(12,'estimate','estimate-already-send','english','Estimate Already Sent to Customer','Estimate # {estimate_number} ','<span style=\"font-size: 12pt;\">Dear {contact_firstname} {contact_lastname}</span><br /> <br /><span style=\"font-size: 12pt;\">Thank you for your estimate request.</span><br /> <br /><span style=\"font-size: 12pt;\">You can view the estimate on the following link: <a href=\"{estimate_link}\">{estimate_number}</a></span><br /> <br /><span style=\"font-size: 12pt;\">Please contact us for more information.</span><br /> <br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(13,'contract','contract-expiration','english','Contract Expiration Reminder (Sent to Customer Contacts)','Contract Expiration Reminder','<span style=\"font-size: 12pt;\">Dear {client_company}</span><br /><br /><span style=\"font-size: 12pt;\">This is a reminder that the following contract will expire soon:</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject:</strong> {contract_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Description:</strong> {contract_description}</span><br /><span style=\"font-size: 12pt;\"><strong>Date Start:</strong> {contract_datestart}</span><br /><span style=\"font-size: 12pt;\"><strong>Date End:</strong> {contract_dateend}</span><br /><br /><span style=\"font-size: 12pt;\">Please contact us for more information.</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(14,'tasks','task-assigned','english','New Task Assigned (Sent to Staff)','New Task Assigned to You - {task_name}','<span style=\"font-size: 12pt;\">Dear {staff_firstname}</span><br /><br /><span style=\"font-size: 12pt;\">You have been assigned to a new task:</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Name:</strong> {task_name}<br /></span><strong>Start Date:</strong> {task_startdate}<br /><span style=\"font-size: 12pt;\"><strong>Due date:</strong> {task_duedate}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority:</strong> {task_priority}<br /><br /></span><span style=\"font-size: 12pt;\"><span>You can view the task on the following link</span>: <a href=\"{task_link}\">{task_name}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(15,'tasks','task-added-as-follower','english','Staff Member Added as Follower on Task (Sent to Staff)','You are added as follower on task - {task_name}','<span style=\"font-size: 12pt;\">Hi {staff_firstname}<br /></span><br /><span style=\"font-size: 12pt;\">You have been added as follower on the following task:</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Name:</strong> {task_name}</span><br /><span style=\"font-size: 12pt;\"><strong>Start date:</strong> {task_startdate}</span><br /><br /><span>You can view the task on the following link</span><span>: </span><a href=\"{task_link}\">{task_name}</a><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(16,'tasks','task-commented','english','New Comment on Task (Sent to Staff)','New Comment on Task - {task_name}','Dear {staff_firstname}<br /><br />A comment has been made on the following task:<br /><br /><strong>Name:</strong> {task_name}<br /><strong>Comment:</strong> {task_comment}<br /><br />You can view the task on the following link: <a href=\"{task_link}\">{task_name}</a><br /><br />Kind Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),(17,'tasks','task-added-attachment','english','New Attachment(s) on Task (Sent to Staff)','New Attachment on Task - {task_name}','Hi {staff_firstname}<br /><br /><strong>{task_user_take_action}</strong> added an attachment on the following task:<br /><br /><strong>Name:</strong> {task_name}<br /><br />You can view the task on the following link: <a href=\"{task_link}\">{task_name}</a><br /><br />Kind Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),(18,'estimate','estimate-declined-to-staff','english','Estimate Declined (Sent to Staff)','Customer Declined Estimate','<span style=\"font-size: 12pt;\">Hi</span><br /> <br /><span style=\"font-size: 12pt;\">Customer ({client_company}) declined estimate with number <strong># {estimate_number}</strong></span><br /> <br /><span style=\"font-size: 12pt;\">You can view the estimate on the following link: <a href=\"{estimate_link}\">{estimate_number}</a></span><br /> <br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(19,'estimate','estimate-accepted-to-staff','english','Estimate Accepted (Sent to Staff)','Customer Accepted Estimate','<span style=\"font-size: 12pt;\">Hi</span><br /> <br /><span style=\"font-size: 12pt;\">Customer ({client_company}) accepted estimate with number <strong># {estimate_number}</strong></span><br /> <br /><span style=\"font-size: 12pt;\">You can view the estimate on the following link: <a href=\"{estimate_link}\">{estimate_number}</a></span><br /> <br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(20,'proposals','proposal-client-accepted','english','Customer Action - Accepted (Sent to Staff)','Customer Accepted Proposal','<div>Hi<br /> <br />Client <strong>{proposal_proposal_to}</strong> accepted the following proposal:<br /> <br /><strong>Number:</strong> {proposal_number}<br /><strong>Subject</strong>: {proposal_subject}<br /><strong>Total</strong>: {proposal_total}<br /> <br />View the proposal on the following link: <a href=\"{proposal_link}\">{proposal_number}</a><br /> <br />Kind Regards,<br />{email_signature}</div>\r\n<div>&nbsp;</div>\r\n<div>&nbsp;</div>\r\n<div>&nbsp;</div>','{companyname} | CRM','',0,1,0),(21,'proposals','proposal-send-to-customer','english','Send Proposal to Customer','Proposal With Number {proposal_number} Created','Dear {proposal_proposal_to}<br /><br />Please find our attached proposal.<br /><br />This proposal is valid until: {proposal_open_till}<br />You can view the proposal on the following link: <a href=\"{proposal_link}\">{proposal_number}</a><br /><br />Please don\'t hesitate to comment online if you have any questions.<br /><br />We look forward to your communication.<br /><br />Kind Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),(22,'proposals','proposal-client-declined','english','Customer Action - Declined (Sent to Staff)','Client Declined Proposal','Hi<br /> <br />Customer <strong>{proposal_proposal_to}</strong> declined the proposal <strong>{proposal_subject}</strong><br /> <br />View the proposal on the following link <a href=\"{proposal_link}\">{proposal_number}</a>&nbsp;or from the admin area.<br /> <br />Kind Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),(23,'proposals','proposal-client-thank-you','english','Thank You Email (Sent to Customer After Accept)','Thank for you accepting proposal','Dear {proposal_proposal_to}<br /> <br />Thank for for accepting the proposal.<br /> <br />We look forward to doing business with you.<br /> <br />We will contact you as soon as possible<br /> <br />Kind Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),(24,'proposals','proposal-comment-to-client','english','New Comment Â (Sent to Customer/Lead)','New Proposal Comment','Dear {proposal_proposal_to}<br /> <br />A new comment has been made on the following proposal: <strong>{proposal_number}</strong><br /> <br />You can view and reply to the comment on the following link: <a href=\"{proposal_link}\">{proposal_number}</a><br /> <br />Kind Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),(25,'proposals','proposal-comment-to-admin','english','New Comment (Sent to Staff) ','New Proposal Comment','Hi<br /> <br />A new comment has been made to the proposal <strong>{proposal_subject}</strong><br /> <br />You can view and reply to the comment on the following link: <a href=\"{proposal_link}\">{proposal_number}</a>&nbsp;or from the admin area.<br /> <br />{email_signature}','{companyname} | CRM','',0,1,0),(26,'estimate','estimate-thank-you-to-customer','english','Thank You Email (Sent to Customer After Accept)','Thank for you accepting estimate','<span style=\"font-size: 12pt;\">Dear {contact_firstname} {contact_lastname}</span><br /> <br /><span style=\"font-size: 12pt;\">Thank for for accepting the estimate.</span><br /> <br /><span style=\"font-size: 12pt;\">We look forward to doing business with you.</span><br /> <br /><span style=\"font-size: 12pt;\">We will contact you as soon as possible.</span><br /> <br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(27,'tasks','task-deadline-notification','english','Task Deadline Reminder - Sent to Assigned Members','Task Deadline Reminder','Hi {staff_firstname}&nbsp;{staff_lastname}<br /><br />This is an automated email from {companyname}.<br /><br />The task <strong>{task_name}</strong> deadline is on <strong>{task_duedate}</strong>. <br />This task is still not finished.<br /><br />You can view the task on the following link: <a href=\"{task_link}\">{task_name}</a><br /><br />Kind Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),(28,'contract','send-contract','english','Send Contract to Customer','Contract - {contract_subject}','<p><span style=\"font-size: 12pt;\">Hi&nbsp;{contact_firstname}&nbsp;{contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">Please find the <a href=\"{contract_link}\">{contract_subject}</a> attached.<br /><br />Description: {contract_description}<br /><br /></span><span style=\"font-size: 12pt;\">Looking forward to hear from you.</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span></p>','{companyname} | CRM','',0,1,0),(29,'invoice','invoice-payment-recorded-to-staff','english','Invoice Payment Recorded (Sent to Staff)','New Invoice Payment','<span style=\"font-size: 12pt;\">Hi</span><br /><br /><span style=\"font-size: 12pt;\">Customer recorded payment for invoice <strong># {invoice_number}</strong></span><br /> <br /><span style=\"font-size: 12pt;\">You can view the invoice on the following link: <a href=\"{invoice_link}\">{invoice_number}</a></span><br /> <br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(30,'ticket','auto-close-ticket','english','Auto Close Ticket','Ticket Auto Closed','<p><span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">Ticket {ticket_subject} has been auto close due to inactivity.</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Ticket #</strong>: <a href=\"{ticket_public_url}\">{ticket_id}</a></span><br /><span style=\"font-size: 12pt;\"><strong>Department</strong>: {ticket_department}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority:</strong> {ticket_priority}</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span></p>','{companyname} | CRM','',0,1,0),(31,'project','new-project-discussion-created-to-staff','english','New Project Discussion (Sent to Project Members)','New Project Discussion Created - {project_name}','<p>Hi {staff_firstname}<br /><br />New project discussion created from <strong>{discussion_creator}</strong><br /><br /><strong>Subject:</strong> {discussion_subject}<br /><strong>Description:</strong> {discussion_description}<br /><br />You can view the discussion on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a><br /><br />Kind Regards,<br />{email_signature}</p>','{companyname} | CRM','',0,1,0),(32,'project','new-project-discussion-created-to-customer','english','New Project Discussion (Sent to Customer Contacts)','New Project Discussion Created - {project_name}','<p>Hello {contact_firstname} {contact_lastname}<br /><br />New project discussion created from <strong>{discussion_creator}</strong><br /><br /><strong>Subject:</strong> {discussion_subject}<br /><strong>Description:</strong> {discussion_description}<br /><br />You can view the discussion on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a><br /><br />Kind Regards,<br />{email_signature}</p>','{companyname} | CRM','',0,1,0),(33,'project','new-project-file-uploaded-to-customer','english','New Project File(s) Uploaded (Sent to Customer Contacts)','New Project File(s) Uploaded - {project_name}','<p>Hello {contact_firstname} {contact_lastname}<br /><br />New project file is uploaded on <strong>{project_name}</strong> from <strong>{file_creator}</strong><br /><br />You can view the project on the following link: <a href=\"{project_link}\">{project_name}</a><br /><br />To view the file in our CRM you can click on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a><br /><br />Kind Regards,<br />{email_signature}</p>','{companyname} | CRM','',0,1,0),(34,'project','new-project-file-uploaded-to-staff','english','New Project File(s) Uploaded (Sent to Project Members)','New Project File(s) Uploaded - {project_name}','<p>Hello&nbsp;{staff_firstname}</p>\r\n<p>New project&nbsp;file is uploaded on&nbsp;<strong>{project_name}</strong> from&nbsp;<strong>{file_creator}</strong></p>\r\n<p>You can view the project on the following link: <a href=\"{project_link}\">{project_name}<br /></a><br />To view&nbsp;the file you can click on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a></p>\r\n<p>Kind Regards,<br />{email_signature}</p>','{companyname} | CRM','',0,1,0),(35,'project','new-project-discussion-comment-to-customer','english','New Discussion Comment  (Sent to Customer Contacts)','New Discussion Comment','<p><span style=\"font-size: 12pt;\">Hello {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">New discussion comment has been made on <strong>{discussion_subject}</strong> from <strong>{comment_creator}</strong></span><br /><br /><span style=\"font-size: 12pt;\"><strong>Discussion subject:</strong> {discussion_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Comment</strong>: {discussion_comment}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the discussion on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span></p>','{companyname} | CRM','',0,1,0),(36,'project','new-project-discussion-comment-to-staff','english','New Discussion Comment (Sent to Project Members)','New Discussion Comment','<p>Hi {staff_firstname}<br /><br />New discussion comment has been made on <strong>{discussion_subject}</strong> from <strong>{comment_creator}</strong><br /><br /><strong>Discussion subject:</strong> {discussion_subject}<br /><strong>Comment:</strong> {discussion_comment}<br /><br />You can view the discussion on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a><br /><br />Kind Regards,<br />{email_signature}</p>','{companyname} | CRM','',0,1,0),(37,'project','staff-added-as-project-member','english','Staff Added as Project Member','New project assigned to you','<p>Hi {staff_firstname}<br /><br />New project has been assigned to you.<br /><br />You can view the project on the following link <a href=\"{project_link}\">{project_name}</a><br /><br />{email_signature}</p>','{companyname} | CRM','',0,1,0),(38,'estimate','estimate-expiry-reminder','english','Estimate Expiration Reminder','Estimate Expiration Reminder','<p><span style=\"font-size: 12pt;\">Hello {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">The estimate with <strong># {estimate_number}</strong> will expire on <strong>{estimate_expirydate}</strong></span><br /><br /><span style=\"font-size: 12pt;\">You can view the estimate on the following link: <a href=\"{estimate_link}\">{estimate_number}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span></p>','{companyname} | CRM','',0,1,0),(39,'proposals','proposal-expiry-reminder','english','Proposal Expiration Reminder','Proposal Expiration Reminder','<p>Hello {proposal_proposal_to}<br /><br />The proposal {proposal_number}&nbsp;will expire on <strong>{proposal_open_till}</strong><br /><br />You can view the proposal on the following link: <a href=\"{proposal_link}\">{proposal_number}</a><br /><br />Kind Regards,<br />{email_signature}</p>','{companyname} | CRM','',0,1,0),(40,'staff','new-staff-created','english','New Staff Created (Welcome Email)','You are added as staff member','Hi {staff_firstname}<br /><br />You are added as member on our CRM.<br /><br />Please use the following logic credentials:<br /><br /><strong>Email:</strong> {staff_email}<br /><strong>Password:</strong> {password}<br /><br />Click <a href=\"{admin_url}\">here </a>to login in the dashboard.<br /><br />Best Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),(41,'client','contact-forgot-password','english','Forgot Password','Create New Password','<h2>Create a new password</h2>\r\nForgot your password?<br /> To create a new password, just follow this link:<br /> <br /><a href=\"{reset_password_url}\">Reset Password</a><br /> <br /> You received this email, because it was requested by a {companyname}&nbsp;user. This is part of the procedure to create a new password on the system. If you DID NOT request a new password then please ignore this email and your password will remain the same. <br /><br /> {email_signature}','{companyname} | CRM','',0,1,0),(42,'client','contact-password-reseted','english','Password Reset - Confirmation','Your password has been changed','<strong><span style=\"font-size: 14pt;\">You have changed your password.</span><br /></strong><br /> Please, keep it in your records so you don\'t forget it.<br /> <br /> Your email address for login is: {contact_email}<br /><br />If this wasnt you, please contact us.<br /><br />{email_signature}','{companyname} | CRM','',0,1,0),(43,'client','contact-set-password','english','Set New Password','Set new password on {companyname} ','<h2><span style=\"font-size: 14pt;\">Setup your new password on {companyname}</span></h2>\r\nPlease use the following link to set up your new password:<br /><br /><a href=\"{set_password_url}\">Set new password</a><br /><br />Keep it in your records so you don\'t forget it.<br /><br />Please set your new password in <strong>48 hours</strong>. After that, you won\'t be able to set your password because this link will expire.<br /><br />You can login at: <a href=\"{crm_url}\">{crm_url}</a><br />Your email address for login: {contact_email}<br /><br />{email_signature}','{companyname} | CRM','',0,1,0),(44,'staff','staff-forgot-password','english','Forgot Password','Create New Password','<h2><span style=\"font-size: 14pt;\">Create a new password</span></h2>\r\nForgot your password?<br /> To create a new password, just follow this link:<br /> <br /><a href=\"{reset_password_url}\">Reset Password</a><br /> <br /> You received this email, because it was requested by a <strong>{companyname}</strong>&nbsp;user. This is part of the procedure to create a new password on the system. If you DID NOT request a new password then please ignore this email and your password will remain the same. <br /><br /> {email_signature}','{companyname} | CRM','',0,1,0),(45,'staff','staff-password-reseted','english','Password Reset - Confirmation','Your password has been changed','<span style=\"font-size: 14pt;\"><strong>You have changed your password.<br /></strong></span><br /> Please, keep it in your records so you don\'t forget it.<br /> <br /> Your email address for login is: {staff_email}<br /><br /> If this wasnt you, please contact us.<br /><br />{email_signature}','{companyname} | CRM','',0,1,0),(46,'project','assigned-to-project','english','New Project Created (Sent to Customer Contacts)','New Project Created','<p>Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}</p>\r\n<p>New project is assigned to your company.<br /><br /><strong>Project Name:</strong>&nbsp;{project_name}<br /><strong>Project Start Date:</strong>&nbsp;{project_start_date}</p>\r\n<p>You can view the project on the following link:&nbsp;<a href=\"{project_link}\">{project_name}</a></p>\r\n<p>We are looking forward hearing from you.<br /><br />Kind Regards,<br />{email_signature}</p>','{companyname} | CRM','',0,1,0),(47,'tasks','task-added-attachment-to-contacts','english','New Attachment(s) on Task (Sent to Customer Contacts)','New Attachment on Task - {task_name}','<span>Hi {contact_firstname} {contact_lastname}</span><br /><br /><strong>{task_user_take_action}</strong><span> added an attachment on the following task:</span><br /><br /><strong>Name:</strong><span> {task_name}</span><br /><br /><span>You can view the task on the following link: </span><a href=\"{task_link}\">{task_name}</a><br /><br /><span>Kind Regards,</span><br /><span>{email_signature}</span>','{companyname} | CRM','',0,1,0),(48,'tasks','task-commented-to-contacts','english','New Comment on Task (Sent to Customer Contacts)','New Comment on Task - {task_name}','<span>Dear {contact_firstname} {contact_lastname}</span><br /><br /><span>A comment has been made on the following task:</span><br /><br /><strong>Name:</strong><span> {task_name}</span><br /><strong>Comment:</strong><span> {task_comment}</span><br /><br /><span>You can view the task on the following link: </span><a href=\"{task_link}\">{task_name}</a><br /><br /><span>Kind Regards,</span><br /><span>{email_signature}</span>','{companyname} | CRM','',0,1,0),(49,'leads','new-lead-assigned','english','New Lead Assigned to Staff Member','New lead assigned to you','<p>Hello {lead_assigned}<br /><br />New lead is assigned to you.<br /><br /><strong>Lead Name:</strong>&nbsp;{lead_name}<br /><strong>Lead Email:</strong>&nbsp;{lead_email}<br /><br />You can view the lead on the following link: <a href=\"{lead_link}\">{lead_name}</a><br /><br />Kind Regards,<br />{email_signature}</p>','{companyname} | CRM','',0,1,0),(50,'client','client-statement','english','Statement - Account Summary','Account Statement from {statement_from} to {statement_to}','Dear {contact_firstname} {contact_lastname}, <br /><br />Its been a great experience working with you.<br /><br />Attached with this email is a list of all transactions for the period between {statement_from} to {statement_to}<br /><br />For your information your account balance due is total:&nbsp;{statement_balance_due}<br /><br />Please contact us if you need more information.<br /> <br />Kind Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),(51,'ticket','ticket-assigned-to-admin','english','New Ticket Assigned (Sent to Staff)','New support ticket has been assigned to you','<p><span style=\"font-size: 12pt;\">Hi</span></p>\r\n<p><span style=\"font-size: 12pt;\">A new support ticket&nbsp;has been assigned to you.</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject</strong>: {ticket_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Department</strong>: {ticket_department}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority</strong>: {ticket_priority}</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Ticket message:</strong></span><br /><span style=\"font-size: 12pt;\">{ticket_message}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_url}\">#{ticket_id}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span></p>','{companyname} | CRM','',0,1,0),(52,'client','new-client-registered-to-admin','english','New Customer Registration (Sent to admins)','New Customer Registration','Hello.<br /><br />New customer registration on your customer portal:<br /><br /><strong>Firstname:</strong>&nbsp;{contact_firstname}<br /><strong>Lastname:</strong>&nbsp;{contact_lastname}<br /><strong>Company:</strong>&nbsp;{client_company}<br /><strong>Email:</strong>&nbsp;{contact_email}<br /><br />Best Regards','{companyname} | CRM','',0,1,0),(53,'leads','new-web-to-lead-form-submitted','english','Web to lead form submitted - Sent to lead','{lead_name} - We Received Your Request','Hello {lead_name}.<br /><br /><strong>Your request has been received.</strong><br /><br />This email is to let you know that we received your request and we will get back to you as soon as possible with more information.<br /><br />Best Regards,<br />{email_signature}','{companyname} | CRM','',0,0,0),(54,'staff','two-factor-authentication','english','Two Factor Authentication','Confirm Your Login','<p>Hi {staff_firstname}</p>\r\n<p style=\"text-align: left;\">You received this email because you have enabled two factor authentication in your account.<br />Use the following code to confirm your login:</p>\r\n<p style=\"text-align: left;\"><span style=\"font-size: 18pt;\"><strong>{two_factor_auth_code}<br /><br /></strong><span style=\"font-size: 12pt;\">{email_signature}</span><strong><br /><br /><br /><br /></strong></span></p>','{companyname} | CRM','',0,1,0),(55,'project','project-finished-to-customer','english','Project Marked as Finished (Sent to Customer Contacts)','Project Marked as Finished','<p>Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}</p>\r\n<p>You are receiving this email because project&nbsp;<strong>{project_name}</strong> has been marked as finished. This project is assigned under your company and we just wanted to keep you up to date.<br /><br />You can view the project on the following link:&nbsp;<a href=\"{project_link}\">{project_name}</a></p>\r\n<p>If you have any questions don\'t hesitate to contact us.<br /><br />Kind Regards,<br />{email_signature}</p>','{companyname} | CRM','',0,1,0),(56,'credit_note','credit-note-send-to-client','english','Send Credit Note To Email','Credit Note With Number #{credit_note_number} Created','Dear&nbsp;{contact_firstname}&nbsp;{contact_lastname}<br /><br />We have attached the credit note with number <strong>#{credit_note_number} </strong>for your reference.<br /><br /><strong>Date:</strong>&nbsp;{credit_note_date}<br /><strong>Total Amount:</strong>&nbsp;{credit_note_total}<br /><br /><span style=\"font-size: 12pt;\">Please contact us for more information.</span><br /> <br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(57,'tasks','task-status-change-to-staff','english','Task Status Changed (Sent to Staff)','Task Status Changed','<span style=\"font-size: 12pt;\">Hi {staff_firstname}</span><br /><br /><span style=\"font-size: 12pt;\"><strong>{task_user_take_action}</strong> marked task as <strong>{task_status}</strong></span><br /><br /><span style=\"font-size: 12pt;\"><strong>Name:</strong> {task_name}</span><br /><span style=\"font-size: 12pt;\"><strong>Due date:</strong> {task_duedate}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the task on the following link: <a href=\"{task_link}\">{task_name}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(58,'tasks','task-status-change-to-contacts','english','Task Status Changed (Sent to Customer Contacts)','Task Status Changed','<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\"><strong>{task_user_take_action}</strong> marked task as <strong>{task_status}</strong></span><br /><br /><span style=\"font-size: 12pt;\"><strong>Name:</strong> {task_name}</span><br /><span style=\"font-size: 12pt;\"><strong>Due date:</strong> {task_duedate}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the task on the following link: <a href=\"{task_link}\">{task_name}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(59,'staff','reminder-email-staff','english','Staff Reminder Email','You Have a New Reminder!','<p>Hello&nbsp;{staff_firstname}<br /><br /><strong>You have a new reminder&nbsp;linked to&nbsp;{staff_reminder_relation_name}!<br /><br />Reminder description:</strong><br />{staff_reminder_description}<br /><br />Click <a href=\"{staff_reminder_relation_link}\">here</a> to view&nbsp;<a href=\"{staff_reminder_relation_link}\">{staff_reminder_relation_name}</a><br /><br />Best Regards<br /><br /></p>','{companyname} | CRM','',0,1,0),(60,'contract','contract-comment-to-client','english','New Comment Â (Sent to Customer Contacts)','New Contract Comment','Dear {contact_firstname} {contact_lastname}<br /> <br />A new comment has been made on the following contract: <strong>{contract_subject}</strong><br /> <br />You can view and reply to the comment on the following link: <a href=\"{contract_link}\">{contract_subject}</a><br /> <br />Kind Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),(61,'contract','contract-comment-to-admin','english','New Comment (Sent to Staff) ','New Contract Comment','Hi {staff_firstname}<br /><br />A new comment has been made to the contract&nbsp;<strong>{contract_subject}</strong><br /><br />You can view and reply to the comment on the following link: <a href=\"{contract_link}\">{contract_subject}</a>&nbsp;or from the admin area.<br /><br />{email_signature}','{companyname} | CRM','',0,1,0),(62,'subscriptions','send-subscription','english','Send Subscription to Customer','Subscription Created','Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}<br /><br />We have prepared the subscription&nbsp;<strong>{subscription_name}</strong> for your company.<br /><br />Click <a href=\"{subscription_link}\">here</a> to review the subscription and subscribe.<br /><br />Best Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),(63,'subscriptions','subscription-payment-failed','english','Subscription Payment Failed','Your most recent invoice payment failed','Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}<br /><br br=\"\" />Unfortunately, your most recent invoice payment for&nbsp;<strong>{subscription_name}</strong> was declined.<br /><br />This could be due to a change in your card number, your card expiring,<br />cancellation of your credit card, or the card issuer not recognizing the<br />payment and therefore taking action to prevent it.<br /><br />Please update your payment information as soon as possible by logging in here:<br /><a href=\"{crm_url}/login\">{crm_url}/login</a><br /><br />Best Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),(64,'subscriptions','subscription-canceled','english','Subscription Canceled (Sent to customer primary contact)','Your subscription has been canceled','Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}<br /><br />Your subscription&nbsp;<strong>{subscription_name} </strong>has been canceled, if you have any questions don\'t hesitate to contact us.<br /><br />It was a pleasure doing business with you.<br /><br />Best Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),(65,'subscriptions','subscription-payment-succeeded','english','Subscription Payment Succeeded (Sent to customer primary contact)','Subscription  Payment Receipt - {subscription_name}','Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}<br /><br />This email is to let you know that we received your payment for subscription&nbsp;<strong>{subscription_name}&nbsp;</strong>of&nbsp;<strong><span>{payment_total}<br /><br /></span></strong>The invoice associated with it is now with status&nbsp;<strong>{invoice_status}<br /></strong><br />Thank you for your confidence.<br /><br />Best Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),(66,'contract','contract-expiration-to-staff','english','Contract Expiration Reminder (Sent to Staff)','Contract Expiration Reminder','Hi {staff_firstname}<br /><br /><span style=\"font-size: 12pt;\">This is a reminder that the following contract will expire soon:</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject:</strong> {contract_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Description:</strong> {contract_description}</span><br /><span style=\"font-size: 12pt;\"><strong>Date Start:</strong> {contract_datestart}</span><br /><span style=\"font-size: 12pt;\"><strong>Date End:</strong> {contract_dateend}</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(67,'gdpr','gdpr-removal-request','english','Removal Request From Contact (Sent to administrators)','Data Removal Request Received','Hello&nbsp;{staff_firstname}&nbsp;{staff_lastname}<br /><br />Data removal has been requested by&nbsp;{contact_firstname} {contact_lastname}<br /><br />You can review this request and take proper actions directly from the admin area.','{companyname} | CRM','',0,1,0),(68,'gdpr','gdpr-removal-request-lead','english','Removal Request From Lead (Sent to administrators)','Data Removal Request Received','Hello&nbsp;{staff_firstname}&nbsp;{staff_lastname}<br /><br />Data removal has been requested by {lead_name}<br /><br />You can review this request and take proper actions directly from the admin area.<br /><br />To view the lead inside the admin area click here:&nbsp;<a href=\"{lead_link}\">{lead_link}</a>','{companyname} | CRM','',0,1,0),(69,'client','client-registration-confirmed','english','Customer Registration Confirmed','Your registration is confirmed','<p>Dear {contact_firstname} {contact_lastname}<br /><br />We just wanted to let you know that your registration at&nbsp;{companyname} is successfully confirmed and your account is now active.<br /><br />You can login at&nbsp;<a href=\"{crm_url}\">{crm_url}</a> with the email and password you provided during registration.<br /><br />Please contact us if you need any help.<br /><br />Kind Regards, <br />{email_signature}</p>\r\n<p><br />(This is an automated email, so please don\'t reply to this email address)</p>','{companyname} | CRM','',0,1,0),(70,'contract','contract-signed-to-staff','english','Contract Signed (Sent to Staff)','Customer Signed a Contract','Hi {staff_firstname}<br /><br />A contract with subject&nbsp;<strong>{contract_subject} </strong>has been successfully signed by the customer.<br /><br />You can view the contract at the following link: <a href=\"{contract_link}\">{contract_subject}</a>&nbsp;or from the admin area.<br /><br />{email_signature}','{companyname} | CRM','',0,1,0),(71,'subscriptions','customer-subscribed-to-staff','english','Customer Subscribed to a Subscription (Sent to administrators and subscription creator)','Customer Subscribed to a Subscription','The customer <strong>{client_company}</strong> subscribed to a subscription with name&nbsp;<strong>{subscription_name}</strong><br /><br /><strong>ID</strong>:&nbsp;{subscription_id}<br /><strong>Subscription name</strong>:&nbsp;{subscription_name}<br /><strong>Subscription description</strong>:&nbsp;{subscription_description}<br /><br />You can view the subscription by clicking <a href=\"{subscription_link}\">here</a><br />\r\n<div style=\"text-align: center;\"><span style=\"font-size: 10pt;\">&nbsp;</span></div>\r\nBest Regards,<br />{email_signature}<br /><br /><span style=\"font-size: 10pt;\"><span style=\"color: #999999;\">You are receiving this email because you are either administrator or you are creator of the subscription.</span></span>','{companyname} | CRM','',0,1,0),(72,'client','contact-verification-email','english','Email Verification (Sent to Contact After Registration)','Verify Email Address','<p>Hello&nbsp;{contact_firstname}<br /><br />Please click the button below to verify your email address.<br /><br /><a href=\"{email_verification_url}\">Verify Email Address</a><br /><br />If you did not create an account, no further action is required</p>\r\n<p><br />{email_signature}</p>','{companyname} | CRM','',0,1,0),(73,'client','new-customer-profile-file-uploaded-to-staff','english','New Customer Profile File(s) Uploaded (Sent to Staff)','Customer Uploaded New File(s) in Profile','Hi!<br /><br />New file(s) is uploaded into the customer ({client_company}) profile by&nbsp;{contact_firstname}<br /><br />You can check the uploaded files into the admin area by clicking <a href=\"{customer_profile_files_admin_link}\">here</a> or at the following link:&nbsp;{customer_profile_files_admin_link}<br /><br />{email_signature}','{companyname} | CRM','',0,1,0),(74,'staff','event-notification-to-staff','english','Event Notification (Calendar)','Upcoming Event - {event_title}','Hi {staff_firstname}! <br /><br />This is a reminder for event <a href=\\\"{event_link}\\\">{event_title}</a> scheduled at {event_start_date}. <br /><br />Regards.','','',0,1,0),(75,'subscriptions','subscription-payment-requires-action','english','Credit Card Authorization Required - SCA','Important: Confirm your subscription {subscription_name} payment','<p>Hello {contact_firstname}</p>\r\n<p><strong>Your bank sometimes requires an additional step to make sure an online transaction was authorized.</strong><br /><br />Because of European regulation to protect consumers, many online payments now require two-factor authentication. Your bank ultimately decides when authentication is required to confirm a payment, but you may notice this step when you start paying for a service or when the cost changes.<br /><br />In order to pay the subscription <strong>{subscription_name}</strong>, you will need to&nbsp;confirm your payment by clicking on the follow link: <strong><a href=\"{subscription_authorize_payment_link}\">{subscription_authorize_payment_link}</a></strong><br /><br />To view the subscription, please click at the following link: <a href=\"{subscription_link}\"><span>{subscription_link}</span></a><br />or you can login in our dedicated area here: <a href=\"{crm_url}/login\">{crm_url}/login</a> in case you want to update your credit card or view the subscriptions you are subscribed.<br /><br />Best Regards,<br />{email_signature}</p>','{companyname} | CRM','',0,1,0),(76,'invoice','invoice-due-notice','english','Invoice Due Notice','Your {invoice_number} will be due soon','<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}<br /><br /></span>You invoice <span style=\"font-size: 12pt;\"><strong># {invoice_number} </strong>will be due on <strong>{invoice_duedate}</strong></span><br /><br /><span style=\"font-size: 12pt;\">You can view the invoice on the following link: <a href=\"{invoice_link}\">{invoice_number}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(77,'estimate_request','estimate-request-submitted-to-staff','english','Estimate Request Submitted (Sent to Staff)','New Estimate Request Submitted','<span> Hello,&nbsp;</span><br /><br />{estimate_request_email} submitted an estimate request via the {estimate_request_form_name} form.<br /><br />You can view the request at the following link: <a href=\"{estimate_request_link}\">{estimate_request_link}</a><br /><br />==<br /><br />{estimate_request_submitted_data}<br /><br />Kind Regards,<br /><span>{email_signature}</span>','{companyname} | CRM','',0,1,0),(78,'estimate_request','estimate-request-assigned','english','Estimate Request Assigned (Sent to Staff)','New Estimate Request Assigned','<span> Hello {estimate_request_assigned},&nbsp;</span><br /><br />Estimate request #{estimate_request_id} has been assigned to you.<br /><br />You can view the request at the following link: <a href=\"{estimate_request_link}\">{estimate_request_link}</a><br /><br />Kind Regards,<br /><span>{email_signature}</span>','{companyname} | CRM','',0,1,0),(79,'estimate_request','estimate-request-received-to-user','english','Estimate Request Received (Sent to User)','Estimate Request Received','Hello,<br /><br /><strong>Your request has been received.</strong><br /><br />This email is to let you know that we received your request and we will get back to you as soon as possible with more information.<br /><br />Best Regards,<br />{email_signature}','{companyname} | CRM','',0,0,0),(80,'notifications','non-billed-tasks-reminder','english','Non-billed tasks reminder (sent to selected staff members)','Action required: Completed tasks are not billed','Hello {staff_firstname}<br><br>The following tasks are marked as complete but not yet billed:<br><br>{unbilled_tasks_list}<br><br>Kind Regards,<br><br>{email_signature}','{companyname} | CRM','',0,1,0),(81,'invoice','invoices-batch-payments','english','Invoices Payments Recorded in Batch (Sent to Customer)','We have received your payments','Hello {contact_firstname} {contact_lastname}<br><br>Thank you for the payments. Please find the payments details below:<br><br>{batch_payments_list}<br><br>We are looking forward working with you.<br><br>Kind Regards,<br><br>{email_signature}','{companyname} | CRM','',0,1,0),(82,'contract','contract-sign-reminder','english','Contract Sign Reminder (Sent to Customer)','Contract Sign Reminder','<p>Hello {contact_firstname} {contact_lastname}<br /><br />This is a reminder to review and sign the contract:<a href=\"{contract_link}\">{contract_subject}</a></p><p>You can view and sign by visiting: <a href=\"{contract_link}\">{contract_subject}</a></p><p><br />We are looking forward working with you.<br /><br />Kind Regards,<br /><br />{email_signature}</p>','{companyname} | CRM','',0,1,0),(83,'timesheets_attendance_mgt','attendance_notice','english','Attendance notice','Timesheets - Attendance notice','{staff_name} {type_check} at {date_time}','{companyname} | CRM',NULL,0,1,0),(84,'timesheets_attendance_mgt','send_request_approval','english','Send request approval','Timesheets - Send request approval to approver','Hi {approver}! <br>-{staff_name} has created an apply for leave and requires your approval. Please go to this link for details and approval: {link}','{companyname} | CRM',NULL,0,1,0),(85,'timesheets_attendance_mgt','remind_user_check_in','english','Remind user check in','Timesheets - Remind user check in','Remind you to check in today to record the start time of the shift {date_time}','{companyname} | CRM',NULL,0,1,0),(86,'timesheets_attendance_mgt','new_leave_application_send_to_notification_recipient','english','New application (Send to notification recipient)','Timesheets - New application - Send to notification recipient','{staff_name} created a new application {link} at {date_time}','{companyname} | CRM',NULL,0,1,0),(87,'client','affiliate_management_payout_updated','english','Affiliate Payout Request Update','An update regarding your payout request','Dear {contact_firstname},<br/><br/>\n    We hope this message finds you well.\n    <br/>\n    We wanted to inform you about the latest status of your payout request, identified by reference number <b>#{payout_id}</b>. \n    <br/><br/>\n    Amount: {payout_amount}<br/>\n    Status: {payout_status}<br/>\n    Note: {payout_note_for_affiliate}<br/>\n    Created: {payout_created_at}<br/>\n    <br/><br/>\n    If you have any questions or need further clarification, please do not hesitate to reach out. We are here to assist you in any way possible.<br/><br/>\n    \n    Best regards,<br/>\n    {email_signature}','{companyname} | CRM',NULL,0,1,0),(88,'client','affiliate_management_signup_through_affiliate_link','english','Successful Signup through Affiliate Link','Congratulations on a successful signup!','Dear {contact_firstname},<br/><br/>\n    We are delighted to inform you that someone has successfully signed up using your affiliate link.\n    <br/><br/>\n    Company/Contact: {referral_name}<br/>\n    Date: {referral_created_at}<br/>\n    <br/><br/>\n    While this signup may not have resulted in an immediate transaction, your efforts are highly valued. We appreciate your contribution to our community and anticipate further success in the future.\n    <br/><br/>\n    If you have any questions or need additional information, please feel free to reach out.\n    <br/><br/>\n    Best regards,<br/>\n    {email_signature}','{companyname} | CRM',NULL,0,1,0),(89,'client','affiliate_management_successful_referral_commission','english','Successful Referral Commission Notification','A referral commission received!','Dear {contact_firstname},<br/><br/>\n    We are thrilled to inform you that your referral has resulted in a successful transaction, earning you a commission.\n    <br/><br/>\n    Company/Contact: {referral_name}<br/>\n    Transaction Amount: {payment_amount}<br/>\n    Commission Earned: {commission_amount}<br/>\n    New Balance: {affiliate_balance}<br/>\n    Date: {commission_created_at}<br/>\n    <br/><br/>\n    We appreciate your efforts and look forward to more successful collaborations. Should you have any questions or require further information, feel free to reach out.\n    <br/><br/>\n    Best regards,<br/>\n    {email_signature}','{companyname} | CRM',NULL,0,1,0),(90,'staff','affiliate_management_new_payout_request_for_admin','english','Affiliate Payout Request','You have new affiliate payout request','Dear Admin,<br/><br/>\n    I wanted to inform you about a new payout request, identified by reference number <b>#{payout_id}</b>. \n    <br/><br/>\n    Affiliate: {affiliate_name}<br/>\n    Amount: {payout_amount}<br/>\n    Status: {payout_status}<br/>\n    Note: {payout_note_for_admin}<br/>\n    Created: {payout_created_at}<br/>\n    <br/><br/>    \n    Best regards,<br/>\n    {email_signature}','{companyname} | CRM',NULL,0,1,0),(91,'staff','affiliate_management_payout_updated_for_admin','english','Affiliate Payout Request Updated','You marked payout: #{payout_id} as {payout_status}','Dear Admin,<br/><br/>\n    I wanted to update you about the recent update to a payout request, identified by reference number <b>#{payout_id}</b>. \n    <br/><br/>\n    Affiliate: {affiliate_name}<br/>\n    Amount: {payout_amount}<br/>\n    Status: {payout_status}<br/><br/>\n    Admin Note: {payout_note_for_admin}<br/>\n    Note: {payout_note_for_affiliate}<br/>\n    Created: {payout_created_at}<br/>\n    <br/><br/>    \n    Best regards,<br/>\n    {email_signature}','{companyname} | CRM',NULL,0,1,0),(92,'staff','affiliate_management_new_affiliate_signup_for_admin','english','New Affiliate Signup','A new affiliate signup','Dear Admin,<br/><br/>\n    I wanted to inform you about a new affiliate signup, identified by reference number <b>#{affiliate_slug}</b>. \n    <br/><br/>\n    Affiliate: {affiliate_name}<br/>\n    Status: {affiliate_status}<br/>\n    Created: {affiliate_created_at}<br/>\n    <br/><br/>    \n    Best regards,<br/>\n    {email_signature}','{companyname} | CRM',NULL,0,1,0),(93,'client','affiliate_management_referral_commission_reversal','english','Referral Commission Reversal Notification','A referral commission was reversed!','Dear {contact_firstname},<br/><br/>\n    We regret to inform you that the commission previously awarded for your referral has been reversed due to reversal or removal of the rewarded payment.\n    <br/><br/>\n    Company/Contact: {referral_name}<br/>\n    Comission ID: {commission_id}<br/>\n    Amount Reversed: {commission_amount}<br/>\n    New Balance: {affiliate_balance}<br/>\n    Date of commission: {commission_created_at}<br/>\n    <br/><br/>\n    We appreciate your efforts and look forward to more successful collaborations. Should you have any questions or require further information, feel free to reach out.\n    <br/><br/>\n    Best regards,<br/>\n    {email_signature}','{companyname} | CRM',NULL,0,1,0),(94,'inventory_warning','inventory-warning-to-staff','english','Inventory warning (Sent to staff)','Inventory warning','Hi {staff_name}! <br /><br />This is a inventory warning<br />{<span 12pt=\"\">notification_content</span>}. <br /><br />Regards.','{companyname} | CRM',NULL,0,1,0),(103,'purchase_order','purchase-order-to-contact','english','Purchase Order (Sent to contact)','Purchase Order','<span style=\\\"font-size: 12pt;\\\"> Hello !. </span><br /><br /><span style=\\\"font-size: 12pt;\\\"> We would like to share with you a link of Purchase Order information with the number {po_number} </span><br /><br /><span style=\\\"font-size: 12pt;\\\"><br />Please click on the link to view information: {public_link}\r\n  </span><br /><br />','{companyname} | CRM',NULL,0,1,0),(104,'purchase_order','purchase-request-to-contact','english','Purchase Request (Sent to contact)','Purchase Request','<span style=\\\"font-size: 12pt;\\\"> Hello !. </span><br /><br /><span style=\\\"font-size: 12pt;\\\"> We would like to share with you a link of Purchase Request information with the number {pr_number} </span><br /><br /><span style=\\\"font-size: 12pt;\\\"><br />Please click on the link to view information: {public_link}<br/ >{additional_content}\r\n  </span><br /><br />','{companyname} | CRM',NULL,0,1,0),(105,'purchase_order','purchase-quotation-to-contact','english','Purchase Quotation (Sent to contact)','Purchase Quotation','<span style=\\\"font-size: 12pt;\\\"> Hello !. </span><br /><br /><span style=\\\"font-size: 12pt;\\\"> We would like to share with you a link of Purchase Quotation information with the number {pq_number} </span><br /><br /><span style=\\\"font-size: 12pt;\\\"><br />Please click on the link to view information: {quotation_link}<br/ >{additional_content}\r\n  </span><br /><br />','{companyname} | CRM',NULL,0,1,0),(106,'purchase_order','debit-note-to-contact','english','Debit Note (Sent to contact)','Debit Note','<span style=\\\"font-size: 12pt;\\\"> Hello !. </span><br /><br /><span style=\\\"font-size: 12pt;\\\"> We would like to share with you a link of Debit Note information with the number {dn_number} </span><br /><br /><span style=\\\"font-size: 12pt;\\\"><br />{additional_content}\r\n  </span><br /><br />','{companyname} | CRM',NULL,0,1,0),(107,'purchase_order','purchase-statement-to-contact','english','Purchase Statement (Sent to contact)','Purchase Statement','<span style=\\\"font-size: 12pt;\\\"> Dear {contact_firstname} {contact_lastname} !. </span><br /><br /><span style=\\\"font-size: 12pt;\\\">Its been a great experience working with you. </span><br /><br /><span style=\\\"font-size: 12pt;\\\"><br />Attached with this email is a list of all transactions for the period between {statement_from} to {statement_to}<br/ ><br/ >For your information your account balance due is total: {statement_balance_due}<br /><br/ > Please contact us if you need more information.<br/ > <br />{additional_content}\r\n  </span><br /><br />','{companyname} | CRM',NULL,0,1,0),(108,'purchase_order','vendor-registration-confirmed','english','Vendor Registration Confirmed','Your registration is confirmed','<p>Dear {contact_firstname} {contact_lastname}<br /><br />We just wanted to let you know that your registration at&nbsp;{companyname} is successfully confirmed and your account is now active.<br /><br />You can login at&nbsp;<a href=\"{vendor_portal_url}\">{vendor_portal_url}</a> with the email and password you provided during registration.<br /><br />Please contact us if you need any help.<br /><br />Kind Regards, <br />{email_signature}</p>\r\n <p><br />(This is an automated email, so please dont reply to this email address)</p>','{companyname} | CRM',NULL,0,1,0),(109,'purchase_order','purchase-contract-to-contact','english','Purchase Contract (Sent to contact)','Purchase Contract','<span style=\\\"font-size: 12pt;\\\"> Hello !. </span><br /><br /><span style=\\\"font-size: 12pt;\\\"> We would like to share with you a link of Purchase Contract information with the number {contract_number} </span><br /><br /><span style=\\\"font-size: 12pt;\\\"><br />Please click on the link to view information: {contract_link}\r\n  </span><br /><br />','{companyname} | CRM',NULL,0,1,0),(110,'purchase_order','new-contact-created','english','New Contact Added/Registered (Welcome Email)','New Contact Added/Registered (Welcome Email)','<span style=\\\"font-size: 12pt;\\\"> Dear {contact_firstname} {contact_lastname}! </span><br /><br /><span style=\\\"font-size: 12pt;\\\"> Welcome to our system </span><br /><br /><span style=\\\"font-size: 12pt;\\\"><br />Click here to login: {vendor_portal_link}</span><br /></span><br />','{companyname} | CRM',NULL,0,1,0),(111,'purchase_order','purchase-request-approval','english','Request approval','Request approval','<span style=\\\"font-size: 12pt;\\\"> Hello {staff_name}! </span><br /><br /><span style=\\\"font-size: 12pt;\\\"> You receive an approval request: {link} from {from_staff_name}</span>','{companyname} | CRM',NULL,0,1,0),(112,'purchase_order','purchase-send-approved','english','Email send approved','Email send approved','<span style=\\\"font-size: 12pt;\\\"> Hello {staff_name}! </span><br /><br /><span style=\\\"font-size: 12pt;\\\">{type} has been approved by {by_staff_name} </span><br /><span style=\\\"font-size: 12pt;\\\"><br />Click here to view detail: {link} </span><br /></span><br />','{companyname} | CRM',NULL,0,1,0),(113,'purchase_order','purchase-send-rejected','english','Email send rejected','Email send rejected','<span style=\\\"font-size: 12pt;\\\"> Hello {staff_name}! </span><br /><br /><span style=\\\"font-size: 12pt;\\\"> {type} has been declined by {by_staff_name} </span><br /><span style=\\\"font-size: 12pt;\\\"><br />Click here to view detail: {link}  </span><br /></span><br />','{companyname} | CRM',NULL,0,1,0),(114,'change_candidate_status','change-candidate-status-to-candidate','english','Change Candidate Status (Sent to Candidate)','Changed Candidate Status','<br />Hi {candidate_name} {last_name}<br /><br />I would like to inform you that your candidate profile status changed to {candidate_status}<br /><br />I will contact you again as soon as I have any news.<br /><br />Kind Regards,<br />{email_signature}.','{companyname} | CRM',NULL,0,1,0),(115,'change_candidate_job_applied_status','change-candidate-job-applied-status-to-candidate','english','Change Candidate Job Applied Status (Sent to Candidate)','Changed Candidate Job Applied Status','<br />Hi {candidate_name} {last_name}<br /><br />I would like to inform you that your Job Applied status changed to {job_applied_status}<br /><br />I will contact you again as soon as I have any news.<br /><br />Kind Regards,<br />{email_signature}.','{companyname} | CRM',NULL,0,1,0),(116,'change_candidate_interview_schedule_status','change-candidate-interview-schedule-status-to-candidate','english','Change Candidate Interview Schedule Status (Sent to Candidate)','Changed Candidate Interview Schedule Status','<br />Hi {candidate_name} {last_name}<br /><br />I would like to inform you that your Interview Schedule status changed to {interview_schedule_status}<br /><br />I will contact you again as soon as I have any news.<br /><br />Kind Regards,<br />{email_signature}.','{companyname} | CRM',NULL,0,1,0),(117,'new_candidate_have_applied','new-candidate-have-applied','english','New candidate have applied (Sent to Responsible)','New candidate have applied','<p><span style=\"font-size: 12pt;\">New Candidate have been applied.</span><br /><br /><span style=\"font-size: 12pt;\">You can view the Candidate profile on the following link: <a href=\"{candidate_link}\">#{candidate_link}</a><br /><br />Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span></p>','{companyname} | CRM',NULL,0,1,0),(118,'staff','flexibackup-new-backup-to-staff','english','Flexi Backup Notification','New Backup Available  - {backup_name}','Hi there! <br /><br /> Please find attached a copy of your {backup_type} created on {backup_date}.  <br /><br /> Regards.','{companyname} | CRM',NULL,0,1,0),(119,'appointly','appointment-cron-reminder-to-staff','english','Appointment reminder (Sent to Staff and Attendees)','You have an upcoming appointment!','<span style=\\\"font-size: 12pt;\\\"> Hello {staff_firstname} {staff_lastname} </span><br /><br /><span style=\\\"font-size: 12pt;\\\"> You have an upcoming appointment that is need to be held date {appointment_date} and location {appointment_location}</span><br /><br /><span style=\\\"font-size: 12pt;\\\"><strong>Additional info for your appointment:</strong></span><br /><span style=\\\"font-size: 12pt;\\\"><strong>Appointment Subject:</strong> {appointment_subject}</span><br /><span style=\\\"font-size: 12pt;\\\"><strong>Appointment Description:</strong> {appointment_description}</span><br /><span style=\\\"font-size: 12pt;\\\"><strong>Appointment scheduled date to start:</strong> {appointment_date}</span><br /><span style=\\\"font-size: 12pt;\\\"><strong>You can view this appointment at the following link:</strong> <a href=\"{appointment_admin_url}\">Your appointment URL</a></span><br /><span style=\\\"font-size: 12pt;\\\"><br />Kind Regards</span><br /><br /><span style=\\\"font-size: 12pt;\\\">{email_signature}</span>','{companyname} | CRM',NULL,0,1,0),(120,'appointly','appointment-recurring-to-staff','english','Appointment recurring (Sent to Staff and Attendees)','Recurring appointment was re-created!','<span style=\\\"font-size: 12pt;\\\"> Hello {staff_firstname} {staff_lastname} </span><br /><br /><span style=\\\"font-size: 12pt;\\\"> Your recurring appointment was recreated with date {appointment_date} and location {appointment_location}</span><br /><br /><span style=\\\"font-size: 12pt;\\\"><strong> Additional info for your appointment:</strong></span><br /><span style=\\\"font-size: 12pt;\\\"><strong>Appointment Subject:</strong> {appointment_subject}</span><br /><span style=\\\"font-size: 12pt;\\\"><strong>Appointment Description:</strong> {appointment_description}</span><br /><span style=\\\"font-size: 12pt;\\\"><strong>Appointment scheduled date to start:</strong> {appointment_date}</span><br /><span style=\\\"font-size: 12pt;\\\"><strong>You can view this appointment at the following link:</strong> <a href=\"{appointment_admin_url}\">Your appointment URL</a></span><br /><span style=\\\"font-size: 12pt;\\\"><br />Kind Regards</span><br /><br /><span style=\\\"font-size: 12pt;\\\">{email_signature}</span>','{companyname} | CRM',NULL,0,1,0),(121,'appointly','appointment-cancelled-to-staff','english','Appointment cancelled (Sent to Staff and Attendees)','Appointment has been cancelled!','<span style=\\\"font-size: 12pt;\\\"> Hello {staff_firstname} {staff_lastname}. </span><br /><br /><span style=\\\"font-size: 12pt;\\\"> The appointment that needed to be held on date {appointment_date} and location {appointment_location} with contact {appointment_client_name} is cancelled.</span><br /><br /><span style=\\\"font-size: 12pt;\\\"><br />Kind Regards</span><br /><br /><span style=\\\"font-size: 12pt;\\\">{email_signature}</span>','{companyname} | CRM',NULL,0,1,0),(122,'appointly','appointment-cancelled-to-contact','english','Appointment cancelled (Sent to Contact)','Your appointment has been cancelled!','<span style=\\\"font-size: 12pt;\\\"> Hello {appointment_client_name}. </span><br /><br /><span style=\\\"font-size: 12pt;\\\"> The appointment that needed to be held on date {appointment_date} and location {appointment_location} is now cancelled.</span><br /><br /><span style=\\\"font-size:12pt;\\\"><br />Kind Regards</span><br /><br /><span style=\\\"font-size: 12pt;\\\">{email_signature}</span>','{companyname} | CRM',NULL,0,1,0),(123,'appointly','appointment-cron-reminder-to-contact','english','Appointment reminder (Sent to Contact)','You have an upcoming appointment!','<span style=\\\"font-size: 12pt;\\\"> Hello {appointment_client_name}. </span><br /><br /><span style=\\\"font-size: 12pt;\\\"> You have an upcoming appointment that is need to be held date {appointment_date} and location {appointment_location}.</span><br /><br /><span style=\\\"font-size: 12pt;\\\"><strong>Additional info for your appointment</strong></span><br /><span style=\\\"font-size: 12pt;\\\"><strong>Appointment Subject:</strong> {appointment_subject}</span><br /><span style=\\\"font-size: 12pt;\\\"><strong>Appointment Description:</strong> {appointment_description}</span><br /><span style=\\\"font-size: 12pt;\\\"><strong>Appointment scheduled date to start:</strong> {appointment_date}</span><br /><span style=\\\"font-size: 12pt;\\\"><strong>You can view this appointment at the following link:</strong> <a href=\"{appointment_public_url}\">Your appointment URL</a></span><br /><span style=\\\"font-size: 12pt;\\\"><br />Kind Regards</span><br /><br /><span style=\\\"font-size: 12pt;\\\">{email_signature}</span>','{companyname} | CRM',NULL,0,1,0),(124,'appointly','appointment-recurring-to-contacts','english','Appointment recurring (Sent to Contact)','Recurring appointment was re-created!','<span style=\\\"font-size: 12pt;\\\"> Hello {appointment_client_name}. </span><br /><br /><span style=\\\"font-size: 12pt;\\\"> Your recurring appointment was recreated with date {appointment_date} and location {appointment_location}.</span><br /><br /><span style=\\\"font-size: 12pt;\\\"><strong>Additional info for your appointment</strong></span><br /><span style=\\\"font-size: 12pt;\\\"><strong>Appointment Subject:</strong> {appointment_subject}</span><br /><span style=\\\"font-size: 12pt;\\\"><strong>Appointment Description:</strong> {appointment_description}</span><br /><span style=\\\"font-size: 12pt;\\\"><strong>Appointment scheduled date to start:</strong> {appointment_date}</span><br /><span style=\\\"font-size: 12pt;\\\"><strong>You can view this appointment at the following link:</strong> <a href=\"{appointment_public_url}\">Your appointment URL</a></span><br /><span style=\\\"font-size: 12pt;\\\"><br />Kind Regards</span><br /><br /><span style=\\\"font-size: 12pt;\\\">{email_signature}</span>','{companyname} | CRM',NULL,0,1,0),(125,'appointly','appointment-approved-to-staff','english','Appointment approved (Sent to Staff and Atendees)','You are added as a appointment attendee!','<span style=\\\"font-size: 12pt;\\\"> Hello {staff_firstname} {staff_lastname}.</span><br /><br /><span style=\\\"font-size: 12pt;\\\"> You are added as a appointment attendee.</span><br /><br /><span style=\\\"font-size: 12pt;\\\"><strong>Appointment Subject:</strong> {appointment_subject}</span><br /><span style=\\\"font-size: 12pt;\\\"><strong>Appointment Description:</strong> {appointment_description}</span><br /><span style=\\\"font-size: 12pt;\\\"><strong>Appointment scheduled date to start:</strong> {appointment_date}</span><br /><span style=\\\"font-size: 12pt;\\\"><strong>You can view this appointment at the following link:</strong> <a href=\"{appointment_admin_url}\">Your appointment URL</a></span><br /><span style=\\\"font-size: 12pt;\\\"><br />Kind Regards</span><br /><br /><span style=\\\"font-size: 12pt;\\\">{email_signature}</span>','{companyname} | CRM',NULL,0,1,0),(126,'appointly','appointment-approved-to-contact','english','Appointment approved (Sent to Contact)','Your appointment has been approved!','<span style=\\\"font-size: 12pt;\\\"> Hello {appointment_client_name}.</span><br /><br /><span style=\\\"font-size: 12pt;\\\"> You appointment has been approved!</span><br /><br /><span style=\\\"font-size: 12pt;\\\"><strong>Appointment Subject:</strong> {appointment_subject}</span><br /><span style=\\\"font-size: 12pt;\\\"><strong>Appointment Description:</strong> {appointment_description}</span><br /><span style=\\\"font-size: 12pt;\\\"><strong>Appointment scheduled date to start:</strong> {appointment_date}</span><br /><span style=\\\"font-size: 12pt;\\\"><strong>You can keep track of your appointment at the following link:</strong> <a href=\"{appointment_public_url}\">Your appointment URL</a></span><br /><span style=\\\"font-size: 12pt;\\\"><br/>If you have any questions Please contact us for more information.</span><br /><br /><span style=\\\"font-size: 12pt;\\\"><br />Kind Regards</span><br /><br /><span style=\\\"font-size: 12pt;\\\">{email_signature}</span>','{companyname} | CRM',NULL,0,1,0),(127,'appointly','appointment-submitted-to-staff','english','New appointment request (Sent to Responsible Person)','New appointment request via external form!','<span 12pt=\"\"><span 12pt=\"\">Hello {staff_firstname} {staff_lastname}<br /><br />New appointment request submitted via external form</span>.<br /><br /><span 12pt=\"\"><strong>Appointment Subject:</strong> {appointment_subject}</span><br /><br /><span 12pt=\"\"><strong>Appointment Description:</strong> {appointment_description}</span><br /><br /><span 12pt=\"\"><strong>Appointment requested scheduled start date:</strong> {appointment_date}</span><br /><br /><span 12pt=\"\"><strong>You can view this appointment request at the following link:</strong> <a href=\"{appointment_admin_url}\">{appointment_admin_url}</a></span><br /><br /><br />{companyname}<br />{crm_url}<br /><span 12pt=\"\"></span></span>','{companyname} | CRM',NULL,0,1,0),(128,'appointly','callback-assigned-to-staff','english','Assigned to callback (Sent to Staff)','You have been assigned to handle a new callback!','<span 12pt=\"\"><span 12pt=\"\">Hello {staff_firstname} {staff_lastname}<br /><br />An admin assigned a callback to you, you can view this callback request at the following link:</strong> <a href=\"{admin_url}/appointly/callbacks\">{admin_url}/appointly/callbacks</a></span><br /><br /><br />{companyname}<br />{crm_url}<br /><span 12pt=\"\"></span></span>','{companyname} | CRM',NULL,0,1,0),(129,'appointly','newcallback-requested-to-staff','english','New callback request (Sent to Callbacks Responsible Person)','You have a new callback request!','<span 12pt=\"\"><span 12pt=\"\">Hello {staff_firstname} {staff_lastname}<br /><br />A new callback request has just been submitted, fast navigate to callbacks to view latest callback submitted:</strong> <a href=\"{admin_url}/appointly/callbacks\">{admin_url}/appointly/callbacks</a></span><br /><br /><br />{companyname}<br />{crm_url}<br /><span 12pt=\"\"></span></span>','{companyname} | CRM',NULL,0,1,0),(130,'appointly','appointly-appointment-request-feedback','english','Request Appointment Feedback (Sent to Client)','Feedback request for appointment!','<span 12pt=\"\"><span 12pt=\"\">Hello {appointment_client_name} <br /><br />A new feedback request has just been submitted, please leave your comments and thoughts about this past appointment, fast navigate to the appointment to add a feedback:</strong> <a href=\"{appointment_public_url}\">{appointment_public_url}</a></span><br /><br /><br />{companyname}<br />{crm_url}<br /><span 12pt=\"\"></span></span>','{companyname} | CRM',NULL,0,1,0),(131,'appointly','appointly-appointment-feedback-received','english','New Feedback Received (Sent to Responsible Person)','New appointment feedback rating received!','<span 12pt=\"\"><span 12pt=\"\">Hello {staff_firstname} {staff_lastname} <br /><br />A new feedback rating has been received from client {appointment_client_name}. View the new feedback rating submitted at the following link:</strong> <a href=\"{appointment_admin_url}\">{appointment_admin_url}</a></span><br /><br /><br />{companyname}<br />{crm_url}<br /><span 12pt=\"\"></span></span>','{companyname} | CRM',NULL,0,1,0),(132,'appointly','appointly-appointment-feedback-updated','english','Feedback Updated (Sent to Responsible Person)','Appointment feedback rating updated!','<span 12pt=\"\"><span 12pt=\"\">Hello {staff_firstname} {staff_lastname} <br /><br />An existing feedback was just updated from client {appointment_client_name}. View the new rating submitted at the following link:</strong> <a href=\"{appointment_admin_url}\">{appointment_admin_url}</a></span><br /><br /><br />{companyname}<br />{crm_url}<br /><span 12pt=\"\"></span></span>','{companyname} | CRM',NULL,0,1,0),(133,'staff','flexstage-tickets-success','english','Flexstage Tickets Success','Tickets - {event_name}','Hi there! <br/><br/>Find the tickets you ordered for the {event_name} event below.<br/><br/> Venue: {venue} <br/><br/> Date/Time: {date_time} <br/><br/> <strong>Tickets</strong><br/> {ticket_details}<br/>Regards.','{companyname} | CRM',NULL,0,1,0),(134,'staff','flexstage-event-invitation','english','Flexstage Event Invitation','Invitation - {event_name}','Hi there! <br/><br/>You are hereby invited for {event_name}.<br/><br/> Venue: {venue} <br/><br/> Date/Time: {date_time} <br/><br/> You can register for the event here: {event_link}<br><br/>Regards.','{companyname} | CRM',NULL,0,1,0);
/*!40000 ALTER TABLE `himalay_tblemailtemplates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblestimate_request_forms`
--

DROP TABLE IF EXISTS `himalay_tblestimate_request_forms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblestimate_request_forms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `form_key` varchar(32) NOT NULL,
  `type` varchar(100) NOT NULL,
  `name` varchar(191) NOT NULL,
  `form_data` longtext DEFAULT NULL,
  `recaptcha` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL,
  `submit_btn_name` varchar(100) DEFAULT NULL,
  `submit_btn_bg_color` varchar(10) DEFAULT '#84c529',
  `submit_btn_text_color` varchar(10) DEFAULT '#ffffff',
  `success_submit_msg` mediumtext DEFAULT NULL,
  `submit_action` int(11) DEFAULT 0,
  `submit_redirect_url` longtext DEFAULT NULL,
  `language` varchar(100) DEFAULT NULL,
  `dateadded` datetime DEFAULT NULL,
  `notify_type` varchar(100) DEFAULT NULL,
  `notify_ids` longtext DEFAULT NULL,
  `responsible` int(11) DEFAULT NULL,
  `notify_request_submitted` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblestimate_request_forms`
--

LOCK TABLES `himalay_tblestimate_request_forms` WRITE;
/*!40000 ALTER TABLE `himalay_tblestimate_request_forms` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblestimate_request_forms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblestimate_request_status`
--

DROP TABLE IF EXISTS `himalay_tblestimate_request_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblestimate_request_status` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `statusorder` int(11) DEFAULT NULL,
  `color` varchar(10) DEFAULT NULL,
  `flag` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblestimate_request_status`
--

LOCK TABLES `himalay_tblestimate_request_status` WRITE;
/*!40000 ALTER TABLE `himalay_tblestimate_request_status` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblestimate_request_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblestimate_requests`
--

DROP TABLE IF EXISTS `himalay_tblestimate_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblestimate_requests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `submission` longtext NOT NULL,
  `last_status_change` datetime DEFAULT NULL,
  `date_estimated` datetime DEFAULT NULL,
  `from_form_id` int(11) DEFAULT NULL,
  `assigned` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `default_language` int(11) NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblestimate_requests`
--

LOCK TABLES `himalay_tblestimate_requests` WRITE;
/*!40000 ALTER TABLE `himalay_tblestimate_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblestimate_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblestimates`
--

DROP TABLE IF EXISTS `himalay_tblestimates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblestimates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sent` tinyint(1) NOT NULL DEFAULT 0,
  `datesend` datetime DEFAULT NULL,
  `clientid` int(11) NOT NULL,
  `deleted_customer_name` varchar(100) DEFAULT NULL,
  `project_id` int(11) NOT NULL DEFAULT 0,
  `number` int(11) NOT NULL,
  `prefix` varchar(50) DEFAULT NULL,
  `number_format` int(11) NOT NULL DEFAULT 0,
  `hash` varchar(32) DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `date` date NOT NULL,
  `expirydate` date DEFAULT NULL,
  `currency` int(11) NOT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `total_tax` decimal(15,2) NOT NULL DEFAULT 0.00,
  `total` decimal(15,2) NOT NULL,
  `adjustment` decimal(15,2) DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `clientnote` mediumtext DEFAULT NULL,
  `adminnote` mediumtext DEFAULT NULL,
  `discount_percent` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `discount_type` varchar(30) DEFAULT NULL,
  `invoiceid` int(11) DEFAULT NULL,
  `invoiced_date` datetime DEFAULT NULL,
  `terms` mediumtext DEFAULT NULL,
  `reference_no` varchar(100) DEFAULT NULL,
  `sale_agent` int(11) NOT NULL DEFAULT 0,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT NULL,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT NULL,
  `include_shipping` tinyint(1) NOT NULL,
  `show_shipping_on_estimate` tinyint(1) NOT NULL DEFAULT 1,
  `show_quantity_as` int(11) NOT NULL DEFAULT 1,
  `pipeline_order` int(11) DEFAULT 1,
  `is_expiry_notified` int(11) NOT NULL DEFAULT 0,
  `acceptance_firstname` varchar(50) DEFAULT NULL,
  `acceptance_lastname` varchar(50) DEFAULT NULL,
  `acceptance_email` varchar(100) DEFAULT NULL,
  `acceptance_date` datetime DEFAULT NULL,
  `acceptance_ip` varchar(40) DEFAULT NULL,
  `signature` varchar(40) DEFAULT NULL,
  `short_link` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `currency` (`currency`),
  KEY `project_id` (`project_id`),
  KEY `sale_agent` (`sale_agent`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblestimates`
--

LOCK TABLES `himalay_tblestimates` WRITE;
/*!40000 ALTER TABLE `himalay_tblestimates` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblestimates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblevents`
--

DROP TABLE IF EXISTS `himalay_tblevents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblevents` (
  `eventid` int(11) NOT NULL AUTO_INCREMENT,
  `title` longtext NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `userid` int(11) NOT NULL,
  `start` datetime NOT NULL,
  `end` datetime DEFAULT NULL,
  `public` int(11) NOT NULL DEFAULT 0,
  `color` varchar(10) DEFAULT NULL,
  `isstartnotified` tinyint(1) NOT NULL DEFAULT 0,
  `reminder_before` int(11) NOT NULL DEFAULT 0,
  `reminder_before_type` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`eventid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblevents`
--

LOCK TABLES `himalay_tblevents` WRITE;
/*!40000 ALTER TABLE `himalay_tblevents` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblevents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblexpenses`
--

DROP TABLE IF EXISTS `himalay_tblexpenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblexpenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` int(11) NOT NULL,
  `currency` int(11) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `tax` int(11) DEFAULT NULL,
  `tax2` int(11) NOT NULL DEFAULT 0,
  `reference_no` varchar(100) DEFAULT NULL,
  `note` mediumtext DEFAULT NULL,
  `expense_name` varchar(191) DEFAULT NULL,
  `clientid` int(11) NOT NULL,
  `project_id` int(11) NOT NULL DEFAULT 0,
  `billable` int(11) DEFAULT 0,
  `invoiceid` int(11) DEFAULT NULL,
  `paymentmode` varchar(50) DEFAULT NULL,
  `date` date NOT NULL,
  `recurring_type` varchar(10) DEFAULT NULL,
  `repeat_every` int(11) DEFAULT NULL,
  `recurring` int(11) NOT NULL DEFAULT 0,
  `cycles` int(11) NOT NULL DEFAULT 0,
  `total_cycles` int(11) NOT NULL DEFAULT 0,
  `custom_recurring` int(11) NOT NULL DEFAULT 0,
  `last_recurring_date` date DEFAULT NULL,
  `create_invoice_billable` tinyint(1) DEFAULT NULL,
  `send_invoice_to_customer` tinyint(1) NOT NULL,
  `recurring_from` int(11) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  `addedfrom` int(11) NOT NULL,
  `vendor` int(11) DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `date_paid` date DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `is_bill` int(11) NOT NULL DEFAULT 0,
  `reason_for_void` text DEFAULT NULL,
  `voided` int(11) NOT NULL DEFAULT 0,
  `approved` int(11) NOT NULL DEFAULT 0,
  `from_fleet` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `project_id` (`project_id`),
  KEY `category` (`category`),
  KEY `currency` (`currency`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblexpenses`
--

LOCK TABLES `himalay_tblexpenses` WRITE;
/*!40000 ALTER TABLE `himalay_tblexpenses` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblexpenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblexpenses_categories`
--

DROP TABLE IF EXISTS `himalay_tblexpenses_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblexpenses_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblexpenses_categories`
--

LOCK TABLES `himalay_tblexpenses_categories` WRITE;
/*!40000 ALTER TABLE `himalay_tblexpenses_categories` DISABLE KEYS */;
INSERT INTO `himalay_tblexpenses_categories` VALUES (1,'Fleet: Work Order',NULL);
/*!40000 ALTER TABLE `himalay_tblexpenses_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfe_activity_log`
--

DROP TABLE IF EXISTS `himalay_tblfe_activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfe_activity_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(45) NOT NULL,
  `staffid` int(11) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `note` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfe_activity_log`
--

LOCK TABLES `himalay_tblfe_activity_log` WRITE;
/*!40000 ALTER TABLE `himalay_tblfe_activity_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfe_activity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfe_approval_details`
--

DROP TABLE IF EXISTS `himalay_tblfe_approval_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfe_approval_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(45) NOT NULL,
  `staffid` varchar(45) DEFAULT NULL,
  `approve` varchar(45) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `approve_action` varchar(255) DEFAULT NULL,
  `reject_action` varchar(255) DEFAULT NULL,
  `approve_value` varchar(255) DEFAULT NULL,
  `reject_value` varchar(255) DEFAULT NULL,
  `staff_approve` int(11) DEFAULT NULL,
  `action` varchar(45) DEFAULT NULL,
  `sender` int(11) DEFAULT NULL,
  `date_send` datetime DEFAULT NULL,
  `notification_recipient` longtext DEFAULT NULL,
  `approval_deadline` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfe_approval_details`
--

LOCK TABLES `himalay_tblfe_approval_details` WRITE;
/*!40000 ALTER TABLE `himalay_tblfe_approval_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfe_approval_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfe_approval_setting`
--

DROP TABLE IF EXISTS `himalay_tblfe_approval_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfe_approval_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `related` varchar(255) NOT NULL,
  `setting` longtext NOT NULL,
  `choose_when_approving` int(11) NOT NULL DEFAULT 0,
  `notification_recipient` longtext DEFAULT NULL,
  `number_day_approval` int(11) DEFAULT NULL,
  `departments` text DEFAULT NULL,
  `job_positions` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfe_approval_setting`
--

LOCK TABLES `himalay_tblfe_approval_setting` WRITE;
/*!40000 ALTER TABLE `himalay_tblfe_approval_setting` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfe_approval_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfe_asset_maintenances`
--

DROP TABLE IF EXISTS `himalay_tblfe_asset_maintenances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfe_asset_maintenances` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `asset_id` int(11) DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `maintenance_type` varchar(30) DEFAULT NULL,
  `title` varchar(250) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `completion_date` date DEFAULT NULL,
  `cost` decimal(15,2) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  `warranty_improvement` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfe_asset_maintenances`
--

LOCK TABLES `himalay_tblfe_asset_maintenances` WRITE;
/*!40000 ALTER TABLE `himalay_tblfe_asset_maintenances` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfe_asset_maintenances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfe_asset_manufacturers`
--

DROP TABLE IF EXISTS `himalay_tblfe_asset_manufacturers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfe_asset_manufacturers` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `url` text DEFAULT NULL,
  `support_url` text DEFAULT NULL,
  `support_phone` varchar(50) DEFAULT NULL,
  `support_email` varchar(100) DEFAULT NULL,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  `creator_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfe_asset_manufacturers`
--

LOCK TABLES `himalay_tblfe_asset_manufacturers` WRITE;
/*!40000 ALTER TABLE `himalay_tblfe_asset_manufacturers` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfe_asset_manufacturers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfe_assets`
--

DROP TABLE IF EXISTS `himalay_tblfe_assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfe_assets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `assets_code` varchar(20) DEFAULT NULL,
  `assets_name` varchar(255) DEFAULT NULL,
  `series` varchar(200) DEFAULT NULL,
  `asset_group` int(11) DEFAULT NULL,
  `asset_location` int(11) DEFAULT NULL,
  `model_id` int(11) DEFAULT NULL,
  `date_buy` date DEFAULT NULL,
  `warranty_period` int(11) DEFAULT NULL,
  `unit_price` decimal(15,2) DEFAULT NULL,
  `depreciation` int(11) DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `order_number` varchar(150) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `requestable` int(11) DEFAULT 0,
  `qr_code` varchar(300) DEFAULT NULL,
  `type` varchar(50) NOT NULL DEFAULT 'asset',
  `status` int(11) NOT NULL DEFAULT 1,
  `checkin_out` int(11) NOT NULL DEFAULT 1,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  `quantity` int(11) DEFAULT NULL,
  `min_quantity` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `product_key` text DEFAULT NULL,
  `seats` varchar(50) DEFAULT NULL,
  `model_no` varchar(80) DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `manufacturer_id` int(11) DEFAULT NULL,
  `licensed_to_name` text DEFAULT NULL,
  `licensed_to_email` text DEFAULT NULL,
  `reassignable` int(11) NOT NULL DEFAULT 0,
  `termination_date` date DEFAULT NULL,
  `expiration_date` date DEFAULT NULL,
  `purchase_order_number` varchar(150) DEFAULT NULL,
  `maintained` int(11) NOT NULL DEFAULT 0,
  `item_no` varchar(80) DEFAULT NULL,
  `checkin_out_id` int(11) DEFAULT NULL,
  `active` int(11) NOT NULL DEFAULT 1,
  `selling_price` decimal(15,2) NOT NULL DEFAULT 0.00,
  `rental_price` decimal(15,2) NOT NULL DEFAULT 0.00,
  `for_rent` int(11) NOT NULL DEFAULT 0,
  `for_sell` int(11) NOT NULL DEFAULT 0,
  `renting_period` decimal(15,2) DEFAULT NULL,
  `renting_unit` varchar(10) DEFAULT NULL COMMENT 'hour day week month year',
  `warehouse_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfe_assets`
--

LOCK TABLES `himalay_tblfe_assets` WRITE;
/*!40000 ALTER TABLE `himalay_tblfe_assets` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfe_assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfe_assign_asset_predefined_kits`
--

DROP TABLE IF EXISTS `himalay_tblfe_assign_asset_predefined_kits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfe_assign_asset_predefined_kits` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) DEFAULT NULL,
  `assign_data` text DEFAULT '',
  `parent_id` int(11) DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfe_assign_asset_predefined_kits`
--

LOCK TABLES `himalay_tblfe_assign_asset_predefined_kits` WRITE;
/*!40000 ALTER TABLE `himalay_tblfe_assign_asset_predefined_kits` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfe_assign_asset_predefined_kits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfe_audit_detail_requests`
--

DROP TABLE IF EXISTS `himalay_tblfe_audit_detail_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfe_audit_detail_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `asset_id` int(11) DEFAULT NULL,
  `asset_name` varchar(300) DEFAULT NULL,
  `type` varchar(30) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `adjusted` int(11) DEFAULT NULL,
  `accept` int(11) NOT NULL DEFAULT 0,
  `audit_id` int(11) DEFAULT NULL,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  `maintenance` int(11) NOT NULL DEFAULT 0,
  `maintenance_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfe_audit_detail_requests`
--

LOCK TABLES `himalay_tblfe_audit_detail_requests` WRITE;
/*!40000 ALTER TABLE `himalay_tblfe_audit_detail_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfe_audit_detail_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfe_audit_requests`
--

DROP TABLE IF EXISTS `himalay_tblfe_audit_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfe_audit_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(300) DEFAULT NULL,
  `audit_date` datetime NOT NULL DEFAULT current_timestamp(),
  `auditor` int(11) DEFAULT NULL,
  `asset_location` int(11) DEFAULT NULL,
  `model_id` int(11) DEFAULT NULL,
  `asset_id` text DEFAULT NULL,
  `checkin_checkout_status` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `closed` int(11) NOT NULL DEFAULT 0,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  `from_order` int(11) DEFAULT NULL,
  `creator_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfe_audit_requests`
--

LOCK TABLES `himalay_tblfe_audit_requests` WRITE;
/*!40000 ALTER TABLE `himalay_tblfe_audit_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfe_audit_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfe_cart`
--

DROP TABLE IF EXISTS `himalay_tblfe_cart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfe_cart` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_contact` int(11) NOT NULL,
  `name` varchar(120) NOT NULL,
  `address` varchar(250) NOT NULL,
  `phone_number` varchar(20) NOT NULL,
  `voucher` varchar(100) NOT NULL,
  `status` int(11) DEFAULT 0,
  `complete` int(11) DEFAULT 0,
  `order_number` varchar(100) DEFAULT NULL,
  `channel_id` int(11) DEFAULT NULL,
  `channel` varchar(150) DEFAULT NULL,
  `first_name` varchar(60) DEFAULT NULL,
  `last_name` varchar(60) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `hash` varchar(32) DEFAULT NULL,
  `tax_id` text DEFAULT NULL,
  `tax_rate` text DEFAULT NULL,
  `tax_name` text DEFAULT NULL,
  `unit_id` int(11) DEFAULT NULL,
  `unit_name` varchar(255) DEFAULT NULL,
  `add_discount` decimal(15,2) DEFAULT 0.00,
  `company` varchar(150) DEFAULT NULL,
  `phonenumber` varchar(15) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL,
  `zip` varchar(50) DEFAULT NULL,
  `billing_street` varchar(150) DEFAULT NULL,
  `billing_city` varchar(50) DEFAULT NULL,
  `billing_state` varchar(50) DEFAULT NULL,
  `billing_country` varchar(50) DEFAULT NULL,
  `billing_zip` varchar(50) DEFAULT NULL,
  `shipping_street` varchar(150) DEFAULT NULL,
  `shipping_city` varchar(50) DEFAULT NULL,
  `shipping_state` varchar(50) DEFAULT NULL,
  `shipping_country` varchar(50) DEFAULT NULL,
  `shipping_zip` varchar(50) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `reason` varchar(250) DEFAULT NULL,
  `admin_action` int(11) DEFAULT 0,
  `discount` varchar(250) DEFAULT NULL,
  `discount_type` int(11) DEFAULT 0,
  `total` varchar(250) DEFAULT NULL,
  `sub_total` varchar(250) DEFAULT NULL,
  `discount_total` decimal(15,2) NOT NULL DEFAULT 0.00,
  `invoice` varchar(250) NOT NULL DEFAULT '',
  `number_invoice` varchar(250) NOT NULL DEFAULT '',
  `stock_export_number` varchar(250) NOT NULL DEFAULT '',
  `create_invoice` varchar(5) NOT NULL DEFAULT 'off',
  `stock_export` varchar(5) NOT NULL DEFAULT 'off',
  `customers_pay` decimal(15,2) NOT NULL DEFAULT 0.00,
  `amount_returned` decimal(15,2) NOT NULL DEFAULT 0.00,
  `tax` decimal(15,2) NOT NULL DEFAULT 0.00,
  `seller` int(11) DEFAULT NULL,
  `staff_note` text DEFAULT NULL,
  `payment_note` text DEFAULT NULL,
  `allowed_payment_modes` varchar(200) DEFAULT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `shipping` decimal(15,2) NOT NULL DEFAULT 0.00,
  `payment_method_title` varchar(250) DEFAULT NULL,
  `discount_type_str` text DEFAULT NULL,
  `discount_percent` decimal(15,2) DEFAULT NULL,
  `adjustment` decimal(15,2) DEFAULT NULL,
  `currency` int(11) DEFAULT NULL,
  `terms` text DEFAULT NULL,
  `shipping_tax` decimal(15,2) DEFAULT NULL,
  `enable` int(11) NOT NULL DEFAULT 1,
  `duedate` date DEFAULT NULL,
  `shipping_tax_json` varchar(150) DEFAULT NULL,
  `discount_voucher` varchar(150) DEFAULT NULL,
  `original_order_id` int(11) DEFAULT NULL,
  `return_reason` longtext DEFAULT NULL,
  `approve_status` int(11) NOT NULL DEFAULT 0,
  `process_invoice` varchar(5) NOT NULL DEFAULT 'off',
  `stock_import_number` int(11) NOT NULL DEFAULT 0,
  `fee_for_return_order` decimal(15,2) DEFAULT NULL,
  `estimate_id` int(11) DEFAULT NULL,
  `shipping_form` varchar(50) DEFAULT 'fixed',
  `shipping_value` decimal(15,2) DEFAULT 0.00,
  `type` varchar(30) NOT NULL DEFAULT 'order',
  `datecreator` datetime NOT NULL DEFAULT current_timestamp(),
  `return_reason_type` varchar(50) DEFAULT NULL,
  `return_type` varchar(30) DEFAULT NULL,
  `audit_id` int(11) DEFAULT NULL,
  `maintenance_id` int(11) DEFAULT NULL,
  `credit_note_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfe_cart`
--

LOCK TABLES `himalay_tblfe_cart` WRITE;
/*!40000 ALTER TABLE `himalay_tblfe_cart` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfe_cart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfe_cart_detailt`
--

DROP TABLE IF EXISTS `himalay_tblfe_cart_detailt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfe_cart_detailt` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `classify` varchar(30) DEFAULT NULL,
  `cart_id` int(11) NOT NULL,
  `product_name` varchar(150) DEFAULT NULL,
  `prices` decimal(15,2) DEFAULT NULL,
  `long_description` text DEFAULT NULL,
  `sku` text NOT NULL,
  `percent_discount` float NOT NULL,
  `prices_discount` decimal(15,2) NOT NULL,
  `tax` text DEFAULT NULL,
  `tax_id` text DEFAULT NULL,
  `tax_rate` text DEFAULT NULL,
  `tax_name` text DEFAULT NULL,
  `unit_id` int(11) DEFAULT NULL,
  `unit_name` varchar(255) DEFAULT NULL,
  `pickup_time` varchar(10) DEFAULT NULL,
  `dropoff_time` varchar(10) DEFAULT NULL,
  `rental_start_date` date DEFAULT NULL,
  `rental_end_date` date DEFAULT NULL,
  `number_date` int(11) DEFAULT NULL,
  `rental_value` decimal(15,2) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `renting_period` decimal(15,2) DEFAULT NULL,
  `renting_unit` varchar(10) DEFAULT NULL COMMENT 'hour day week month year',
  `maintenance_id` int(11) DEFAULT NULL,
  `estimate_id` int(11) DEFAULT NULL,
  `available_quantity` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfe_cart_detailt`
--

LOCK TABLES `himalay_tblfe_cart_detailt` WRITE;
/*!40000 ALTER TABLE `himalay_tblfe_cart_detailt` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfe_cart_detailt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfe_categories`
--

DROP TABLE IF EXISTS `himalay_tblfe_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfe_categories` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `category_name` varchar(200) NOT NULL,
  `type` varchar(30) DEFAULT NULL,
  `category_eula` text DEFAULT NULL,
  `primary_default_eula` bit(1) NOT NULL DEFAULT b'0',
  `confirm_acceptance` bit(1) NOT NULL DEFAULT b'0',
  `send_mail_to_user` bit(1) NOT NULL DEFAULT b'0',
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  `creator_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfe_categories`
--

LOCK TABLES `himalay_tblfe_categories` WRITE;
/*!40000 ALTER TABLE `himalay_tblfe_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfe_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfe_checkin_assets`
--

DROP TABLE IF EXISTS `himalay_tblfe_checkin_assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfe_checkin_assets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `model` varchar(200) DEFAULT NULL,
  `asset_name` varchar(200) DEFAULT NULL,
  `item_id` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `checkout_to` varchar(20) DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `asset_id` int(11) DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `checkin_date` date DEFAULT NULL,
  `expected_checkin_date` date DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  `check_status` int(11) NOT NULL DEFAULT 2,
  `requestable` int(11) NOT NULL DEFAULT 0,
  `request_status` int(11) NOT NULL DEFAULT 0,
  `request_title` varchar(300) DEFAULT NULL,
  `predefined_kit_id` int(11) DEFAULT NULL,
  `item_type` varchar(30) DEFAULT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `creator_id` int(11) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfe_checkin_assets`
--

LOCK TABLES `himalay_tblfe_checkin_assets` WRITE;
/*!40000 ALTER TABLE `himalay_tblfe_checkin_assets` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfe_checkin_assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfe_cron_log`
--

DROP TABLE IF EXISTS `himalay_tblfe_cron_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfe_cron_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  `cron_name` varchar(200) DEFAULT NULL,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfe_cron_log`
--

LOCK TABLES `himalay_tblfe_cron_log` WRITE;
/*!40000 ALTER TABLE `himalay_tblfe_cron_log` DISABLE KEYS */;
INSERT INTO `himalay_tblfe_cron_log` VALUES (1,'2025-07-09 00:00:00','auto_depreciation',0,''),(2,'2025-07-09 00:00:00','auto_depreciation',0,''),(3,'2025-07-10 00:00:00','auto_depreciation',0,''),(4,'2025-07-11 00:00:00','auto_depreciation',0,''),(5,'2025-07-12 00:00:00','auto_depreciation',0,''),(6,'2025-07-13 00:00:00','auto_depreciation',0,''),(7,'2025-07-14 00:00:00','auto_depreciation',0,''),(8,'2025-07-15 00:00:00','auto_depreciation',0,'');
/*!40000 ALTER TABLE `himalay_tblfe_cron_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfe_custom_field_values`
--

DROP TABLE IF EXISTS `himalay_tblfe_custom_field_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfe_custom_field_values` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(300) DEFAULT NULL,
  `type` varchar(30) DEFAULT NULL,
  `option` text DEFAULT NULL,
  `required` int(11) NOT NULL DEFAULT 1,
  `value` text DEFAULT NULL,
  `fieldset_id` int(11) NOT NULL,
  `custom_field_id` int(11) NOT NULL,
  `asset_id` int(11) NOT NULL,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfe_custom_field_values`
--

LOCK TABLES `himalay_tblfe_custom_field_values` WRITE;
/*!40000 ALTER TABLE `himalay_tblfe_custom_field_values` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfe_custom_field_values` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfe_custom_fields`
--

DROP TABLE IF EXISTS `himalay_tblfe_custom_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfe_custom_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(300) DEFAULT NULL,
  `type` varchar(30) DEFAULT NULL,
  `option` text DEFAULT NULL,
  `required` int(11) NOT NULL DEFAULT 1,
  `default_value` text DEFAULT NULL,
  `fieldset_id` int(11) NOT NULL,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfe_custom_fields`
--

LOCK TABLES `himalay_tblfe_custom_fields` WRITE;
/*!40000 ALTER TABLE `himalay_tblfe_custom_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfe_custom_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfe_depreciation_items`
--

DROP TABLE IF EXISTS `himalay_tblfe_depreciation_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfe_depreciation_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL,
  `value` float DEFAULT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfe_depreciation_items`
--

LOCK TABLES `himalay_tblfe_depreciation_items` WRITE;
/*!40000 ALTER TABLE `himalay_tblfe_depreciation_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfe_depreciation_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfe_depreciations`
--

DROP TABLE IF EXISTS `himalay_tblfe_depreciations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfe_depreciations` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `term` double DEFAULT NULL,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  `creator_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfe_depreciations`
--

LOCK TABLES `himalay_tblfe_depreciations` WRITE;
/*!40000 ALTER TABLE `himalay_tblfe_depreciations` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfe_depreciations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfe_fieldsets`
--

DROP TABLE IF EXISTS `himalay_tblfe_fieldsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfe_fieldsets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(300) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  `creator_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfe_fieldsets`
--

LOCK TABLES `himalay_tblfe_fieldsets` WRITE;
/*!40000 ALTER TABLE `himalay_tblfe_fieldsets` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfe_fieldsets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfe_goods_delivery`
--

DROP TABLE IF EXISTS `himalay_tblfe_goods_delivery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfe_goods_delivery` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rel_type` int(11) DEFAULT NULL COMMENT 'type goods delivery',
  `rel_document` int(11) DEFAULT NULL COMMENT 'document id of goods delivery',
  `customer_code` text DEFAULT NULL,
  `customer_name` varchar(100) DEFAULT NULL,
  `to_` varchar(100) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL COMMENT 'the reason delivery',
  `staff_id` int(11) DEFAULT NULL COMMENT 'salesman',
  `date_c` date DEFAULT NULL,
  `date_add` date DEFAULT NULL,
  `goods_delivery_code` varchar(100) DEFAULT NULL COMMENT 'số chứng từ xuất kho',
  `approval` int(11) DEFAULT 0 COMMENT 'status approval ',
  `addedfrom` int(11) DEFAULT NULL,
  `total_money` varchar(200) DEFAULT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `total_discount` varchar(100) DEFAULT NULL,
  `after_discount` varchar(100) DEFAULT NULL,
  `invoice_id` varchar(100) DEFAULT NULL,
  `project` text DEFAULT NULL,
  `type` text DEFAULT NULL,
  `department` int(11) DEFAULT NULL,
  `requester` int(11) DEFAULT NULL,
  `invoice_no` text DEFAULT NULL,
  `pr_order_id` int(11) DEFAULT NULL,
  `type_of_delivery` varchar(100) DEFAULT 'total',
  `additional_discount` decimal(15,2) DEFAULT 0.00,
  `sub_total` decimal(15,2) DEFAULT 0.00,
  `delivery_status` varchar(100) DEFAULT 'ready_for_packing',
  `shipping_fee` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfe_goods_delivery`
--

LOCK TABLES `himalay_tblfe_goods_delivery` WRITE;
/*!40000 ALTER TABLE `himalay_tblfe_goods_delivery` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfe_goods_delivery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfe_goods_delivery_activity_log`
--

DROP TABLE IF EXISTS `himalay_tblfe_goods_delivery_activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfe_goods_delivery_activity_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(100) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `additional_data` text DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `staffid` int(11) DEFAULT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfe_goods_delivery_activity_log`
--

LOCK TABLES `himalay_tblfe_goods_delivery_activity_log` WRITE;
/*!40000 ALTER TABLE `himalay_tblfe_goods_delivery_activity_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfe_goods_delivery_activity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfe_goods_delivery_detail`
--

DROP TABLE IF EXISTS `himalay_tblfe_goods_delivery_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfe_goods_delivery_detail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `goods_delivery_id` int(11) NOT NULL,
  `commodity_code` varchar(100) DEFAULT NULL,
  `commodity_name` text DEFAULT NULL,
  `warehouse_id` text DEFAULT NULL,
  `unit_id` text DEFAULT NULL,
  `quantities` text DEFAULT NULL,
  `unit_price` varchar(100) DEFAULT NULL,
  `total_money` varchar(200) DEFAULT NULL,
  `discount` varchar(100) DEFAULT NULL,
  `discount_money` varchar(100) DEFAULT NULL,
  `available_quantity` varchar(100) DEFAULT NULL,
  `tax_id` varchar(100) DEFAULT NULL,
  `total_after_discount` varchar(100) DEFAULT NULL,
  `expiry_date` text DEFAULT NULL,
  `lot_number` text DEFAULT NULL,
  `guarantee_period` text DEFAULT NULL,
  `tax_rate` text DEFAULT NULL,
  `tax_name` text DEFAULT NULL,
  `sub_total` decimal(15,2) DEFAULT 0.00,
  `packing_qty` decimal(15,2) DEFAULT 0.00,
  `serial_number` varchar(255) DEFAULT NULL,
  `note` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfe_goods_delivery_detail`
--

LOCK TABLES `himalay_tblfe_goods_delivery_detail` WRITE;
/*!40000 ALTER TABLE `himalay_tblfe_goods_delivery_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfe_goods_delivery_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfe_goods_delivery_invoices_pr_orders`
--

DROP TABLE IF EXISTS `himalay_tblfe_goods_delivery_invoices_pr_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfe_goods_delivery_invoices_pr_orders` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) DEFAULT NULL COMMENT 'goods_delivery_id',
  `rel_type` int(11) DEFAULT NULL COMMENT 'invoice_id or purchase order id',
  `type` varchar(100) DEFAULT NULL COMMENT 'invoice,  purchase_orders',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfe_goods_delivery_invoices_pr_orders`
--

LOCK TABLES `himalay_tblfe_goods_delivery_invoices_pr_orders` WRITE;
/*!40000 ALTER TABLE `himalay_tblfe_goods_delivery_invoices_pr_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfe_goods_delivery_invoices_pr_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfe_goods_receipt`
--

DROP TABLE IF EXISTS `himalay_tblfe_goods_receipt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfe_goods_receipt` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `supplier_code` varchar(100) DEFAULT NULL,
  `supplier_name` text DEFAULT NULL,
  `deliver_name` text DEFAULT NULL,
  `buyer_id` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `pr_order_id` int(11) DEFAULT NULL COMMENT 'code puchase request agree',
  `date_c` date DEFAULT NULL,
  `date_add` date DEFAULT NULL,
  `goods_receipt_code` varchar(100) DEFAULT NULL,
  `total_tax_money` varchar(100) DEFAULT NULL,
  `total_goods_money` varchar(100) DEFAULT NULL,
  `value_of_inventory` varchar(100) DEFAULT NULL,
  `invoice_no` text DEFAULT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `total_money` varchar(100) DEFAULT NULL COMMENT 'total_money = total_tax_money +total_goods_money ',
  `approval` int(11) DEFAULT 0,
  `addedfrom` int(11) DEFAULT NULL,
  `from_order` int(11) DEFAULT NULL,
  `creator_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfe_goods_receipt`
--

LOCK TABLES `himalay_tblfe_goods_receipt` WRITE;
/*!40000 ALTER TABLE `himalay_tblfe_goods_receipt` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfe_goods_receipt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfe_goods_receipt_detail`
--

DROP TABLE IF EXISTS `himalay_tblfe_goods_receipt_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfe_goods_receipt_detail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `goods_receipt_id` int(11) NOT NULL,
  `commodity_code` varchar(100) DEFAULT NULL,
  `commodity_name` text DEFAULT NULL,
  `warehouse_id` text DEFAULT NULL,
  `unit_id` text DEFAULT NULL,
  `quantities` text DEFAULT NULL,
  `unit_price` varchar(100) DEFAULT NULL,
  `tax` varchar(100) DEFAULT NULL,
  `tax_money` varchar(100) DEFAULT NULL,
  `goods_money` varchar(100) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `tax_name` text DEFAULT NULL,
  `sub_total` decimal(15,2) DEFAULT 0.00,
  `tax_rate` text DEFAULT NULL,
  `serial_number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfe_goods_receipt_detail`
--

LOCK TABLES `himalay_tblfe_goods_receipt_detail` WRITE;
/*!40000 ALTER TABLE `himalay_tblfe_goods_receipt_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfe_goods_receipt_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfe_goods_transaction_detail`
--

DROP TABLE IF EXISTS `himalay_tblfe_goods_transaction_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfe_goods_transaction_detail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `goods_receipt_id` int(11) DEFAULT NULL COMMENT 'id_goods_receipt_id or goods_delivery_id',
  `goods_id` int(11) NOT NULL COMMENT ' is id commodity',
  `quantity` varchar(100) DEFAULT NULL,
  `date_add` datetime DEFAULT NULL,
  `commodity_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `note` text DEFAULT NULL,
  `status` int(2) DEFAULT NULL COMMENT '1:Goods receipt note 2:Goods delivery note',
  `old_quantity` varchar(100) DEFAULT NULL,
  `purchase_price` varchar(100) DEFAULT NULL,
  `price` varchar(100) DEFAULT NULL,
  `expiry_date` text DEFAULT NULL,
  `lot_number` text DEFAULT NULL,
  `from_stock_name` int(11) DEFAULT NULL,
  `to_stock_name` int(11) DEFAULT NULL,
  `serial_number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`,`commodity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfe_goods_transaction_detail`
--

LOCK TABLES `himalay_tblfe_goods_transaction_detail` WRITE;
/*!40000 ALTER TABLE `himalay_tblfe_goods_transaction_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfe_goods_transaction_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfe_goods_transaction_details`
--

DROP TABLE IF EXISTS `himalay_tblfe_goods_transaction_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfe_goods_transaction_details` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rel_type` varchar(100) DEFAULT NULL COMMENT 'goods_receipt or goods_delivery or loss_adjustment or internal_delivery',
  `rel_id` int(11) NOT NULL COMMENT ' goods_receipt_id or goods_delivery_id or loss_adjustment_id or internal_delivery_id',
  `rel_id_detail` int(11) NOT NULL COMMENT ' goods_receipt_id or goods_delivery_id or loss_adjustment_id or internal_delivery_id',
  `item_id` int(11) NOT NULL,
  `old_quantity` decimal(15,2) DEFAULT 0.00,
  `quantity` decimal(15,2) DEFAULT 0.00,
  `rate` decimal(15,2) DEFAULT 0.00,
  `expiry_date` date DEFAULT NULL,
  `lot_number` text DEFAULT NULL,
  `from_warehouse_id` int(11) DEFAULT NULL,
  `to_warehouse_id` int(11) DEFAULT NULL,
  `date_add` datetime DEFAULT NULL,
  `added_from_id` int(11) DEFAULT NULL,
  `added_from_type` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfe_goods_transaction_details`
--

LOCK TABLES `himalay_tblfe_goods_transaction_details` WRITE;
/*!40000 ALTER TABLE `himalay_tblfe_goods_transaction_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfe_goods_transaction_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfe_locations`
--

DROP TABLE IF EXISTS `himalay_tblfe_locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfe_locations` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `location_name` varchar(200) NOT NULL,
  `parent` int(11) DEFAULT NULL,
  `manager` int(11) DEFAULT NULL,
  `location_currency` varchar(50) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL,
  `zip` varchar(50) DEFAULT NULL,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfe_locations`
--

LOCK TABLES `himalay_tblfe_locations` WRITE;
/*!40000 ALTER TABLE `himalay_tblfe_locations` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfe_locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfe_log_assets`
--

DROP TABLE IF EXISTS `himalay_tblfe_log_assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfe_log_assets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_id` int(11) DEFAULT NULL,
  `action` varchar(200) DEFAULT NULL,
  `item_id` int(11) DEFAULT NULL,
  `target` varchar(200) DEFAULT NULL,
  `changed` varchar(200) DEFAULT NULL,
  `to` varchar(20) DEFAULT NULL,
  `to_id` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfe_log_assets`
--

LOCK TABLES `himalay_tblfe_log_assets` WRITE;
/*!40000 ALTER TABLE `himalay_tblfe_log_assets` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfe_log_assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfe_model_predefined_kits`
--

DROP TABLE IF EXISTS `himalay_tblfe_model_predefined_kits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfe_model_predefined_kits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `model_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfe_model_predefined_kits`
--

LOCK TABLES `himalay_tblfe_model_predefined_kits` WRITE;
/*!40000 ALTER TABLE `himalay_tblfe_model_predefined_kits` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfe_model_predefined_kits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfe_models`
--

DROP TABLE IF EXISTS `himalay_tblfe_models`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfe_models` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `model_name` varchar(200) NOT NULL,
  `manufacturer` int(11) DEFAULT NULL,
  `category` int(11) DEFAULT NULL,
  `model_no` varchar(200) DEFAULT NULL,
  `depreciation` int(11) DEFAULT NULL,
  `eol` int(11) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `custom_field` text DEFAULT NULL,
  `may_request` bit(1) NOT NULL DEFAULT b'0',
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  `fieldset_id` int(11) DEFAULT NULL,
  `creator_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfe_models`
--

LOCK TABLES `himalay_tblfe_models` WRITE;
/*!40000 ALTER TABLE `himalay_tblfe_models` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfe_models` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfe_omni_shipments`
--

DROP TABLE IF EXISTS `himalay_tblfe_omni_shipments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfe_omni_shipments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cart_id` int(11) DEFAULT NULL,
  `goods_delivery_id` int(11) DEFAULT NULL,
  `shipment_hash` varchar(32) DEFAULT NULL,
  `order_id` int(11) DEFAULT 0,
  `shipment_number` varchar(100) DEFAULT NULL,
  `planned_shipping_date` datetime DEFAULT NULL,
  `shipment_status` varchar(50) DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfe_omni_shipments`
--

LOCK TABLES `himalay_tblfe_omni_shipments` WRITE;
/*!40000 ALTER TABLE `himalay_tblfe_omni_shipments` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfe_omni_shipments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfe_packing_list_details`
--

DROP TABLE IF EXISTS `himalay_tblfe_packing_list_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfe_packing_list_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `packing_list_id` int(11) NOT NULL,
  `delivery_detail_id` int(11) DEFAULT NULL,
  `commodity_code` int(11) DEFAULT NULL,
  `commodity_name` text DEFAULT NULL,
  `quantity` decimal(15,2) DEFAULT 0.00,
  `unit_id` int(11) DEFAULT NULL,
  `unit_price` decimal(15,2) DEFAULT 0.00,
  `sub_total` decimal(15,2) DEFAULT 0.00,
  `tax_id` text DEFAULT NULL,
  `tax_rate` text DEFAULT NULL,
  `tax_name` text DEFAULT NULL,
  `total_amount` decimal(15,2) DEFAULT 0.00,
  `discount` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `total_after_discount` decimal(15,2) DEFAULT 0.00,
  `serial_number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfe_packing_list_details`
--

LOCK TABLES `himalay_tblfe_packing_list_details` WRITE;
/*!40000 ALTER TABLE `himalay_tblfe_packing_list_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfe_packing_list_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfe_packing_lists`
--

DROP TABLE IF EXISTS `himalay_tblfe_packing_lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfe_packing_lists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `delivery_note_id` int(11) DEFAULT NULL,
  `packing_list_number` varchar(100) DEFAULT NULL,
  `packing_list_name` varchar(200) DEFAULT NULL,
  `width` decimal(15,2) DEFAULT 0.00,
  `height` decimal(15,2) DEFAULT 0.00,
  `lenght` decimal(15,2) DEFAULT 0.00,
  `weight` decimal(15,2) DEFAULT 0.00,
  `volume` decimal(15,2) DEFAULT 0.00,
  `clientid` int(11) DEFAULT NULL,
  `subtotal` decimal(15,2) DEFAULT 0.00,
  `total_amount` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `additional_discount` decimal(15,2) DEFAULT 0.00,
  `total_after_discount` decimal(15,2) DEFAULT 0.00,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT NULL,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT NULL,
  `client_note` text DEFAULT NULL,
  `admin_note` text DEFAULT NULL,
  `approval` int(11) DEFAULT 0,
  `datecreated` datetime DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `type_of_packing_list` varchar(100) DEFAULT 'total',
  `delivery_status` varchar(100) DEFAULT 'wh_ready_to_deliver',
  `shipping_fee` decimal(15,2) DEFAULT 0.00,
  `sales_order_reference` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfe_packing_lists`
--

LOCK TABLES `himalay_tblfe_packing_lists` WRITE;
/*!40000 ALTER TABLE `himalay_tblfe_packing_lists` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfe_packing_lists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfe_refunds`
--

DROP TABLE IF EXISTS `himalay_tblfe_refunds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfe_refunds` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(11) DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `refunded_on` date DEFAULT NULL,
  `payment_mode` varchar(40) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `amount` decimal(15,2) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfe_refunds`
--

LOCK TABLES `himalay_tblfe_refunds` WRITE;
/*!40000 ALTER TABLE `himalay_tblfe_refunds` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfe_refunds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfe_seats`
--

DROP TABLE IF EXISTS `himalay_tblfe_seats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfe_seats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `seat_name` varchar(200) DEFAULT NULL,
  `to` varchar(20) DEFAULT NULL,
  `to_id` int(11) DEFAULT NULL,
  `license_id` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  `warehouse_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfe_seats`
--

LOCK TABLES `himalay_tblfe_seats` WRITE;
/*!40000 ALTER TABLE `himalay_tblfe_seats` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfe_seats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfe_sign_documents`
--

DROP TABLE IF EXISTS `himalay_tblfe_sign_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfe_sign_documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `checkin_out_id` text DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `check_to_staff` int(11) DEFAULT NULL,
  `reference` varchar(30) DEFAULT NULL,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfe_sign_documents`
--

LOCK TABLES `himalay_tblfe_sign_documents` WRITE;
/*!40000 ALTER TABLE `himalay_tblfe_sign_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfe_sign_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfe_signers`
--

DROP TABLE IF EXISTS `himalay_tblfe_signers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfe_signers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sign_document_id` int(11) DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `ip_address` varchar(100) DEFAULT NULL,
  `date_of_signing` datetime DEFAULT NULL,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  `firstname` varchar(50) DEFAULT NULL,
  `lastname` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfe_signers`
--

LOCK TABLES `himalay_tblfe_signers` WRITE;
/*!40000 ALTER TABLE `himalay_tblfe_signers` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfe_signers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfe_status_labels`
--

DROP TABLE IF EXISTS `himalay_tblfe_status_labels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfe_status_labels` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `status_type` varchar(30) NOT NULL,
  `chart_color` varchar(30) NOT NULL,
  `note` text DEFAULT NULL,
  `show_in_side_nav` bit(1) NOT NULL DEFAULT b'0',
  `default_label` bit(1) NOT NULL DEFAULT b'0',
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  `creator_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfe_status_labels`
--

LOCK TABLES `himalay_tblfe_status_labels` WRITE;
/*!40000 ALTER TABLE `himalay_tblfe_status_labels` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfe_status_labels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfe_suppliers`
--

DROP TABLE IF EXISTS `himalay_tblfe_suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfe_suppliers` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `supplier_name` varchar(200) NOT NULL,
  `address` text DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL,
  `zip` varchar(50) DEFAULT NULL,
  `contact_name` varchar(200) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `fax` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `url` text DEFAULT NULL,
  `note` text DEFAULT NULL,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  `creator_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfe_suppliers`
--

LOCK TABLES `himalay_tblfe_suppliers` WRITE;
/*!40000 ALTER TABLE `himalay_tblfe_suppliers` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfe_suppliers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfe_ticket_action_post_internal_notes`
--

DROP TABLE IF EXISTS `himalay_tblfe_ticket_action_post_internal_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfe_ticket_action_post_internal_notes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_id` int(11) DEFAULT NULL,
  `note_title` text DEFAULT NULL,
  `note_details` text DEFAULT NULL,
  `ticket_status` text DEFAULT NULL COMMENT 'select workflow progess Resolved Closed',
  `resolution` text DEFAULT NULL COMMENT 'Set Reply as Resolution if you want the message entered fix issue',
  `created_type` varchar(20) DEFAULT 'staff',
  `datecreated` datetime DEFAULT NULL,
  `dateupdated` datetime DEFAULT NULL,
  `staffid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfe_ticket_action_post_internal_notes`
--

LOCK TABLES `himalay_tblfe_ticket_action_post_internal_notes` WRITE;
/*!40000 ALTER TABLE `himalay_tblfe_ticket_action_post_internal_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfe_ticket_action_post_internal_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfe_ticket_timeline_logs`
--

DROP TABLE IF EXISTS `himalay_tblfe_ticket_timeline_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfe_ticket_timeline_logs` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(100) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `additional_data` text DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `staffid` int(11) DEFAULT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `from_date` datetime DEFAULT NULL,
  `to_date` datetime DEFAULT NULL,
  `duration` decimal(15,2) DEFAULT 0.00,
  `created_type` varchar(200) DEFAULT 'System',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfe_ticket_timeline_logs`
--

LOCK TABLES `himalay_tblfe_ticket_timeline_logs` WRITE;
/*!40000 ALTER TABLE `himalay_tblfe_ticket_timeline_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfe_ticket_timeline_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfe_tickets`
--

DROP TABLE IF EXISTS `himalay_tblfe_tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfe_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_id` int(11) DEFAULT NULL,
  `created_type` varchar(20) DEFAULT 'staff',
  `client_id` int(11) DEFAULT NULL,
  `cart_id` int(11) DEFAULT NULL,
  `asset_id` int(11) DEFAULT NULL,
  `ticket_source` text DEFAULT NULL,
  `assigned_id` int(11) DEFAULT NULL,
  `time_spent` decimal(15,2) DEFAULT NULL,
  `due_date` datetime DEFAULT NULL,
  `code` text DEFAULT NULL,
  `ticket_subject` text DEFAULT NULL,
  `issue_summary` text DEFAULT NULL,
  `priority_level` text DEFAULT NULL,
  `ticket_type` text DEFAULT NULL,
  `internal_note` text DEFAULT NULL,
  `last_message_time` datetime DEFAULT NULL,
  `last_response_time` datetime DEFAULT NULL,
  `first_reply_time` datetime DEFAULT NULL,
  `last_update_time` datetime DEFAULT NULL,
  `resolution` longtext DEFAULT NULL,
  `status` text DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `dateupdated` datetime DEFAULT NULL,
  `staffid` int(11) DEFAULT NULL,
  `model_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfe_tickets`
--

LOCK TABLES `himalay_tblfe_tickets` WRITE;
/*!40000 ALTER TABLE `himalay_tblfe_tickets` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfe_tickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfe_warehouse`
--

DROP TABLE IF EXISTS `himalay_tblfe_warehouse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfe_warehouse` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(100) DEFAULT NULL,
  `name` text DEFAULT NULL,
  `address` text DEFAULT NULL,
  `city` text DEFAULT NULL,
  `state` text DEFAULT NULL,
  `zip_code` text DEFAULT NULL,
  `country` text DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  `display` int(1) DEFAULT NULL COMMENT 'display 1: display (yes)  0: not displayed (no)',
  `note` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfe_warehouse`
--

LOCK TABLES `himalay_tblfe_warehouse` WRITE;
/*!40000 ALTER TABLE `himalay_tblfe_warehouse` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfe_warehouse` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfiles`
--

DROP TABLE IF EXISTS `himalay_tblfiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) NOT NULL,
  `file_name` varchar(191) NOT NULL,
  `filetype` varchar(40) DEFAULT NULL,
  `visible_to_customer` int(11) NOT NULL DEFAULT 0,
  `attachment_key` varchar(32) DEFAULT NULL,
  `external` varchar(40) DEFAULT NULL,
  `external_link` mediumtext DEFAULT NULL,
  `thumbnail_link` mediumtext DEFAULT NULL COMMENT 'For external usage',
  `staffid` int(11) NOT NULL,
  `contact_id` int(11) DEFAULT 0,
  `task_comment_id` int(11) NOT NULL DEFAULT 0,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfiles`
--

LOCK TABLES `himalay_tblfiles` WRITE;
/*!40000 ALTER TABLE `himalay_tblfiles` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfilter_defaults`
--

DROP TABLE IF EXISTS `himalay_tblfilter_defaults`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfilter_defaults` (
  `filter_id` int(10) unsigned NOT NULL,
  `staff_id` int(11) NOT NULL,
  `identifier` varchar(191) NOT NULL,
  `view` varchar(191) NOT NULL,
  KEY `filter_id` (`filter_id`),
  KEY `himalay_staff_id` (`staff_id`),
  CONSTRAINT `himalay_tblfilter_defaults_ibfk_1` FOREIGN KEY (`filter_id`) REFERENCES `himalay_tblfilters` (`id`) ON DELETE CASCADE,
  CONSTRAINT `himalay_tblfilter_defaults_ibfk_2` FOREIGN KEY (`staff_id`) REFERENCES `himalay_tblstaff` (`staffid`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfilter_defaults`
--

LOCK TABLES `himalay_tblfilter_defaults` WRITE;
/*!40000 ALTER TABLE `himalay_tblfilter_defaults` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfilter_defaults` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfilters`
--

DROP TABLE IF EXISTS `himalay_tblfilters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfilters` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `builder` mediumtext NOT NULL,
  `staff_id` int(10) unsigned NOT NULL,
  `identifier` varchar(191) NOT NULL,
  `is_shared` tinyint(3) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfilters`
--

LOCK TABLES `himalay_tblfilters` WRITE;
/*!40000 ALTER TABLE `himalay_tblfilters` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfilters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfleet_benefit_and_penalty`
--

DROP TABLE IF EXISTS `himalay_tblfleet_benefit_and_penalty`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfleet_benefit_and_penalty` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` text DEFAULT NULL,
  `criteria_id` int(11) DEFAULT NULL,
  `driver_id` int(11) DEFAULT NULL,
  `type` text DEFAULT NULL,
  `date` date DEFAULT NULL,
  `benefit_formality` text DEFAULT NULL,
  `reward` decimal(15,2) DEFAULT NULL,
  `penalty_formality` text DEFAULT NULL,
  `amount_of_damage` decimal(15,2) DEFAULT NULL,
  `amount_of_compensation` decimal(15,2) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfleet_benefit_and_penalty`
--

LOCK TABLES `himalay_tblfleet_benefit_and_penalty` WRITE;
/*!40000 ALTER TABLE `himalay_tblfleet_benefit_and_penalty` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfleet_benefit_and_penalty` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfleet_bookings`
--

DROP TABLE IF EXISTS `himalay_tblfleet_bookings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfleet_bookings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` text NOT NULL,
  `contactid` int(11) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  `approved` int(11) NOT NULL DEFAULT 0,
  `status` varchar(45) NOT NULL DEFAULT 'new',
  `delivery_date` date DEFAULT NULL,
  `phone` text NOT NULL,
  `receipt_address` text NOT NULL,
  `delivery_address` text NOT NULL,
  `note` text NOT NULL,
  `invoice_id` int(11) NOT NULL DEFAULT 0,
  `admin_note` text DEFAULT NULL,
  `number` text DEFAULT NULL,
  `amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `invoice_hash` text DEFAULT NULL,
  `rating` int(11) NOT NULL DEFAULT 0,
  `comments` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfleet_bookings`
--

LOCK TABLES `himalay_tblfleet_bookings` WRITE;
/*!40000 ALTER TABLE `himalay_tblfleet_bookings` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfleet_bookings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfleet_criterias`
--

DROP TABLE IF EXISTS `himalay_tblfleet_criterias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfleet_criterias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `description` text DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfleet_criterias`
--

LOCK TABLES `himalay_tblfleet_criterias` WRITE;
/*!40000 ALTER TABLE `himalay_tblfleet_criterias` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfleet_criterias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfleet_driver_documents`
--

DROP TABLE IF EXISTS `himalay_tblfleet_driver_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfleet_driver_documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `driver_id` int(11) NOT NULL DEFAULT 0,
  `subject` text NOT NULL,
  `description` text DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `type` varchar(45) NOT NULL DEFAULT 'driver',
  `vehicle_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfleet_driver_documents`
--

LOCK TABLES `himalay_tblfleet_driver_documents` WRITE;
/*!40000 ALTER TABLE `himalay_tblfleet_driver_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfleet_driver_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfleet_events`
--

DROP TABLE IF EXISTS `himalay_tblfleet_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfleet_events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` text NOT NULL,
  `vehicle_id` int(11) DEFAULT NULL,
  `driver_id` int(11) DEFAULT NULL,
  `event_type` text NOT NULL,
  `event_time` datetime NOT NULL,
  `description` text DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfleet_events`
--

LOCK TABLES `himalay_tblfleet_events` WRITE;
/*!40000 ALTER TABLE `himalay_tblfleet_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfleet_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfleet_fuel_history`
--

DROP TABLE IF EXISTS `himalay_tblfleet_fuel_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfleet_fuel_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vehicle_id` int(11) DEFAULT NULL,
  `vendor_id` int(11) DEFAULT NULL,
  `fuel_time` datetime NOT NULL,
  `odometer` int(11) DEFAULT NULL,
  `gallons` text DEFAULT NULL,
  `price` decimal(15,2) DEFAULT NULL,
  `fuel_type` text DEFAULT NULL,
  `reference` text DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfleet_fuel_history`
--

LOCK TABLES `himalay_tblfleet_fuel_history` WRITE;
/*!40000 ALTER TABLE `himalay_tblfleet_fuel_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfleet_fuel_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfleet_garages`
--

DROP TABLE IF EXISTS `himalay_tblfleet_garages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfleet_garages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `country` int(11) NOT NULL DEFAULT 0,
  `city` varchar(100) DEFAULT NULL,
  `zip` varchar(15) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfleet_garages`
--

LOCK TABLES `himalay_tblfleet_garages` WRITE;
/*!40000 ALTER TABLE `himalay_tblfleet_garages` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfleet_garages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfleet_inspection_forms`
--

DROP TABLE IF EXISTS `himalay_tblfleet_inspection_forms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfleet_inspection_forms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `color` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `slug` text DEFAULT NULL,
  `hash` text DEFAULT NULL,
  `recurring` int(11) NOT NULL DEFAULT 0,
  `recurring_type` varchar(10) DEFAULT NULL,
  `custom_recurring` tinyint(1) NOT NULL DEFAULT 0,
  `cycles` int(11) NOT NULL DEFAULT 0,
  `total_cycles` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfleet_inspection_forms`
--

LOCK TABLES `himalay_tblfleet_inspection_forms` WRITE;
/*!40000 ALTER TABLE `himalay_tblfleet_inspection_forms` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfleet_inspection_forms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfleet_inspection_question_box`
--

DROP TABLE IF EXISTS `himalay_tblfleet_inspection_question_box`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfleet_inspection_question_box` (
  `boxid` int(11) NOT NULL AUTO_INCREMENT,
  `boxtype` varchar(10) NOT NULL,
  `questionid` int(11) NOT NULL,
  PRIMARY KEY (`boxid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfleet_inspection_question_box`
--

LOCK TABLES `himalay_tblfleet_inspection_question_box` WRITE;
/*!40000 ALTER TABLE `himalay_tblfleet_inspection_question_box` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfleet_inspection_question_box` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfleet_inspection_question_box_description`
--

DROP TABLE IF EXISTS `himalay_tblfleet_inspection_question_box_description`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfleet_inspection_question_box_description` (
  `questionboxdescriptionid` int(11) NOT NULL AUTO_INCREMENT,
  `description` mediumtext NOT NULL,
  `boxid` mediumtext NOT NULL,
  `questionid` int(11) NOT NULL,
  `is_fail` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`questionboxdescriptionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfleet_inspection_question_box_description`
--

LOCK TABLES `himalay_tblfleet_inspection_question_box_description` WRITE;
/*!40000 ALTER TABLE `himalay_tblfleet_inspection_question_box_description` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfleet_inspection_question_box_description` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfleet_inspection_question_forms`
--

DROP TABLE IF EXISTS `himalay_tblfleet_inspection_question_forms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfleet_inspection_question_forms` (
  `questionid` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) DEFAULT NULL,
  `question` mediumtext NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT 0,
  `question_order` int(11) NOT NULL,
  PRIMARY KEY (`questionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfleet_inspection_question_forms`
--

LOCK TABLES `himalay_tblfleet_inspection_question_forms` WRITE;
/*!40000 ALTER TABLE `himalay_tblfleet_inspection_question_forms` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfleet_inspection_question_forms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfleet_inspection_results`
--

DROP TABLE IF EXISTS `himalay_tblfleet_inspection_results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfleet_inspection_results` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `inspection_id` int(11) DEFAULT NULL,
  `boxid` int(11) DEFAULT NULL,
  `boxdescriptionid` int(11) DEFAULT NULL,
  `questionid` int(11) DEFAULT NULL,
  `answer` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfleet_inspection_results`
--

LOCK TABLES `himalay_tblfleet_inspection_results` WRITE;
/*!40000 ALTER TABLE `himalay_tblfleet_inspection_results` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfleet_inspection_results` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfleet_inspections`
--

DROP TABLE IF EXISTS `himalay_tblfleet_inspections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfleet_inspections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vehicle_id` int(11) DEFAULT NULL,
  `inspection_form_id` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `recurring` int(11) NOT NULL DEFAULT 0,
  `recurring_type` varchar(10) DEFAULT NULL,
  `custom_recurring` tinyint(1) NOT NULL DEFAULT 0,
  `cycles` int(11) NOT NULL DEFAULT 0,
  `total_cycles` int(11) NOT NULL DEFAULT 0,
  `is_recurring_from` int(11) NOT NULL DEFAULT 0,
  `last_recurring_date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfleet_inspections`
--

LOCK TABLES `himalay_tblfleet_inspections` WRITE;
/*!40000 ALTER TABLE `himalay_tblfleet_inspections` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfleet_inspections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfleet_insurance_categories`
--

DROP TABLE IF EXISTS `himalay_tblfleet_insurance_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfleet_insurance_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `description` text DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfleet_insurance_categories`
--

LOCK TABLES `himalay_tblfleet_insurance_categories` WRITE;
/*!40000 ALTER TABLE `himalay_tblfleet_insurance_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfleet_insurance_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfleet_insurance_company`
--

DROP TABLE IF EXISTS `himalay_tblfleet_insurance_company`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfleet_insurance_company` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `description` text DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfleet_insurance_company`
--

LOCK TABLES `himalay_tblfleet_insurance_company` WRITE;
/*!40000 ALTER TABLE `himalay_tblfleet_insurance_company` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfleet_insurance_company` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfleet_insurance_status`
--

DROP TABLE IF EXISTS `himalay_tblfleet_insurance_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfleet_insurance_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `description` text DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfleet_insurance_status`
--

LOCK TABLES `himalay_tblfleet_insurance_status` WRITE;
/*!40000 ALTER TABLE `himalay_tblfleet_insurance_status` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfleet_insurance_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfleet_insurance_types`
--

DROP TABLE IF EXISTS `himalay_tblfleet_insurance_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfleet_insurance_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `description` text DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfleet_insurance_types`
--

LOCK TABLES `himalay_tblfleet_insurance_types` WRITE;
/*!40000 ALTER TABLE `himalay_tblfleet_insurance_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfleet_insurance_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfleet_insurances`
--

DROP TABLE IF EXISTS `himalay_tblfleet_insurances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfleet_insurances` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vehicle_id` int(11) DEFAULT NULL,
  `insurance_category_id` int(11) DEFAULT NULL,
  `insurance_type_id` int(11) DEFAULT NULL,
  `name` text DEFAULT NULL,
  `status` text DEFAULT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `description` text DEFAULT NULL,
  `amount` decimal(15,2) NOT NULL,
  `insurance_company_id` int(11) NOT NULL DEFAULT 0,
  `insurance_status_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfleet_insurances`
--

LOCK TABLES `himalay_tblfleet_insurances` WRITE;
/*!40000 ALTER TABLE `himalay_tblfleet_insurances` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfleet_insurances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfleet_logbooks`
--

DROP TABLE IF EXISTS `himalay_tblfleet_logbooks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfleet_logbooks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vehicle_id` int(11) DEFAULT NULL,
  `driver_id` int(11) DEFAULT NULL,
  `booking_id` int(11) DEFAULT NULL,
  `odometer` int(11) DEFAULT NULL,
  `status` varchar(45) NOT NULL DEFAULT 'new',
  `date` date DEFAULT NULL,
  `description` text DEFAULT NULL,
  `name` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfleet_logbooks`
--

LOCK TABLES `himalay_tblfleet_logbooks` WRITE;
/*!40000 ALTER TABLE `himalay_tblfleet_logbooks` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfleet_logbooks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfleet_maintenance_teams`
--

DROP TABLE IF EXISTS `himalay_tblfleet_maintenance_teams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfleet_maintenance_teams` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staffid` int(11) DEFAULT NULL,
  `garage_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfleet_maintenance_teams`
--

LOCK TABLES `himalay_tblfleet_maintenance_teams` WRITE;
/*!40000 ALTER TABLE `himalay_tblfleet_maintenance_teams` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfleet_maintenance_teams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfleet_maintenances`
--

DROP TABLE IF EXISTS `himalay_tblfleet_maintenances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfleet_maintenances` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vehicle_id` int(11) DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `maintenance_type` varchar(30) DEFAULT NULL,
  `title` varchar(250) DEFAULT NULL,
  `warranty_improvement` int(11) NOT NULL DEFAULT 0,
  `start_date` date DEFAULT NULL,
  `completion_date` date DEFAULT NULL,
  `cost` decimal(15,2) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  `garage_id` int(11) NOT NULL DEFAULT 0,
  `parts` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfleet_maintenances`
--

LOCK TABLES `himalay_tblfleet_maintenances` WRITE;
/*!40000 ALTER TABLE `himalay_tblfleet_maintenances` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfleet_maintenances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfleet_part_groups`
--

DROP TABLE IF EXISTS `himalay_tblfleet_part_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfleet_part_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `description` text DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfleet_part_groups`
--

LOCK TABLES `himalay_tblfleet_part_groups` WRITE;
/*!40000 ALTER TABLE `himalay_tblfleet_part_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfleet_part_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfleet_part_histories`
--

DROP TABLE IF EXISTS `himalay_tblfleet_part_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfleet_part_histories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `part_id` int(11) NOT NULL,
  `type` text NOT NULL,
  `vehicle_id` int(11) DEFAULT NULL,
  `driver_id` int(11) DEFAULT NULL,
  `start_time` text DEFAULT NULL,
  `end_time` text DEFAULT NULL,
  `start_by` int(11) DEFAULT NULL,
  `end_by` int(11) DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfleet_part_histories`
--

LOCK TABLES `himalay_tblfleet_part_histories` WRITE;
/*!40000 ALTER TABLE `himalay_tblfleet_part_histories` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfleet_part_histories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfleet_part_types`
--

DROP TABLE IF EXISTS `himalay_tblfleet_part_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfleet_part_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `description` text DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfleet_part_types`
--

LOCK TABLES `himalay_tblfleet_part_types` WRITE;
/*!40000 ALTER TABLE `himalay_tblfleet_part_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfleet_part_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfleet_parts`
--

DROP TABLE IF EXISTS `himalay_tblfleet_parts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfleet_parts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `part_type_id` int(11) DEFAULT NULL,
  `brand` text DEFAULT NULL,
  `model` text DEFAULT NULL,
  `serial_number` text DEFAULT NULL,
  `vehicle_id` int(11) NOT NULL DEFAULT 0,
  `driver_id` int(11) NOT NULL DEFAULT 0,
  `part_group_id` int(11) DEFAULT NULL,
  `status` text DEFAULT NULL,
  `purchase_vendor` int(11) DEFAULT NULL,
  `purchase_date` date DEFAULT NULL,
  `purchase_price` decimal(15,2) DEFAULT NULL,
  `warranty_expiration_date` date DEFAULT NULL,
  `purchase_comments` text DEFAULT NULL,
  `in_service_date` date DEFAULT NULL,
  `estimated_service_life_in_months` int(11) DEFAULT NULL,
  `estimated_resale_value` decimal(15,2) DEFAULT NULL,
  `out_of_service_date` date DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfleet_parts`
--

LOCK TABLES `himalay_tblfleet_parts` WRITE;
/*!40000 ALTER TABLE `himalay_tblfleet_parts` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfleet_parts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfleet_time_cards`
--

DROP TABLE IF EXISTS `himalay_tblfleet_time_cards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfleet_time_cards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `logbook_id` int(11) DEFAULT NULL,
  `driver_id` int(11) DEFAULT NULL,
  `start_time` text NOT NULL,
  `end_time` text NOT NULL,
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfleet_time_cards`
--

LOCK TABLES `himalay_tblfleet_time_cards` WRITE;
/*!40000 ALTER TABLE `himalay_tblfleet_time_cards` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfleet_time_cards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfleet_vehicle_assignments`
--

DROP TABLE IF EXISTS `himalay_tblfleet_vehicle_assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfleet_vehicle_assignments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `driver_id` int(11) NOT NULL,
  `vehicle_id` int(11) NOT NULL,
  `start_time` datetime DEFAULT NULL,
  `starting_odometer` float DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `ending_odometer` float DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfleet_vehicle_assignments`
--

LOCK TABLES `himalay_tblfleet_vehicle_assignments` WRITE;
/*!40000 ALTER TABLE `himalay_tblfleet_vehicle_assignments` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfleet_vehicle_assignments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfleet_vehicle_groups`
--

DROP TABLE IF EXISTS `himalay_tblfleet_vehicle_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfleet_vehicle_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `description` text DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfleet_vehicle_groups`
--

LOCK TABLES `himalay_tblfleet_vehicle_groups` WRITE;
/*!40000 ALTER TABLE `himalay_tblfleet_vehicle_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfleet_vehicle_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfleet_vehicle_histories`
--

DROP TABLE IF EXISTS `himalay_tblfleet_vehicle_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfleet_vehicle_histories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vehicle_id` int(11) NOT NULL,
  `type` text NOT NULL,
  `from_value` text DEFAULT NULL,
  `to_value` text DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfleet_vehicle_histories`
--

LOCK TABLES `himalay_tblfleet_vehicle_histories` WRITE;
/*!40000 ALTER TABLE `himalay_tblfleet_vehicle_histories` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfleet_vehicle_histories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfleet_vehicle_types`
--

DROP TABLE IF EXISTS `himalay_tblfleet_vehicle_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfleet_vehicle_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `description` text DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfleet_vehicle_types`
--

LOCK TABLES `himalay_tblfleet_vehicle_types` WRITE;
/*!40000 ALTER TABLE `himalay_tblfleet_vehicle_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfleet_vehicle_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfleet_vehicles`
--

DROP TABLE IF EXISTS `himalay_tblfleet_vehicles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfleet_vehicles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `vehicle_type_id` int(11) DEFAULT NULL,
  `vehicle_group_id` int(11) DEFAULT NULL,
  `status` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `model` text DEFAULT NULL,
  `year` text DEFAULT NULL,
  `width` text DEFAULT NULL,
  `height` text DEFAULT NULL,
  `length` text DEFAULT NULL,
  `interior_volume` text DEFAULT NULL,
  `passenger_volume` text DEFAULT NULL,
  `cargo_volume` text DEFAULT NULL,
  `ground_clearance` text DEFAULT NULL,
  `bed_length` text DEFAULT NULL,
  `curb_weight` text DEFAULT NULL,
  `gross_vehicle_weight_rating` text DEFAULT NULL,
  `towing_capacity` text DEFAULT NULL,
  `max_payload` text DEFAULT NULL,
  `epa_city` text DEFAULT NULL,
  `epa_highway` text DEFAULT NULL,
  `epa_combined` text DEFAULT NULL,
  `oil_capacity` text DEFAULT NULL,
  `in_service_date` date DEFAULT NULL,
  `in_service_odometer` int(11) DEFAULT NULL,
  `estimated_service_life_in_months` text DEFAULT NULL,
  `estimated_service_life_in_meter` text DEFAULT NULL,
  `estimated_resale_value` text DEFAULT NULL,
  `out_of_service_date` date DEFAULT NULL,
  `out_of_service_odometer` int(11) DEFAULT NULL,
  `vin` text DEFAULT NULL,
  `license_plate` text DEFAULT NULL,
  `make` text DEFAULT NULL,
  `trim` text DEFAULT NULL,
  `registration_state` text DEFAULT NULL,
  `ownership` text DEFAULT NULL,
  `color` text DEFAULT NULL,
  `body_type` text DEFAULT NULL,
  `body_subtype` text DEFAULT NULL,
  `msrp` text DEFAULT NULL,
  `purchase_vendor` int(11) DEFAULT NULL,
  `purchase_date` date DEFAULT NULL,
  `purchase_price` decimal(15,2) DEFAULT NULL,
  `odometer` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `expiration_date` date DEFAULT NULL,
  `max_meter_value` text DEFAULT NULL,
  `engine_summary` text DEFAULT NULL,
  `engine_brand` text DEFAULT NULL,
  `aspiration` text DEFAULT NULL,
  `block_type` text DEFAULT NULL,
  `bore` text DEFAULT NULL,
  `cam_type` text DEFAULT NULL,
  `compression` text DEFAULT NULL,
  `cylinders` text DEFAULT NULL,
  `displacement` text DEFAULT NULL,
  `fuel_induction` text DEFAULT NULL,
  `max_hp` text DEFAULT NULL,
  `max_torque` text DEFAULT NULL,
  `redline_rpm` text DEFAULT NULL,
  `stroke` text DEFAULT NULL,
  `valves` text DEFAULT NULL,
  `transmission_summary` text DEFAULT NULL,
  `transmission_brand` text DEFAULT NULL,
  `transmission_type` text DEFAULT NULL,
  `transmission_gears` text DEFAULT NULL,
  `drive_type` text DEFAULT NULL,
  `brake_system` text DEFAULT NULL,
  `front_track_width` text DEFAULT NULL,
  `rear_track_width` text DEFAULT NULL,
  `wheelbase` text DEFAULT NULL,
  `front_wheel_diameter` text DEFAULT NULL,
  `rear_wheel_diameter` text DEFAULT NULL,
  `rear_axle` text DEFAULT NULL,
  `front_tire_type` text DEFAULT NULL,
  `front_tire_psi` text DEFAULT NULL,
  `rear_tire_type` text DEFAULT NULL,
  `rear_tire_psi` text DEFAULT NULL,
  `fuel_type` text DEFAULT NULL,
  `fuel_quality` text DEFAULT NULL,
  `fuel_tank_1_capacity` text DEFAULT NULL,
  `fuel_tank_2_capacity` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfleet_vehicles`
--

LOCK TABLES `himalay_tblfleet_vehicles` WRITE;
/*!40000 ALTER TABLE `himalay_tblfleet_vehicles` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfleet_vehicles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfleet_work_order_details`
--

DROP TABLE IF EXISTS `himalay_tblfleet_work_order_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfleet_work_order_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `work_order_id` int(11) DEFAULT NULL,
  `part_id` int(11) DEFAULT NULL,
  `item_name` text DEFAULT NULL,
  `qty` int(11) DEFAULT NULL,
  `price` decimal(15,2) DEFAULT NULL,
  `total` decimal(15,2) DEFAULT NULL,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfleet_work_order_details`
--

LOCK TABLES `himalay_tblfleet_work_order_details` WRITE;
/*!40000 ALTER TABLE `himalay_tblfleet_work_order_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfleet_work_order_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfleet_work_orders`
--

DROP TABLE IF EXISTS `himalay_tblfleet_work_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfleet_work_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` text NOT NULL,
  `number` text DEFAULT NULL,
  `vehicle_id` int(11) DEFAULT NULL,
  `driver_id` int(11) DEFAULT NULL,
  `vendor_id` int(11) DEFAULT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `purchase_order_id` int(11) DEFAULT NULL,
  `status` varchar(45) NOT NULL DEFAULT 'open',
  `issue_date` date DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `complete_date` date DEFAULT NULL,
  `odometer_in` int(11) DEFAULT NULL,
  `odometer_out` int(11) DEFAULT NULL,
  `total` decimal(15,2) DEFAULT NULL,
  `work_requested` text DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `expense_id` int(11) NOT NULL DEFAULT 0,
  `parts` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfleet_work_orders`
--

LOCK TABLES `himalay_tblfleet_work_orders` WRITE;
/*!40000 ALTER TABLE `himalay_tblfleet_work_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfleet_work_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblflexcategories`
--

DROP TABLE IF EXISTS `himalay_tblflexcategories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblflexcategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` mediumtext NOT NULL,
  `slug` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblflexcategories`
--

LOCK TABLES `himalay_tblflexcategories` WRITE;
/*!40000 ALTER TABLE `himalay_tblflexcategories` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblflexcategories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblflexemaillists`
--

DROP TABLE IF EXISTS `himalay_tblflexemaillists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblflexemaillists` (
  `listid` int(11) NOT NULL AUTO_INCREMENT,
  `name` mediumtext NOT NULL,
  `creator` varchar(100) NOT NULL,
  `datecreated` datetime NOT NULL,
  PRIMARY KEY (`listid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblflexemaillists`
--

LOCK TABLES `himalay_tblflexemaillists` WRITE;
/*!40000 ALTER TABLE `himalay_tblflexemaillists` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblflexemaillists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblflexevents`
--

DROP TABLE IF EXISTS `himalay_tblflexevents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblflexevents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` mediumtext NOT NULL,
  `slug` mediumtext NOT NULL,
  `description` text DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `start_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `create_date` datetime NOT NULL,
  `auto_sync_attendees` tinyint(1) NOT NULL DEFAULT 0,
  `auto_add_to_calendar` tinyint(1) NOT NULL DEFAULT 0,
  `category_id` int(11) NOT NULL,
  `summary` mediumtext DEFAULT NULL,
  `type` mediumtext NOT NULL,
  `location` mediumtext DEFAULT NULL,
  `event_link` mediumtext DEFAULT NULL,
  `password` mediumtext DEFAULT NULL,
  `longitude` double(15,12) DEFAULT NULL,
  `latitude` double(15,12) DEFAULT NULL,
  `privacy` mediumtext NOT NULL,
  `created_by` int(11) NOT NULL,
  `tags` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `himalay_category_event_fk` (`category_id`),
  CONSTRAINT `himalay_category_event_fk` FOREIGN KEY (`category_id`) REFERENCES `himalay_tblflexcategories` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblflexevents`
--

LOCK TABLES `himalay_tblflexevents` WRITE;
/*!40000 ALTER TABLE `himalay_tblflexevents` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblflexevents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblflexibackup`
--

DROP TABLE IF EXISTS `himalay_tblflexibackup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblflexibackup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `backup_name` varchar(255) NOT NULL,
  `backup_type` varchar(255) NOT NULL,
  `backup_data` varchar(255) NOT NULL,
  `datecreated` datetime NOT NULL,
  `uploaded_to_remote` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblflexibackup`
--

LOCK TABLES `himalay_tblflexibackup` WRITE;
/*!40000 ALTER TABLE `himalay_tblflexibackup` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblflexibackup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfleximages`
--

DROP TABLE IF EXISTS `himalay_tblfleximages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfleximages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event_id` int(11) NOT NULL,
  `file_name` mediumtext NOT NULL,
  `original_file_name` mediumtext NOT NULL,
  `filetype` mediumtext NOT NULL,
  `dateadded` datetime NOT NULL,
  `uploaded_by` int(11) NOT NULL,
  `subject` mediumtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `himalay_event_image_fk` (`event_id`),
  CONSTRAINT `himalay_event_image_fk` FOREIGN KEY (`event_id`) REFERENCES `himalay_tblflexevents` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfleximages`
--

LOCK TABLES `himalay_tblfleximages` WRITE;
/*!40000 ALTER TABLE `himalay_tblfleximages` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfleximages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblflexinvitationsemailsendcron`
--

DROP TABLE IF EXISTS `himalay_tblflexinvitationsemailsendcron`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblflexinvitationsemailsendcron` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `eventid` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `emailid` int(11) DEFAULT NULL,
  `listid` varchar(11) DEFAULT NULL,
  `log_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblflexinvitationsemailsendcron`
--

LOCK TABLES `himalay_tblflexinvitationsemailsendcron` WRITE;
/*!40000 ALTER TABLE `himalay_tblflexinvitationsemailsendcron` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblflexinvitationsemailsendcron` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblflexinvitationsendlog`
--

DROP TABLE IF EXISTS `himalay_tblflexinvitationsendlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblflexinvitationsendlog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `eventid` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `iscronfinished` int(11) NOT NULL DEFAULT 0,
  `send_to_mail_lists` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblflexinvitationsendlog`
--

LOCK TABLES `himalay_tblflexinvitationsendlog` WRITE;
/*!40000 ALTER TABLE `himalay_tblflexinvitationsendlog` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblflexinvitationsendlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblflexlistemails`
--

DROP TABLE IF EXISTS `himalay_tblflexlistemails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblflexlistemails` (
  `emailid` int(11) NOT NULL AUTO_INCREMENT,
  `listid` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`emailid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblflexlistemails`
--

LOCK TABLES `himalay_tblflexlistemails` WRITE;
/*!40000 ALTER TABLE `himalay_tblflexlistemails` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblflexlistemails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblflexsocialchannels`
--

DROP TABLE IF EXISTS `himalay_tblflexsocialchannels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblflexsocialchannels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event_id` int(11) NOT NULL,
  `channel_id` mediumtext NOT NULL,
  `url` mediumtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `himalay_event_socialchannel_fk` (`event_id`),
  CONSTRAINT `himalay_event_socialchannel_fk` FOREIGN KEY (`event_id`) REFERENCES `himalay_tblflexevents` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblflexsocialchannels`
--

LOCK TABLES `himalay_tblflexsocialchannels` WRITE;
/*!40000 ALTER TABLE `himalay_tblflexsocialchannels` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblflexsocialchannels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblflexspeakers`
--

DROP TABLE IF EXISTS `himalay_tblflexspeakers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblflexspeakers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event_id` int(11) NOT NULL,
  `name` mediumtext NOT NULL,
  `email` mediumtext NOT NULL,
  `image` mediumtext NOT NULL,
  `show` tinyint(1) DEFAULT 0,
  `bio` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `himalay_event_speaker_fk` (`event_id`),
  CONSTRAINT `himalay_event_speaker_fk` FOREIGN KEY (`event_id`) REFERENCES `himalay_tblflexevents` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblflexspeakers`
--

LOCK TABLES `himalay_tblflexspeakers` WRITE;
/*!40000 ALTER TABLE `himalay_tblflexspeakers` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblflexspeakers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblflexticketorders`
--

DROP TABLE IF EXISTS `himalay_tblflexticketorders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblflexticketorders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `eventid` int(11) NOT NULL,
  `invoiceid` int(11) DEFAULT NULL,
  `attendee_name` varchar(100) NOT NULL,
  `attendee_email` varchar(100) NOT NULL,
  `attendee_mobile` varchar(100) DEFAULT NULL,
  `attendee_company` varchar(100) DEFAULT NULL,
  `total_amount` double(15,3) NOT NULL DEFAULT 0.000,
  `tickets_sent` tinyint(1) NOT NULL DEFAULT 0,
  `in_leads` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblflexticketorders`
--

LOCK TABLES `himalay_tblflexticketorders` WRITE;
/*!40000 ALTER TABLE `himalay_tblflexticketorders` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblflexticketorders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblflextickets`
--

DROP TABLE IF EXISTS `himalay_tblflextickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblflextickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event_id` int(11) NOT NULL,
  `name` mediumtext NOT NULL,
  `status` mediumtext NOT NULL,
  `quantity` int(11) NOT NULL,
  `paid` tinyint(1) DEFAULT 0,
  `currency` mediumtext DEFAULT NULL,
  `price` double(15,3) DEFAULT NULL,
  `min_buying_limit` int(11) DEFAULT NULL,
  `max_buying_limit` int(11) DEFAULT NULL,
  `sales_start_date` datetime DEFAULT NULL,
  `sales_end_date` datetime DEFAULT NULL,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `himalay_event_ticket_fk` (`event_id`),
  CONSTRAINT `himalay_event_ticket_fk` FOREIGN KEY (`event_id`) REFERENCES `himalay_tblflexevents` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblflextickets`
--

LOCK TABLES `himalay_tblflextickets` WRITE;
/*!40000 ALTER TABLE `himalay_tblflextickets` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblflextickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblflexticketsales`
--

DROP TABLE IF EXISTS `himalay_tblflexticketsales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblflexticketsales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticketorderid` int(11) NOT NULL,
  `eventid` int(11) NOT NULL,
  `ticketid` int(11) NOT NULL,
  `reference_code` varchar(100) NOT NULL,
  `quantity` int(11) NOT NULL,
  `sub_total` double(15,3) DEFAULT NULL,
  `checked_in` int(10) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblflexticketsales`
--

LOCK TABLES `himalay_tblflexticketsales` WRITE;
/*!40000 ALTER TABLE `himalay_tblflexticketsales` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblflexticketsales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblflexvideos`
--

DROP TABLE IF EXISTS `himalay_tblflexvideos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblflexvideos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event_id` int(11) NOT NULL,
  `url` mediumtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `himalay_event_video_fk` (`event_id`),
  CONSTRAINT `himalay_event_video_fk` FOREIGN KEY (`event_id`) REFERENCES `himalay_tblflexevents` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblflexvideos`
--

LOCK TABLES `himalay_tblflexvideos` WRITE;
/*!40000 ALTER TABLE `himalay_tblflexvideos` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblflexvideos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfmlcustomfields`
--

DROP TABLE IF EXISTS `himalay_tblfmlcustomfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfmlcustomfields` (
  `customfieldid` int(11) NOT NULL AUTO_INCREMENT,
  `listid` int(11) NOT NULL,
  `fieldname` varchar(150) NOT NULL,
  `fieldslug` varchar(100) NOT NULL,
  PRIMARY KEY (`customfieldid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfmlcustomfields`
--

LOCK TABLES `himalay_tblfmlcustomfields` WRITE;
/*!40000 ALTER TABLE `himalay_tblfmlcustomfields` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfmlcustomfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblfmlcustomfieldvalues`
--

DROP TABLE IF EXISTS `himalay_tblfmlcustomfieldvalues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblfmlcustomfieldvalues` (
  `customfieldvalueid` int(11) NOT NULL AUTO_INCREMENT,
  `listid` int(11) NOT NULL,
  `customfieldid` int(11) NOT NULL,
  `emailid` int(11) NOT NULL,
  `value` varchar(100) NOT NULL,
  PRIMARY KEY (`customfieldvalueid`),
  KEY `listid` (`listid`),
  KEY `customfieldid` (`customfieldid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblfmlcustomfieldvalues`
--

LOCK TABLES `himalay_tblfmlcustomfieldvalues` WRITE;
/*!40000 ALTER TABLE `himalay_tblfmlcustomfieldvalues` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblfmlcustomfieldvalues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblform_question_box`
--

DROP TABLE IF EXISTS `himalay_tblform_question_box`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblform_question_box` (
  `boxid` int(11) NOT NULL AUTO_INCREMENT,
  `boxtype` varchar(10) NOT NULL,
  `questionid` int(11) NOT NULL,
  PRIMARY KEY (`boxid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblform_question_box`
--

LOCK TABLES `himalay_tblform_question_box` WRITE;
/*!40000 ALTER TABLE `himalay_tblform_question_box` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblform_question_box` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblform_question_box_description`
--

DROP TABLE IF EXISTS `himalay_tblform_question_box_description`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblform_question_box_description` (
  `questionboxdescriptionid` int(11) NOT NULL AUTO_INCREMENT,
  `description` longtext NOT NULL,
  `boxid` longtext NOT NULL,
  `questionid` int(11) NOT NULL,
  PRIMARY KEY (`questionboxdescriptionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblform_question_box_description`
--

LOCK TABLES `himalay_tblform_question_box_description` WRITE;
/*!40000 ALTER TABLE `himalay_tblform_question_box_description` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblform_question_box_description` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblform_questions`
--

DROP TABLE IF EXISTS `himalay_tblform_questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblform_questions` (
  `questionid` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) DEFAULT NULL,
  `question` longtext NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT 0,
  `question_order` int(11) NOT NULL,
  PRIMARY KEY (`questionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblform_questions`
--

LOCK TABLES `himalay_tblform_questions` WRITE;
/*!40000 ALTER TABLE `himalay_tblform_questions` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblform_questions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblform_results`
--

DROP TABLE IF EXISTS `himalay_tblform_results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblform_results` (
  `resultid` int(11) NOT NULL AUTO_INCREMENT,
  `boxid` int(11) NOT NULL,
  `boxdescriptionid` int(11) DEFAULT NULL,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) DEFAULT NULL,
  `questionid` int(11) NOT NULL,
  `answer` mediumtext DEFAULT NULL,
  `resultsetid` int(11) NOT NULL,
  PRIMARY KEY (`resultid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblform_results`
--

LOCK TABLES `himalay_tblform_results` WRITE;
/*!40000 ALTER TABLE `himalay_tblform_results` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblform_results` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblgdpr_requests`
--

DROP TABLE IF EXISTS `himalay_tblgdpr_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblgdpr_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clientid` int(11) NOT NULL DEFAULT 0,
  `contact_id` int(11) NOT NULL DEFAULT 0,
  `lead_id` int(11) NOT NULL DEFAULT 0,
  `request_type` varchar(191) DEFAULT NULL,
  `status` varchar(40) DEFAULT NULL,
  `request_date` datetime NOT NULL,
  `request_from` varchar(150) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblgdpr_requests`
--

LOCK TABLES `himalay_tblgdpr_requests` WRITE;
/*!40000 ALTER TABLE `himalay_tblgdpr_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblgdpr_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblgoals`
--

DROP TABLE IF EXISTS `himalay_tblgoals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblgoals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(191) NOT NULL,
  `description` text NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `goal_type` int(11) NOT NULL,
  `contract_type` int(11) NOT NULL DEFAULT 0,
  `achievement` int(11) NOT NULL,
  `notify_when_fail` tinyint(1) NOT NULL DEFAULT 1,
  `notify_when_achieve` tinyint(1) NOT NULL DEFAULT 1,
  `notified` int(11) NOT NULL DEFAULT 0,
  `staff_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `staff_id` (`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblgoals`
--

LOCK TABLES `himalay_tblgoals` WRITE;
/*!40000 ALTER TABLE `himalay_tblgoals` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblgoals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblgoods_delivery`
--

DROP TABLE IF EXISTS `himalay_tblgoods_delivery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblgoods_delivery` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rel_type` int(11) DEFAULT NULL COMMENT 'type goods delivery',
  `rel_document` int(11) DEFAULT NULL COMMENT 'document id of goods delivery',
  `customer_code` text DEFAULT NULL,
  `customer_name` varchar(100) DEFAULT NULL,
  `to_` varchar(100) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL COMMENT 'the reason delivery',
  `staff_id` int(11) DEFAULT NULL COMMENT 'salesman',
  `date_c` date DEFAULT NULL,
  `date_add` date DEFAULT NULL,
  `goods_delivery_code` varchar(100) DEFAULT NULL COMMENT 'số chứng từ xuất kho',
  `warehouse_id` int(11) DEFAULT NULL,
  `total_money` varchar(200) DEFAULT NULL,
  `approval` int(11) DEFAULT 0 COMMENT 'status approval ',
  `addedfrom` int(11) DEFAULT NULL,
  `total_discount` varchar(100) DEFAULT NULL,
  `after_discount` varchar(100) DEFAULT NULL,
  `invoice_id` varchar(100) DEFAULT NULL,
  `project` text DEFAULT NULL,
  `type` text DEFAULT NULL,
  `department` int(11) DEFAULT NULL,
  `requester` int(11) DEFAULT NULL,
  `invoice_no` text DEFAULT NULL,
  `pr_order_id` int(11) DEFAULT NULL,
  `type_of_delivery` varchar(100) DEFAULT 'total',
  `additional_discount` decimal(15,2) DEFAULT 0.00,
  `sub_total` decimal(15,2) DEFAULT 0.00,
  `delivery_status` varchar(100) DEFAULT 'ready_for_packing',
  `shipping_fee` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblgoods_delivery`
--

LOCK TABLES `himalay_tblgoods_delivery` WRITE;
/*!40000 ALTER TABLE `himalay_tblgoods_delivery` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblgoods_delivery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblgoods_delivery_detail`
--

DROP TABLE IF EXISTS `himalay_tblgoods_delivery_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblgoods_delivery_detail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `goods_delivery_id` int(11) NOT NULL,
  `commodity_code` varchar(100) DEFAULT NULL,
  `commodity_name` text DEFAULT NULL,
  `warehouse_id` text DEFAULT NULL,
  `unit_id` text DEFAULT NULL,
  `quantities` text DEFAULT NULL,
  `unit_price` varchar(100) DEFAULT NULL,
  `total_money` varchar(200) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `discount` varchar(100) DEFAULT NULL,
  `discount_money` varchar(100) DEFAULT NULL,
  `available_quantity` varchar(100) DEFAULT NULL,
  `tax_id` varchar(100) DEFAULT NULL,
  `total_after_discount` varchar(100) DEFAULT NULL,
  `expiry_date` text DEFAULT NULL,
  `lot_number` text DEFAULT NULL,
  `guarantee_period` text DEFAULT NULL,
  `tax_rate` text DEFAULT NULL,
  `tax_name` text DEFAULT NULL,
  `sub_total` decimal(15,2) DEFAULT 0.00,
  `packing_qty` decimal(15,2) DEFAULT 0.00,
  `serial_number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblgoods_delivery_detail`
--

LOCK TABLES `himalay_tblgoods_delivery_detail` WRITE;
/*!40000 ALTER TABLE `himalay_tblgoods_delivery_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblgoods_delivery_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblgoods_delivery_invoices_pr_orders`
--

DROP TABLE IF EXISTS `himalay_tblgoods_delivery_invoices_pr_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblgoods_delivery_invoices_pr_orders` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) DEFAULT NULL COMMENT 'goods_delivery_id',
  `rel_type` int(11) DEFAULT NULL COMMENT 'invoice_id or purchase order id',
  `type` varchar(100) DEFAULT NULL COMMENT 'invoice,  purchase_orders',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblgoods_delivery_invoices_pr_orders`
--

LOCK TABLES `himalay_tblgoods_delivery_invoices_pr_orders` WRITE;
/*!40000 ALTER TABLE `himalay_tblgoods_delivery_invoices_pr_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblgoods_delivery_invoices_pr_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblgoods_receipt`
--

DROP TABLE IF EXISTS `himalay_tblgoods_receipt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblgoods_receipt` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `supplier_code` varchar(100) DEFAULT NULL,
  `supplier_name` text DEFAULT NULL,
  `deliver_name` text DEFAULT NULL,
  `buyer_id` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `pr_order_id` int(11) DEFAULT NULL COMMENT 'code puchase request agree',
  `date_c` date DEFAULT NULL,
  `date_add` date DEFAULT NULL,
  `goods_receipt_code` varchar(100) DEFAULT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `total_tax_money` varchar(100) DEFAULT NULL,
  `total_goods_money` varchar(100) DEFAULT NULL,
  `value_of_inventory` varchar(100) DEFAULT NULL,
  `total_money` varchar(100) DEFAULT NULL COMMENT 'total_money = total_tax_money +total_goods_money ',
  `addedfrom` int(11) DEFAULT NULL,
  `approval` int(11) DEFAULT 0,
  `project` text DEFAULT NULL,
  `type` text DEFAULT NULL,
  `department` int(11) DEFAULT NULL,
  `requester` int(11) DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `invoice_no` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblgoods_receipt`
--

LOCK TABLES `himalay_tblgoods_receipt` WRITE;
/*!40000 ALTER TABLE `himalay_tblgoods_receipt` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblgoods_receipt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblgoods_receipt_detail`
--

DROP TABLE IF EXISTS `himalay_tblgoods_receipt_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblgoods_receipt_detail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `goods_receipt_id` int(11) NOT NULL,
  `commodity_code` varchar(100) DEFAULT NULL,
  `commodity_name` text DEFAULT NULL,
  `warehouse_id` text DEFAULT NULL,
  `unit_id` text DEFAULT NULL,
  `quantities` text DEFAULT NULL,
  `unit_price` varchar(100) DEFAULT NULL,
  `tax` varchar(100) DEFAULT NULL,
  `tax_money` varchar(100) DEFAULT NULL,
  `goods_money` varchar(100) DEFAULT NULL,
  `date_manufacture` date DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `note` text DEFAULT NULL,
  `discount` varchar(100) DEFAULT NULL,
  `discount_money` varchar(100) DEFAULT NULL,
  `lot_number` varchar(100) DEFAULT NULL,
  `tax_rate` text DEFAULT NULL,
  `sub_total` decimal(15,2) DEFAULT 0.00,
  `tax_name` text DEFAULT NULL,
  `serial_number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblgoods_receipt_detail`
--

LOCK TABLES `himalay_tblgoods_receipt_detail` WRITE;
/*!40000 ALTER TABLE `himalay_tblgoods_receipt_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblgoods_receipt_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblgoods_transaction_detail`
--

DROP TABLE IF EXISTS `himalay_tblgoods_transaction_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblgoods_transaction_detail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `goods_receipt_id` int(11) DEFAULT NULL COMMENT 'id_goods_receipt_id or goods_delivery_id',
  `goods_id` int(11) NOT NULL COMMENT ' is id commodity',
  `old_quantity` varchar(100) DEFAULT NULL,
  `quantity` varchar(100) DEFAULT NULL,
  `date_add` datetime DEFAULT NULL,
  `commodity_id` int(11) NOT NULL,
  `warehouse_id` text NOT NULL,
  `note` text DEFAULT NULL,
  `status` int(2) DEFAULT NULL COMMENT '1:Goods receipt note 2:Goods delivery note',
  `purchase_price` varchar(100) DEFAULT NULL,
  `price` varchar(100) DEFAULT NULL,
  `expiry_date` text DEFAULT NULL,
  `lot_number` text DEFAULT NULL,
  `from_stock_name` int(11) DEFAULT NULL,
  `to_stock_name` int(11) DEFAULT NULL,
  `serial_number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`,`commodity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblgoods_transaction_detail`
--

LOCK TABLES `himalay_tblgoods_transaction_detail` WRITE;
/*!40000 ALTER TABLE `himalay_tblgoods_transaction_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblgoods_transaction_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblgroup_checklist`
--

DROP TABLE IF EXISTS `himalay_tblgroup_checklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblgroup_checklist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(100) NOT NULL,
  `meta` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblgroup_checklist`
--

LOCK TABLES `himalay_tblgroup_checklist` WRITE;
/*!40000 ALTER TABLE `himalay_tblgroup_checklist` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblgroup_checklist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblgroup_checklist_allocation`
--

DROP TABLE IF EXISTS `himalay_tblgroup_checklist_allocation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblgroup_checklist_allocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(100) NOT NULL,
  `meta` varchar(100) DEFAULT NULL,
  `staffid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblgroup_checklist_allocation`
--

LOCK TABLES `himalay_tblgroup_checklist_allocation` WRITE;
/*!40000 ALTER TABLE `himalay_tblgroup_checklist_allocation` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblgroup_checklist_allocation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhr_allocation_asset`
--

DROP TABLE IF EXISTS `himalay_tblhr_allocation_asset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhr_allocation_asset` (
  `allocation_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) unsigned NOT NULL,
  `asset_name` varchar(100) DEFAULT NULL,
  `assets_amount` int(11) unsigned NOT NULL,
  `status_allocation` int(11) unsigned DEFAULT 0 COMMENT '1: Allocated 0: Unallocated',
  PRIMARY KEY (`allocation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhr_allocation_asset`
--

LOCK TABLES `himalay_tblhr_allocation_asset` WRITE;
/*!40000 ALTER TABLE `himalay_tblhr_allocation_asset` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblhr_allocation_asset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhr_allowance_type`
--

DROP TABLE IF EXISTS `himalay_tblhr_allowance_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhr_allowance_type` (
  `type_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type_name` varchar(200) NOT NULL,
  `allowance_val` decimal(15,2) NOT NULL,
  `taxable` tinyint(1) NOT NULL,
  PRIMARY KEY (`type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhr_allowance_type`
--

LOCK TABLES `himalay_tblhr_allowance_type` WRITE;
/*!40000 ALTER TABLE `himalay_tblhr_allowance_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblhr_allowance_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhr_checklist_allocation`
--

DROP TABLE IF EXISTS `himalay_tblhr_checklist_allocation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhr_checklist_allocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `group_id` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhr_checklist_allocation`
--

LOCK TABLES `himalay_tblhr_checklist_allocation` WRITE;
/*!40000 ALTER TABLE `himalay_tblhr_checklist_allocation` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblhr_checklist_allocation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhr_contract_template`
--

DROP TABLE IF EXISTS `himalay_tblhr_contract_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhr_contract_template` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text DEFAULT NULL,
  `job_position` longtext DEFAULT NULL,
  `content` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhr_contract_template`
--

LOCK TABLES `himalay_tblhr_contract_template` WRITE;
/*!40000 ALTER TABLE `himalay_tblhr_contract_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblhr_contract_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhr_dependent_person`
--

DROP TABLE IF EXISTS `himalay_tblhr_dependent_person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhr_dependent_person` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staffid` int(11) unsigned DEFAULT NULL,
  `dependent_name` varchar(100) DEFAULT NULL,
  `relationship` varchar(100) DEFAULT NULL,
  `dependent_bir` date DEFAULT NULL,
  `start_month` date DEFAULT NULL,
  `end_month` date DEFAULT NULL,
  `dependent_iden` varchar(20) NOT NULL,
  `reason` longtext DEFAULT NULL,
  `status` int(11) unsigned DEFAULT 0,
  `status_comment` longtext DEFAULT NULL,
  PRIMARY KEY (`id`,`dependent_iden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhr_dependent_person`
--

LOCK TABLES `himalay_tblhr_dependent_person` WRITE;
/*!40000 ALTER TABLE `himalay_tblhr_dependent_person` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblhr_dependent_person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhr_education`
--

DROP TABLE IF EXISTS `himalay_tblhr_education`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhr_education` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `programe_id` int(11) DEFAULT NULL,
  `training_programs_name` text NOT NULL,
  `training_places` text DEFAULT NULL,
  `training_time_from` datetime DEFAULT NULL,
  `training_time_to` datetime DEFAULT NULL,
  `date_create` datetime DEFAULT NULL,
  `training_result` varchar(150) DEFAULT NULL,
  `degree` varchar(150) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhr_education`
--

LOCK TABLES `himalay_tblhr_education` WRITE;
/*!40000 ALTER TABLE `himalay_tblhr_education` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblhr_education` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhr_group_checklist_allocation`
--

DROP TABLE IF EXISTS `himalay_tblhr_group_checklist_allocation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhr_group_checklist_allocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(100) NOT NULL,
  `meta` varchar(100) DEFAULT NULL,
  `staffid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhr_group_checklist_allocation`
--

LOCK TABLES `himalay_tblhr_group_checklist_allocation` WRITE;
/*!40000 ALTER TABLE `himalay_tblhr_group_checklist_allocation` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblhr_group_checklist_allocation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhr_job_p`
--

DROP TABLE IF EXISTS `himalay_tblhr_job_p`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhr_job_p` (
  `job_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `job_name` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`job_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhr_job_p`
--

LOCK TABLES `himalay_tblhr_job_p` WRITE;
/*!40000 ALTER TABLE `himalay_tblhr_job_p` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblhr_job_p` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhr_job_position`
--

DROP TABLE IF EXISTS `himalay_tblhr_job_position`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhr_job_position` (
  `position_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `position_name` varchar(200) NOT NULL,
  `job_position_description` text DEFAULT NULL,
  `job_p_id` int(11) unsigned NOT NULL,
  `position_code` varchar(50) DEFAULT NULL,
  `department_id` text DEFAULT NULL,
  PRIMARY KEY (`position_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhr_job_position`
--

LOCK TABLES `himalay_tblhr_job_position` WRITE;
/*!40000 ALTER TABLE `himalay_tblhr_job_position` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblhr_job_position` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhr_jp_interview_training`
--

DROP TABLE IF EXISTS `himalay_tblhr_jp_interview_training`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhr_jp_interview_training` (
  `training_process_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `job_position_id` longtext DEFAULT NULL,
  `training_name` varchar(100) DEFAULT NULL,
  `training_type` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `date_add` datetime DEFAULT NULL,
  `position_training_id` text DEFAULT NULL,
  `mint_point` int(11) DEFAULT NULL,
  `additional_training` varchar(100) DEFAULT '',
  `staff_id` text DEFAULT NULL,
  `time_to_start` date DEFAULT NULL,
  `time_to_end` date DEFAULT NULL,
  PRIMARY KEY (`training_process_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhr_jp_interview_training`
--

LOCK TABLES `himalay_tblhr_jp_interview_training` WRITE;
/*!40000 ALTER TABLE `himalay_tblhr_jp_interview_training` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblhr_jp_interview_training` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhr_jp_salary_scale`
--

DROP TABLE IF EXISTS `himalay_tblhr_jp_salary_scale`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhr_jp_salary_scale` (
  `salary_scale_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `job_position_id` int(11) unsigned NOT NULL,
  `rel_type` varchar(100) DEFAULT NULL COMMENT 'salary:allowance:insurance',
  `rel_id` int(11) DEFAULT NULL,
  `value` text DEFAULT NULL,
  PRIMARY KEY (`salary_scale_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhr_jp_salary_scale`
--

LOCK TABLES `himalay_tblhr_jp_salary_scale` WRITE;
/*!40000 ALTER TABLE `himalay_tblhr_jp_salary_scale` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblhr_jp_salary_scale` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhr_knowedge_base_article_feedback`
--

DROP TABLE IF EXISTS `himalay_tblhr_knowedge_base_article_feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhr_knowedge_base_article_feedback` (
  `articleanswerid` int(11) NOT NULL AUTO_INCREMENT,
  `articleid` int(11) NOT NULL,
  `answer` int(11) NOT NULL,
  `ip` varchar(40) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`articleanswerid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhr_knowedge_base_article_feedback`
--

LOCK TABLES `himalay_tblhr_knowedge_base_article_feedback` WRITE;
/*!40000 ALTER TABLE `himalay_tblhr_knowedge_base_article_feedback` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblhr_knowedge_base_article_feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhr_knowledge_base`
--

DROP TABLE IF EXISTS `himalay_tblhr_knowledge_base`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhr_knowledge_base` (
  `articleid` int(11) NOT NULL AUTO_INCREMENT,
  `articlegroup` int(11) NOT NULL,
  `subject` mediumtext NOT NULL,
  `description` text NOT NULL,
  `slug` mediumtext NOT NULL,
  `active` tinyint(4) NOT NULL,
  `datecreated` datetime NOT NULL,
  `article_order` int(11) NOT NULL DEFAULT 0,
  `staff_article` int(11) NOT NULL DEFAULT 0,
  `question_answers` int(11) DEFAULT 0,
  `file_name` varchar(255) DEFAULT '',
  `curator` varchar(11) DEFAULT '',
  `benchmark` int(11) DEFAULT 0,
  `score` int(11) DEFAULT 0,
  PRIMARY KEY (`articleid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhr_knowledge_base`
--

LOCK TABLES `himalay_tblhr_knowledge_base` WRITE;
/*!40000 ALTER TABLE `himalay_tblhr_knowledge_base` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblhr_knowledge_base` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhr_knowledge_base_groups`
--

DROP TABLE IF EXISTS `himalay_tblhr_knowledge_base_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhr_knowledge_base_groups` (
  `groupid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `group_slug` text DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `active` tinyint(4) NOT NULL,
  `color` varchar(10) DEFAULT '#28B8DA',
  `group_order` int(11) DEFAULT 0,
  PRIMARY KEY (`groupid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhr_knowledge_base_groups`
--

LOCK TABLES `himalay_tblhr_knowledge_base_groups` WRITE;
/*!40000 ALTER TABLE `himalay_tblhr_knowledge_base_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblhr_knowledge_base_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhr_list_staff_quitting_work`
--

DROP TABLE IF EXISTS `himalay_tblhr_list_staff_quitting_work`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhr_list_staff_quitting_work` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staffid` int(11) DEFAULT NULL,
  `staff_name` text DEFAULT NULL,
  `department_name` text DEFAULT NULL,
  `role_name` text DEFAULT NULL,
  `email` text DEFAULT NULL,
  `dateoff` datetime DEFAULT NULL,
  `approval` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhr_list_staff_quitting_work`
--

LOCK TABLES `himalay_tblhr_list_staff_quitting_work` WRITE;
/*!40000 ALTER TABLE `himalay_tblhr_list_staff_quitting_work` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblhr_list_staff_quitting_work` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhr_p_t_form_question_box`
--

DROP TABLE IF EXISTS `himalay_tblhr_p_t_form_question_box`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhr_p_t_form_question_box` (
  `boxid` int(11) NOT NULL AUTO_INCREMENT,
  `boxtype` varchar(10) NOT NULL,
  `questionid` int(11) NOT NULL,
  PRIMARY KEY (`boxid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhr_p_t_form_question_box`
--

LOCK TABLES `himalay_tblhr_p_t_form_question_box` WRITE;
/*!40000 ALTER TABLE `himalay_tblhr_p_t_form_question_box` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblhr_p_t_form_question_box` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhr_p_t_form_question_box_description`
--

DROP TABLE IF EXISTS `himalay_tblhr_p_t_form_question_box_description`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhr_p_t_form_question_box_description` (
  `questionboxdescriptionid` int(11) NOT NULL AUTO_INCREMENT,
  `description` mediumtext NOT NULL,
  `boxid` mediumtext NOT NULL,
  `questionid` int(11) NOT NULL,
  `correct` int(11) DEFAULT 1 COMMENT '0: correct 1: incorrect',
  PRIMARY KEY (`questionboxdescriptionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhr_p_t_form_question_box_description`
--

LOCK TABLES `himalay_tblhr_p_t_form_question_box_description` WRITE;
/*!40000 ALTER TABLE `himalay_tblhr_p_t_form_question_box_description` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblhr_p_t_form_question_box_description` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhr_p_t_form_results`
--

DROP TABLE IF EXISTS `himalay_tblhr_p_t_form_results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhr_p_t_form_results` (
  `resultid` int(11) NOT NULL AUTO_INCREMENT,
  `boxid` int(11) NOT NULL,
  `boxdescriptionid` int(11) DEFAULT NULL,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) DEFAULT NULL,
  `questionid` int(11) NOT NULL,
  `answer` text DEFAULT NULL,
  `resultsetid` int(11) NOT NULL,
  PRIMARY KEY (`resultid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhr_p_t_form_results`
--

LOCK TABLES `himalay_tblhr_p_t_form_results` WRITE;
/*!40000 ALTER TABLE `himalay_tblhr_p_t_form_results` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblhr_p_t_form_results` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhr_p_t_surveyresultsets`
--

DROP TABLE IF EXISTS `himalay_tblhr_p_t_surveyresultsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhr_p_t_surveyresultsets` (
  `resultsetid` int(11) NOT NULL AUTO_INCREMENT,
  `trainingid` int(11) NOT NULL,
  `ip` varchar(40) NOT NULL,
  `useragent` varchar(150) NOT NULL,
  `date` datetime NOT NULL,
  `staff_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`resultsetid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhr_p_t_surveyresultsets`
--

LOCK TABLES `himalay_tblhr_p_t_surveyresultsets` WRITE;
/*!40000 ALTER TABLE `himalay_tblhr_p_t_surveyresultsets` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblhr_p_t_surveyresultsets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhr_payroll_option`
--

DROP TABLE IF EXISTS `himalay_tblhr_payroll_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhr_payroll_option` (
  `option_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(200) NOT NULL,
  `option_val` longtext DEFAULT NULL,
  `auto` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`option_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhr_payroll_option`
--

LOCK TABLES `himalay_tblhr_payroll_option` WRITE;
/*!40000 ALTER TABLE `himalay_tblhr_payroll_option` DISABLE KEYS */;
INSERT INTO `himalay_tblhr_payroll_option` VALUES (1,'integrated_hrprofile','0',1),(2,'integrated_timesheets','0',1),(3,'integration_actual_workday','W,B',1),(4,'integration_paid_leave','AL,HO,EB',1),(5,'integration_unpaid_leave','U,SI,UB,P',1),(6,'standard_working_time','160',1),(7,'integrated_commissions','0',1),(8,'hrp_customize_staff_payslip_column','0',1);
/*!40000 ALTER TABLE `himalay_tblhr_payroll_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhr_position_training`
--

DROP TABLE IF EXISTS `himalay_tblhr_position_training`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhr_position_training` (
  `training_id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` mediumtext NOT NULL,
  `training_type` int(11) unsigned NOT NULL,
  `slug` mediumtext NOT NULL,
  `description` text DEFAULT NULL,
  `viewdescription` text DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `redirect_url` varchar(100) DEFAULT NULL,
  `send` tinyint(1) NOT NULL DEFAULT 0,
  `onlyforloggedin` int(11) DEFAULT 0,
  `fromname` varchar(100) DEFAULT NULL,
  `iprestrict` tinyint(1) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `hash` varchar(32) NOT NULL,
  `mint_point` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`training_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhr_position_training`
--

LOCK TABLES `himalay_tblhr_position_training` WRITE;
/*!40000 ALTER TABLE `himalay_tblhr_position_training` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblhr_position_training` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhr_position_training_question_form`
--

DROP TABLE IF EXISTS `himalay_tblhr_position_training_question_form`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhr_position_training_question_form` (
  `questionid` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) DEFAULT NULL,
  `question` mediumtext NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT 0,
  `question_order` int(11) NOT NULL,
  `point` int(11) NOT NULL,
  PRIMARY KEY (`questionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhr_position_training_question_form`
--

LOCK TABLES `himalay_tblhr_position_training_question_form` WRITE;
/*!40000 ALTER TABLE `himalay_tblhr_position_training_question_form` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblhr_position_training_question_form` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhr_procedure_retire`
--

DROP TABLE IF EXISTS `himalay_tblhr_procedure_retire`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhr_procedure_retire` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_name` text DEFAULT NULL,
  `option_name` text DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `people_handle_id` int(11) NOT NULL,
  `procedure_retire_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhr_procedure_retire`
--

LOCK TABLES `himalay_tblhr_procedure_retire` WRITE;
/*!40000 ALTER TABLE `himalay_tblhr_procedure_retire` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblhr_procedure_retire` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhr_procedure_retire_manage`
--

DROP TABLE IF EXISTS `himalay_tblhr_procedure_retire_manage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhr_procedure_retire_manage` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name_procedure_retire` text NOT NULL,
  `department` varchar(250) NOT NULL,
  `datecreator` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhr_procedure_retire_manage`
--

LOCK TABLES `himalay_tblhr_procedure_retire_manage` WRITE;
/*!40000 ALTER TABLE `himalay_tblhr_procedure_retire_manage` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblhr_procedure_retire_manage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhr_procedure_retire_of_staff`
--

DROP TABLE IF EXISTS `himalay_tblhr_procedure_retire_of_staff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhr_procedure_retire_of_staff` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) DEFAULT NULL,
  `option_name` text DEFAULT NULL,
  `status` int(11) DEFAULT 0,
  `staffid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhr_procedure_retire_of_staff`
--

LOCK TABLES `himalay_tblhr_procedure_retire_of_staff` WRITE;
/*!40000 ALTER TABLE `himalay_tblhr_procedure_retire_of_staff` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblhr_procedure_retire_of_staff` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhr_procedure_retire_of_staff_by_id`
--

DROP TABLE IF EXISTS `himalay_tblhr_procedure_retire_of_staff_by_id`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhr_procedure_retire_of_staff_by_id` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_name` text DEFAULT NULL,
  `people_handle_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhr_procedure_retire_of_staff_by_id`
--

LOCK TABLES `himalay_tblhr_procedure_retire_of_staff_by_id` WRITE;
/*!40000 ALTER TABLE `himalay_tblhr_procedure_retire_of_staff_by_id` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblhr_procedure_retire_of_staff_by_id` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhr_profile_option`
--

DROP TABLE IF EXISTS `himalay_tblhr_profile_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhr_profile_option` (
  `option_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(200) NOT NULL,
  `option_val` longtext DEFAULT NULL,
  `auto` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`option_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhr_profile_option`
--

LOCK TABLES `himalay_tblhr_profile_option` WRITE;
/*!40000 ALTER TABLE `himalay_tblhr_profile_option` DISABLE KEYS */;
INSERT INTO `himalay_tblhr_profile_option` VALUES (1,'job_position_prefix','#JOB',1),(2,'job_position_number','1',1),(3,'contract_code_prefix','#CONTRACT',1),(4,'contract_code_number','1',1),(5,'staff_code_prefix','EC',1),(6,'staff_code_number','1',1);
/*!40000 ALTER TABLE `himalay_tblhr_profile_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhr_rec_transfer_records`
--

DROP TABLE IF EXISTS `himalay_tblhr_rec_transfer_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhr_rec_transfer_records` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `firstname` varchar(100) DEFAULT NULL,
  `lastname` varchar(100) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `gender` varchar(11) DEFAULT NULL,
  `staff_identifi` varchar(20) DEFAULT NULL,
  `creator` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhr_rec_transfer_records`
--

LOCK TABLES `himalay_tblhr_rec_transfer_records` WRITE;
/*!40000 ALTER TABLE `himalay_tblhr_rec_transfer_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblhr_rec_transfer_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhr_salary_form`
--

DROP TABLE IF EXISTS `himalay_tblhr_salary_form`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhr_salary_form` (
  `form_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `form_name` varchar(200) NOT NULL,
  `salary_val` decimal(15,2) NOT NULL,
  `tax` tinyint(1) NOT NULL,
  PRIMARY KEY (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhr_salary_form`
--

LOCK TABLES `himalay_tblhr_salary_form` WRITE;
/*!40000 ALTER TABLE `himalay_tblhr_salary_form` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblhr_salary_form` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhr_staff_contract`
--

DROP TABLE IF EXISTS `himalay_tblhr_staff_contract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhr_staff_contract` (
  `id_contract` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `contract_code` varchar(200) NOT NULL,
  `name_contract` int(11) NOT NULL,
  `staff` int(11) NOT NULL,
  `start_valid` date DEFAULT NULL,
  `end_valid` date DEFAULT NULL,
  `contract_status` varchar(100) DEFAULT NULL,
  `sign_day` date DEFAULT NULL,
  `staff_delegate` int(11) DEFAULT NULL,
  `hourly_or_month` longtext DEFAULT NULL,
  `content` longtext DEFAULT NULL,
  `hash` varchar(32) DEFAULT NULL,
  `signature` varchar(40) DEFAULT NULL,
  `signer` int(11) DEFAULT NULL,
  `staff_signature` varchar(40) DEFAULT NULL,
  `staff_sign_day` date DEFAULT NULL,
  PRIMARY KEY (`id_contract`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhr_staff_contract`
--

LOCK TABLES `himalay_tblhr_staff_contract` WRITE;
/*!40000 ALTER TABLE `himalay_tblhr_staff_contract` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblhr_staff_contract` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhr_staff_contract_detail`
--

DROP TABLE IF EXISTS `himalay_tblhr_staff_contract_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhr_staff_contract_detail` (
  `contract_detail_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staff_contract_id` int(11) unsigned NOT NULL,
  `type` text DEFAULT NULL,
  `rel_type` text DEFAULT NULL,
  `rel_value` decimal(15,2) DEFAULT 0.00,
  `since_date` date DEFAULT NULL,
  `contract_note` text DEFAULT NULL,
  PRIMARY KEY (`contract_detail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhr_staff_contract_detail`
--

LOCK TABLES `himalay_tblhr_staff_contract_detail` WRITE;
/*!40000 ALTER TABLE `himalay_tblhr_staff_contract_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblhr_staff_contract_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhr_staff_contract_type`
--

DROP TABLE IF EXISTS `himalay_tblhr_staff_contract_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhr_staff_contract_type` (
  `id_contracttype` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name_contracttype` varchar(200) NOT NULL,
  `description` longtext DEFAULT NULL,
  `duration` int(11) DEFAULT NULL,
  `unit` varchar(20) DEFAULT NULL,
  `insurance` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id_contracttype`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhr_staff_contract_type`
--

LOCK TABLES `himalay_tblhr_staff_contract_type` WRITE;
/*!40000 ALTER TABLE `himalay_tblhr_staff_contract_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblhr_staff_contract_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhr_training_allocation`
--

DROP TABLE IF EXISTS `himalay_tblhr_training_allocation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhr_training_allocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `training_process_id` varchar(100) NOT NULL,
  `staffid` int(11) DEFAULT NULL,
  `training_type` int(11) DEFAULT NULL,
  `date_add` datetime DEFAULT NULL,
  `training_name` varchar(150) DEFAULT NULL,
  `jp_interview_training_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhr_training_allocation`
--

LOCK TABLES `himalay_tblhr_training_allocation` WRITE;
/*!40000 ALTER TABLE `himalay_tblhr_training_allocation` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblhr_training_allocation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhr_type_of_trainings`
--

DROP TABLE IF EXISTS `himalay_tblhr_type_of_trainings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhr_type_of_trainings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhr_type_of_trainings`
--

LOCK TABLES `himalay_tblhr_type_of_trainings` WRITE;
/*!40000 ALTER TABLE `himalay_tblhr_type_of_trainings` DISABLE KEYS */;
INSERT INTO `himalay_tblhr_type_of_trainings` VALUES (1,'Basic training');
/*!40000 ALTER TABLE `himalay_tblhr_type_of_trainings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhr_views_tracking`
--

DROP TABLE IF EXISTS `himalay_tblhr_views_tracking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhr_views_tracking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(40) NOT NULL,
  `date` datetime NOT NULL,
  `view_ip` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhr_views_tracking`
--

LOCK TABLES `himalay_tblhr_views_tracking` WRITE;
/*!40000 ALTER TABLE `himalay_tblhr_views_tracking` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblhr_views_tracking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhr_workplace`
--

DROP TABLE IF EXISTS `himalay_tblhr_workplace`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhr_workplace` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `workplace_address` varchar(400) DEFAULT NULL,
  `latitude` double DEFAULT NULL,
  `longitude` double DEFAULT NULL,
  `default` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhr_workplace`
--

LOCK TABLES `himalay_tblhr_workplace` WRITE;
/*!40000 ALTER TABLE `himalay_tblhr_workplace` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblhr_workplace` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhrp_bonus_kpi`
--

DROP TABLE IF EXISTS `himalay_tblhrp_bonus_kpi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhrp_bonus_kpi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `month_bonus_kpi` varchar(45) DEFAULT NULL,
  `staffid` int(11) DEFAULT NULL,
  `bonus_kpi` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhrp_bonus_kpi`
--

LOCK TABLES `himalay_tblhrp_bonus_kpi` WRITE;
/*!40000 ALTER TABLE `himalay_tblhrp_bonus_kpi` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblhrp_bonus_kpi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhrp_commissions`
--

DROP TABLE IF EXISTS `himalay_tblhrp_commissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhrp_commissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `month` date NOT NULL,
  `commission_amount` decimal(15,2) DEFAULT NULL,
  `rel_type` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhrp_commissions`
--

LOCK TABLES `himalay_tblhrp_commissions` WRITE;
/*!40000 ALTER TABLE `himalay_tblhrp_commissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblhrp_commissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhrp_company_contributions_list`
--

DROP TABLE IF EXISTS `himalay_tblhrp_company_contributions_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhrp_company_contributions_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(200) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `rate` decimal(15,2) DEFAULT NULL,
  `basis` varchar(200) DEFAULT NULL,
  `earn_inclusion` varchar(200) DEFAULT NULL,
  `earn_exclusion` varchar(200) DEFAULT NULL,
  `earnings_max` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhrp_company_contributions_list`
--

LOCK TABLES `himalay_tblhrp_company_contributions_list` WRITE;
/*!40000 ALTER TABLE `himalay_tblhrp_company_contributions_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblhrp_company_contributions_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhrp_customize_staff_payslip_columns`
--

DROP TABLE IF EXISTS `himalay_tblhrp_customize_staff_payslip_columns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhrp_customize_staff_payslip_columns` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `column_name` text DEFAULT NULL,
  `order_number` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhrp_customize_staff_payslip_columns`
--

LOCK TABLES `himalay_tblhrp_customize_staff_payslip_columns` WRITE;
/*!40000 ALTER TABLE `himalay_tblhrp_customize_staff_payslip_columns` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblhrp_customize_staff_payslip_columns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhrp_earnings_list`
--

DROP TABLE IF EXISTS `himalay_tblhrp_earnings_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhrp_earnings_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(200) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `short_name` varchar(200) DEFAULT NULL,
  `taxable` decimal(15,2) DEFAULT NULL,
  `basis_type` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhrp_earnings_list`
--

LOCK TABLES `himalay_tblhrp_earnings_list` WRITE;
/*!40000 ALTER TABLE `himalay_tblhrp_earnings_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblhrp_earnings_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhrp_earnings_list_hr_records`
--

DROP TABLE IF EXISTS `himalay_tblhrp_earnings_list_hr_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhrp_earnings_list_hr_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(200) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `short_name` varchar(200) DEFAULT NULL,
  `taxable` decimal(15,2) DEFAULT NULL,
  `basis_type` varchar(200) DEFAULT NULL,
  `rel_type` varchar(200) DEFAULT NULL,
  `rel_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhrp_earnings_list_hr_records`
--

LOCK TABLES `himalay_tblhrp_earnings_list_hr_records` WRITE;
/*!40000 ALTER TABLE `himalay_tblhrp_earnings_list_hr_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblhrp_earnings_list_hr_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhrp_employees_timeshee_leaves`
--

DROP TABLE IF EXISTS `himalay_tblhrp_employees_timeshee_leaves`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhrp_employees_timeshee_leaves` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `month` date NOT NULL,
  `day_1` text DEFAULT '',
  `day_2` text DEFAULT '',
  `day_3` text DEFAULT '',
  `day_4` text DEFAULT '',
  `day_5` text DEFAULT '',
  `day_6` text DEFAULT '',
  `day_7` text DEFAULT '',
  `day_8` text DEFAULT '',
  `day_9` text DEFAULT '',
  `day_10` text DEFAULT '',
  `day_11` text DEFAULT '',
  `day_12` text DEFAULT '',
  `day_13` text DEFAULT '',
  `day_14` text DEFAULT '',
  `day_15` text DEFAULT '',
  `day_16` text DEFAULT '',
  `day_17` text DEFAULT '',
  `day_18` text DEFAULT '',
  `day_19` text DEFAULT '',
  `day_20` text DEFAULT '',
  `day_21` text DEFAULT '',
  `day_22` text DEFAULT '',
  `day_23` text DEFAULT '',
  `day_24` text DEFAULT '',
  `day_25` text DEFAULT '',
  `day_26` text DEFAULT '',
  `day_27` text DEFAULT '',
  `day_28` text DEFAULT '',
  `day_29` text DEFAULT '',
  `day_30` text DEFAULT '',
  `day_31` text DEFAULT '',
  `paid_leave` decimal(15,2) DEFAULT NULL,
  `unpaid_leave` decimal(15,2) DEFAULT NULL,
  `rel_type` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhrp_employees_timeshee_leaves`
--

LOCK TABLES `himalay_tblhrp_employees_timeshee_leaves` WRITE;
/*!40000 ALTER TABLE `himalay_tblhrp_employees_timeshee_leaves` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblhrp_employees_timeshee_leaves` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhrp_employees_timesheets`
--

DROP TABLE IF EXISTS `himalay_tblhrp_employees_timesheets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhrp_employees_timesheets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `month` date NOT NULL,
  `day_1` decimal(15,2) DEFAULT 0.00,
  `day_2` decimal(15,2) DEFAULT 0.00,
  `day_3` decimal(15,2) DEFAULT 0.00,
  `day_4` decimal(15,2) DEFAULT 0.00,
  `day_5` decimal(15,2) DEFAULT 0.00,
  `day_6` decimal(15,2) DEFAULT 0.00,
  `day_7` decimal(15,2) DEFAULT 0.00,
  `day_8` decimal(15,2) DEFAULT 0.00,
  `day_9` decimal(15,2) DEFAULT 0.00,
  `day_10` decimal(15,2) DEFAULT 0.00,
  `day_11` decimal(15,2) DEFAULT 0.00,
  `day_12` decimal(15,2) DEFAULT 0.00,
  `day_13` decimal(15,2) DEFAULT 0.00,
  `day_14` decimal(15,2) DEFAULT 0.00,
  `day_15` decimal(15,2) DEFAULT 0.00,
  `day_16` decimal(15,2) DEFAULT 0.00,
  `day_17` decimal(15,2) DEFAULT 0.00,
  `day_18` decimal(15,2) DEFAULT 0.00,
  `day_19` decimal(15,2) DEFAULT 0.00,
  `day_20` decimal(15,2) DEFAULT 0.00,
  `day_21` decimal(15,2) DEFAULT 0.00,
  `day_22` decimal(15,2) DEFAULT 0.00,
  `day_23` decimal(15,2) DEFAULT 0.00,
  `day_24` decimal(15,2) DEFAULT 0.00,
  `day_25` decimal(15,2) DEFAULT 0.00,
  `day_26` decimal(15,2) DEFAULT 0.00,
  `day_27` decimal(15,2) DEFAULT 0.00,
  `day_28` decimal(15,2) DEFAULT 0.00,
  `day_29` decimal(15,2) DEFAULT 0.00,
  `day_30` decimal(15,2) DEFAULT 0.00,
  `day_31` decimal(15,2) DEFAULT 0.00,
  `standard_workday` decimal(15,2) DEFAULT NULL,
  `actual_workday` decimal(15,2) DEFAULT NULL,
  `paid_leave` decimal(15,2) DEFAULT NULL,
  `unpaid_leave` decimal(15,2) DEFAULT NULL,
  `rel_type` varchar(100) DEFAULT NULL,
  `actual_workday_probation` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhrp_employees_timesheets`
--

LOCK TABLES `himalay_tblhrp_employees_timesheets` WRITE;
/*!40000 ALTER TABLE `himalay_tblhrp_employees_timesheets` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblhrp_employees_timesheets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhrp_employees_value`
--

DROP TABLE IF EXISTS `himalay_tblhrp_employees_value`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhrp_employees_value` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `month` date NOT NULL,
  `job_title` varchar(200) DEFAULT NULL,
  `income_tax_number` varchar(200) DEFAULT NULL,
  `residential_address` text DEFAULT NULL,
  `income_rebate_code` varchar(200) DEFAULT NULL,
  `income_tax_rate` varchar(200) DEFAULT NULL,
  `probationary_contracts` longtext DEFAULT NULL,
  `primary_contracts` longtext DEFAULT NULL,
  `rel_type` varchar(100) DEFAULT NULL,
  `probationary_effective` date DEFAULT NULL,
  `probationary_expiration` date DEFAULT NULL,
  `primary_effective` date DEFAULT NULL,
  `primary_expiration` date DEFAULT NULL,
  `bank_name` varchar(500) DEFAULT NULL,
  `account_number` varchar(200) DEFAULT NULL,
  `epf_no` text DEFAULT NULL,
  `social_security_no` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhrp_employees_value`
--

LOCK TABLES `himalay_tblhrp_employees_value` WRITE;
/*!40000 ALTER TABLE `himalay_tblhrp_employees_value` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblhrp_employees_value` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhrp_income_tax_rates`
--

DROP TABLE IF EXISTS `himalay_tblhrp_income_tax_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhrp_income_tax_rates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tax_bracket_value_from` decimal(15,2) DEFAULT NULL,
  `tax_bracket_value_to` decimal(15,2) DEFAULT NULL,
  `tax_rate` decimal(15,2) DEFAULT NULL,
  `equivalent_value` decimal(15,2) DEFAULT NULL,
  `effective_rate` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhrp_income_tax_rates`
--

LOCK TABLES `himalay_tblhrp_income_tax_rates` WRITE;
/*!40000 ALTER TABLE `himalay_tblhrp_income_tax_rates` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblhrp_income_tax_rates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhrp_income_tax_rebates`
--

DROP TABLE IF EXISTS `himalay_tblhrp_income_tax_rebates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhrp_income_tax_rebates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(200) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `value` decimal(15,2) DEFAULT NULL,
  `total` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhrp_income_tax_rebates`
--

LOCK TABLES `himalay_tblhrp_income_tax_rebates` WRITE;
/*!40000 ALTER TABLE `himalay_tblhrp_income_tax_rebates` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblhrp_income_tax_rebates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhrp_income_taxs`
--

DROP TABLE IF EXISTS `himalay_tblhrp_income_taxs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhrp_income_taxs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `month` date NOT NULL,
  `gross_amount` decimal(15,2) DEFAULT NULL,
  `total_deduction_amount` decimal(15,2) DEFAULT NULL,
  `income_tax` decimal(15,2) DEFAULT NULL,
  `payslip_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhrp_income_taxs`
--

LOCK TABLES `himalay_tblhrp_income_taxs` WRITE;
/*!40000 ALTER TABLE `himalay_tblhrp_income_taxs` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblhrp_income_taxs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhrp_insurance_list`
--

DROP TABLE IF EXISTS `himalay_tblhrp_insurance_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhrp_insurance_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(200) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `rate` decimal(15,2) DEFAULT NULL,
  `basis` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhrp_insurance_list`
--

LOCK TABLES `himalay_tblhrp_insurance_list` WRITE;
/*!40000 ALTER TABLE `himalay_tblhrp_insurance_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblhrp_insurance_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhrp_payroll_columns`
--

DROP TABLE IF EXISTS `himalay_tblhrp_payroll_columns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhrp_payroll_columns` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `column_key` text DEFAULT NULL,
  `taking_method` text DEFAULT NULL COMMENT 'get from system, caculator, constant... ',
  `function_name` text DEFAULT NULL COMMENT 'get value for method system',
  `value_related_to` text DEFAULT NULL COMMENT 'salary, allowance value...',
  `display_with_staff` varchar(10) DEFAULT 'true',
  `description` text DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `staff_id_created` int(11) NOT NULL,
  `order_display` int(11) DEFAULT NULL,
  `is_edit` varchar(100) DEFAULT 'yes',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhrp_payroll_columns`
--

LOCK TABLES `himalay_tblhrp_payroll_columns` WRITE;
/*!40000 ALTER TABLE `himalay_tblhrp_payroll_columns` DISABLE KEYS */;
INSERT INTO `himalay_tblhrp_payroll_columns` VALUES (1,'Staff ID','system','staff_id','','true','Staff ID','2025-07-09 13:01:17',0,1,'no'),(2,'Payslip Number','system','pay_slip_number','','true','Pay Slip Number','2025-07-09 13:01:17',0,2,'no'),(3,'Payment Run Date','system','payment_run_date','','true','Payment Run Date','2025-07-09 13:01:17',0,3,'no'),(4,'Employee Number','system','employee_number','','true','Employee Number','2025-07-09 13:01:17',0,4,'no'),(5,'Employee Name','system','employee_name','','true','Employee Name','2025-07-09 13:01:17',0,5,'no'),(6,'Deparment Name','system','dept_name','','true','Dept name Name','2025-07-09 13:01:17',0,6,'no'),(7,'Standard Working Time','system','standard_workday','','true','Standard working time of the month (hours)','2025-07-09 13:01:17',0,7,'no'),(8,'Actual Working Time of Formal contract','system','actual_workday','','true','Actual working time (hours)','2025-07-09 13:01:17',0,8,'no'),(9,'Actual Working Time of Probation contract','system','actual_workday_probation','','true','Actual Working Time of Probation contract (hours)','2025-07-09 13:01:17',0,9,'no'),(10,'Paid Leave Time','system','paid_leave','','true','Paid Leave Time (hours)','2025-07-09 13:01:17',0,10,'no'),(11,'Unpaid Leave Time','system','unpaid_leave','','true','Unpaid Leave Time (hours)','2025-07-09 13:01:17',0,11,'no'),(12,'Salary of the probationary contract','caculator','salary_of_the_probationary_contract','','true','Salary of the probationary contract','2025-07-09 13:01:17',0,12,'no'),(13,'Salary of the formal contract','caculator','salary_of_the_formal_contract','','true','Salary of the formal contract','2025-07-09 13:01:17',0,13,'no'),(14,'Gross Pay','caculator','gross_pay','','true','Gross Pay','2025-07-09 13:01:17',0,14,'no'),(15,'Total Deductions','caculator','total_deductions','','true','Total Deductions','2025-07-09 13:01:17',0,15,'no'),(16,'Total Insurance','caculator','total_insurance','','true','Total Insurance','2025-07-09 13:01:17',0,16,'no'),(17,'Income Tax Rebate Code','system','it_rebate_code','','true','IT Rebate Code','2025-07-09 13:01:17',0,17,'no'),(18,'Income Tax Rebate Value','system','it_rebate_value','','true','IT Rebate Value','2025-07-09 13:01:17',0,18,'no'),(19,'Taxable salary','caculator','taxable_salary','','true','Taxable salary','2025-07-09 13:01:17',0,19,'no'),(20,'Income Tax code','system','income_tax_code','','true','Income Tax code','2025-07-09 13:01:17',0,20,'no'),(21,'Personal Income Tax','system','income_tax_paye','','true','Personal Income Tax','2025-07-09 13:01:17',0,21,'no'),(22,'Commission Amount','system','commission_amount','','true','Commission','2025-07-09 13:01:17',0,22,'no'),(23,'Bonus Kpi','system','bonus_kpi','','true','Bonus Kpi','2025-07-09 13:01:17',0,23,'no'),(24,'Net Pay','caculator','net_pay','','true','Net Pay','2025-07-09 13:01:17',0,24,'no'),(25,'Total Cost','caculator','total_cost','','true','Total cost','2025-07-09 13:01:17',0,25,'no'),(26,'Total hours by tasks','system','total_hours_by_tasks','','true','Total hours by tasks','2025-07-09 13:01:17',0,16,'no'),(27,'Salary from tasks','system','salary_from_tasks','','true','Salary from tasks','2025-07-09 13:01:17',0,16,'no'),(28,'Bank Name','system','bank_name','','true','Bank Name','2025-07-09 13:01:17',0,17,'no'),(29,'Account Number','system','account_number','','true','Account Number','2025-07-09 13:01:17',0,17,'no'),(30,'EPF No','system','epf_no','','true','EPF No','2025-07-09 13:01:17',0,17,'no'),(31,'Social Security No','system','social_security_no','','true','Social Security No','2025-07-09 13:01:17',0,17,'no');
/*!40000 ALTER TABLE `himalay_tblhrp_payroll_columns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhrp_payslip_details`
--

DROP TABLE IF EXISTS `himalay_tblhrp_payslip_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhrp_payslip_details` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `payslip_id` int(11) DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `month` date NOT NULL,
  `pay_slip_number` text DEFAULT NULL,
  `payment_run_date` date NOT NULL,
  `employee_number` text DEFAULT NULL,
  `employee_name` text DEFAULT NULL,
  `dept_name` text DEFAULT NULL,
  `standard_workday` decimal(15,2) DEFAULT 0.00,
  `actual_workday` decimal(15,2) DEFAULT 0.00,
  `paid_leave` decimal(15,2) DEFAULT 0.00,
  `unpaid_leave` decimal(15,2) DEFAULT 0.00,
  `gross_pay` decimal(15,2) DEFAULT 0.00,
  `income_tax_paye` decimal(15,2) DEFAULT 0.00,
  `total_deductions` decimal(15,2) DEFAULT 0.00,
  `net_pay` decimal(15,2) DEFAULT 0.00,
  `it_rebate_code` text DEFAULT NULL,
  `it_rebate_value` decimal(15,2) DEFAULT 0.00,
  `income_tax_code` text DEFAULT NULL,
  `commission_amount` decimal(15,2) DEFAULT 0.00,
  `bonus_kpi` decimal(15,2) DEFAULT 0.00,
  `total_cost` decimal(15,2) DEFAULT 0.00,
  `total_insurance` decimal(15,2) DEFAULT 0.00,
  `json_data` longtext DEFAULT NULL,
  `salary_of_the_probationary_contract` decimal(15,2) DEFAULT 0.00,
  `salary_of_the_formal_contract` decimal(15,2) DEFAULT 0.00,
  `taxable_salary` decimal(15,2) DEFAULT 0.00,
  `actual_workday_probation` decimal(15,2) DEFAULT 0.00,
  `total_hours_by_tasks` decimal(15,2) DEFAULT 0.00,
  `salary_from_tasks` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhrp_payslip_details`
--

LOCK TABLES `himalay_tblhrp_payslip_details` WRITE;
/*!40000 ALTER TABLE `himalay_tblhrp_payslip_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblhrp_payslip_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhrp_payslip_pdf_templates`
--

DROP TABLE IF EXISTS `himalay_tblhrp_payslip_pdf_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhrp_payslip_pdf_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text DEFAULT NULL,
  `payslip_template_id` int(11) DEFAULT NULL,
  `content` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhrp_payslip_pdf_templates`
--

LOCK TABLES `himalay_tblhrp_payslip_pdf_templates` WRITE;
/*!40000 ALTER TABLE `himalay_tblhrp_payslip_pdf_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblhrp_payslip_pdf_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhrp_payslip_templates`
--

DROP TABLE IF EXISTS `himalay_tblhrp_payslip_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhrp_payslip_templates` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `templates_name` varchar(100) NOT NULL,
  `payslip_columns` longtext DEFAULT NULL,
  `payslip_id_copy` int(11) unsigned NOT NULL,
  `department_id` longtext DEFAULT NULL,
  `role_employees` longtext DEFAULT NULL,
  `staff_employees` longtext DEFAULT NULL,
  `payslip_template_data` longtext DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `staff_id_created` int(11) NOT NULL,
  `cell_data` longtext DEFAULT NULL,
  `except_staff` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhrp_payslip_templates`
--

LOCK TABLES `himalay_tblhrp_payslip_templates` WRITE;
/*!40000 ALTER TABLE `himalay_tblhrp_payslip_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblhrp_payslip_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhrp_payslips`
--

DROP TABLE IF EXISTS `himalay_tblhrp_payslips`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhrp_payslips` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `payslip_name` varchar(100) NOT NULL,
  `payslip_template_id` int(11) DEFAULT NULL,
  `payslip_month` date NOT NULL,
  `staff_id_created` int(11) NOT NULL,
  `date_created` datetime NOT NULL,
  `payslip_data` longtext DEFAULT NULL,
  `file_name` text DEFAULT NULL,
  `payslip_status` varchar(100) DEFAULT 'payslip_opening',
  `payslip_range` varchar(500) DEFAULT NULL,
  `pdf_template_id` int(11) DEFAULT NULL,
  `from_currency_id` int(11) DEFAULT 0,
  `from_currency_name` varchar(100) DEFAULT NULL,
  `from_currency_rate` decimal(15,6) NOT NULL DEFAULT 1.000000,
  `to_currency_id` int(11) DEFAULT 0,
  `to_currency_name` varchar(100) DEFAULT NULL,
  `to_currency_rate` decimal(15,6) NOT NULL DEFAULT 1.000000,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhrp_payslips`
--

LOCK TABLES `himalay_tblhrp_payslips` WRITE;
/*!40000 ALTER TABLE `himalay_tblhrp_payslips` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblhrp_payslips` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhrp_salary_deductions`
--

DROP TABLE IF EXISTS `himalay_tblhrp_salary_deductions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhrp_salary_deductions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `month` date NOT NULL,
  `deduction_list` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhrp_salary_deductions`
--

LOCK TABLES `himalay_tblhrp_salary_deductions` WRITE;
/*!40000 ALTER TABLE `himalay_tblhrp_salary_deductions` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblhrp_salary_deductions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhrp_salary_deductions_list`
--

DROP TABLE IF EXISTS `himalay_tblhrp_salary_deductions_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhrp_salary_deductions_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(200) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `rate` decimal(15,2) DEFAULT NULL,
  `basis` varchar(200) DEFAULT NULL,
  `earn_inclusion` varchar(200) DEFAULT NULL,
  `earn_exclusion` varchar(200) DEFAULT NULL,
  `earnings_max` decimal(15,2) DEFAULT NULL,
  `tax` decimal(15,2) DEFAULT NULL,
  `annual_tax_limit` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhrp_salary_deductions_list`
--

LOCK TABLES `himalay_tblhrp_salary_deductions_list` WRITE;
/*!40000 ALTER TABLE `himalay_tblhrp_salary_deductions_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblhrp_salary_deductions_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblhrp_staff_insurances`
--

DROP TABLE IF EXISTS `himalay_tblhrp_staff_insurances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblhrp_staff_insurances` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `month` date NOT NULL,
  `insurance_list` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblhrp_staff_insurances`
--

LOCK TABLES `himalay_tblhrp_staff_insurances` WRITE;
/*!40000 ALTER TABLE `himalay_tblhrp_staff_insurances` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblhrp_staff_insurances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblinternal_delivery_note`
--

DROP TABLE IF EXISTS `himalay_tblinternal_delivery_note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblinternal_delivery_note` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `internal_delivery_name` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `date_c` date DEFAULT NULL,
  `date_add` date DEFAULT NULL,
  `internal_delivery_code` varchar(100) DEFAULT NULL,
  `approval` int(11) DEFAULT 0 COMMENT 'status approval ',
  `addedfrom` int(11) DEFAULT NULL,
  `total_amount` decimal(15,2) DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblinternal_delivery_note`
--

LOCK TABLES `himalay_tblinternal_delivery_note` WRITE;
/*!40000 ALTER TABLE `himalay_tblinternal_delivery_note` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblinternal_delivery_note` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblinternal_delivery_note_detail`
--

DROP TABLE IF EXISTS `himalay_tblinternal_delivery_note_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblinternal_delivery_note_detail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `internal_delivery_id` int(11) NOT NULL,
  `commodity_code` varchar(100) DEFAULT NULL,
  `from_stock_name` text DEFAULT NULL,
  `to_stock_name` text DEFAULT NULL,
  `unit_id` text DEFAULT NULL,
  `available_quantity` text DEFAULT NULL,
  `quantities` text DEFAULT NULL,
  `unit_price` varchar(100) DEFAULT NULL,
  `into_money` varchar(100) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `commodity_name` text DEFAULT NULL,
  `serial_number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblinternal_delivery_note_detail`
--

LOCK TABLES `himalay_tblinternal_delivery_note_detail` WRITE;
/*!40000 ALTER TABLE `himalay_tblinternal_delivery_note_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblinternal_delivery_note_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblinventory_commodity_min`
--

DROP TABLE IF EXISTS `himalay_tblinventory_commodity_min`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblinventory_commodity_min` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `commodity_id` int(11) NOT NULL,
  `commodity_code` varchar(100) DEFAULT NULL,
  `commodity_name` varchar(100) DEFAULT NULL,
  `inventory_number_min` varchar(100) DEFAULT NULL,
  `inventory_number_max` varchar(100) DEFAULT '0',
  PRIMARY KEY (`id`,`commodity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblinventory_commodity_min`
--

LOCK TABLES `himalay_tblinventory_commodity_min` WRITE;
/*!40000 ALTER TABLE `himalay_tblinventory_commodity_min` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblinventory_commodity_min` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblinventory_manage`
--

DROP TABLE IF EXISTS `himalay_tblinventory_manage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblinventory_manage` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `warehouse_id` int(11) NOT NULL,
  `commodity_id` int(11) NOT NULL,
  `inventory_number` varchar(100) DEFAULT NULL,
  `date_manufacture` date DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `lot_number` varchar(100) DEFAULT NULL,
  `purchase_price` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`,`commodity_id`,`warehouse_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblinventory_manage`
--

LOCK TABLES `himalay_tblinventory_manage` WRITE;
/*!40000 ALTER TABLE `himalay_tblinventory_manage` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblinventory_manage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblinvoicepaymentrecords`
--

DROP TABLE IF EXISTS `himalay_tblinvoicepaymentrecords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblinvoicepaymentrecords` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoiceid` int(11) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `paymentmode` varchar(40) DEFAULT NULL,
  `paymentmethod` varchar(191) DEFAULT NULL,
  `date` date NOT NULL,
  `daterecorded` datetime NOT NULL,
  `note` mediumtext DEFAULT NULL,
  `transactionid` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `invoiceid` (`invoiceid`),
  KEY `paymentmethod` (`paymentmethod`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblinvoicepaymentrecords`
--

LOCK TABLES `himalay_tblinvoicepaymentrecords` WRITE;
/*!40000 ALTER TABLE `himalay_tblinvoicepaymentrecords` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblinvoicepaymentrecords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblinvoices`
--

DROP TABLE IF EXISTS `himalay_tblinvoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblinvoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sent` tinyint(1) NOT NULL DEFAULT 0,
  `datesend` datetime DEFAULT NULL,
  `clientid` int(11) NOT NULL,
  `deleted_customer_name` varchar(100) DEFAULT NULL,
  `number` int(11) NOT NULL,
  `prefix` varchar(50) DEFAULT NULL,
  `number_format` int(11) NOT NULL DEFAULT 0,
  `datecreated` datetime NOT NULL,
  `date` date NOT NULL,
  `duedate` date DEFAULT NULL,
  `currency` int(11) NOT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `total_tax` decimal(15,2) NOT NULL DEFAULT 0.00,
  `total` decimal(15,2) NOT NULL,
  `adjustment` decimal(15,2) DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `hash` varchar(32) NOT NULL,
  `status` int(11) DEFAULT 1,
  `clientnote` mediumtext DEFAULT NULL,
  `adminnote` mediumtext DEFAULT NULL,
  `last_overdue_reminder` date DEFAULT NULL,
  `last_due_reminder` date DEFAULT NULL,
  `cancel_overdue_reminders` int(11) NOT NULL DEFAULT 0,
  `allowed_payment_modes` longtext DEFAULT NULL,
  `token` longtext DEFAULT NULL,
  `discount_percent` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `discount_type` varchar(30) NOT NULL,
  `recurring` int(11) NOT NULL DEFAULT 0,
  `recurring_type` varchar(10) DEFAULT NULL,
  `custom_recurring` tinyint(1) NOT NULL DEFAULT 0,
  `cycles` int(11) NOT NULL DEFAULT 0,
  `total_cycles` int(11) NOT NULL DEFAULT 0,
  `is_recurring_from` int(11) DEFAULT NULL,
  `last_recurring_date` date DEFAULT NULL,
  `terms` mediumtext DEFAULT NULL,
  `sale_agent` int(11) NOT NULL DEFAULT 0,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT NULL,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT NULL,
  `include_shipping` tinyint(1) NOT NULL,
  `show_shipping_on_invoice` tinyint(1) NOT NULL DEFAULT 1,
  `show_quantity_as` int(11) NOT NULL DEFAULT 1,
  `project_id` int(11) DEFAULT 0,
  `subscription_id` int(11) NOT NULL DEFAULT 0,
  `perfex_saas_packageid` int(11) DEFAULT NULL,
  `short_link` varchar(100) DEFAULT NULL,
  `from_fleet` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `currency` (`currency`),
  KEY `clientid` (`clientid`),
  KEY `project_id` (`project_id`),
  KEY `sale_agent` (`sale_agent`),
  KEY `total` (`total`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblinvoices`
--

LOCK TABLES `himalay_tblinvoices` WRITE;
/*!40000 ALTER TABLE `himalay_tblinvoices` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblinvoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblitem_tax`
--

DROP TABLE IF EXISTS `himalay_tblitem_tax`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblitem_tax` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemid` int(11) NOT NULL,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) NOT NULL,
  `taxrate` decimal(15,2) NOT NULL,
  `taxname` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `itemid` (`itemid`),
  KEY `rel_id` (`rel_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblitem_tax`
--

LOCK TABLES `himalay_tblitem_tax` WRITE;
/*!40000 ALTER TABLE `himalay_tblitem_tax` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblitem_tax` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblitemable`
--

DROP TABLE IF EXISTS `himalay_tblitemable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblitemable` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(15) NOT NULL,
  `description` longtext NOT NULL,
  `long_description` longtext DEFAULT NULL,
  `qty` decimal(15,2) NOT NULL,
  `rate` decimal(15,2) NOT NULL,
  `unit` varchar(40) DEFAULT NULL,
  `item_order` int(11) DEFAULT NULL,
  `wh_delivered_quantity` decimal(15,2) DEFAULT 0.00,
  `item_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`),
  KEY `qty` (`qty`),
  KEY `rate` (`rate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblitemable`
--

LOCK TABLES `himalay_tblitemable` WRITE;
/*!40000 ALTER TABLE `himalay_tblitemable` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblitemable` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblitems`
--

DROP TABLE IF EXISTS `himalay_tblitems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblitems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` longtext NOT NULL,
  `long_description` mediumtext DEFAULT NULL,
  `rate` decimal(15,2) NOT NULL,
  `tax` int(11) DEFAULT NULL,
  `tax2` int(11) DEFAULT NULL,
  `unit` varchar(40) DEFAULT NULL,
  `group_id` int(11) NOT NULL DEFAULT 0,
  `product_type` varchar(100) DEFAULT NULL,
  `description_internal_transfers` text DEFAULT NULL,
  `description_receipts` text DEFAULT NULL,
  `description_delivery_orders` text DEFAULT NULL,
  `customer_lead_time` decimal(15,2) DEFAULT 0.00,
  `replenish_on_order` varchar(100) DEFAULT NULL,
  `supplier_taxes_id` text DEFAULT NULL,
  `description_sale` text DEFAULT NULL,
  `invoice_policy` varchar(100) DEFAULT 'ordered_quantities',
  `purchase_unit_measure` int(11) DEFAULT NULL,
  `can_be_sold` varchar(100) DEFAULT 'can_be_sold',
  `can_be_purchased` varchar(100) DEFAULT 'can_be_purchased',
  `can_be_manufacturing` varchar(100) DEFAULT 'can_be_manufacturing',
  `manufacture` varchar(100) DEFAULT NULL,
  `manufacturing_lead_time` decimal(15,2) DEFAULT 0.00,
  `weight` decimal(15,2) DEFAULT 0.00,
  `volume` decimal(15,2) DEFAULT 0.00,
  `hs_code` varchar(200) DEFAULT NULL,
  `commodity_code` varchar(100) NOT NULL,
  `commodity_barcode` text DEFAULT NULL,
  `commodity_type` int(11) DEFAULT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `origin` varchar(100) DEFAULT NULL,
  `color_id` int(11) DEFAULT NULL,
  `style_id` int(11) DEFAULT NULL,
  `model_id` int(11) DEFAULT NULL,
  `size_id` int(11) DEFAULT NULL,
  `unit_id` int(11) DEFAULT NULL,
  `sku_code` varchar(200) DEFAULT NULL,
  `sku_name` varchar(200) DEFAULT NULL,
  `purchase_price` decimal(15,2) DEFAULT NULL,
  `sub_group` varchar(200) DEFAULT NULL,
  `commodity_name` varchar(200) NOT NULL,
  `color` text DEFAULT NULL,
  `guarantee` text DEFAULT NULL,
  `profif_ratio` text DEFAULT NULL,
  `active` int(11) DEFAULT 1,
  `long_descriptions` longtext DEFAULT NULL,
  `without_checking_warehouse` int(11) DEFAULT 0,
  `series_id` text DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `attributes` longtext DEFAULT NULL,
  `parent_attributes` longtext DEFAULT NULL,
  `can_be_inventory` varchar(100) DEFAULT 'can_be_inventory',
  `from_vendor_item` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tax` (`tax`),
  KEY `tax2` (`tax2`),
  KEY `group_id` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblitems`
--

LOCK TABLES `himalay_tblitems` WRITE;
/*!40000 ALTER TABLE `himalay_tblitems` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblitems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblitems_groups`
--

DROP TABLE IF EXISTS `himalay_tblitems_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblitems_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `commodity_group_code` varchar(100) DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  `display` int(1) DEFAULT NULL,
  `note` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblitems_groups`
--

LOCK TABLES `himalay_tblitems_groups` WRITE;
/*!40000 ALTER TABLE `himalay_tblitems_groups` DISABLE KEYS */;
INSERT INTO `himalay_tblitems_groups` VALUES (1,'Fleet: Parts','FLEET_PARTS',10,1,'');
/*!40000 ALTER TABLE `himalay_tblitems_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblitems_of_vendor`
--

DROP TABLE IF EXISTS `himalay_tblitems_of_vendor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblitems_of_vendor` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `vendor_id` int(11) NOT NULL,
  `description` text NOT NULL,
  `long_description` text DEFAULT NULL,
  `rate` decimal(15,2) DEFAULT NULL,
  `tax` int(11) DEFAULT NULL,
  `tax2` int(11) DEFAULT NULL,
  `unit` varchar(40) DEFAULT NULL,
  `group_id` int(11) NOT NULL,
  `commodity_code` varchar(100) NOT NULL,
  `commodity_barcode` text DEFAULT NULL,
  `unit_id` int(11) DEFAULT NULL,
  `sku_code` varchar(200) DEFAULT NULL,
  `sku_name` varchar(200) DEFAULT NULL,
  `sub_group` varchar(200) DEFAULT NULL,
  `active` int(11) DEFAULT NULL,
  `parent` int(11) DEFAULT NULL,
  `attributes` longtext DEFAULT NULL,
  `parent_attributes` longtext DEFAULT NULL,
  `commodity_type` int(11) DEFAULT NULL,
  `origin` varchar(100) DEFAULT NULL,
  `commodity_name` varchar(200) NOT NULL,
  `series_id` text DEFAULT NULL,
  `long_descriptions` longtext DEFAULT NULL,
  `share_status` int(1) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblitems_of_vendor`
--

LOCK TABLES `himalay_tblitems_of_vendor` WRITE;
/*!40000 ALTER TABLE `himalay_tblitems_of_vendor` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblitems_of_vendor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tbljob_industry`
--

DROP TABLE IF EXISTS `himalay_tbljob_industry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tbljob_industry` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `industry_name` varchar(200) NOT NULL,
  `industry_description` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tbljob_industry`
--

LOCK TABLES `himalay_tbljob_industry` WRITE;
/*!40000 ALTER TABLE `himalay_tbljob_industry` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tbljob_industry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblknowedge_base_article_feedback`
--

DROP TABLE IF EXISTS `himalay_tblknowedge_base_article_feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblknowedge_base_article_feedback` (
  `articleanswerid` int(11) NOT NULL AUTO_INCREMENT,
  `articleid` int(11) NOT NULL,
  `answer` int(11) NOT NULL,
  `ip` varchar(40) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`articleanswerid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblknowedge_base_article_feedback`
--

LOCK TABLES `himalay_tblknowedge_base_article_feedback` WRITE;
/*!40000 ALTER TABLE `himalay_tblknowedge_base_article_feedback` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblknowedge_base_article_feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblknowledge_base`
--

DROP TABLE IF EXISTS `himalay_tblknowledge_base`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblknowledge_base` (
  `articleid` int(11) NOT NULL AUTO_INCREMENT,
  `articlegroup` int(11) NOT NULL,
  `subject` longtext NOT NULL,
  `description` mediumtext NOT NULL,
  `slug` longtext NOT NULL,
  `active` tinyint(4) NOT NULL,
  `datecreated` datetime NOT NULL,
  `article_order` int(11) NOT NULL DEFAULT 0,
  `staff_article` int(11) NOT NULL DEFAULT 0,
  `question_answers` int(11) DEFAULT 0,
  `file_name` varchar(255) DEFAULT '',
  `curator` varchar(11) DEFAULT '',
  `benchmark` int(11) DEFAULT 0,
  `score` int(11) DEFAULT 0,
  PRIMARY KEY (`articleid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblknowledge_base`
--

LOCK TABLES `himalay_tblknowledge_base` WRITE;
/*!40000 ALTER TABLE `himalay_tblknowledge_base` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblknowledge_base` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblknowledge_base_groups`
--

DROP TABLE IF EXISTS `himalay_tblknowledge_base_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblknowledge_base_groups` (
  `groupid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `group_slug` mediumtext DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `active` tinyint(4) NOT NULL,
  `color` varchar(10) DEFAULT '#28B8DA',
  `group_order` int(11) DEFAULT 0,
  PRIMARY KEY (`groupid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblknowledge_base_groups`
--

LOCK TABLES `himalay_tblknowledge_base_groups` WRITE;
/*!40000 ALTER TABLE `himalay_tblknowledge_base_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblknowledge_base_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tbllead_activity_log`
--

DROP TABLE IF EXISTS `himalay_tbllead_activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tbllead_activity_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `leadid` int(11) NOT NULL,
  `description` longtext NOT NULL,
  `additional_data` mediumtext DEFAULT NULL,
  `date` datetime NOT NULL,
  `staffid` int(11) NOT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `custom_activity` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tbllead_activity_log`
--

LOCK TABLES `himalay_tbllead_activity_log` WRITE;
/*!40000 ALTER TABLE `himalay_tbllead_activity_log` DISABLE KEYS */;
INSERT INTO `himalay_tbllead_activity_log` VALUES (1,1,'not_lead_activity_created','','2025-07-09 13:08:10',1,'faizan ahmad',0),(2,2,'not_lead_activity_created','','2025-07-09 13:08:31',1,'faizan ahmad',0);
/*!40000 ALTER TABLE `himalay_tbllead_activity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tbllead_integration_emails`
--

DROP TABLE IF EXISTS `himalay_tbllead_integration_emails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tbllead_integration_emails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` longtext DEFAULT NULL,
  `body` longtext DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  `leadid` int(11) NOT NULL,
  `emailid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tbllead_integration_emails`
--

LOCK TABLES `himalay_tbllead_integration_emails` WRITE;
/*!40000 ALTER TABLE `himalay_tbllead_integration_emails` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tbllead_integration_emails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblleads`
--

DROP TABLE IF EXISTS `himalay_tblleads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblleads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(65) DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `company` varchar(191) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `country` int(11) NOT NULL DEFAULT 0,
  `zip` varchar(15) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `assigned` int(11) NOT NULL DEFAULT 0,
  `dateadded` datetime NOT NULL,
  `from_form_id` int(11) NOT NULL DEFAULT 0,
  `status` int(11) NOT NULL,
  `source` int(11) NOT NULL,
  `lastcontact` datetime DEFAULT NULL,
  `dateassigned` date DEFAULT NULL,
  `last_status_change` datetime DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `website` varchar(150) DEFAULT NULL,
  `leadorder` int(11) DEFAULT 1,
  `phonenumber` varchar(50) DEFAULT NULL,
  `date_converted` datetime DEFAULT NULL,
  `lost` tinyint(1) NOT NULL DEFAULT 0,
  `junk` int(11) NOT NULL DEFAULT 0,
  `last_lead_status` int(11) NOT NULL DEFAULT 0,
  `is_imported_from_email_integration` tinyint(1) NOT NULL DEFAULT 0,
  `email_integration_uid` varchar(30) DEFAULT NULL,
  `is_public` tinyint(1) NOT NULL DEFAULT 0,
  `default_language` varchar(40) DEFAULT NULL,
  `client_id` int(11) NOT NULL DEFAULT 0,
  `lead_value` decimal(15,2) DEFAULT NULL,
  `vat` varchar(50) DEFAULT NULL,
  `from_ma_form_id` int(11) NOT NULL DEFAULT 0,
  `ma_point` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `company` (`company`),
  KEY `email` (`email`),
  KEY `assigned` (`assigned`),
  KEY `status` (`status`),
  KEY `source` (`source`),
  KEY `lastcontact` (`lastcontact`),
  KEY `dateadded` (`dateadded`),
  KEY `leadorder` (`leadorder`),
  KEY `from_form_id` (`from_form_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblleads`
--

LOCK TABLES `himalay_tblleads` WRITE;
/*!40000 ALTER TABLE `himalay_tblleads` DISABLE KEYS */;
INSERT INTO `himalay_tblleads` VALUES (1,'a127834a096424cfa2c57c3c8478cef1-9b03165404e403ce3d1e6c772946bd85','Naveen','','','',102,'','','','',1,'2025-07-09 13:08:10',0,2,2,'2025-07-09 13:08:10',NULL,NULL,1,'','',1,'09766732604',NULL,0,0,0,0,NULL,0,'',0,0.00,NULL,0,0),(2,'632f7de90e9ccc50bef80690964e3a8a-8368baa185a63839b019299698d4fab3','Naveen','','','',102,'','','','',1,'2025-07-09 13:08:31',0,2,2,'2025-07-09 13:08:31',NULL,NULL,1,'','',1,'09766732604',NULL,0,0,0,0,NULL,0,'',0,0.00,NULL,0,0);
/*!40000 ALTER TABLE `himalay_tblleads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblleads_email_integration`
--

DROP TABLE IF EXISTS `himalay_tblleads_email_integration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblleads_email_integration` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'the ID always must be 1',
  `active` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `imap_server` varchar(100) NOT NULL,
  `password` longtext NOT NULL,
  `check_every` int(11) NOT NULL DEFAULT 5,
  `responsible` int(11) NOT NULL,
  `lead_source` int(11) NOT NULL,
  `lead_status` int(11) NOT NULL,
  `encryption` varchar(3) DEFAULT NULL,
  `folder` varchar(100) NOT NULL,
  `last_run` varchar(50) DEFAULT NULL,
  `notify_lead_imported` tinyint(1) NOT NULL DEFAULT 1,
  `notify_lead_contact_more_times` tinyint(1) NOT NULL DEFAULT 1,
  `notify_type` varchar(20) DEFAULT NULL,
  `notify_ids` longtext DEFAULT NULL,
  `mark_public` int(11) NOT NULL DEFAULT 0,
  `only_loop_on_unseen_emails` tinyint(1) NOT NULL DEFAULT 1,
  `delete_after_import` int(11) NOT NULL DEFAULT 0,
  `create_task_if_customer` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblleads_email_integration`
--

LOCK TABLES `himalay_tblleads_email_integration` WRITE;
/*!40000 ALTER TABLE `himalay_tblleads_email_integration` DISABLE KEYS */;
INSERT INTO `himalay_tblleads_email_integration` VALUES (1,0,'','','',10,0,0,0,'tls','INBOX','',1,1,'assigned','',0,1,0,1);
/*!40000 ALTER TABLE `himalay_tblleads_email_integration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblleads_sources`
--

DROP TABLE IF EXISTS `himalay_tblleads_sources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblleads_sources` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblleads_sources`
--

LOCK TABLES `himalay_tblleads_sources` WRITE;
/*!40000 ALTER TABLE `himalay_tblleads_sources` DISABLE KEYS */;
INSERT INTO `himalay_tblleads_sources` VALUES (2,'Facebook'),(3,'Flexstage Events'),(1,'Google');
/*!40000 ALTER TABLE `himalay_tblleads_sources` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblleads_status`
--

DROP TABLE IF EXISTS `himalay_tblleads_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblleads_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `statusorder` int(11) DEFAULT NULL,
  `color` varchar(10) DEFAULT '#28B8DA',
  `isdefault` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblleads_status`
--

LOCK TABLES `himalay_tblleads_status` WRITE;
/*!40000 ALTER TABLE `himalay_tblleads_status` DISABLE KEYS */;
INSERT INTO `himalay_tblleads_status` VALUES (1,'Customer',1000,'#7cb342',1),(2,'Event Attendees',2,'#28B8DA',0);
/*!40000 ALTER TABLE `himalay_tblleads_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblleave_of_the_year`
--

DROP TABLE IF EXISTS `himalay_tblleave_of_the_year`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblleave_of_the_year` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `value` double DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblleave_of_the_year`
--

LOCK TABLES `himalay_tblleave_of_the_year` WRITE;
/*!40000 ALTER TABLE `himalay_tblleave_of_the_year` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblleave_of_the_year` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tbllist_widget`
--

DROP TABLE IF EXISTS `himalay_tbllist_widget`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tbllist_widget` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `add_from` int(11) NOT NULL,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(45) DEFAULT NULL,
  `layout` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tbllist_widget`
--

LOCK TABLES `himalay_tbllist_widget` WRITE;
/*!40000 ALTER TABLE `himalay_tbllist_widget` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tbllist_widget` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tbllistemails`
--

DROP TABLE IF EXISTS `himalay_tbllistemails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tbllistemails` (
  `emailid` int(11) NOT NULL AUTO_INCREMENT,
  `listid` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`emailid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tbllistemails`
--

LOCK TABLES `himalay_tbllistemails` WRITE;
/*!40000 ALTER TABLE `himalay_tbllistemails` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tbllistemails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblloy_card`
--

DROP TABLE IF EXISTS `himalay_tblloy_card`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblloy_card` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `add_from` int(11) NOT NULL,
  `date_create` date DEFAULT NULL,
  `subject_card` int(2) DEFAULT 0,
  `client_name` int(2) DEFAULT 0,
  `membership` int(2) DEFAULT 0,
  `company_name` int(2) DEFAULT 0,
  `member_since` int(2) DEFAULT 0,
  `custom_field` int(2) DEFAULT 0,
  `custom_field_content` varchar(200) DEFAULT NULL,
  `text_color` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblloy_card`
--

LOCK TABLES `himalay_tblloy_card` WRITE;
/*!40000 ALTER TABLE `himalay_tblloy_card` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblloy_card` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblloy_mbs_program`
--

DROP TABLE IF EXISTS `himalay_tblloy_mbs_program`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblloy_mbs_program` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `program_name` varchar(200) NOT NULL,
  `add_from` int(11) NOT NULL,
  `date_create` date DEFAULT NULL,
  `voucher_code` text NOT NULL,
  `discount` varchar(30) DEFAULT NULL,
  `discount_percent` int(5) DEFAULT NULL,
  `loyalty_point_from` decimal(15,0) DEFAULT NULL,
  `loyalty_point_to` decimal(15,0) DEFAULT NULL,
  `membership` text NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `note` text DEFAULT NULL,
  `voucher_value` decimal(15,2) DEFAULT 0.00,
  `formal` int(1) DEFAULT 1,
  `minium_purchase` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblloy_mbs_program`
--

LOCK TABLES `himalay_tblloy_mbs_program` WRITE;
/*!40000 ALTER TABLE `himalay_tblloy_mbs_program` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblloy_mbs_program` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblloy_mbs_rule`
--

DROP TABLE IF EXISTS `himalay_tblloy_mbs_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblloy_mbs_rule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `add_from` int(11) NOT NULL,
  `date_create` date DEFAULT NULL,
  `client_group` int(11) DEFAULT NULL,
  `client` text NOT NULL,
  `loyalty_point_from` decimal(15,0) DEFAULT NULL,
  `loyalty_point_to` decimal(15,0) DEFAULT NULL,
  `card` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblloy_mbs_rule`
--

LOCK TABLES `himalay_tblloy_mbs_rule` WRITE;
/*!40000 ALTER TABLE `himalay_tblloy_mbs_rule` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblloy_mbs_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblloy_program_detail`
--

DROP TABLE IF EXISTS `himalay_tblloy_program_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblloy_program_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mbs_program` int(11) NOT NULL,
  `rel_type` varchar(30) NOT NULL,
  `rel_id` text NOT NULL,
  `percent` int(5) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblloy_program_detail`
--

LOCK TABLES `himalay_tblloy_program_detail` WRITE;
/*!40000 ALTER TABLE `himalay_tblloy_program_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblloy_program_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblloy_redeem_log`
--

DROP TABLE IF EXISTS `himalay_tblloy_redeem_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblloy_redeem_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client` int(11) NOT NULL,
  `cart` int(11) DEFAULT NULL,
  `invoice` int(11) DEFAULT NULL,
  `time` datetime DEFAULT NULL,
  `old_point` decimal(10,0) DEFAULT NULL,
  `new_point` decimal(10,0) DEFAULT NULL,
  `redeep_from` decimal(10,0) DEFAULT NULL,
  `redeep_to` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblloy_redeem_log`
--

LOCK TABLES `himalay_tblloy_redeem_log` WRITE;
/*!40000 ALTER TABLE `himalay_tblloy_redeem_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblloy_redeem_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblloy_redemp_detail`
--

DROP TABLE IF EXISTS `himalay_tblloy_redemp_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblloy_redemp_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `loy_rule` int(11) NOT NULL,
  `rule_name` varchar(200) NOT NULL,
  `point_from` decimal(15,0) DEFAULT NULL,
  `point_to` decimal(15,0) DEFAULT NULL,
  `point_weight` decimal(15,2) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblloy_redemp_detail`
--

LOCK TABLES `himalay_tblloy_redemp_detail` WRITE;
/*!40000 ALTER TABLE `himalay_tblloy_redemp_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblloy_redemp_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblloy_rule`
--

DROP TABLE IF EXISTS `himalay_tblloy_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblloy_rule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(200) NOT NULL,
  `add_from` int(11) NOT NULL,
  `date_create` date DEFAULT NULL,
  `enable` int(2) DEFAULT 0,
  `redeemp_type` varchar(15) DEFAULT NULL,
  `min_poin_to_redeem` decimal(15,0) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `rule_base` varchar(30) DEFAULT NULL,
  `minium_purchase` decimal(15,0) DEFAULT NULL,
  `poin_awarded` decimal(15,0) DEFAULT NULL,
  `purchase_value` decimal(15,0) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `redeem_portal` int(1) DEFAULT 0,
  `redeem_pos` int(1) DEFAULT 0,
  `client_group` int(11) DEFAULT 0,
  `client` text NOT NULL,
  `max_amount_received` int(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblloy_rule`
--

LOCK TABLES `himalay_tblloy_rule` WRITE;
/*!40000 ALTER TABLE `himalay_tblloy_rule` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblloy_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblloy_rule_detail`
--

DROP TABLE IF EXISTS `himalay_tblloy_rule_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblloy_rule_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `loy_rule` int(11) NOT NULL,
  `rel_type` varchar(30) NOT NULL,
  `rel_id` text NOT NULL,
  `loyalty_point` decimal(15,0) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblloy_rule_detail`
--

LOCK TABLES `himalay_tblloy_rule_detail` WRITE;
/*!40000 ALTER TABLE `himalay_tblloy_rule_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblloy_rule_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblloy_transation`
--

DROP TABLE IF EXISTS `himalay_tblloy_transation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblloy_transation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference` varchar(30) NOT NULL,
  `invoice` int(11) DEFAULT NULL,
  `client` int(11) NOT NULL,
  `add_from` int(11) DEFAULT NULL,
  `date_create` datetime DEFAULT NULL,
  `loyalty_point` decimal(15,0) DEFAULT NULL,
  `type` varchar(30) DEFAULT NULL,
  `note` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblloy_transation`
--

LOCK TABLES `himalay_tblloy_transation` WRITE;
/*!40000 ALTER TABLE `himalay_tblloy_transation` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblloy_transation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblmail_queue`
--

DROP TABLE IF EXISTS `himalay_tblmail_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblmail_queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `engine` varchar(40) DEFAULT NULL,
  `email` varchar(191) NOT NULL,
  `cc` mediumtext DEFAULT NULL,
  `bcc` mediumtext DEFAULT NULL,
  `message` longtext NOT NULL,
  `alt_message` longtext DEFAULT NULL,
  `status` enum('pending','sending','sent','failed') DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `headers` mediumtext DEFAULT NULL,
  `attachments` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblmail_queue`
--

LOCK TABLES `himalay_tblmail_queue` WRITE;
/*!40000 ALTER TABLE `himalay_tblmail_queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblmail_queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblmailflow_email_templates`
--

DROP TABLE IF EXISTS `himalay_tblmailflow_email_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblmailflow_email_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_name` text DEFAULT NULL,
  `template_subject` text DEFAULT NULL,
  `template_content` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblmailflow_email_templates`
--

LOCK TABLES `himalay_tblmailflow_email_templates` WRITE;
/*!40000 ALTER TABLE `himalay_tblmailflow_email_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblmailflow_email_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblmailflow_newsletter_history`
--

DROP TABLE IF EXISTS `himalay_tblmailflow_newsletter_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblmailflow_newsletter_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sent_by` text DEFAULT NULL,
  `email_subject` text DEFAULT NULL,
  `email_content` text DEFAULT NULL,
  `total_emails_to_send` text DEFAULT NULL,
  `email_list` text DEFAULT NULL,
  `emails_sent` text DEFAULT NULL,
  `emails_failed` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblmailflow_newsletter_history`
--

LOCK TABLES `himalay_tblmailflow_newsletter_history` WRITE;
/*!40000 ALTER TABLE `himalay_tblmailflow_newsletter_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblmailflow_newsletter_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblmailflow_unsubscribed_emails`
--

DROP TABLE IF EXISTS `himalay_tblmailflow_unsubscribed_emails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblmailflow_unsubscribed_emails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblmailflow_unsubscribed_emails`
--

LOCK TABLES `himalay_tblmailflow_unsubscribed_emails` WRITE;
/*!40000 ALTER TABLE `himalay_tblmailflow_unsubscribed_emails` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblmailflow_unsubscribed_emails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblmaillistscustomfields`
--

DROP TABLE IF EXISTS `himalay_tblmaillistscustomfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblmaillistscustomfields` (
  `customfieldid` int(11) NOT NULL AUTO_INCREMENT,
  `listid` int(11) NOT NULL,
  `fieldname` varchar(150) NOT NULL,
  `fieldslug` varchar(100) NOT NULL,
  PRIMARY KEY (`customfieldid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblmaillistscustomfields`
--

LOCK TABLES `himalay_tblmaillistscustomfields` WRITE;
/*!40000 ALTER TABLE `himalay_tblmaillistscustomfields` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblmaillistscustomfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblmaillistscustomfieldvalues`
--

DROP TABLE IF EXISTS `himalay_tblmaillistscustomfieldvalues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblmaillistscustomfieldvalues` (
  `customfieldvalueid` int(11) NOT NULL AUTO_INCREMENT,
  `listid` int(11) NOT NULL,
  `customfieldid` int(11) NOT NULL,
  `emailid` int(11) NOT NULL,
  `value` varchar(100) NOT NULL,
  PRIMARY KEY (`customfieldvalueid`),
  KEY `listid` (`listid`),
  KEY `customfieldid` (`customfieldid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblmaillistscustomfieldvalues`
--

LOCK TABLES `himalay_tblmaillistscustomfieldvalues` WRITE;
/*!40000 ALTER TABLE `himalay_tblmaillistscustomfieldvalues` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblmaillistscustomfieldvalues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblmanage_leave`
--

DROP TABLE IF EXISTS `himalay_tblmanage_leave`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblmanage_leave` (
  `leave_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_staff` int(11) NOT NULL,
  `leave_date` int(11) DEFAULT NULL,
  `leave_year` int(11) DEFAULT NULL,
  `accumulated_leave` int(11) DEFAULT NULL,
  `seniority_leave` int(11) DEFAULT NULL,
  `borrow_leave` int(11) DEFAULT NULL,
  `actual_leave` int(11) DEFAULT NULL,
  `expected_leave` int(11) DEFAULT NULL,
  PRIMARY KEY (`leave_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblmanage_leave`
--

LOCK TABLES `himalay_tblmanage_leave` WRITE;
/*!40000 ALTER TABLE `himalay_tblmanage_leave` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblmanage_leave` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblmfa_history_login`
--

DROP TABLE IF EXISTS `himalay_tblmfa_history_login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblmfa_history_login` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staff` int(11) NOT NULL,
  `type` varchar(100) NOT NULL,
  `status` varchar(50) NOT NULL,
  `mess` text DEFAULT NULL,
  `time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblmfa_history_login`
--

LOCK TABLES `himalay_tblmfa_history_login` WRITE;
/*!40000 ALTER TABLE `himalay_tblmfa_history_login` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblmfa_history_login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblmfa_options`
--

DROP TABLE IF EXISTS `himalay_tblmfa_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblmfa_options` (
  `option_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(200) NOT NULL,
  `option_val` longtext DEFAULT NULL,
  `auto` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`option_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblmfa_options`
--

LOCK TABLES `himalay_tblmfa_options` WRITE;
/*!40000 ALTER TABLE `himalay_tblmfa_options` DISABLE KEYS */;
INSERT INTO `himalay_tblmfa_options` VALUES (1,'enable_mfa','0',1),(2,'enable_google_authenticator','0',1),(3,'enable_whatsapp','0',1),(4,'google_authenticator_secret_key','',1),(5,'enable_sms','0',1),(6,'twilio_account_sid','',1),(7,'twilio_auth_token','',1),(8,'twilio_phone_number','',1),(9,'twilio_phone_number_for_sms','',1),(10,'delete_history_after_months','6',1),(11,'whatsapp_message_template','Your login code for {{1}} is {{2}}',1),(12,'enable_gg_auth_for_users_have_not_role','0',1);
/*!40000 ALTER TABLE `himalay_tblmfa_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblmfa_security_code`
--

DROP TABLE IF EXISTS `himalay_tblmfa_security_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblmfa_security_code` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staff` int(11) NOT NULL,
  `code` text NOT NULL,
  `created_at` datetime NOT NULL,
  `type` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblmfa_security_code`
--

LOCK TABLES `himalay_tblmfa_security_code` WRITE;
/*!40000 ALTER TABLE `himalay_tblmfa_security_code` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblmfa_security_code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblmfa_send_code_logs`
--

DROP TABLE IF EXISTS `himalay_tblmfa_send_code_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblmfa_send_code_logs` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staff` int(11) NOT NULL,
  `type` varchar(100) NOT NULL,
  `status` varchar(50) NOT NULL,
  `mess` text DEFAULT NULL,
  `time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblmfa_send_code_logs`
--

LOCK TABLES `himalay_tblmfa_send_code_logs` WRITE;
/*!40000 ALTER TABLE `himalay_tblmfa_send_code_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblmfa_send_code_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblmigrations`
--

DROP TABLE IF EXISTS `himalay_tblmigrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblmigrations` (
  `version` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblmigrations`
--

LOCK TABLES `himalay_tblmigrations` WRITE;
/*!40000 ALTER TABLE `himalay_tblmigrations` DISABLE KEYS */;
INSERT INTO `himalay_tblmigrations` VALUES (310),(310);
/*!40000 ALTER TABLE `himalay_tblmigrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblmilestones`
--

DROP TABLE IF EXISTS `himalay_tblmilestones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblmilestones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `description_visible_to_customer` tinyint(1) DEFAULT 0,
  `start_date` date DEFAULT NULL,
  `due_date` date NOT NULL,
  `project_id` int(11) NOT NULL,
  `color` varchar(10) DEFAULT NULL,
  `milestone_order` int(11) NOT NULL DEFAULT 0,
  `datecreated` date NOT NULL,
  `hide_from_customer` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblmilestones`
--

LOCK TABLES `himalay_tblmilestones` WRITE;
/*!40000 ALTER TABLE `himalay_tblmilestones` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblmilestones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblmodules`
--

DROP TABLE IF EXISTS `himalay_tblmodules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblmodules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module_name` varchar(55) NOT NULL,
  `installed_version` varchar(11) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblmodules`
--

LOCK TABLES `himalay_tblmodules` WRITE;
/*!40000 ALTER TABLE `himalay_tblmodules` DISABLE KEYS */;
INSERT INTO `himalay_tblmodules` VALUES (1,'account_planning','1.0.0',1),(2,'accounting','1.3.4',1),(3,'affiliate_management','1.0.6',1),(4,'appointly','1.1.9',1),(5,'aws_integration','1.0.0',0),(6,'exports','1.0.0',1),(7,'loyalty','1.0.0',1),(8,'backup','2.3.0',1),(9,'facebook_leads_integration','1.0.0',0),(10,'fixed_equipment','1.0.9',1),(11,'fleet','1.0.0',1),(12,'flexstage','1.0.2',0),(13,'flexibackup','1.0.1',1),(14,'goals','2.3.0',1),(15,'hr_payroll','1.0.9',1),(16,'hr_profile','1.0.9',1),(17,'si_lead_followup','1.0.1',1),(18,'mailbox','2.0.1',0),(19,'mailflow','1.1.0',1),(20,'si_custom_status','1.0.5',1),(21,'manufacturing','1.0.5',1),(22,'menu_setup','2.3.0',1),(23,'mfa','1.0.1',1),(24,'perfex_office_theme','1.2.6',1),(25,'project_roadmap','1.0.0',1),(26,'purchase','1.5.0',1),(27,'razorpay','2.3.0',1),(28,'recruitment','1.2.3',1),(29,'resource_workload','1.0.7',1),(30,'surveys','2.3.0',1),(31,'theme_style','2.3.0',1),(32,'timesheets','1.1.9',1),(33,'user_mention','1.0.2',1),(34,'user_mention','1.0.2',1),(35,'warehouse','1.3.9',1),(36,'webhooks','1.1.0',0),(37,'whatsapp_api','1.2.1',1);
/*!40000 ALTER TABLE `himalay_tblmodules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblmrp_bill_of_material_details`
--

DROP TABLE IF EXISTS `himalay_tblmrp_bill_of_material_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblmrp_bill_of_material_details` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `bill_of_material_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL COMMENT 'Only Product variant do not get parent Product',
  `product_qty` decimal(15,2) DEFAULT 0.00,
  `unit_id` int(11) DEFAULT NULL,
  `apply_on_variants` text DEFAULT NULL,
  `operation_id` int(11) DEFAULT NULL,
  `display_order` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblmrp_bill_of_material_details`
--

LOCK TABLES `himalay_tblmrp_bill_of_material_details` WRITE;
/*!40000 ALTER TABLE `himalay_tblmrp_bill_of_material_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblmrp_bill_of_material_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblmrp_bill_of_materials`
--

DROP TABLE IF EXISTS `himalay_tblmrp_bill_of_materials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblmrp_bill_of_materials` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `bom_code` varchar(100) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `product_variant_id` int(11) DEFAULT NULL,
  `product_qty` decimal(15,2) DEFAULT 0.00,
  `unit_id` int(11) DEFAULT NULL,
  `routing_id` int(11) DEFAULT NULL,
  `bom_type` varchar(100) DEFAULT NULL,
  `ready_to_produce` varchar(200) DEFAULT NULL,
  `consumption` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblmrp_bill_of_materials`
--

LOCK TABLES `himalay_tblmrp_bill_of_materials` WRITE;
/*!40000 ALTER TABLE `himalay_tblmrp_bill_of_materials` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblmrp_bill_of_materials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblmrp_bom_changes_logs`
--

DROP TABLE IF EXISTS `himalay_tblmrp_bom_changes_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblmrp_bom_changes_logs` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `manufacturing_order_id` int(11) DEFAULT NULL,
  `parent_product_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `unit_id` int(11) DEFAULT 0,
  `change_type` text DEFAULT NULL,
  `change_quantity` decimal(15,2) DEFAULT 0.00,
  `created_at` datetime DEFAULT NULL,
  `staff_id` int(11) DEFAULT 0,
  `description` text DEFAULT NULL,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` text DEFAULT NULL COMMENT 'receipt_note, delivery_note',
  `check_availability` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblmrp_bom_changes_logs`
--

LOCK TABLES `himalay_tblmrp_bom_changes_logs` WRITE;
/*!40000 ALTER TABLE `himalay_tblmrp_bom_changes_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblmrp_bom_changes_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblmrp_manufacturing_order_details`
--

DROP TABLE IF EXISTS `himalay_tblmrp_manufacturing_order_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblmrp_manufacturing_order_details` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `manufacturing_order_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `unit_id` int(11) DEFAULT NULL,
  `qty_to_consume` decimal(15,2) DEFAULT 0.00,
  `qty_reserved` decimal(15,2) DEFAULT 0.00,
  `qty_done` decimal(15,2) DEFAULT 0.00,
  `check_inventory_qty` varchar(10) DEFAULT NULL,
  `warehouse_id` text DEFAULT NULL,
  `lot_number` text DEFAULT NULL,
  `expiry_date` text DEFAULT NULL,
  `available_quantity` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblmrp_manufacturing_order_details`
--

LOCK TABLES `himalay_tblmrp_manufacturing_order_details` WRITE;
/*!40000 ALTER TABLE `himalay_tblmrp_manufacturing_order_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblmrp_manufacturing_order_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblmrp_manufacturing_orders`
--

DROP TABLE IF EXISTS `himalay_tblmrp_manufacturing_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblmrp_manufacturing_orders` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `manufacturing_order_code` varchar(100) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL COMMENT 'Only Product variant do not get parent Product',
  `product_qty` decimal(15,2) DEFAULT 0.00,
  `unit_id` int(11) DEFAULT NULL,
  `bom_id` int(11) DEFAULT NULL,
  `routing_id` int(11) DEFAULT NULL,
  `date_deadline` datetime DEFAULT NULL,
  `date_plan_from` datetime DEFAULT NULL,
  `date_planned_start` datetime DEFAULT NULL,
  `date_planned_finished` datetime DEFAULT NULL,
  `status` varchar(100) DEFAULT 'draft',
  `material_availability_status` varchar(100) DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `components_warehouse_id` text DEFAULT NULL,
  `finished_products_warehouse_id` text DEFAULT NULL,
  `purchase_request_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblmrp_manufacturing_orders`
--

LOCK TABLES `himalay_tblmrp_manufacturing_orders` WRITE;
/*!40000 ALTER TABLE `himalay_tblmrp_manufacturing_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblmrp_manufacturing_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblmrp_option`
--

DROP TABLE IF EXISTS `himalay_tblmrp_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblmrp_option` (
  `option_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(200) NOT NULL,
  `option_val` longtext DEFAULT NULL,
  `auto` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`option_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblmrp_option`
--

LOCK TABLES `himalay_tblmrp_option` WRITE;
/*!40000 ALTER TABLE `himalay_tblmrp_option` DISABLE KEYS */;
INSERT INTO `himalay_tblmrp_option` VALUES (1,'bom_prefix','#BOM_',1),(2,'bom_number','1',1),(3,'routing_prefix','#RO_',1),(4,'routing_number','1',1),(5,'mo_prefix','#MO_',1),(6,'mo_number','1',1),(7,'cost_hour','0',1);
/*!40000 ALTER TABLE `himalay_tblmrp_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblmrp_routing_details`
--

DROP TABLE IF EXISTS `himalay_tblmrp_routing_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblmrp_routing_details` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `routing_id` int(11) NOT NULL,
  `operation` varchar(200) DEFAULT NULL,
  `work_center_id` int(11) DEFAULT NULL,
  `duration_computation` varchar(200) DEFAULT NULL,
  `based_on` decimal(15,2) DEFAULT 0.00,
  `default_duration` decimal(15,2) DEFAULT 0.00,
  `start_next_operation` varchar(200) DEFAULT NULL,
  `quantity_process` decimal(15,2) DEFAULT 0.00,
  `description` text DEFAULT NULL,
  `display_order` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblmrp_routing_details`
--

LOCK TABLES `himalay_tblmrp_routing_details` WRITE;
/*!40000 ALTER TABLE `himalay_tblmrp_routing_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblmrp_routing_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblmrp_routings`
--

DROP TABLE IF EXISTS `himalay_tblmrp_routings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblmrp_routings` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `routing_code` varchar(200) DEFAULT NULL,
  `routing_name` varchar(200) DEFAULT NULL,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblmrp_routings`
--

LOCK TABLES `himalay_tblmrp_routings` WRITE;
/*!40000 ALTER TABLE `himalay_tblmrp_routings` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblmrp_routings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblmrp_scrap`
--

DROP TABLE IF EXISTS `himalay_tblmrp_scrap`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblmrp_scrap` (
  `ScrapID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `manufacturing_order_id` int(11) NOT NULL,
  `product_id` int(255) NOT NULL,
  `unit_id` int(255) NOT NULL,
  `scrap_type` enum('component','finished_good') NOT NULL,
  `estimated_quantity` decimal(10,2) DEFAULT NULL,
  `actual_quantity` decimal(10,2) NOT NULL,
  `cost_allocation` decimal(10,2) DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`ScrapID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblmrp_scrap`
--

LOCK TABLES `himalay_tblmrp_scrap` WRITE;
/*!40000 ALTER TABLE `himalay_tblmrp_scrap` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblmrp_scrap` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblmrp_unit_measure_categories`
--

DROP TABLE IF EXISTS `himalay_tblmrp_unit_measure_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblmrp_unit_measure_categories` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `category_name` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblmrp_unit_measure_categories`
--

LOCK TABLES `himalay_tblmrp_unit_measure_categories` WRITE;
/*!40000 ALTER TABLE `himalay_tblmrp_unit_measure_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblmrp_unit_measure_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblmrp_work_centers`
--

DROP TABLE IF EXISTS `himalay_tblmrp_work_centers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblmrp_work_centers` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `work_center_name` varchar(200) DEFAULT NULL,
  `work_center_code` varchar(200) DEFAULT NULL,
  `working_hours` varchar(200) DEFAULT NULL,
  `time_efficiency` decimal(15,2) DEFAULT 0.00,
  `capacity` decimal(15,2) DEFAULT 0.00,
  `oee_target` decimal(15,2) DEFAULT 0.00,
  `time_start` decimal(15,2) DEFAULT 0.00,
  `time_stop` decimal(15,2) DEFAULT 0.00,
  `costs_hour` decimal(15,2) DEFAULT 0.00,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblmrp_work_centers`
--

LOCK TABLES `himalay_tblmrp_work_centers` WRITE;
/*!40000 ALTER TABLE `himalay_tblmrp_work_centers` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblmrp_work_centers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblmrp_work_order_details`
--

DROP TABLE IF EXISTS `himalay_tblmrp_work_order_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblmrp_work_order_details` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `work_order_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `to_consume` decimal(15,2) DEFAULT 0.00,
  `reserved` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblmrp_work_order_details`
--

LOCK TABLES `himalay_tblmrp_work_order_details` WRITE;
/*!40000 ALTER TABLE `himalay_tblmrp_work_order_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblmrp_work_order_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblmrp_work_order_time_trackings`
--

DROP TABLE IF EXISTS `himalay_tblmrp_work_order_time_trackings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblmrp_work_order_time_trackings` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `work_order_id` int(11) NOT NULL,
  `from_date` datetime DEFAULT NULL,
  `to_date` datetime DEFAULT NULL,
  `duration` decimal(15,2) DEFAULT 0.00,
  `staff_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblmrp_work_order_time_trackings`
--

LOCK TABLES `himalay_tblmrp_work_order_time_trackings` WRITE;
/*!40000 ALTER TABLE `himalay_tblmrp_work_order_time_trackings` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblmrp_work_order_time_trackings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblmrp_work_orders`
--

DROP TABLE IF EXISTS `himalay_tblmrp_work_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblmrp_work_orders` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `manufacturing_order_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `qty_produced` decimal(15,2) DEFAULT 0.00,
  `qty_production` decimal(15,2) DEFAULT 0.00,
  `qty_producing` decimal(15,2) DEFAULT 0.00,
  `unit_id` int(11) DEFAULT NULL,
  `routing_detail_id` int(11) DEFAULT NULL,
  `operation_name` text DEFAULT NULL,
  `work_center_id` int(11) DEFAULT NULL,
  `date_planned_start` datetime DEFAULT NULL,
  `date_planned_finished` datetime DEFAULT NULL,
  `date_start` datetime DEFAULT NULL,
  `date_finished` datetime DEFAULT NULL,
  `duration_expected` decimal(15,2) DEFAULT 0.00,
  `real_duration` decimal(15,2) DEFAULT 0.00,
  `status` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblmrp_work_orders`
--

LOCK TABLES `himalay_tblmrp_work_orders` WRITE;
/*!40000 ALTER TABLE `himalay_tblmrp_work_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblmrp_work_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblmrp_working_hour_time_off`
--

DROP TABLE IF EXISTS `himalay_tblmrp_working_hour_time_off`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblmrp_working_hour_time_off` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `working_hour_id` int(11) NOT NULL,
  `reason` varchar(200) DEFAULT NULL,
  `starting_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblmrp_working_hour_time_off`
--

LOCK TABLES `himalay_tblmrp_working_hour_time_off` WRITE;
/*!40000 ALTER TABLE `himalay_tblmrp_working_hour_time_off` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblmrp_working_hour_time_off` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblmrp_working_hour_times`
--

DROP TABLE IF EXISTS `himalay_tblmrp_working_hour_times`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblmrp_working_hour_times` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `working_hour_id` int(11) NOT NULL,
  `working_hour_name` varchar(200) DEFAULT NULL,
  `day_of_week` varchar(100) DEFAULT NULL,
  `day_period` varchar(100) DEFAULT NULL,
  `work_from` time DEFAULT NULL,
  `work_to` time DEFAULT NULL,
  `starting_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblmrp_working_hour_times`
--

LOCK TABLES `himalay_tblmrp_working_hour_times` WRITE;
/*!40000 ALTER TABLE `himalay_tblmrp_working_hour_times` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblmrp_working_hour_times` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblmrp_working_hours`
--

DROP TABLE IF EXISTS `himalay_tblmrp_working_hours`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblmrp_working_hours` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `working_hour_name` varchar(200) DEFAULT NULL,
  `hours_per_day` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblmrp_working_hours`
--

LOCK TABLES `himalay_tblmrp_working_hours` WRITE;
/*!40000 ALTER TABLE `himalay_tblmrp_working_hours` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblmrp_working_hours` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblnewsfeed_comment_likes`
--

DROP TABLE IF EXISTS `himalay_tblnewsfeed_comment_likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblnewsfeed_comment_likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `postid` int(11) NOT NULL,
  `commentid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `dateliked` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblnewsfeed_comment_likes`
--

LOCK TABLES `himalay_tblnewsfeed_comment_likes` WRITE;
/*!40000 ALTER TABLE `himalay_tblnewsfeed_comment_likes` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblnewsfeed_comment_likes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblnewsfeed_post_comments`
--

DROP TABLE IF EXISTS `himalay_tblnewsfeed_post_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblnewsfeed_post_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` mediumtext DEFAULT NULL,
  `userid` int(11) NOT NULL,
  `postid` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblnewsfeed_post_comments`
--

LOCK TABLES `himalay_tblnewsfeed_post_comments` WRITE;
/*!40000 ALTER TABLE `himalay_tblnewsfeed_post_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblnewsfeed_post_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblnewsfeed_post_likes`
--

DROP TABLE IF EXISTS `himalay_tblnewsfeed_post_likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblnewsfeed_post_likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `postid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `dateliked` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblnewsfeed_post_likes`
--

LOCK TABLES `himalay_tblnewsfeed_post_likes` WRITE;
/*!40000 ALTER TABLE `himalay_tblnewsfeed_post_likes` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblnewsfeed_post_likes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblnewsfeed_posts`
--

DROP TABLE IF EXISTS `himalay_tblnewsfeed_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblnewsfeed_posts` (
  `postid` int(11) NOT NULL AUTO_INCREMENT,
  `creator` int(11) NOT NULL,
  `datecreated` datetime NOT NULL,
  `visibility` varchar(100) NOT NULL,
  `content` mediumtext NOT NULL,
  `pinned` int(11) NOT NULL,
  `datepinned` datetime DEFAULT NULL,
  PRIMARY KEY (`postid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblnewsfeed_posts`
--

LOCK TABLES `himalay_tblnewsfeed_posts` WRITE;
/*!40000 ALTER TABLE `himalay_tblnewsfeed_posts` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblnewsfeed_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblnotes`
--

DROP TABLE IF EXISTS `himalay_tblnotes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblnotes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `date_contacted` datetime DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblnotes`
--

LOCK TABLES `himalay_tblnotes` WRITE;
/*!40000 ALTER TABLE `himalay_tblnotes` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblnotes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblnotifications`
--

DROP TABLE IF EXISTS `himalay_tblnotifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblnotifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `isread` int(11) NOT NULL DEFAULT 0,
  `isread_inline` tinyint(1) NOT NULL DEFAULT 0,
  `date` datetime NOT NULL,
  `description` mediumtext NOT NULL,
  `fromuserid` int(11) NOT NULL,
  `fromclientid` int(11) NOT NULL DEFAULT 0,
  `from_fullname` varchar(100) NOT NULL,
  `touserid` int(11) NOT NULL,
  `fromcompany` int(11) DEFAULT NULL,
  `link` longtext DEFAULT NULL,
  `additional_data` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblnotifications`
--

LOCK TABLES `himalay_tblnotifications` WRITE;
/*!40000 ALTER TABLE `himalay_tblnotifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblnotifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tbloptions`
--

DROP TABLE IF EXISTS `himalay_tbloptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tbloptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `value` longtext NOT NULL,
  `autoload` tinyint(1) NOT NULL DEFAULT 1,
  `annual_turnover` decimal(15,2) DEFAULT 0.00 COMMENT 'Yearly turnover (?) as declared by admin or fetched from GSTR-3B',
  `einvoice_enabled` tinyint(1) DEFAULT 0 COMMENT 'True/False – whether E-Invoicing is enabled for this company',
  `einvoice_enforced` tinyint(1) DEFAULT 0 COMMENT 'True if system decides it must be enabled (auto based on turnover)',
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=875 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tbloptions`
--

LOCK TABLES `himalay_tbloptions` WRITE;
/*!40000 ALTER TABLE `himalay_tbloptions` DISABLE KEYS */;
INSERT INTO `himalay_tbloptions` VALUES (1,'dateformat','Y-m-d|%Y-%m-%d',1,0.00,0,0),(2,'companyname','Himalay Ply',1,0.00,0,0),(3,'services','1',1,0.00,0,0),(4,'maximum_allowed_ticket_attachments','4',1,0.00,0,0),(5,'ticket_attachments_file_extensions','.jpg,.png,.pdf,.doc,.zip,.rar',1,0.00,0,0),(6,'staff_access_only_assigned_departments','1',1,0.00,0,0),(7,'use_knowledge_base','1',1,0.00,0,0),(8,'smtp_email','noreply@techdotbit.com',1,0.00,0,0),(10,'company_info_format','{company_name}<br />\r\n      {address}<br />\r\n      {city} {state}<br />\r\n      {country_code} {zip_code}<br />\r\n      {vat_number_with_label}',0,0.00,0,0),(11,'smtp_port','587',1,0.00,0,0),(12,'smtp_host','smtp.hostinger.com',1,0.00,0,0),(13,'smtp_email_charset','utf-8',1,0.00,0,0),(14,'default_timezone','Asia/Kolkata',1,0.00,0,0),(15,'clients_default_theme','perfex',1,0.00,0,0),(17,'tables_pagination_limit','25',1,0.00,0,0),(19,'allow_registration','1',1,0.00,0,0),(20,'knowledge_base_without_registration','1',1,0.00,0,0),(21,'email_signature','<br><br>\r\n--<br>\r\n<b>DOT ONE ERP System</b><br>\r\nAutomated Notification Service<br>\r\n? no-reply@techdotbit.in<br>\r\n? <a href=\"https://www.techdotbit.in\" target=\"_blank\">www.techdotbit.in</a><br>\r\n<small><i>Please do not reply to this email. For assistance, contact support@techdotbit.com</i></small>',1,0.00,0,0),(22,'default_staff_role','1',1,0.00,0,0),(23,'newsfeed_maximum_files_upload','10',1,0.00,0,0),(24,'contract_expiration_before','4',1,0.00,0,0),(25,'invoice_prefix','INV-',1,0.00,0,0),(26,'decimal_separator','.',1,0.00,0,0),(27,'thousand_separator',',',1,0.00,0,0),(34,'view_invoice_only_logged_in','1',1,0.00,0,0),(35,'invoice_number_format','1',1,0.00,0,0),(36,'next_invoice_number','1',0,0.00,0,0),(37,'active_language','english',1,0.00,0,0),(38,'invoice_number_decrement_on_delete','1',1,0.00,0,0),(39,'automatically_send_invoice_overdue_reminder_after','1',1,0.00,0,0),(40,'automatically_resend_invoice_overdue_reminder_after','3',1,0.00,0,0),(41,'expenses_auto_operations_hour','21',1,0.00,0,0),(42,'delete_only_on_last_invoice','1',1,0.00,0,0),(43,'delete_only_on_last_estimate','1',1,0.00,0,0),(44,'create_invoice_from_recurring_only_on_paid_invoices','0',1,0.00,0,0),(45,'allow_payment_amount_to_be_modified','0',1,0.00,0,0),(46,'rtl_support_client','0',1,0.00,0,0),(47,'limit_top_search_bar_results_to','10',1,0.00,0,0),(48,'estimate_prefix','EST-',1,0.00,0,0),(49,'next_estimate_number','1',0,0.00,0,0),(50,'estimate_number_decrement_on_delete','1',1,0.00,0,0),(51,'estimate_number_format','1',1,0.00,0,0),(52,'estimate_auto_convert_to_invoice_on_client_accept','1',1,0.00,0,0),(53,'exclude_estimate_from_client_area_with_draft_status','1',1,0.00,0,0),(54,'rtl_support_admin','0',1,0.00,0,0),(55,'last_cron_run','1752525125',1,0.00,0,0),(56,'show_sale_agent_on_estimates','1',1,0.00,0,0),(57,'show_sale_agent_on_invoices','1',1,0.00,0,0),(58,'predefined_terms_invoice','',1,0.00,0,0),(59,'predefined_terms_estimate','',1,0.00,0,0),(60,'default_task_priority','2',1,0.00,0,0),(62,'show_expense_reminders_on_calendar','1',1,0.00,0,0),(63,'only_show_contact_tickets','1',1,0.00,0,0),(64,'predefined_clientnote_invoice','',1,0.00,0,0),(65,'predefined_clientnote_estimate','',1,0.00,0,0),(66,'custom_pdf_logo_image_url','',1,0.00,0,0),(68,'invoice_due_after','30',1,0.00,0,0),(70,'google_calendar_main_calendar','',1,0.00,0,0),(71,'default_tax','a:0:{}',1,0.00,0,0),(72,'show_invoices_on_calendar','1',1,0.00,0,0),(73,'show_estimates_on_calendar','1',1,0.00,0,0),(74,'show_contracts_on_calendar','1',1,0.00,0,0),(75,'show_tasks_on_calendar','1',1,0.00,0,0),(76,'show_customer_reminders_on_calendar','1',1,0.00,0,0),(77,'output_client_pdfs_from_admin_area_in_client_language','0',1,0.00,0,0),(78,'show_lead_reminders_on_calendar','1',1,0.00,0,0),(79,'send_estimate_expiry_reminder_before','4',1,0.00,0,0),(80,'leads_default_source','',1,0.00,0,0),(81,'leads_default_status','',1,0.00,0,0),(82,'proposal_expiry_reminder_enabled','1',1,0.00,0,0),(83,'send_proposal_expiry_reminder_before','4',1,0.00,0,0),(84,'default_contact_permissions','a:8:{i:0;s:1:\"1\";i:1;s:1:\"2\";i:2;s:1:\"3\";i:3;s:1:\"4\";i:4;s:1:\"5\";i:5;s:1:\"6\";i:6;s:6:\"311301\";i:7;s:6:\"311302\";}',1,0.00,0,0),(85,'pdf_logo_width','150',1,0.00,0,0),(86,'access_tickets_to_none_staff_members','0',1,0.00,0,0),(87,'customer_default_country','102',1,0.00,0,0),(88,'view_estimate_only_logged_in','0',1,0.00,0,0),(89,'show_status_on_pdf_ei','1',1,0.00,0,0),(90,'email_piping_only_replies','0',1,0.00,0,0),(91,'email_piping_only_registered','0',1,0.00,0,0),(92,'default_view_calendar','dayGridMonth',1,0.00,0,0),(93,'email_piping_default_priority','2',1,0.00,0,0),(94,'total_to_words_lowercase','0',1,0.00,0,0),(95,'show_tax_per_item','1',1,0.00,0,0),(96,'total_to_words_enabled','0',1,0.00,0,0),(97,'receive_notification_on_new_ticket','1',0,0.00,0,0),(98,'autoclose_tickets_after','0',1,0.00,0,0),(99,'media_max_file_size_upload','10',1,0.00,0,0),(100,'client_staff_add_edit_delete_task_comments_first_hour','0',1,0.00,0,0),(101,'show_projects_on_calendar','1',1,0.00,0,0),(102,'leads_kanban_limit','50',1,0.00,0,0),(103,'tasks_reminder_notification_before','2',1,0.00,0,0),(104,'pdf_font','freesans',1,0.00,0,0),(105,'pdf_table_heading_color','#323a45',1,0.00,0,0),(106,'pdf_table_heading_text_color','#ffffff',1,0.00,0,0),(107,'pdf_font_size','10',1,0.00,0,0),(108,'default_leads_kanban_sort','leadorder',1,0.00,0,0),(109,'default_leads_kanban_sort_type','asc',1,0.00,0,0),(110,'allowed_files','.png,.jpg,.pdf,.doc,.docx,.xls,.xlsx,.zip,.rar,.txt',1,0.00,0,0),(111,'show_all_tasks_for_project_member','1',1,0.00,0,0),(112,'email_protocol','smtp',1,0.00,0,0),(113,'calendar_first_day','0',1,0.00,0,0),(115,'show_help_on_setup_menu','1',1,0.00,0,0),(116,'show_proposals_on_calendar','1',1,0.00,0,0),(117,'smtp_encryption','ssl',1,0.00,0,0),(119,'smtp_username','noreply@techdotbit.com',1,0.00,0,0),(120,'auto_stop_tasks_timers_on_new_timer','1',1,0.00,0,0),(121,'notification_when_customer_pay_invoice','1',1,0.00,0,0),(122,'calendar_invoice_color','#FF6F00',1,0.00,0,0),(123,'calendar_estimate_color','#FF6F00',1,0.00,0,0),(124,'calendar_proposal_color','#84c529',1,0.00,0,0),(125,'new_task_auto_assign_current_member','1',1,0.00,0,0),(126,'calendar_reminder_color','#03A9F4',1,0.00,0,0),(127,'calendar_contract_color','#B72974',1,0.00,0,0),(128,'calendar_project_color','#B72974',1,0.00,0,0),(129,'update_info_message','',1,0.00,0,0),(130,'show_estimate_reminders_on_calendar','1',1,0.00,0,0),(131,'show_invoice_reminders_on_calendar','1',1,0.00,0,0),(132,'show_proposal_reminders_on_calendar','1',1,0.00,0,0),(133,'proposal_due_after','7',1,0.00,0,0),(134,'allow_customer_to_change_ticket_status','0',1,0.00,0,0),(135,'lead_lock_after_convert_to_customer','0',1,0.00,0,0),(136,'default_proposals_pipeline_sort','pipeline_order',1,0.00,0,0),(137,'default_proposals_pipeline_sort_type','asc',1,0.00,0,0),(138,'default_estimates_pipeline_sort','pipeline_order',1,0.00,0,0),(139,'default_estimates_pipeline_sort_type','asc',1,0.00,0,0),(140,'use_recaptcha_customers_area','0',1,0.00,0,0),(141,'remove_decimals_on_zero','0',1,0.00,0,0),(142,'remove_tax_name_from_item_table','0',1,0.00,0,0),(143,'pdf_format_invoice','A4-PORTRAIT',1,0.00,0,0),(144,'pdf_format_estimate','A4-PORTRAIT',1,0.00,0,0),(145,'pdf_format_proposal','A4-PORTRAIT',1,0.00,0,0),(146,'pdf_format_payment','A4-PORTRAIT',1,0.00,0,0),(147,'pdf_format_contract','A4-PORTRAIT',1,0.00,0,0),(148,'swap_pdf_info','0',1,0.00,0,0),(149,'exclude_invoice_from_client_area_with_draft_status','1',1,0.00,0,0),(150,'cron_has_run_from_cli','1',1,0.00,0,0),(151,'hide_cron_is_required_message','0',0,0.00,0,0),(152,'auto_assign_customer_admin_after_lead_convert','1',1,0.00,0,0),(153,'show_transactions_on_invoice_pdf','1',1,0.00,0,0),(154,'show_pay_link_to_invoice_pdf','1',1,0.00,0,0),(155,'tasks_kanban_limit','50',1,0.00,0,0),(157,'estimates_pipeline_limit','50',1,0.00,0,0),(158,'proposals_pipeline_limit','50',1,0.00,0,0),(159,'proposal_number_prefix','PRO-',1,0.00,0,0),(160,'number_padding_prefixes','6',1,0.00,0,0),(161,'show_page_number_on_pdf','0',1,0.00,0,0),(162,'calendar_events_limit','4',1,0.00,0,0),(163,'show_setup_menu_item_only_on_hover','0',1,0.00,0,0),(164,'company_requires_vat_number_field','1',1,0.00,0,0),(165,'company_is_required','1',1,0.00,0,0),(166,'allow_contact_to_delete_files','0',1,0.00,0,0),(168,'di','1750847029',1,0.00,0,0),(169,'invoice_auto_operations_hour','21',1,0.00,0,0),(170,'use_minified_files','1',1,0.00,0,0),(171,'only_own_files_contacts','0',1,0.00,0,0),(172,'allow_primary_contact_to_view_edit_billing_and_shipping','0',1,0.00,0,0),(173,'estimate_due_after','7',1,0.00,0,0),(174,'staff_members_open_tickets_to_all_contacts','1',1,0.00,0,0),(175,'time_format','24',1,0.00,0,0),(176,'delete_activity_log_older_then','1',1,0.00,0,0),(177,'disable_language','0',1,0.00,0,0),(179,'email_header','<!doctype html>\r\n      <html>\r\n      <head>\r\n      <meta name=\"viewport\" content=\"width=device-width\" />\r\n      <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />\r\n      <style>\r\n      body {\r\n        background-color: #f6f6f6;\r\n        font-family: sans-serif;\r\n        -webkit-font-smoothing: antialiased;\r\n        font-size: 14px;\r\n        line-height: 1.4;\r\n        margin: 0;\r\n        padding: 0;\r\n        -ms-text-size-adjust: 100%;\r\n        -webkit-text-size-adjust: 100%;\r\n      }\r\n      table {\r\n        border-collapse: separate;\r\n        mso-table-lspace: 0pt;\r\n        mso-table-rspace: 0pt;\r\n        width: 100%;\r\n      }\r\n      table td {\r\n        font-family: sans-serif;\r\n        font-size: 14px;\r\n        vertical-align: top;\r\n      }\r\n      /* -------------------------------------\r\n      BODY & CONTAINER\r\n      ------------------------------------- */\r\n      .body {\r\n        background-color: #f6f6f6;\r\n        width: 100%;\r\n      }\r\n      /* Set a max-width, and make it display as block so it will automatically stretch to that width, but will also shrink down on a phone or something */\r\n      \r\n      .container {\r\n        display: block;\r\n        margin: 0 auto !important;\r\n        /* makes it centered */\r\n        max-width: 680px;\r\n        padding: 10px;\r\n        width: 680px;\r\n      }\r\n      /* This should also be a block element, so that it will fill 100% of the .container */\r\n      \r\n      .content {\r\n        box-sizing: border-box;\r\n        display: block;\r\n        margin: 0 auto;\r\n        max-width: 680px;\r\n        padding: 10px;\r\n      }\r\n      /* -------------------------------------\r\n      HEADER, FOOTER, MAIN\r\n      ------------------------------------- */\r\n      \r\n      .main {\r\n        background: #fff;\r\n        border-radius: 3px;\r\n        width: 100%;\r\n      }\r\n      .wrapper {\r\n        box-sizing: border-box;\r\n        padding: 20px;\r\n      }\r\n      .footer {\r\n        clear: both;\r\n        padding-top: 10px;\r\n        text-align: center;\r\n        width: 100%;\r\n      }\r\n      .footer td,\r\n      .footer p,\r\n      .footer span,\r\n      .footer a {\r\n        color: #999999;\r\n        font-size: 12px;\r\n        text-align: center;\r\n      }\r\n      hr {\r\n        border: 0;\r\n        border-bottom: 1px solid #f6f6f6;\r\n        margin: 20px 0;\r\n      }\r\n      /* -------------------------------------\r\n      RESPONSIVE AND MOBILE FRIENDLY STYLES\r\n      ------------------------------------- */\r\n      \r\n      @media only screen and (max-width: 620px) {\r\n        table[class=body] .content {\r\n          padding: 0 !important;\r\n        }\r\n        table[class=body] .container {\r\n          padding: 0 !important;\r\n          width: 100% !important;\r\n        }\r\n        table[class=body] .main {\r\n          border-left-width: 0 !important;\r\n          border-radius: 0 !important;\r\n          border-right-width: 0 !important;\r\n        }\r\n      }\r\n      </style>\r\n      </head>\r\n      <body class=\"\">\r\n      <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" class=\"body\">\r\n      <tr>\r\n      <td>&nbsp;</td>\r\n      <td class=\"container\">\r\n      <div class=\"content\">\r\n      <!-- START CENTERED WHITE CONTAINER -->\r\n      <table class=\"main\">\r\n      <!-- START MAIN CONTENT AREA -->\r\n      <tr>\r\n      <td class=\"wrapper\">\r\n      <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\r\n      <tr>\r\n      <td>',1,0.00,0,0),(180,'show_pdf_signature_invoice','1',0,0.00,0,0),(181,'show_pdf_signature_estimate','1',0,0.00,0,0),(182,'signature_image','',0,0.00,0,0),(183,'email_footer','</td>\r\n      </tr>\r\n      </table>\r\n      </td>\r\n      </tr>\r\n      <!-- END MAIN CONTENT AREA -->\r\n      </table>\r\n      <!-- START FOOTER -->\r\n      <div class=\"footer\">\r\n      <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\r\n      <tr>\r\n      <td class=\"content-block\">\r\n      <span>{companyname}</span>\r\n      </td>\r\n      </tr>\r\n      </table>\r\n      </div>\r\n      <!-- END FOOTER -->\r\n      <!-- END CENTERED WHITE CONTAINER -->\r\n      </div>\r\n      </td>\r\n      <td>&nbsp;</td>\r\n      </tr>\r\n      </table>\r\n      </body>\r\n      </html>',1,0.00,0,0),(184,'exclude_proposal_from_client_area_with_draft_status','1',1,0.00,0,0),(188,'pusher_realtime_notifications','0',1,0.00,0,0),(189,'pdf_format_statement','A4-PORTRAIT',1,0.00,0,0),(190,'pusher_cluster','',1,0.00,0,0),(191,'show_table_export_button','to_all',1,0.00,0,0),(192,'allow_staff_view_proposals_assigned','1',1,0.00,0,0),(193,'show_cloudflare_notice','1',0,0.00,0,0),(194,'task_modal_class','modal-lg',1,0.00,0,0),(195,'lead_modal_class','modal-lg',1,0.00,0,0),(196,'show_timesheets_overview_all_members_notice_admins','0',1,0.00,0,0),(197,'desktop_notifications','0',1,0.00,0,0),(198,'hide_notified_reminders_from_calendar','1',0,0.00,0,0),(199,'customer_info_format','{company_name}<br />\r\n      {street}<br />\r\n      {city} {state}<br />\r\n      {country_code} {zip_code}<br />\r\n      {vat_number_with_label}',0,0.00,0,0),(200,'timer_started_change_status_in_progress','1',0,0.00,0,0),(201,'default_ticket_reply_status','3',1,0.00,0,0),(202,'default_task_status','auto',1,0.00,0,0),(203,'email_queue_skip_with_attachments','1',1,0.00,0,0),(204,'email_queue_enabled','0',1,0.00,0,0),(205,'last_email_queue_retry','1752525125',1,0.00,0,0),(206,'auto_dismiss_desktop_notifications_after','0',1,0.00,0,0),(207,'proposal_info_format','{proposal_to}<br />\r\n      {address}<br />\r\n      {city} {state}<br />\r\n      {country_code} {zip_code}<br />\r\n      {phone}<br />\r\n      {email}',0,0.00,0,0),(208,'ticket_replies_order','asc',1,0.00,0,0),(209,'new_recurring_invoice_action','generate_and_send',0,0.00,0,0),(210,'bcc_emails','',0,0.00,0,0),(211,'email_templates_language_checks','',0,0.00,0,0),(212,'proposal_accept_identity_confirmation','1',0,0.00,0,0),(213,'estimate_accept_identity_confirmation','1',0,0.00,0,0),(214,'new_task_auto_follower_current_member','0',1,0.00,0,0),(215,'task_biillable_checked_on_creation','1',1,0.00,0,0),(216,'predefined_clientnote_credit_note','',1,0.00,0,0),(217,'predefined_terms_credit_note','',1,0.00,0,0),(218,'next_credit_note_number','1',1,0.00,0,0),(219,'credit_note_prefix','CN-',1,0.00,0,0),(220,'credit_note_number_decrement_on_delete','1',1,0.00,0,0),(221,'pdf_format_credit_note','A4-PORTRAIT',1,0.00,0,0),(222,'show_pdf_signature_credit_note','1',0,0.00,0,0),(223,'show_credit_note_reminders_on_calendar','1',1,0.00,0,0),(224,'show_amount_due_on_invoice','1',1,0.00,0,0),(225,'show_total_paid_on_invoice','1',1,0.00,0,0),(226,'show_credits_applied_on_invoice','1',1,0.00,0,0),(227,'staff_members_create_inline_lead_status','1',1,0.00,0,0),(228,'staff_members_create_inline_customer_groups','1',1,0.00,0,0),(229,'staff_members_create_inline_ticket_services','1',1,0.00,0,0),(230,'staff_members_save_tickets_predefined_replies','1',1,0.00,0,0),(231,'staff_members_create_inline_contract_types','1',1,0.00,0,0),(232,'staff_members_create_inline_expense_categories','1',1,0.00,0,0),(233,'show_project_on_credit_note','1',1,0.00,0,0),(234,'proposals_auto_operations_hour','21',1,0.00,0,0),(235,'estimates_auto_operations_hour','21',1,0.00,0,0),(236,'contracts_auto_operations_hour','21',1,0.00,0,0),(237,'credit_note_number_format','1',1,0.00,0,0),(238,'allow_non_admin_members_to_import_leads','0',1,0.00,0,0),(239,'e_sign_legal_text','By clicking on \"Sign\", I consent to be legally bound by this electronic representation of my signature.',1,0.00,0,0),(240,'show_pdf_signature_contract','1',1,0.00,0,0),(241,'view_contract_only_logged_in','0',1,0.00,0,0),(242,'show_subscriptions_in_customers_area','1',1,0.00,0,0),(243,'calendar_only_assigned_tasks','0',1,0.00,0,0),(244,'after_subscription_payment_captured','send_invoice_and_receipt',1,0.00,0,0),(245,'mail_engine','phpmailer',1,0.00,0,0),(246,'gdpr_enable_terms_and_conditions','0',1,0.00,0,0),(247,'privacy_policy','',1,0.00,0,0),(248,'terms_and_conditions','',1,0.00,0,0),(249,'gdpr_enable_terms_and_conditions_lead_form','0',1,0.00,0,0),(250,'gdpr_enable_terms_and_conditions_ticket_form','0',1,0.00,0,0),(251,'gdpr_contact_enable_right_to_be_forgotten','0',1,0.00,0,0),(252,'show_gdpr_in_customers_menu','1',1,0.00,0,0),(253,'show_gdpr_link_in_footer','1',1,0.00,0,0),(254,'enable_gdpr','0',1,0.00,0,0),(255,'gdpr_on_forgotten_remove_invoices_credit_notes','0',1,0.00,0,0),(256,'gdpr_on_forgotten_remove_estimates','0',1,0.00,0,0),(257,'gdpr_enable_consent_for_contacts','0',1,0.00,0,0),(258,'gdpr_consent_public_page_top_block','',1,0.00,0,0),(259,'gdpr_page_top_information_block','',1,0.00,0,0),(260,'gdpr_enable_lead_public_form','0',1,0.00,0,0),(261,'gdpr_show_lead_custom_fields_on_public_form','0',1,0.00,0,0),(262,'gdpr_lead_attachments_on_public_form','0',1,0.00,0,0),(263,'gdpr_enable_consent_for_leads','0',1,0.00,0,0),(264,'gdpr_lead_enable_right_to_be_forgotten','0',1,0.00,0,0),(265,'allow_staff_view_invoices_assigned','1',1,0.00,0,0),(266,'gdpr_data_portability_leads','0',1,0.00,0,0),(267,'gdpr_lead_data_portability_allowed','',1,0.00,0,0),(268,'gdpr_contact_data_portability_allowed','',1,0.00,0,0),(269,'gdpr_data_portability_contacts','0',1,0.00,0,0),(270,'allow_staff_view_estimates_assigned','1',1,0.00,0,0),(271,'gdpr_after_lead_converted_delete','0',1,0.00,0,0),(272,'gdpr_show_terms_and_conditions_in_footer','0',1,0.00,0,0),(273,'save_last_order_for_tables','0',1,0.00,0,0),(275,'customers_register_require_confirmation','0',1,0.00,0,0),(276,'allow_non_admin_staff_to_delete_ticket_attachments','0',1,0.00,0,0),(277,'receive_notification_on_new_ticket_replies','1',0,0.00,0,0),(279,'enable_google_picker','1',1,0.00,0,0),(280,'show_ticket_reminders_on_calendar','1',1,0.00,0,0),(281,'ticket_import_reply_only','0',1,0.00,0,0),(282,'visible_customer_profile_tabs','a:19:{s:7:\"profile\";b:0;s:8:\"contacts\";b:0;s:5:\"notes\";b:1;s:9:\"statement\";b:1;s:8:\"invoices\";b:1;s:8:\"payments\";b:1;s:9:\"proposals\";b:1;s:12:\"credit_notes\";b:1;s:9:\"estimates\";b:1;s:13:\"subscriptions\";b:1;s:8:\"expenses\";b:1;s:9:\"contracts\";b:1;s:8:\"projects\";b:1;s:5:\"tasks\";b:1;s:7:\"tickets\";b:1;s:11:\"attachments\";b:1;s:5:\"vault\";b:1;s:9:\"reminders\";b:1;s:3:\"map\";b:1;}',0,0.00,0,0),(283,'show_project_on_invoice','0',1,0.00,0,0),(284,'show_project_on_estimate','1',1,0.00,0,0),(285,'staff_members_create_inline_lead_source','1',1,0.00,0,0),(286,'lead_unique_validation','[\"email\"]',1,0.00,0,0),(287,'last_upgrade_copy_data','',1,0.00,0,0),(288,'custom_js_admin_scripts','',1,0.00,0,0),(289,'custom_js_customer_scripts','0',1,0.00,0,0),(294,'show_php_version_notice','1',0,0.00,0,0),(295,'recaptcha_ignore_ips','',1,0.00,0,0),(296,'show_task_reminders_on_calendar','1',1,0.00,0,0),(297,'customer_settings','true',1,0.00,0,0),(298,'tasks_reminder_notification_hour','21',1,0.00,0,0),(299,'allow_primary_contact_to_manage_other_contacts','0',1,0.00,0,0),(300,'items_table_amounts_exclude_currency_symbol','1',1,0.00,0,0),(301,'round_off_task_timer_option','0',1,0.00,0,0),(302,'round_off_task_timer_time','5',1,0.00,0,0),(304,'enable_support_menu_badges','0',1,0.00,0,0),(305,'attach_invoice_to_payment_receipt_email','0',1,0.00,0,0),(306,'invoice_due_notice_before','2',1,0.00,0,0),(307,'invoice_due_notice_resend_after','0',1,0.00,0,0),(308,'_leads_settings','true',1,0.00,0,0),(309,'show_estimate_request_in_customers_area','0',1,0.00,0,0),(310,'gdpr_enable_terms_and_conditions_estimate_request_form','0',1,0.00,0,0),(312,'automatically_stop_task_timer_after_hours','8',1,0.00,0,0),(313,'automatically_assign_ticket_to_first_staff_responding','0',1,0.00,0,0),(314,'reminder_for_completed_but_not_billed_tasks','0',1,0.00,0,0),(315,'staff_notify_completed_but_not_billed_tasks','',1,0.00,0,0),(316,'reminder_for_completed_but_not_billed_tasks_days','',1,0.00,0,0),(317,'tasks_reminder_notification_last_notified_day','',1,0.00,0,0),(318,'staff_related_ticket_notification_to_assignee_only','0',1,0.00,0,0),(319,'show_pdf_signature_proposal','1',1,0.00,0,0),(320,'enable_honeypot_spam_validation','1',1,0.00,0,0),(328,'automatically_set_logged_in_staff_sales_agent','1',1,0.00,0,0),(329,'contract_sign_reminder_every_days','0',1,0.00,0,0),(330,'last_updated_date','',1,0.00,0,0),(331,'v310_incompatible_tables','[]',1,0.00,0,0),(332,'upgraded_from_version','',0,0.00,0,0),(334,'sms_clickatell_active','0',1,0.00,0,0),(335,'sms_clickatell_initialized','1',1,0.00,0,0),(337,'sms_msg91_api_type','api',1,0.00,0,0),(339,'sms_msg91_active','0',1,0.00,0,0),(340,'sms_msg91_initialized','1',1,0.00,0,0),(341,'sms_twilio_account_sid','',1,0.00,0,0),(343,'sms_twilio_phone_number','',1,0.00,0,0),(345,'sms_twilio_active','0',1,0.00,0,0),(346,'sms_twilio_initialized','1',1,0.00,0,0),(347,'cr_date_cronjob_currency_rates','2025-07-14',1,0.00,0,0),(348,'cr_automatically_get_currency_rate','1',1,0.00,0,0),(349,'cr_global_amount_expiration','0',1,0.00,0,0),(350,'hr_profile_hide_menu','1',1,0.00,0,0),(351,'account_planning_enabled','1',1,0.00,0,0),(353,'mailbox_last_verification','1750867445',1,0.00,0,0),(355,'mailbox_enabled','1',1,0.00,0,0),(356,'mailbox_imap_server','',1,0.00,0,0),(357,'mailbox_encryption','',1,0.00,0,0),(358,'mailbox_folder_scan','Inbox',1,0.00,0,0),(359,'mailbox_check_every','3',1,0.00,0,0),(360,'mailbox_only_loop_on_unseen_emails','1',1,0.00,0,0),(361,'acc_first_month_of_financial_year','January',1,0.00,0,0),(362,'acc_first_month_of_tax_year','same_as_financial_year',1,0.00,0,0),(363,'acc_accounting_method','accrual',1,0.00,0,0),(364,'acc_close_the_books','0',1,0.00,0,0),(365,'acc_allow_changes_after_viewing','allow_changes_after_viewing_a_warning',1,0.00,0,0),(368,'acc_enable_account_numbers','0',1,0.00,0,0),(369,'acc_show_account_numbers','0',1,0.00,0,0),(370,'acc_closing_date','',1,0.00,0,0),(371,'acc_add_default_account','1',1,0.00,0,0),(372,'acc_add_default_account_new','0',1,0.00,0,0),(373,'acc_invoice_automatic_conversion','1',1,0.00,0,0),(374,'acc_payment_automatic_conversion','1',1,0.00,0,0),(375,'acc_credit_note_automatic_conversion','1',1,0.00,0,0),(376,'acc_credit_note_refund_automatic_conversion','1',1,0.00,0,0),(377,'acc_expense_automatic_conversion','1',1,0.00,0,0),(378,'acc_tax_automatic_conversion','1',1,0.00,0,0),(379,'acc_invoice_payment_account','66',1,0.00,0,0),(380,'acc_invoice_deposit_to','1',1,0.00,0,0),(381,'acc_payment_payment_account','1',1,0.00,0,0),(382,'acc_payment_deposit_to','13',1,0.00,0,0),(383,'acc_credit_note_payment_account','1',1,0.00,0,0),(384,'acc_credit_note_deposit_to','13',1,0.00,0,0),(385,'acc_credit_note_refund_payment_account','1',1,0.00,0,0),(386,'acc_credit_note_refund_deposit_to','13',1,0.00,0,0),(387,'acc_expense_payment_account','13',1,0.00,0,0),(388,'acc_expense_deposit_to','80',1,0.00,0,0),(389,'acc_tax_payment_account','29',1,0.00,0,0),(390,'acc_tax_deposit_to','1',1,0.00,0,0),(391,'acc_expense_tax_payment_account','13',1,0.00,0,0),(392,'acc_expense_tax_deposit_to','29',1,0.00,0,0),(393,'acc_active_payment_mode_mapping','1',1,0.00,0,0),(394,'acc_active_expense_category_mapping','1',1,0.00,0,0),(395,'acc_payment_expense_automatic_conversion','1',1,0.00,0,0),(396,'acc_payment_sale_automatic_conversion','1',1,0.00,0,0),(397,'acc_expense_payment_payment_account','1',1,0.00,0,0),(398,'acc_expense_payment_deposit_to','1',1,0.00,0,0),(399,'acc_pl_total_insurance_automatic_conversion','1',1,0.00,0,0),(400,'acc_pl_total_insurance_payment_account','13',1,0.00,0,0),(401,'acc_pl_total_insurance_deposit_to','32',1,0.00,0,0),(402,'acc_pl_tax_paye_automatic_conversion','1',1,0.00,0,0),(403,'acc_pl_tax_paye_payment_account','13',1,0.00,0,0),(404,'acc_pl_tax_paye_deposit_to','28',1,0.00,0,0),(405,'acc_pl_net_pay_automatic_conversion','1',1,0.00,0,0),(406,'acc_pl_net_pay_payment_account','13',1,0.00,0,0),(407,'acc_pl_net_pay_deposit_to','56',1,0.00,0,0),(408,'acc_wh_stock_import_automatic_conversion','1',1,0.00,0,0),(409,'acc_wh_stock_import_payment_account','87',1,0.00,0,0),(410,'acc_wh_stock_import_deposit_to','37',1,0.00,0,0),(411,'acc_wh_stock_export_automatic_conversion','1',1,0.00,0,0),(412,'acc_wh_stock_export_payment_account','37',1,0.00,0,0),(413,'acc_wh_stock_export_deposit_to','1',1,0.00,0,0),(414,'acc_wh_loss_adjustment_automatic_conversion','1',1,0.00,0,0),(415,'acc_wh_decrease_payment_account','37',1,0.00,0,0),(416,'acc_wh_decrease_deposit_to','1',1,0.00,0,0),(417,'acc_wh_increase_payment_account','87',1,0.00,0,0),(418,'acc_wh_increase_deposit_to','37',1,0.00,0,0),(419,'acc_wh_opening_stock_automatic_conversion','1',1,0.00,0,0),(420,'acc_wh_opening_stock_payment_account','88',1,0.00,0,0),(421,'acc_wh_opening_stock_deposit_to','37',1,0.00,0,0),(422,'acc_pur_order_automatic_conversion','1',1,0.00,0,0),(423,'acc_pur_order_payment_account','13',1,0.00,0,0),(424,'acc_pur_order_deposit_to','80',1,0.00,0,0),(425,'acc_pur_payment_automatic_conversion','1',1,0.00,0,0),(426,'acc_pur_payment_payment_account','16',1,0.00,0,0),(427,'acc_pur_payment_deposit_to','37',1,0.00,0,0),(428,'acc_mrp_manufacturing_order_automatic_conversion','1',1,0.00,0,0),(429,'acc_mrp_material_cost_payment_account','13',1,0.00,0,0),(430,'acc_mrp_material_cost_deposit_to','45',1,0.00,0,0),(431,'acc_mrp_labour_cost_payment_account','13',1,0.00,0,0),(432,'acc_mrp_labour_cost_deposit_to','18',1,0.00,0,0),(433,'acc_pur_order_return_automatic_conversion','1',1,0.00,0,0),(434,'acc_pur_order_return_payment_account','80',1,0.00,0,0),(435,'acc_pur_order_return_deposit_to','13',1,0.00,0,0),(436,'acc_pur_refund_automatic_conversion','1',1,0.00,0,0),(437,'acc_pur_refund_payment_account','37',1,0.00,0,0),(438,'acc_pur_refund_deposit_to','16',1,0.00,0,0),(439,'acc_pur_invoice_automatic_conversion','1',1,0.00,0,0),(440,'acc_pur_invoice_payment_account','13',1,0.00,0,0),(441,'acc_pur_invoice_deposit_to','80',1,0.00,0,0),(442,'acc_omni_sales_order_return_automatic_conversion','1',1,0.00,0,0),(443,'acc_omni_sales_order_return_payment_account','1',1,0.00,0,0),(444,'acc_omni_sales_order_return_deposit_to','66',1,0.00,0,0),(445,'acc_omni_sales_refund_automatic_conversion','1',1,0.00,0,0),(446,'acc_omni_sales_refund_payment_account','13',1,0.00,0,0),(447,'acc_omni_sales_refund_deposit_to','1',1,0.00,0,0),(448,'acc_routing_number_icon_a','a',1,0.00,0,0),(449,'acc_routing_number_icon_b','a',1,0.00,0,0),(450,'acc_bank_account_icon_a','a',1,0.00,0,0),(451,'acc_bank_account_icon_b','a',1,0.00,0,0),(452,'acc_current_check_no_icon_a','a',1,0.00,0,0),(453,'acc_current_check_no_icon_b','a',1,0.00,0,0),(454,'acc_check_type','type_1',1,0.00,0,0),(455,'acc_fe_asset_automatic_conversion','1',1,0.00,0,0),(456,'acc_fe_asset_payment_account','13',1,0.00,0,0),(457,'acc_fe_asset_deposit_to','1',1,0.00,0,0),(458,'acc_fe_license_automatic_conversion','1',1,0.00,0,0),(459,'acc_fe_license_payment_account','13',1,0.00,0,0),(460,'acc_fe_license_deposit_to','1',1,0.00,0,0),(461,'acc_fe_consumable_automatic_conversion','1',1,0.00,0,0),(462,'acc_fe_consumable_payment_account','13',1,0.00,0,0),(463,'acc_fe_consumable_deposit_to','1',1,0.00,0,0),(464,'acc_fe_component_automatic_conversion','1',1,0.00,0,0),(465,'acc_fe_component_payment_account','13',1,0.00,0,0),(466,'acc_fe_component_deposit_to','1',1,0.00,0,0),(467,'acc_fe_maintenance_automatic_conversion','1',1,0.00,0,0),(468,'acc_fe_maintenance_payment_account','13',1,0.00,0,0),(469,'acc_fe_maintenance_deposit_to','1',1,0.00,0,0),(470,'acc_fe_depreciation_automatic_conversion','1',1,0.00,0,0),(471,'acc_fe_depreciation_payment_account','13',1,0.00,0,0),(472,'acc_fe_depreciation_deposit_to','1',1,0.00,0,0),(473,'acc_wh_stock_export_profit_payment_account','66',1,0.00,0,0),(474,'acc_wh_stock_export_profit_deposit_to','1',1,0.00,0,0),(475,'update_bank_account_v124','1',1,0.00,0,0),(476,'update_income_statement_modifications_v125','1',1,0.00,0,0),(477,'acc_enable_income_statement_modifications','0',1,0.00,0,0),(478,'acc_invoice_discount_payment_account','1',1,0.00,0,0),(479,'acc_invoice_discount_deposit_to','19',1,0.00,0,0),(480,'acc_pur_tax_automatic_conversion','1',1,0.00,0,0),(481,'acc_pur_tax_payment_account','13',1,0.00,0,0),(482,'acc_pur_tax_deposit_to','29',1,0.00,0,0),(483,'acc_wh_stock_import_return_automatic_conversion','0',1,0.00,0,0),(484,'acc_wh_stock_import_return_payment_account','1',1,0.00,0,0),(485,'acc_wh_stock_import_return_deposit_to','37',1,0.00,0,0),(486,'acc_wh_stock_export_profit_automatic_conversion','1',1,0.00,0,0),(487,'affiliate_management_auto_approve_signup','1',1,0.00,0,0),(488,'affiliate_management_save_referral_client_info','1',1,0.00,0,0),(489,'affiliate_management_groups','{\"general\":{\"name\":\"General\",\"settings\":{\"affiliate_management_commission_enabled\":\"1\",\"affiliate_management_commission_rule\":\"first-invoice-payment\",\"affiliate_management_commission_type\":\"percent\",\"affiliate_management_commission_amount\":\"15\",\"affiliate_management_commission_cap\":\"-1\",\"affiliate_management_payout_min\":\"50\",\"affiliate_management_payout_methods\":\"bank, paypal\"}}}',1,0.00,0,0),(490,'affiliate_management_join_page_content','\n                    <div class=\"jumbotron text-center\">\n                        <h1>Welcome to Our Affiliate Program!</h1>\n                        <p>Join us and start earning today.</p>\n                        <a href=\"{SIGNUP_LINK}\" class=\"btn btn-primary btn-lg\">Join Now</a>\n                    </div>\n                    <div id=\"referral\" class=\"row\">\n                        <div class=\"col-md-6\">\n                            <h2>Referral Program</h2>\n                            <p>Join our referral program and start earning rewards!</p>\n                            <p>Earn {COMMISSION_AMOUNT} on every referral\'s first payment.</p>\n                            <p>Minimum payout is {MIN_PAYOUT}.</p>\n                        </div>\n                        <div class=\"col-md-6\">\n                            <h2>How It Works</h2>\n                            <p>1. Register for the affiliate program.</p>\n                            <p>2. Share your referral link with friends and colleagues.</p>\n                            <p>3. When someone signs up using your link and makes their first payment, you earn {COMMISSION_AMOUNT}.</p>\n                            <p>4. Once your earnings reach {MIN_PAYOUT}, you can request a payout.</p>\n                        </div>\n                    </div>\n                ',1,0.00,0,0),(491,'affiliate_management_affiliate_model','first-click',1,0.00,0,0),(492,'affiliate_management_enable_referral_removal','0',1,0.00,0,0),(493,'loyalty_setting','1',1,0.00,0,0),(494,'warehouse_selling_price_rule_profif_ratio','0',1,0.00,0,0),(495,'profit_rate_by_purchase_price_sale','0',1,0.00,0,0),(496,'warehouse_the_fractional_part','0',1,0.00,0,0),(497,'warehouse_integer_part','0',1,0.00,0,0),(498,'auto_create_goods_received','0',1,0.00,0,0),(499,'auto_create_goods_delivery','0',1,0.00,0,0),(500,'goods_receipt_warehouse','0',1,0.00,0,0),(501,'barcode_with_sku_code','0',1,0.00,0,0),(502,'revert_goods_receipt_goods_delivery','0',1,0.00,0,0),(503,'cancelled_invoice_reverse_inventory_delivery_voucher','0',1,0.00,0,0),(504,'uncancelled_invoice_create_inventory_delivery_voucher','0',1,0.00,0,0),(505,'inventory_auto_operations_hour','0',1,0.00,0,0),(506,'automatically_send_items_expired_before','0',1,0.00,0,0),(507,'inventorys_cronjob_active','0',1,0.00,0,0),(508,'inventory_cronjob_notification_recipients','',1,0.00,0,0),(509,'inventory_received_number_prefix','NK',1,0.00,0,0),(510,'next_inventory_received_mumber','1',1,0.00,0,0),(511,'inventory_delivery_number_prefix','XK',1,0.00,0,0),(512,'next_inventory_delivery_mumber','1',1,0.00,0,0),(513,'internal_delivery_number_prefix','ID',1,0.00,0,0),(514,'next_internal_delivery_mumber','1',1,0.00,0,0),(515,'item_sku_prefix','',1,0.00,0,0),(516,'goods_receipt_required_po','0',1,0.00,0,0),(517,'goods_delivery_required_po','0',1,0.00,0,0),(518,'goods_delivery_pdf_display','0',1,0.00,0,0),(519,'display_product_name_when_print_barcode','0',1,0.00,0,0),(520,'show_item_cf_on_pdf','0',1,0.00,0,0),(521,'goods_delivery_pdf_display_outstanding','0',1,0.00,0,0),(522,'goods_delivery_pdf_display_warehouse_lotnumber_bottom_infor','0',1,0.00,0,0),(523,'packing_list_number_prefix','PL',1,0.00,0,0),(524,'next_packing_list_number','1',1,0.00,0,0),(525,'wh_return_request_within_x_day','30',1,0.00,0,0),(526,'wh_fee_for_return_order','0',1,0.00,0,0),(527,'wh_return_policies_information','',1,0.00,0,0),(528,'wh_refund_loyaty_point','1',1,0.00,0,0),(529,'order_return_number_prefix','ReReturn',1,0.00,0,0),(530,'next_order_return_number','1',1,0.00,0,0),(531,'e_order_return_number_prefix','DEReturn',1,0.00,0,0),(532,'e_next_order_return_number','1',1,0.00,0,0),(533,'warehouse_receive_return_order ','0',1,0.00,0,0),(534,'wh_display_shipment_on_client_portal','1',1,0.00,0,0),(535,'wh_on_total_items','200',1,0.00,0,0),(536,'wh_products_by_serial','1',1,0.00,0,0),(537,'wh_shortened_form_pdf','0',1,0.00,0,0),(538,'wh_show_price_when_print_barcode','1',1,0.00,0,0),(539,'notify_customer_when_change_delivery_status','1',1,0.00,0,0),(540,'wh_hide_shipping_fee','0',1,0.00,0,0),(541,'lot_number_prefix','LOT',1,0.00,0,0),(542,'next_lot_number','1',1,0.00,0,0),(543,'auto_generate_lotnumber','0',1,0.00,0,0),(544,'custom_name_for_meter','m',1,0.00,0,0),(545,'custom_name_for_kg','kg',1,0.00,0,0),(546,'custom_name_for_m3','m3',1,0.00,0,0),(547,'packing_list_pdf_display_rate','1',1,0.00,0,0),(548,'packing_list_pdf_display_tax','1',1,0.00,0,0),(549,'packing_list_pdf_display_subtotal','1',1,0.00,0,0),(550,'packing_list_pdf_display_discount_percent','1',1,0.00,0,0),(551,'packing_list_pdf_display_discount_amount','1',1,0.00,0,0),(552,'packing_list_pdf_display_totalpayment','1',1,0.00,0,0),(553,'packing_list_pdf_display_summary','1',1,0.00,0,0),(554,'standard_workload','8',1,0.00,0,0),(555,'aside_menu_active','[]',1,0.00,0,0),(556,'setup_menu_active','[]',1,0.00,0,0),(585,'paymentmethod_affiliate_management_gateway_active','0',1,0.00,0,0),(586,'paymentmethod_affiliate_management_gateway_label','Affiliate Earnings',1,0.00,0,0),(587,'paymentmethod_affiliate_management_gateway_currencies','USD',0,0.00,0,0),(588,'paymentmethod_affiliate_management_gateway_default_selected','1',1,0.00,0,0),(589,'paymentmethod_affiliate_management_gateway_initialized','1',1,0.00,0,0),(590,'paymentmethod_authorize_acceptjs_active','0',1,0.00,0,0),(591,'paymentmethod_authorize_acceptjs_label','Authorize.net Accept.js',1,0.00,0,0),(595,'paymentmethod_authorize_acceptjs_description_dashboard','Payment for Invoice {invoice_number}',0,0.00,0,0),(596,'paymentmethod_authorize_acceptjs_currencies','USD',0,0.00,0,0),(597,'paymentmethod_authorize_acceptjs_test_mode_enabled','0',0,0.00,0,0),(598,'paymentmethod_authorize_acceptjs_default_selected','1',1,0.00,0,0),(599,'paymentmethod_authorize_acceptjs_initialized','1',1,0.00,0,0),(600,'paymentmethod_instamojo_active','0',1,0.00,0,0),(601,'paymentmethod_instamojo_label','Instamojo',1,0.00,0,0),(602,'paymentmethod_instamojo_fee_fixed','0',0,0.00,0,0),(603,'paymentmethod_instamojo_fee_percent','0',0,0.00,0,0),(606,'paymentmethod_instamojo_description_dashboard','Payment for Invoice {invoice_number}',0,0.00,0,0),(607,'paymentmethod_instamojo_currencies','INR',0,0.00,0,0),(608,'paymentmethod_instamojo_test_mode_enabled','1',0,0.00,0,0),(609,'paymentmethod_instamojo_default_selected','1',1,0.00,0,0),(610,'paymentmethod_instamojo_initialized','1',1,0.00,0,0),(611,'paymentmethod_mollie_active','0',1,0.00,0,0),(612,'paymentmethod_mollie_label','Mollie',1,0.00,0,0),(614,'paymentmethod_mollie_description_dashboard','Payment for Invoice {invoice_number}',0,0.00,0,0),(615,'paymentmethod_mollie_currencies','EUR',0,0.00,0,0),(616,'paymentmethod_mollie_test_mode_enabled','1',0,0.00,0,0),(617,'paymentmethod_mollie_default_selected','1',1,0.00,0,0),(618,'paymentmethod_mollie_initialized','1',1,0.00,0,0),(619,'paymentmethod_paypal_braintree_active','0',1,0.00,0,0),(620,'paymentmethod_paypal_braintree_label','Braintree',1,0.00,0,0),(624,'paymentmethod_paypal_braintree_currencies','USD',0,0.00,0,0),(625,'paymentmethod_paypal_braintree_paypal_enabled','1',0,0.00,0,0),(626,'paymentmethod_paypal_braintree_test_mode_enabled','1',0,0.00,0,0),(627,'paymentmethod_paypal_braintree_default_selected','1',1,0.00,0,0),(628,'paymentmethod_paypal_braintree_initialized','1',1,0.00,0,0),(629,'paymentmethod_paypal_checkout_active','0',1,0.00,0,0),(630,'paymentmethod_paypal_checkout_label','Paypal Smart Checkout',1,0.00,0,0),(631,'paymentmethod_paypal_checkout_fee_fixed','0',0,0.00,0,0),(632,'paymentmethod_paypal_checkout_fee_percent','0',0,0.00,0,0),(635,'paymentmethod_paypal_checkout_payment_description','Payment for Invoice {invoice_number}',0,0.00,0,0),(636,'paymentmethod_paypal_checkout_currencies','USD,CAD,EUR',0,0.00,0,0),(637,'paymentmethod_paypal_checkout_test_mode_enabled','1',0,0.00,0,0),(638,'paymentmethod_paypal_checkout_default_selected','1',1,0.00,0,0),(639,'paymentmethod_paypal_checkout_initialized','1',1,0.00,0,0),(640,'paymentmethod_paypal_active','0',1,0.00,0,0),(641,'paymentmethod_paypal_label','Paypal',1,0.00,0,0),(642,'paymentmethod_paypal_fee_fixed','0',0,0.00,0,0),(643,'paymentmethod_paypal_fee_percent','0',0,0.00,0,0),(644,'paymentmethod_paypal_username','',0,0.00,0,0),(646,'paymentmethod_paypal_signature','',0,0.00,0,0),(647,'paymentmethod_paypal_description_dashboard','Payment for Invoice {invoice_number}',0,0.00,0,0),(648,'paymentmethod_paypal_currencies','EUR,USD',0,0.00,0,0),(649,'paymentmethod_paypal_test_mode_enabled','1',0,0.00,0,0),(650,'paymentmethod_paypal_default_selected','1',1,0.00,0,0),(651,'paymentmethod_paypal_initialized','1',1,0.00,0,0),(652,'paymentmethod_payu_money_active','0',1,0.00,0,0),(653,'paymentmethod_payu_money_label','PayU Money',1,0.00,0,0),(654,'paymentmethod_payu_money_fee_fixed','0',0,0.00,0,0),(655,'paymentmethod_payu_money_fee_percent','0',0,0.00,0,0),(657,'paymentmethod_payu_money_salt','',0,0.00,0,0),(658,'paymentmethod_payu_money_description_dashboard','Payment for Invoice {invoice_number}',0,0.00,0,0),(659,'paymentmethod_payu_money_currencies','INR',0,0.00,0,0),(660,'paymentmethod_payu_money_test_mode_enabled','1',0,0.00,0,0),(661,'paymentmethod_payu_money_default_selected','1',1,0.00,0,0),(662,'paymentmethod_payu_money_initialized','1',1,0.00,0,0),(663,'paymentmethod_stripe_active','1',1,0.00,0,0),(664,'paymentmethod_stripe_label','Stripe Checkout',1,0.00,0,0),(665,'paymentmethod_stripe_fee_fixed','0',0,0.00,0,0),(666,'paymentmethod_stripe_fee_percent','0',0,0.00,0,0),(669,'paymentmethod_stripe_description_dashboard','Payment for Invoice {invoice_number}',0,0.00,0,0),(670,'paymentmethod_stripe_currencies','USD,CAD',0,0.00,0,0),(671,'paymentmethod_stripe_allow_primary_contact_to_update_credit_card','1',0,0.00,0,0),(672,'paymentmethod_stripe_default_selected','1',1,0.00,0,0),(673,'paymentmethod_stripe_initialized','1',1,0.00,0,0),(674,'paymentmethod_stripe_ideal_active','0',1,0.00,0,0),(675,'paymentmethod_stripe_ideal_label','Stripe iDEAL',1,0.00,0,0),(678,'paymentmethod_stripe_ideal_description_dashboard','Payment for Invoice {invoice_number}',0,0.00,0,0),(679,'paymentmethod_stripe_ideal_statement_descriptor','Payment for Invoice {invoice_number}',0,0.00,0,0),(680,'paymentmethod_stripe_ideal_currencies','EUR',0,0.00,0,0),(681,'paymentmethod_stripe_ideal_default_selected','1',1,0.00,0,0),(682,'paymentmethod_stripe_ideal_initialized','1',1,0.00,0,0),(683,'paymentmethod_two_checkout_active','0',1,0.00,0,0),(684,'paymentmethod_two_checkout_label','2Checkout',1,0.00,0,0),(685,'paymentmethod_two_checkout_fee_fixed','0',0,0.00,0,0),(686,'paymentmethod_two_checkout_fee_percent','0',0,0.00,0,0),(687,'paymentmethod_two_checkout_merchant_code','',0,0.00,0,0),(689,'paymentmethod_two_checkout_description','Payment for Invoice {invoice_number}',0,0.00,0,0),(690,'paymentmethod_two_checkout_currencies','USD, EUR, GBP',0,0.00,0,0),(691,'paymentmethod_two_checkout_test_mode_enabled','1',0,0.00,0,0),(692,'paymentmethod_two_checkout_default_selected','1',1,0.00,0,0),(693,'paymentmethod_two_checkout_initialized','1',1,0.00,0,0),(736,'sms_trigger_invoice_overdue_notice','',0,0.00,0,0),(737,'sms_trigger_invoice_due_notice','',0,0.00,0,0),(738,'sms_trigger_invoice_payment_recorded','',0,0.00,0,0),(739,'sms_trigger_estimate_expiration_reminder','',0,0.00,0,0),(740,'sms_trigger_proposal_expiration_reminder','',0,0.00,0,0),(741,'sms_trigger_proposal_new_comment_to_customer','',0,0.00,0,0),(742,'sms_trigger_proposal_new_comment_to_staff','',0,0.00,0,0),(743,'sms_trigger_contract_new_comment_to_customer','',0,0.00,0,0),(744,'sms_trigger_contract_new_comment_to_staff','',0,0.00,0,0),(745,'sms_trigger_contract_expiration_reminder','',0,0.00,0,0),(746,'sms_trigger_contract_sign_reminder_to_customer','',0,0.00,0,0),(747,'sms_trigger_staff_reminder','',0,0.00,0,0),(748,'perfex_office_theme_customers','1',1,0.00,0,0),(752,'required_register_fields','[\"contact_firstname\",\"contact_lastname\"]',1,0.00,0,0),(756,'pur_invoice_auto_operations_hour','21',1,0.00,0,0),(757,'next_debit_note_number','1',1,0.00,0,0),(758,'debit_note_number_format','1',1,0.00,0,0),(759,'debit_note_prefix','DN-',1,0.00,0,0),(760,'show_purchase_tax_column','1',1,0.00,0,0),(761,'po_only_prefix_and_number','0',1,0.00,0,0),(762,'pur_return_request_within_x_day','30',1,0.00,0,0),(763,'pur_fee_for_return_order','0',1,0.00,0,0),(764,'pur_return_policies_information','',1,0.00,0,0),(765,'pur_order_return_number_prefix','OReturn',1,0.00,0,0),(766,'next_pur_order_return_number','1',1,0.00,0,0),(767,'send_email_welcome_for_new_contact','1',1,0.00,0,0),(768,'reset_purchase_order_number_every_month','1',1,0.00,0,0),(769,'pur_company_address','',1,0.00,0,0),(770,'pur_company_city','',1,0.00,0,0),(771,'pur_company_state','',1,0.00,0,0),(772,'pur_company_zipcode','',1,0.00,0,0),(773,'pur_company_country_code','',1,0.00,0,0),(774,'allow_vendors_to_register','1',1,0.00,0,0),(775,'pur_company_country_text','',1,0.00,0,0),(776,'whatsapp_api_verification_id','38690826',1,0.00,0,0),(777,'whatsapp_api_last_verification','999999999',1,0.00,0,0),(778,'whatsapp_api_verified','1',1,0.00,0,0),(779,'whatsapp_api_heartbeat','1',1,0.00,0,0),(780,'whatsapp_api_enabled','1',1,0.00,0,0),(781,'recruitment_create_campaign_with_plan ','1',1,0.00,0,0),(782,'display_quantity_to_be_recruited','1',1,0.00,0,0),(783,'candidate_code_prefix','ID',1,0.00,0,0),(784,'candidate_code_number','1',1,0.00,0,0),(785,'send_email_welcome_for_new_candidate','1',1,0.00,0,0),(786,'flexibackup_files_backup_schedule','1',1,0.00,0,0),(787,'flexibackup_database_backup_schedule','1',1,0.00,0,0),(788,'flexibackup_remote_storage','',1,0.00,0,0),(789,'last_flexi_backup_file','',1,0.00,0,0),(790,'last_flexi_backup_database','',1,0.00,0,0),(791,'paymentmethod_razorpay_active','1',1,0.00,0,0),(792,'paymentmethod_razorpay_label','Razorpay',1,0.00,0,0),(793,'paymentmethod_razorpay_key_id','rzp_live_HI0V07stWalvUa',0,0.00,0,0),(794,'paymentmethod_razorpay_key_secret','a47c2140b2a4df8aa3a442d35af770c4d785e019650f49d8c66bae44850594e3b08118198a17d37714082727d27cfa11330653dea32ef9e0a937380752e6b94dBGCxpf++61fQn/fsjYXvgN7HaninjzUIZC6UAooL0+RV3RP+gOfX6yji7P1z6oQn',0,0.00,0,0),(795,'paymentmethod_razorpay_description_dashboard','Payment for Invoice {invoice_number}',0,0.00,0,0),(796,'paymentmethod_razorpay_currencies','INR',0,0.00,0,0),(797,'paymentmethod_razorpay_default_selected','1',1,0.00,0,0),(798,'paymentmethod_razorpay_initialized','1',1,0.00,0,0),(799,'ma_insert_email_template_default','1',1,0.00,0,0),(800,'si_lead_followup_activated','0',1,0.00,0,0),(801,'si_lead_followup_activation_code','',1,0.00,0,0),(802,'sms_trigger_si_lead_followup_custom_sms','',1,0.00,0,0),(803,'si_lead_followup_trigger_schedule_sms_last_run','2025-07-15 02:02:05',1,0.00,0,0),(804,'si_lead_followup_clear_schedule_sms_log_after_days','30',1,0.00,0,0),(805,'si_custom_status_edit_default_status_tasks','0',1,0.00,0,0),(806,'si_custom_status_edit_default_status_projects','0',1,0.00,0,0),(807,'perfex_saas_installation_secured','true',0,0.00,0,0),(808,'acc_close_book_password','',1,0.00,0,0),(809,'acc_close_book_passwordr','',1,0.00,0,0),(810,'appointly_responsible_person','',1,0.00,0,0),(811,'callbacks_responsible_person','',1,0.00,0,0),(812,'appointly_show_clients_schedule_button','0',1,0.00,0,0),(813,'appointly_tab_on_clients_page','0',1,0.00,0,0),(814,'appointly_also_delete_in_google_calendar','1',1,0.00,0,0),(815,'appointments_show_past_times','1',1,0.00,0,0),(816,'appointments_disable_weekends','1',1,0.00,0,0),(817,'appointly_client_meeting_approved_default','0',1,0.00,0,0),(818,'appointly_google_client_secret','',1,0.00,0,0),(819,'appointly_outlook_client_id','',1,0.00,0,0),(820,'appointly_available_hours','[\"08:00\",\"08:30\",\"09:00\",\"09:30\",\"10:00\",\"10:30\",\"11:00\",\"11:30\",\"12:00\",\"12:30\",\"13:00\",\"13:30\",\"14:00\",\"14:30\",\"15:00\",\"15:30\",\"16:00\",\"16:30\",\"17:00\"]',1,0.00,0,0),(821,'appointly_default_feedbacks','[\"0\",\"1\",\"2\",\"3\",\"4\",\"5\",\"6\"]',1,0.00,0,0),(822,'appointly_busy_times_enabled','1',1,0.00,0,0),(823,'callbacks_mode_enabled','1',1,0.00,0,0),(824,'appointly_appointments_recaptcha','0',1,0.00,0,0),(825,'fe_googlemap_api_key','',1,0.00,0,0),(826,'fe_show_public_page','1',1,0.00,0,0),(827,'fe_inventory_receiving_prefix','IR',1,0.00,0,0),(828,'fe_next_inventory_receiving_mumber','1',1,0.00,0,0),(829,'fe_inventory_delivery_prefix','ID',1,0.00,0,0),(830,'fe_next_inventory_delivery_mumber','1',1,0.00,0,0),(831,'fe_packing_list_prefix','PL',1,0.00,0,0),(832,'fe_next_packing_list_number','1',1,0.00,0,0),(833,'fe_next_serial_number','1',1,0.00,0,0),(834,'fe_serial_number_format','1',1,0.00,0,0),(835,'fe_show_customer_asset','0',1,0.00,0,0),(836,'fe_issue_prefix','ISSUE',1,0.00,0,0),(837,'fe_next_issue_number','1',1,0.00,0,0),(838,'fe_issue_number_format','1',1,0.00,0,0),(839,'flexstage_send_emails_per_cron_run','100',1,0.00,0,0),(840,'last_flexstage_send_cron','',1,0.00,0,0),(841,'flexstage_customer_reference_id','1',1,0.00,0,0),(842,'flexstage_lead_source','3',1,0.00,0,0),(843,'flexstage_lead_status','2',1,0.00,0,0),(844,'flexstage_color','#a9b338',1,0.00,0,0),(845,'flexstage_qrcode_image_width','150',1,0.00,0,0),(846,'staff_workload_monday','1',1,0.00,0,0),(847,'staff_workload_tuesday','1',1,0.00,0,0),(848,'staff_workload_thursday','1',1,0.00,0,0),(849,'staff_workload_wednesday','1',1,0.00,0,0),(850,'staff_workload_friday','1',1,0.00,0,0),(851,'staff_workload_saturday','0',1,0.00,0,0),(852,'staff_workload_sunday','0',1,0.00,0,0),(853,'staff_workload_monday_visible','1',1,0.00,0,0),(854,'staff_workload_tuesday_visible','1',1,0.00,0,0),(855,'staff_workload_thursday_visible','1',1,0.00,0,0),(856,'staff_workload_wednesday_visible','1',1,0.00,0,0),(857,'staff_workload_friday_visible','1',1,0.00,0,0),(858,'staff_workload_saturday_visible','1',1,0.00,0,0),(859,'staff_workload_sunday_visible','1',1,0.00,0,0),(860,'integrated_timesheet_holiday','0',1,0.00,0,0),(861,'integrated_timesheet_leave','0',1,0.00,0,0),(862,'staff_workload_exception','',1,0.00,0,0),(863,'theme_style','[]',1,0.00,0,0),(864,'theme_style_custom_admin_area','',1,0.00,0,0),(865,'theme_style_custom_clients_area','',1,0.00,0,0),(866,'theme_style_custom_clients_and_admin_area','',1,0.00,0,0),(867,'identification_key','14796505211752046318686e1aee1cbf1',1,0.00,0,0),(868,'auto_backup_enabled','0',1,0.00,0,0),(869,'auto_backup_every','7',1,0.00,0,0),(870,'last_auto_backup','',1,0.00,0,0),(871,'delete_backups_older_then','0',1,0.00,0,0),(872,'auto_backup_hour','6',1,0.00,0,0),(873,'survey_send_emails_per_cron_run','100',1,0.00,0,0),(874,'last_survey_send_cron','',1,0.00,0,0);
/*!40000 ALTER TABLE `himalay_tbloptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblp_t_form_question_box_description`
--

DROP TABLE IF EXISTS `himalay_tblp_t_form_question_box_description`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblp_t_form_question_box_description` (
  `questionboxdescriptionid` int(11) NOT NULL AUTO_INCREMENT,
  `description` mediumtext NOT NULL,
  `boxid` mediumtext NOT NULL,
  `questionid` int(11) NOT NULL,
  `correct` int(11) DEFAULT 1 COMMENT '0: correct 1: incorrect',
  PRIMARY KEY (`questionboxdescriptionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblp_t_form_question_box_description`
--

LOCK TABLES `himalay_tblp_t_form_question_box_description` WRITE;
/*!40000 ALTER TABLE `himalay_tblp_t_form_question_box_description` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblp_t_form_question_box_description` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblpayment_attempts`
--

DROP TABLE IF EXISTS `himalay_tblpayment_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblpayment_attempts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference` varchar(100) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `amount` double NOT NULL,
  `fee` double NOT NULL,
  `payment_gateway` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblpayment_attempts`
--

LOCK TABLES `himalay_tblpayment_attempts` WRITE;
/*!40000 ALTER TABLE `himalay_tblpayment_attempts` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblpayment_attempts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblpayment_modes`
--

DROP TABLE IF EXISTS `himalay_tblpayment_modes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblpayment_modes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `show_on_pdf` int(11) NOT NULL DEFAULT 0,
  `invoices_only` int(11) NOT NULL DEFAULT 0,
  `expenses_only` int(11) NOT NULL DEFAULT 0,
  `selected_by_default` int(11) NOT NULL DEFAULT 1,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblpayment_modes`
--

LOCK TABLES `himalay_tblpayment_modes` WRITE;
/*!40000 ALTER TABLE `himalay_tblpayment_modes` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblpayment_modes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblpinned_projects`
--

DROP TABLE IF EXISTS `himalay_tblpinned_projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblpinned_projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblpinned_projects`
--

LOCK TABLES `himalay_tblpinned_projects` WRITE;
/*!40000 ALTER TABLE `himalay_tblpinned_projects` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblpinned_projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblposition_training_question_form`
--

DROP TABLE IF EXISTS `himalay_tblposition_training_question_form`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblposition_training_question_form` (
  `questionid` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) DEFAULT NULL,
  `question` mediumtext NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT 0,
  `question_order` int(11) NOT NULL,
  `point` int(11) NOT NULL,
  PRIMARY KEY (`questionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblposition_training_question_form`
--

LOCK TABLES `himalay_tblposition_training_question_form` WRITE;
/*!40000 ALTER TABLE `himalay_tblposition_training_question_form` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblposition_training_question_form` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblproject_activity`
--

DROP TABLE IF EXISTS `himalay_tblproject_activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblproject_activity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL DEFAULT 0,
  `contact_id` int(11) NOT NULL DEFAULT 0,
  `fullname` varchar(100) DEFAULT NULL,
  `visible_to_customer` int(11) NOT NULL DEFAULT 0,
  `description_key` varchar(191) NOT NULL COMMENT 'Language file key',
  `additional_data` mediumtext DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblproject_activity`
--

LOCK TABLES `himalay_tblproject_activity` WRITE;
/*!40000 ALTER TABLE `himalay_tblproject_activity` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblproject_activity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblproject_files`
--

DROP TABLE IF EXISTS `himalay_tblproject_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblproject_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file_name` varchar(191) NOT NULL,
  `original_file_name` longtext DEFAULT NULL,
  `subject` varchar(191) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `filetype` varchar(50) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  `last_activity` datetime DEFAULT NULL,
  `project_id` int(11) NOT NULL,
  `visible_to_customer` tinyint(1) DEFAULT 0,
  `staffid` int(11) NOT NULL,
  `contact_id` int(11) NOT NULL DEFAULT 0,
  `external` varchar(40) DEFAULT NULL,
  `external_link` mediumtext DEFAULT NULL,
  `thumbnail_link` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblproject_files`
--

LOCK TABLES `himalay_tblproject_files` WRITE;
/*!40000 ALTER TABLE `himalay_tblproject_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblproject_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblproject_members`
--

DROP TABLE IF EXISTS `himalay_tblproject_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblproject_members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`),
  KEY `himalay_staff_id` (`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblproject_members`
--

LOCK TABLES `himalay_tblproject_members` WRITE;
/*!40000 ALTER TABLE `himalay_tblproject_members` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblproject_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblproject_notes`
--

DROP TABLE IF EXISTS `himalay_tblproject_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblproject_notes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `content` mediumtext NOT NULL,
  `staff_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblproject_notes`
--

LOCK TABLES `himalay_tblproject_notes` WRITE;
/*!40000 ALTER TABLE `himalay_tblproject_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblproject_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblproject_settings`
--

DROP TABLE IF EXISTS `himalay_tblproject_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblproject_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `value` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblproject_settings`
--

LOCK TABLES `himalay_tblproject_settings` WRITE;
/*!40000 ALTER TABLE `himalay_tblproject_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblproject_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblprojectdiscussioncomments`
--

DROP TABLE IF EXISTS `himalay_tblprojectdiscussioncomments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblprojectdiscussioncomments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `discussion_id` int(11) NOT NULL,
  `discussion_type` varchar(10) NOT NULL,
  `parent` int(11) DEFAULT NULL,
  `created` datetime NOT NULL,
  `modified` datetime DEFAULT NULL,
  `content` mediumtext NOT NULL,
  `staff_id` int(11) NOT NULL,
  `contact_id` int(11) DEFAULT 0,
  `fullname` varchar(191) DEFAULT NULL,
  `file_name` varchar(191) DEFAULT NULL,
  `file_mime_type` varchar(70) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblprojectdiscussioncomments`
--

LOCK TABLES `himalay_tblprojectdiscussioncomments` WRITE;
/*!40000 ALTER TABLE `himalay_tblprojectdiscussioncomments` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblprojectdiscussioncomments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblprojectdiscussions`
--

DROP TABLE IF EXISTS `himalay_tblprojectdiscussions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblprojectdiscussions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `subject` varchar(191) NOT NULL,
  `description` mediumtext NOT NULL,
  `show_to_customer` tinyint(1) NOT NULL DEFAULT 0,
  `datecreated` datetime NOT NULL,
  `last_activity` datetime DEFAULT NULL,
  `staff_id` int(11) NOT NULL DEFAULT 0,
  `contact_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblprojectdiscussions`
--

LOCK TABLES `himalay_tblprojectdiscussions` WRITE;
/*!40000 ALTER TABLE `himalay_tblprojectdiscussions` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblprojectdiscussions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblprojects`
--

DROP TABLE IF EXISTS `himalay_tblprojects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblprojects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `clientid` int(11) NOT NULL,
  `billing_type` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `deadline` date DEFAULT NULL,
  `project_created` date NOT NULL,
  `date_finished` datetime DEFAULT NULL,
  `progress` int(11) DEFAULT 0,
  `progress_from_tasks` int(11) NOT NULL DEFAULT 1,
  `project_cost` decimal(15,2) DEFAULT NULL,
  `project_rate_per_hour` decimal(15,2) DEFAULT NULL,
  `estimated_hours` decimal(15,2) DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `contact_notification` int(11) DEFAULT 1,
  `notify_contacts` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblprojects`
--

LOCK TABLES `himalay_tblprojects` WRITE;
/*!40000 ALTER TABLE `himalay_tblprojects` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblprojects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblproposal_comments`
--

DROP TABLE IF EXISTS `himalay_tblproposal_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblproposal_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` longtext DEFAULT NULL,
  `proposalid` int(11) NOT NULL,
  `staffid` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblproposal_comments`
--

LOCK TABLES `himalay_tblproposal_comments` WRITE;
/*!40000 ALTER TABLE `himalay_tblproposal_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblproposal_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblproposals`
--

DROP TABLE IF EXISTS `himalay_tblproposals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblproposals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(191) DEFAULT NULL,
  `content` longtext DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `datecreated` datetime NOT NULL,
  `total` decimal(15,2) DEFAULT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `total_tax` decimal(15,2) NOT NULL DEFAULT 0.00,
  `adjustment` decimal(15,2) DEFAULT NULL,
  `discount_percent` decimal(15,2) NOT NULL,
  `discount_total` decimal(15,2) NOT NULL,
  `discount_type` varchar(30) DEFAULT NULL,
  `show_quantity_as` int(11) NOT NULL DEFAULT 1,
  `currency` int(11) NOT NULL,
  `open_till` date DEFAULT NULL,
  `date` date NOT NULL,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(40) DEFAULT NULL,
  `assigned` int(11) DEFAULT NULL,
  `hash` varchar(32) NOT NULL,
  `proposal_to` varchar(191) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  `country` int(11) NOT NULL DEFAULT 0,
  `zip` varchar(50) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `allow_comments` tinyint(1) NOT NULL DEFAULT 1,
  `status` int(11) NOT NULL,
  `estimate_id` int(11) DEFAULT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `date_converted` datetime DEFAULT NULL,
  `pipeline_order` int(11) DEFAULT 1,
  `is_expiry_notified` int(11) NOT NULL DEFAULT 0,
  `acceptance_firstname` varchar(50) DEFAULT NULL,
  `acceptance_lastname` varchar(50) DEFAULT NULL,
  `acceptance_email` varchar(100) DEFAULT NULL,
  `acceptance_date` datetime DEFAULT NULL,
  `acceptance_ip` varchar(40) DEFAULT NULL,
  `signature` varchar(40) DEFAULT NULL,
  `short_link` varchar(100) DEFAULT NULL,
  `processing` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblproposals`
--

LOCK TABLES `himalay_tblproposals` WRITE;
/*!40000 ALTER TABLE `himalay_tblproposals` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblproposals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblpur_activity_log`
--

DROP TABLE IF EXISTS `himalay_tblpur_activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblpur_activity_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(45) NOT NULL,
  `staffid` int(11) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `note` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblpur_activity_log`
--

LOCK TABLES `himalay_tblpur_activity_log` WRITE;
/*!40000 ALTER TABLE `himalay_tblpur_activity_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblpur_activity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblpur_approval_details`
--

DROP TABLE IF EXISTS `himalay_tblpur_approval_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblpur_approval_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(45) NOT NULL,
  `staffid` varchar(45) DEFAULT NULL,
  `approve` varchar(45) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `approve_action` varchar(255) DEFAULT NULL,
  `reject_action` varchar(255) DEFAULT NULL,
  `approve_value` varchar(255) DEFAULT NULL,
  `reject_value` varchar(255) DEFAULT NULL,
  `staff_approve` int(11) DEFAULT NULL,
  `action` varchar(45) DEFAULT NULL,
  `sender` int(11) DEFAULT NULL,
  `date_send` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblpur_approval_details`
--

LOCK TABLES `himalay_tblpur_approval_details` WRITE;
/*!40000 ALTER TABLE `himalay_tblpur_approval_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblpur_approval_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblpur_approval_setting`
--

DROP TABLE IF EXISTS `himalay_tblpur_approval_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblpur_approval_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `related` varchar(255) NOT NULL,
  `setting` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblpur_approval_setting`
--

LOCK TABLES `himalay_tblpur_approval_setting` WRITE;
/*!40000 ALTER TABLE `himalay_tblpur_approval_setting` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblpur_approval_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblpur_comments`
--

DROP TABLE IF EXISTS `himalay_tblpur_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblpur_comments` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `content` mediumtext DEFAULT NULL,
  `rel_type` varchar(50) NOT NULL,
  `rel_id` int(11) DEFAULT NULL,
  `staffid` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblpur_comments`
--

LOCK TABLES `himalay_tblpur_comments` WRITE;
/*!40000 ALTER TABLE `himalay_tblpur_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblpur_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblpur_contacts`
--

DROP TABLE IF EXISTS `himalay_tblpur_contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblpur_contacts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `is_primary` int(11) NOT NULL DEFAULT 1,
  `firstname` varchar(191) NOT NULL,
  `lastname` varchar(191) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phonenumber` varchar(100) NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `new_pass_key` varchar(32) DEFAULT NULL,
  `new_pass_key_requested` datetime DEFAULT NULL,
  `email_verified_at` datetime DEFAULT NULL,
  `email_verification_key` varchar(32) DEFAULT NULL,
  `email_verification_sent_at` datetime DEFAULT NULL,
  `last_ip` varchar(40) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_password_change` datetime DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `profile_image` varchar(191) DEFAULT NULL,
  `direction` varchar(3) DEFAULT NULL,
  `invoice_emails` tinyint(1) NOT NULL DEFAULT 1,
  `estimate_emails` tinyint(1) NOT NULL DEFAULT 1,
  `credit_note_emails` tinyint(1) NOT NULL DEFAULT 1,
  `contract_emails` tinyint(1) NOT NULL DEFAULT 1,
  `task_emails` tinyint(1) NOT NULL DEFAULT 1,
  `project_emails` tinyint(1) NOT NULL DEFAULT 1,
  `ticket_emails` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblpur_contacts`
--

LOCK TABLES `himalay_tblpur_contacts` WRITE;
/*!40000 ALTER TABLE `himalay_tblpur_contacts` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblpur_contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblpur_contracts`
--

DROP TABLE IF EXISTS `himalay_tblpur_contracts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblpur_contracts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `contract_number` varchar(200) NOT NULL,
  `contract_name` varchar(200) NOT NULL,
  `content` longtext DEFAULT NULL,
  `vendor` int(11) NOT NULL,
  `pur_order` int(11) NOT NULL,
  `contract_value` decimal(15,2) DEFAULT NULL,
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `buyer` int(11) DEFAULT NULL,
  `time_payment` date DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  `signed` int(32) NOT NULL DEFAULT 0,
  `note` longtext DEFAULT NULL,
  `signer` int(11) DEFAULT NULL,
  `signed_date` date DEFAULT NULL,
  `signed_status` varchar(50) DEFAULT NULL,
  `service_category` text DEFAULT NULL,
  `project` int(11) DEFAULT NULL,
  `payment_terms` text DEFAULT NULL,
  `payment_amount` decimal(15,2) DEFAULT NULL,
  `payment_cycle` varchar(50) DEFAULT NULL,
  `department` int(11) DEFAULT NULL,
  `signature` text DEFAULT NULL,
  `marked_as_signed` tinyint(1) DEFAULT 0,
  `acceptance_firstname` text DEFAULT NULL,
  `acceptance_lastname` text DEFAULT NULL,
  `acceptance_email` text DEFAULT NULL,
  `acceptance_date` datetime DEFAULT NULL,
  `acceptance_ip` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblpur_contracts`
--

LOCK TABLES `himalay_tblpur_contracts` WRITE;
/*!40000 ALTER TABLE `himalay_tblpur_contracts` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblpur_contracts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblpur_debit_notes`
--

DROP TABLE IF EXISTS `himalay_tblpur_debit_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblpur_debit_notes` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `vendorid` int(11) DEFAULT NULL,
  `deleted_vendor_name` varchar(100) DEFAULT NULL,
  `number` int(11) DEFAULT NULL,
  `prefix` varchar(50) DEFAULT NULL,
  `number_format` int(11) DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `date` date DEFAULT NULL,
  `adminnote` text DEFAULT NULL,
  `terms` text DEFAULT NULL,
  `vendornote` text DEFAULT NULL,
  `currency` int(11) DEFAULT NULL,
  `subtotal` decimal(15,2) DEFAULT NULL,
  `total_tax` decimal(15,2) DEFAULT NULL,
  `total` decimal(15,2) DEFAULT NULL,
  `adjustment` decimal(15,2) DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `discount_percent` decimal(15,2) DEFAULT NULL,
  `discount_total` decimal(15,2) DEFAULT NULL,
  `discount_type` varchar(30) DEFAULT NULL,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT NULL,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT NULL,
  `include_shipping` tinyint(1) DEFAULT NULL,
  `show_shipping_on_debit_note` tinyint(1) DEFAULT NULL,
  `show_quantity_as` int(11) DEFAULT NULL,
  `reference_no` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblpur_debit_notes`
--

LOCK TABLES `himalay_tblpur_debit_notes` WRITE;
/*!40000 ALTER TABLE `himalay_tblpur_debit_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblpur_debit_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblpur_debits`
--

DROP TABLE IF EXISTS `himalay_tblpur_debits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblpur_debits` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) DEFAULT NULL,
  `debit_id` int(11) DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `date_applied` datetime DEFAULT NULL,
  `date` date DEFAULT NULL,
  `amount` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblpur_debits`
--

LOCK TABLES `himalay_tblpur_debits` WRITE;
/*!40000 ALTER TABLE `himalay_tblpur_debits` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblpur_debits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblpur_debits_refunds`
--

DROP TABLE IF EXISTS `himalay_tblpur_debits_refunds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblpur_debits_refunds` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `debit_note_id` int(11) DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `refunded_on` date DEFAULT NULL,
  `payment_mode` varchar(40) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `amount` decimal(15,2) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblpur_debits_refunds`
--

LOCK TABLES `himalay_tblpur_debits_refunds` WRITE;
/*!40000 ALTER TABLE `himalay_tblpur_debits_refunds` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblpur_debits_refunds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblpur_estimate_detail`
--

DROP TABLE IF EXISTS `himalay_tblpur_estimate_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblpur_estimate_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pur_estimate` int(11) NOT NULL,
  `item_code` varchar(100) NOT NULL,
  `unit_id` int(11) DEFAULT NULL,
  `unit_price` decimal(15,2) DEFAULT NULL,
  `quantity` decimal(15,2) NOT NULL,
  `into_money` decimal(15,2) DEFAULT NULL,
  `tax` text DEFAULT NULL,
  `total` decimal(15,2) DEFAULT NULL,
  `total_money` decimal(15,2) DEFAULT NULL,
  `discount_money` decimal(15,2) DEFAULT NULL,
  `discount_%` decimal(15,2) DEFAULT NULL,
  `tax_value` decimal(15,2) DEFAULT NULL,
  `tax_rate` text DEFAULT NULL,
  `tax_name` text DEFAULT NULL,
  `item_name` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblpur_estimate_detail`
--

LOCK TABLES `himalay_tblpur_estimate_detail` WRITE;
/*!40000 ALTER TABLE `himalay_tblpur_estimate_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblpur_estimate_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblpur_estimates`
--

DROP TABLE IF EXISTS `himalay_tblpur_estimates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblpur_estimates` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sent` tinyint(1) NOT NULL DEFAULT 0,
  `datesend` datetime DEFAULT NULL,
  `vendor` int(11) NOT NULL,
  `deleted_vendor_name` varchar(100) DEFAULT NULL,
  `pur_request` int(11) DEFAULT NULL,
  `number` int(11) NOT NULL,
  `prefix` varchar(50) DEFAULT NULL,
  `number_format` int(11) NOT NULL DEFAULT 0,
  `hash` varchar(32) DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `date` date NOT NULL,
  `expirydate` date DEFAULT NULL,
  `currency` int(11) NOT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `total_tax` decimal(15,2) NOT NULL,
  `total` decimal(15,2) NOT NULL,
  `adjustment` decimal(15,2) DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `vendornote` text DEFAULT NULL,
  `adminnote` text DEFAULT NULL,
  `discount_percent` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `discount_type` varchar(30) DEFAULT NULL,
  `invoiceid` int(11) DEFAULT NULL,
  `invoiced_date` datetime DEFAULT NULL,
  `terms` text DEFAULT NULL,
  `reference_no` varchar(100) DEFAULT NULL,
  `buyer` int(11) NOT NULL DEFAULT 0,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT NULL,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT NULL,
  `include_shipping` tinyint(1) NOT NULL,
  `show_shipping_on_estimate` tinyint(1) NOT NULL DEFAULT 1,
  `show_quantity_as` int(11) NOT NULL DEFAULT 1,
  `pipeline_order` int(11) NOT NULL DEFAULT 0,
  `is_expiry_notified` int(11) NOT NULL DEFAULT 0,
  `acceptance_firstname` varchar(50) DEFAULT NULL,
  `acceptance_lastname` varchar(50) DEFAULT NULL,
  `acceptance_email` varchar(100) DEFAULT NULL,
  `acceptance_date` datetime DEFAULT NULL,
  `acceptance_ip` varchar(40) DEFAULT NULL,
  `signature` varchar(40) DEFAULT NULL,
  `make_a_contract` text DEFAULT NULL,
  `currency_rate` decimal(15,6) DEFAULT NULL,
  `from_currency` varchar(20) DEFAULT NULL,
  `to_currency` varchar(20) DEFAULT NULL,
  `shipping_fee` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblpur_estimates`
--

LOCK TABLES `himalay_tblpur_estimates` WRITE;
/*!40000 ALTER TABLE `himalay_tblpur_estimates` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblpur_estimates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblpur_invoice_details`
--

DROP TABLE IF EXISTS `himalay_tblpur_invoice_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblpur_invoice_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pur_invoice` int(11) NOT NULL,
  `item_code` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `unit_id` int(11) DEFAULT NULL,
  `unit_price` decimal(15,2) DEFAULT NULL,
  `quantity` decimal(15,2) DEFAULT NULL,
  `into_money` decimal(15,2) DEFAULT NULL,
  `tax` text DEFAULT NULL,
  `total` decimal(15,2) DEFAULT NULL,
  `discount_percent` decimal(15,2) DEFAULT NULL,
  `discount_money` decimal(15,2) DEFAULT NULL,
  `total_money` decimal(15,2) DEFAULT NULL,
  `tax_value` decimal(15,2) DEFAULT NULL,
  `tax_rate` text DEFAULT NULL,
  `tax_name` text DEFAULT NULL,
  `item_name` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblpur_invoice_details`
--

LOCK TABLES `himalay_tblpur_invoice_details` WRITE;
/*!40000 ALTER TABLE `himalay_tblpur_invoice_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblpur_invoice_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblpur_invoice_payment`
--

DROP TABLE IF EXISTS `himalay_tblpur_invoice_payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblpur_invoice_payment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pur_invoice` int(11) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `paymentmode` longtext DEFAULT NULL,
  `date` date NOT NULL,
  `daterecorded` datetime NOT NULL,
  `note` text NOT NULL,
  `transactionid` mediumtext DEFAULT NULL,
  `approval_status` int(2) DEFAULT NULL,
  `requester` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblpur_invoice_payment`
--

LOCK TABLES `himalay_tblpur_invoice_payment` WRITE;
/*!40000 ALTER TABLE `himalay_tblpur_invoice_payment` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblpur_invoice_payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblpur_invoices`
--

DROP TABLE IF EXISTS `himalay_tblpur_invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblpur_invoices` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `number` int(11) NOT NULL,
  `invoice_number` text DEFAULT NULL,
  `invoice_date` date DEFAULT NULL,
  `subtotal` decimal(15,2) DEFAULT NULL,
  `tax_rate` int(11) DEFAULT NULL,
  `tax` decimal(15,2) DEFAULT NULL,
  `total` decimal(15,2) DEFAULT NULL,
  `contract` int(11) DEFAULT NULL,
  `vendor` int(11) DEFAULT NULL,
  `transactionid` mediumtext DEFAULT NULL,
  `transaction_date` date DEFAULT NULL,
  `payment_request_status` varchar(30) DEFAULT NULL,
  `payment_status` varchar(30) DEFAULT NULL,
  `vendor_note` text DEFAULT NULL,
  `adminnote` text DEFAULT NULL,
  `terms` text DEFAULT NULL,
  `add_from` int(11) DEFAULT NULL,
  `date_add` date DEFAULT NULL,
  `pur_order` int(11) DEFAULT NULL,
  `recurring` int(11) DEFAULT NULL,
  `recurring_type` varchar(10) DEFAULT NULL,
  `cycles` int(11) DEFAULT 0,
  `total_cycles` int(11) DEFAULT 0,
  `last_recurring_date` date DEFAULT NULL,
  `is_recurring_from` int(11) DEFAULT NULL,
  `duedate` date DEFAULT NULL,
  `add_from_type` varchar(20) DEFAULT NULL,
  `currency` int(11) DEFAULT 0,
  `discount_total` decimal(15,2) DEFAULT NULL,
  `discount_percent` decimal(15,2) DEFAULT NULL,
  `currency_rate` decimal(15,6) DEFAULT NULL,
  `from_currency` varchar(20) DEFAULT NULL,
  `to_currency` varchar(20) DEFAULT NULL,
  `shipping_fee` decimal(15,2) DEFAULT NULL,
  `vendor_invoice_number` text DEFAULT NULL,
  `discount_type` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblpur_invoices`
--

LOCK TABLES `himalay_tblpur_invoices` WRITE;
/*!40000 ALTER TABLE `himalay_tblpur_invoices` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblpur_invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblpur_order_detail`
--

DROP TABLE IF EXISTS `himalay_tblpur_order_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblpur_order_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pur_order` int(11) NOT NULL,
  `item_code` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `unit_id` int(11) DEFAULT NULL,
  `unit_price` decimal(15,2) DEFAULT NULL,
  `quantity` decimal(15,2) NOT NULL,
  `into_money` decimal(15,2) DEFAULT NULL,
  `tax` text DEFAULT NULL,
  `total` decimal(15,2) DEFAULT NULL,
  `discount_%` decimal(15,2) DEFAULT NULL,
  `discount_money` decimal(15,2) DEFAULT NULL,
  `total_money` decimal(15,2) DEFAULT NULL,
  `tax_value` decimal(15,2) DEFAULT NULL,
  `tax_rate` text DEFAULT NULL,
  `tax_name` text DEFAULT NULL,
  `item_name` text DEFAULT NULL,
  `wh_quantity_received` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblpur_order_detail`
--

LOCK TABLES `himalay_tblpur_order_detail` WRITE;
/*!40000 ALTER TABLE `himalay_tblpur_order_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblpur_order_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblpur_order_payment`
--

DROP TABLE IF EXISTS `himalay_tblpur_order_payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblpur_order_payment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pur_order` int(11) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `paymentmode` longtext DEFAULT NULL,
  `date` date NOT NULL,
  `daterecorded` datetime NOT NULL,
  `note` text NOT NULL,
  `transactionid` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblpur_order_payment`
--

LOCK TABLES `himalay_tblpur_order_payment` WRITE;
/*!40000 ALTER TABLE `himalay_tblpur_order_payment` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblpur_order_payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblpur_orders`
--

DROP TABLE IF EXISTS `himalay_tblpur_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblpur_orders` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pur_order_name` varchar(100) NOT NULL,
  `vendor` int(11) NOT NULL,
  `estimate` int(11) NOT NULL,
  `pur_order_number` varchar(30) NOT NULL,
  `order_date` date NOT NULL,
  `status` int(32) NOT NULL DEFAULT 1,
  `approve_status` int(32) NOT NULL DEFAULT 1,
  `datecreated` datetime NOT NULL,
  `days_owed` int(11) NOT NULL,
  `delivery_date` date DEFAULT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `total_tax` decimal(15,2) NOT NULL,
  `total` decimal(15,2) NOT NULL,
  `addedfrom` int(11) NOT NULL,
  `vendornote` text DEFAULT NULL,
  `terms` text DEFAULT NULL,
  `discount_percent` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `discount_type` varchar(30) DEFAULT NULL,
  `buyer` int(11) NOT NULL DEFAULT 0,
  `status_goods` int(11) NOT NULL DEFAULT 0,
  `number` int(11) DEFAULT NULL,
  `expense_convert` int(11) DEFAULT 0,
  `hash` varchar(32) DEFAULT NULL,
  `clients` text DEFAULT NULL,
  `delivery_status` int(2) DEFAULT 0,
  `type` text DEFAULT NULL,
  `project` int(11) DEFAULT NULL,
  `pur_request` int(11) DEFAULT NULL,
  `department` int(11) DEFAULT NULL,
  `tax_order_rate` decimal(15,2) DEFAULT NULL,
  `tax_order_amount` decimal(15,2) DEFAULT NULL,
  `sale_invoice` int(11) DEFAULT NULL,
  `currency` int(11) DEFAULT 0,
  `order_status` varchar(30) DEFAULT NULL,
  `shipping_note` text DEFAULT NULL,
  `currency_rate` decimal(15,6) DEFAULT NULL,
  `from_currency` varchar(20) DEFAULT NULL,
  `to_currency` varchar(20) DEFAULT NULL,
  `shipping_fee` decimal(15,2) DEFAULT NULL,
  `shipping_address` text DEFAULT NULL,
  `shipping_city` text DEFAULT NULL,
  `shipping_state` text DEFAULT NULL,
  `shipping_zip` text DEFAULT NULL,
  `shipping_country` int(11) DEFAULT NULL,
  `shipping_country_text` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblpur_orders`
--

LOCK TABLES `himalay_tblpur_orders` WRITE;
/*!40000 ALTER TABLE `himalay_tblpur_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblpur_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblpur_request`
--

DROP TABLE IF EXISTS `himalay_tblpur_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblpur_request` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pur_rq_code` varchar(45) NOT NULL,
  `pur_rq_name` varchar(100) NOT NULL,
  `rq_description` text DEFAULT NULL,
  `requester` int(11) NOT NULL,
  `department` int(11) DEFAULT NULL,
  `request_date` datetime NOT NULL,
  `status` int(11) DEFAULT NULL,
  `status_goods` int(11) NOT NULL DEFAULT 0,
  `hash` varchar(32) DEFAULT NULL,
  `type` text DEFAULT NULL,
  `project` int(11) DEFAULT NULL,
  `number` int(11) DEFAULT NULL,
  `from_items` int(2) DEFAULT 1,
  `subtotal` decimal(15,2) DEFAULT NULL,
  `total_tax` decimal(15,2) DEFAULT NULL,
  `total` decimal(15,2) DEFAULT NULL,
  `sale_invoice` int(11) DEFAULT NULL,
  `compare_note` text DEFAULT NULL,
  `send_to_vendors` text DEFAULT NULL,
  `currency` int(11) DEFAULT 0,
  `currency_rate` decimal(15,6) DEFAULT NULL,
  `from_currency` varchar(20) DEFAULT NULL,
  `to_currency` varchar(20) DEFAULT NULL,
  `sale_estimate` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblpur_request`
--

LOCK TABLES `himalay_tblpur_request` WRITE;
/*!40000 ALTER TABLE `himalay_tblpur_request` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblpur_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblpur_request_detail`
--

DROP TABLE IF EXISTS `himalay_tblpur_request_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblpur_request_detail` (
  `prd_id` int(11) NOT NULL AUTO_INCREMENT,
  `pur_request` int(11) NOT NULL,
  `item_code` varchar(100) NOT NULL,
  `unit_id` int(11) DEFAULT NULL,
  `unit_price` decimal(15,2) DEFAULT NULL,
  `quantity` decimal(15,2) NOT NULL,
  `into_money` decimal(15,2) DEFAULT NULL,
  `inventory_quantity` int(11) DEFAULT 0,
  `item_text` text DEFAULT NULL,
  `tax` text DEFAULT NULL,
  `tax_rate` text DEFAULT NULL,
  `tax_value` decimal(15,2) DEFAULT NULL,
  `total` decimal(15,2) DEFAULT NULL,
  `tax_name` text DEFAULT NULL,
  PRIMARY KEY (`prd_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblpur_request_detail`
--

LOCK TABLES `himalay_tblpur_request_detail` WRITE;
/*!40000 ALTER TABLE `himalay_tblpur_request_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblpur_request_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblpur_unit`
--

DROP TABLE IF EXISTS `himalay_tblpur_unit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblpur_unit` (
  `unit_id` int(11) NOT NULL AUTO_INCREMENT,
  `unit_name` varchar(100) NOT NULL,
  PRIMARY KEY (`unit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblpur_unit`
--

LOCK TABLES `himalay_tblpur_unit` WRITE;
/*!40000 ALTER TABLE `himalay_tblpur_unit` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblpur_unit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblpur_vendor`
--

DROP TABLE IF EXISTS `himalay_tblpur_vendor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblpur_vendor` (
  `userid` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `company` varchar(200) DEFAULT NULL,
  `vat` varchar(200) DEFAULT NULL,
  `phonenumber` varchar(30) DEFAULT NULL,
  `country` int(11) NOT NULL DEFAULT 0,
  `city` varchar(100) DEFAULT NULL,
  `zip` varchar(15) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `website` varchar(150) DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `active` int(11) NOT NULL DEFAULT 1,
  `leadid` int(11) DEFAULT NULL,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT 0,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT 0,
  `longitude` varchar(191) DEFAULT NULL,
  `latitude` varchar(191) DEFAULT NULL,
  `default_language` varchar(40) DEFAULT NULL,
  `default_currency` int(11) NOT NULL DEFAULT 0,
  `show_primary_contact` int(11) NOT NULL DEFAULT 0,
  `stripe_id` varchar(40) DEFAULT NULL,
  `registration_confirmed` int(11) NOT NULL DEFAULT 1,
  `addedfrom` int(11) NOT NULL DEFAULT 0,
  `category` text DEFAULT NULL,
  `bank_detail` text DEFAULT NULL,
  `payment_terms` text DEFAULT NULL,
  `vendor_code` varchar(100) DEFAULT NULL,
  `return_within_day` int(11) DEFAULT NULL,
  `return_order_fee` decimal(15,2) DEFAULT NULL,
  `return_policies` text DEFAULT NULL,
  `balance` decimal(15,2) DEFAULT NULL,
  `balance_as_of` date DEFAULT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblpur_vendor`
--

LOCK TABLES `himalay_tblpur_vendor` WRITE;
/*!40000 ALTER TABLE `himalay_tblpur_vendor` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblpur_vendor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblpur_vendor_admin`
--

DROP TABLE IF EXISTS `himalay_tblpur_vendor_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblpur_vendor_admin` (
  `staff_id` int(11) NOT NULL,
  `vendor_id` int(11) NOT NULL,
  `date_assigned` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblpur_vendor_admin`
--

LOCK TABLES `himalay_tblpur_vendor_admin` WRITE;
/*!40000 ALTER TABLE `himalay_tblpur_vendor_admin` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblpur_vendor_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblpur_vendor_cate`
--

DROP TABLE IF EXISTS `himalay_tblpur_vendor_cate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblpur_vendor_cate` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblpur_vendor_cate`
--

LOCK TABLES `himalay_tblpur_vendor_cate` WRITE;
/*!40000 ALTER TABLE `himalay_tblpur_vendor_cate` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblpur_vendor_cate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblpur_vendor_items`
--

DROP TABLE IF EXISTS `himalay_tblpur_vendor_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblpur_vendor_items` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `vendor` int(11) NOT NULL,
  `group_items` int(11) DEFAULT NULL,
  `items` int(11) NOT NULL,
  `add_from` int(11) DEFAULT NULL,
  `datecreate` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblpur_vendor_items`
--

LOCK TABLES `himalay_tblpur_vendor_items` WRITE;
/*!40000 ALTER TABLE `himalay_tblpur_vendor_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblpur_vendor_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblpurchase_option`
--

DROP TABLE IF EXISTS `himalay_tblpurchase_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblpurchase_option` (
  `option_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(200) NOT NULL,
  `option_val` longtext DEFAULT NULL,
  `auto` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`option_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblpurchase_option`
--

LOCK TABLES `himalay_tblpurchase_option` WRITE;
/*!40000 ALTER TABLE `himalay_tblpurchase_option` DISABLE KEYS */;
INSERT INTO `himalay_tblpurchase_option` VALUES (1,'purchase_order_setting','1',1),(2,'pur_order_prefix','#PO',1),(3,'next_po_number','1',1),(4,'date_reset_number','',1),(5,'pur_request_prefix','#PR',1),(6,'next_pr_number','1',1),(7,'date_reset_pr_number','',1),(8,'pur_inv_prefix','#INV',1),(9,'next_inv_number','1',1),(10,'create_invoice_by','contract',1),(11,'item_by_vendor','0',1),(12,'terms_and_conditions','',1),(13,'vendor_note','',1);
/*!40000 ALTER TABLE `himalay_tblpurchase_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblrec_activity_log`
--

DROP TABLE IF EXISTS `himalay_tblrec_activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblrec_activity_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(100) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `additional_data` text DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `staffid` int(11) DEFAULT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblrec_activity_log`
--

LOCK TABLES `himalay_tblrec_activity_log` WRITE;
/*!40000 ALTER TABLE `himalay_tblrec_activity_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblrec_activity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblrec_applied_jobs`
--

DROP TABLE IF EXISTS `himalay_tblrec_applied_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblrec_applied_jobs` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `candidate_id` int(11) DEFAULT NULL,
  `campaign_id` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `status` text DEFAULT NULL,
  `activate` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblrec_applied_jobs`
--

LOCK TABLES `himalay_tblrec_applied_jobs` WRITE;
/*!40000 ALTER TABLE `himalay_tblrec_applied_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblrec_applied_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblrec_campaign`
--

DROP TABLE IF EXISTS `himalay_tblrec_campaign`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblrec_campaign` (
  `cp_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `campaign_code` varchar(200) NOT NULL,
  `campaign_name` varchar(200) NOT NULL,
  `cp_proposal` text DEFAULT NULL,
  `cp_position` int(11) NOT NULL,
  `cp_department` int(11) DEFAULT NULL,
  `cp_amount_recruiment` int(11) DEFAULT NULL,
  `cp_form_work` varchar(45) DEFAULT NULL,
  `cp_workplace` varchar(255) DEFAULT NULL,
  `cp_salary_from` decimal(15,0) DEFAULT NULL,
  `cp_salary_to` decimal(15,0) DEFAULT NULL,
  `cp_from_date` date DEFAULT NULL,
  `cp_to_date` date NOT NULL,
  `cp_reason_recruitment` text DEFAULT NULL,
  `cp_job_description` text DEFAULT NULL,
  `cp_manager` text DEFAULT NULL,
  `cp_follower` text DEFAULT NULL,
  `cp_ages_from` int(11) DEFAULT NULL,
  `cp_ages_to` int(11) DEFAULT NULL,
  `cp_gender` varchar(10) DEFAULT NULL,
  `cp_height` float DEFAULT NULL,
  `cp_weight` float DEFAULT NULL,
  `cp_literacy` varchar(200) DEFAULT NULL,
  `cp_experience` varchar(200) DEFAULT NULL,
  `cp_add_from` int(11) NOT NULL,
  `cp_date_add` date NOT NULL,
  `cp_status` int(11) NOT NULL,
  `display_salary` int(15) DEFAULT NULL,
  `rec_channel_form_id` int(15) DEFAULT NULL,
  `company_id` int(15) DEFAULT NULL,
  `job_meta_title` text DEFAULT NULL,
  `job_meta_description` text DEFAULT NULL,
  PRIMARY KEY (`cp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblrec_campaign`
--

LOCK TABLES `himalay_tblrec_campaign` WRITE;
/*!40000 ALTER TABLE `himalay_tblrec_campaign` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblrec_campaign` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblrec_campaign_form_web`
--

DROP TABLE IF EXISTS `himalay_tblrec_campaign_form_web`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblrec_campaign_form_web` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rec_campaign_id` int(11) NOT NULL,
  `form_type` int(11) DEFAULT NULL,
  `lead_source` varchar(10) DEFAULT NULL,
  `lead_status` varchar(10) DEFAULT NULL,
  `notify_ids_staff` text DEFAULT NULL,
  `notify_ids_roles` text DEFAULT NULL,
  `form_key` varchar(32) DEFAULT NULL,
  `notify_lead_imported` int(11) DEFAULT 1,
  `notify_type` varchar(20) DEFAULT NULL,
  `notify_ids` mediumtext DEFAULT NULL,
  `responsible` int(11) DEFAULT 0,
  `r_form_name` varchar(191) DEFAULT NULL,
  `form_data` mediumtext DEFAULT NULL,
  `recaptcha` int(11) DEFAULT 0,
  `submit_btn_name` varchar(40) DEFAULT NULL,
  `success_submit_msg` text DEFAULT NULL,
  `language` varchar(40) DEFAULT NULL,
  `allow_duplicate` int(11) DEFAULT 1,
  `mark_public` int(11) DEFAULT 0,
  `track_duplicate_field` varchar(20) DEFAULT NULL,
  `track_duplicate_field_and` varchar(20) DEFAULT NULL,
  `create_task_on_duplicate` int(11) DEFAULT 0,
  PRIMARY KEY (`id`,`rec_campaign_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblrec_campaign_form_web`
--

LOCK TABLES `himalay_tblrec_campaign_form_web` WRITE;
/*!40000 ALTER TABLE `himalay_tblrec_campaign_form_web` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblrec_campaign_form_web` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblrec_candidate`
--

DROP TABLE IF EXISTS `himalay_tblrec_candidate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblrec_candidate` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rec_campaign` int(11) DEFAULT NULL,
  `candidate_code` varchar(200) NOT NULL,
  `candidate_name` varchar(200) NOT NULL,
  `birthday` date DEFAULT NULL,
  `gender` varchar(11) DEFAULT NULL,
  `birthplace` text DEFAULT NULL,
  `home_town` text DEFAULT NULL,
  `identification` varchar(45) DEFAULT NULL,
  `days_for_identity` date DEFAULT NULL,
  `place_of_issue` varchar(255) DEFAULT NULL,
  `marital_status` varchar(11) DEFAULT NULL,
  `nationality` varchar(100) DEFAULT NULL,
  `nation` varchar(100) NOT NULL,
  `religion` varchar(100) DEFAULT NULL,
  `height` float DEFAULT NULL,
  `weight` float DEFAULT NULL,
  `introduce_yourself` text DEFAULT NULL,
  `phonenumber` text DEFAULT NULL,
  `email` text DEFAULT NULL,
  `skype` text DEFAULT NULL,
  `facebook` text DEFAULT NULL,
  `resident` text DEFAULT NULL,
  `current_accommodation` text DEFAULT NULL,
  `status` int(11) NOT NULL,
  `rate` int(11) DEFAULT NULL,
  `desired_salary` decimal(15,0) DEFAULT NULL,
  `date_add` date DEFAULT NULL,
  `recruitment_channel` int(11) DEFAULT NULL,
  `skill` text DEFAULT NULL,
  `interests` text DEFAULT NULL,
  `linkedin` text DEFAULT NULL,
  `alternate_contact_number` varchar(15) DEFAULT NULL,
  `last_name` varchar(200) DEFAULT NULL,
  `year_experience` varchar(200) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `new_pass_key` varchar(32) DEFAULT NULL,
  `new_pass_key_requested` datetime DEFAULT NULL,
  `email_verified_at` datetime DEFAULT NULL,
  `email_verification_key` varchar(32) DEFAULT NULL,
  `email_verification_sent_at` datetime DEFAULT NULL,
  `last_ip` varchar(40) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_password_change` datetime DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblrec_candidate`
--

LOCK TABLES `himalay_tblrec_candidate` WRITE;
/*!40000 ALTER TABLE `himalay_tblrec_candidate` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblrec_candidate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblrec_cd_evaluation`
--

DROP TABLE IF EXISTS `himalay_tblrec_cd_evaluation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblrec_cd_evaluation` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `criteria` int(11) NOT NULL,
  `rate_score` int(11) NOT NULL,
  `assessor` int(11) NOT NULL,
  `evaluation_date` datetime NOT NULL,
  `percent` int(11) NOT NULL,
  `candidate` int(11) NOT NULL,
  `feedback` text NOT NULL,
  `group_criteria` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblrec_cd_evaluation`
--

LOCK TABLES `himalay_tblrec_cd_evaluation` WRITE;
/*!40000 ALTER TABLE `himalay_tblrec_cd_evaluation` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblrec_cd_evaluation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblrec_company`
--

DROP TABLE IF EXISTS `himalay_tblrec_company`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblrec_company` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `company_name` varchar(200) NOT NULL,
  `company_description` text DEFAULT NULL,
  `company_address` varchar(200) DEFAULT NULL,
  `company_industry` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblrec_company`
--

LOCK TABLES `himalay_tblrec_company` WRITE;
/*!40000 ALTER TABLE `himalay_tblrec_company` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblrec_company` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblrec_criteria`
--

DROP TABLE IF EXISTS `himalay_tblrec_criteria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblrec_criteria` (
  `criteria_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `criteria_type` varchar(45) NOT NULL,
  `criteria_title` varchar(200) NOT NULL,
  `group_criteria` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  `add_date` date DEFAULT NULL,
  `score_des1` text DEFAULT NULL,
  `score_des2` text DEFAULT NULL,
  `score_des3` text DEFAULT NULL,
  `score_des4` text DEFAULT NULL,
  `score_des5` text DEFAULT NULL,
  PRIMARY KEY (`criteria_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblrec_criteria`
--

LOCK TABLES `himalay_tblrec_criteria` WRITE;
/*!40000 ALTER TABLE `himalay_tblrec_criteria` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblrec_criteria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblrec_evaluation_form`
--

DROP TABLE IF EXISTS `himalay_tblrec_evaluation_form`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblrec_evaluation_form` (
  `form_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `form_name` varchar(200) NOT NULL,
  `position` int(11) DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  `add_date` date DEFAULT NULL,
  PRIMARY KEY (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblrec_evaluation_form`
--

LOCK TABLES `himalay_tblrec_evaluation_form` WRITE;
/*!40000 ALTER TABLE `himalay_tblrec_evaluation_form` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblrec_evaluation_form` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblrec_interview`
--

DROP TABLE IF EXISTS `himalay_tblrec_interview`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblrec_interview` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `campaign` int(11) NOT NULL,
  `is_name` varchar(100) NOT NULL,
  `interview_day` varchar(200) NOT NULL,
  `from_time` text NOT NULL,
  `to_time` text NOT NULL,
  `from_hours` datetime DEFAULT NULL,
  `to_hours` datetime DEFAULT NULL,
  `interviewer` text NOT NULL,
  `added_from` int(11) NOT NULL,
  `added_date` date NOT NULL,
  `position` int(15) DEFAULT NULL,
  `send_notify` int(1) DEFAULT 0,
  `interview_location` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblrec_interview`
--

LOCK TABLES `himalay_tblrec_interview` WRITE;
/*!40000 ALTER TABLE `himalay_tblrec_interview` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblrec_interview` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblrec_job_position`
--

DROP TABLE IF EXISTS `himalay_tblrec_job_position`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblrec_job_position` (
  `position_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `position_name` varchar(200) NOT NULL,
  `position_description` text DEFAULT NULL,
  `industry_id` int(15) DEFAULT NULL,
  `company_id` int(15) DEFAULT NULL,
  `job_skill` text DEFAULT NULL,
  PRIMARY KEY (`position_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblrec_job_position`
--

LOCK TABLES `himalay_tblrec_job_position` WRITE;
/*!40000 ALTER TABLE `himalay_tblrec_job_position` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblrec_job_position` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblrec_list_criteria`
--

DROP TABLE IF EXISTS `himalay_tblrec_list_criteria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblrec_list_criteria` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `evaluation_form` int(11) NOT NULL,
  `group_criteria` int(11) NOT NULL,
  `evaluation_criteria` int(11) NOT NULL,
  `percent` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblrec_list_criteria`
--

LOCK TABLES `himalay_tblrec_list_criteria` WRITE;
/*!40000 ALTER TABLE `himalay_tblrec_list_criteria` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblrec_list_criteria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblrec_notifications`
--

DROP TABLE IF EXISTS `himalay_tblrec_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblrec_notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `isread` int(11) NOT NULL DEFAULT 0,
  `isread_inline` tinyint(1) NOT NULL DEFAULT 0,
  `date` datetime NOT NULL,
  `description` text NOT NULL,
  `fromuserid` int(11) NOT NULL,
  `fromclientid` int(11) NOT NULL DEFAULT 0,
  `from_fullname` varchar(100) NOT NULL,
  `touserid` int(11) NOT NULL,
  `fromcompany` int(11) DEFAULT NULL,
  `link` mediumtext DEFAULT NULL,
  `additional_data` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblrec_notifications`
--

LOCK TABLES `himalay_tblrec_notifications` WRITE;
/*!40000 ALTER TABLE `himalay_tblrec_notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblrec_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblrec_proposal`
--

DROP TABLE IF EXISTS `himalay_tblrec_proposal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblrec_proposal` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `proposal_name` varchar(200) NOT NULL,
  `position` int(11) NOT NULL,
  `department` int(11) DEFAULT NULL,
  `amount_recruiment` int(11) DEFAULT NULL,
  `form_work` varchar(45) DEFAULT NULL,
  `workplace` varchar(255) DEFAULT NULL,
  `salary_from` decimal(15,0) DEFAULT NULL,
  `salary_to` decimal(15,0) DEFAULT NULL,
  `from_date` date DEFAULT NULL,
  `to_date` date NOT NULL,
  `reason_recruitment` text DEFAULT NULL,
  `job_description` text DEFAULT NULL,
  `approver` int(11) NOT NULL,
  `ages_from` int(11) DEFAULT NULL,
  `ages_to` int(11) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `height` float DEFAULT NULL,
  `weight` float DEFAULT NULL,
  `literacy` varchar(200) DEFAULT NULL,
  `experience` varchar(200) DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  `date_add` date NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblrec_proposal`
--

LOCK TABLES `himalay_tblrec_proposal` WRITE;
/*!40000 ALTER TABLE `himalay_tblrec_proposal` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblrec_proposal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblrec_set_transfer_record`
--

DROP TABLE IF EXISTS `himalay_tblrec_set_transfer_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblrec_set_transfer_record` (
  `set_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `send_to` varchar(45) NOT NULL,
  `email_to` text DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  `add_date` date NOT NULL,
  `subject` text NOT NULL,
  `content` text DEFAULT NULL,
  `order` int(11) NOT NULL,
  PRIMARY KEY (`set_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblrec_set_transfer_record`
--

LOCK TABLES `himalay_tblrec_set_transfer_record` WRITE;
/*!40000 ALTER TABLE `himalay_tblrec_set_transfer_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblrec_set_transfer_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblrec_skill`
--

DROP TABLE IF EXISTS `himalay_tblrec_skill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblrec_skill` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `skill_name` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblrec_skill`
--

LOCK TABLES `himalay_tblrec_skill` WRITE;
/*!40000 ALTER TABLE `himalay_tblrec_skill` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblrec_skill` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblrec_transfer_records`
--

DROP TABLE IF EXISTS `himalay_tblrec_transfer_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblrec_transfer_records` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `firstname` varchar(100) DEFAULT NULL,
  `lastname` varchar(100) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `gender` varchar(11) DEFAULT NULL,
  `staff_identifi` varchar(20) DEFAULT NULL,
  `creator` int(11) DEFAULT NULL,
  `datecreator` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblrec_transfer_records`
--

LOCK TABLES `himalay_tblrec_transfer_records` WRITE;
/*!40000 ALTER TABLE `himalay_tblrec_transfer_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblrec_transfer_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblrecords_meta`
--

DROP TABLE IF EXISTS `himalay_tblrecords_meta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblrecords_meta` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) DEFAULT NULL,
  `meta` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblrecords_meta`
--

LOCK TABLES `himalay_tblrecords_meta` WRITE;
/*!40000 ALTER TABLE `himalay_tblrecords_meta` DISABLE KEYS */;
INSERT INTO `himalay_tblrecords_meta` VALUES (1,'staff_identifi','staff_identifi'),(2,'firstname','firstname'),(3,'email','email'),(4,'phonenumber','phonenumber'),(5,'facebook','facebook'),(6,'skype','skype'),(7,'birthday','birthday'),(8,'birthplace','birthplace'),(9,'home_town','home_town'),(10,'marital_status','marital_status'),(11,'nation','nation'),(12,'religion','religion'),(13,'identification','identification'),(14,'days_for_identity','days_for_identity'),(15,'place_of_issue','place_of_issue'),(16,'resident','resident'),(17,'current_address','current_address'),(18,'literacy','literacy');
/*!40000 ALTER TABLE `himalay_tblrecords_meta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblrelated_items`
--

DROP TABLE IF EXISTS `himalay_tblrelated_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblrelated_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(30) NOT NULL,
  `item_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblrelated_items`
--

LOCK TABLES `himalay_tblrelated_items` WRITE;
/*!40000 ALTER TABLE `himalay_tblrelated_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblrelated_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblreminders`
--

DROP TABLE IF EXISTS `himalay_tblreminders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblreminders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` mediumtext DEFAULT NULL,
  `date` datetime NOT NULL,
  `isnotified` int(11) NOT NULL DEFAULT 0,
  `rel_id` int(11) NOT NULL,
  `staff` int(11) NOT NULL,
  `rel_type` varchar(40) NOT NULL,
  `notify_by_email` int(11) NOT NULL DEFAULT 1,
  `creator` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`),
  KEY `himalay_staff` (`staff`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblreminders`
--

LOCK TABLES `himalay_tblreminders` WRITE;
/*!40000 ALTER TABLE `himalay_tblreminders` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblreminders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblroles`
--

DROP TABLE IF EXISTS `himalay_tblroles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblroles` (
  `roleid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `permissions` longtext DEFAULT NULL,
  `enable_gg_auth` int(1) DEFAULT 0,
  PRIMARY KEY (`roleid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblroles`
--

LOCK TABLES `himalay_tblroles` WRITE;
/*!40000 ALTER TABLE `himalay_tblroles` DISABLE KEYS */;
INSERT INTO `himalay_tblroles` VALUES (1,'Employee',NULL,0),(2,'Fleet: Driver',NULL,0);
/*!40000 ALTER TABLE `himalay_tblroles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblsales_activity`
--

DROP TABLE IF EXISTS `himalay_tblsales_activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblsales_activity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_type` varchar(20) DEFAULT NULL,
  `rel_id` int(11) NOT NULL,
  `description` mediumtext NOT NULL,
  `additional_data` mediumtext DEFAULT NULL,
  `staffid` varchar(11) DEFAULT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblsales_activity`
--

LOCK TABLES `himalay_tblsales_activity` WRITE;
/*!40000 ALTER TABLE `himalay_tblsales_activity` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblsales_activity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblscheduled_emails`
--

DROP TABLE IF EXISTS `himalay_tblscheduled_emails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblscheduled_emails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(15) NOT NULL,
  `scheduled_at` datetime NOT NULL,
  `contacts` varchar(197) NOT NULL,
  `cc` mediumtext DEFAULT NULL,
  `attach_pdf` tinyint(1) NOT NULL DEFAULT 1,
  `template` varchar(197) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblscheduled_emails`
--

LOCK TABLES `himalay_tblscheduled_emails` WRITE;
/*!40000 ALTER TABLE `himalay_tblscheduled_emails` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblscheduled_emails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblservices`
--

DROP TABLE IF EXISTS `himalay_tblservices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblservices` (
  `serviceid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`serviceid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblservices`
--

LOCK TABLES `himalay_tblservices` WRITE;
/*!40000 ALTER TABLE `himalay_tblservices` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblservices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblsessions`
--

DROP TABLE IF EXISTS `himalay_tblsessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblsessions` (
  `id` varchar(128) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT 0,
  `data` blob NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ci_sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblsessions`
--

LOCK TABLES `himalay_tblsessions` WRITE;
/*!40000 ALTER TABLE `himalay_tblsessions` DISABLE KEYS */;
INSERT INTO `himalay_tblsessions` VALUES ('014ar79lbcji96638me7ij0kn4eil2qb','82.29.165.22',1752453665,'__ci_last_regenerate|i:1752453664;'),('015klbnu8gpn2vtd4lpnukdg0fu4gihc','82.29.165.22',1752093306,'__ci_last_regenerate|i:1752093305;'),('033g2s7cfgh0r2tt67nu938ncm04ggsr','82.29.165.22',1752119107,'__ci_last_regenerate|i:1752119105;'),('04ls9km8f3kvv38j7j4hq8rg6bbqi18i','82.29.165.22',1752130986,'__ci_last_regenerate|i:1752130985;'),('04q9ke5lmn1qvdgkbss5qpbjstsi26e7','82.29.165.22',1752335285,'__ci_last_regenerate|i:1752335284;'),('05vmmnr1d9umgdcgsj7p1tt1nbru2bd0','82.29.165.22',1752458224,'__ci_last_regenerate|i:1752458224;'),('06g21lq1pkl3nahdi8aodmds73gp5ltk','82.29.165.22',1752112025,'__ci_last_regenerate|i:1752112024;'),('06gq13k91531jhn5ugng7lobvfn21tkk','82.29.165.22',1752298507,'__ci_last_regenerate|i:1752298506;'),('06q3c2981sopcpjne2m1iloknneukv9g','82.29.165.22',1752143648,'__ci_last_regenerate|i:1752143647;'),('08b0r8k06a3l7cj81864616r8ae98obr','82.29.165.22',1752378066,'__ci_last_regenerate|i:1752378065;'),('0a32hn6t9o9h69f629kr8af45j0j64ru','82.29.165.22',1752340148,'__ci_last_regenerate|i:1752340147;'),('0acvv6rmvb3kjf5mi8sue6nv1dttmvoc','82.29.165.22',1752477484,'__ci_last_regenerate|i:1752477484;'),('0btsa8g30gi98b51ldo724734hbsatq6','82.29.165.22',1752294304,'__ci_last_regenerate|i:1752294304;'),('0cgmj7irvas46kghbba4tj09mgcsl66e','82.29.165.22',1752092945,'__ci_last_regenerate|i:1752092944;'),('0clchn5vfn340c40qcmgsd7m0dt4lea6','82.29.165.22',1752242411,'__ci_last_regenerate|i:1752242409;'),('0d56555p877jhhjub7aq89cv3iko8bp7','82.29.165.22',1752423187,'__ci_last_regenerate|i:1752423185;'),('0drf0irm0llu3r1g30kisi2c35fdm85e','82.29.165.22',1752075726,'__ci_last_regenerate|i:1752075724;'),('0edc7trotvsqia3i33sh5ea7jhf3qkmh','82.29.165.22',1752359946,'__ci_last_regenerate|i:1752359945;'),('0f4t137epi32lecans2dfrv85e3rtcr0','82.29.165.22',1752480727,'__ci_last_regenerate|i:1752480726;'),('0fv9qfoj5acp944em56d0kmfp28srl7s','82.29.165.22',1752142566,'__ci_last_regenerate|i:1752142565;'),('0gd9oitk0ea8de6k0gicjt8d3eeus0lg','82.29.165.22',1752507009,'__ci_last_regenerate|i:1752507007;'),('0gj1k381orh9v7hpvd5ssfjhi3fhan79','152.58.131.193',1752054037,'__ci_last_regenerate|i:1752054037;is_mobile|b:1;staff_user_id|s:1:\"2\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";'),('0gtsfpb69rlkqlabni1d23b1cdvhnd8r','82.29.165.22',1752390907,'__ci_last_regenerate|i:1752390905;'),('0hot6v94qt0jtssd3bc07mak5viqfuor','82.29.165.22',1752300246,'__ci_last_regenerate|i:1752300245;'),('0hr78meustslabolu7pghvi2g30dq5kr','82.29.165.22',1752470586,'__ci_last_regenerate|i:1752470585;'),('0kk50ij8gqgdqocd8ap7vsh4817d6qs7','82.29.165.22',1752100385,'__ci_last_regenerate|i:1752100384;'),('0nhdn6i1e2mfth7r673q49n3vdqrkdta','82.29.165.22',1752337745,'__ci_last_regenerate|i:1752337745;'),('0osld6ud57b6l0mla909kj84cja451at','82.29.165.22',1752198125,'__ci_last_regenerate|i:1752198124;'),('0pnl1baak7ld5lhj1r5dsccp6c3jc0f9','82.29.165.22',1752332824,'__ci_last_regenerate|i:1752332824;'),('0q7jtd0s5j5r63t92qjlnfuuhdtsgd61','82.29.165.22',1752438906,'__ci_last_regenerate|i:1752438905;'),('0r2ifmdvvgg5h6abr58tked53k3k4p7j','82.29.165.22',1752515408,'__ci_last_regenerate|i:1752515406;'),('0sdi6n9stpr8pcr17p05vr6qugrudgsr','82.29.165.22',1752128466,'__ci_last_regenerate|i:1752128465;'),('0sein5p2ccrcp400uq6t703ckc9u4850','82.29.165.22',1752095045,'__ci_last_regenerate|i:1752095044;'),('0smno34erd20el55pt6gsc9pmr0ra2uc','82.29.165.22',1752272464,'__ci_last_regenerate|i:1752272464;'),('0snrm0okqkoantu1vgunmv3a9ru4s9u7','82.29.165.22',1752428347,'__ci_last_regenerate|i:1752428346;'),('0sre8oopj2b7e5us5f41356s90sbn8cn','82.29.165.22',1752368345,'__ci_last_regenerate|i:1752368344;'),('0vn2kc55mojkh5fe4eq0l7uaree32gv8','82.29.165.22',1752051727,'__ci_last_regenerate|i:1752051726;'),('101v1lutc1jkubbi9ieep7127nmjtha8','82.29.165.22',1752137946,'__ci_last_regenerate|i:1752137945;'),('10cf3pvrgj9178so0hc3ngcli8t07a86','82.29.165.22',1752309786,'__ci_last_regenerate|i:1752309785;'),('11f7o2paqngtojjcucc0im9nqmg04lvo','82.29.165.22',1752458586,'__ci_last_regenerate|i:1752458585;'),('12j9k8u2is3f5nn0ephss370ntju13vg','82.29.165.22',1752090905,'__ci_last_regenerate|i:1752090904;'),('12n4dh9ni3n292pdt2n4di2n4ln1c1qq','82.29.165.22',1752228367,'__ci_last_regenerate|i:1752228365;'),('135m9he9ug0eq2ov08v1eqnkhtj454aa','82.29.165.22',1752268206,'__ci_last_regenerate|i:1752268205;'),('13gttv8kruj4ca22vdkn653nao4tlndq','82.29.165.22',1752064686,'__ci_last_regenerate|i:1752064685;'),('13na4hrhcppv3ad1o4echop9u5cv9ugb','82.29.165.22',1752358505,'__ci_last_regenerate|i:1752358504;'),('14334jdjb1nsg0bkt38n2o7g9jrp1lcl','82.29.165.22',1752280806,'__ci_last_regenerate|i:1752280805;'),('15klhgjseggv19ts0nffhl19h4e2b6k4','82.29.165.22',1752246607,'__ci_last_regenerate|i:1752246606;'),('15lbgpb2vduv714k8n0amht2g4q6c97k','82.29.165.22',1752503408,'__ci_last_regenerate|i:1752503407;'),('15mhisdm8i35t69fu5d27m8ml4h5r6rg','82.29.165.22',1752183725,'__ci_last_regenerate|i:1752183724;'),('170ri5idvh0vu958llvdg2g702jv0d9m','82.29.165.22',1752520265,'__ci_last_regenerate|i:1752520264;'),('1781ntv9f91clibokdf70besu16m15uc','82.29.165.22',1752435065,'__ci_last_regenerate|i:1752435065;'),('182cinj5accb6v8u6osvf31lovhc34sg','82.29.165.22',1752365163,'__ci_last_regenerate|i:1752365161;'),('18ghq8lr33fmoa6vbmdkl6bh0kkl89rr','82.29.165.22',1752161167,'__ci_last_regenerate|i:1752161166;'),('18gmpbeiovf0os0ere9vhk0ji0bdkgik','82.29.165.22',1752060187,'__ci_last_regenerate|i:1752060186;'),('19486ugbigfkeb71dn2egvm8kdv8272d','82.29.165.22',1752440705,'__ci_last_regenerate|i:1752440704;'),('19i4avv7j04i5hcva1m7u74sr0la9csg','82.29.165.22',1752373446,'__ci_last_regenerate|i:1752373445;'),('1a9he4ds2bd382v9bfrfeio9f45ddndc','82.29.165.22',1752432606,'__ci_last_regenerate|i:1752432605;'),('1aftd3ia2942cr8cetditokuca2m64fq','82.29.165.22',1752195610,'__ci_last_regenerate|i:1752195608;'),('1ag3qkumi3ssfrinps7lf8vhh7a2hshh','82.29.165.22',1752454385,'__ci_last_regenerate|i:1752454384;'),('1anvpj1kovpch91equ8fp8o74lnnjm31','82.29.165.22',1752394086,'__ci_last_regenerate|i:1752394085;'),('1at8j969km88km1omfbk92uul6qrosc5','82.29.165.22',1752275943,'__ci_last_regenerate|i:1752275943;'),('1b0hb7l2pl2d3muj4ln2ibc8b6joicbc','82.29.165.22',1752138666,'__ci_last_regenerate|i:1752138665;'),('1b4pss39b7sh1bt5nis9a2i0atn9tpfe','82.29.165.22',1752371404,'__ci_last_regenerate|i:1752371404;'),('1bg0nooqaoh8t02u2map2mhri54nkve3','82.29.165.22',1752414846,'__ci_last_regenerate|i:1752414845;'),('1casei5jl613rdhslhe4n9a7n3ofn3jr','82.29.165.22',1752051010,'__ci_last_regenerate|i:1752051008;'),('1cj3hohjhr2ujnqau6kr43fs3r92ke5t','152.59.190.1',1752423465,'__ci_last_regenerate|i:1752423463;is_mobile|b:1;red_url|s:30:\"https://himalay.techdotbit.in/\";'),('1d6vsm7ubli5kmmo5hcphhe56fnb29i4','82.29.165.22',1752398286,'__ci_last_regenerate|i:1752398285;'),('1d7n9ftounhcrp7ed8jeaobovoi8j2qu','82.29.165.22',1752445323,'__ci_last_regenerate|i:1752445323;'),('1dobol1uiv29ag7if8tgfut4amhule1c','82.29.165.22',1752273185,'__ci_last_regenerate|i:1752273184;'),('1ejtpb4olrosh3kv84cg2jfmj49avtei','82.29.165.22',1752145028,'__ci_last_regenerate|i:1752145027;'),('1gr4fklc4e63ocgdnsks02hkkqrfsiua','82.29.165.22',1752373084,'__ci_last_regenerate|i:1752373084;'),('1hg9b3jp43s6snckhm2copmroksm8qu1','82.29.165.22',1752065046,'__ci_last_regenerate|i:1752065045;'),('1ibj8pmqc7u9povvoeui8qqh179o5lbl','82.29.165.22',1752365525,'__ci_last_regenerate|i:1752365524;'),('1ktdle3ffgqjh2147mcoojufeutnbemh','82.29.165.22',1752349985,'__ci_last_regenerate|i:1752349984;'),('1l10492u09geba1bk4nivc1m74eh1l4u','82.29.165.22',1752224826,'__ci_last_regenerate|i:1752224825;'),('1l65k3d77kqv0pm1pk8qe4h7rn82o9bk','82.29.165.22',1752367985,'__ci_last_regenerate|i:1752367984;'),('1ldbk0diluqnn5uvicepl0ltch4orfm4','82.29.165.22',1752252607,'__ci_last_regenerate|i:1752252606;'),('1lhfdjhgl7uhepjeart1pgi7lafp1ign','82.29.165.22',1752141487,'__ci_last_regenerate|i:1752141486;'),('1m98am6vigkf2uc4dtfatg7156dgiehc','82.29.165.22',1752309066,'__ci_last_regenerate|i:1752309065;'),('1nrg7pi7sg6nfuhuf7q0fo5bfl8nbsb8','82.29.165.22',1752363423,'__ci_last_regenerate|i:1752363423;'),('1oaei3ihhqce3573e8fbqs195mf6tjnv','82.29.165.22',1752402907,'__ci_last_regenerate|i:1752402906;'),('1p7baaha3nor3t1u1mepqvt0fqftluvo','82.29.165.22',1752228011,'__ci_last_regenerate|i:1752228009;'),('1pg48nlmfdlqe22kvp9b0ecpg2k6c0vd','82.29.165.22',1752248045,'__ci_last_regenerate|i:1752248044;'),('1ptg08jbhsi93mv2poqe54oeu4m77hbl','82.29.165.22',1752483908,'__ci_last_regenerate|i:1752483906;'),('1pticg5gl6t6gv24o4n4tm2hq81en7sr','82.29.165.22',1752239286,'__ci_last_regenerate|i:1752239285;'),('1ri7v6p9gtr6ppo5eb14pij5f2qghast','82.29.165.22',1752354546,'__ci_last_regenerate|i:1752354545;'),('1rpbi4v48a38m0ooc0aq94il1ab1s6tm','82.29.165.22',1752184445,'__ci_last_regenerate|i:1752184444;'),('1t0khm9u1on5jpn7fdb59clrv7cvj857','82.29.165.22',1752240365,'__ci_last_regenerate|i:1752240365;'),('1t1gmkvvbk7oh6bo4estpmbhv62l22ud','82.29.165.22',1752248349,'__ci_last_regenerate|i:1752248347;'),('1to516485olvfqqfchq0eg7kl07illl1','82.29.165.22',1752247685,'__ci_last_regenerate|i:1752247684;'),('1uok5evk2bbnlgphmb3rf2n8j3di585f','82.29.165.22',1752302708,'__ci_last_regenerate|i:1752302706;'),('1vrvgfg41mpa3pqrkis6c2b3hkpom5kf','82.29.165.22',1752118385,'__ci_last_regenerate|i:1752118384;'),('20ugfj2iuh63mqmh7bq46cjq1ish7hej','82.29.165.22',1752303069,'__ci_last_regenerate|i:1752303067;'),('2134ualsvmahsrkk302abi2a2o6i4ka3','82.29.165.22',1752475446,'__ci_last_regenerate|i:1752475445;'),('21f9tko64ie4miosdkh94giomp8ea0j8','82.29.165.22',1752389526,'__ci_last_regenerate|i:1752389525;'),('21r6m030pssn3imptg4n8ipfuevo8gta','82.29.165.22',1752427684,'__ci_last_regenerate|i:1752427684;'),('22c3g1qafhp6b1s6jehcebr8ud76tb55','117.98.44.15',1752469449,'__ci_last_regenerate|i:1752469446;is_mobile|b:1;red_url|s:30:\"https://himalay.techdotbit.in/\";'),('22fu40vm2576eag1fj0mr2e8kasgms20','82.29.165.22',1752517506,'__ci_last_regenerate|i:1752517505;'),('23dvk7mlakqtgoqe4amaof6adrt80n4d','82.29.165.22',1752135546,'__ci_last_regenerate|i:1752135545;'),('23fdqhjcvrhlff4bsnc5fv6u9o02nmqr','82.29.165.22',1752097206,'__ci_last_regenerate|i:1752097205;'),('25rvqahm9u5f8h0l9i3oue4l6fqcjovq','82.29.165.22',1752169745,'__ci_last_regenerate|i:1752169745;'),('26cj5nsv73q21v2smhju0tua9cl9819h','82.29.165.22',1752387426,'__ci_last_regenerate|i:1752387425;'),('27dth2o51g5sh6turlcqkr74oo4qe277','82.29.165.22',1752325926,'__ci_last_regenerate|i:1752325925;'),('2ajvmmaorptt08490am4q4fc2ucrk14u','82.29.165.22',1752147845,'__ci_last_regenerate|i:1752147844;'),('2ak3o7pigdhro4ltvcqd5i0i1p40pbl1','82.29.165.22',1752440345,'__ci_last_regenerate|i:1752440344;'),('2bv69ckv7oe8dipo2rflvj3hbrbhan5f','82.29.165.22',1752403206,'__ci_last_regenerate|i:1752403206;'),('2c2ufukmasup84lbnfkvtk9t4jhdag2o','82.29.165.22',1752336307,'__ci_last_regenerate|i:1752336306;'),('2dbdc55ftfkgb8cbbb9lgt6a4n0m380f','82.29.165.22',1752203826,'__ci_last_regenerate|i:1752203825;'),('2e3itcjfv8q5dr95a0fbpldk5d01f4fk','82.29.165.22',1752313986,'__ci_last_regenerate|i:1752313985;'),('2eoae8el4qcp7thq2pnt2gkk8i2qc5i5','82.29.165.22',1752391626,'__ci_last_regenerate|i:1752391625;'),('2f5572k4ukdvibuaj5upmeg3mc2ieht4','82.29.165.22',1752312908,'__ci_last_regenerate|i:1752312906;'),('2h3o171c1hqp62tsse3euk011cg4m812','82.29.165.22',1752178265,'__ci_last_regenerate|i:1752178264;'),('2jrpinnt52do1415jcndo1badanegj8t','82.29.165.22',1752519610,'__ci_last_regenerate|i:1752519609;'),('2k38dikvi7jju2j08j9v0ug4u2pvvrp2','82.29.165.22',1752338404,'__ci_last_regenerate|i:1752338404;'),('2km4b58aa74her8ifr4tkqb1ulb3q4e0','82.29.165.22',1752204484,'__ci_last_regenerate|i:1752204484;'),('2l198vgml6lo6drvqi1n7b40na7oq872','82.29.165.22',1752377706,'__ci_last_regenerate|i:1752377705;'),('2l565r08f56v8432iohi9336f0pl9nhb','82.29.165.22',1752514026,'__ci_last_regenerate|i:1752514025;'),('2l8br9slbjgtl0lloumg2q3cr3oifnpm','82.29.165.22',1752214687,'__ci_last_regenerate|i:1752214686;'),('2n36o4adukm98viii8qrqcfm37tkss65','82.29.165.22',1752059466,'__ci_last_regenerate|i:1752059465;'),('2nbhndijaqt6f3h3vpnq443scftsg1r3','82.29.165.22',1752472324,'__ci_last_regenerate|i:1752472324;'),('2nds739beem3dhlcgb8a6855pmv712il','82.29.165.22',1752157324,'__ci_last_regenerate|i:1752157324;'),('2o4pnl9nvk24usvrqjrq1pb6kp64gv8e','82.29.165.22',1752480012,'__ci_last_regenerate|i:1752480010;'),('2opmn8cgl9415q1o4t4i1aeg3ekbfjk0','82.29.165.22',1752129549,'__ci_last_regenerate|i:1752129548;'),('2p1sqh83mrjp1gbnrjcg4o1qljis4rfb','82.29.165.22',1752499927,'__ci_last_regenerate|i:1752499925;'),('2pc5uu16l91rdjo186eanlkiv3973jpq','82.29.165.22',1752141847,'__ci_last_regenerate|i:1752141845;'),('2phhshogpe8a2pt8ehp3b468f3j9sv44','82.29.165.22',1752152046,'__ci_last_regenerate|i:1752152045;'),('2q2mfgd5bk9fpre5t2ktu72d1fnvc4s1','82.29.165.22',1752201664,'__ci_last_regenerate|i:1752201664;'),('2rf905rm77a4p8nujkl91hm3rhssgjn0','82.29.165.22',1752256144,'__ci_last_regenerate|i:1752256143;'),('2vgo0l7c3egqvt7v3g62kcfeq9lh8eq6','82.29.165.22',1752182643,'__ci_last_regenerate|i:1752182643;'),('2vo8oer3mk9bk8g54pn5bsvohepfenlf','82.29.165.22',1752169026,'__ci_last_regenerate|i:1752169025;'),('30dsvea67gb9mnmvad55s4okjusivf4m','82.29.165.22',1752218227,'__ci_last_regenerate|i:1752218226;'),('30t19a6qrmo2p8meb4lltloegpb5hii1','82.29.165.22',1752410884,'__ci_last_regenerate|i:1752410884;'),('31crc7gortuhuf8qqpsp9j1aoef9183l','82.29.165.22',1752287704,'__ci_last_regenerate|i:1752287704;'),('31h0jdbaja309an0jk4a3blg9afodg5o','82.29.165.22',1752390545,'__ci_last_regenerate|i:1752390545;'),('322cjla3rgcustpkd6khc3dgkkk8jkqh','82.29.165.22',1752416225,'__ci_last_regenerate|i:1752416224;'),('32rt7mmh5444vbgbi3pqe8kp7436nr83','82.29.165.22',1752289506,'__ci_last_regenerate|i:1752289505;'),('3365lka6l1abaemcf9nisg80f6fmv9a1','49.36.189.194',1752050314,'__ci_last_regenerate|i:1752050314;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;'),('33lj0ihbdre44qlrfh3g8vh20edr26k1','82.29.165.22',1752089105,'__ci_last_regenerate|i:1752089104;'),('35kivtfnt8ono1hh65kq65ud19ik8o1p','82.29.165.22',1752063305,'__ci_last_regenerate|i:1752063305;'),('36i1k40if3t9b4tn8o8hcgk98vj63up5','82.29.165.22',1752392348,'__ci_last_regenerate|i:1752392347;'),('36qe202h6qc12ps82qdgvj9kvoudmhpo','82.29.165.22',1752337387,'__ci_last_regenerate|i:1752337385;'),('37bibir5bdqklr0745711o1hqd3kback','82.29.165.22',1752229087,'__ci_last_regenerate|i:1752229086;'),('37sfj59tkndsdo761mq9j174tvderlp6','82.29.165.22',1752101465,'__ci_last_regenerate|i:1752101464;'),('39fq85tbvfg1i6scqpkcfldc1q68n8d8','82.29.165.22',1752316026,'__ci_last_regenerate|i:1752316025;'),('3ak3annqi3jhbhkngdc0c5eosak6n10t','82.29.165.22',1752176105,'__ci_last_regenerate|i:1752176104;'),('3b6f1h9utrp4337omdmikgq8avojm54f','82.29.165.22',1752430506,'__ci_last_regenerate|i:1752430505;'),('3bmgvaqpuphkaiu5rmn1bfl9l3ft18km','82.29.165.22',1752329764,'__ci_last_regenerate|i:1752329764;'),('3btu5jo8eduvkk61lugn7bi27veccs8e','82.29.165.22',1752069185,'__ci_last_regenerate|i:1752069185;'),('3c1v13ud5nubiss0criavbg7qkmd7igo','82.29.165.22',1752381907,'__ci_last_regenerate|i:1752381905;'),('3dl56lhg3c2sgtin1gd7gdunl1locqq6','82.29.165.22',1752506286,'__ci_last_regenerate|i:1752506285;'),('3dp5apik7a7liirq66jvv14kttt3km5u','82.29.165.22',1752374886,'__ci_last_regenerate|i:1752374885;'),('3dqdsclamlblmesaf2eea6flq8rovoi2','82.29.165.22',1752396607,'__ci_last_regenerate|i:1752396606;'),('3eotottg1j8sp943cskfjnkqqn177ept','82.29.165.22',1752521345,'__ci_last_regenerate|i:1752521344;'),('3fjmdhumbmu1qu3ku97m8pl90to38qj9','152.58.131.84',1752057195,'__ci_last_regenerate|i:1752057195;is_mobile|b:1;staff_user_id|s:1:\"2\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";'),('3hgevl84a5f0nk4p850u2qrjhu2obpsh','82.29.165.22',1752359585,'__ci_last_regenerate|i:1752359584;'),('3hoi3qq68tftepn4jefeejqfmgdfcgfk','82.29.165.22',1752334926,'__ci_last_regenerate|i:1752334925;'),('3i83qvtnbll748adlc1rd924itskian1','82.29.165.22',1752273906,'__ci_last_regenerate|i:1752273905;'),('3ig04di8kqj4ha8fb11t31jv5v9mkunj','82.29.165.22',1752469504,'__ci_last_regenerate|i:1752469504;'),('3insqr7lgd77dtl8csv04m50kc0n627s','82.29.165.22',1752322327,'__ci_last_regenerate|i:1752322325;'),('3j1e17rmalj9asi06k85ujicc8k8r96j','82.29.165.22',1752200286,'__ci_last_regenerate|i:1752200285;'),('3j1gleefvfrg114o2svqg4ntr6p5bobb','82.29.165.22',1752380886,'__ci_last_regenerate|i:1752380885;'),('3jddkbnf379qrntpeeiflh4b0pqr716f','82.29.165.22',1752355625,'__ci_last_regenerate|i:1752355624;'),('3jsg0jqibj9ooq3fti4n4t3fmqte8pb8','82.29.165.22',1752110286,'__ci_last_regenerate|i:1752110285;'),('3kt6saq6pmsp1kn2t3337i0v3sfpb7ep','82.29.165.22',1752148207,'__ci_last_regenerate|i:1752148206;'),('3kv0hd6pbgkcplds7h0benjo8a8sqk5m','82.29.165.22',1752262865,'__ci_last_regenerate|i:1752262864;'),('3l8tkuba47ask9r9u3e207dhb9c8bnut','82.29.165.22',1752203106,'__ci_last_regenerate|i:1752203105;'),('3m8lmp7v35803e6t80me1cmevremj2a0','82.29.165.22',1752395165,'__ci_last_regenerate|i:1752395164;'),('3nq9lfeu5v2ul9i9nijv50qvh635kghr','82.29.165.22',1752070804,'__ci_last_regenerate|i:1752070804;'),('3p47m70vsqrvos3f8adbonue9apnehiv','82.29.165.22',1752517143,'__ci_last_regenerate|i:1752517143;'),('3ps1jo22frv9t72vr54opoio96ckk9mi','82.29.165.22',1752235747,'__ci_last_regenerate|i:1752235746;'),('3qeo9r1j2t6v2kvt3ls1r7v48mhug0d5','82.29.165.22',1752157026,'__ci_last_regenerate|i:1752157025;'),('3qsjl22ofbrreot6lobkk805ltdfnid3','82.29.165.22',1752326646,'__ci_last_regenerate|i:1752326645;'),('3smejemt7kkjhe8ra0cge893fk5n8k0n','82.29.165.22',1752219306,'__ci_last_regenerate|i:1752219305;'),('3tujho57c6ggvvsae8oj98j6g3repcu7','82.29.165.22',1752449404,'__ci_last_regenerate|i:1752449404;'),('3uih0b73qbeeun2lretrmg0274cul9qd','82.29.165.22',1752369725,'__ci_last_regenerate|i:1752369724;'),('3v9mrcrfi24rjlbv7e0n7s6mbds86ivd','82.29.165.22',1752501965,'__ci_last_regenerate|i:1752501965;'),('3vck8dgmhgq01iuhson7ojqpvp3gttnn','82.29.165.22',1752457865,'__ci_last_regenerate|i:1752457864;'),('3vepgr8oluk7hmhvotkikhrdhou0b10i','82.29.165.22',1752318908,'__ci_last_regenerate|i:1752318906;'),('3vjq2e4ujm2jnfmk4nbstar8qhkug1uj','82.29.165.22',1752237485,'__ci_last_regenerate|i:1752237485;'),('3vqhmnf1ldqrprhnm9c916s7ki7ctd2k','82.29.165.22',1752207966,'__ci_last_regenerate|i:1752207965;'),('3vs0cku99o7c5co3sk3fdue66d8diqnq','82.29.165.22',1752281165,'__ci_last_regenerate|i:1752281164;'),('417n34tp1j9uphjotpvrirkip0p1i4kb','82.29.165.22',1752476167,'__ci_last_regenerate|i:1752476165;'),('442jhqbpai0bgaomqhenkpl1altlbu5i','152.58.131.84',1752059881,'__ci_last_regenerate|i:1752059881;is_mobile|b:1;staff_user_id|s:1:\"2\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";'),('44gi27g3mdcbu5o9g5f86vub8vlfdjhv','82.29.165.22',1752336666,'__ci_last_regenerate|i:1752336665;'),('45kqepi5q3ibupkb9harfk531kcha36h','82.29.165.22',1752083706,'__ci_last_regenerate|i:1752083705;'),('46e0jqf7iltdimbsceuignorcj855ak4','82.29.165.22',1752195966,'__ci_last_regenerate|i:1752195965;'),('474iko30q65bdcp7gt5fv6ugas0auu32','82.29.165.22',1752271085,'__ci_last_regenerate|i:1752271084;'),('47577p8stqa0n12rq9kac0i580o2o1j1','82.29.165.22',1752071885,'__ci_last_regenerate|i:1752071884;'),('47fl34bnh0v7jlgrqg1ppu75lihqqv5t','82.29.165.22',1752177905,'__ci_last_regenerate|i:1752177904;'),('48ifqucifvqtaev2j0nt9lvc5j0og8qn','82.29.165.22',1752475808,'__ci_last_regenerate|i:1752475807;'),('48qavi3ujldtb9l87t2qu6hdmdv2q35a','110.172.155.237',1752053136,'__ci_last_regenerate|i:1752053136;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;'),('493qomscc2p1qqa08re6nnv4ggd2k6kc','82.29.165.22',1752144306,'__ci_last_regenerate|i:1752144306;'),('499lpf3u86kg8pjn5lmpvp4jr55bja6h','82.29.165.22',1752102484,'__ci_last_regenerate|i:1752102483;'),('4bcv3pe2j7m97g6q2oaojoqdjmoe3s90','82.29.165.22',1752239645,'__ci_last_regenerate|i:1752239645;'),('4c1akpp0ldfb7qsn10q3i7ihbh3oiigr','82.29.165.22',1752240007,'__ci_last_regenerate|i:1752240006;'),('4csc2ukifgsbhlujhbucmr4h0rb7l6tc','82.29.165.22',1752478567,'__ci_last_regenerate|i:1752478565;'),('4dqmu653q47ghmnsddt36st6kmdmq8t4','82.29.165.22',1752382627,'__ci_last_regenerate|i:1752382626;'),('4e550lktvhcgbmu40rm9akgcrf35nnns','82.29.165.22',1752048847,'__ci_last_regenerate|i:1752048846;'),('4e8538sop6a9575thhb3jiolshe8oluh','82.29.165.22',1752245226,'__ci_last_regenerate|i:1752245225;'),('4efp5belfl11n3r2hkoo2kbalineun0r','82.29.165.22',1752472985,'__ci_last_regenerate|i:1752472985;'),('4fmpl2s8esoe9oiejjbm2p8q3051o862','49.36.189.194',1752225972,'__ci_last_regenerate|i:1752225933;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";'),('4ftp0om5p61f3924odh1qk7ojr4sikub','82.29.165.22',1752240664,'__ci_last_regenerate|i:1752240664;'),('4ioumfcec4nab7agin71dbot4e7c0a8u','82.29.165.22',1752241386,'__ci_last_regenerate|i:1752241385;'),('4isth6mvdc0i43t6pssslm3rucrk3n86','82.29.165.22',1752396246,'__ci_last_regenerate|i:1752396245;'),('4ke186h5od97bcbt1qsr8mrurbjec5uv','82.29.165.22',1752174664,'__ci_last_regenerate|i:1752174664;'),('4krqo3fnfr449aliqqhpe14l9g609qm7','82.29.165.22',1752287045,'__ci_last_regenerate|i:1752287044;'),('4nd9usbgm5nrsbu59trjrokgrncsrjl7','82.29.165.22',1752243485,'__ci_last_regenerate|i:1752243484;'),('4ndu8ci5vkubqk3i6f6vtalk9qv2maq8','82.29.165.22',1752369365,'__ci_last_regenerate|i:1752369364;'),('4ntjhr7bg37nv6igofofpmqsjan7nn4g','82.29.165.22',1752176465,'__ci_last_regenerate|i:1752176464;'),('4r64q0jh7qrd9vgp95s95kbqfb6h95bp','82.29.165.22',1752091209,'__ci_last_regenerate|i:1752091208;'),('4rt8v06dglt4rmi0ea0bp63r328f5un3','82.29.165.22',1752110584,'__ci_last_regenerate|i:1752110584;'),('4s9jrq4q5b32s4b5keqg0e9lnebnjemu','82.29.165.22',1752291906,'__ci_last_regenerate|i:1752291905;'),('4sc3hc1ov64u8amudtlfdi7qhm5o56cp','82.29.165.22',1752285305,'__ci_last_regenerate|i:1752285304;'),('4tb899uarbrfebr95sklukn57h5q5i1s','82.29.165.22',1752396904,'__ci_last_regenerate|i:1752396904;'),('4uuesdhfcj97u7dj0o397npuj5qcmo40','82.29.165.22',1752152411,'__ci_last_regenerate|i:1752152410;'),('4v6s0eomvbk86c0a35054rojcnt0gvl9','82.29.165.22',1752494046,'__ci_last_regenerate|i:1752494045;'),('4vt4353pov86mbu26ua5hap3ikqmmtbt','82.29.165.22',1752249726,'__ci_last_regenerate|i:1752249725;'),('503dp70ua4op576nm8pphc24q07nopqh','82.29.165.22',1752496805,'__ci_last_regenerate|i:1752496804;'),('508sckhhb6fh1koujvnc95i6c1c39e4r','82.29.165.22',1752234666,'__ci_last_regenerate|i:1752234665;'),('50p344bnbi2rklg9f5278eimbcqoq1tf','82.29.165.22',1752379446,'__ci_last_regenerate|i:1752379445;'),('520r0grlqqcu7rt87j0kolbakonl8u88','82.29.165.22',1752329465,'__ci_last_regenerate|i:1752329464;'),('54d19ps0fm5p5cqvoatguvid7tc71dg8','82.29.165.22',1752267184,'__ci_last_regenerate|i:1752267184;'),('54qclhl835tnsr8h8fkvc9p7unkq8jpt','82.29.165.22',1752290464,'__ci_last_regenerate|i:1752290463;'),('5593k0tokak4aqj0kjefvfe0tvs5tdem','82.29.165.22',1752510545,'__ci_last_regenerate|i:1752510545;'),('55dqa77f2j9mr2e5ltiqqqibjo8uhq2q','82.29.165.22',1752358146,'__ci_last_regenerate|i:1752358146;'),('55jhi10onc143qadu8qncvfvqaa03ek4','82.29.165.22',1752512645,'__ci_last_regenerate|i:1752512644;'),('568ehkbsos4bqfk2e9efibuqcbuvvhob','82.29.165.22',1752271805,'__ci_last_regenerate|i:1752271805;'),('56gio2ms0thmgg9rp4aghkek90vr65f7','82.29.165.22',1752468486,'__ci_last_regenerate|i:1752468485;'),('56rhru1s34fnvnv3vhs1m87c7gevctm0','82.29.165.22',1752408485,'__ci_last_regenerate|i:1752408484;'),('56t3kvsocsapusjpkht9l4b62u153k6q','82.29.165.22',1752168667,'__ci_last_regenerate|i:1752168666;'),('57tpf13gka49u0les96iihuihpe534fa','82.29.165.22',1752397564,'__ci_last_regenerate|i:1752397564;'),('595d2v7i7ok741jmsfjtq012phch87d7','82.29.165.22',1752121926,'__ci_last_regenerate|i:1752121925;'),('59lt8oluaovfi6r3grhholv46of5uda8','82.29.165.22',1752524108,'__ci_last_regenerate|i:1752524106;'),('59urqbpkhtkqg467juf2blll0vkglinv','82.29.165.22',1752126426,'__ci_last_regenerate|i:1752126424;'),('5a4vcis2c15pn4ehllv42pauj3f4pvmg','82.29.165.22',1752106685,'__ci_last_regenerate|i:1752106684;'),('5cvnon9rnhqrg5b58q2qkt3dvvdpkoqe','82.29.165.22',1752492248,'__ci_last_regenerate|i:1752492246;'),('5e4tkafalddtka7iioi1he4egia4mj1t','82.29.165.22',1752490927,'__ci_last_regenerate|i:1752490926;'),('5fghd5ilto8rmm8n10ssrt7r88uues2v','82.29.165.22',1752374526,'__ci_last_regenerate|i:1752374525;'),('5fr0194nmhcimltt6703nha6ac69qada','82.29.165.22',1752242765,'__ci_last_regenerate|i:1752242765;'),('5g2ib7l71i2jvlu4phmjfg7vd58i2ktp','82.29.165.22',1752381548,'__ci_last_regenerate|i:1752381547;'),('5hcc020blhupuplqbe254qdmuq3aoskn','82.29.165.22',1752192845,'__ci_last_regenerate|i:1752192844;'),('5j9prvs75aci2a1kgodv94g13v5f0bei','82.29.165.22',1752075366,'__ci_last_regenerate|i:1752075365;'),('5jg64vamgb2dbllgf7mopp7soisio6qu','82.29.165.22',1752266465,'__ci_last_regenerate|i:1752266464;'),('5jjho9nr3aend08s472evg2r4km0krs6','82.29.165.22',1752085866,'__ci_last_regenerate|i:1752085865;'),('5ma67tg9llhd2snpboe7l2gi1rf77ev3','82.29.165.22',1752495424,'__ci_last_regenerate|i:1752495424;'),('5nl7e7jp47tnqn6ooh5vfep45h5q48nj','82.29.165.22',1752202025,'__ci_last_regenerate|i:1752202024;'),('5nlqb0medg5gj25hgdan9tko3ro4m4t9','82.29.165.22',1752491225,'__ci_last_regenerate|i:1752491225;'),('5q20tro1ssc8o2kvd6jhma89s8ctsnn5','82.29.165.22',1752338106,'__ci_last_regenerate|i:1752338105;'),('5q3s3js9mir9008g7gfmflhbght2n8g8','82.29.165.22',1752395527,'__ci_last_regenerate|i:1752395525;'),('5qqgvuj8r4q2l3n6beoa1en66re8se34','82.29.165.22',1752511563,'__ci_last_regenerate|i:1752511563;'),('5s93j7s863r56oliaioocg741gt1e6fp','82.29.165.22',1752474726,'__ci_last_regenerate|i:1752474724;'),('5t23nc5trjr4rahhjeof2scph3m8iv2l','82.29.165.22',1752451225,'__ci_last_regenerate|i:1752451221;'),('5t441jdl5uuvna9610tuip8to7vrvm84','82.29.165.22',1752178925,'__ci_last_regenerate|i:1752178924;'),('5tpfqvanomgn5qhag1a3m2qlf31635ni','82.29.165.22',1752331506,'__ci_last_regenerate|i:1752331505;'),('5uk05997ufkmo1mjblst2n3cq0dmjc0r','82.29.165.22',1752444305,'__ci_last_regenerate|i:1752444304;'),('5usfkg5eadnmvkf6itl3nv1q690r0qiv','82.29.165.22',1752501612,'__ci_last_regenerate|i:1752501609;'),('5v39ptq9c7qi90ceh9dehngkqsi42jd2','82.29.165.22',1752307986,'__ci_last_regenerate|i:1752307985;'),('5v4v2rra7o6j52p2ib88f7p1g93ofa2h','82.29.165.22',1752248706,'__ci_last_regenerate|i:1752248705;'),('5v5gamm0iotdd0rq50odo8dabl3gjnub','82.29.165.22',1752352385,'__ci_last_regenerate|i:1752352384;'),('5v5qib8s989jcotb0v23d3vihi228ioj','82.29.165.22',1752196326,'__ci_last_regenerate|i:1752196325;'),('5vb6i6mkhe7006evr96g2bbir0ubes96','82.29.165.22',1752187565,'__ci_last_regenerate|i:1752187564;'),('5vmutbiqo8bmongfq6i8mij0l6p14gpc','82.29.165.22',1752111666,'__ci_last_regenerate|i:1752111665;'),('5vtci21nprgn6lejv6kb37j3f84jtkj4','82.29.165.22',1752496146,'__ci_last_regenerate|i:1752496145;'),('60tt47llr73v2vb2gsps4cbidjsu4put','82.29.165.22',1752080164,'__ci_last_regenerate|i:1752080164;'),('60vvkso35lkjg8j1t16s98cmgmhm81l0','82.29.165.22',1752220987,'__ci_last_regenerate|i:1752220985;'),('61survehoaflhi6e3l6mbh5lro8t06o4','82.29.165.22',1752516126,'__ci_last_regenerate|i:1752516125;'),('62bbgck93m2r40p6765c0la170a7a6ug','82.29.165.22',1752460685,'__ci_last_regenerate|i:1752460684;'),('62k6tus4lhpb46q9p99suddur1urunc4','82.29.165.22',1752210010,'__ci_last_regenerate|i:1752210008;'),('6364hliuma9q8cbnboao9d1nuqhadmik','82.29.165.22',1752382267,'__ci_last_regenerate|i:1752382266;'),('63fm8buit4ntktrqghbcchhu3cq45r7j','82.29.165.22',1752178564,'__ci_last_regenerate|i:1752178564;'),('65v1r62go8u8b59sl1glgts7ub1kljm7','82.29.165.22',1752411611,'__ci_last_regenerate|i:1752411609;'),('66aabs3j566e13h2m9k6u5e7fakbgjb4','82.29.165.22',1752216786,'__ci_last_regenerate|i:1752216785;'),('67vb1j0tbphlpfsta1b7vet981chdo0r','82.29.165.22',1752089825,'__ci_last_regenerate|i:1752089824;'),('68d6fv0lv5bj9gbi0be15lbl5u5u5cue','82.29.165.22',1752468126,'__ci_last_regenerate|i:1752468124;'),('69dsnshlrg0qlh1ho8jqftfsurjf6ov1','82.29.165.22',1752400086,'__ci_last_regenerate|i:1752400084;'),('6b47ct4kta6s18biibm2ldhd3n0ihs7f','82.29.165.22',1752481446,'__ci_last_regenerate|i:1752481445;'),('6b99s2p9ln51rnipd8vdgin71t3gereh','82.29.165.22',1752504486,'__ci_last_regenerate|i:1752504485;'),('6cdvgckin2g03gcju9mqck7g86gbd8vp','82.29.165.22',1752353465,'__ci_last_regenerate|i:1752353464;'),('6dqavrbp0k8hvvdtjuib0f755a2bjj39','82.29.165.22',1752437165,'__ci_last_regenerate|i:1752437164;'),('6easjmbqgk79rn8ap6lt4c05c6q05qrd','82.29.165.22',1752216426,'__ci_last_regenerate|i:1752216425;'),('6f6kd39lbkuf6t501dv8iv3es0rlf8kv','82.29.165.22',1752512285,'__ci_last_regenerate|i:1752512284;'),('6fbdv66p6goapqutnmaijccmkjmh5out','82.29.165.22',1752231186,'__ci_last_regenerate|i:1752231186;'),('6fn6d03qirmqh0a6h5ng4vdeehdc1qrd','82.29.165.22',1752459307,'__ci_last_regenerate|i:1752459306;'),('6hoa6hdcc3p92egg08qrg6gh78sifcie','82.29.165.22',1752153126,'__ci_last_regenerate|i:1752153125;'),('6jagc7hiv9e7ndptk7koajgt1p6d36dv','82.29.165.22',1752059827,'__ci_last_regenerate|i:1752059825;'),('6jtnihbi16sjah67rqo9kfsqqtodu42i','82.29.165.22',1752520986,'__ci_last_regenerate|i:1752520985;'),('6k86016fct3g585buq2ck0k6gf3ocsr2','82.29.165.22',1752164408,'__ci_last_regenerate|i:1752164407;'),('6kdqmg1d3p569l0adai517gibd38j2fm','82.29.165.22',1752412326,'__ci_last_regenerate|i:1752412325;'),('6l0i4m9ck3ahj3ndap06okaj0k0juh47','82.29.165.22',1752433625,'__ci_last_regenerate|i:1752433624;'),('6lo4pe1q9gjsn07s84ilt59t8r4gb1ao','82.29.165.22',1752186545,'__ci_last_regenerate|i:1752186544;'),('6lob9sq6t1bqbsq0b5sgbhovt9usqrch','82.29.165.22',1752137227,'__ci_last_regenerate|i:1752137226;'),('6ntohp3bt71g409gvrv98udliqvfjagr','82.29.165.22',1752086586,'__ci_last_regenerate|i:1752086585;'),('6o225c0gm8t9991vlh161fpnk0e2lhgm','82.29.165.22',1752113765,'__ci_last_regenerate|i:1752113764;'),('6p0b0qosbvfjdjvbqgb89b7ri9euj2h0','82.29.165.22',1752080525,'__ci_last_regenerate|i:1752080525;'),('6pdii4s69mstto1mairavcutd5o2cm69','82.29.165.22',1752501007,'__ci_last_regenerate|i:1752501006;'),('6qbsbilm9c3qc215nl3smjgfalgtc5ce','82.29.165.22',1752301687,'__ci_last_regenerate|i:1752301685;'),('6tiq8td4qqiifpdfje77vpe0k5aes9ul','82.29.165.22',1752233286,'__ci_last_regenerate|i:1752233285;'),('6tjial1t7minigr1un6hcjs8gt9ivc1v','82.29.165.22',1752058024,'__ci_last_regenerate|i:1752058024;'),('6tshjirjp13ffo9hcrgjp273nernff2b','82.29.165.22',1752241025,'__ci_last_regenerate|i:1752241024;'),('6usgvu193js5lv8ceacgu51b37q25ecb','82.29.165.22',1752282845,'__ci_last_regenerate|i:1752282844;'),('6v0718dd8gk0bvv4sd83b6b8uf0f2h6m','82.29.165.22',1752142927,'__ci_last_regenerate|i:1752142926;'),('6vbmkl875et3ul6dhj8dnp23crhiujrv','82.29.165.22',1752116585,'__ci_last_regenerate|i:1752116585;'),('707ip88j29vtqob5em4ljbt8cv4nactj','82.29.165.22',1752177545,'__ci_last_regenerate|i:1752177544;'),('7116grb8hofu5qhsshtunvm1h3o17acs','82.29.165.22',1752212886,'__ci_last_regenerate|i:1752212885;'),('72463brfe1dbjevgc43hkct28d9gbble','82.29.165.22',1752254045,'__ci_last_regenerate|i:1752254044;'),('72hh9g6qeircfhjrkdcs87mv83disn5i','82.29.165.22',1752295025,'__ci_last_regenerate|i:1752295024;'),('74vcigk8gppqo1qh5h0nodh49hcnu8l0','82.29.165.22',1752342965,'__ci_last_regenerate|i:1752342965;'),('753f46r7kv3o5k9qq3oa1erghrfc7jmc','82.29.165.22',1752450845,'__ci_last_regenerate|i:1752450844;'),('76q5329km2cuij80ho1rqg338pqg63db','82.29.165.22',1752088025,'__ci_last_regenerate|i:1752088024;'),('77vl1u39cpeb0p2qev61uhh08443tlgm','82.29.165.22',1752462846,'__ci_last_regenerate|i:1752462845;'),('78u06e3pvfko3ld7c3r2paemsedtbhcs','82.29.165.22',1752363124,'__ci_last_regenerate|i:1752363124;'),('79834ohk4i7kragm0njdqeu7kg5oaeii','82.29.165.22',1752437525,'__ci_last_regenerate|i:1752437525;'),('798gbumrm7idvigotrk6ft4or0uqnnkg','82.29.165.22',1752170764,'__ci_last_regenerate|i:1752170764;'),('79p3nvc4197saode1pshuge54a5ogtra','82.29.165.22',1752358865,'__ci_last_regenerate|i:1752358864;'),('7a528jpm327cpj901oudtnrvme6oj230','82.29.165.22',1752460026,'__ci_last_regenerate|i:1752460024;'),('7abh4r5hrb2lnfid599ouhokfhbl0arr','82.29.165.22',1752389164,'__ci_last_regenerate|i:1752389164;'),('7aoaugv1fcs5sqjfv01g7plud4blhpmi','82.29.165.22',1752461765,'__ci_last_regenerate|i:1752461764;'),('7asuf6qq7en0kttqr19oqv04a0rm894g','82.29.165.22',1752181985,'__ci_last_regenerate|i:1752181985;'),('7b4lpbfggeuo2b8p74tbg74eg0bf9elp','82.29.165.22',1752439625,'__ci_last_regenerate|i:1752439624;'),('7b866n2sva179df3vn78bsam0q5jdhfd','82.29.165.22',1752246244,'__ci_last_regenerate|i:1752246244;'),('7bqi1nj60aunf2f3pq67i664phu0c1ml','82.29.165.22',1752348185,'__ci_last_regenerate|i:1752348184;'),('7c73bpdmb5hrq7qkmmcsp8b8vtcjo5ve','82.29.165.22',1752063667,'__ci_last_regenerate|i:1752063665;'),('7cchmuvocfkvaigbl8e6edpgmnhe8rft','82.29.165.22',1752483186,'__ci_last_regenerate|i:1752483185;'),('7cu9j1qq71ndr6b1bu686350ldbociaa','82.29.165.22',1752393726,'__ci_last_regenerate|i:1752393725;'),('7dbainq58bl3uocemgo2p3i6shgiv8ac','82.29.165.22',1752170107,'__ci_last_regenerate|i:1752170105;'),('7dsvbneus56542ra2gkbrtd2pp6uueji','82.29.165.22',1752516485,'__ci_last_regenerate|i:1752516484;'),('7fgfdn97j7a26sv3uq2n3mtqjljkgluh','82.29.165.22',1752343325,'__ci_last_regenerate|i:1752343324;'),('7fkrivencuk6ibl0ckdj3jjrm3m657jr','82.29.165.22',1752407467,'__ci_last_regenerate|i:1752407466;'),('7g62sb18fo2k80hh5a25nj3msfhudam5','82.29.165.22',1752412685,'__ci_last_regenerate|i:1752412684;'),('7h39fijic9q0g66em4i82b33msdi14ca','82.29.165.22',1752261066,'__ci_last_regenerate|i:1752261065;'),('7h761cfuqnmktkaqknqi89q9172hj38c','82.29.165.22',1752079865,'__ci_last_regenerate|i:1752079864;'),('7heqq7t347thknhbc3jf5bjllmploema','82.29.165.22',1752424926,'__ci_last_regenerate|i:1752424925;'),('7hh0fblhlu8p1pdse97kk3rr58trmj2f','82.29.165.22',1752455404,'__ci_last_regenerate|i:1752455404;'),('7hio13k1jkoal4iad3aik5hfk2qk87gu','82.29.165.22',1752265744,'__ci_last_regenerate|i:1752265744;'),('7jfhvb3h3bluoobs4nfc7peq0rtc6jon','82.29.165.22',1752090545,'__ci_last_regenerate|i:1752090545;'),('7kho4q0v3a6ksbqpogjmanfc4ni580lk','82.29.165.22',1752133086,'__ci_last_regenerate|i:1752133085;'),('7kk4utss0j75875glb3u0j5snkegmp3d','82.29.165.22',1752126724,'__ci_last_regenerate|i:1752126724;'),('7lbvuq408otn8qtef25sim0huv1tmajm','82.29.165.22',1752314646,'__ci_last_regenerate|i:1752314645;'),('7mir3gdejgtbkj6g7k7g16dqtiktqmbe','152.58.131.50',1752051254,'__ci_last_regenerate|i:1752051254;is_mobile|b:1;staff_user_id|s:1:\"2\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";'),('7n1t1gnb5j0hker44fgdlv4da9p05tgn','82.29.165.22',1752301984,'__ci_last_regenerate|i:1752301984;'),('7ndacnr956f070a794qv2ao370dgva0f','82.29.165.22',1752376325,'__ci_last_regenerate|i:1752376324;'),('7nu4uaqp297bhvad8u1jep5e460i1rv7','82.29.165.22',1752199211,'__ci_last_regenerate|i:1752199209;'),('7nve47lfd5p052kt9nr1fkom8scq1u2s','82.29.165.22',1752490208,'__ci_last_regenerate|i:1752490207;'),('7o5dt4bqtcvus8uj07qvlsnddpleb66p','82.29.165.22',1752166866,'__ci_last_regenerate|i:1752166865;'),('7qarfr26sada4ldo7lgkq3qtgeamlid3','82.29.165.22',1752055267,'__ci_last_regenerate|i:1752055266;'),('7rhv4vmq0drg605c6jj1es7q9gvk4rns','82.29.165.22',1752094385,'__ci_last_regenerate|i:1752094384;'),('7rmaq390o89rmg35orfr6duskorpbpq8','82.29.165.22',1752514683,'__ci_last_regenerate|i:1752514683;'),('7t0ac0g7jo7ut5ns8q0ubmh612d5a3ju','82.29.165.22',1752084785,'__ci_last_regenerate|i:1752084784;'),('7titkkdarc1j9in0pc8rt6eov453u6th','82.29.165.22',1752327010,'__ci_last_regenerate|i:1752327008;'),('7trv5brqer2bk58bhbupdhskd1djrquo','82.29.165.22',1752165486,'__ci_last_regenerate|i:1752165485;'),('7vmuaeb0fgutbekuira0l8b7osvlj9mj','82.29.165.22',1752235025,'__ci_last_regenerate|i:1752235025;'),('80cejqp9n9n5nbtcr30l7o9sdmvdvah4','82.29.165.22',1752330786,'__ci_last_regenerate|i:1752330785;'),('80fk9ai36grpd6p9fkc7vu76oh396hlp','82.29.165.22',1752081545,'__ci_last_regenerate|i:1752081544;'),('80va685ardgmgn7a2777iplfnkbc1vkp','82.29.165.22',1752491885,'__ci_last_regenerate|i:1752491885;'),('81dqj86gqsebaj0078v3sqd21ec71e6p','82.29.165.22',1752204186,'__ci_last_regenerate|i:1752204185;'),('826joj86pkjetg3es3jl9m9s31gcsngo','82.29.165.22',1752122287,'__ci_last_regenerate|i:1752122286;'),('83brq4osu7pu1fd9o7bulv0i5u360gsd','82.29.165.22',1752107765,'__ci_last_regenerate|i:1752107764;'),('83dd9ek90fihmcendv86uvt5jlq48puq','82.29.165.22',1752081186,'__ci_last_regenerate|i:1752081185;'),('86ld13r9dtfvidaa93s47tt3mrr7qnmr','82.29.165.22',1752115506,'__ci_last_regenerate|i:1752115505;'),('87u5vb3rd02t55vi1j3b0aso47d8rpt5','82.29.165.22',1752307266,'__ci_last_regenerate|i:1752307266;'),('888a7v7j10gvpcafoi91omgs8luja30g','82.29.165.22',1752346809,'__ci_last_regenerate|i:1752346807;'),('89ft4s402n0venihdo0cu6k4fkpsonkn','82.29.165.22',1752199925,'__ci_last_regenerate|i:1752199924;'),('89o7s2uvkeao1f39lr5va8512lfiuu0v','82.29.165.22',1752338766,'__ci_last_regenerate|i:1752338765;'),('89onn36771cd7tnalqqf50d8qrr7s11m','82.29.165.22',1752418266,'__ci_last_regenerate|i:1752418265;'),('8a1lbgseb5ia091ktjannn20adfaje6r','82.29.165.22',1752050647,'__ci_last_regenerate|i:1752050645;'),('8ac2m0u3cncfiid5nnu6j948nmjmpu6c','82.29.165.22',1752418986,'__ci_last_regenerate|i:1752418985;'),('8bt60776vo6563n6koni0ra9kng75mdj','82.29.165.22',1752246967,'__ci_last_regenerate|i:1752246966;'),('8cukggonu94jn34q34ude09ga94gfc51','82.29.165.22',1752376986,'__ci_last_regenerate|i:1752376985;'),('8d16oij891v1r37q35knnnvfbhe3469t','82.29.165.22',1752053526,'__ci_last_regenerate|i:1752053525;'),('8g2um2idkv51piqq30tr6jbl3ejrgq7h','82.29.165.22',1752354906,'__ci_last_regenerate|i:1752354905;'),('8gfhttlasgmu81ilrbscskif56rma0go','82.29.165.22',1752080824,'__ci_last_regenerate|i:1752080823;'),('8hh7hv6qqje3ut5eoa73lu4c415edmjl','82.29.165.22',1752136209,'__ci_last_regenerate|i:1752136208;'),('8hqmacftnfos4oah67u8ucbdejo9qddb','82.29.165.22',1752108125,'__ci_last_regenerate|i:1752108124;'),('8hvopqgg89ll8ghadc8v773c5ic2ir4l','82.29.165.22',1752376624,'__ci_last_regenerate|i:1752376624;'),('8iejft5gb65ip6kk57vbf3qakm1gljdu','82.29.165.22',1752101825,'__ci_last_regenerate|i:1752101824;'),('8iqg5cmg2btdv4bfdv4fjt54e8nuvjoe','82.29.165.22',1752235386,'__ci_last_regenerate|i:1752235385;'),('8jhnvvugcp2tpmh759477ke4h732vtdt','82.29.165.22',1752072606,'__ci_last_regenerate|i:1752072605;'),('8k8gkk540v4d9cfgfdik8lijhig5c59o','82.29.165.22',1752391987,'__ci_last_regenerate|i:1752391986;'),('8l87nprv62nqbh6iru67j0k2ars5rqpp','82.29.165.22',1752060908,'__ci_last_regenerate|i:1752060906;'),('8lfk2ngklbmj0tjpitgnbge39lapcmpc','82.29.165.22',1752464946,'__ci_last_regenerate|i:1752464945;'),('8ltacjadcqmi4b1oqc53eu4blk1javjj','82.29.165.22',1752258610,'__ci_last_regenerate|i:1752258608;'),('8n9mlm1pienf5tqps5reep2glhtdufit','82.29.165.22',1752074345,'__ci_last_regenerate|i:1752074344;'),('8ncu0dcer2cf40g5799idt85br23fpk0','82.29.165.22',1752470946,'__ci_last_regenerate|i:1752470945;'),('8nrqaeatk9pd0o3es681ekt35c2c0vsb','82.29.165.22',1752175385,'__ci_last_regenerate|i:1752175384;'),('8oda6rdh259r2iut3tu0tlni2kfrq60h','82.29.165.22',1752507365,'__ci_last_regenerate|i:1752507364;'),('8pflemedmdlrf5a5oopb3ifu0bjnct0o','82.29.165.22',1752098223,'__ci_last_regenerate|i:1752098223;'),('8qetle0k2sfjf7jgiupij3k1vlg4asjs','82.29.165.22',1752323409,'__ci_last_regenerate|i:1752323407;'),('8regh31q8e9fej6446ed5avb0ehvbj0t','82.29.165.22',1752327726,'__ci_last_regenerate|i:1752327725;'),('8rlekuan26393g0gkp82h8m9d9o00fdg','82.29.165.22',1752323766,'__ci_last_regenerate|i:1752323765;'),('8sbkiqssa7h1f26bnadnrdq8qgpu9404','82.29.165.22',1752391266,'__ci_last_regenerate|i:1752391265;'),('8soor8hofig86s1hav5mgi40q240m5dm','82.29.165.22',1752097924,'__ci_last_regenerate|i:1752097923;'),('8t0at2d9o1akeovrtjtorcm9fi2aleaq','82.29.165.22',1752400384,'__ci_last_regenerate|i:1752400384;'),('8tbt81onl16hul7sn2ipqhdvd3ttaeuh','82.29.165.22',1752269645,'__ci_last_regenerate|i:1752269644;'),('8tli5cvs7dgoba7ck4uv2fvseja287t7','82.29.165.22',1752279425,'__ci_last_regenerate|i:1752279424;'),('8uakmuf45aiv6o6qmqiufit3hncsc7as','82.29.165.22',1752461406,'__ci_last_regenerate|i:1752461405;'),('8ue7g39eju3vk2ds2at55sscrj05cdhe','82.29.165.22',1752146468,'__ci_last_regenerate|i:1752146467;'),('8uujav27lb5agd7g3up7rpjn958i4ojg','82.29.165.22',1752432245,'__ci_last_regenerate|i:1752432245;'),('8vtldjid4p6dl3pe314sjd06hug3oj5r','82.29.165.22',1752422106,'__ci_last_regenerate|i:1752422105;'),('90h73aent8se1cd58ovj1i1llqd5i23a','82.29.165.22',1752276305,'__ci_last_regenerate|i:1752276304;'),('90kc3cki5msplhvor160ru3bbrak9k7f','82.29.165.22',1752479646,'__ci_last_regenerate|i:1752479645;'),('91781tekgptj5gdnr2osdip5krdiroa9','82.29.165.22',1752457147,'__ci_last_regenerate|i:1752457146;'),('92eo00mffmuccnh1qnom6kdt360ku2j9','82.29.165.22',1752469209,'__ci_last_regenerate|i:1752469207;'),('93vrdf0sl1387cu5rpkmpipjpoo1q2o2','82.29.165.22',1752361385,'__ci_last_regenerate|i:1752361384;'),('9401r0d47j7to6mn08a56ncv7r3mp2v4','82.29.165.22',1752225487,'__ci_last_regenerate|i:1752225486;'),('94kkhvvrsildrobga2o7cfva0kjs1pj3','82.29.165.22',1752480367,'__ci_last_regenerate|i:1752480366;'),('95a9882sknb892i8dq8as4mrc84ujp1e','82.29.165.22',1752407826,'__ci_last_regenerate|i:1752407825;'),('9723gcpm7sff5sohu6d5dnc5auebafah','82.29.165.22',1752137586,'__ci_last_regenerate|i:1752137585;'),('972o9ugv0ri144ep6md8ukst5v0m8kbf','82.29.165.22',1752328024,'__ci_last_regenerate|i:1752328024;'),('97ifi8niq91pc22s3vhhnoue8ftoe73n','82.29.165.22',1752259685,'__ci_last_regenerate|i:1752259684;'),('9a1neoovs4be2aa5nl5b2u2tvk6rcirl','82.29.165.22',1752124686,'__ci_last_regenerate|i:1752124685;'),('9a4je2s6p8i2ksrse4j2jn85dsruigtj','82.29.165.22',1752448743,'__ci_last_regenerate|i:1752448743;'),('9av1b5qom6r82hii7jaoo5ffsl64ts6e','82.29.165.22',1752073983,'__ci_last_regenerate|i:1752073983;'),('9b08df95v4hgf49u0fbv6192lc27i04e','82.29.165.22',1752247325,'__ci_last_regenerate|i:1752247324;'),('9c2f5j6mfdr97q7uvso6qtkjnjpf2i8g','82.29.165.22',1752436810,'__ci_last_regenerate|i:1752436809;'),('9cimtqpid1o8m9iciqa2ertupgf7vm9o','82.29.165.22',1752496507,'__ci_last_regenerate|i:1752496506;'),('9cjf823t9mvvc5m943e6h63cgafnh5m2','82.29.165.22',1752258965,'__ci_last_regenerate|i:1752258964;'),('9clb43bh9bdntvi67nk3h30fqv8rtepm','82.29.165.22',1752192126,'__ci_last_regenerate|i:1752192125;'),('9fcapfenrmk2n42vm5ukiqjl0pj9q1rh','82.29.165.22',1752274564,'__ci_last_regenerate|i:1752274563;'),('9fvbm6ndda3d6a70p36hgtlirnfibip9','82.29.165.22',1752460324,'__ci_last_regenerate|i:1752460324;'),('9gkh3n6jcm0s8pgl4tupuvs0bt5nmp0i','82.29.165.22',1752404587,'__ci_last_regenerate|i:1752404586;'),('9glq6g928nfgcetptutk8gtc9pr6qu9d','82.29.165.22',1752355985,'__ci_last_regenerate|i:1752355984;'),('9gu824hq7gips16gccbq4tqqsm5876pp','82.29.165.22',1752470225,'__ci_last_regenerate|i:1752470224;'),('9h0j3m0qkc7r61hbemu7eit26jliuubq','82.29.165.22',1752312186,'__ci_last_regenerate|i:1752312185;'),('9hl28o09amulvurbcg4cie7llk4s0606','82.29.165.22',1752365885,'__ci_last_regenerate|i:1752365885;'),('9hvo9s3evh7jj9vgp8hr27h42ng5di6o','82.29.165.22',1752128827,'__ci_last_regenerate|i:1752128825;'),('9ji2323n8a41d9496o6gk02ib1mq4804','82.29.165.22',1752078483,'__ci_last_regenerate|i:1752078483;'),('9jmss6tshn45lp2fvdr8f00f7viff1o7','82.29.165.22',1752159066,'__ci_last_regenerate|i:1752159065;'),('9kdfpk47mpsq9ls0ljo0ivuqpu1u7rpv','82.29.165.22',1752132008,'__ci_last_regenerate|i:1752132006;'),('9lbmie38jsibje3kb5lf0pj5e7snhnv7','82.29.165.22',1752150667,'__ci_last_regenerate|i:1752150666;'),('9m3s7ue6porgs7ba3tomsmtacb9rrs8g','82.29.165.22',1752367326,'__ci_last_regenerate|i:1752367325;'),('9m46votr75e1elnv1k0elj4k7hfe3j9u','82.29.165.22',1752139746,'__ci_last_regenerate|i:1752139745;'),('9mha9sb3teu9tn7jsc2n4khmlob0f9df','82.29.165.22',1752473349,'__ci_last_regenerate|i:1752473348;'),('9mnmhr5nidjq8uinfnno219di7jpc7t3','82.29.165.22',1752511925,'__ci_last_regenerate|i:1752511924;'),('9o0l5tfp00p2cbrd036k7bu0g6p6639u','82.29.165.22',1752223807,'__ci_last_regenerate|i:1752223806;'),('9o11fmte70fd02bvprt32fm5sq4lij6d','82.29.165.22',1752442145,'__ci_last_regenerate|i:1752442144;'),('9q9s03r3ictvpri34602ajtvbeds8kj4','82.29.165.22',1752169386,'__ci_last_regenerate|i:1752169385;'),('9qja1s1g8tisklotqda2du557bo70q5p','82.29.165.22',1752074643,'__ci_last_regenerate|i:1752074643;'),('9qt8sla448njji93on7b8ibef76h0eej','82.29.165.22',1752252245,'__ci_last_regenerate|i:1752252244;'),('9r6f26kfj7f1n9melql2tt59ihinv1t0','223.184.153.143',1752152857,'__ci_last_regenerate|i:1752152856;is_mobile|b:1;staff_user_id|s:2:\"12\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";'),('9rmpkngumcd96erajesc7621a9tlp86q','82.29.165.22',1752486605,'__ci_last_regenerate|i:1752486604;'),('9rpv5ncujeipd0q3puev4m624iqhpsk5','82.29.165.22',1752139026,'__ci_last_regenerate|i:1752139025;'),('9rq9bk0d307vpk1hjavbnotu5cvn2q0u','82.29.165.22',1752061267,'__ci_last_regenerate|i:1752061266;'),('9rqaggitn5ml7ljhuro9f4hl4jvabird','82.29.165.22',1752147124,'__ci_last_regenerate|i:1752147124;'),('9sivqmfpqoqqehd6g9t0kqo81eep51gv','82.29.165.22',1752482166,'__ci_last_regenerate|i:1752482165;'),('9uqb8cg31o8ljp91f502b4n58cnpb4o3','82.29.165.22',1752305167,'__ci_last_regenerate|i:1752305165;'),('a1p7pgrb1k2tlburk0p29qr6rqls87ok','82.29.165.22',1752341225,'__ci_last_regenerate|i:1752341224;'),('a272jk42btg9hir30g7ag00lsnendotl','82.29.165.22',1752251525,'__ci_last_regenerate|i:1752251524;'),('a2r4kiia18qcn9384s7clft7luka7ik4','82.29.165.22',1752127748,'__ci_last_regenerate|i:1752127747;'),('a34ddg3hke4h9d4jbo257eptdum1ofum','82.29.165.22',1752316387,'__ci_last_regenerate|i:1752316386;'),('a3gm2dtj4smh246b1k20uakikocfabsg','82.29.165.22',1752457506,'__ci_last_regenerate|i:1752457505;'),('a4i5dl5lr29ujra0s8r56d5vppd3cr52','82.29.165.22',1752404948,'__ci_last_regenerate|i:1752404947;'),('a5i63ors2ru112a8plj0j03og8kbun91','82.29.165.22',1752217507,'__ci_last_regenerate|i:1752217505;'),('a9ovlrihc9sja1r9urja6mv6l1hbv9kn','82.29.165.22',1752444665,'__ci_last_regenerate|i:1752444664;'),('ab43hifkmdp4hlbl9vpclil3f2fvqooi','82.29.165.22',1752110945,'__ci_last_regenerate|i:1752110944;'),('abbqsllc5ktbd9989stkqe7ji7clgste','82.29.165.22',1752108845,'__ci_last_regenerate|i:1752108845;'),('abntvrinrb773bvmi30rdvk8il90m177','82.29.165.22',1752502686,'__ci_last_regenerate|i:1752502685;'),('abq3r6sqcjgum1bif50u4rl7lpnd9lbv','82.29.165.22',1752226927,'__ci_last_regenerate|i:1752226926;'),('acefsfh0o2rs8ett99dljfe7vq55m4a5','82.29.165.22',1752193808,'__ci_last_regenerate|i:1752193807;'),('acp7ihn3opg3og9d0q0ijninltvihafk','82.29.165.22',1752243126,'__ci_last_regenerate|i:1752243125;'),('ahlbcdjddajn9p10j6a3j2c6j7p2nvsj','82.29.165.22',1752237126,'__ci_last_regenerate|i:1752237125;'),('aiatcpdfadohbnpll1phrf16i0mta3e0','152.56.140.31',1752251204,'__ci_last_regenerate|i:1752251204;is_mobile|b:1;red_url|s:58:\"https://himalay.techdotbit.in/admin/hr_profile/staff_infor\";'),('aii3spjkugi76ghaah5897btpnna54mf','82.29.165.22',1752051367,'__ci_last_regenerate|i:1752051365;'),('amer0fnkokc42r1c2nfaqfv4mjl6ttpv','82.29.165.22',1752517805,'__ci_last_regenerate|i:1752517805;'),('amr6nvts44j7s812ltsvmbbhgmml5kp9','82.29.165.22',1752134107,'__ci_last_regenerate|i:1752134106;'),('anrqbbimninjajg3qu9lvec3vurcqti9','82.29.165.22',1752180306,'__ci_last_regenerate|i:1752180305;'),('ant8umbv5cl354fkrjdbsurpd3efbl8k','82.29.165.22',1752226208,'__ci_last_regenerate|i:1752226207;'),('apsg7gj0alfe7oth9t4rtsoetul512jb','82.29.165.22',1752136565,'__ci_last_regenerate|i:1752136565;'),('asgkubcmkgj2skquisd9117snk5taj9b','82.29.165.22',1752458948,'__ci_last_regenerate|i:1752458947;'),('ast0s4c6hctqhidkeolqb20s5h4bmqfi','82.29.165.22',1752201009,'__ci_last_regenerate|i:1752201007;'),('asvk8caoite291grvoeuujrnoilnfjts','82.29.165.22',1752130267,'__ci_last_regenerate|i:1752130265;'),('atsjk0n6os9u7bdhmuhqf0rounophtsu','82.29.165.22',1752180965,'__ci_last_regenerate|i:1752180964;'),('av5ur00d2dpvm1t395dk6hr4lqtgu7hq','82.29.165.22',1752399727,'__ci_last_regenerate|i:1752399726;'),('ava4jof62q77ompfhe123kegdi7pd6jr','82.29.165.22',1752187204,'__ci_last_regenerate|i:1752187204;'),('b03mjsn3q7aqovmjtjd1rp6chmc78one','82.29.165.22',1752092585,'__ci_last_regenerate|i:1752092584;'),('b13scajnf0kt4q28ci9ui4tapv5249d4','82.29.165.22',1752151025,'__ci_last_regenerate|i:1752151024;'),('b1hoek89gj61gcctdpihi2cvp0q59c1i','82.29.165.22',1752107045,'__ci_last_regenerate|i:1752107045;'),('b1qrn9sg0gnvnvp8gsbpbf11cgerf1hl','82.29.165.22',1752431526,'__ci_last_regenerate|i:1752431525;'),('b4g4tqco91sqqq18mfa69pu79f9jni5a','82.29.165.22',1752205866,'__ci_last_regenerate|i:1752205865;'),('b5h1mmu52ingsf5d7huafkq2pc2oiose','82.29.165.22',1752340866,'__ci_last_regenerate|i:1752340865;'),('b6tscch6lq5un1v30i73mohe7qv97os6','82.29.165.22',1752423847,'__ci_last_regenerate|i:1752423846;'),('b70nt5kq26h6hpst5neu76n50dkj7bsu','82.29.165.22',1752069845,'__ci_last_regenerate|i:1752069845;'),('b91m9ujh7d9qg8fsoqn7tq7ib7oiaiku','82.29.165.22',1752251885,'__ci_last_regenerate|i:1752251885;'),('bar6uik8cbckgh1gn1g04t3vqai89bg8','82.29.165.22',1752095405,'__ci_last_regenerate|i:1752095404;'),('bc1otcvj1j1dbdgc3dl3f49935nhpa00','82.29.165.22',1752103505,'__ci_last_regenerate|i:1752103504;'),('bc9g49ognq5piq10arkbkc2fqrf4cfo3','82.29.165.22',1752502326,'__ci_last_regenerate|i:1752502325;'),('bcar21g853plaagra6f26p268k4taud6','82.29.165.22',1752263945,'__ci_last_regenerate|i:1752263944;'),('bcftuvu7crmacfrt5itsconn66ru1b0a','82.29.165.22',1752117310,'__ci_last_regenerate|i:1752117308;'),('bd8n9nccd80tltngqg265tfa0ksgh1vq','82.29.165.22',1752361025,'__ci_last_regenerate|i:1752361024;'),('bdgdcudqkc0n86uo86sm93ul37769h6b','82.29.165.22',1752244210,'__ci_last_regenerate|i:1752244208;'),('bdhire5k5ah6utpid3n5bkb4h6e0a8bp','82.29.165.22',1752328385,'__ci_last_regenerate|i:1752328384;'),('bfbvke2v2okukdguuubd9fk9id6ldi8l','82.29.165.22',1752429425,'__ci_last_regenerate|i:1752429424;'),('bh1mc4tuqmrjhgpiu371ekunud78geu2','82.29.165.22',1752452645,'__ci_last_regenerate|i:1752452644;'),('bic0cclvs9bahmm7edulfcc0acjh9m00','82.29.165.22',1752254344,'__ci_last_regenerate|i:1752254344;'),('binlh5qi3q0vmve0b6jpdjef9f8cfau1','82.29.165.22',1752289145,'__ci_last_regenerate|i:1752289145;'),('bjkqnhhaio5le6sqqqau4kspv14rpqb2','82.29.165.22',1752106325,'__ci_last_regenerate|i:1752106324;'),('bjuh1td3iev68jdm4u52lji9ckb50uaf','82.29.165.22',1752284945,'__ci_last_regenerate|i:1752284944;'),('bkn1bb9pmtv7i8atc5pqb4tbf4vbb79u','82.29.165.22',1752158046,'__ci_last_regenerate|i:1752158045;'),('bo5g9sdv11bddt8auk5f55pjjkr0n671','82.29.165.22',1752522363,'__ci_last_regenerate|i:1752522363;'),('bo9rvpu0adlkafpd1m2577khn9hct5e0','82.29.165.22',1752078187,'__ci_last_regenerate|i:1752078186;'),('boleck7henjolhi3thsohree9qrs6un6','82.29.165.22',1752127384,'__ci_last_regenerate|i:1752127384;'),('bq9nmas60soquftnbef15lnotven7igd','82.29.165.22',1752282123,'__ci_last_regenerate|i:1752282123;'),('bqoaj9dun7dq6ulrg0bvfq7oh13a16b5','82.29.165.22',1752321304,'__ci_last_regenerate|i:1752321304;'),('bqt4ls39dipd68bi5pimm0u2edahj1c9','82.29.165.22',1752066786,'__ci_last_regenerate|i:1752066785;'),('bratmrtt6lubbtrsn9kavgfk7k9o4llr','82.29.165.22',1752287407,'__ci_last_regenerate|i:1752287406;'),('bruojqbfrmfp9lfg392cvhf8tvutnk5v','82.29.165.22',1752056707,'__ci_last_regenerate|i:1752056706;'),('bsa6nh5pg18qsf42co5addh6121192c1','82.29.165.22',1752385686,'__ci_last_regenerate|i:1752385685;'),('bsg8bfd7ia9t01gt2eb0u6p8vhsm0q7n','82.29.165.22',1752283206,'__ci_last_regenerate|i:1752283205;'),('btpe2d8lufe6gbfv90or84vsf2rc89nn','82.29.165.22',1752310811,'__ci_last_regenerate|i:1752310809;'),('bu6sgcev7he9icnkt8jvd2sl4hdqeta2','82.29.165.22',1752067809,'__ci_last_regenerate|i:1752067807;'),('buo8if1lv6gltf6v0acn90u19i4pds2i','82.29.165.22',1752118748,'__ci_last_regenerate|i:1752118747;'),('bv225skdv66svh7dn765ucrh13k6aqe4','82.29.165.22',1752198845,'__ci_last_regenerate|i:1752198844;'),('bv4a5dk09lhnc8h8lbrv468c54jald0c','82.29.165.22',1752452285,'__ci_last_regenerate|i:1752452285;'),('c1iger0gsgnaamr0v1efjngej57n7ts6','82.29.165.22',1752386707,'__ci_last_regenerate|i:1752386705;'),('c1u39ltaf3tq1c26utk9n53pfqn5721t','103.95.164.179',1752133901,'__ci_last_regenerate|i:1752133901;is_mobile|b:1;red_url|s:35:\"https://himalay.techdotbit.in/admin\";message-danger|s:28:\"Invalid username or password\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"old\";}'),('c4cafubapa7cd9gug7ubps6oueujcgee','82.29.165.22',1752326286,'__ci_last_regenerate|i:1752326286;'),('c58efb17235ivk6i2fmh5m1ruiat9j2k','82.29.165.22',1752407108,'__ci_last_regenerate|i:1752407107;'),('c7nu4lg7fm222mbrqk74mder7fk063ml','82.29.165.22',1752464584,'__ci_last_regenerate|i:1752464584;'),('c7o67taihivpemgesravhu5as0maqpvp','82.29.165.22',1752232206,'__ci_last_regenerate|i:1752232205;'),('c7vjrrjk3f89nksa6c4efi6i38cc9fsc','82.29.165.22',1752097564,'__ci_last_regenerate|i:1752097564;'),('c9129lhns4gba6fdhnq6r1adlf8m6km3','82.29.165.22',1752234307,'__ci_last_regenerate|i:1752234306;'),('c97htqosjpmfncmr2u9i6t5he9es17g5','82.29.165.22',1752513006,'__ci_last_regenerate|i:1752513005;'),('cb8emfjig5p9gnph6ipbdgf6m530us7g','82.29.165.22',1752497465,'__ci_last_regenerate|i:1752497464;'),('cc1mq2uqh9mvo2bunlj8hcdqrv4id8mr','82.29.165.22',1752297125,'__ci_last_regenerate|i:1752297124;'),('cdoknfcnf5b1f9revjm20qpre3j9pp5a','82.29.165.22',1752284223,'__ci_last_regenerate|i:1752284223;'),('ce2o500psnmcase6ql0lh3jbc51vifmt','82.29.165.22',1752099306,'__ci_last_regenerate|i:1752099305;'),('ceikoav9rueo66d330bu11olpdf334k2','82.29.165.22',1752383284,'__ci_last_regenerate|i:1752383284;'),('cejb86u1se2a49ccau264rjfgs9au6pf','103.95.164.179',1752133584,'__ci_last_regenerate|i:1752133584;is_mobile|b:1;red_url|s:35:\"https://himalay.techdotbit.in/admin\";'),('ceq4fphta8b20lgr3ptf242bd77sffjh','82.29.165.22',1752483547,'__ci_last_regenerate|i:1752483546;'),('cf9k0jpkp0u8cgd9afb0ec5c0p43ts0a','82.29.165.22',1752462125,'__ci_last_regenerate|i:1752462125;'),('cg1lkc2rsdva4950itrgq5080a23gb9v','152.58.131.47',1752055055,'__ci_last_regenerate|i:1752055055;red_url|s:35:\"https://himalay.techdotbit.in/admin\";'),('cg9f4ipldnndq32io6li85b5b7j7l6b5','82.29.165.22',1752167226,'__ci_last_regenerate|i:1752167225;'),('cghqr465jcj94l3u282ptnir8s6rnamt','82.29.165.22',1752393366,'__ci_last_regenerate|i:1752393365;'),('cheptvc1ini48d3bu9ti1qqlpeq3t5cg','82.29.165.22',1752264306,'__ci_last_regenerate|i:1752264305;'),('cim2k3c6lceo2sf2641cev6lth3oaok8','82.29.165.22',1752357785,'__ci_last_regenerate|i:1752357785;'),('cjkvtfr81h78h6v49j182ecftqml7sg2','82.29.165.22',1752195246,'__ci_last_regenerate|i:1752195245;'),('ckpq1fqq4tvn7sdd0vqr2ccugpc11fqq','82.29.165.22',1752518165,'__ci_last_regenerate|i:1752518164;'),('cl14n36pnhqluudbb8ao82n6ou9fornm','82.29.165.22',1752056346,'__ci_last_regenerate|i:1752056344;'),('cl8p6eq8avk727lqu6ub3q620enht5a2','82.29.165.22',1752456424,'__ci_last_regenerate|i:1752456423;'),('cnansarlh6m8j8bu350ab2e9bbdp0g0b','82.29.165.22',1752197046,'__ci_last_regenerate|i:1752197045;'),('cnc6672r899n5slndr3qh18uq7dh40nc','82.29.165.22',1752244566,'__ci_last_regenerate|i:1752244565;'),('co1ssp07jbsr0cbrmc7vdcsdhvrp3v1m','82.29.165.22',1752520625,'__ci_last_regenerate|i:1752520624;'),('cp0qs62rordvvsqfbv7c6q8l058g9ig0','82.29.165.22',1752333185,'__ci_last_regenerate|i:1752333184;'),('cp53j87qo9cpbq1kg7d65gij41a4o843','82.29.165.22',1752082985,'__ci_last_regenerate|i:1752082984;'),('cp8g9v97vqnot5h6070lrgom1s7im39b','82.29.165.22',1752078846,'__ci_last_regenerate|i:1752078845;'),('cqc671cf7umlk83r0jetac9nt7olqqop','82.29.165.22',1752100025,'__ci_last_regenerate|i:1752100024;'),('cqfpi02ehaddfhnmldlqdm20ii9m08v6','82.29.165.22',1752267483,'__ci_last_regenerate|i:1752267483;'),('cqrsoq62ascr3vk1blcb42k3uad6aokc','82.29.165.22',1752142207,'__ci_last_regenerate|i:1752142206;'),('cr29ttledta49dapolkljbr2vgl0s0b4','82.29.165.22',1752438245,'__ci_last_regenerate|i:1752438244;'),('crs87bos6971u1eu6dbctl794218jpgd','82.29.165.22',1752491586,'__ci_last_regenerate|i:1752491586;'),('ctvohl7umupk7n0uh620hrth7nrg0203','82.29.165.22',1752347165,'__ci_last_regenerate|i:1752347164;'),('cu97i1dfc4vufqni32v16u5ct0rdtt01','82.29.165.22',1752360306,'__ci_last_regenerate|i:1752360305;'),('cv1f0ulc4211klhm8826j5alu4huidr4','82.29.165.22',1752353825,'__ci_last_regenerate|i:1752353824;'),('cvom07t5835df7m89ghnrlhhbutv7855','82.29.165.22',1752272824,'__ci_last_regenerate|i:1752272823;'),('d0ro4kovtn0misaifit62c9tjhbvk0tv','82.29.165.22',1752492966,'__ci_last_regenerate|i:1752492965;'),('d10c97m5u7uavki3ki76ck5fpkhsnkua','82.29.165.22',1752089465,'__ci_last_regenerate|i:1752089465;'),('d1ovb2potav5nvsqp4l7lqsq9ee8n2up','82.29.165.22',1752120125,'__ci_last_regenerate|i:1752120124;'),('d2d411pai8uo8lf2662ei9msq3pneouj','82.29.165.22',1752151686,'__ci_last_regenerate|i:1752151685;'),('d2gah3hs33ojfs3v58euq7e8f8is33a7','82.29.165.22',1752370747,'__ci_last_regenerate|i:1752370746;'),('d2uh6t4q2javid384fki3b3ru24puc94','110.172.155.237',1752053945,'__ci_last_regenerate|i:1752053945;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";'),('d2vbcns3rs8ovj1922tiqutkja4n3go1','82.29.165.22',1752503046,'__ci_last_regenerate|i:1752503045;'),('d3kjaen0jh2fv6m3kbk8dfj529n89pue','82.29.165.22',1752306246,'__ci_last_regenerate|i:1752306245;'),('d3tkek515luaerfdag6akcnhdpu79m62','82.29.165.22',1752261425,'__ci_last_regenerate|i:1752261424;'),('d40si6jkeqnpm9bsnql5cc7s302at8rd','82.29.165.22',1752485284,'__ci_last_regenerate|i:1752485284;'),('d53o12mfp94tegp971rhjmk9r5o5ovpu','82.29.165.22',1752124326,'__ci_last_regenerate|i:1752124325;'),('d55u762i74rd46legvardbh42g9bl7lb','82.29.165.22',1752462485,'__ci_last_regenerate|i:1752462484;'),('d5n97ai6umae0se66v1hgsmbcbeptlra','82.29.165.22',1752406748,'__ci_last_regenerate|i:1752406746;'),('d6aqgjq9vpe2bbvrbqoekv8facso8ehl','82.29.165.22',1752297786,'__ci_last_regenerate|i:1752297785;'),('d8ju8ttl997r7j3b8u1ds4trsmp90sc5','82.29.165.22',1752509166,'__ci_last_regenerate|i:1752509165;'),('d9reh9ujndl9kfrjhtu1c1i8oiuvg6g5','82.29.165.22',1752172565,'__ci_last_regenerate|i:1752172564;'),('daa1sb5k9pb5u6557h0vtkcfepvbvsgd','82.29.165.22',1752436505,'__ci_last_regenerate|i:1752436505;'),('daqnbsbr9lh0dgimmp8782ovo5i4hr2j','82.29.165.22',1752371106,'__ci_last_regenerate|i:1752371105;'),('db033fr33tqi6luu5s65qvs3i9cngv9m','82.29.165.22',1752082626,'__ci_last_regenerate|i:1752082625;'),('dckjihcarrdi9e02ram4pi5325h338j7','82.29.165.22',1752489127,'__ci_last_regenerate|i:1752489126;'),('de6gdonq3ggrtbgkdv4jrq4vi835v5hg','82.29.165.22',1752434345,'__ci_last_regenerate|i:1752434344;'),('dfeap3t870v3dme6oimbjegm4v4rohsk','82.29.165.22',1752488407,'__ci_last_regenerate|i:1752488406;'),('dgak7b12km83rlqp4e40774qcr1eiotu','82.29.165.22',1752283924,'__ci_last_regenerate|i:1752283924;'),('dgdguegt8k7nkdajkvdng4ts5mu0auuq','82.29.165.22',1752205149,'__ci_last_regenerate|i:1752205147;'),('dgg6g03neoinodam7cnssjv2j3f9ch6i','82.29.165.22',1752164048,'__ci_last_regenerate|i:1752164047;'),('dgnalj5m0hch0nskvm9slav0u437m71m','82.29.165.22',1752215046,'__ci_last_regenerate|i:1752215045;'),('di4johue14rhuq19ms191g55rtqvki6g','82.29.165.22',1752096845,'__ci_last_regenerate|i:1752096844;'),('dimveh1q557ef93puakui73p89ujv8hg','82.29.165.22',1752049567,'__ci_last_regenerate|i:1752049566;'),('dj4i748ksdtocc7j3mahuv78fu48vg33','82.29.165.22',1752294006,'__ci_last_regenerate|i:1752294005;'),('djmvophq1eihca3bs4fhjosog55pf7ku','82.29.165.22',1752498186,'__ci_last_regenerate|i:1752498185;'),('djp7q5k858m3rs3mem3ge36rstt7pktf','82.29.165.22',1752428707,'__ci_last_regenerate|i:1752428705;'),('djt1tvqhrffavle23rp9pa9v4anmor7j','82.29.165.22',1752115148,'__ci_last_regenerate|i:1752115147;'),('djvgvud0jcmb6kb1t3rebpso3i23covd','82.29.165.22',1752190685,'__ci_last_regenerate|i:1752190684;'),('dl39si1off7kb3lvrqitr87d43g1k0ks','82.29.165.22',1752423485,'__ci_last_regenerate|i:1752423485;'),('dlgthfck88hjovt23dkmnml8k1ec46lr','82.29.165.22',1752136864,'__ci_last_regenerate|i:1752136864;'),('dnrodf64a451rpcnrue4o31kmf905mal','82.29.165.22',1752461045,'__ci_last_regenerate|i:1752461045;'),('doe4j1s0ih085eh2btgss9p3j3g5l2cq','82.29.165.22',1752121566,'__ci_last_regenerate|i:1752121565;'),('donl2eibsq2qatg6h29nggicc88imq3r','82.29.165.22',1752476465,'__ci_last_regenerate|i:1752476465;'),('dp8nm8sc6dgbmo2ef1vv427oqme9ifmk','82.29.165.22',1752125766,'__ci_last_regenerate|i:1752125765;'),('dqcp9t7s6gmv2acrfmck8kh3s0ir92v1','82.29.165.22',1752184809,'__ci_last_regenerate|i:1752184807;'),('dr797ub4dbqkt1f1417ju9ocg6aet845','82.29.165.22',1752447725,'__ci_last_regenerate|i:1752447724;'),('dri1s7difbm7vo54dtvn30bn141khm0o','82.29.165.22',1752105633,'__ci_last_regenerate|i:1752105627;'),('dt0ko1fr9t6iq5n10a9kfifvblmtv5bf','82.29.165.22',1752351725,'__ci_last_regenerate|i:1752351724;'),('e0ipgta7a3k28ukmt8k7r5i0qqhqt5ut','82.29.165.22',1752497826,'__ci_last_regenerate|i:1752497825;'),('e1jpg5ni3ikq9vbgtoqr8ia907fong0m','82.29.165.22',1752229810,'__ci_last_regenerate|i:1752229808;'),('e1lel541u2o6ugmnnp1sv4gdl1scg1nj','82.29.165.22',1752499564,'__ci_last_regenerate|i:1752499564;'),('e32uvja7aroiqvdvljjsohd9ruf72pl4','82.29.165.22',1752310506,'__ci_last_regenerate|i:1752310505;'),('e48uupkccsqe4db01talicbo6tk2r58r','82.29.165.22',1752324126,'__ci_last_regenerate|i:1752324125;'),('e5g5qko19q2g9g94k2rto76tbjivjnes','82.29.165.22',1752222006,'__ci_last_regenerate|i:1752222005;'),('e6alj4nu9302c514pdlhn7sauqih99l6','152.58.131.84',1752058156,'__ci_last_regenerate|i:1752058156;is_mobile|b:1;staff_user_id|s:1:\"2\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";'),('e6oqk550ug6nk5uom0lbf5k0kstfd5oh','82.29.165.22',1752449765,'__ci_last_regenerate|i:1752449764;'),('e7qcdfr4icntkl7uqp9gp68djq14h996','82.29.165.22',1752421386,'__ci_last_regenerate|i:1752421385;'),('e81qn4sjrusq57a57dh28qi181207op6','82.29.165.22',1752450125,'__ci_last_regenerate|i:1752450124;'),('e846eq1eqves1uvfku8afpsq3fic3vmb','82.29.165.22',1752166145,'__ci_last_regenerate|i:1752166145;'),('e923kvcvqrg614qmvot1b1hlgm857mhb','82.29.165.22',1752067447,'__ci_last_regenerate|i:1752067445;'),('ebpfq19touml4hgh07j86jdktukjq94f','82.29.165.22',1752255785,'__ci_last_regenerate|i:1752255784;'),('ebrkrehhc9qqdjl5s2ra6t2pj1d93gii','82.29.165.22',1752325213,'__ci_last_regenerate|i:1752325210;'),('ec0nl7g6hv6i9e22vkk3ef2m3cthm81u','82.29.165.22',1752417548,'__ci_last_regenerate|i:1752417547;'),('ec66eq0317ju176rlrptogqk9cj7migs','82.29.165.22',1752196685,'__ci_last_regenerate|i:1752196684;'),('ec68mkp12l1ke7tksb7b0g0ao8l49d8s','82.29.165.22',1752296106,'__ci_last_regenerate|i:1752296105;'),('ecnub5sn8semn0fbv8fi3jhda8atp3r0','82.29.165.22',1752179645,'__ci_last_regenerate|i:1752179644;'),('ecs6dipjkvku7oui7q5pn62l1cnos5m3','82.29.165.22',1752193504,'__ci_last_regenerate|i:1752193504;'),('ed1vsif2k5k0fh4a5rs1leb1i6hce5a9','82.29.165.22',1752167946,'__ci_last_regenerate|i:1752167945;'),('eec5mrsbq7q35kc88ejc7coliifu7dkk','82.29.165.22',1752406026,'__ci_last_regenerate|i:1752406025;'),('eepqjd1derdu2stlua9vk72ki983sl9e','82.29.165.22',1752356706,'__ci_last_regenerate|i:1752356705;'),('eero6gohs3eiqo0jnkcl9slakeu9g9eh','82.29.165.22',1752152766,'__ci_last_regenerate|i:1752152765;'),('effhittd79k95oi0ooglnt0eavso65gl','82.29.165.22',1752305886,'__ci_last_regenerate|i:1752305885;'),('efs37smd627j1rokf672ctaga7fi9vg9','82.29.165.22',1752428045,'__ci_last_regenerate|i:1752428044;'),('eg4i1nm1i722lj3f6m5jhf4ugajpeb9a','82.29.165.22',1752148925,'__ci_last_regenerate|i:1752148924;'),('egp71tgn1559p5dt7hkcn5kfkq936lq6','82.29.165.22',1752218946,'__ci_last_regenerate|i:1752218945;'),('egu7f36510l9k0sv3kqufjrgh4mlc3fq','82.29.165.22',1752244864,'__ci_last_regenerate|i:1752244864;'),('ehlv37q14mcosr6jmaav0dos838dtcsf','82.29.165.22',1752321964,'__ci_last_regenerate|i:1752321964;'),('ejf5q08cvrlvpan1kju98vc0fj1eu2ui','82.29.165.22',1752463925,'__ci_last_regenerate|i:1752463925;'),('ekcps24ggos2uv1vuot1f9d26lpv2rbj','82.29.165.22',1752472686,'__ci_last_regenerate|i:1752472685;'),('ekf6kecetth5t2s10bqc9hfuq2fkvvga','82.29.165.22',1752061625,'__ci_last_regenerate|i:1752061624;'),('emksga2df1odjq3odbodpodhu2p1nq2r','82.29.165.22',1752413409,'__ci_last_regenerate|i:1752413407;'),('emuh8crm9d4lll9di7aaaari7k6sphfp','82.29.165.22',1752125410,'__ci_last_regenerate|i:1752125408;'),('en1km0su7ngggn6o9115de5v9ut9o855','82.29.165.22',1752425586,'__ci_last_regenerate|i:1752425585;'),('en4ckabj2f2o7bvu9breifr8lb95o2i7','110.172.155.237',1752053634,'__ci_last_regenerate|i:1752053634;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;'),('eoc5uh2n5hme77srd9ltfv5ilkqtievm','82.29.165.22',1752154209,'__ci_last_regenerate|i:1752154207;'),('eorld6hiatg0a6brpka4qoc9o65rikgj','82.29.165.22',1752473707,'__ci_last_regenerate|i:1752473706;'),('ep7p6n4kt87tpoamlb881utnns76squv','82.29.165.22',1752406385,'__ci_last_regenerate|i:1752406384;'),('eqoge96udqq88flm09rlk0faj925shqk','82.29.165.22',1752082266,'__ci_last_regenerate|i:1752082265;'),('et84ndljur75i723lhos9u3kqvsgmo12','82.29.165.22',1752206949,'__ci_last_regenerate|i:1752206947;'),('etj1sbvrbra8a27ne6sqjb3u5bn0s6jo','82.29.165.22',1752163687,'__ci_last_regenerate|i:1752163686;'),('eu1iip6qtk0icka6nep4ksa5o4bvk8hf','82.29.165.22',1752521705,'__ci_last_regenerate|i:1752521704;'),('euatg467iaujvvtrfb8kjrcsbr0u7bal','82.29.165.22',1752420366,'__ci_last_regenerate|i:1752420365;'),('euci2echfv1gspm02oo62vtfeqd2k6jm','82.29.165.22',1752513666,'__ci_last_regenerate|i:1752513665;'),('evusdu5r4u6cpamm0hei0t342v5s4lo2','82.29.165.22',1752064026,'__ci_last_regenerate|i:1752064025;'),('f0m39t2qs2hf6jku99g8e7nrrldaq902','82.29.165.22',1752478209,'__ci_last_regenerate|i:1752478207;'),('f3o1ghdesk950ptvfkjsddus0jt29olh','82.29.165.22',1752522725,'__ci_last_regenerate|i:1752522724;'),('f4p8ldh1cou2e0k76u2lg17kkhpf8b7h','82.29.165.22',1752155944,'__ci_last_regenerate|i:1752155944;'),('f52jutmc1t380p0hotn3uqoa3uhgsi33','82.29.165.22',1752286685,'__ci_last_regenerate|i:1752286684;'),('f57gt199tntrspgqh31mmpbh8ee4sqlk','82.29.165.22',1752208624,'__ci_last_regenerate|i:1752208624;'),('f5tn3e8ga47kff5t8495h4od3riq120i','82.29.165.22',1752091565,'__ci_last_regenerate|i:1752091564;'),('f7kosr9qiaslq5btu5hih2t7n1kfocrr','82.29.165.22',1752443584,'__ci_last_regenerate|i:1752443584;'),('f97li2cngbn7cvnbkqufd3v9n21ln2od','82.29.165.22',1752058746,'__ci_last_regenerate|i:1752058745;'),('fad4l60dp6is9qjk7j1al5h7p4oqvmuh','82.29.165.22',1752500646,'__ci_last_regenerate|i:1752500645;'),('fae2u9loeordv6drst66s1ql3khs51go','82.29.165.22',1752068464,'__ci_last_regenerate|i:1752068464;'),('fbmhi1bjair693qqsntrl22e19h61d9i','82.29.165.22',1752158708,'__ci_last_regenerate|i:1752158706;'),('fccb2e84q5llc1nt48fgnqcmle5jtnn3','82.29.165.22',1752523084,'__ci_last_regenerate|i:1752523083;'),('fcdh63vhaocaobn6no4jqpl2iv1kbk8q','82.29.165.22',1752433266,'__ci_last_regenerate|i:1752433265;'),('fcr0c32joei28b6vl2psd89lt2efe3h3','82.29.165.22',1752251166,'__ci_last_regenerate|i:1752251165;'),('fd8r9p9v4l4l20thnu3816dhh1f2678q','82.29.165.22',1752415505,'__ci_last_regenerate|i:1752415504;'),('fdb41fectgagl167ctk08f61omt0icjd','82.29.165.22',1752304809,'__ci_last_regenerate|i:1752304807;'),('fddrjekqlvb199bf9f1vim3g2u9470ca','82.29.165.22',1752211808,'__ci_last_regenerate|i:1752211807;'),('fdircgn9luh97esgvgvk0lkco45j55mh','82.29.165.22',1752395887,'__ci_last_regenerate|i:1752395886;'),('fes2mvjm5lsegdet4qjs6kfu60d3l4vh','82.29.165.22',1752329106,'__ci_last_regenerate|i:1752329105;'),('fgfqku9kbvt4ubk1vlgdhn7aia29h4ja','82.29.165.22',1752485949,'__ci_last_regenerate|i:1752485948;'),('fguckod915ic3jsm67vemgp5h6i52h4b','82.29.165.22',1752096125,'__ci_last_regenerate|i:1752096124;'),('fhdvev9jqcqissq59ugtcq9qa61cugal','82.29.165.22',1752378425,'__ci_last_regenerate|i:1752378424;'),('fhlvl7egflvvkgn60uppuub5lfdcit88','82.29.165.22',1752249066,'__ci_last_regenerate|i:1752249065;'),('fhvftq1gv8ggne35j7aflqv3bef0u7t4','82.29.165.22',1752292566,'__ci_last_regenerate|i:1752292565;'),('fj036tpes095evile664filupbln5f65','82.29.165.22',1752519245,'__ci_last_regenerate|i:1752519244;'),('fj7ifc06e6bobvqc7fjcfasnkjdk3k8j','82.29.165.22',1752373808,'__ci_last_regenerate|i:1752373806;'),('fjku61lnl15ueoetbc54ltc6lepn80m1','82.29.165.22',1752272165,'__ci_last_regenerate|i:1752272164;'),('fjtacapsu20dq9i2n3mabg2mj8d2lv0t','82.29.165.22',1752506646,'__ci_last_regenerate|i:1752506645;'),('fk489osb76umm2s89bm13d8lr1d4nclr','117.98.28.3',1752413196,'__ci_last_regenerate|i:1752413195;is_mobile|b:1;'),('fkava872tm49eulq65227emvuqoam3ju','82.29.165.22',1752205507,'__ci_last_regenerate|i:1752205506;'),('fkcu70hlpm4kv4s8fojehu150thmi052','82.29.165.22',1752518525,'__ci_last_regenerate|i:1752518524;'),('flcff5613deqjf0vdpqlloh8rso5bevd','82.29.165.22',1752223086,'__ci_last_regenerate|i:1752223085;'),('fmc7ounsem79h7es8ajhfed24ia3v87a','49.36.189.194',1752065739,'__ci_last_regenerate|i:1752065739;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";'),('fmuvgrchagsp416oh7gbm8bap3c36ica','82.29.165.22',1752425224,'__ci_last_regenerate|i:1752425224;'),('fn0fm6r4vf07p9qdafru1bf0epgagj96','82.29.165.22',1752415865,'__ci_last_regenerate|i:1752415865;'),('fndmjrqhfeut1h457pgbnirmj7uda70t','82.29.165.22',1752410586,'__ci_last_regenerate|i:1752410585;'),('fnpt9c4tlsk54esqb1qcpcnq2p9anm8m','82.29.165.22',1752149286,'__ci_last_regenerate|i:1752149285;'),('fnuhivcs25r4obn3e2j9k00knkf286ja','82.29.165.22',1752068826,'__ci_last_regenerate|i:1752068825;'),('fsmhtdfdl7it01loslvkidlh2ubebp49','82.29.165.22',1752190325,'__ci_last_regenerate|i:1752190324;'),('fsn7a7lfbg6lkid5qjq2csoddro18u8b','82.29.165.22',1752123611,'__ci_last_regenerate|i:1752123609;'),('fu5nnih6tgm3ip4bcqqni3s9eqkeg1jf','82.29.165.22',1752497166,'__ci_last_regenerate|i:1752497165;'),('fud59qvv0ddtlq965h2luhmb4ti7ml9p','82.29.165.22',1752430865,'__ci_last_regenerate|i:1752430864;'),('fvbdouh1sdsmjvsttlr4i2e3m7822bjs','82.29.165.22',1752382986,'__ci_last_regenerate|i:1752382984;'),('fvfg04h802vh3fjkd2r7dptfvk7kcs1s','82.29.165.22',1752188946,'__ci_last_regenerate|i:1752188946;'),('fvkg6ifqbtrdej1v6qo6ic88mue53ddd','82.29.165.22',1752402185,'__ci_last_regenerate|i:1752402185;'),('g0aqnsub8gip8puortdn2u31g74v2rep','82.29.165.22',1752129186,'__ci_last_regenerate|i:1752129185;'),('g0ei8v72820hvv9sp72e1c8saqal5dvt','82.29.165.22',1752186185,'__ci_last_regenerate|i:1752186184;'),('g0kh1puv85ckpmfcp22vl19utrql0bme','82.29.165.22',1752334210,'__ci_last_regenerate|i:1752334208;'),('g15tigsk5d8c8jk6f5b2mj7a40ej1caf','82.29.165.22',1752120845,'__ci_last_regenerate|i:1752120844;'),('g1dra9ejnp629lqehdt4g4l6h9vf2qai','82.29.165.22',1752154567,'__ci_last_regenerate|i:1752154565;'),('g2m2574dnl5bc9eiee55ounc40os4ntq','82.29.165.22',1752445024,'__ci_last_regenerate|i:1752445024;'),('g2q9o3i792agbe89cugjivdubptekae5','152.58.131.47',1752056095,'__ci_last_regenerate|i:1752056095;is_mobile|b:1;staff_user_id|s:1:\"2\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";'),('g302u9vm83ciop33o5d84sfq5vneupt5','82.29.165.22',1752267845,'__ci_last_regenerate|i:1752267844;'),('g3u762gjkedfddtb4hqu2mj8krmo6qpp','82.29.165.22',1752370085,'__ci_last_regenerate|i:1752370084;'),('g4anjla1918ji28aj358duglgu5k8159','82.29.165.22',1752481086,'__ci_last_regenerate|i:1752481085;'),('g4q98gfonoah6753slqmtlrfof2vm7q7','82.29.165.22',1752516845,'__ci_last_regenerate|i:1752516844;'),('g5cvpo6rgmrb1f50ll88r0dtp8t80odr','82.29.165.22',1752256811,'__ci_last_regenerate|i:1752256810;'),('g5o5hpdc3ujsjg95g04s6s38esf2q064','82.29.165.22',1752304446,'__ci_last_regenerate|i:1752304445;'),('g86gqgq2prnn8tb7bepmc66rq20c17gh','82.29.165.22',1752179285,'__ci_last_regenerate|i:1752179284;'),('g8pbh40k3cmjh6cfjdlolft319vvghqh','82.29.165.22',1752408124,'__ci_last_regenerate|i:1752408124;'),('garv3i1t3btrb1cfmuio5df5575e2iij','82.29.165.22',1752071165,'__ci_last_regenerate|i:1752071164;'),('gckk9kq8b5f8aa1tee95n3og651g5h3q','82.29.165.22',1752438544,'__ci_last_regenerate|i:1752438543;'),('ge06m6dno6b3d6147b0j7okf7rbmnv88','82.29.165.22',1752341885,'__ci_last_regenerate|i:1752341884;'),('gfam2n1dirs19kvk283ocdu4hcdmh64a','82.29.165.22',1752342606,'__ci_last_regenerate|i:1752342606;'),('ggoe042lj8k5alqbu1fct1kt66s7se3b','82.29.165.22',1752245945,'__ci_last_regenerate|i:1752245944;'),('gh2sf5sko3o9cd5dqe1sdimafnafu4b5','82.29.165.22',1752416945,'__ci_last_regenerate|i:1752416945;'),('ghe8pag5lljg4nfagbos52bbr3c6jqja','82.29.165.22',1752420727,'__ci_last_regenerate|i:1752420726;'),('gi956mtqr2ajjn7pf4ch9i3vqeq360mp','82.29.165.22',1752387787,'__ci_last_regenerate|i:1752387786;'),('gi9frag3rc1i7ohl5jcsb15ijc361e99','82.29.165.22',1752206586,'__ci_last_regenerate|i:1752206585;'),('gictt6mc4hp2pk18pd7a7ko3pml63r88','82.29.165.22',1752101106,'__ci_last_regenerate|i:1752101105;'),('gj80mcc19lqulospir9qo42em6ab1tpe','82.29.165.22',1752305527,'__ci_last_regenerate|i:1752305525;'),('gl2pk8mtjvfde26oemus6ok0boha4kh8','82.29.165.22',1752315307,'__ci_last_regenerate|i:1752315306;'),('gl894ng90pa1bi2qmrv3ssve55p0er23','82.29.165.22',1752465609,'__ci_last_regenerate|i:1752465608;'),('glejq0nn1ehkb5vgs5e1tendjrumebni','82.29.165.22',1752145387,'__ci_last_regenerate|i:1752145386;'),('gmtsp2hon9sn9sg5sj1su8v93j7ivvfc','82.29.165.22',1752065765,'__ci_last_regenerate|i:1752065764;'),('gnrd3u2tnierd7udj0hfgvlj4t63bjai','82.29.165.22',1752261786,'__ci_last_regenerate|i:1752261785;'),('gpfcng6bobjgl4bb22i5jq721bbksmmp','82.29.165.22',1752096485,'__ci_last_regenerate|i:1752096485;'),('gpqiao7hs4k4golc37g870rqqr7me3ht','82.29.165.22',1752350345,'__ci_last_regenerate|i:1752350344;'),('gqdl8gukqlo82ohm6b10a3oon3om0jnt','82.29.165.22',1752281464,'__ci_last_regenerate|i:1752281464;'),('gqpa3kn3lro3dak8cbcl0kknjeakjgis','82.29.165.22',1752357425,'__ci_last_regenerate|i:1752357424;'),('gqtllpkfu75hd049fnk8bt0optk27scn','82.29.165.22',1752046387,'__ci_last_regenerate|i:1752046387;'),('gr2a2t3tjei7l4fsblimn9sf899v0gfk','82.29.165.22',1752156667,'__ci_last_regenerate|i:1752156666;'),('grgm842ea3qatnj9hqbee7g53buh5adr','82.29.165.22',1752320286,'__ci_last_regenerate|i:1752320285;'),('grkobgrm7giahppakp7cuu9lu5vrq9r7','82.29.165.22',1752334565,'__ci_last_regenerate|i:1752334565;'),('gst6clt7cjkirt309ok8a82lejdb4cf2','82.29.165.22',1752094025,'__ci_last_regenerate|i:1752094025;'),('gu46937en4snnlb72sidtmpti7r8247v','82.29.165.22',1752301326,'__ci_last_regenerate|i:1752301325;'),('gva7mcemj2b3ej6lj1dc8npfb7j92lev','82.29.165.22',1752426666,'__ci_last_regenerate|i:1752426665;'),('gvqlvnidkt629ol2uajl6kcj3eu8frh2','82.29.165.22',1752381184,'__ci_last_regenerate|i:1752381184;'),('h038635skb9bm2ebnfl3v71vbegu11bc','82.29.165.22',1752062647,'__ci_last_regenerate|i:1752062646;'),('h120hgbmepdpb2852725u69r3923mop3','82.29.165.22',1752425946,'__ci_last_regenerate|i:1752425945;'),('h1drtpoqltbuf6c7avuvqccl9dme6sor','82.29.165.22',1752508446,'__ci_last_regenerate|i:1752508445;'),('h23cb797hdf0mjr6l0qhool4bcitm4ot','82.29.165.22',1752402546,'__ci_last_regenerate|i:1752402545;'),('h3obt3u0a43rlgq49accgir12hslce81','82.29.165.22',1752323046,'__ci_last_regenerate|i:1752323045;'),('h4ggjtu30172kglphsplk9jfl6kigaf3','82.29.165.22',1752411966,'__ci_last_regenerate|i:1752411965;'),('h4jpcptjsrepikquont572uu7mbob728','82.29.165.22',1752250086,'__ci_last_regenerate|i:1752250085;'),('h4m1ku6kg9kae5jrt95oeevp9ibg69ls','82.29.165.22',1752144009,'__ci_last_regenerate|i:1752144007;'),('h69pnjnvep2fe1o4u89k35r45po3paeb','82.29.165.22',1752204846,'__ci_last_regenerate|i:1752204845;'),('h6fjk86umd9gl33b02nirionsqjas5r6','82.29.165.22',1752308707,'__ci_last_regenerate|i:1752308706;'),('h7e6ri9jj4bu9725eo3lmpi53nmevqqj','82.29.165.22',1752049208,'__ci_last_regenerate|i:1752049206;'),('h7ud4hlk7ajt79og6k9taina6u5fvpbl','82.29.165.22',1752173646,'__ci_last_regenerate|i:1752173645;'),('h8rqiack3i50dotjqhcvtdvljp40bmcj','82.29.165.22',1752158346,'__ci_last_regenerate|i:1752158345;'),('h9dtitftpls9r8vmgqfog1r47o6931s2','82.29.165.22',1752058387,'__ci_last_regenerate|i:1752058386;'),('h9lc0ar0a0hjf8bqqg05lnt2kp7uebnu','82.29.165.22',1752282484,'__ci_last_regenerate|i:1752282484;'),('hamisndh6bv6t9mg6kml78vfooalrsp9','82.29.165.22',1752317109,'__ci_last_regenerate|i:1752317107;'),('hb06n942ml4d3uafb1bft2saianrvdo8','82.29.165.22',1752259325,'__ci_last_regenerate|i:1752259324;'),('hccmlrv95vns4jpekuo8rfnbmnqodra2','82.29.165.22',1752230167,'__ci_last_regenerate|i:1752230166;'),('heaomu372e50m59ecj85bo2p5renmle5','82.29.165.22',1752394445,'__ci_last_regenerate|i:1752394444;'),('hfr2hfpfd5g8qsv8irl9r1vutsk5le42','82.29.165.22',1752313626,'__ci_last_regenerate|i:1752313625;'),('hg5d203ohd67hjcctflrcsh0hma1ibug','82.29.165.22',1752184085,'__ci_last_regenerate|i:1752184084;'),('hh4e2pqve3ffukh2j0kg7s51skq37o0j','82.29.165.22',1752409504,'__ci_last_regenerate|i:1752409504;'),('hhc19v1k5rtgg756j1npgkh2llfhsmgb','82.29.165.22',1752168307,'__ci_last_regenerate|i:1752168305;'),('hhepja3q8bs96lltus8054q6f4u96p23','82.29.165.22',1752346085,'__ci_last_regenerate|i:1752346084;'),('hhm6638e7i1vilvcm4fgfoonmdu0teur','82.29.165.22',1752482527,'__ci_last_regenerate|i:1752482526;'),('hho4qc7uv7gtlns8raojq9j3fe89fqvl','82.29.165.22',1752171486,'__ci_last_regenerate|i:1752171485;'),('hi03os2mkhps0unn6koffdr2rbnrgnrb','82.29.165.22',1752047406,'__ci_last_regenerate|i:1752047406;'),('hidvi6gqr3sg64mq9bgu2ecrnfbu9cm6','42.105.212.56',1752051265,'__ci_last_regenerate|i:1752051090;is_mobile|b:1;staff_user_id|s:1:\"3\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";'),('hieaq2tqpjsn5k4tv16ea5o7t6tp53na','82.29.165.22',1752279723,'__ci_last_regenerate|i:1752279723;'),('hiqnfskk7uljt7h7hbfb0f0lrli4g5a1','82.29.165.22',1752102123,'__ci_last_regenerate|i:1752102123;'),('hjiklopu2djhqujjka17me45q72cf4ph','49.36.189.194',1752151551,'__ci_last_regenerate|i:1752151547;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";'),('hk4ja7lmtjmtt7q9nh2n0cf4kgqrup8t','82.29.165.22',1752129908,'__ci_last_regenerate|i:1752129907;'),('hkjhruj3gr1bf5ss6q5vp1c88dhjobne','82.29.165.22',1752306607,'__ci_last_regenerate|i:1752306606;'),('hkkpv8o5msgupdmv5uv1d87cvrfhlq2a','117.98.44.15',1752469447,'__ci_last_regenerate|i:1752469446;is_mobile|b:1;'),('hkvdc7941es7bgqli4lglvb8khgpgkfi','82.29.165.22',1752236765,'__ci_last_regenerate|i:1752236765;'),('hldm9omi9crrg6cht053791fq55ngpdp','82.29.165.22',1752133445,'__ci_last_regenerate|i:1752133444;'),('hlocbnft0ruqi0htmel4r5vbrpuf0n73','82.29.165.22',1752443225,'__ci_last_regenerate|i:1752443224;'),('hlt0vq95kqnohi64f9ra3ne33k5iasad','82.29.165.22',1752463565,'__ci_last_regenerate|i:1752463564;'),('hnuofoir4kqat6vharhma8egde3mdqjd','82.29.165.22',1752467766,'__ci_last_regenerate|i:1752467765;'),('ho4h37e1agb5km92ig1ev9l90c8m87tp','82.29.165.22',1752220326,'__ci_last_regenerate|i:1752220325;'),('hpnbapnm57b20bd8susn6631sh3un9bc','82.29.165.22',1752109209,'__ci_last_regenerate|i:1752109207;'),('hprtp298qcjghub7lmlrd5miq7rvd17n','82.29.165.22',1752511265,'__ci_last_regenerate|i:1752511264;'),('hqsesr23p1a3gau9dv7he5gvllpupspa','82.29.165.22',1752057066,'__ci_last_regenerate|i:1752057065;'),('hqtlq52ecplsi3ji58kvb408ha3mn4li','82.29.165.22',1752146108,'__ci_last_regenerate|i:1752146107;'),('hu491j4kifkran87rmnku0746b56hah7','82.29.165.22',1752067084,'__ci_last_regenerate|i:1752067084;'),('hvt63jeqg03n96jffbukio3tcftcgoii','82.29.165.22',1752070506,'__ci_last_regenerate|i:1752070505;'),('i013d1phjktfd0eghcngp6cuoit9f26p','82.29.165.22',1752346445,'__ci_last_regenerate|i:1752346444;'),('i0305pk5lrrrrmnet5m82qb2psh7abca','82.29.165.22',1752073326,'__ci_last_regenerate|i:1752073325;'),('i0gcgovi3jfqn050atarjpl0ntd0capo','82.29.165.22',1752253326,'__ci_last_regenerate|i:1752253325;'),('i15mu7qj6v3gk9d72isrqmotpi6l7lhb','82.29.165.22',1752140109,'__ci_last_regenerate|i:1752140107;'),('i344m5p90di4o2a7u4laluceo2t2va6s','82.29.165.22',1752160808,'__ci_last_regenerate|i:1752160807;'),('i38gd8tohn4sl6sqkm70pgr1jvr31cd0','110.172.155.237',1752050645,'__ci_last_regenerate|i:1752050645;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;'),('i3ajv3snomtlbquo8307po32ij0sff36','82.29.165.22',1752187925,'__ci_last_regenerate|i:1752187924;'),('i3hvfb73e1rniepk2ge18fnacfveedoc','82.29.165.22',1752335944,'__ci_last_regenerate|i:1752335944;'),('i3il545me20ds9oodfi9hptnnankabp6','82.29.165.22',1752392645,'__ci_last_regenerate|i:1752392645;'),('i3r5cjdjeb07uophruc91us6lfm88ivb','110.172.155.237',1752046796,'__ci_last_regenerate|i:1752046651;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";'),('i43f2i79quu4aapt3d7hvksvn71jd34a','82.29.165.22',1752298805,'__ci_last_regenerate|i:1752298805;'),('i480tqegkj7gacii10lbdlcsh3ojaav8','82.29.165.22',1752354185,'__ci_last_regenerate|i:1752354184;'),('i4pqu8o3r2ge35l7cq6vpud57efghhan','82.29.165.22',1752132726,'__ci_last_regenerate|i:1752132725;'),('i5hnl3qtorklfklp53grepgrm3flurgf','82.29.165.22',1752213613,'__ci_last_regenerate|i:1752213611;'),('i64r7764lnjfkst9815njdurikrfvks2','82.29.165.22',1752285610,'__ci_last_regenerate|i:1752285608;'),('i7f18h00a3qn6ds62nsr1n8bjo4tj7vg','82.29.165.22',1752435785,'__ci_last_regenerate|i:1752435784;'),('i7gfl4t60g7irf8o7mfub6t5fmkprkrl','82.29.165.22',1752424209,'__ci_last_regenerate|i:1752424207;'),('i7osvt9ai7o13u6udip1f8a62b4837lb','82.29.165.22',1752318188,'__ci_last_regenerate|i:1752318187;'),('i85c7qe6vejvd57vsbd8qtads0j2l5qe','82.29.165.22',1752233584,'__ci_last_regenerate|i:1752233584;'),('i8amv1m1oog2jou48l4gptp35o6pljct','82.29.165.22',1752264665,'__ci_last_regenerate|i:1752264664;'),('ibf7j4hv3acnh6sv76pe3igt0ofd0hk3','82.29.165.22',1752141126,'__ci_last_regenerate|i:1752141125;'),('idsgv1hnufj5upkd640t0nqg1ip8k70s','82.29.165.22',1752090185,'__ci_last_regenerate|i:1752090184;'),('idt5akhhsv31qpjpbfcgodrjs5541o0j','82.29.165.22',1752413046,'__ci_last_regenerate|i:1752413045;'),('idtsi7iqmf7ess56cb5u98c7oe7kqgu5','82.29.165.22',1752452944,'__ci_last_regenerate|i:1752452944;'),('ie9e95sppc2cjlt48bv1n5687869k82c','82.29.165.22',1752471308,'__ci_last_regenerate|i:1752471306;'),('ifhuop9s04i2r632o42rt05lr4i8u1gm','82.29.165.22',1752175025,'__ci_last_regenerate|i:1752175024;'),('igoj67jrpk365270rbri47nk2lfikalk','82.29.165.22',1752291186,'__ci_last_regenerate|i:1752291185;'),('iij2l8hmvs1mbpk5e1t57lrutrb755ev','82.29.165.22',1752098947,'__ci_last_regenerate|i:1752098946;'),('ij6hagf1g7bije706grq82ucjc1q80ge','82.29.165.22',1752418626,'__ci_last_regenerate|i:1752418625;'),('ijerm6ap54msorekk28nq2gi8fe54mto','82.29.165.22',1752400746,'__ci_last_regenerate|i:1752400745;'),('ik7ol9trm4k5bqfqhqbl2a45pt91at77','152.59.172.131',1752133423,'__ci_last_regenerate|i:1752133423;is_mobile|b:1;staff_user_id|s:1:\"2\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";'),('ik9q90291a9etpgg0hp5d8lnglh0n4nj','82.29.165.22',1752194165,'__ci_last_regenerate|i:1752194165;'),('ika50tdle3b56jk0h3dork8h3a66idaj','82.29.165.22',1752113043,'__ci_last_regenerate|i:1752113043;'),('ikv8djkmeh1huu24t43dpjamk9or2h3m','82.29.165.22',1752372064,'__ci_last_regenerate|i:1752372064;'),('ilcqmnehokmqbvjg8hkpnosc5ukf933e','82.29.165.22',1752103144,'__ci_last_regenerate|i:1752103143;'),('ili1rkaehn6j4cs03f9r1cdvmtkk48e1','82.29.165.22',1752450484,'__ci_last_regenerate|i:1752450484;'),('im1p053isucqrgsrgrajig6inkmerv1o','82.29.165.22',1752509525,'__ci_last_regenerate|i:1752509524;'),('imah3u8i00gr98ecqlisjne70qajvq3m','82.29.165.22',1752368706,'__ci_last_regenerate|i:1752368705;'),('imbuo9s2fat5cgbguehbv8tomtfppfil','82.29.165.22',1752216064,'__ci_last_regenerate|i:1752216064;'),('imo9qebq1g5ek82are3m7kkdjjbtrgvp','82.29.165.22',1752384964,'__ci_last_regenerate|i:1752384964;'),('io361frpc93i4t27ugq26vii6u7kpec7','82.29.165.22',1752215410,'__ci_last_regenerate|i:1752215409;'),('iopdfcrv8eeuefk8m2pjfi8isstja3b4','82.29.165.22',1752288785,'__ci_last_regenerate|i:1752288784;'),('iordqdrgrqp4lsai6oitv5oca1g0sqrj','82.29.165.22',1752309426,'__ci_last_regenerate|i:1752309425;'),('iq9j27j5bfofcr5tbtue4tbfvi50ous4','82.29.165.22',1752347824,'__ci_last_regenerate|i:1752347824;'),('iql91sm43us9m327e86s3lbmhnge6blb','82.29.165.22',1752293286,'__ci_last_regenerate|i:1752293285;'),('ir9sdddql44la430ev1urj4gd2b1keji','82.29.165.22',1752505210,'__ci_last_regenerate|i:1752505208;'),('iroc3v70qqmdkee9e67cmlos4j239bn7','82.29.165.22',1752345066,'__ci_last_regenerate|i:1752345065;'),('is6gq50eiurji2uhl251c7a5ubs1a8h8','82.29.165.22',1752419706,'__ci_last_regenerate|i:1752419705;'),('isah1n8eq5trk6retjo5jk0rkcdmqtme','82.29.165.22',1752148566,'__ci_last_regenerate|i:1752148565;'),('itkjicagb4srek6k8t1sg4dpt8ahdu2h','82.29.165.22',1752344706,'__ci_last_regenerate|i:1752344705;'),('iu98pcifmcq48f8p39dvb6ei212m1v6m','82.29.165.22',1752104225,'__ci_last_regenerate|i:1752104224;'),('ium4vf63hmnq295bhafjcpajpo9ht9o2','82.29.165.22',1752182344,'__ci_last_regenerate|i:1752182344;'),('ivide8vu9rg4l24hlutovo7a8vvt0cb5','82.29.165.22',1752493686,'__ci_last_regenerate|i:1752493685;'),('j0k40u484dr9bifutjht63smi5eukbjv','82.29.165.22',1752478926,'__ci_last_regenerate|i:1752478925;'),('j11s44r4gbl06qfpicgr59vtjabj1o4q','82.29.165.22',1752105305,'__ci_last_regenerate|i:1752105304;'),('j1p0rta4rmss2doaihm8kckgapt144ck','82.29.165.22',1752312546,'__ci_last_regenerate|i:1752312545;'),('j2106h4cdjj3f8hin0nj7m6kgkrfcb47','82.29.165.22',1752389886,'__ci_last_regenerate|i:1752389885;'),('j28nsrlragpntknviv14kjoqqi1vtct6','82.29.165.22',1752217865,'__ci_last_regenerate|i:1752217865;'),('j3tb35a98vhsqo9pmlofvms0u5n8bnfs','82.29.165.22',1752194526,'__ci_last_regenerate|i:1752194525;'),('j49go4fll8nrpiojdcdcsa2nrard2lhr','82.29.165.22',1752414487,'__ci_last_regenerate|i:1752414485;'),('j4c8knfohs04gt61gak83r6091sd36ag','82.29.165.22',1752165785,'__ci_last_regenerate|i:1752165784;'),('j53euip3566lgmkdbp1abtlumnvajliv','82.29.165.22',1752489487,'__ci_last_regenerate|i:1752489486;'),('j5iq14r87uud58lpkruil59hjof39op5','82.29.165.22',1752188285,'__ci_last_regenerate|i:1752188284;'),('j64tdb0gc7ug0l5p544poj044cpvkpua','82.29.165.22',1752192485,'__ci_last_regenerate|i:1752192485;'),('j6ub5cp0cpb0ldj6b7ft1chve2b6rkl5','82.29.165.22',1752149943,'__ci_last_regenerate|i:1752149943;'),('j754v50pn46o05h9suatoitl4klppp4o','82.29.165.22',1752284585,'__ci_last_regenerate|i:1752284584;'),('j7ca8o6amfru5sevd39onepra6f9od86','82.29.165.22',1752127085,'__ci_last_regenerate|i:1752127084;'),('j7pml4fl5ubuutghvq5ij5jd7huekgpe','82.29.165.22',1752201366,'__ci_last_regenerate|i:1752201365;'),('j87cusanfik22rljablgqhk1l1t2d8d7','82.29.165.22',1752276604,'__ci_last_regenerate|i:1752276604;'),('j8q6lbigse4q036a5roabe52cuukmrqh','82.29.165.22',1752163327,'__ci_last_regenerate|i:1752163326;'),('j9c6fskcc1g991195l9g0akhoitnqgkb','82.29.165.22',1752427386,'__ci_last_regenerate|i:1752427385;'),('j9o2qttj7gtt41v475b74nctrit9m2d8','82.29.165.22',1752331805,'__ci_last_regenerate|i:1752331805;'),('ja2janap1bdc5n137g9vpb1nd228onbn','82.29.165.22',1752357065,'__ci_last_regenerate|i:1752357064;'),('jappukmiib2in9sgj2j0230krrbrbi7s','82.29.165.22',1752448445,'__ci_last_regenerate|i:1752448444;'),('jb6fpm04n61ihddn9n4evrjf9tbt3oq6','82.29.165.22',1752366965,'__ci_last_regenerate|i:1752366964;'),('jd58g72avnu4tvt42tc0h0hiu5vmitsj','82.29.165.22',1752315667,'__ci_last_regenerate|i:1752315666;'),('jdh6gkcmncf6r4tbnnstp76j56gvri6m','82.29.165.22',1752340507,'__ci_last_regenerate|i:1752340505;'),('jgr8co458gmje6cle9rdrc3n6lr5fjm2','82.29.165.22',1752422825,'__ci_last_regenerate|i:1752422824;'),('jh45helekvil7d8jgqqui5kcs3kkdv0v','82.29.165.22',1752513305,'__ci_last_regenerate|i:1752513305;'),('jhb773pd243gpb1cuq468ihmg82gdd82','82.29.165.22',1752265025,'__ci_last_regenerate|i:1752265024;'),('jhjj8j2774d6t89pldool72c7gke282a','82.29.165.22',1752366245,'__ci_last_regenerate|i:1752366244;'),('jj18o58l5rnfvr0illbhkc3nmr8ic9ak','82.29.165.22',1752515046,'__ci_last_regenerate|i:1752515045;'),('jl8g9d8sgg7960orcnh0bgvh70pdm79d','82.29.165.22',1752337026,'__ci_last_regenerate|i:1752337025;'),('jl9ngh16th65cdffgelm0n8c0jlv58se','82.29.165.22',1752468846,'__ci_last_regenerate|i:1752468845;'),('jlk06gjt6f6k66027h12tm0o026erlo3','82.29.165.22',1752488047,'__ci_last_regenerate|i:1752488045;'),('jm52p03v9franjpcl98nau307o5jev0l','82.29.165.22',1752352023,'__ci_last_regenerate|i:1752352023;'),('jmdb3sd6omn0oofudg37cii2hhkcufot','82.29.165.22',1752256444,'__ci_last_regenerate|i:1752256443;'),('jn7m0udvhemj7t705rhlsmn0aj6iep8q','82.29.165.22',1752073685,'__ci_last_regenerate|i:1752073684;'),('jq42odv4p94iut0igp3josil4s3edhap','82.29.165.22',1752270006,'__ci_last_regenerate|i:1752270005;'),('jq99feqbokuelot962f37t3nf35od48j','82.29.165.22',1752139386,'__ci_last_regenerate|i:1752139385;'),('jrb722svkn42lvaq1gqpgfnm6hfdan15','82.29.165.22',1752490567,'__ci_last_regenerate|i:1752490566;'),('js1c5tsbbmru4q4t8tdlm5mgs3rvvjii','82.29.165.22',1752488766,'__ci_last_regenerate|i:1752488765;'),('jtj6il41flj485lb187q3oivth72pn7j','82.29.165.22',1752138308,'__ci_last_regenerate|i:1752138307;'),('jubh7upgki9g1alicidcdlpu7eqjmf1v','82.29.165.22',1752325566,'__ci_last_regenerate|i:1752325565;'),('jujfan3pmc7ubd68fv0k68o7rr7905r3','82.29.165.22',1752515765,'__ci_last_regenerate|i:1752515764;'),('jvvfok8661il360fi3l4ajlegbr94jf2','82.29.165.22',1752362763,'__ci_last_regenerate|i:1752362763;'),('k286580jspc74c6rhu6gfq67iu9iprl7','82.29.165.22',1752160084,'__ci_last_regenerate|i:1752160084;'),('k3iqucqe11jp9r0fcdvb0jgp1kjv3c29','82.29.165.22',1752476826,'__ci_last_regenerate|i:1752476825;'),('k3qnbers0nojhv07olp1a5cp7tehbv2h','82.29.165.22',1752209646,'__ci_last_regenerate|i:1752209645;'),('k42c21d9hmt9snlebc9dbrv81t428bdp','82.29.165.22',1752125045,'__ci_last_regenerate|i:1752125044;'),('k4dc0httbal60qb8l3ks10phamm1jpc3','82.29.165.22',1752081907,'__ci_last_regenerate|i:1752081906;'),('k4jbjnli6ukk8tch7jiv6espuc2gs3us','82.29.165.22',1752143288,'__ci_last_regenerate|i:1752143286;'),('k6dtjq8208h1ba6rro6gus94nmttikqr','82.29.165.22',1752375246,'__ci_last_regenerate|i:1752375245;'),('k6k4e5nf0h6uud6pcvjq6nf2rc6gkoj8','82.29.165.22',1752451925,'__ci_last_regenerate|i:1752451924;'),('k71itmbdlug0ihqla7d2usb7vqdv5822','82.29.165.22',1752191405,'__ci_last_regenerate|i:1752191405;'),('k7mglddg9e14qfuvh3i3jdmtfiocatrr','82.29.165.22',1752349625,'__ci_last_regenerate|i:1752349625;'),('k88ralfijbepdll7auohfk72n8scllsa','82.29.165.22',1752161527,'__ci_last_regenerate|i:1752161526;'),('k8vqpumls0rgovdrni0stp3ssj446uof','82.29.165.22',1752238925,'__ci_last_regenerate|i:1752238925;'),('kb1j6v74cd21i999c4qmgsdfcqgeb21j','82.29.165.22',1752177185,'__ci_last_regenerate|i:1752177184;'),('kccprr8l8h9subruu57jo06i0tn28ggd','82.29.165.22',1752353106,'__ci_last_regenerate|i:1752353105;'),('kctfvbrq8lbs7bm8d4gvufa7em2a3fvr','110.172.155.237',1752046651,'__ci_last_regenerate|i:1752046651;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";'),('kcumnj74u83b33q4o8vu2pu42o0fpket','82.29.165.22',1752061924,'__ci_last_regenerate|i:1752061924;'),('kd5koleslsocfpp0lrs2f8d88v4p1rkt','82.29.165.22',1752370384,'__ci_last_regenerate|i:1752370384;'),('kec0jklopsaotoa0lvjbo3dnjejbc9sj','82.29.165.22',1752049926,'__ci_last_regenerate|i:1752049925;'),('kefqnieo0ch6lkdh8s9rujnsahe7avgd','82.29.165.22',1752123007,'__ci_last_regenerate|i:1752123006;'),('kf5jov6vfd13fra1jt2ml0e9ihjfg4as','82.29.165.22',1752255065,'__ci_last_regenerate|i:1752255064;'),('kfu4vup9sgmkqvv6dktd6338u2ip4gtj','82.29.165.22',1752319627,'__ci_last_regenerate|i:1752319626;'),('kgt1546j1rbcjlbfusssvb5mpp7dsm1d','82.29.165.22',1752299526,'__ci_last_regenerate|i:1752299525;'),('kgusdkghkv4b5kcf4crfs2gtdbcel92v','82.29.165.22',1752465306,'__ci_last_regenerate|i:1752465305;'),('khc1qf5hpl2vgfr46gslfr92hmpg3vhj','82.29.165.22',1752218586,'__ci_last_regenerate|i:1752218585;'),('kip7hj1b1rsgg0h1g4n9r237kfvd5srv','82.29.165.22',1752385328,'__ci_last_regenerate|i:1752385326;'),('kiqblbbpv8rbref7ia212u7d5ebvg9ev','82.29.165.22',1752433985,'__ci_last_regenerate|i:1752433984;'),('kj54tes5g4mlhpsn5j8r9fbh8ius6hef','82.29.165.22',1752431885,'__ci_last_regenerate|i:1752431884;'),('kjg3k7pf3ima1a0860er3l6skf1gk7i6','82.29.165.22',1752166506,'__ci_last_regenerate|i:1752166505;'),('kjskdgo7qsosu5dtg2q4i99bienq9tn7','82.29.165.22',1752507728,'__ci_last_regenerate|i:1752507727;'),('kkqiodbrvuovr8oqaumgf8un2i794ap3','82.29.165.22',1752159786,'__ci_last_regenerate|i:1752159785;'),('kkucp7tu0sl1n5qoodbvsogs9v9k1oc1','82.29.165.22',1752380165,'__ci_last_regenerate|i:1752380165;'),('kl8fllriitm9sp1t8ici836vno8v49gi','82.29.165.22',1752300965,'__ci_last_regenerate|i:1752300964;'),('km08s5d9dnl01uc69t5uva4qtvm6113j','82.29.165.22',1752318550,'__ci_last_regenerate|i:1752318548;'),('kpek0a0gglka0i49fitk3ke9ksju3n3v','82.29.165.22',1752047108,'__ci_last_regenerate|i:1752047106;'),('kpru4diei9prnpnabvka3pmtdatr0fs4','82.29.165.22',1752484267,'__ci_last_regenerate|i:1752484266;'),('kpvuh8ovjtlsfc7hhm0eor636r720nvt','82.29.165.22',1752258246,'__ci_last_regenerate|i:1752258245;'),('kqfu7buikfatible8fdjt87mdtnu0kq2','82.29.165.22',1752199565,'__ci_last_regenerate|i:1752199564;'),('kskc7qljl92ir08jb3j3jtae727gpdjb','82.29.165.22',1752495126,'__ci_last_regenerate|i:1752495125;'),('ksu6tmeor0apep28fleqq7p95cgl3ggn','82.29.165.22',1752077107,'__ci_last_regenerate|i:1752077105;'),('kt7a84hsc8t31p053qocags3vvpra01o','82.29.165.22',1752085506,'__ci_last_regenerate|i:1752085505;'),('ktln72rl0pftaanftqs54v4632m13nb0','82.29.165.22',1752111306,'__ci_last_regenerate|i:1752111305;'),('ku9jj3bvbv2kr8dlhbo9nbuc5cnvfn8d','82.29.165.22',1752249364,'__ci_last_regenerate|i:1752249364;'),('kv3g74hmarn9r423rd2ds7324ja5m8iv','82.29.165.22',1752252965,'__ci_last_regenerate|i:1752252965;'),('kvbbam36l59j2eo5r5hglg1kvl8ld29v','82.29.165.22',1752356347,'__ci_last_regenerate|i:1752356346;'),('l07ql553n44buln0mjb1n5eghv97ien9','82.29.165.22',1752186905,'__ci_last_regenerate|i:1752186904;'),('l0h4j25hq7g9l8r8j793qt5kg6avr8ia','82.29.165.22',1752486967,'__ci_last_regenerate|i:1752486965;'),('l17rr6vlrpog4727js81vrb70uop0lqo','82.29.165.22',1752072245,'__ci_last_regenerate|i:1752072244;'),('l31n51p94m57pifs5ikkn61hfh2sp29u','82.29.165.22',1752394808,'__ci_last_regenerate|i:1752394806;'),('l3ducrvdpfhq7stbmb73n8hb3e1gt940','82.29.165.22',1752384007,'__ci_last_regenerate|i:1752384006;'),('l4bdpptgtsrbrl5j5i0t288qd6dud4pl','82.29.165.22',1752332166,'__ci_last_regenerate|i:1752332165;'),('l4erjtm89j3oidp7eq6gkl8lh01u8dr3','82.29.165.22',1752241745,'__ci_last_regenerate|i:1752241744;'),('l4etbj3e51ig7nontsm1vi8uh7quo98e','82.29.165.22',1752072966,'__ci_last_regenerate|i:1752072965;'),('l4rgmab98neivl8gcuiflu9pjpidet14','82.29.165.22',1752419348,'__ci_last_regenerate|i:1752419347;'),('l5pk2hbmkui7jovd96ntck0vb40fohrr','82.29.165.22',1752399008,'__ci_last_regenerate|i:1752399007;'),('l5th01et0j2bbs4upeve0uchs2cbvo9k','82.29.165.22',1752050288,'__ci_last_regenerate|i:1752050287;'),('l6ibdherbirtii6fgp1ihumbjr1rgt9n','82.29.165.22',1752390246,'__ci_last_regenerate|i:1752390245;'),('l6ursurobvr8j03afc1744rq6ipn0ghf','82.29.165.22',1752465965,'__ci_last_regenerate|i:1752465964;'),('l7r1qa74aru335u61k4767dao7aubah3','122.173.125.91',1752341720,'__ci_last_regenerate|i:1752341720;is_mobile|b:1;'),('l8eb9qflemrqmjpj1nu4pejgjovg1i2m','82.29.165.22',1752274265,'__ci_last_regenerate|i:1752274264;'),('l8n755aek9nm7vcoul6he4nu4c92ou73','82.29.165.22',1752385985,'__ci_last_regenerate|i:1752385985;'),('l94smkl4g07oht9pkbi214jd4ed6idqq','82.29.165.22',1752335646,'__ci_last_regenerate|i:1752335645;'),('lar6li9huhn662fpp93jjnd4fav8k9l5','82.29.165.22',1752319268,'__ci_last_regenerate|i:1752319267;'),('lbl7do693te48ohliqcsjhbjqpn46i9h','82.29.165.22',1752324846,'__ci_last_regenerate|i:1752324845;'),('lc5omudqtub3a3gs2a8naburtt4rouhi','82.29.165.22',1752297423,'__ci_last_regenerate|i:1752297423;'),('lcvohg362nfemgk6f229gr39tfiin1qd','82.29.165.22',1752347525,'__ci_last_regenerate|i:1752347524;'),('ldlabt7knmatmbe5462u60j8nrhuueop','82.29.165.22',1752131646,'__ci_last_regenerate|i:1752131645;'),('ldsj437j3v7uq4v747qcndvbk4r2i3em','82.29.165.22',1752424566,'__ci_last_regenerate|i:1752424565;'),('le0s54cmjs2uno3n29hd6ql3apuiv9pk','82.29.165.22',1752066064,'__ci_last_regenerate|i:1752066064;'),('leu7csonuao1olec9cnrj6oe6cgr1qgk','82.29.165.22',1752339786,'__ci_last_regenerate|i:1752339785;'),('levjeveehetrbs1cu75obreq104tnkq7','82.29.165.22',1752157687,'__ci_last_regenerate|i:1752157686;'),('lf6t4mn873jo0ck24jftpjct9o5qna3i','82.29.165.22',1752119764,'__ci_last_regenerate|i:1752119764;'),('lfi83m7qja6r6vj1v2a5793uq4k5nk1g','82.29.165.22',1752183365,'__ci_last_regenerate|i:1752183365;'),('lfkbjo27sn4cl686geb5fr9eta9uhgmi','82.29.165.22',1752232926,'__ci_last_regenerate|i:1752232925;'),('lfonsk167v5voqb2bdf9poqt9pubunn1','82.29.165.22',1752439985,'__ci_last_regenerate|i:1752439985;'),('lg051btkrhqu9omhqgj09v17cnnlv2k8','82.29.165.22',1752066426,'__ci_last_regenerate|i:1752066425;'),('lg7mhtk7hu0j24tj6f4h3nbju1d5tq71','82.29.165.22',1752294666,'__ci_last_regenerate|i:1752294665;'),('lgqrpn6r78cda3fitos1fbqrfk5l5r52','82.29.165.22',1752257166,'__ci_last_regenerate|i:1752257165;'),('lhba4t21n50k6u8b1ujaqd1gumd8bket','82.29.165.22',1752397926,'__ci_last_regenerate|i:1752397925;'),('ljh73nfaorj14prn5sfauo25747mv1sj','82.29.165.22',1752471667,'__ci_last_regenerate|i:1752471666;'),('lklfutgt2bmdb2rvf8apq6tvjpnf813n','82.29.165.22',1752070147,'__ci_last_regenerate|i:1752070147;'),('lkvpm42nff2rai3fdv7156tmefu56m20','82.29.165.22',1752214326,'__ci_last_regenerate|i:1752214325;'),('ll1r8bpi966me8q8j6mt00a8rifriclu','82.29.165.22',1752091863,'__ci_last_regenerate|i:1752091863;'),('ll7bes0pnsv5l05tmg6h4rvev0u4brjd','82.29.165.22',1752299165,'__ci_last_regenerate|i:1752299164;'),('llgcb0va2vmar5kgdp9l85kaupqgesbl','82.29.165.22',1752132367,'__ci_last_regenerate|i:1752132366;'),('lls9u4meudpi1bpiuk381uovg9elj6se','82.29.165.22',1752292204,'__ci_last_regenerate|i:1752292204;'),('lms46ojurs8meono3edqo1veb0kcrlv8','82.29.165.22',1752410226,'__ci_last_regenerate|i:1752410225;'),('ln4tpgs00fa1jj7vev395jcnesobiuh5','82.29.165.22',1752426307,'__ci_last_regenerate|i:1752426306;'),('lnb56ug5ebnpecj8b5f48rhg25c1r0v7','82.29.165.22',1752343985,'__ci_last_regenerate|i:1752343984;'),('lnugchdv0j860arodgmju0m4br2n4dq3','82.29.165.22',1752339426,'__ci_last_regenerate|i:1752339425;'),('lpupclo9fu34oovddll5bfk03ts5bkov','82.29.165.22',1752277325,'__ci_last_regenerate|i:1752277324;'),('lq1lcg3p6fpjpju37efoflkmtdftpds7','82.29.165.22',1752314948,'__ci_last_regenerate|i:1752314947;'),('lq9mvu6aikf8cc6mhb9v3bbtcnfhoo8m','82.29.165.22',1752170465,'__ci_last_regenerate|i:1752170464;'),('lr2vqscqn0jkkiogup65uanm84b0j8pm','82.29.165.22',1752355265,'__ci_last_regenerate|i:1752355264;'),('lrkvsqb3atp5b31q6ficrl6or1gtk3o3','82.29.165.22',1752266825,'__ci_last_regenerate|i:1752266824;'),('lsp3dv15rte5tdjq3h71gconrat1drpv','82.29.165.22',1752504846,'__ci_last_regenerate|i:1752504845;'),('lt585gafgihac2bc0bj6keleduv0hboe','82.29.165.22',1752130626,'__ci_last_regenerate|i:1752130625;'),('lu0lvp1v572ardfi0tta2ekqoq71pq0i','82.29.165.22',1752185525,'__ci_last_regenerate|i:1752185524;'),('lubsnk2bkrftghvnv084p1e8g80v52a9','82.29.165.22',1752189305,'__ci_last_regenerate|i:1752189304;'),('m0231pibraibb5m3n1mt8q2bk4ukpve0','82.29.165.22',1752317827,'__ci_last_regenerate|i:1752317826;'),('m1qh135bt3ja9gd3gdlhksm2ad4q95r2','82.29.165.22',1752477186,'__ci_last_regenerate|i:1752477184;'),('m2dn320ko9mvoqrmau233lu9olngfuuf','82.29.165.22',1752296465,'__ci_last_regenerate|i:1752296464;'),('m2pjkr3h9qak4c0oqvm9823bqaui6199','82.29.165.22',1752047767,'__ci_last_regenerate|i:1752047766;'),('m2ul5cmhfln1mbbdevj80ee0siusadj8','82.29.165.22',1752524763,'__ci_last_regenerate|i:1752524763;'),('m3gje0h39g4eqarojpl4mtvb0g1er5ka','82.29.165.22',1752046751,'__ci_last_regenerate|i:1752046749;'),('m3ste1nbo4iqsiqdtlkl5f6q9fcv5ip7','82.29.165.22',1752486307,'__ci_last_regenerate|i:1752486305;'),('m456qelc8ulnra6alido1fftp0egie0j','103.95.164.179',1752133990,'__ci_last_regenerate|i:1752133901;is_mobile|b:1;red_url|s:35:\"https://himalay.techdotbit.in/admin\";'),('m542t4de648hkim0tj6lr670e6a7elv6','82.29.165.22',1752522065,'__ci_last_regenerate|i:1752522064;'),('m550bfqtsq9fmgu4hfr0itddsi8a97o7','82.29.165.22',1752085146,'__ci_last_regenerate|i:1752085145;'),('m6eo4oqpp9g1n2q41a25vmovvjljf9hg','110.172.155.237',1752051279,'__ci_last_regenerate|i:1752051279;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;'),('m6si3cn292rck0lo3jhi412g50np88si','82.29.165.22',1752250445,'__ci_last_regenerate|i:1752250444;'),('m7mohthm0kfvdnqgp7ajffp4ngc5rf1c','82.29.165.22',1752268925,'__ci_last_regenerate|i:1752268924;'),('m7q5j36kiin92he255jsb3d9nob73i7l','82.29.165.22',1752153847,'__ci_last_regenerate|i:1752153846;'),('m8ltc2u8qecmjvjdauh4lm1kj5kak8mk','82.29.165.22',1752135845,'__ci_last_regenerate|i:1752135845;'),('m8q1dh3sgsqtdrui2b7bfppoiqv6721d','82.29.165.22',1752242043,'__ci_last_regenerate|i:1752242043;'),('m8qbherittefs07c8qdi8de5in771uee','106.205.68.112',1752228310,'__ci_last_regenerate|i:1752228310;is_mobile|b:1;red_url|s:35:\"https://himalay.techdotbit.in/admin\";'),('m8ssk1k130rutmo6493smrcrff8b8vh4','82.29.165.22',1752324486,'__ci_last_regenerate|i:1752324485;'),('m967kt4if1t48o2vnubu1mv1vp4a5dv6','82.29.165.22',1752228726,'__ci_last_regenerate|i:1752228725;'),('mb3kof0ph4ab699galh4h4qqo77jgs6b','82.29.165.22',1752345425,'__ci_last_regenerate|i:1752345425;'),('mb5dmlv3phsbkjtvl8cva8mj2ufjfmd9','82.29.165.22',1752421745,'__ci_last_regenerate|i:1752421745;'),('mcpgh4a7ncfha2or953macnlq51gdm4n','82.29.165.22',1752119465,'__ci_last_regenerate|i:1752119464;'),('mdj3e22rc6dsufiaanpojk6cftgj7h9p','82.29.165.22',1752303426,'__ci_last_regenerate|i:1752303425;'),('mdq748fpuuouju9qqn2bh8fjkcc4s160','82.29.165.22',1752495786,'__ci_last_regenerate|i:1752495785;'),('meimvi97n7o3tohm1hq0tqphvrmvqpq6','223.184.153.158',1752133804,'__ci_last_regenerate|i:1752133804;is_mobile|b:1;red_url|s:35:\"https://himalay.techdotbit.in/admin\";message-danger|s:25:\"Invalid email or password\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"old\";}'),('mf5pi97lal5e4f8ug6g8rs71m2gldaqh','82.29.165.22',1752087305,'__ci_last_regenerate|i:1752087304;'),('mfhpdjqsdfsnbce1o0ka02gi3gqo2h2i','82.29.165.22',1752348545,'__ci_last_regenerate|i:1752348544;'),('mfn8gcfba31j78q2vmbiqo9ifhf6c72v','82.29.165.22',1752223445,'__ci_last_regenerate|i:1752223444;'),('mg5k6bs2mfu5d7uvg47kiv97kquqtiam','82.29.165.22',1752099665,'__ci_last_regenerate|i:1752099665;'),('mgced8fctu7pm2ojdpvpuptrk3tkrn6q','110.172.155.237',1752046287,''),('mgn3q9jc301ri5v77hc8crqb38nvqjtj','82.29.165.22',1752109565,'__ci_last_regenerate|i:1752109564;'),('mhcr68bktf8c90ac49hen39e5um9n89k','82.29.165.22',1752431164,'__ci_last_regenerate|i:1752431164;'),('mht39qnu0o7tjdubnvj1tohlhrmmse0a','82.29.165.22',1752185165,'__ci_last_regenerate|i:1752185164;'),('mi69htrcg1beh3d42hqrelmhlc7ja69f','82.29.165.22',1752442505,'__ci_last_regenerate|i:1752442504;'),('miqq1b76gqfbja217bf4ql1sc63kqijq','82.29.165.22',1752372785,'__ci_last_regenerate|i:1752372784;'),('mjajife4qp2h9tcpaj3ub24144ef47eu','82.29.165.22',1752183008,'__ci_last_regenerate|i:1752183006;'),('mkrssjujj3fq66p8vngd8t09mr00ud4d','82.29.165.22',1752063008,'__ci_last_regenerate|i:1752063006;'),('mlqphuvsu7mgov3a5rav9m7gb7tt59l6','82.29.165.22',1752062287,'__ci_last_regenerate|i:1752062286;'),('mmcfudacmbl7h6p4i8kais315ov3jk6f','82.29.165.22',1752275285,'__ci_last_regenerate|i:1752275284;'),('mnn8ii4olv882n9o0j1aob9jd19kog86','82.29.165.22',1752103866,'__ci_last_regenerate|i:1752103865;'),('moajl653n65crgvt50kjlj8e0ti8rvab','82.29.165.22',1752505925,'__ci_last_regenerate|i:1752505925;'),('moh93j9q1i0p2vdlvqhn4ls0fb8ikcf7','82.29.165.22',1752104585,'__ci_last_regenerate|i:1752104584;'),('mornf20a3ib5mn4h5q0e0p74kn8fqk6a','82.29.165.22',1752364145,'__ci_last_regenerate|i:1752364144;'),('mp4noa8cs9uvdc7p20c2e76u12kbkina','82.29.165.22',1752504126,'__ci_last_regenerate|i:1752504125;'),('mpic71ao6g8oai9mk11otjdt1bljehlp','82.29.165.22',1752403927,'__ci_last_regenerate|i:1752403926;'),('mr4e3mkioqm706umg3s74kdmnrtp05md','82.29.165.22',1752108485,'__ci_last_regenerate|i:1752108484;'),('mrmng3rc18gf0t1maa4phvbtaj58608g','223.184.153.158',1752152856,'__ci_last_regenerate|i:1752152856;is_mobile|b:1;staff_user_id|s:2:\"12\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";'),('mrpuo1spga8itp6iv3h1fos290vinc19','82.29.165.22',1752076746,'__ci_last_regenerate|i:1752076745;'),('ms20k8eoj8b7ibgie7ubonppjml21q5b','82.29.165.22',1752303725,'__ci_last_regenerate|i:1752303725;'),('msvuovh6m61r33g6h978o626aam14ier','82.29.165.22',1752295385,'__ci_last_regenerate|i:1752295385;'),('mtm2odf61enc589p0rmbj2oduvrogltr','82.29.165.22',1752278045,'__ci_last_regenerate|i:1752278044;'),('mvgrgvae0brn9ci8p4k6356mn9qqgq50','82.29.165.22',1752077466,'__ci_last_regenerate|i:1752077465;'),('n0muuib24d3pla9n0d1uudl2ecmvhass','82.29.165.22',1752441425,'__ci_last_regenerate|i:1752441424;'),('n0uv8tu1ab8hmormjmelvqqohmccal6m','82.29.165.22',1752052447,'__ci_last_regenerate|i:1752052445;'),('n14d929bvdnee7fjska8pr9vaaag5tu9','82.29.165.22',1752311526,'__ci_last_regenerate|i:1752311525;'),('n1662jlks2jrdjabciavqs6sg1gatmag','82.29.165.22',1752060546,'__ci_last_regenerate|i:1752060545;'),('n1tnquec6kbf0mfo69qqof9h4vmm2ls7','82.29.165.22',1752255425,'__ci_last_regenerate|i:1752255424;'),('n2eslev99oojrp4okd1r3r1j1qerr8r3','82.29.165.22',1752271445,'__ci_last_regenerate|i:1752271445;'),('n3c003crcqlvvl3r52lvkmp34rvkb6ol','82.29.165.22',1752289805,'__ci_last_regenerate|i:1752289805;'),('n3npmfdb7mq7pvbcfc360dctar4r3ob4','82.29.165.22',1752479286,'__ci_last_regenerate|i:1752479285;'),('n4619q0oj8c1dmuccbt12s2hsh6obs0l','82.29.165.22',1752189964,'__ci_last_regenerate|i:1752189963;'),('n4u7p2b2dvj2becmla3b4eonbk1j4br5','82.29.165.22',1752399367,'__ci_last_regenerate|i:1752399366;'),('n6tvu4n9t5in9c4c22e696qq1c1t6tc6','82.29.165.22',1752281825,'__ci_last_regenerate|i:1752281824;'),('n82o8psgv6u0ms4enjf6n56a3kueavm8','82.29.165.22',1752112385,'__ci_last_regenerate|i:1752112384;'),('n99u67fmvtsj4q36j9cagtblr7lgehet','82.29.165.22',1752266106,'__ci_last_regenerate|i:1752266105;'),('n9u9r8etttfks55vkahj21roio9m7st1','82.29.165.22',1752448084,'__ci_last_regenerate|i:1752448084;'),('nbhihjnmp1vloal79jgm2tvhrdhhfrq8','82.29.165.22',1752348906,'__ci_last_regenerate|i:1752348905;'),('nbrekodmvd0i6he4dpddoon2d2a82e7q','82.29.165.22',1752352747,'__ci_last_regenerate|i:1752352746;'),('nclmnvltec0ohc1t4ku0e84lsdtf4l9t','82.29.165.22',1752117666,'__ci_last_regenerate|i:1752117665;'),('ne7m4re3hg4uqs4i2bm3k4oh3ti3fga9','82.29.165.22',1752505566,'__ci_last_regenerate|i:1752505565;'),('negpjgfu7t6sp36nqbm15je8rn375v7t','82.29.165.22',1752518886,'__ci_last_regenerate|i:1752518885;'),('nerabeav8ttrq8354jaums9mbqq555b1','82.29.165.22',1752280085,'__ci_last_regenerate|i:1752280084;'),('nhrll2hg0tmp7qtq7v5isr92mcl55qhv','82.29.165.22',1752210726,'__ci_last_regenerate|i:1752210725;'),('nhumelnei408f14b1mlufeq34l2v39mo','82.29.165.22',1752466326,'__ci_last_regenerate|i:1752466325;'),('nic5e5sfubgu2f2sk0g0gsv21jhmc5ng','82.29.165.22',1752088745,'__ci_last_regenerate|i:1752088744;'),('niu3k227t8n4h1gd1dtricra6vcsr515','82.29.165.22',1752343623,'__ci_last_regenerate|i:1752343623;'),('nj2jc18mfa0p46jn8oult8v1rhdr8sf8','82.29.165.22',1752509823,'__ci_last_regenerate|i:1752509823;'),('nj65auuho1dfgnu0bsiuaokc6130up87','82.29.165.22',1752405308,'__ci_last_regenerate|i:1752405307;'),('nkdffecs32ntikm1q4333vlmtae3s4r4','82.29.165.22',1752508087,'__ci_last_regenerate|i:1752508085;'),('nkfmtb2k8aiu73ragjlmdem0lbc0hcci','82.29.165.22',1752429786,'__ci_last_regenerate|i:1752429785;'),('nls2acevurp28m2lmheudctlemb50s35','82.29.165.22',1752167586,'__ci_last_regenerate|i:1752167585;'),('nm4qvplghmp4nj508duokekj4p64f72i','82.29.165.22',1752174009,'__ci_last_regenerate|i:1752174007;'),('nmg65p8jpessul33stqqam796oce99r0','82.29.165.22',1752208326,'__ci_last_regenerate|i:1752208325;'),('nmj7v5iq3b7pcstntbq1sgiqd4hkn793','82.29.165.22',1752449105,'__ci_last_regenerate|i:1752449104;'),('nmul059usaia1qfha1ei2vi4nbglu3vt','82.29.165.22',1752057364,'__ci_last_regenerate|i:1752057364;'),('nn5f4h73hkjshpvghnff12u7q0tqinbo','82.29.165.22',1752508810,'__ci_last_regenerate|i:1752508809;'),('nnhsbo147ou4ucn7f76vc4gj0hfhek9e','82.29.165.22',1752122646,'__ci_last_regenerate|i:1752122645;'),('nnob5rc2r12bsjidnd8j9vc16bm0kjqj','82.29.165.22',1752162608,'__ci_last_regenerate|i:1752162606;'),('nnt35v7hc16dlkadlokv22jovejdg3qc','103.95.164.179',1752133616,'__ci_last_regenerate|i:1752133423;is_mobile|b:1;staff_user_id|s:1:\"2\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";'),('np36e6ailj4gn6m12lr434k7plv1di5a','82.29.165.22',1752499266,'__ci_last_regenerate|i:1752499265;'),('np82h6j56b8kdq4h77vfgcjl7g74csof','82.29.165.22',1752197765,'__ci_last_regenerate|i:1752197764;'),('nphm89dok4fcuimb4p65v7v1bf1i04j7','82.29.165.22',1752455764,'__ci_last_regenerate|i:1752455763;'),('nplgeav6jclmn66tr7i6upmg3snq8fj5','82.29.165.22',1752048486,'__ci_last_regenerate|i:1752048485;'),('nqsacbk1mvs5q8raiou82eqtfatcb39l','82.29.165.22',1752270725,'__ci_last_regenerate|i:1752270724;'),('nstcsu1m20muj3ep98cvja7kuuf2051p','82.29.165.22',1752220625,'__ci_last_regenerate|i:1752220625;'),('ntln92v54amqoohvrmkqroaiarpqhdof','82.29.165.22',1752384667,'__ci_last_regenerate|i:1752384665;'),('nuel3pr4ee76sjvjcvf2m2g6fomb0s5h','82.29.165.22',1752467046,'__ci_last_regenerate|i:1752467046;'),('nvnq5b0he790bq49p0nh8nfpj59fpt3r','82.29.165.22',1752414126,'__ci_last_regenerate|i:1752414125;'),('o08206eq5nr7f0vuni1jcoeuesr459hd','223.184.170.162',1752228310,'__ci_last_regenerate|i:1752228310;is_mobile|b:1;red_url|s:35:\"https://himalay.techdotbit.in/admin\";'),('o0d9b2h6bt4er87lo31mbkro7vuu2hv6','82.29.165.22',1752437885,'__ci_last_regenerate|i:1752437884;'),('o1iv20jksom9k7m4p4o7538deuuvkfqv','82.29.165.22',1752229447,'__ci_last_regenerate|i:1752229445;'),('o1tiacuc80592duvq8hg1olr60mls7go','152.58.131.47',1752055055,'__ci_last_regenerate|i:1752055055;'),('o1tpucjqq836gnkh3tnkeotjue0phi3d','82.29.165.22',1752380526,'__ci_last_regenerate|i:1752380525;'),('o2en00adqn5bubm9mc3adjrekfec7uu8','82.29.165.22',1752185823,'__ci_last_regenerate|i:1752185823;'),('o2itbb9lu7jfmb750pqpbdroqm0d36p4','82.29.165.22',1752159426,'__ci_last_regenerate|i:1752159425;'),('o3la8v54sh0ocdft5lpatm34d8f05qor','82.29.165.22',1752456063,'__ci_last_regenerate|i:1752456063;'),('o3psusjm7kmbmb9s8cn1q9f36f7o3pqu','82.29.165.22',1752150306,'__ci_last_regenerate|i:1752150305;'),('o4h7imghtm2did160bu2sngju5akmk5e','82.29.165.22',1752359225,'__ci_last_regenerate|i:1752359224;'),('o5g2dsqef0reva2jh3uvjrhpa3ne2k2m','82.29.165.22',1752230527,'__ci_last_regenerate|i:1752230526;'),('o5ob5bndlpa09ucdfhmfdee7ae3t58cr','82.29.165.22',1752053167,'__ci_last_regenerate|i:1752053166;'),('o616mr5dfit2dqtkk1vun5gleldmnqm7','82.29.165.22',1752403566,'__ci_last_regenerate|i:1752403565;'),('o6osif49nr8rnb44uog20a4tl01t00kp','82.29.165.22',1752245587,'__ci_last_regenerate|i:1752245586;'),('o75npdpruqtnp7h17ojkatm4593hfa31','82.29.165.22',1752447363,'__ci_last_regenerate|i:1752447363;'),('o9ufts6f699vi6gvf1312e979krupsca','82.29.165.22',1752371765,'__ci_last_regenerate|i:1752371764;'),('oa9e5eejl3s0gmp0f7hetrbnjbb5j1n2','82.29.165.22',1752441065,'__ci_last_regenerate|i:1752441065;'),('oagm056ge2fabb5154brhnejvdtm3n65','82.29.165.22',1752254706,'__ci_last_regenerate|i:1752254705;'),('oc1olcoltkfgalgmqcofujbcn43o8fgv','82.29.165.22',1752493327,'__ci_last_regenerate|i:1752493326;'),('od3f1ac5e9ga4rh0dlflj8j64sgt7jne','82.29.165.22',1752411246,'__ci_last_regenerate|i:1752411245;'),('od4focp668ukmpj05s3h0b54vm8s9tju','82.29.165.22',1752208985,'__ci_last_regenerate|i:1752208984;'),('oebu1m5p8oabekq4rhhf03eu3lmc515m','82.29.165.22',1752523747,'__ci_last_regenerate|i:1752523747;'),('oenjoq60h5egumj58tucsjh6q1oide27','82.29.165.22',1752113406,'__ci_last_regenerate|i:1752113405;'),('oeqee5s0p0c02spj8gnd078uojmekqfi','82.29.165.22',1752126064,'__ci_last_regenerate|i:1752126064;'),('oeqskrs2tatbomb98eopvqiqecn78sof','82.29.165.22',1752153487,'__ci_last_regenerate|i:1752153486;'),('of2ptebsobrqtqr4t19b6idvfhdmpciu','82.29.165.22',1752213967,'__ci_last_regenerate|i:1752213965;'),('ohomdse8s5j1obo85cp5nbmdb15g4iih','82.29.165.22',1752135186,'__ci_last_regenerate|i:1752135185;'),('ojiach26qai8i5hhjrhr3cqi9vfckbl5','82.29.165.22',1752321666,'__ci_last_regenerate|i:1752321664;'),('okk89sp2jubevitbh4nb7rvrbcuu1mcg','82.29.165.22',1752417907,'__ci_last_regenerate|i:1752417906;'),('okt0ggpdmfuthm145rqbglvhueddb0of','82.29.165.22',1752197409,'__ci_last_regenerate|i:1752197408;'),('oli0lo97vtkvvseogg7nov937pu4onga','82.29.165.22',1752446346,'__ci_last_regenerate|i:1752446346;'),('opt2oq1or5a9l7o5v25a044k2vb1tsm6','82.29.165.22',1752181623,'__ci_last_regenerate|i:1752181623;'),('oqp755gofurh78ic3rgm063k1upf9hjh','82.29.165.22',1752442865,'__ci_last_regenerate|i:1752442864;'),('ornjquubmksfkvoab29lonpi1u8eglku','82.29.165.22',1752290165,'__ci_last_regenerate|i:1752290164;'),('orsuq3lqo0a1utj23vjkh3bbgunehr9i','82.29.165.22',1752215766,'__ci_last_regenerate|i:1752215765;'),('oscro1opkdhqj4kv1pcejkuqqm6stlfg','82.29.165.22',1752236106,'__ci_last_regenerate|i:1752236105;'),('osh4vaeu4j8lon4bbgoavv09pss7ud1e','82.29.165.22',1752330424,'__ci_last_regenerate|i:1752330424;'),('ot58re5to7i9aiqqdfi436oq4fdl6ogj','82.29.165.22',1752123966,'__ci_last_regenerate|i:1752123965;'),('ov6ufcil2tku9lv7qnfnihjvbthcq1is','82.29.165.22',1752116947,'__ci_last_regenerate|i:1752116947;'),('p0huu6sfebiuu966i2p0d74o6m7m4pbu','82.29.165.22',1752413767,'__ci_last_regenerate|i:1752413765;'),('p13mm8988q3ku6621ohbsmlvitoqdbfp','82.29.165.22',1752435425,'__ci_last_regenerate|i:1752435424;'),('p1afe1si6iq3vt1ftbul156ffddg14ed','82.29.165.22',1752310146,'__ci_last_regenerate|i:1752310145;'),('p3u8ldeup0j3fh4u89s93gvf9a9vqpn5','82.29.165.22',1752472026,'__ci_last_regenerate|i:1752472025;'),('p40g1he07a337qf9l2h16dqphm4cbado','82.29.165.22',1752224465,'__ci_last_regenerate|i:1752224465;'),('p48ul8fp16ogtc5uf5kpmmrntkejvcok','82.29.165.22',1752233948,'__ci_last_regenerate|i:1752233948;'),('p5upotr9e14c3ial14oobiprhf5ms3f7','82.29.165.22',1752098586,'__ci_last_regenerate|i:1752098585;'),('p74lu7adpg3le21qmup17oj33tqvvb84','82.29.165.22',1752374166,'__ci_last_regenerate|i:1752374165;'),('p76sj0ihod3kam1d8hf2n6m9aoc71l6m','82.29.165.22',1752232567,'__ci_last_regenerate|i:1752232566;'),('p98hkmeulq7jam05msrqv5sjqv0l2vvd','82.29.165.22',1752164767,'__ci_last_regenerate|i:1752164765;'),('pbbi6oobfb6n0jrsqtn2evll0171vep0','82.29.165.22',1752219966,'__ci_last_regenerate|i:1752219965;'),('pbou69rmqdr7n0artan5688kirq48fk3','82.29.165.22',1752210366,'__ci_last_regenerate|i:1752210365;'),('pbp4ql1565qg6ee978f1n49uuhh3ktot','82.29.165.22',1752422466,'__ci_last_regenerate|i:1752422465;'),('pcfmpmdad6lsa4g1fhs20tkudhp9503l','82.29.165.22',1752149646,'__ci_last_regenerate|i:1752149645;'),('pcl8lrhemjheccj7qilnjcbr2alfotit','82.29.165.22',1752263585,'__ci_last_regenerate|i:1752263584;'),('pdp1uo1qjn1jueo06ur8hm5htomf0t35','82.29.165.22',1752475086,'__ci_last_regenerate|i:1752475085;'),('pebdfqiq4u9e0bffbu4roionlfacic3h','82.29.165.22',1752454024,'__ci_last_regenerate|i:1752454024;'),('pfmuvj8em3bt3n7msllvuis74epgd2g7','82.29.165.22',1752068166,'__ci_last_regenerate|i:1752068165;'),('pfti1776233j6sr269jmsnq4q4thqtum','82.29.165.22',1752317467,'__ci_last_regenerate|i:1752317466;'),('pgba776e7vbbd5afr63a36rlb7e4umlm','82.29.165.22',1752114786,'__ci_last_regenerate|i:1752114785;'),('pgbd9dti6nu1ei6418c9umblsnvr6op9','82.29.165.22',1752293645,'__ci_last_regenerate|i:1752293644;'),('pgikmpbqdf7u8jo68c899l5bsaddn0cl','82.29.165.22',1752405667,'__ci_last_regenerate|i:1752405666;'),('pi986cntbi6ngtaqj2p3tmunhml7mqm4','82.29.165.22',1752263224,'__ci_last_regenerate|i:1752263224;'),('pihj0tii5c1uljfthhrjsomua9v3b1n7','82.29.165.22',1752361746,'__ci_last_regenerate|i:1752361745;'),('piij4eqcaun2i9qpp25ntksurekh5u2m','82.29.165.22',1752290825,'__ci_last_regenerate|i:1752290824;'),('pinmj85i5gf2lk0ucc7dcm0fhint39oo','82.29.165.22',1752146827,'__ci_last_regenerate|i:1752146826;'),('pip5od86n5pihct62jkauektf49cvbui','82.29.165.22',1752409866,'__ci_last_regenerate|i:1752409865;'),('pkmfok2vus5er3coeirb13boflm4qkaq','82.29.165.22',1752330125,'__ci_last_regenerate|i:1752330124;'),('pmciiffmfn4hlvq5cdj11m21itpj5if0','82.29.165.22',1752300608,'__ci_last_regenerate|i:1752300606;'),('pme3pv3rd9h2aqtqmqu4kin28r3tnejk','82.29.165.22',1752155286,'__ci_last_regenerate|i:1752155285;'),('pmta17tc59nto8qhge6lfntosj4s86df','82.29.165.22',1752443945,'__ci_last_regenerate|i:1752443944;'),('pqpgpe8vp29gffi4a7512mfcrt3t83ut','82.29.165.22',1752084425,'__ci_last_regenerate|i:1752084425;'),('prb9jeecavdlsdtqr7g8qptsjt95m2od','82.29.165.22',1752147486,'__ci_last_regenerate|i:1752147485;'),('pt05eiuhacrsge9q7k8hd6f1ku655uqf','82.29.165.22',1752434706,'__ci_last_regenerate|i:1752434705;'),('pukrrdbjqatvrgub1fulv9r50uhp7fpg','82.29.165.22',1752409207,'__ci_last_regenerate|i:1752409205;'),('pv2q0mccdmv6sjhdl82emnfk08puovk2','82.29.165.22',1752401466,'__ci_last_regenerate|i:1752401465;'),('pv7jqf9orekars1ci9f5ohvlroqlgdlu','82.29.165.22',1752202386,'__ci_last_regenerate|i:1752202384;'),('pvejhr3nqru8qhn9ppm35cp0v9dmv0ka','82.29.165.22',1752053886,'__ci_last_regenerate|i:1752053885;'),('pvhrbj46qhk98e1ta2o9c56fa4tko56e','82.29.165.22',1752350706,'__ci_last_regenerate|i:1752350705;'),('pviv8r5gcfcemag88699r245s6mj4jra','82.29.165.22',1752172211,'__ci_last_regenerate|i:1752172210;'),('q0rg9cfpl31kovcvaap97n4gce7asl8s','82.29.165.22',1752144666,'__ci_last_regenerate|i:1752144666;'),('q1eugb94qmmgi9g84mp2rcd3rm915q1e','82.29.165.22',1752469866,'__ci_last_regenerate|i:1752469865;'),('q1jlam7rfdl0vdcnnuia8srph8v6vaoh','82.29.165.22',1752296764,'__ci_last_regenerate|i:1752296764;'),('q1r7493rg3vv5icfi6ear1tsf7j7jsk8','82.29.165.22',1752349265,'__ci_last_regenerate|i:1752349264;'),('q3ppmeipos1mfe9kjlk3fm7hufdt9uoc','82.29.165.22',1752436145,'__ci_last_regenerate|i:1752436144;'),('q4b4cev3c4a4ec1jn28lglmt4s03qcij','82.29.165.22',1752093666,'__ci_last_regenerate|i:1752093665;'),('q4vkv2h7fcdo9setof5avj8phh0a02p8','82.29.165.22',1752514386,'__ci_last_regenerate|i:1752514385;'),('q5e9inv7p20kmo3s7kld659h25ogtq5g','82.29.165.22',1752401106,'__ci_last_regenerate|i:1752401105;'),('q601rv0vg1lcis6hbvd9l2pk3aq2uq0u','82.29.165.22',1752054247,'__ci_last_regenerate|i:1752054245;'),('q613s5s2srhqmnej4b1gu0t2s7dsv50j','82.29.165.22',1752094683,'__ci_last_regenerate|i:1752094683;'),('q67j0p1d6u0qv3q49hj8afd0e3hodn6q','82.29.165.22',1752059109,'__ci_last_regenerate|i:1752059107;'),('q69u2tvsdf9cq2cr4r7pos64ch5v1bl8','82.29.165.22',1752401826,'__ci_last_regenerate|i:1752401825;'),('q6i5gfu7arugqslglvrl66mrsfl2oofi','82.29.165.22',1752286325,'__ci_last_regenerate|i:1752286324;'),('q7b9h7bjpafugq46o87vlvv551bhc0bi','82.29.165.22',1752459666,'__ci_last_regenerate|i:1752459665;'),('q815bah7p56se6d1n1gvic7jmddks3qc','82.29.165.22',1752207606,'__ci_last_regenerate|i:1752207606;'),('q93fr95ugq2i8qr781k6e6qekcuer4ae','82.29.165.22',1752416585,'__ci_last_regenerate|i:1752416584;'),('q9fst947ojlhndociol2n30nivg2ao02','82.29.165.22',1752484627,'__ci_last_regenerate|i:1752484626;'),('qat7var4k7tts1c9avcepe80st82s5q2','110.172.155.237',1752054178,'__ci_last_regenerate|i:1752053945;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";'),('qc59g7b19th6dbqvekm0vj2neqlfvvo2','82.29.165.22',1752500286,'__ci_last_regenerate|i:1752500285;'),('qdtu1gvkjv96gcfbvv6fv02cgl0cun5v','82.29.165.22',1752393008,'__ci_last_regenerate|i:1752393006;'),('qe3iu1qqrirocvu9d5qf6vj6ff7lneu1','82.29.165.22',1752510186,'__ci_last_regenerate|i:1752510185;'),('qeiu374gdn3j15ck2kh6cct8tl0rs2p5','82.29.165.22',1752388508,'__ci_last_regenerate|i:1752388506;'),('qf75ef1718cf5uolhef8sl236k7ajmif','82.29.165.22',1752054608,'__ci_last_regenerate|i:1752054607;'),('qh5d4fff40e1cig97dad4bau1c0hsapn','82.29.165.22',1752487687,'__ci_last_regenerate|i:1752487685;'),('qh5dbr04gm9dtgcltbkr8b1tum78rtnr','82.29.165.22',1752372425,'__ci_last_regenerate|i:1752372424;'),('qhddp529t2ckrhjjp3mbjgviti85v3k5','82.29.165.22',1752307626,'__ci_last_regenerate|i:1752307625;'),('qi69at2bhsh7sv2rsln7rjcu8bhei0u4','82.29.165.22',1752118026,'__ci_last_regenerate|i:1752118025;'),('qiln318dhggbn0mcbs27tfcjjfih0vms','82.29.165.22',1752311166,'__ci_last_regenerate|i:1752311165;'),('qj5ui0re8for2c347tdcd4d9qmbvgnq9','82.29.165.22',1752388866,'__ci_last_regenerate|i:1752388865;'),('qj70rbglobksk7qiq5lebi0r4rgu5l69','82.29.165.22',1752366607,'__ci_last_regenerate|i:1752366606;'),('qj9m4mr74bum2h4k0sp3bcc1qunbond6','82.29.165.22',1752276965,'__ci_last_regenerate|i:1752276964;'),('qldnd65cddc1pnj8d0onj044917dboob','82.29.165.22',1752275645,'__ci_last_regenerate|i:1752275644;'),('qmgknr1ktoqh4pq743ana1fb5sje5evk','82.29.165.22',1752237846,'__ci_last_regenerate|i:1752237845;'),('qmsoapa1f86bg2au9q4ka9q84phnhked','82.29.165.22',1752219605,'__ci_last_regenerate|i:1752219605;'),('qn6pdcgsqilt9dv619mneogdsu73n8c2','82.29.165.22',1752202745,'__ci_last_regenerate|i:1752202745;'),('qnf16d81c7hq41prmp6ruftlg4c4vojt','82.29.165.22',1752417244,'__ci_last_regenerate|i:1752417244;'),('qnfmktcrst4bdgide7fo8hep8qf7053j','82.29.165.22',1752441785,'__ci_last_regenerate|i:1752441784;'),('qo6jb79aau9mh2pso0vqs28fj2surhj3','82.29.165.22',1752086225,'__ci_last_regenerate|i:1752086224;'),('qp94fvqrtoo7s5eau07fhoab13f8k42v','82.29.165.22',1752052810,'__ci_last_regenerate|i:1752052808;'),('qq17ie30e7hlhjp6ftqtccdhcoo2o1jq','82.29.165.22',1752193206,'__ci_last_regenerate|i:1752193205;'),('qq48pk473ai4hek8jovcbjdqdd5f40jf','82.29.165.22',1752175745,'__ci_last_regenerate|i:1752175744;'),('qqmaap6ns1b7msi3iu3fgbnddkui1aid','82.29.165.22',1752079207,'__ci_last_regenerate|i:1752079205;'),('qsl23mvae4i9bibf8t60hpk35v0l73eo','152.58.131.50',1752053619,'__ci_last_regenerate|i:1752053619;is_mobile|b:1;staff_user_id|s:1:\"2\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";'),('qt6rve3m2kd6flmn4eq8ijscg8a2n8g5','82.29.165.22',1752313266,'__ci_last_regenerate|i:1752313265;'),('r0lua700denrpqurmbfpc68h6o9glvpf','82.29.165.22',1752345724,'__ci_last_regenerate|i:1752345724;'),('r1r75c3enpd1qn36qncqvvf7jfr0rbpr','152.58.131.147',1752056848,'__ci_last_regenerate|i:1752056848;is_mobile|b:1;staff_user_id|s:1:\"2\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";'),('r1urk5olj2er0i5s74fu2pjlbh85o04t','82.29.165.22',1752203465,'__ci_last_regenerate|i:1752203464;'),('r2b9ppusrb3pup24ee0ql2dut38ht599','82.29.165.22',1752453305,'__ci_last_regenerate|i:1752453304;'),('r2m3fshftn8j94ttktdt04fe7mok0u8r','82.29.165.22',1752065407,'__ci_last_regenerate|i:1752065406;'),('r33i4hkf1qiufs081mdg0kthd4m011s4','82.29.165.22',1752172926,'__ci_last_regenerate|i:1752172925;'),('r39s4ljin9hrqh7o0biphqgkjenj0oga','82.29.165.22',1752466686,'__ci_last_regenerate|i:1752466685;'),('r3nttt6r9bh1ntp1no5tihks7klnhqg2','82.29.165.22',1752481812,'__ci_last_regenerate|i:1752481810;'),('r6a0nmiv3nhstpj6ivh42mllb1nglvj0','82.29.165.22',1752375965,'__ci_last_regenerate|i:1752375964;'),('r705o6p1jl9a4sgj0mmjpourg05lefav','82.29.165.22',1752102783,'__ci_last_regenerate|i:1752102783;'),('r8nppa5k5t0k9pm0ddgk2cuo4ri33lue','82.29.165.22',1752375610,'__ci_last_regenerate|i:1752375608;'),('r9b6ohm8l3fv6qu0tnvf5emht8ch6pl7','82.29.165.22',1752077826,'__ci_last_regenerate|i:1752077825;'),('r9s0grsm8hj5ihvad1pl8dtmsmb2p593','82.29.165.22',1752320646,'__ci_last_regenerate|i:1752320645;'),('rb6cq69vp1q5ddfje9anad9s6b6n9ufd','82.29.165.22',1752503766,'__ci_last_regenerate|i:1752503765;'),('rb92j5ff0erj8t393g33bp73c2ebvicg','82.29.165.22',1752498548,'__ci_last_regenerate|i:1752498547;'),('rbockq9c28so6vdk03r8su7h4jl3dmu6','82.29.165.22',1752225124,'__ci_last_regenerate|i:1752225124;'),('rbt0fcg1v49gvutqoiqq4f7p2jvu6qmr','82.29.165.22',1752052087,'__ci_last_regenerate|i:1752052086;'),('rcpoi3jp7q7tvrv1hup4dc0kiepsujlh','82.29.165.22',1752151324,'__ci_last_regenerate|i:1752151324;'),('reclrdqr9unae9bnt4spl7borktdviq2','82.29.165.22',1752299886,'__ci_last_regenerate|i:1752299885;'),('revot86cba2qt63q8gtfk9lccc9hf172','82.29.165.22',1752295745,'__ci_last_regenerate|i:1752295745;'),('rf4ueee8rij5fp156s5qua8g9qh37uur','82.29.165.22',1752268565,'__ci_last_regenerate|i:1752268564;'),('rg2nvmj60smv41abcf1uu743tjq15jsg','82.29.165.22',1752298146,'__ci_last_regenerate|i:1752298145;'),('rg5fdimmj6fidq82cfqnagvqu11362l5','82.29.165.22',1752213247,'__ci_last_regenerate|i:1752213246;'),('rgb04ha7crh0vlc7rkvs8dfaohnn0ja6','82.29.165.22',1752075010,'__ci_last_regenerate|i:1752075009;'),('rhd735vn0m3pdp28ice1kcf2rvubmh2v','82.29.165.22',1752171125,'__ci_last_regenerate|i:1752171124;'),('rhkf0dsv01erc9uh8pl3tocbh1ka70l7','82.29.165.22',1752257885,'__ci_last_regenerate|i:1752257884;'),('rhnl06ea8tm10fr2posvufhhenvql4hj','82.29.165.22',1752344345,'__ci_last_regenerate|i:1752344344;'),('rimk4h0q46jprllqvb3vmjcfdcq12grk','82.29.165.22',1752474367,'__ci_last_regenerate|i:1752474366;'),('rjfasu6bgtist16epk0oh32q5ktjqaj3','82.29.165.22',1752107407,'__ci_last_regenerate|i:1752107406;'),('rktpebk9oq0hpsb59djbf0m073ava7l1','82.29.165.22',1752388146,'__ci_last_regenerate|i:1752388145;'),('rm5rkjajr68s3885klj9bek58b5a02oo','82.29.165.22',1752280445,'__ci_last_regenerate|i:1752280444;'),('rmttkrl32vtr07mcdadrmvof742objpp','82.29.165.22',1752398646,'__ci_last_regenerate|i:1752398645;'),('rns348jr3mp5lc5rsu6h1r0hgu3phc1v','82.29.165.22',1752519904,'__ci_last_regenerate|i:1752519904;'),('rqu3cnp51j703jf7v6b49i6avtcp8svu','82.29.165.22',1752260706,'__ci_last_regenerate|i:1752260705;'),('rrap0ihd6bmshumbln6rrmlcmv0vmv6h','82.29.165.22',1752386347,'__ci_last_regenerate|i:1752386346;'),('rrc0hb35su04atoscrdma6rvrip3fdkn','82.29.165.22',1752227286,'__ci_last_regenerate|i:1752227285;'),('rsf1pd2678n5417sgnmaq1tbj8npjlcs','82.29.165.22',1752432904,'__ci_last_regenerate|i:1752432904;'),('ru5mf030gacp9a2ldk2ji2dstgj1m50t','82.29.165.22',1752501304,'__ci_last_regenerate|i:1752501304;'),('rvv0fpruj6cddll932lgsnqaa4q38jb5','82.29.165.22',1752171845,'__ci_last_regenerate|i:1752171845;'),('s02k6nltuog2pniqqn0nlalpb8k9jcg9','82.29.165.22',1752087666,'__ci_last_regenerate|i:1752087665;'),('s0ctu5dojk1bb82hoiej7cicuuae3eqh','82.29.165.22',1752339064,'__ci_last_regenerate|i:1752339064;'),('s0u93j5fjrs8iu8vc331kuooci9t4lht','82.29.165.22',1752069484,'__ci_last_regenerate|i:1752069484;'),('s18l03gfj4ejik394qd4ukaf66tpvrl3','82.29.165.22',1752262145,'__ci_last_regenerate|i:1752262144;'),('s1q05dlqmvls9j8fsj66jn5jap0cmlgl','82.29.165.22',1752482825,'__ci_last_regenerate|i:1752482824;'),('s45f5esofqm0teg0sm9n4optsupebevi','82.29.165.22',1752321008,'__ci_last_regenerate|i:1752321006;'),('s46s3l9of9t9u8ejne3u9m9ff9lle5ck','82.29.165.22',1752415209,'__ci_last_regenerate|i:1752415207;'),('s48tkonuhop7fker3onoqojcv77210e3','82.29.165.22',1752274924,'__ci_last_regenerate|i:1752274924;'),('s4nq1luiam4va6c7g7j7p9aau9o9a8si','82.29.165.22',1752341524,'__ci_last_regenerate|i:1752341524;'),('s5615b1tkfpohgih7ajunvj5ti7bl6es','82.29.165.22',1752057727,'__ci_last_regenerate|i:1752057726;'),('s5qsau26blj1vi0ehb7inuhdcvibbj8d','82.29.165.22',1752114063,'__ci_last_regenerate|i:1752114063;'),('s63ubhjtsprfcabu1vack9ade07jf347','82.29.165.22',1752408846,'__ci_last_regenerate|i:1752408845;'),('s7l0bgv0d4461dkacm6ksojh55rnilv6','82.29.165.22',1752404226,'__ci_last_regenerate|i:1752404226;'),('s8a4gqnvmnik6cctu9dd2ltqgha9t3ce','82.29.165.22',1752429066,'__ci_last_regenerate|i:1752429065;'),('s8cn4nrfirkatmslee49tio37fbq7oj6','82.29.165.22',1752369004,'__ci_last_regenerate|i:1752369004;'),('s9ido2j93r7bmtf7oojio0ro9m8r5lj8','82.29.165.22',1752427025,'__ci_last_regenerate|i:1752427025;'),('s9m1o3a0eb9d1hi3girish8e7tkae2ku','82.29.165.22',1752333545,'__ci_last_regenerate|i:1752333545;'),('sa3857m01s24946i9967kf0ba1js1tt8','82.29.165.22',1752165127,'__ci_last_regenerate|i:1752165126;'),('saqputf750aosk4rqkspe50pspkc8b7l','82.29.165.22',1752211086,'__ci_last_regenerate|i:1752211085;'),('sc0d3qae20nomoi81erg6i1maije00q8','82.29.165.22',1752463206,'__ci_last_regenerate|i:1752463205;'),('scdpnjjll8brndad74kkv65qq1actln7','82.29.165.22',1752189605,'__ci_last_regenerate|i:1752189604;'),('scjin612c0l629qeesrjot0iboe9rgu3','82.29.165.22',1752100747,'__ci_last_regenerate|i:1752100746;'),('sdd2usg25v3u8faan00re9jfotge32h7','82.29.165.22',1752342245,'__ci_last_regenerate|i:1752342245;'),('sdhdj2hkg9brq17j4vtianltsr99hltq','82.29.165.22',1752114426,'__ci_last_regenerate|i:1752114425;'),('se2480rm7c9kgi4sb8l798tkaqb97iqv','82.29.165.22',1752206226,'__ci_last_regenerate|i:1752206225;'),('sg7tcqmeabikr5pe16lsjf8uhu28qm4i','82.29.165.22',1752363785,'__ci_last_regenerate|i:1752363784;'),('sgl2sqohbkvcb7mp04naor3it3asvs8q','82.29.165.22',1752485646,'__ci_last_regenerate|i:1752485645;'),('sig8le4kuii0un7c091oj1hmt640s8sm','82.29.165.22',1752162247,'__ci_last_regenerate|i:1752162245;'),('sj453jbhl3uol91kv9frp0eto18b661o','82.29.165.22',1752378724,'__ci_last_regenerate|i:1752378724;'),('ske35nhm7t6kmtmm8qm00fbhajspktki','82.29.165.22',1752288425,'__ci_last_regenerate|i:1752288424;'),('skvvhce01445jq793j4dr1gre54v53m0','82.29.165.22',1752377345,'__ci_last_regenerate|i:1752377344;'),('sllbu3mm7tmvi236ck25s7s1dnuok1l1','82.29.165.22',1752525125,'__ci_last_regenerate|i:1752525124;'),('smcooodg591dvp2mbqukdgn5c73skb99','82.29.165.22',1752227647,'__ci_last_regenerate|i:1752227646;'),('smgarhe3aank3enunjcp1fnq7cuuhsoq','82.29.165.22',1752474005,'__ci_last_regenerate|i:1752474005;'),('smsqhgj6imna4q0n7upfgrea928dqbu1','82.29.165.22',1752257525,'__ci_last_regenerate|i:1752257524;'),('snn5kegv85c677rcj9as0g68hlph2rrc','82.29.165.22',1752064324,'__ci_last_regenerate|i:1752064324;'),('sor4gmfoltm79v2qdak3gothrmtnm64q','82.29.165.22',1752292925,'__ci_last_regenerate|i:1752292924;'),('sosf3hgcds7jts0ovpfi2gt7t0cumvo6','82.29.165.22',1752222366,'__ci_last_regenerate|i:1752222365;'),('spa4e964cgvfdpj34o2cs5uhhqgvli1h','82.29.165.22',1752225846,'__ci_last_regenerate|i:1752225845;'),('spdfee4f5695bfblp9b54a4ehu84g12r','82.29.165.22',1752155646,'__ci_last_regenerate|i:1752155645;'),('spebmslamlncnt86ud27dd38in7a80o4','82.29.165.22',1752379807,'__ci_last_regenerate|i:1752379806;'),('sqlg5isuot9t0jt2dqbcidjb8069gekp','82.29.165.22',1752259984,'__ci_last_regenerate|i:1752259984;'),('ss3q993cn0vafea3hg3dmndisd41a5b4','82.29.165.22',1752121206,'__ci_last_regenerate|i:1752121205;'),('ssmoucb7gpjrrs32dga1j6vc72m1t2qg','82.29.165.22',1752086945,'__ci_last_regenerate|i:1752086944;'),('stkhagueupaf4de4jm1bb1i7rt7hcnbs','82.29.165.22',1752331148,'__ci_last_regenerate|i:1752331147;'),('sucmh0uvv8621qd67no04si8hbhr8adi','82.29.165.22',1752212529,'__ci_last_regenerate|i:1752212527;'),('suldv20eq3j8rhmjenblmh7p6mev43nq','82.29.165.22',1752083345,'__ci_last_regenerate|i:1752083344;'),('svhplplup9gede3oc5sp5qdekeb3stvr','82.29.165.22',1752134468,'__ci_last_regenerate|i:1752134467;'),('svi86srfb7unemqqr02dm2fpnlvk33vd','82.29.165.22',1752447065,'__ci_last_regenerate|i:1752447064;'),('t03sn9itfo830f17b76mn1hb875ndav6','82.29.165.22',1752173285,'__ci_last_regenerate|i:1752173284;'),('t099u8o9dq581ob1bapchgco7cjm1ee2','110.172.155.237',1752050341,'__ci_last_regenerate|i:1752050341;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;'),('t1cdlc2lki57911qkuicsmohgq3a9bhe','82.29.165.22',1752198485,'__ci_last_regenerate|i:1752198484;'),('t1sedt2aka23tqtf4b07v6bt0oi3kcqb','82.29.165.22',1752467409,'__ci_last_regenerate|i:1752467407;'),('t2dt2ktqchkhqrk1s4mhjpq3257ejf35','82.29.165.22',1752523386,'__ci_last_regenerate|i:1752523385;'),('t3vb9td4136uta1dm7g3udgtqjn1sepb','82.29.165.22',1752288066,'__ci_last_regenerate|i:1752288065;'),('t4o9slj6ou5fs01qphjkchafvhbmrcdr','82.29.165.22',1752160446,'__ci_last_regenerate|i:1752160445;'),('t58g8dlljsk9et6k8elikl2i9lpcmg12','82.29.165.22',1752304087,'__ci_last_regenerate|i:1752304086;'),('t66apc4ma3ud1gueqhsekq25optjmu79','82.29.165.22',1752133744,'__ci_last_regenerate|i:1752133744;'),('t6qa2b1vhotvd50qpe6smfr6cs9ivkeo','82.29.165.22',1752109925,'__ci_last_regenerate|i:1752109924;'),('t6rogpdgtovk9oh34a16qq78po9bj1a3','82.29.165.22',1752054905,'__ci_last_regenerate|i:1752054905;'),('t780cphbp1ctrk244vl6v37fufoshsj6','82.29.165.22',1752134826,'__ci_last_regenerate|i:1752134825;'),('t7fumkbu150og2s82of4lo9mf3htrmiv','82.29.165.22',1752456785,'__ci_last_regenerate|i:1752456784;'),('t8opstpd6qq5f6dkip2ckpsgavlbupvm','82.29.165.22',1752270365,'__ci_last_regenerate|i:1752270364;'),('t8osbbhse20he1bum3164hbiikudsv8f','82.29.165.22',1752265385,'__ci_last_regenerate|i:1752265384;'),('t8rgj3i8shenrsrmurtojrra7h1pm2mn','82.29.165.22',1752439265,'__ci_last_regenerate|i:1752439264;'),('t8tsng7rd8ns8dlj5oh7os7kc1ohegnl','82.29.165.22',1752498906,'__ci_last_regenerate|i:1752498905;'),('tacbk86d4vle6t57ctrntg63hm1k4t20','82.29.165.22',1752279066,'__ci_last_regenerate|i:1752279065;'),('tatc1o72al46trkgfjfavd1ei8o7v076','82.29.165.22',1752123304,'__ci_last_regenerate|i:1752123304;'),('tb862oq76nb9tb3fj5ecb2umpadfbtvd','82.29.165.22',1752092225,'__ci_last_regenerate|i:1752092224;'),('tb9van5bbc74ndnqd2npj492a8c2m2jv','82.29.165.22',1752430148,'__ci_last_regenerate|i:1752430147;'),('tcl7t49lblacv1ojne4if2nivr2969k3','82.29.165.22',1752191045,'__ci_last_regenerate|i:1752191044;'),('temsn0vqoenvb1nrcaeubvn84bu8inef','82.29.165.22',1752253687,'__ci_last_regenerate|i:1752253686;'),('tf685khmv9n8ua85m9k14brg4ppo64pr','49.36.189.194',1752059611,'__ci_last_regenerate|i:1752059611;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;'),('tib1b9m40ibsqu2l40k5tdvuur4jvnr1','82.29.165.22',1752156307,'__ci_last_regenerate|i:1752156306;'),('tlqa9fq5utqtslgif7o4d3vtvi2uhoqe','82.29.165.22',1752283565,'__ci_last_regenerate|i:1752283564;'),('tmb53nb4kdhqks1mc5vbguq9cmtd3fof','82.29.165.22',1752131284,'__ci_last_regenerate|i:1752131284;'),('tmc8ej6bd9g4smc35du42orcn39i3l4d','82.29.165.22',1752351065,'__ci_last_regenerate|i:1752351064;'),('tmhqphqn9uvjb0690083avbn3acnaprl','82.29.165.22',1752212167,'__ci_last_regenerate|i:1752212165;'),('tmpg11qfrh61bdnudvici79ik7rdtn6g','82.29.165.22',1752397265,'__ci_last_regenerate|i:1752397264;'),('to63tk7jid9nfjaq6rkvq9b964b85mkd','82.29.165.22',1752162966,'__ci_last_regenerate|i:1752162965;'),('tohkh3t5q2epe69j90del7b2shlji787','82.29.165.22',1752367623,'__ci_last_regenerate|i:1752367623;'),('toqpmtht7scduvltt98u1pq5jt8lnrcn','110.172.155.237',1752050946,'__ci_last_regenerate|i:1752050946;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;'),('toud0nlrblv72hgeajptl943jofasatr','82.29.165.22',1752492609,'__ci_last_regenerate|i:1752492607;'),('tqfpi2detooncfp741e2d8fdt4cedlsm','82.29.165.22',1752230825,'__ci_last_regenerate|i:1752230825;'),('tt0n4o4q6cp0o7v9csrom5s2s91s8euf','82.29.165.22',1752188583,'__ci_last_regenerate|i:1752188583;'),('tt10hg7e97lq1roa3aj4vr99ovd3dkhn','82.29.165.22',1752273546,'__ci_last_regenerate|i:1752273545;'),('tt8bofclmc5h8qu0ilpsj1q7bglhpg8t','82.29.165.22',1752455105,'__ci_last_regenerate|i:1752455104;'),('tt8t1dprpavkgbrkblg8akmt8futrhnm','82.29.165.22',1752306966,'__ci_last_regenerate|i:1752306965;'),('tuaaj4tl8uv5il1dmfq7ofja6kn0pq5h','82.29.165.22',1752224166,'__ci_last_regenerate|i:1752224165;'),('tuhcd5crt4abhvd6u8pfpca5tpf1873l','82.29.165.22',1752174366,'__ci_last_regenerate|i:1752174365;'),('tunkqelea4jp4g82nedrcn1mnhnjqbe1','82.29.165.22',1752277685,'__ci_last_regenerate|i:1752277684;'),('u0fgp7nbd3bqouhosvubab57bo8t4d2e','82.29.165.22',1752194885,'__ci_last_regenerate|i:1752194884;'),('u0k2qidjs3jijng83m5oaa410vblire2','82.29.165.22',1752112745,'__ci_last_regenerate|i:1752112744;'),('u0qob6ovirnvt760nhj694duqd5rhp5q','122.173.125.91',1752341722,'__ci_last_regenerate|i:1752341720;is_mobile|b:1;red_url|s:30:\"https://himalay.techdotbit.in/\";'),('u0svboaojunf7rmvinu57ue5v5h428gj','82.29.165.22',1752387067,'__ci_last_regenerate|i:1752387066;'),('u1brqv13286tj39kheff0c1laoahjeur','49.36.189.194',1752065758,'__ci_last_regenerate|i:1752065739;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;'),('u1spto6967tenkkjj2vvvtoa7tsi45hg','82.29.165.22',1752046285,'__ci_last_regenerate|i:1752046271;'),('u300ak7nddl5g1nlb5drcvt9ib2oqtde','82.29.165.22',1752487327,'__ci_last_regenerate|i:1752487326;'),('u3ie623sku8a4f6lfjg6id2607l9f58a','82.29.165.22',1752260345,'__ci_last_regenerate|i:1752260344;'),('u3q4g3f7c9lok91uifurciso5bhgasci','82.29.165.22',1752477846,'__ci_last_regenerate|i:1752477845;'),('u447ok0m4t1j41v0l5q7v170umf3ub55','82.29.165.22',1752207317,'__ci_last_regenerate|i:1752207310;'),('u4lv93dnrq1iacebrfrbc12i4tjonsch','82.29.165.22',1752236405,'__ci_last_regenerate|i:1752236404;'),('u58vcum9aiv2k80nj7ta5ip1utu8m2nt','82.29.165.22',1752176825,'__ci_last_regenerate|i:1752176824;'),('u5ifv4hefrusobnqqrg9lu1mccf5rgta','82.29.165.22',1752464285,'__ci_last_regenerate|i:1752464284;'),('u7uaj3civl1gkd2ilmlso5kh1epm0a9i','82.29.165.22',1752250807,'__ci_last_regenerate|i:1752250806;'),('u90138qu16h3dijshiuvcamb4f6qlmok','82.29.165.22',1752222726,'__ci_last_regenerate|i:1752222725;'),('u92h1l6083hnerula2ror5epv2kstr2q','82.29.165.22',1752076384,'__ci_last_regenerate|i:1752076384;'),('u941sn6uke42ibjsp17kh72ltsh3ckov','82.29.165.22',1752360665,'__ci_last_regenerate|i:1752360664;'),('u9vj8kda0hr9ijfhg6i6ppr29m2tktcv','82.29.165.22',1752362465,'__ci_last_regenerate|i:1752362464;'),('uaibfdls6j6jl0p1921ufflmn6jmsd7i','82.29.165.22',1752322687,'__ci_last_regenerate|i:1752322685;'),('uaja2i049n0lmqq3i2mrtfi9bhfpf3hq','82.29.165.22',1752362105,'__ci_last_regenerate|i:1752362104;'),('ucgau5l8egn1ffm54nrea9k4cb3t9p4v','82.29.165.22',1752314284,'__ci_last_regenerate|i:1752314284;'),('ui19n84n47qt66m7nj71eh5f2lvvr4sj','82.29.165.22',1752154926,'__ci_last_regenerate|i:1752154925;'),('ui9mmmn3lmg9bcg6mqhnrghf4mjbm1at','82.29.165.22',1752333906,'__ci_last_regenerate|i:1752333905;'),('uigrinjskt9a2bbv5egjpif57qu9hvot','82.29.165.22',1752145751,'__ci_last_regenerate|i:1752145749;'),('uipe5m07f1jen95em13v5l0vg1ht3hts','82.29.165.22',1752484987,'__ci_last_regenerate|i:1752484985;'),('uj00b1kngutqckuf0n1dgne0qv92htro','82.29.165.22',1752489846,'__ci_last_regenerate|i:1752489845;'),('ujg6jff84husos8votdlrq1rg26q41dc','82.29.165.22',1752221348,'__ci_last_regenerate|i:1752221347;'),('ujsflqemk9cg936e5v37uq4gpp4jr5pu','82.29.165.22',1752445983,'__ci_last_regenerate|i:1752445983;'),('uk74tn77ktkmo45qqjjevj7hp9fiq73u','82.29.165.22',1752327366,'__ci_last_regenerate|i:1752327365;'),('ukaa5m1as6pq8pqc6mt96si6opkqk7iu','82.29.165.22',1752120485,'__ci_last_regenerate|i:1752120484;'),('ukatae2kea668mcv8s1lnapjt1c00nks','82.29.165.22',1752200645,'__ci_last_regenerate|i:1752200644;'),('ulckqkr7mb8ge8549v1hg1kvo6bkp2n3','82.29.165.22',1752104944,'__ci_last_regenerate|i:1752104944;'),('unb16lekicaoe27kqjk19cl35m2mg1qj','82.29.165.22',1752115865,'__ci_last_regenerate|i:1752115864;'),('uo6mtdo289vsthgh961jus7nr3hbv7q8','82.29.165.22',1752383646,'__ci_last_regenerate|i:1752383645;'),('uob5koe21601tfj96o370fkvin9nl6qs','82.29.165.22',1752243846,'__ci_last_regenerate|i:1752243845;'),('up8mf5getsm3e2sohuidmlj5g5uahlu5','82.29.165.22',1752180604,'__ci_last_regenerate|i:1752180604;'),('upiobmkk9eann8kk2gh7ne60344bg8tb','82.29.165.22',1752524465,'__ci_last_regenerate|i:1752524464;'),('uq1c422g1jf2gvosop5dh59clpvr68p7','82.29.165.22',1752278432,'__ci_last_regenerate|i:1752278428;'),('urbcr6k539vhd60cfq02pm3bt0v2i7nb','82.29.165.22',1752446706,'__ci_last_regenerate|i:1752446704;'),('uteuf35f946766a86jvo205ss6hqg2sf','82.29.165.22',1752308346,'__ci_last_regenerate|i:1752308345;'),('uvj79b7pojo0jc2cmgjolnhq8s199vtt','82.29.165.22',1752379086,'__ci_last_regenerate|i:1752379085;'),('v08r7njjqv2rsilk1qvg6ifoutel3hvj','82.29.165.22',1752181325,'__ci_last_regenerate|i:1752181324;'),('v0c5u1o2jp9rtitfbe25he8tn6qg5d2d','82.29.165.22',1752088385,'__ci_last_regenerate|i:1752088384;'),('v0er51npj12k9dnpl1hb75i34d51heu8','82.29.165.22',1752231907,'__ci_last_regenerate|i:1752231906;'),('v0pd954om13bgrigi0odt8uqsg832adm','82.29.165.22',1752084066,'__ci_last_regenerate|i:1752084065;'),('v106jss076k9s8aqupuhjfpsuppmfov2','152.58.131.193',1752055035,'__ci_last_regenerate|i:1752055035;is_mobile|b:1;staff_user_id|s:1:\"2\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";'),('v119ga6nihq76kddnblu6op9hp8naim1','82.29.165.22',1752316749,'__ci_last_regenerate|i:1752316748;'),('v18ke87us2l7ccqpi70gaujvg3am5aeg','82.29.165.22',1752238565,'__ci_last_regenerate|i:1752238564;'),('v2ccuag3ho8j5r7hllc009dqr3he2i7k','82.29.165.22',1752494767,'__ci_last_regenerate|i:1752494765;'),('v2g68e5dsd2tjjb9ja7uu519smrlb4vb','82.29.165.22',1752217145,'__ci_last_regenerate|i:1752217144;'),('v3o7at75mrsn65ct6v6sc7mr5a5sqq7l','82.29.165.22',1752191765,'__ci_last_regenerate|i:1752191764;'),('v42p638of2rohvt8h6hlgrjprvl4fnqs','82.29.165.22',1752076085,'__ci_last_regenerate|i:1752076084;'),('v6bcmm4dmtbfgvfog3dcd5u1q78ov5mn','82.29.165.22',1752319924,'__ci_last_regenerate|i:1752319924;'),('v6qncn312n6dqnd4rn9b86l1igmqot01','82.29.165.22',1752221707,'__ci_last_regenerate|i:1752221706;'),('v8uhtukv76v223uu8hdgfb0atqvh400r','82.29.165.22',1752445685,'__ci_last_regenerate|i:1752445684;'),('v9ms3lnmt73vdcapk75qri2mhv56hupi','82.29.165.22',1752055626,'__ci_last_regenerate|i:1752055625;'),('vb8v8mf38esarrnk8nt941rmelc8u6ei','82.29.165.22',1752095765,'__ci_last_regenerate|i:1752095764;'),('vcc4pkp9vtu8h40nhi6jb7s1tnbvkbio','82.29.165.22',1752116225,'__ci_last_regenerate|i:1752116225;'),('vd5q31nkm5dgrpk8vdg6tkguuruebmhq','82.29.165.22',1752048127,'__ci_last_regenerate|i:1752048125;'),('vdc18vfo46a85vae5f4cioqqbh5u266r','82.29.165.22',1752332526,'__ci_last_regenerate|i:1752332525;'),('ve7hbbq1l4iievtmtjnhc8pf6hv0ipnk','82.29.165.22',1752071526,'__ci_last_regenerate|i:1752071525;'),('ved099104c38ndaiv1tgd3fde4vmtk0a','82.29.165.22',1752055985,'__ci_last_regenerate|i:1752055984;'),('vf77ujkrrmhs9lnjl9j00v2hu2ok7f2p','82.29.165.22',1752328745,'__ci_last_regenerate|i:1752328744;'),('vg00vbcneicheuk9e0632md7kcij2d7r','82.29.165.22',1752364505,'__ci_last_regenerate|i:1752364504;'),('vgv8eh0h5hfa06dqluhmq90cca4hfj86','82.29.165.22',1752291547,'__ci_last_regenerate|i:1752291545;'),('vh5l7rb6dmh4la1udna22n2ruiqbae9j','82.29.165.22',1752140466,'__ci_last_regenerate|i:1752140465;'),('vhdps929pl8aqo6s28ki4ivjpjg3re8e','82.29.165.22',1752420005,'__ci_last_regenerate|i:1752420005;'),('vhlgv8eu2g8hdmr71mgt0964abv3fs4s','82.29.165.22',1752179947,'__ci_last_regenerate|i:1752179946;'),('vivvfc6oblci3dknkalrvvrefd6jrb5j','82.29.165.22',1752128108,'__ci_last_regenerate|i:1752128106;'),('vj4lfl34mseg79iveh227ragledmsbl2','152.58.131.122',1752059886,'__ci_last_regenerate|i:1752059881;is_mobile|b:1;staff_user_id|s:1:\"2\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";'),('vjp1d9e8p8gs54j5dmoje7qi0n61rkfj','82.29.165.22',1752384304,'__ci_last_regenerate|i:1752384304;'),('vl4uca406mca99lnj9ev428ebmcimb0a','82.29.165.22',1752510908,'__ci_last_regenerate|i:1752510906;'),('vlbnjetqnnmok79rkbblqla1othkln5a','82.29.165.22',1752285966,'__ci_last_regenerate|i:1752285965;'),('vmkdqk87mgkjjdh7kfs53ggcsm5c1aii','82.29.165.22',1752262506,'__ci_last_regenerate|i:1752262505;'),('vml2bd7j769v7e5gqpf6a3aipp4o5obk','82.29.165.22',1752494415,'__ci_last_regenerate|i:1752494412;'),('vnt83ah88ogv9ift3c7v7ufu3a9pj4in','82.29.165.22',1752209284,'__ci_last_regenerate|i:1752209284;'),('vou51804gofq6194p7uurcss6n4tjfhk','82.29.165.22',1752231546,'__ci_last_regenerate|i:1752231545;'),('vphsdkkst9q0hec5orj2hd2orge5s59d','82.29.165.22',1752211447,'__ci_last_regenerate|i:1752211446;'),('vq0pumjh6sh7ofi38b4h8h5f4tubs8r0','82.29.165.22',1752079505,'__ci_last_regenerate|i:1752079504;'),('vq936sprar77rmto7627dcval857sdc4','82.29.165.22',1752311824,'__ci_last_regenerate|i:1752311824;'),('vqu30dojcs1gi363schdvgkefgiv48au','82.29.165.22',1752302349,'__ci_last_regenerate|i:1752302348;'),('vtofkv24bp06jphsauugv6gh9j0io93d','82.29.165.22',1752454744,'__ci_last_regenerate|i:1752454743;'),('vu5t4c9u25sl4can0febh7fq7m9ulb3v','82.29.165.22',1752269285,'__ci_last_regenerate|i:1752269284;'),('vv6i10tlbp7vp35osrjed8jgohegd4r0','82.29.165.22',1752238208,'__ci_last_regenerate|i:1752238206;'),('vvlbftjgi867p2io6f1eq209k9a8m5pb','82.29.165.22',1752351364,'__ci_last_regenerate|i:1752351363;');
/*!40000 ALTER TABLE `himalay_tblsessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblsetting_asset_allocation`
--

DROP TABLE IF EXISTS `himalay_tblsetting_asset_allocation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblsetting_asset_allocation` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) DEFAULT NULL,
  `meta` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblsetting_asset_allocation`
--

LOCK TABLES `himalay_tblsetting_asset_allocation` WRITE;
/*!40000 ALTER TABLE `himalay_tblsetting_asset_allocation` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblsetting_asset_allocation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblsetting_training`
--

DROP TABLE IF EXISTS `himalay_tblsetting_training`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblsetting_training` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `training_type` int(11) NOT NULL,
  `position_training` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblsetting_training`
--

LOCK TABLES `himalay_tblsetting_training` WRITE;
/*!40000 ALTER TABLE `himalay_tblsetting_training` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblsetting_training` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblsetting_transfer_records`
--

DROP TABLE IF EXISTS `himalay_tblsetting_transfer_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblsetting_transfer_records` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) DEFAULT NULL,
  `meta` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblsetting_transfer_records`
--

LOCK TABLES `himalay_tblsetting_transfer_records` WRITE;
/*!40000 ALTER TABLE `himalay_tblsetting_transfer_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblsetting_transfer_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblshared_customer_files`
--

DROP TABLE IF EXISTS `himalay_tblshared_customer_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblshared_customer_files` (
  `file_id` int(11) NOT NULL,
  `contact_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblshared_customer_files`
--

LOCK TABLES `himalay_tblshared_customer_files` WRITE;
/*!40000 ALTER TABLE `himalay_tblshared_customer_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblshared_customer_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblshift_type`
--

DROP TABLE IF EXISTS `himalay_tblshift_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblshift_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shift_type_name` varchar(150) DEFAULT NULL,
  `color` varchar(50) DEFAULT NULL,
  `time_start` date DEFAULT NULL,
  `time_end` date DEFAULT NULL,
  `time_start_work` varchar(50) DEFAULT NULL,
  `time_end_work` varchar(50) DEFAULT NULL,
  `start_lunch_break_time` varchar(50) DEFAULT NULL,
  `end_lunch_break_time` varchar(50) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblshift_type`
--

LOCK TABLES `himalay_tblshift_type` WRITE;
/*!40000 ALTER TABLE `himalay_tblshift_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblshift_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblsi_custom_status`
--

DROP TABLE IF EXISTS `himalay_tblsi_custom_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblsi_custom_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '',
  `order` int(11) NOT NULL DEFAULT 0,
  `color` varchar(7) NOT NULL DEFAULT '#757575',
  `filter_default` int(11) NOT NULL DEFAULT 0,
  `relto` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=200 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblsi_custom_status`
--

LOCK TABLES `himalay_tblsi_custom_status` WRITE;
/*!40000 ALTER TABLE `himalay_tblsi_custom_status` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblsi_custom_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblsi_custom_status_default`
--

DROP TABLE IF EXISTS `himalay_tblsi_custom_status_default`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblsi_custom_status_default` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status_id` int(11) NOT NULL DEFAULT 0,
  `name` varchar(50) NOT NULL DEFAULT '',
  `order` int(11) NOT NULL DEFAULT 0,
  `color` varchar(7) NOT NULL DEFAULT '#757575',
  `filter_default` int(11) NOT NULL DEFAULT 0,
  `active` int(11) NOT NULL DEFAULT 1,
  `relto` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblsi_custom_status_default`
--

LOCK TABLES `himalay_tblsi_custom_status_default` WRITE;
/*!40000 ALTER TABLE `himalay_tblsi_custom_status_default` DISABLE KEYS */;
INSERT INTO `himalay_tblsi_custom_status_default` VALUES (1,1,'',1,'#64748b',1,1,'tasks'),(2,2,'',4,'#84cc16',1,1,'tasks'),(3,3,'',3,'#0284c7',1,1,'tasks'),(4,4,'',2,'#3b82f6',1,1,'tasks'),(5,5,'',100,'#22c55e',0,1,'tasks'),(6,1,'',1,'#475569',1,1,'projects'),(7,2,'',2,'#2563eb',1,1,'projects'),(8,3,'',3,'#f97316',1,1,'projects'),(9,4,'',100,'#16a34a',0,1,'projects'),(10,5,'',4,'#94a3b8',0,1,'projects');
/*!40000 ALTER TABLE `himalay_tblsi_custom_status_default` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblsi_lead_followup_schedule`
--

DROP TABLE IF EXISTS `himalay_tblsi_lead_followup_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblsi_lead_followup_schedule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `source` int(11) NOT NULL DEFAULT 0,
  `filter_by` varchar(25) NOT NULL,
  `content` text NOT NULL,
  `dlt_template_id_key` varchar(100) NOT NULL DEFAULT '',
  `dlt_template_id_value` varchar(100) NOT NULL DEFAULT '',
  `staff_id` int(11) NOT NULL DEFAULT 0,
  `schedule_days` int(11) NOT NULL DEFAULT 1,
  `schedule_hour` int(11) NOT NULL DEFAULT 12,
  `last_executed` datetime DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `staff_id` (`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblsi_lead_followup_schedule`
--

LOCK TABLES `himalay_tblsi_lead_followup_schedule` WRITE;
/*!40000 ALTER TABLE `himalay_tblsi_lead_followup_schedule` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblsi_lead_followup_schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblsi_lead_followup_schedule_rel`
--

DROP TABLE IF EXISTS `himalay_tblsi_lead_followup_schedule_rel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblsi_lead_followup_schedule_rel` (
  `schedule_id` int(11) NOT NULL DEFAULT 0,
  `rel_id` int(11) NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  KEY `schedule_id` (`schedule_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblsi_lead_followup_schedule_rel`
--

LOCK TABLES `himalay_tblsi_lead_followup_schedule_rel` WRITE;
/*!40000 ALTER TABLE `himalay_tblsi_lead_followup_schedule_rel` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblsi_lead_followup_schedule_rel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblspam_filters`
--

DROP TABLE IF EXISTS `himalay_tblspam_filters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblspam_filters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(40) NOT NULL,
  `rel_type` varchar(10) NOT NULL,
  `value` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblspam_filters`
--

LOCK TABLES `himalay_tblspam_filters` WRITE;
/*!40000 ALTER TABLE `himalay_tblspam_filters` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblspam_filters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblstaff`
--

DROP TABLE IF EXISTS `himalay_tblstaff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblstaff` (
  `staffid` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `facebook` longtext DEFAULT NULL,
  `linkedin` longtext DEFAULT NULL,
  `phonenumber` varchar(30) DEFAULT NULL,
  `skype` varchar(50) DEFAULT NULL,
  `password` varchar(250) NOT NULL,
  `datecreated` datetime NOT NULL,
  `profile_image` varchar(191) DEFAULT NULL,
  `last_ip` varchar(40) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_activity` datetime DEFAULT NULL,
  `last_password_change` datetime DEFAULT NULL,
  `new_pass_key` varchar(32) DEFAULT NULL,
  `new_pass_key_requested` datetime DEFAULT NULL,
  `admin` int(11) NOT NULL DEFAULT 0,
  `role` int(11) DEFAULT NULL,
  `active` int(11) NOT NULL DEFAULT 1,
  `default_language` varchar(40) DEFAULT NULL,
  `direction` varchar(3) DEFAULT NULL,
  `media_path_slug` varchar(191) DEFAULT NULL,
  `is_not_staff` int(11) NOT NULL DEFAULT 0,
  `hourly_rate` decimal(15,2) NOT NULL DEFAULT 0.00,
  `two_factor_auth_enabled` tinyint(1) DEFAULT 0,
  `two_factor_auth_code` varchar(100) DEFAULT NULL,
  `two_factor_auth_code_requested` datetime DEFAULT NULL,
  `email_signature` mediumtext DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `birthplace` varchar(200) DEFAULT NULL,
  `sex` varchar(15) DEFAULT NULL,
  `marital_status` varchar(25) DEFAULT NULL,
  `nation` varchar(25) DEFAULT NULL,
  `religion` varchar(50) DEFAULT NULL,
  `identification` varchar(100) DEFAULT NULL,
  `days_for_identity` date DEFAULT NULL,
  `home_town` varchar(200) DEFAULT NULL,
  `resident` varchar(200) DEFAULT NULL,
  `current_address` varchar(200) DEFAULT NULL,
  `literacy` varchar(50) DEFAULT NULL,
  `orther_infor` text DEFAULT NULL,
  `job_position` int(11) DEFAULT NULL,
  `workplace` int(11) DEFAULT NULL,
  `place_of_issue` varchar(50) DEFAULT NULL,
  `account_number` varchar(50) DEFAULT NULL,
  `name_account` varchar(50) DEFAULT NULL,
  `issue_bank` varchar(200) DEFAULT NULL,
  `records_received` longtext DEFAULT NULL,
  `Personal_tax_code` varchar(50) DEFAULT NULL,
  `google_auth_secret` mediumtext DEFAULT NULL,
  `team_manage` int(11) DEFAULT 0,
  `staff_identifi` varchar(200) DEFAULT NULL,
  `status_work` varchar(100) DEFAULT NULL,
  `date_update` date DEFAULT NULL,
  `epf_no` text DEFAULT NULL,
  `social_security_no` text DEFAULT NULL,
  `mail_password` varchar(250) DEFAULT NULL,
  `mail_signature` varchar(250) DEFAULT NULL,
  `last_email_check` varchar(50) DEFAULT NULL,
  `token` varchar(255) DEFAULT NULL,
  `date_of_joining` date DEFAULT NULL,
  `pan_no` varchar(20) DEFAULT NULL,
  `uan_no` varchar(20) DEFAULT NULL,
  `mother_name` varchar(100) DEFAULT NULL,
  `father_name` varchar(100) DEFAULT NULL,
  `ho_wo_name` varchar(100) DEFAULT NULL,
  `ifsc_code` varchar(20) DEFAULT NULL,
  `account_type` varchar(50) DEFAULT NULL,
  `disability_type` varchar(100) DEFAULT NULL,
  `adhar_no` varchar(20) DEFAULT NULL,
  `esi_insurance_no` varchar(20) DEFAULT NULL,
  `esi_enable` tinyint(1) DEFAULT 0,
  `epf_enable` tinyint(1) DEFAULT 0,
  `enable_contribute_to_employee_pension_scheme` tinyint(1) DEFAULT 0,
  `contribute_eps_on_actual_pf_wages` tinyint(1) DEFAULT 0,
  `mfa_google_ath_enable` tinyint(1) DEFAULT 0,
  `mfa_whatsapp_enable` tinyint(1) DEFAULT 0,
  `mfa_sms_enable` tinyint(1) DEFAULT 0,
  `whatsapp_number` text DEFAULT '',
  `gg_auth_secret_key` text DEFAULT '',
  `fleet_is_driver` int(11) DEFAULT 0,
  PRIMARY KEY (`staffid`),
  KEY `firstname` (`firstname`),
  KEY `lastname` (`lastname`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblstaff`
--

LOCK TABLES `himalay_tblstaff` WRITE;
/*!40000 ALTER TABLE `himalay_tblstaff` DISABLE KEYS */;
INSERT INTO `himalay_tblstaff` VALUES (1,'md@spliceply.com','faizan','ahmad',NULL,NULL,'+919415692511',NULL,'$2a$08$/WeMutKGXb4RkXqfCsbPWO/JV2oJX1UVxdEHnPrNt.xVY6Hkwru.G','2025-07-09 13:01:06',NULL,'49.36.189.194','2025-07-11 14:55:33','2025-07-11 14:56:12',NULL,NULL,NULL,1,NULL,1,NULL,NULL,NULL,0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,0,0,'','',0),(2,'Musheer@himalayply.com','Musheer','Belal','https://www.facebook.com/share/1BEzK54phh/','','','','$2a$08$o/2FQV1kPB0tnpMjhQy2oOOKZap6rvXMEBbeKfXCORdOX2wthOghK','2025-07-09 13:03:28',NULL,'103.95.164.179','2025-07-10 13:11:49','2025-07-10 13:16:56',NULL,NULL,NULL,1,1,1,'','','musheer-belal',0,0.00,0,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,0,0,'','',0),(3,'Faiz@himalayply.com','Mohd ','Faiz','','','','','$2a$08$FA3pQcPKh9z4WjIAy5f7ZOX9HXiIYzF1GN9F.Qxm74Y7xjNmdSBbO','2025-07-09 13:04:14',NULL,'42.105.212.56','2025-07-09 14:23:05','2025-07-09 14:24:24',NULL,NULL,NULL,1,1,1,'','','mohd-faiz',0,0.00,0,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,0,0,'','',0),(5,'Shafique@himalayply.com','Shafique','Siddiqui','','','9219820188','','$2a$08$gpqy8gzfIHYVKfoNGfl9YuRq43zSPzvvauGif9U6NzJooq8BgPlpa','2025-07-09 14:06:54',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,1,'','','shafique-siddiqui',0,0.00,0,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,0,0,'','',0),(6,'Tauseef@himalayply.com','Tauseef ','Alam','','','7754050130','','$2a$08$Z5b.x4WkiF6NFBPC9/LJcufoWyP6hxvHBi1kjjehSoyqPLrDrqXe6','2025-07-09 14:08:05',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,1,'','','tauseef-alam',0,0.00,0,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,0,0,'','',0),(7,'mahfooz@himalayply.com','Mahfooz','Khan','','','8810793658','','$2a$08$AP/xOt9S4fiJPGxpUxqK5e.7ee.FCrHHvYOKG2r4NcgWKho8Fugpy','2025-07-09 14:10:46',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,1,'','','mahfooz-khan',0,0.00,0,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,0,0,'','',0),(8,'javed@himalayply.com','Javed','Khan','','','9219821085','','$2a$08$X9jpQaIlhrLMJsOEOlS7JuJOVX6gxnc7c0ksfH2uhrXB6ctYrOKPC','2025-07-09 14:12:25',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,1,'','','javed-khan',0,0.00,0,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,0,0,'','',0),(9,'sameer@himalayply.com','Sameer','Ahmed','','','7753940042','','$2a$08$tTMiluNDUbCa4pY7fa3Ah.C54NJNk4hcc9lY8Ys55H.Qm1G9BAio6','2025-07-09 14:13:47',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,1,'','','sameer-ahmed',0,0.00,0,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,0,0,'','',0),(10,'raj@himalayply.com','Raj','Kumar','','','7754050241','','$2a$08$wsiZx0tvjVheh4Fxfrv3iOwYsiKqw63xvFrNjpVZ1j.GYqywboWmm','2025-07-09 14:15:37',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,1,'','','raj-kumar',0,0.00,0,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,0,0,'','',0),(11,'ashish@himalayply.com','Ashish','Kumar','','','7754050077','','$2a$08$OyTbjnKPomuJ9yQr4nbDIOx.uWd7N3Tr61RoSlHPpagWu4kHSW8YS','2025-07-09 14:17:12',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,1,'','','ashish-kumar',0,0.00,0,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,0,0,'','',0),(12,'dilshad@himalayply.com','Dilshad','Khan','','','7754050078','','$2a$08$0deHdttuktumzUdDHyOKbOMQUX/fHHBVUjyscBNJUaEtTTybGoWqW','2025-07-09 14:18:58',NULL,'223.184.153.158','2025-07-10 13:20:04','2025-07-10 18:37:37',NULL,'1bc01ce1bc029e3c34ff9dc37a86ce06','2025-07-10 13:18:36',0,1,1,'','','dilshad-khan',0,0.00,0,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,0,0,'','',0);
/*!40000 ALTER TABLE `himalay_tblstaff` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblstaff_departments`
--

DROP TABLE IF EXISTS `himalay_tblstaff_departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblstaff_departments` (
  `staffdepartmentid` int(11) NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `departmentid` int(11) NOT NULL,
  PRIMARY KEY (`staffdepartmentid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblstaff_departments`
--

LOCK TABLES `himalay_tblstaff_departments` WRITE;
/*!40000 ALTER TABLE `himalay_tblstaff_departments` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblstaff_departments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblstaff_permissions`
--

DROP TABLE IF EXISTS `himalay_tblstaff_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblstaff_permissions` (
  `staff_id` int(11) NOT NULL,
  `feature` varchar(40) NOT NULL,
  `capability` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblstaff_permissions`
--

LOCK TABLES `himalay_tblstaff_permissions` WRITE;
/*!40000 ALTER TABLE `himalay_tblstaff_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblstaff_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblstandard_workload`
--

DROP TABLE IF EXISTS `himalay_tblstandard_workload`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblstandard_workload` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `monday` varchar(45) DEFAULT NULL,
  `tuesday` varchar(45) DEFAULT NULL,
  `wednesday` varchar(45) DEFAULT NULL,
  `thursday` varchar(45) DEFAULT NULL,
  `friday` varchar(45) DEFAULT NULL,
  `saturday` varchar(45) DEFAULT NULL,
  `sunday` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblstandard_workload`
--

LOCK TABLES `himalay_tblstandard_workload` WRITE;
/*!40000 ALTER TABLE `himalay_tblstandard_workload` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblstandard_workload` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblstock_take`
--

DROP TABLE IF EXISTS `himalay_tblstock_take`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblstock_take` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `description` text DEFAULT NULL COMMENT 'the reason stock take',
  `warehouse_id` int(11) DEFAULT NULL,
  `date_stock_take` date DEFAULT NULL,
  `stock_take_code` varchar(100) DEFAULT NULL COMMENT 'số kiểm kê kho',
  `date_add` date DEFAULT NULL,
  `hour_add` date DEFAULT NULL,
  `staff_id` varchar(100) DEFAULT NULL,
  `approval` int(11) DEFAULT 0 COMMENT 'status approval ',
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblstock_take`
--

LOCK TABLES `himalay_tblstock_take` WRITE;
/*!40000 ALTER TABLE `himalay_tblstock_take` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblstock_take` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblstock_take_detail`
--

DROP TABLE IF EXISTS `himalay_tblstock_take_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblstock_take_detail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `stock_take_id` int(11) NOT NULL,
  `commodity_code` varchar(100) DEFAULT NULL,
  `commodity_name` text DEFAULT NULL,
  `unit_id` text DEFAULT NULL,
  `unit_price` varchar(100) DEFAULT NULL,
  `quantity_stock_take` varchar(100) DEFAULT NULL,
  `quantity_accounting_book` varchar(100) DEFAULT NULL,
  `quantity_change` varchar(100) DEFAULT NULL,
  `handling` text DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `approval` int(11) DEFAULT 0 COMMENT 'status approval ',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblstock_take_detail`
--

LOCK TABLES `himalay_tblstock_take_detail` WRITE;
/*!40000 ALTER TABLE `himalay_tblstock_take_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblstock_take_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblsubscriptions`
--

DROP TABLE IF EXISTS `himalay_tblsubscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblsubscriptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `description_in_item` tinyint(1) NOT NULL DEFAULT 0,
  `clientid` int(11) NOT NULL,
  `date` date DEFAULT NULL,
  `terms` mediumtext DEFAULT NULL,
  `currency` int(11) NOT NULL,
  `tax_id` int(11) NOT NULL DEFAULT 0,
  `stripe_tax_id` varchar(50) DEFAULT NULL,
  `tax_id_2` int(11) NOT NULL DEFAULT 0,
  `stripe_tax_id_2` varchar(50) DEFAULT NULL,
  `stripe_plan_id` mediumtext DEFAULT NULL,
  `stripe_subscription_id` mediumtext NOT NULL,
  `next_billing_cycle` bigint(20) DEFAULT NULL,
  `ends_at` bigint(20) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `project_id` int(11) NOT NULL DEFAULT 0,
  `hash` varchar(32) NOT NULL,
  `created` datetime NOT NULL,
  `created_from` int(11) NOT NULL,
  `date_subscribed` datetime DEFAULT NULL,
  `in_test_environment` int(11) DEFAULT NULL,
  `last_sent_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `currency` (`currency`),
  KEY `tax_id` (`tax_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblsubscriptions`
--

LOCK TABLES `himalay_tblsubscriptions` WRITE;
/*!40000 ALTER TABLE `himalay_tblsubscriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblsubscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblsurveyresultsets`
--

DROP TABLE IF EXISTS `himalay_tblsurveyresultsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblsurveyresultsets` (
  `resultsetid` int(11) NOT NULL AUTO_INCREMENT,
  `surveyid` int(11) NOT NULL,
  `ip` varchar(40) NOT NULL,
  `useragent` varchar(150) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`resultsetid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblsurveyresultsets`
--

LOCK TABLES `himalay_tblsurveyresultsets` WRITE;
/*!40000 ALTER TABLE `himalay_tblsurveyresultsets` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblsurveyresultsets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblsurveys`
--

DROP TABLE IF EXISTS `himalay_tblsurveys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblsurveys` (
  `surveyid` int(11) NOT NULL AUTO_INCREMENT,
  `subject` mediumtext NOT NULL,
  `slug` mediumtext NOT NULL,
  `description` text NOT NULL,
  `viewdescription` text DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `redirect_url` varchar(100) DEFAULT NULL,
  `send` tinyint(1) NOT NULL DEFAULT 0,
  `onlyforloggedin` int(11) DEFAULT 0,
  `fromname` varchar(100) DEFAULT NULL,
  `iprestrict` tinyint(1) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `hash` varchar(32) NOT NULL,
  PRIMARY KEY (`surveyid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblsurveys`
--

LOCK TABLES `himalay_tblsurveys` WRITE;
/*!40000 ALTER TABLE `himalay_tblsurveys` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblsurveys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblsurveysemailsendcron`
--

DROP TABLE IF EXISTS `himalay_tblsurveysemailsendcron`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblsurveysemailsendcron` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `surveyid` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `emailid` int(11) DEFAULT NULL,
  `listid` varchar(11) DEFAULT NULL,
  `log_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblsurveysemailsendcron`
--

LOCK TABLES `himalay_tblsurveysemailsendcron` WRITE;
/*!40000 ALTER TABLE `himalay_tblsurveysemailsendcron` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblsurveysemailsendcron` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblsurveysendlog`
--

DROP TABLE IF EXISTS `himalay_tblsurveysendlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblsurveysendlog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `surveyid` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `iscronfinished` int(11) NOT NULL DEFAULT 0,
  `send_to_mail_lists` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblsurveysendlog`
--

LOCK TABLES `himalay_tblsurveysendlog` WRITE;
/*!40000 ALTER TABLE `himalay_tblsurveysendlog` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblsurveysendlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tbltaggables`
--

DROP TABLE IF EXISTS `himalay_tbltaggables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tbltaggables` (
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) NOT NULL,
  `tag_id` int(11) NOT NULL,
  `tag_order` int(11) NOT NULL DEFAULT 0,
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`),
  KEY `tag_id` (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tbltaggables`
--

LOCK TABLES `himalay_tbltaggables` WRITE;
/*!40000 ALTER TABLE `himalay_tbltaggables` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tbltaggables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tbltags`
--

DROP TABLE IF EXISTS `himalay_tbltags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tbltags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tbltags`
--

LOCK TABLES `himalay_tbltags` WRITE;
/*!40000 ALTER TABLE `himalay_tbltags` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tbltags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tbltask_assigned`
--

DROP TABLE IF EXISTS `himalay_tbltask_assigned`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tbltask_assigned` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `taskid` int(11) NOT NULL,
  `assigned_from` int(11) NOT NULL DEFAULT 0,
  `is_assigned_from_contact` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `taskid` (`taskid`),
  KEY `himalay_staffid` (`staffid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tbltask_assigned`
--

LOCK TABLES `himalay_tbltask_assigned` WRITE;
/*!40000 ALTER TABLE `himalay_tbltask_assigned` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tbltask_assigned` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tbltask_checklist_items`
--

DROP TABLE IF EXISTS `himalay_tbltask_checklist_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tbltask_checklist_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `taskid` int(11) NOT NULL,
  `description` mediumtext NOT NULL,
  `finished` int(11) NOT NULL DEFAULT 0,
  `dateadded` datetime NOT NULL,
  `addedfrom` int(11) NOT NULL,
  `finished_from` int(11) DEFAULT 0,
  `list_order` int(11) NOT NULL DEFAULT 0,
  `assigned` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `taskid` (`taskid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tbltask_checklist_items`
--

LOCK TABLES `himalay_tbltask_checklist_items` WRITE;
/*!40000 ALTER TABLE `himalay_tbltask_checklist_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tbltask_checklist_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tbltask_comments`
--

DROP TABLE IF EXISTS `himalay_tbltask_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tbltask_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` mediumtext NOT NULL,
  `taskid` int(11) NOT NULL,
  `staffid` int(11) NOT NULL,
  `contact_id` int(11) NOT NULL DEFAULT 0,
  `file_id` int(11) NOT NULL DEFAULT 0,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `file_id` (`file_id`),
  KEY `taskid` (`taskid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tbltask_comments`
--

LOCK TABLES `himalay_tbltask_comments` WRITE;
/*!40000 ALTER TABLE `himalay_tbltask_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tbltask_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tbltask_followers`
--

DROP TABLE IF EXISTS `himalay_tbltask_followers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tbltask_followers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `taskid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tbltask_followers`
--

LOCK TABLES `himalay_tbltask_followers` WRITE;
/*!40000 ALTER TABLE `himalay_tbltask_followers` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tbltask_followers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tbltasks`
--

DROP TABLE IF EXISTS `himalay_tbltasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tbltasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  `startdate` date NOT NULL,
  `duedate` date DEFAULT NULL,
  `datefinished` datetime DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `is_added_from_contact` tinyint(1) NOT NULL DEFAULT 0,
  `status` int(11) NOT NULL DEFAULT 0,
  `recurring_type` varchar(10) DEFAULT NULL,
  `repeat_every` int(11) DEFAULT NULL,
  `recurring` int(11) NOT NULL DEFAULT 0,
  `is_recurring_from` int(11) DEFAULT NULL,
  `cycles` int(11) NOT NULL DEFAULT 0,
  `total_cycles` int(11) NOT NULL DEFAULT 0,
  `custom_recurring` tinyint(1) NOT NULL DEFAULT 0,
  `last_recurring_date` date DEFAULT NULL,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(30) DEFAULT NULL,
  `is_public` tinyint(1) NOT NULL DEFAULT 0,
  `billable` tinyint(1) NOT NULL DEFAULT 0,
  `billed` tinyint(1) NOT NULL DEFAULT 0,
  `invoice_id` int(11) NOT NULL DEFAULT 0,
  `hourly_rate` decimal(15,2) NOT NULL DEFAULT 0.00,
  `milestone` int(11) DEFAULT 0,
  `kanban_order` int(11) DEFAULT 1,
  `milestone_order` int(11) NOT NULL DEFAULT 0,
  `visible_to_client` tinyint(1) NOT NULL DEFAULT 0,
  `deadline_notified` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`),
  KEY `milestone` (`milestone`),
  KEY `kanban_order` (`kanban_order`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tbltasks`
--

LOCK TABLES `himalay_tbltasks` WRITE;
/*!40000 ALTER TABLE `himalay_tbltasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tbltasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tbltasks_checklist_templates`
--

DROP TABLE IF EXISTS `himalay_tbltasks_checklist_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tbltasks_checklist_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tbltasks_checklist_templates`
--

LOCK TABLES `himalay_tbltasks_checklist_templates` WRITE;
/*!40000 ALTER TABLE `himalay_tbltasks_checklist_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tbltasks_checklist_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tbltaskstimers`
--

DROP TABLE IF EXISTS `himalay_tbltaskstimers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tbltaskstimers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) NOT NULL,
  `start_time` varchar(64) NOT NULL,
  `end_time` varchar(64) DEFAULT NULL,
  `staff_id` int(11) NOT NULL,
  `hourly_rate` decimal(15,2) NOT NULL DEFAULT 0.00,
  `note` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `task_id` (`task_id`),
  KEY `himalay_staff_id` (`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tbltaskstimers`
--

LOCK TABLES `himalay_tbltaskstimers` WRITE;
/*!40000 ALTER TABLE `himalay_tbltaskstimers` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tbltaskstimers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tbltaxes`
--

DROP TABLE IF EXISTS `himalay_tbltaxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tbltaxes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `taxrate` decimal(15,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tbltaxes`
--

LOCK TABLES `himalay_tbltaxes` WRITE;
/*!40000 ALTER TABLE `himalay_tbltaxes` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tbltaxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tbltemplates`
--

DROP TABLE IF EXISTS `himalay_tbltemplates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tbltemplates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `type` varchar(100) NOT NULL,
  `addedfrom` int(11) NOT NULL,
  `content` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tbltemplates`
--

LOCK TABLES `himalay_tbltemplates` WRITE;
/*!40000 ALTER TABLE `himalay_tbltemplates` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tbltemplates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblticket_attachments`
--

DROP TABLE IF EXISTS `himalay_tblticket_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblticket_attachments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticketid` int(11) NOT NULL,
  `replyid` int(11) DEFAULT NULL,
  `file_name` varchar(191) NOT NULL,
  `filetype` varchar(50) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblticket_attachments`
--

LOCK TABLES `himalay_tblticket_attachments` WRITE;
/*!40000 ALTER TABLE `himalay_tblticket_attachments` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblticket_attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblticket_replies`
--

DROP TABLE IF EXISTS `himalay_tblticket_replies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblticket_replies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticketid` int(11) NOT NULL,
  `userid` int(11) DEFAULT NULL,
  `contactid` int(11) NOT NULL DEFAULT 0,
  `name` mediumtext DEFAULT NULL,
  `email` mediumtext DEFAULT NULL,
  `date` datetime NOT NULL,
  `message` mediumtext DEFAULT NULL,
  `attachment` int(11) DEFAULT NULL,
  `admin` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblticket_replies`
--

LOCK TABLES `himalay_tblticket_replies` WRITE;
/*!40000 ALTER TABLE `himalay_tblticket_replies` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblticket_replies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tbltickets`
--

DROP TABLE IF EXISTS `himalay_tbltickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tbltickets` (
  `ticketid` int(11) NOT NULL AUTO_INCREMENT,
  `adminreplying` int(11) NOT NULL DEFAULT 0,
  `userid` int(11) NOT NULL,
  `contactid` int(11) NOT NULL DEFAULT 0,
  `merged_ticket_id` int(11) DEFAULT NULL,
  `email` mediumtext DEFAULT NULL,
  `name` mediumtext DEFAULT NULL,
  `department` int(11) NOT NULL,
  `priority` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `service` int(11) DEFAULT NULL,
  `ticketkey` varchar(32) NOT NULL,
  `subject` varchar(191) NOT NULL,
  `message` mediumtext DEFAULT NULL,
  `admin` int(11) DEFAULT NULL,
  `date` datetime NOT NULL,
  `project_id` int(11) NOT NULL DEFAULT 0,
  `lastreply` datetime DEFAULT NULL,
  `clientread` int(11) NOT NULL DEFAULT 0,
  `adminread` int(11) NOT NULL DEFAULT 0,
  `assigned` int(11) NOT NULL DEFAULT 0,
  `staff_id_replying` int(11) DEFAULT NULL,
  `cc` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`ticketid`),
  KEY `service` (`service`),
  KEY `department` (`department`),
  KEY `status` (`status`),
  KEY `userid` (`userid`),
  KEY `priority` (`priority`),
  KEY `project_id` (`project_id`),
  KEY `contactid` (`contactid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tbltickets`
--

LOCK TABLES `himalay_tbltickets` WRITE;
/*!40000 ALTER TABLE `himalay_tbltickets` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tbltickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tbltickets_pipe_log`
--

DROP TABLE IF EXISTS `himalay_tbltickets_pipe_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tbltickets_pipe_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `email_to` varchar(100) NOT NULL,
  `name` varchar(191) NOT NULL,
  `subject` varchar(191) NOT NULL,
  `message` longtext NOT NULL,
  `email` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tbltickets_pipe_log`
--

LOCK TABLES `himalay_tbltickets_pipe_log` WRITE;
/*!40000 ALTER TABLE `himalay_tbltickets_pipe_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tbltickets_pipe_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tbltickets_predefined_replies`
--

DROP TABLE IF EXISTS `himalay_tbltickets_predefined_replies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tbltickets_predefined_replies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `message` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tbltickets_predefined_replies`
--

LOCK TABLES `himalay_tbltickets_predefined_replies` WRITE;
/*!40000 ALTER TABLE `himalay_tbltickets_predefined_replies` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tbltickets_predefined_replies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tbltickets_priorities`
--

DROP TABLE IF EXISTS `himalay_tbltickets_priorities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tbltickets_priorities` (
  `priorityid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`priorityid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tbltickets_priorities`
--

LOCK TABLES `himalay_tbltickets_priorities` WRITE;
/*!40000 ALTER TABLE `himalay_tbltickets_priorities` DISABLE KEYS */;
INSERT INTO `himalay_tbltickets_priorities` VALUES (1,'Low'),(2,'Medium'),(3,'High');
/*!40000 ALTER TABLE `himalay_tbltickets_priorities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tbltickets_status`
--

DROP TABLE IF EXISTS `himalay_tbltickets_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tbltickets_status` (
  `ticketstatusid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `isdefault` int(11) NOT NULL DEFAULT 0,
  `statuscolor` varchar(7) DEFAULT NULL,
  `statusorder` int(11) DEFAULT NULL,
  PRIMARY KEY (`ticketstatusid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tbltickets_status`
--

LOCK TABLES `himalay_tbltickets_status` WRITE;
/*!40000 ALTER TABLE `himalay_tbltickets_status` DISABLE KEYS */;
INSERT INTO `himalay_tbltickets_status` VALUES (1,'Open',1,'#ff2d42',1),(2,'In progress',1,'#22c55e',2),(3,'Answered',1,'#2563eb',3),(4,'On Hold',1,'#64748b',4),(5,'Closed',1,'#03a9f4',5);
/*!40000 ALTER TABLE `himalay_tbltickets_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tbltimesheets_additional_timesheet`
--

DROP TABLE IF EXISTS `himalay_tbltimesheets_additional_timesheet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tbltimesheets_additional_timesheet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `additional_day` varchar(45) NOT NULL,
  `status` varchar(45) NOT NULL,
  `timekeeping_type` varchar(50) DEFAULT NULL,
  `timekeeping_value` varchar(45) NOT NULL,
  `approver` int(11) NOT NULL,
  `creator` int(11) NOT NULL,
  `old_timekeeping` varchar(50) DEFAULT NULL,
  `time_in` varchar(45) DEFAULT NULL,
  `time_out` varchar(45) DEFAULT NULL,
  `overtime_setting` int(11) DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `staff_id` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tbltimesheets_additional_timesheet`
--

LOCK TABLES `himalay_tbltimesheets_additional_timesheet` WRITE;
/*!40000 ALTER TABLE `himalay_tbltimesheets_additional_timesheet` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tbltimesheets_additional_timesheet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tbltimesheets_approval_details`
--

DROP TABLE IF EXISTS `himalay_tbltimesheets_approval_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tbltimesheets_approval_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(45) NOT NULL,
  `staffid` varchar(45) DEFAULT NULL,
  `approve` varchar(45) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `approve_action` varchar(255) DEFAULT NULL,
  `reject_action` varchar(255) DEFAULT NULL,
  `approve_value` varchar(255) DEFAULT NULL,
  `reject_value` varchar(255) DEFAULT NULL,
  `staff_approve` int(11) DEFAULT NULL,
  `action` varchar(45) DEFAULT NULL,
  `sender` int(11) DEFAULT NULL,
  `date_send` datetime DEFAULT NULL,
  `notification_recipient` longtext DEFAULT NULL,
  `approval_deadline` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tbltimesheets_approval_details`
--

LOCK TABLES `himalay_tbltimesheets_approval_details` WRITE;
/*!40000 ALTER TABLE `himalay_tbltimesheets_approval_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tbltimesheets_approval_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tbltimesheets_approval_setting`
--

DROP TABLE IF EXISTS `himalay_tbltimesheets_approval_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tbltimesheets_approval_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `related` varchar(255) NOT NULL,
  `setting` longtext NOT NULL,
  `choose_when_approving` int(11) NOT NULL DEFAULT 0,
  `notification_recipient` longtext DEFAULT NULL,
  `number_day_approval` int(11) DEFAULT NULL,
  `departments` text DEFAULT NULL,
  `job_positions` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tbltimesheets_approval_setting`
--

LOCK TABLES `himalay_tbltimesheets_approval_setting` WRITE;
/*!40000 ALTER TABLE `himalay_tbltimesheets_approval_setting` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tbltimesheets_approval_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tbltimesheets_day_off`
--

DROP TABLE IF EXISTS `himalay_tbltimesheets_day_off`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tbltimesheets_day_off` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `year` varchar(45) DEFAULT NULL,
  `total` varchar(45) DEFAULT NULL,
  `remain` varchar(45) DEFAULT NULL,
  `accumulated` varchar(45) DEFAULT NULL,
  `days_off` float DEFAULT 0,
  `type_of_leave` varchar(200) NOT NULL DEFAULT '8',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tbltimesheets_day_off`
--

LOCK TABLES `himalay_tbltimesheets_day_off` WRITE;
/*!40000 ALTER TABLE `himalay_tbltimesheets_day_off` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tbltimesheets_day_off` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tbltimesheets_go_bussiness_advance_payment`
--

DROP TABLE IF EXISTS `himalay_tbltimesheets_go_bussiness_advance_payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tbltimesheets_go_bussiness_advance_payment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `requisition_leave` int(11) NOT NULL,
  `used_to` varchar(200) DEFAULT NULL,
  `amoun_of_money` varchar(200) DEFAULT NULL,
  `request_date` date DEFAULT NULL,
  `advance_payment_reason` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tbltimesheets_go_bussiness_advance_payment`
--

LOCK TABLES `himalay_tbltimesheets_go_bussiness_advance_payment` WRITE;
/*!40000 ALTER TABLE `himalay_tbltimesheets_go_bussiness_advance_payment` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tbltimesheets_go_bussiness_advance_payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tbltimesheets_latch_timesheet`
--

DROP TABLE IF EXISTS `himalay_tbltimesheets_latch_timesheet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tbltimesheets_latch_timesheet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `month_latch` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tbltimesheets_latch_timesheet`
--

LOCK TABLES `himalay_tbltimesheets_latch_timesheet` WRITE;
/*!40000 ALTER TABLE `himalay_tbltimesheets_latch_timesheet` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tbltimesheets_latch_timesheet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tbltimesheets_leave`
--

DROP TABLE IF EXISTS `himalay_tbltimesheets_leave`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tbltimesheets_leave` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `date_work` date NOT NULL,
  `value` text DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tbltimesheets_leave`
--

LOCK TABLES `himalay_tbltimesheets_leave` WRITE;
/*!40000 ALTER TABLE `himalay_tbltimesheets_leave` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tbltimesheets_leave` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tbltimesheets_log_send_notify`
--

DROP TABLE IF EXISTS `himalay_tbltimesheets_log_send_notify`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tbltimesheets_log_send_notify` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sent` int(11) NOT NULL DEFAULT 0,
  `staffid` int(11) NOT NULL DEFAULT 0,
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  `type` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tbltimesheets_log_send_notify`
--

LOCK TABLES `himalay_tbltimesheets_log_send_notify` WRITE;
/*!40000 ALTER TABLE `himalay_tbltimesheets_log_send_notify` DISABLE KEYS */;
INSERT INTO `himalay_tbltimesheets_log_send_notify` VALUES (1,1,0,'2025-07-09 00:00:00','approval_expiration'),(2,1,0,'2025-07-10 00:00:00','approval_expiration'),(3,1,0,'2025-07-11 00:00:00','approval_expiration'),(4,1,0,'2025-07-12 00:00:00','approval_expiration'),(5,1,0,'2025-07-13 00:00:00','approval_expiration'),(6,1,0,'2025-07-14 00:00:00','approval_expiration');
/*!40000 ALTER TABLE `himalay_tbltimesheets_log_send_notify` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tbltimesheets_option`
--

DROP TABLE IF EXISTS `himalay_tbltimesheets_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tbltimesheets_option` (
  `option_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(200) NOT NULL,
  `option_val` longtext DEFAULT NULL,
  `auto` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`option_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1203 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tbltimesheets_option`
--

LOCK TABLES `himalay_tbltimesheets_option` WRITE;
/*!40000 ALTER TABLE `himalay_tbltimesheets_option` DISABLE KEYS */;
INSERT INTO `himalay_tbltimesheets_option` VALUES (1,'shift_applicable_object','',1),(2,'shift_applicable_object','',1),(3,'timekeeping_form','timekeeping_manually',1),(4,'timekeeping_form','timekeeping_manually',1),(5,'timekeeping_manually_role','',1),(6,'timekeeping_task_role','',1),(7,'csv_clsx_role','',1),(8,'attendance_notice_recipient','',1),(9,'allows_updating_check_in_time','1',1),(10,'allows_to_choose_an_older_date','0',1),(11,'allows_to_choose_an_older_date','0',1),(12,'allow_attendance_by_coordinates','0',1),(13,'googlemap_api_key','',1),(14,'googlemap_api_key','',1),(15,'allow_attendance_by_route','0',1),(16,'auto_checkout','0',1),(17,'auto_checkout_type','1',1),(18,'auto_checkout_type','1',1),(19,'auto_checkout_value','1',1),(20,'send_notification_if_check_in_forgotten','0',1),(21,'send_notification_if_check_in_forgotten_value','30',1),(22,'start_month_for_annual_leave_cycle','1',1),(23,'start_month_for_annual_leave_cycle','1',1),(24,'start_year_for_annual_leave_cycle','2025',1),(25,'start_year_for_annual_leave_cycle','2025',1),(26,'hour_notification_approval_exp','3',1),(27,'hour_notification_approval_exp','3',1),(28,'timekeeping_enable_valid_ip','0',1),(29,'timekeeping_enable_valid_ip','0',1),(30,'send_email_check_in_out_customer_location','0',1),(31,'allow_employees_to_create_work_points','0',1),(32,'type_of_leave_selected','8',1),(33,'googlemap_api_key','',1),(34,'googlemap_api_key','',1),(35,'googlemap_api_key','',1),(36,'googlemap_api_key','',1),(37,'googlemap_api_key','',1),(38,'googlemap_api_key','',1),(39,'googlemap_api_key','',1),(40,'googlemap_api_key','',1),(41,'googlemap_api_key','',1),(42,'googlemap_api_key','',1),(43,'googlemap_api_key','',1),(44,'googlemap_api_key','',1),(45,'googlemap_api_key','',1),(46,'googlemap_api_key','',1),(47,'googlemap_api_key','',1),(48,'googlemap_api_key','',1),(49,'googlemap_api_key','',1),(50,'googlemap_api_key','',1),(51,'googlemap_api_key','',1),(52,'googlemap_api_key','',1),(53,'googlemap_api_key','',1),(54,'googlemap_api_key','',1),(55,'googlemap_api_key','',1),(56,'googlemap_api_key','',1),(57,'googlemap_api_key','',1),(58,'googlemap_api_key','',1),(59,'googlemap_api_key','',1),(60,'googlemap_api_key','',1),(61,'googlemap_api_key','',1),(62,'googlemap_api_key','',1),(63,'googlemap_api_key','',1),(64,'googlemap_api_key','',1),(65,'googlemap_api_key','',1),(66,'googlemap_api_key','',1),(67,'googlemap_api_key','',1),(68,'googlemap_api_key','',1),(69,'googlemap_api_key','',1),(70,'googlemap_api_key','',1),(71,'googlemap_api_key','',1),(72,'googlemap_api_key','',1),(73,'googlemap_api_key','',1),(74,'googlemap_api_key','',1),(75,'googlemap_api_key','',1),(76,'googlemap_api_key','',1),(77,'googlemap_api_key','',1),(78,'googlemap_api_key','',1),(79,'googlemap_api_key','',1),(80,'googlemap_api_key','',1),(81,'googlemap_api_key','',1),(82,'googlemap_api_key','',1),(83,'googlemap_api_key','',1),(84,'googlemap_api_key','',1),(85,'googlemap_api_key','',1),(86,'googlemap_api_key','',1),(87,'googlemap_api_key','',1),(88,'googlemap_api_key','',1),(89,'googlemap_api_key','',1),(90,'googlemap_api_key','',1),(91,'googlemap_api_key','',1),(92,'googlemap_api_key','',1),(93,'googlemap_api_key','',1),(94,'googlemap_api_key','',1),(95,'googlemap_api_key','',1),(96,'googlemap_api_key','',1),(97,'googlemap_api_key','',1),(98,'googlemap_api_key','',1),(99,'googlemap_api_key','',1),(100,'googlemap_api_key','',1),(101,'googlemap_api_key','',1),(102,'googlemap_api_key','',1),(103,'googlemap_api_key','',1),(104,'googlemap_api_key','',1),(105,'googlemap_api_key','',1),(106,'googlemap_api_key','',1),(107,'googlemap_api_key','',1),(108,'googlemap_api_key','',1),(109,'googlemap_api_key','',1),(110,'googlemap_api_key','',1),(111,'googlemap_api_key','',1),(112,'googlemap_api_key','',1),(113,'googlemap_api_key','',1),(114,'googlemap_api_key','',1),(115,'googlemap_api_key','',1),(116,'googlemap_api_key','',1),(117,'googlemap_api_key','',1),(118,'googlemap_api_key','',1),(119,'googlemap_api_key','',1),(120,'googlemap_api_key','',1),(121,'googlemap_api_key','',1),(122,'googlemap_api_key','',1),(123,'googlemap_api_key','',1),(124,'googlemap_api_key','',1),(125,'googlemap_api_key','',1),(126,'googlemap_api_key','',1),(127,'googlemap_api_key','',1),(128,'googlemap_api_key','',1),(129,'googlemap_api_key','',1),(130,'googlemap_api_key','',1),(131,'googlemap_api_key','',1),(132,'googlemap_api_key','',1),(133,'googlemap_api_key','',1),(134,'googlemap_api_key','',1),(135,'googlemap_api_key','',1),(136,'googlemap_api_key','',1),(137,'googlemap_api_key','',1),(138,'googlemap_api_key','',1),(139,'googlemap_api_key','',1),(140,'googlemap_api_key','',1),(141,'googlemap_api_key','',1),(142,'googlemap_api_key','',1),(143,'googlemap_api_key','',1),(144,'googlemap_api_key','',1),(145,'googlemap_api_key','',1),(146,'googlemap_api_key','',1),(147,'googlemap_api_key','',1),(148,'googlemap_api_key','',1),(149,'googlemap_api_key','',1),(150,'googlemap_api_key','',1),(151,'googlemap_api_key','',1),(152,'googlemap_api_key','',1),(153,'googlemap_api_key','',1),(154,'googlemap_api_key','',1),(155,'googlemap_api_key','',1),(156,'googlemap_api_key','',1),(157,'googlemap_api_key','',1),(158,'googlemap_api_key','',1),(159,'googlemap_api_key','',1),(160,'googlemap_api_key','',1),(161,'googlemap_api_key','',1),(162,'googlemap_api_key','',1),(163,'googlemap_api_key','',1),(164,'googlemap_api_key','',1),(165,'googlemap_api_key','',1),(166,'googlemap_api_key','',1),(167,'googlemap_api_key','',1),(168,'googlemap_api_key','',1),(169,'googlemap_api_key','',1),(170,'googlemap_api_key','',1),(171,'googlemap_api_key','',1),(172,'googlemap_api_key','',1),(173,'googlemap_api_key','',1),(174,'googlemap_api_key','',1),(175,'googlemap_api_key','',1),(176,'googlemap_api_key','',1),(177,'googlemap_api_key','',1),(178,'googlemap_api_key','',1),(179,'googlemap_api_key','',1),(180,'googlemap_api_key','',1),(181,'googlemap_api_key','',1),(182,'googlemap_api_key','',1),(183,'googlemap_api_key','',1),(184,'googlemap_api_key','',1),(185,'googlemap_api_key','',1),(186,'googlemap_api_key','',1),(187,'googlemap_api_key','',1),(188,'googlemap_api_key','',1),(189,'googlemap_api_key','',1),(190,'googlemap_api_key','',1),(191,'googlemap_api_key','',1),(192,'googlemap_api_key','',1),(193,'googlemap_api_key','',1),(194,'googlemap_api_key','',1),(195,'googlemap_api_key','',1),(196,'googlemap_api_key','',1),(197,'googlemap_api_key','',1),(198,'googlemap_api_key','',1),(199,'googlemap_api_key','',1),(200,'googlemap_api_key','',1),(201,'googlemap_api_key','',1),(202,'googlemap_api_key','',1),(203,'googlemap_api_key','',1),(204,'googlemap_api_key','',1),(205,'googlemap_api_key','',1),(206,'googlemap_api_key','',1),(207,'googlemap_api_key','',1),(208,'googlemap_api_key','',1),(209,'googlemap_api_key','',1),(210,'googlemap_api_key','',1),(211,'googlemap_api_key','',1),(212,'googlemap_api_key','',1),(213,'googlemap_api_key','',1),(214,'googlemap_api_key','',1),(215,'googlemap_api_key','',1),(216,'googlemap_api_key','',1),(217,'googlemap_api_key','',1),(218,'googlemap_api_key','',1),(219,'googlemap_api_key','',1),(220,'googlemap_api_key','',1),(221,'googlemap_api_key','',1),(222,'googlemap_api_key','',1),(223,'googlemap_api_key','',1),(224,'googlemap_api_key','',1),(225,'googlemap_api_key','',1),(226,'googlemap_api_key','',1),(227,'googlemap_api_key','',1),(228,'googlemap_api_key','',1),(229,'googlemap_api_key','',1),(230,'googlemap_api_key','',1),(231,'googlemap_api_key','',1),(232,'googlemap_api_key','',1),(233,'googlemap_api_key','',1),(234,'googlemap_api_key','',1),(235,'googlemap_api_key','',1),(236,'googlemap_api_key','',1),(237,'googlemap_api_key','',1),(238,'googlemap_api_key','',1),(239,'googlemap_api_key','',1),(240,'googlemap_api_key','',1),(241,'googlemap_api_key','',1),(242,'googlemap_api_key','',1),(243,'googlemap_api_key','',1),(244,'googlemap_api_key','',1),(245,'googlemap_api_key','',1),(246,'googlemap_api_key','',1),(247,'googlemap_api_key','',1),(248,'googlemap_api_key','',1),(249,'googlemap_api_key','',1),(250,'googlemap_api_key','',1),(251,'googlemap_api_key','',1),(252,'googlemap_api_key','',1),(253,'googlemap_api_key','',1),(254,'googlemap_api_key','',1),(255,'googlemap_api_key','',1),(256,'googlemap_api_key','',1),(257,'googlemap_api_key','',1),(258,'googlemap_api_key','',1),(259,'googlemap_api_key','',1),(260,'googlemap_api_key','',1),(261,'googlemap_api_key','',1),(262,'googlemap_api_key','',1),(263,'googlemap_api_key','',1),(264,'googlemap_api_key','',1),(265,'googlemap_api_key','',1),(266,'googlemap_api_key','',1),(267,'googlemap_api_key','',1),(268,'googlemap_api_key','',1),(269,'googlemap_api_key','',1),(270,'googlemap_api_key','',1),(271,'googlemap_api_key','',1),(272,'googlemap_api_key','',1),(273,'googlemap_api_key','',1),(274,'googlemap_api_key','',1),(275,'googlemap_api_key','',1),(276,'googlemap_api_key','',1),(277,'googlemap_api_key','',1),(278,'googlemap_api_key','',1),(279,'googlemap_api_key','',1),(280,'googlemap_api_key','',1),(281,'googlemap_api_key','',1),(282,'googlemap_api_key','',1),(283,'googlemap_api_key','',1),(284,'googlemap_api_key','',1),(285,'googlemap_api_key','',1),(286,'googlemap_api_key','',1),(287,'googlemap_api_key','',1),(288,'googlemap_api_key','',1),(289,'googlemap_api_key','',1),(290,'googlemap_api_key','',1),(291,'googlemap_api_key','',1),(292,'googlemap_api_key','',1),(293,'googlemap_api_key','',1),(294,'googlemap_api_key','',1),(295,'googlemap_api_key','',1),(296,'googlemap_api_key','',1),(297,'googlemap_api_key','',1),(298,'googlemap_api_key','',1),(299,'googlemap_api_key','',1),(300,'googlemap_api_key','',1),(301,'googlemap_api_key','',1),(302,'googlemap_api_key','',1),(303,'googlemap_api_key','',1),(304,'googlemap_api_key','',1),(305,'googlemap_api_key','',1),(306,'googlemap_api_key','',1),(307,'googlemap_api_key','',1),(308,'googlemap_api_key','',1),(309,'googlemap_api_key','',1),(310,'googlemap_api_key','',1),(311,'googlemap_api_key','',1),(312,'googlemap_api_key','',1),(313,'googlemap_api_key','',1),(314,'googlemap_api_key','',1),(315,'googlemap_api_key','',1),(316,'googlemap_api_key','',1),(317,'googlemap_api_key','',1),(318,'googlemap_api_key','',1),(319,'googlemap_api_key','',1),(320,'googlemap_api_key','',1),(321,'googlemap_api_key','',1),(322,'googlemap_api_key','',1),(323,'googlemap_api_key','',1),(324,'googlemap_api_key','',1),(325,'googlemap_api_key','',1),(326,'googlemap_api_key','',1),(327,'googlemap_api_key','',1),(328,'googlemap_api_key','',1),(329,'googlemap_api_key','',1),(330,'googlemap_api_key','',1),(331,'googlemap_api_key','',1),(332,'googlemap_api_key','',1),(333,'googlemap_api_key','',1),(334,'googlemap_api_key','',1),(335,'googlemap_api_key','',1),(336,'googlemap_api_key','',1),(337,'googlemap_api_key','',1),(338,'googlemap_api_key','',1),(339,'googlemap_api_key','',1),(340,'googlemap_api_key','',1),(341,'googlemap_api_key','',1),(342,'googlemap_api_key','',1),(343,'googlemap_api_key','',1),(344,'googlemap_api_key','',1),(345,'googlemap_api_key','',1),(346,'googlemap_api_key','',1),(347,'googlemap_api_key','',1),(348,'googlemap_api_key','',1),(349,'googlemap_api_key','',1),(350,'googlemap_api_key','',1),(351,'googlemap_api_key','',1),(352,'googlemap_api_key','',1),(353,'googlemap_api_key','',1),(354,'googlemap_api_key','',1),(355,'googlemap_api_key','',1),(356,'googlemap_api_key','',1),(357,'googlemap_api_key','',1),(358,'googlemap_api_key','',1),(359,'googlemap_api_key','',1),(360,'googlemap_api_key','',1),(361,'googlemap_api_key','',1),(362,'googlemap_api_key','',1),(363,'googlemap_api_key','',1),(364,'googlemap_api_key','',1),(365,'googlemap_api_key','',1),(366,'googlemap_api_key','',1),(367,'googlemap_api_key','',1),(368,'googlemap_api_key','',1),(369,'googlemap_api_key','',1),(370,'googlemap_api_key','',1),(371,'googlemap_api_key','',1),(372,'googlemap_api_key','',1),(373,'googlemap_api_key','',1),(374,'googlemap_api_key','',1),(375,'googlemap_api_key','',1),(376,'googlemap_api_key','',1),(377,'googlemap_api_key','',1),(378,'googlemap_api_key','',1),(379,'googlemap_api_key','',1),(380,'googlemap_api_key','',1),(381,'googlemap_api_key','',1),(382,'googlemap_api_key','',1),(383,'googlemap_api_key','',1),(384,'googlemap_api_key','',1),(385,'googlemap_api_key','',1),(386,'googlemap_api_key','',1),(387,'googlemap_api_key','',1),(388,'googlemap_api_key','',1),(389,'googlemap_api_key','',1),(390,'googlemap_api_key','',1),(391,'googlemap_api_key','',1),(392,'googlemap_api_key','',1),(393,'googlemap_api_key','',1),(394,'googlemap_api_key','',1),(395,'googlemap_api_key','',1),(396,'googlemap_api_key','',1),(397,'googlemap_api_key','',1),(398,'googlemap_api_key','',1),(399,'googlemap_api_key','',1),(400,'googlemap_api_key','',1),(401,'googlemap_api_key','',1),(402,'googlemap_api_key','',1),(403,'googlemap_api_key','',1),(404,'googlemap_api_key','',1),(405,'googlemap_api_key','',1),(406,'googlemap_api_key','',1),(407,'googlemap_api_key','',1),(408,'googlemap_api_key','',1),(409,'googlemap_api_key','',1),(410,'googlemap_api_key','',1),(411,'googlemap_api_key','',1),(412,'googlemap_api_key','',1),(413,'googlemap_api_key','',1),(414,'googlemap_api_key','',1),(415,'googlemap_api_key','',1),(416,'googlemap_api_key','',1),(417,'googlemap_api_key','',1),(418,'googlemap_api_key','',1),(419,'googlemap_api_key','',1),(420,'googlemap_api_key','',1),(421,'googlemap_api_key','',1),(422,'googlemap_api_key','',1),(423,'googlemap_api_key','',1),(424,'googlemap_api_key','',1),(425,'googlemap_api_key','',1),(426,'googlemap_api_key','',1),(427,'googlemap_api_key','',1),(428,'googlemap_api_key','',1),(429,'googlemap_api_key','',1),(430,'googlemap_api_key','',1),(431,'googlemap_api_key','',1),(432,'googlemap_api_key','',1),(433,'googlemap_api_key','',1),(434,'googlemap_api_key','',1),(435,'googlemap_api_key','',1),(436,'googlemap_api_key','',1),(437,'googlemap_api_key','',1),(438,'googlemap_api_key','',1),(439,'googlemap_api_key','',1),(440,'googlemap_api_key','',1),(441,'googlemap_api_key','',1),(442,'googlemap_api_key','',1),(443,'googlemap_api_key','',1),(444,'googlemap_api_key','',1),(445,'googlemap_api_key','',1),(446,'googlemap_api_key','',1),(447,'googlemap_api_key','',1),(448,'googlemap_api_key','',1),(449,'googlemap_api_key','',1),(450,'googlemap_api_key','',1),(451,'googlemap_api_key','',1),(452,'googlemap_api_key','',1),(453,'googlemap_api_key','',1),(454,'googlemap_api_key','',1),(455,'googlemap_api_key','',1),(456,'googlemap_api_key','',1),(457,'googlemap_api_key','',1),(458,'googlemap_api_key','',1),(459,'googlemap_api_key','',1),(460,'googlemap_api_key','',1),(461,'googlemap_api_key','',1),(462,'googlemap_api_key','',1),(463,'googlemap_api_key','',1),(464,'googlemap_api_key','',1),(465,'googlemap_api_key','',1),(466,'googlemap_api_key','',1),(467,'googlemap_api_key','',1),(468,'googlemap_api_key','',1),(469,'googlemap_api_key','',1),(470,'googlemap_api_key','',1),(471,'googlemap_api_key','',1),(472,'googlemap_api_key','',1),(473,'googlemap_api_key','',1),(474,'googlemap_api_key','',1),(475,'googlemap_api_key','',1),(476,'googlemap_api_key','',1),(477,'googlemap_api_key','',1),(478,'googlemap_api_key','',1),(479,'googlemap_api_key','',1),(480,'googlemap_api_key','',1),(481,'googlemap_api_key','',1),(482,'googlemap_api_key','',1),(483,'googlemap_api_key','',1),(484,'googlemap_api_key','',1),(485,'googlemap_api_key','',1),(486,'googlemap_api_key','',1),(487,'googlemap_api_key','',1),(488,'googlemap_api_key','',1),(489,'googlemap_api_key','',1),(490,'googlemap_api_key','',1),(491,'googlemap_api_key','',1),(492,'googlemap_api_key','',1),(493,'googlemap_api_key','',1),(494,'googlemap_api_key','',1),(495,'googlemap_api_key','',1),(496,'googlemap_api_key','',1),(497,'googlemap_api_key','',1),(498,'googlemap_api_key','',1),(499,'googlemap_api_key','',1),(500,'googlemap_api_key','',1),(501,'googlemap_api_key','',1),(502,'googlemap_api_key','',1),(503,'googlemap_api_key','',1),(504,'googlemap_api_key','',1),(505,'googlemap_api_key','',1),(506,'googlemap_api_key','',1),(507,'googlemap_api_key','',1),(508,'googlemap_api_key','',1),(509,'googlemap_api_key','',1),(510,'googlemap_api_key','',1),(511,'googlemap_api_key','',1),(512,'googlemap_api_key','',1),(513,'googlemap_api_key','',1),(514,'googlemap_api_key','',1),(515,'googlemap_api_key','',1),(516,'googlemap_api_key','',1),(517,'googlemap_api_key','',1),(518,'googlemap_api_key','',1),(519,'googlemap_api_key','',1),(520,'googlemap_api_key','',1),(521,'googlemap_api_key','',1),(522,'googlemap_api_key','',1),(523,'googlemap_api_key','',1),(524,'googlemap_api_key','',1),(525,'googlemap_api_key','',1),(526,'googlemap_api_key','',1),(527,'googlemap_api_key','',1),(528,'googlemap_api_key','',1),(529,'googlemap_api_key','',1),(530,'googlemap_api_key','',1),(531,'googlemap_api_key','',1),(532,'googlemap_api_key','',1),(533,'googlemap_api_key','',1),(534,'googlemap_api_key','',1),(535,'googlemap_api_key','',1),(536,'googlemap_api_key','',1),(537,'googlemap_api_key','',1),(538,'googlemap_api_key','',1),(539,'googlemap_api_key','',1),(540,'googlemap_api_key','',1),(541,'googlemap_api_key','',1),(542,'googlemap_api_key','',1),(543,'googlemap_api_key','',1),(544,'googlemap_api_key','',1),(545,'googlemap_api_key','',1),(546,'googlemap_api_key','',1),(547,'googlemap_api_key','',1),(548,'googlemap_api_key','',1),(549,'googlemap_api_key','',1),(550,'googlemap_api_key','',1),(551,'googlemap_api_key','',1),(552,'googlemap_api_key','',1),(553,'googlemap_api_key','',1),(554,'googlemap_api_key','',1),(555,'googlemap_api_key','',1),(556,'googlemap_api_key','',1),(557,'googlemap_api_key','',1),(558,'googlemap_api_key','',1),(559,'googlemap_api_key','',1),(560,'googlemap_api_key','',1),(561,'googlemap_api_key','',1),(562,'googlemap_api_key','',1),(563,'googlemap_api_key','',1),(564,'googlemap_api_key','',1),(565,'googlemap_api_key','',1),(566,'googlemap_api_key','',1),(567,'googlemap_api_key','',1),(568,'googlemap_api_key','',1),(569,'googlemap_api_key','',1),(570,'googlemap_api_key','',1),(571,'googlemap_api_key','',1),(572,'googlemap_api_key','',1),(573,'googlemap_api_key','',1),(574,'googlemap_api_key','',1),(575,'googlemap_api_key','',1),(576,'googlemap_api_key','',1),(577,'googlemap_api_key','',1),(578,'googlemap_api_key','',1),(579,'googlemap_api_key','',1),(580,'googlemap_api_key','',1),(581,'googlemap_api_key','',1),(582,'googlemap_api_key','',1),(583,'googlemap_api_key','',1),(584,'googlemap_api_key','',1),(585,'googlemap_api_key','',1),(586,'googlemap_api_key','',1),(587,'googlemap_api_key','',1),(588,'googlemap_api_key','',1),(589,'googlemap_api_key','',1),(590,'googlemap_api_key','',1),(591,'googlemap_api_key','',1),(592,'googlemap_api_key','',1),(593,'googlemap_api_key','',1),(594,'googlemap_api_key','',1),(595,'googlemap_api_key','',1),(596,'googlemap_api_key','',1),(597,'googlemap_api_key','',1),(598,'googlemap_api_key','',1),(599,'googlemap_api_key','',1),(600,'googlemap_api_key','',1),(601,'googlemap_api_key','',1),(602,'googlemap_api_key','',1),(603,'googlemap_api_key','',1),(604,'googlemap_api_key','',1),(605,'googlemap_api_key','',1),(606,'googlemap_api_key','',1),(607,'googlemap_api_key','',1),(608,'googlemap_api_key','',1),(609,'googlemap_api_key','',1),(610,'googlemap_api_key','',1),(611,'googlemap_api_key','',1),(612,'googlemap_api_key','',1),(613,'googlemap_api_key','',1),(614,'googlemap_api_key','',1),(615,'googlemap_api_key','',1),(616,'googlemap_api_key','',1),(617,'googlemap_api_key','',1),(618,'googlemap_api_key','',1),(619,'googlemap_api_key','',1),(620,'googlemap_api_key','',1),(621,'googlemap_api_key','',1),(622,'googlemap_api_key','',1),(623,'googlemap_api_key','',1),(624,'googlemap_api_key','',1),(625,'googlemap_api_key','',1),(626,'googlemap_api_key','',1),(627,'googlemap_api_key','',1),(628,'googlemap_api_key','',1),(629,'googlemap_api_key','',1),(630,'googlemap_api_key','',1),(631,'googlemap_api_key','',1),(632,'googlemap_api_key','',1),(633,'googlemap_api_key','',1),(634,'googlemap_api_key','',1),(635,'googlemap_api_key','',1),(636,'googlemap_api_key','',1),(637,'googlemap_api_key','',1),(638,'googlemap_api_key','',1),(639,'googlemap_api_key','',1),(640,'googlemap_api_key','',1),(641,'googlemap_api_key','',1),(642,'googlemap_api_key','',1),(643,'googlemap_api_key','',1),(644,'googlemap_api_key','',1),(645,'googlemap_api_key','',1),(646,'googlemap_api_key','',1),(647,'googlemap_api_key','',1),(648,'googlemap_api_key','',1),(649,'googlemap_api_key','',1),(650,'googlemap_api_key','',1),(651,'googlemap_api_key','',1),(652,'googlemap_api_key','',1),(653,'googlemap_api_key','',1),(654,'googlemap_api_key','',1),(655,'googlemap_api_key','',1),(656,'googlemap_api_key','',1),(657,'googlemap_api_key','',1),(658,'googlemap_api_key','',1),(659,'googlemap_api_key','',1),(660,'googlemap_api_key','',1),(661,'googlemap_api_key','',1),(662,'googlemap_api_key','',1),(663,'googlemap_api_key','',1),(664,'googlemap_api_key','',1),(665,'googlemap_api_key','',1),(666,'googlemap_api_key','',1),(667,'googlemap_api_key','',1),(668,'googlemap_api_key','',1),(669,'googlemap_api_key','',1),(670,'googlemap_api_key','',1),(671,'googlemap_api_key','',1),(672,'googlemap_api_key','',1),(673,'googlemap_api_key','',1),(674,'googlemap_api_key','',1),(675,'googlemap_api_key','',1),(676,'googlemap_api_key','',1),(677,'googlemap_api_key','',1),(678,'googlemap_api_key','',1),(679,'googlemap_api_key','',1),(680,'googlemap_api_key','',1),(681,'googlemap_api_key','',1),(682,'googlemap_api_key','',1),(683,'googlemap_api_key','',1),(684,'googlemap_api_key','',1),(685,'googlemap_api_key','',1),(686,'googlemap_api_key','',1),(687,'googlemap_api_key','',1),(688,'googlemap_api_key','',1),(689,'googlemap_api_key','',1),(690,'googlemap_api_key','',1),(691,'googlemap_api_key','',1),(692,'googlemap_api_key','',1),(693,'googlemap_api_key','',1),(694,'googlemap_api_key','',1),(695,'googlemap_api_key','',1),(696,'googlemap_api_key','',1),(697,'googlemap_api_key','',1),(698,'googlemap_api_key','',1),(699,'googlemap_api_key','',1),(700,'googlemap_api_key','',1),(701,'googlemap_api_key','',1),(702,'googlemap_api_key','',1),(703,'googlemap_api_key','',1),(704,'googlemap_api_key','',1),(705,'googlemap_api_key','',1),(706,'googlemap_api_key','',1),(707,'googlemap_api_key','',1),(708,'googlemap_api_key','',1),(709,'googlemap_api_key','',1),(710,'googlemap_api_key','',1),(711,'googlemap_api_key','',1),(712,'googlemap_api_key','',1),(713,'googlemap_api_key','',1),(714,'googlemap_api_key','',1),(715,'googlemap_api_key','',1),(716,'googlemap_api_key','',1),(717,'googlemap_api_key','',1),(718,'googlemap_api_key','',1),(719,'googlemap_api_key','',1),(720,'googlemap_api_key','',1),(721,'googlemap_api_key','',1),(722,'googlemap_api_key','',1),(723,'googlemap_api_key','',1),(724,'googlemap_api_key','',1),(725,'googlemap_api_key','',1),(726,'googlemap_api_key','',1),(727,'googlemap_api_key','',1),(728,'googlemap_api_key','',1),(729,'googlemap_api_key','',1),(730,'googlemap_api_key','',1),(731,'googlemap_api_key','',1),(732,'googlemap_api_key','',1),(733,'googlemap_api_key','',1),(734,'googlemap_api_key','',1),(735,'googlemap_api_key','',1),(736,'googlemap_api_key','',1),(737,'googlemap_api_key','',1),(738,'googlemap_api_key','',1),(739,'googlemap_api_key','',1),(740,'googlemap_api_key','',1),(741,'googlemap_api_key','',1),(742,'googlemap_api_key','',1),(743,'googlemap_api_key','',1),(744,'googlemap_api_key','',1),(745,'googlemap_api_key','',1),(746,'googlemap_api_key','',1),(747,'googlemap_api_key','',1),(748,'googlemap_api_key','',1),(749,'googlemap_api_key','',1),(750,'googlemap_api_key','',1),(751,'googlemap_api_key','',1),(752,'googlemap_api_key','',1),(753,'googlemap_api_key','',1),(754,'googlemap_api_key','',1),(755,'googlemap_api_key','',1),(756,'googlemap_api_key','',1),(757,'googlemap_api_key','',1),(758,'googlemap_api_key','',1),(759,'googlemap_api_key','',1),(760,'googlemap_api_key','',1),(761,'googlemap_api_key','',1),(762,'googlemap_api_key','',1),(763,'googlemap_api_key','',1),(764,'googlemap_api_key','',1),(765,'googlemap_api_key','',1),(766,'googlemap_api_key','',1),(767,'googlemap_api_key','',1),(768,'googlemap_api_key','',1),(769,'googlemap_api_key','',1),(770,'googlemap_api_key','',1),(771,'googlemap_api_key','',1),(772,'googlemap_api_key','',1),(773,'googlemap_api_key','',1),(774,'googlemap_api_key','',1),(775,'googlemap_api_key','',1),(776,'googlemap_api_key','',1),(777,'googlemap_api_key','',1),(778,'googlemap_api_key','',1),(779,'googlemap_api_key','',1),(780,'googlemap_api_key','',1),(781,'googlemap_api_key','',1),(782,'googlemap_api_key','',1),(783,'googlemap_api_key','',1),(784,'googlemap_api_key','',1),(785,'googlemap_api_key','',1),(786,'googlemap_api_key','',1),(787,'googlemap_api_key','',1),(788,'googlemap_api_key','',1),(789,'googlemap_api_key','',1),(790,'googlemap_api_key','',1),(791,'googlemap_api_key','',1),(792,'googlemap_api_key','',1),(793,'googlemap_api_key','',1),(794,'googlemap_api_key','',1),(795,'googlemap_api_key','',1),(796,'googlemap_api_key','',1),(797,'googlemap_api_key','',1),(798,'googlemap_api_key','',1),(799,'googlemap_api_key','',1),(800,'googlemap_api_key','',1),(801,'googlemap_api_key','',1),(802,'googlemap_api_key','',1),(803,'googlemap_api_key','',1),(804,'googlemap_api_key','',1),(805,'googlemap_api_key','',1),(806,'googlemap_api_key','',1),(807,'googlemap_api_key','',1),(808,'googlemap_api_key','',1),(809,'googlemap_api_key','',1),(810,'googlemap_api_key','',1),(811,'googlemap_api_key','',1),(812,'googlemap_api_key','',1),(813,'googlemap_api_key','',1),(814,'googlemap_api_key','',1),(815,'googlemap_api_key','',1),(816,'googlemap_api_key','',1),(817,'googlemap_api_key','',1),(818,'googlemap_api_key','',1),(819,'googlemap_api_key','',1),(820,'googlemap_api_key','',1),(821,'googlemap_api_key','',1),(822,'googlemap_api_key','',1),(823,'googlemap_api_key','',1),(824,'googlemap_api_key','',1),(825,'googlemap_api_key','',1),(826,'googlemap_api_key','',1),(827,'googlemap_api_key','',1),(828,'googlemap_api_key','',1),(829,'googlemap_api_key','',1),(830,'googlemap_api_key','',1),(831,'googlemap_api_key','',1),(832,'googlemap_api_key','',1),(833,'googlemap_api_key','',1),(834,'googlemap_api_key','',1),(835,'googlemap_api_key','',1),(836,'googlemap_api_key','',1),(837,'googlemap_api_key','',1),(838,'googlemap_api_key','',1),(839,'googlemap_api_key','',1),(840,'googlemap_api_key','',1),(841,'googlemap_api_key','',1),(842,'googlemap_api_key','',1),(843,'googlemap_api_key','',1),(844,'googlemap_api_key','',1),(845,'googlemap_api_key','',1),(846,'googlemap_api_key','',1),(847,'googlemap_api_key','',1),(848,'googlemap_api_key','',1),(849,'googlemap_api_key','',1),(850,'googlemap_api_key','',1),(851,'googlemap_api_key','',1),(852,'googlemap_api_key','',1),(853,'googlemap_api_key','',1),(854,'googlemap_api_key','',1),(855,'googlemap_api_key','',1),(856,'googlemap_api_key','',1),(857,'googlemap_api_key','',1),(858,'googlemap_api_key','',1),(859,'googlemap_api_key','',1),(860,'googlemap_api_key','',1),(861,'googlemap_api_key','',1),(862,'googlemap_api_key','',1),(863,'googlemap_api_key','',1),(864,'googlemap_api_key','',1),(865,'googlemap_api_key','',1),(866,'googlemap_api_key','',1),(867,'googlemap_api_key','',1),(868,'googlemap_api_key','',1),(869,'googlemap_api_key','',1),(870,'googlemap_api_key','',1),(871,'googlemap_api_key','',1),(872,'googlemap_api_key','',1),(873,'googlemap_api_key','',1),(874,'googlemap_api_key','',1),(875,'googlemap_api_key','',1),(876,'googlemap_api_key','',1),(877,'googlemap_api_key','',1),(878,'googlemap_api_key','',1),(879,'googlemap_api_key','',1),(880,'googlemap_api_key','',1),(881,'googlemap_api_key','',1),(882,'googlemap_api_key','',1),(883,'googlemap_api_key','',1),(884,'googlemap_api_key','',1),(885,'googlemap_api_key','',1),(886,'googlemap_api_key','',1),(887,'googlemap_api_key','',1),(888,'googlemap_api_key','',1),(889,'googlemap_api_key','',1),(890,'googlemap_api_key','',1),(891,'googlemap_api_key','',1),(892,'googlemap_api_key','',1),(893,'googlemap_api_key','',1),(894,'googlemap_api_key','',1),(895,'googlemap_api_key','',1),(896,'googlemap_api_key','',1),(897,'googlemap_api_key','',1),(898,'googlemap_api_key','',1),(899,'googlemap_api_key','',1),(900,'googlemap_api_key','',1),(901,'googlemap_api_key','',1),(902,'googlemap_api_key','',1),(903,'googlemap_api_key','',1),(904,'googlemap_api_key','',1),(905,'googlemap_api_key','',1),(906,'googlemap_api_key','',1),(907,'googlemap_api_key','',1),(908,'googlemap_api_key','',1),(909,'googlemap_api_key','',1),(910,'googlemap_api_key','',1),(911,'googlemap_api_key','',1),(912,'googlemap_api_key','',1),(913,'googlemap_api_key','',1),(914,'googlemap_api_key','',1),(915,'googlemap_api_key','',1),(916,'googlemap_api_key','',1),(917,'googlemap_api_key','',1),(918,'googlemap_api_key','',1),(919,'googlemap_api_key','',1),(920,'googlemap_api_key','',1),(921,'googlemap_api_key','',1),(922,'googlemap_api_key','',1),(923,'googlemap_api_key','',1),(924,'googlemap_api_key','',1),(925,'googlemap_api_key','',1),(926,'googlemap_api_key','',1),(927,'googlemap_api_key','',1),(928,'googlemap_api_key','',1),(929,'googlemap_api_key','',1),(930,'googlemap_api_key','',1),(931,'googlemap_api_key','',1),(932,'googlemap_api_key','',1),(933,'googlemap_api_key','',1),(934,'googlemap_api_key','',1),(935,'googlemap_api_key','',1),(936,'googlemap_api_key','',1),(937,'googlemap_api_key','',1),(938,'googlemap_api_key','',1),(939,'googlemap_api_key','',1),(940,'googlemap_api_key','',1),(941,'googlemap_api_key','',1),(942,'googlemap_api_key','',1),(943,'googlemap_api_key','',1),(944,'googlemap_api_key','',1),(945,'googlemap_api_key','',1),(946,'googlemap_api_key','',1),(947,'googlemap_api_key','',1),(948,'googlemap_api_key','',1),(949,'googlemap_api_key','',1),(950,'googlemap_api_key','',1),(951,'googlemap_api_key','',1),(952,'googlemap_api_key','',1),(953,'googlemap_api_key','',1),(954,'googlemap_api_key','',1),(955,'googlemap_api_key','',1),(956,'googlemap_api_key','',1),(957,'googlemap_api_key','',1),(958,'googlemap_api_key','',1),(959,'googlemap_api_key','',1),(960,'googlemap_api_key','',1),(961,'googlemap_api_key','',1),(962,'googlemap_api_key','',1),(963,'googlemap_api_key','',1),(964,'googlemap_api_key','',1),(965,'googlemap_api_key','',1),(966,'googlemap_api_key','',1),(967,'googlemap_api_key','',1),(968,'googlemap_api_key','',1),(969,'googlemap_api_key','',1),(970,'googlemap_api_key','',1),(971,'googlemap_api_key','',1),(972,'googlemap_api_key','',1),(973,'googlemap_api_key','',1),(974,'googlemap_api_key','',1),(975,'googlemap_api_key','',1),(976,'googlemap_api_key','',1),(977,'googlemap_api_key','',1),(978,'googlemap_api_key','',1),(979,'googlemap_api_key','',1),(980,'googlemap_api_key','',1),(981,'googlemap_api_key','',1),(982,'googlemap_api_key','',1),(983,'googlemap_api_key','',1),(984,'googlemap_api_key','',1),(985,'googlemap_api_key','',1),(986,'googlemap_api_key','',1),(987,'googlemap_api_key','',1),(988,'googlemap_api_key','',1),(989,'googlemap_api_key','',1),(990,'googlemap_api_key','',1),(991,'googlemap_api_key','',1),(992,'googlemap_api_key','',1),(993,'googlemap_api_key','',1),(994,'googlemap_api_key','',1),(995,'googlemap_api_key','',1),(996,'googlemap_api_key','',1),(997,'googlemap_api_key','',1),(998,'googlemap_api_key','',1),(999,'googlemap_api_key','',1),(1000,'googlemap_api_key','',1),(1001,'googlemap_api_key','',1),(1002,'googlemap_api_key','',1),(1003,'googlemap_api_key','',1),(1004,'googlemap_api_key','',1),(1005,'googlemap_api_key','',1),(1006,'googlemap_api_key','',1),(1007,'googlemap_api_key','',1),(1008,'googlemap_api_key','',1),(1009,'googlemap_api_key','',1),(1010,'googlemap_api_key','',1),(1011,'googlemap_api_key','',1),(1012,'googlemap_api_key','',1),(1013,'googlemap_api_key','',1),(1014,'googlemap_api_key','',1),(1015,'googlemap_api_key','',1),(1016,'googlemap_api_key','',1),(1017,'googlemap_api_key','',1),(1018,'googlemap_api_key','',1),(1019,'googlemap_api_key','',1),(1020,'googlemap_api_key','',1),(1021,'googlemap_api_key','',1),(1022,'googlemap_api_key','',1),(1023,'googlemap_api_key','',1),(1024,'googlemap_api_key','',1),(1025,'googlemap_api_key','',1),(1026,'googlemap_api_key','',1),(1027,'googlemap_api_key','',1),(1028,'googlemap_api_key','',1),(1029,'googlemap_api_key','',1),(1030,'googlemap_api_key','',1),(1031,'googlemap_api_key','',1),(1032,'googlemap_api_key','',1),(1033,'googlemap_api_key','',1),(1034,'googlemap_api_key','',1),(1035,'googlemap_api_key','',1),(1036,'googlemap_api_key','',1),(1037,'googlemap_api_key','',1),(1038,'googlemap_api_key','',1),(1039,'googlemap_api_key','',1),(1040,'googlemap_api_key','',1),(1041,'googlemap_api_key','',1),(1042,'googlemap_api_key','',1),(1043,'googlemap_api_key','',1),(1044,'googlemap_api_key','',1),(1045,'googlemap_api_key','',1),(1046,'googlemap_api_key','',1),(1047,'googlemap_api_key','',1),(1048,'googlemap_api_key','',1),(1049,'googlemap_api_key','',1),(1050,'googlemap_api_key','',1),(1051,'googlemap_api_key','',1),(1052,'googlemap_api_key','',1),(1053,'googlemap_api_key','',1),(1054,'googlemap_api_key','',1),(1055,'googlemap_api_key','',1),(1056,'googlemap_api_key','',1),(1057,'googlemap_api_key','',1),(1058,'googlemap_api_key','',1),(1059,'googlemap_api_key','',1),(1060,'googlemap_api_key','',1),(1061,'googlemap_api_key','',1),(1062,'googlemap_api_key','',1),(1063,'googlemap_api_key','',1),(1064,'googlemap_api_key','',1),(1065,'googlemap_api_key','',1),(1066,'googlemap_api_key','',1),(1067,'googlemap_api_key','',1),(1068,'googlemap_api_key','',1),(1069,'googlemap_api_key','',1),(1070,'googlemap_api_key','',1),(1071,'googlemap_api_key','',1),(1072,'googlemap_api_key','',1),(1073,'googlemap_api_key','',1),(1074,'googlemap_api_key','',1),(1075,'googlemap_api_key','',1),(1076,'googlemap_api_key','',1),(1077,'googlemap_api_key','',1),(1078,'googlemap_api_key','',1),(1079,'googlemap_api_key','',1),(1080,'googlemap_api_key','',1),(1081,'googlemap_api_key','',1),(1082,'googlemap_api_key','',1),(1083,'googlemap_api_key','',1),(1084,'googlemap_api_key','',1),(1085,'googlemap_api_key','',1),(1086,'googlemap_api_key','',1),(1087,'googlemap_api_key','',1),(1088,'googlemap_api_key','',1),(1089,'googlemap_api_key','',1),(1090,'googlemap_api_key','',1),(1091,'googlemap_api_key','',1),(1092,'googlemap_api_key','',1),(1093,'googlemap_api_key','',1),(1094,'googlemap_api_key','',1),(1095,'googlemap_api_key','',1),(1096,'googlemap_api_key','',1),(1097,'googlemap_api_key','',1),(1098,'googlemap_api_key','',1),(1099,'googlemap_api_key','',1),(1100,'googlemap_api_key','',1),(1101,'googlemap_api_key','',1),(1102,'googlemap_api_key','',1),(1103,'googlemap_api_key','',1),(1104,'googlemap_api_key','',1),(1105,'googlemap_api_key','',1),(1106,'googlemap_api_key','',1),(1107,'googlemap_api_key','',1),(1108,'googlemap_api_key','',1),(1109,'googlemap_api_key','',1),(1110,'googlemap_api_key','',1),(1111,'googlemap_api_key','',1),(1112,'googlemap_api_key','',1),(1113,'googlemap_api_key','',1),(1114,'googlemap_api_key','',1),(1115,'googlemap_api_key','',1),(1116,'googlemap_api_key','',1),(1117,'googlemap_api_key','',1),(1118,'googlemap_api_key','',1),(1119,'googlemap_api_key','',1),(1120,'googlemap_api_key','',1),(1121,'googlemap_api_key','',1),(1122,'googlemap_api_key','',1),(1123,'googlemap_api_key','',1),(1124,'googlemap_api_key','',1),(1125,'googlemap_api_key','',1),(1126,'googlemap_api_key','',1),(1127,'googlemap_api_key','',1),(1128,'googlemap_api_key','',1),(1129,'googlemap_api_key','',1),(1130,'googlemap_api_key','',1),(1131,'googlemap_api_key','',1),(1132,'googlemap_api_key','',1),(1133,'googlemap_api_key','',1),(1134,'googlemap_api_key','',1),(1135,'googlemap_api_key','',1),(1136,'googlemap_api_key','',1),(1137,'googlemap_api_key','',1),(1138,'googlemap_api_key','',1),(1139,'googlemap_api_key','',1),(1140,'googlemap_api_key','',1),(1141,'googlemap_api_key','',1),(1142,'googlemap_api_key','',1),(1143,'googlemap_api_key','',1),(1144,'googlemap_api_key','',1),(1145,'googlemap_api_key','',1),(1146,'googlemap_api_key','',1),(1147,'googlemap_api_key','',1),(1148,'googlemap_api_key','',1),(1149,'googlemap_api_key','',1),(1150,'googlemap_api_key','',1),(1151,'googlemap_api_key','',1),(1152,'googlemap_api_key','',1),(1153,'googlemap_api_key','',1),(1154,'googlemap_api_key','',1),(1155,'googlemap_api_key','',1),(1156,'googlemap_api_key','',1),(1157,'googlemap_api_key','',1),(1158,'googlemap_api_key','',1),(1159,'googlemap_api_key','',1),(1160,'googlemap_api_key','',1),(1161,'googlemap_api_key','',1),(1162,'googlemap_api_key','',1),(1163,'googlemap_api_key','',1),(1164,'googlemap_api_key','',1),(1165,'googlemap_api_key','',1),(1166,'googlemap_api_key','',1),(1167,'googlemap_api_key','',1),(1168,'googlemap_api_key','',1),(1169,'googlemap_api_key','',1),(1170,'googlemap_api_key','',1),(1171,'googlemap_api_key','',1),(1172,'googlemap_api_key','',1),(1173,'googlemap_api_key','',1),(1174,'googlemap_api_key','',1),(1175,'googlemap_api_key','',1),(1176,'googlemap_api_key','',1),(1177,'googlemap_api_key','',1),(1178,'googlemap_api_key','',1),(1179,'googlemap_api_key','',1),(1180,'googlemap_api_key','',1),(1181,'googlemap_api_key','',1),(1182,'googlemap_api_key','',1),(1183,'googlemap_api_key','',1),(1184,'googlemap_api_key','',1),(1185,'googlemap_api_key','',1),(1186,'googlemap_api_key','',1),(1187,'googlemap_api_key','',1),(1188,'googlemap_api_key','',1),(1189,'googlemap_api_key','',1),(1190,'googlemap_api_key','',1),(1191,'googlemap_api_key','',1),(1192,'googlemap_api_key','',1),(1193,'googlemap_api_key','',1),(1194,'googlemap_api_key','',1),(1195,'googlemap_api_key','',1),(1196,'googlemap_api_key','',1),(1197,'googlemap_api_key','',1),(1198,'googlemap_api_key','',1),(1199,'googlemap_api_key','',1),(1200,'googlemap_api_key','',1),(1201,'googlemap_api_key','',1),(1202,'googlemap_api_key','',1);
/*!40000 ALTER TABLE `himalay_tbltimesheets_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tbltimesheets_requisition_leave`
--

DROP TABLE IF EXISTS `himalay_tbltimesheets_requisition_leave`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tbltimesheets_requisition_leave` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `subject` varchar(100) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `received_date` date DEFAULT NULL,
  `amount_received` text DEFAULT NULL,
  `approver_id` int(11) NOT NULL,
  `followers_id` int(11) DEFAULT NULL,
  `rel_type` int(11) NOT NULL COMMENT '1:Leave 2:Late_early 3:Go_out 4:Go_on_bussiness',
  `status` int(11) DEFAULT 0 COMMENT '0:Create 1:Approver 2:Reject',
  `place_of_business` longtext DEFAULT NULL,
  `type_of_leave` int(11) DEFAULT 0,
  `according_to_the_plan` int(11) DEFAULT 0,
  `handover_recipients` longtext DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `number_of_days` float DEFAULT NULL,
  `number_of_leaving_day` varchar(45) DEFAULT NULL,
  `type_of_leave_text` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`,`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tbltimesheets_requisition_leave`
--

LOCK TABLES `himalay_tbltimesheets_requisition_leave` WRITE;
/*!40000 ALTER TABLE `himalay_tbltimesheets_requisition_leave` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tbltimesheets_requisition_leave` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tbltimesheets_route`
--

DROP TABLE IF EXISTS `himalay_tbltimesheets_route`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tbltimesheets_route` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `route_point_id` int(11) NOT NULL,
  `date_work` date NOT NULL,
  `order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tbltimesheets_route`
--

LOCK TABLES `himalay_tbltimesheets_route` WRITE;
/*!40000 ALTER TABLE `himalay_tbltimesheets_route` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tbltimesheets_route` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tbltimesheets_route_point`
--

DROP TABLE IF EXISTS `himalay_tbltimesheets_route_point`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tbltimesheets_route_point` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `route_point_address` varchar(400) DEFAULT NULL,
  `latitude` varchar(30) DEFAULT NULL,
  `longitude` varchar(30) DEFAULT NULL,
  `distance` double DEFAULT NULL,
  `related_to` int(11) NOT NULL,
  `related_id` int(11) NOT NULL,
  `default` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tbltimesheets_route_point`
--

LOCK TABLES `himalay_tbltimesheets_route_point` WRITE;
/*!40000 ALTER TABLE `himalay_tbltimesheets_route_point` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tbltimesheets_route_point` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tbltimesheets_shift_sc`
--

DROP TABLE IF EXISTS `himalay_tbltimesheets_shift_sc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tbltimesheets_shift_sc` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shift_symbol` varchar(45) NOT NULL,
  `time_start_work` varchar(45) NOT NULL,
  `time_end_work` varchar(45) NOT NULL,
  `start_lunch_break_time` varchar(45) NOT NULL,
  `end_lunch_break_time` varchar(45) NOT NULL,
  `late_latency_allowed` varchar(45) NOT NULL,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tbltimesheets_shift_sc`
--

LOCK TABLES `himalay_tbltimesheets_shift_sc` WRITE;
/*!40000 ALTER TABLE `himalay_tbltimesheets_shift_sc` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tbltimesheets_shift_sc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tbltimesheets_shiftwork_sc`
--

DROP TABLE IF EXISTS `himalay_tbltimesheets_shiftwork_sc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tbltimesheets_shiftwork_sc` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `date_work` date NOT NULL,
  `shift` int(11) NOT NULL,
  `datecreated` datetime DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tbltimesheets_shiftwork_sc`
--

LOCK TABLES `himalay_tbltimesheets_shiftwork_sc` WRITE;
/*!40000 ALTER TABLE `himalay_tbltimesheets_shiftwork_sc` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tbltimesheets_shiftwork_sc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tbltimesheets_timekeeper_data`
--

DROP TABLE IF EXISTS `himalay_tbltimesheets_timekeeper_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tbltimesheets_timekeeper_data` (
  `staff_identifi` varchar(25) NOT NULL,
  `time` datetime NOT NULL,
  `type` varchar(45) NOT NULL,
  PRIMARY KEY (`staff_identifi`,`time`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tbltimesheets_timekeeper_data`
--

LOCK TABLES `himalay_tbltimesheets_timekeeper_data` WRITE;
/*!40000 ALTER TABLE `himalay_tbltimesheets_timekeeper_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tbltimesheets_timekeeper_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tbltimesheets_timesheet`
--

DROP TABLE IF EXISTS `himalay_tbltimesheets_timesheet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tbltimesheets_timesheet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `date_work` date NOT NULL,
  `value` text DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  `overtime_setting` int(11) DEFAULT NULL,
  `relate_id` int(11) DEFAULT NULL,
  `relate_type` varchar(25) DEFAULT NULL,
  `latch` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tbltimesheets_timesheet`
--

LOCK TABLES `himalay_tbltimesheets_timesheet` WRITE;
/*!40000 ALTER TABLE `himalay_tbltimesheets_timesheet` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tbltimesheets_timesheet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tbltimesheets_type_of_leave`
--

DROP TABLE IF EXISTS `himalay_tbltimesheets_type_of_leave`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tbltimesheets_type_of_leave` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type_name` varchar(200) DEFAULT NULL,
  `slug` varchar(200) DEFAULT NULL,
  `symbol` varchar(5) DEFAULT NULL,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tbltimesheets_type_of_leave`
--

LOCK TABLES `himalay_tbltimesheets_type_of_leave` WRITE;
/*!40000 ALTER TABLE `himalay_tbltimesheets_type_of_leave` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tbltimesheets_type_of_leave` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tbltimesheets_valid_ip`
--

DROP TABLE IF EXISTS `himalay_tbltimesheets_valid_ip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tbltimesheets_valid_ip` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ip` varchar(30) DEFAULT NULL,
  `enable` int(11) NOT NULL DEFAULT 1,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tbltimesheets_valid_ip`
--

LOCK TABLES `himalay_tbltimesheets_valid_ip` WRITE;
/*!40000 ALTER TABLE `himalay_tbltimesheets_valid_ip` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tbltimesheets_valid_ip` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tbltimesheets_workplace`
--

DROP TABLE IF EXISTS `himalay_tbltimesheets_workplace`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tbltimesheets_workplace` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `workplace_address` varchar(400) DEFAULT NULL,
  `latitude` varchar(30) DEFAULT NULL,
  `longitude` varchar(30) DEFAULT NULL,
  `distance` double DEFAULT NULL,
  `default` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tbltimesheets_workplace`
--

LOCK TABLES `himalay_tbltimesheets_workplace` WRITE;
/*!40000 ALTER TABLE `himalay_tbltimesheets_workplace` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tbltimesheets_workplace` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tbltimesheets_workplace_assign`
--

DROP TABLE IF EXISTS `himalay_tbltimesheets_workplace_assign`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tbltimesheets_workplace_assign` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `workplace_id` int(11) NOT NULL,
  `datecreator` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tbltimesheets_workplace_assign`
--

LOCK TABLES `himalay_tbltimesheets_workplace_assign` WRITE;
/*!40000 ALTER TABLE `himalay_tbltimesheets_workplace_assign` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tbltimesheets_workplace_assign` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tbltodos`
--

DROP TABLE IF EXISTS `himalay_tbltodos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tbltodos` (
  `todoid` int(11) NOT NULL AUTO_INCREMENT,
  `description` mediumtext NOT NULL,
  `staffid` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  `finished` tinyint(1) NOT NULL,
  `datefinished` datetime DEFAULT NULL,
  `item_order` int(11) DEFAULT NULL,
  PRIMARY KEY (`todoid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tbltodos`
--

LOCK TABLES `himalay_tbltodos` WRITE;
/*!40000 ALTER TABLE `himalay_tbltodos` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tbltodos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tbltracked_mails`
--

DROP TABLE IF EXISTS `himalay_tbltracked_mails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tbltracked_mails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` varchar(32) NOT NULL,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(40) NOT NULL,
  `date` datetime NOT NULL,
  `email` varchar(100) NOT NULL,
  `opened` tinyint(1) NOT NULL DEFAULT 0,
  `date_opened` datetime DEFAULT NULL,
  `subject` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tbltracked_mails`
--

LOCK TABLES `himalay_tbltracked_mails` WRITE;
/*!40000 ALTER TABLE `himalay_tbltracked_mails` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tbltracked_mails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tbltraining_allocation`
--

DROP TABLE IF EXISTS `himalay_tbltraining_allocation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tbltraining_allocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `training_process_id` varchar(100) NOT NULL,
  `staffid` int(11) DEFAULT NULL,
  `training_type` int(11) DEFAULT NULL,
  `date_add` datetime DEFAULT NULL,
  `training_name` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tbltraining_allocation`
--

LOCK TABLES `himalay_tbltraining_allocation` WRITE;
/*!40000 ALTER TABLE `himalay_tbltraining_allocation` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tbltraining_allocation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tbltransfer_records_reception`
--

DROP TABLE IF EXISTS `himalay_tbltransfer_records_reception`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tbltransfer_records_reception` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) DEFAULT NULL,
  `meta` varchar(50) DEFAULT NULL,
  `staffid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tbltransfer_records_reception`
--

LOCK TABLES `himalay_tbltransfer_records_reception` WRITE;
/*!40000 ALTER TABLE `himalay_tbltransfer_records_reception` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tbltransfer_records_reception` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tbltwocheckout_log`
--

DROP TABLE IF EXISTS `himalay_tbltwocheckout_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tbltwocheckout_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference` varchar(64) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `amount` varchar(25) NOT NULL,
  `created_at` datetime NOT NULL,
  `attempt_reference` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `invoice_id` (`invoice_id`),
  CONSTRAINT `himalay_tbltwocheckout_log_ibfk_1` FOREIGN KEY (`invoice_id`) REFERENCES `himalay_tblinvoices` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tbltwocheckout_log`
--

LOCK TABLES `himalay_tbltwocheckout_log` WRITE;
/*!40000 ALTER TABLE `himalay_tbltwocheckout_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tbltwocheckout_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tbluser_auto_login`
--

DROP TABLE IF EXISTS `himalay_tbluser_auto_login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tbluser_auto_login` (
  `key_id` char(32) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_agent` varchar(150) NOT NULL,
  `last_ip` varchar(40) NOT NULL,
  `last_login` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `staff` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tbluser_auto_login`
--

LOCK TABLES `himalay_tbluser_auto_login` WRITE;
/*!40000 ALTER TABLE `himalay_tbluser_auto_login` DISABLE KEYS */;
INSERT INTO `himalay_tbluser_auto_login` VALUES ('2aa812fd7de88515156498402cc6df77',1,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36 Edg/138.0.0.0','110.172.155.237','2025-07-09 07:31:57',1),('ec718231cf2e4cc05cacab2f1c1d1639',1,'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','49.36.189.194','2025-07-09 07:49:20',1),('1b4b3a3a1fcce6a4dcf3626779120818',1,'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','110.172.155.237','2025-07-09 08:33:39',1),('2a39b50a3f74386e939394a2a411215c',1,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','49.36.189.194','2025-07-11 09:25:33',1);
/*!40000 ALTER TABLE `himalay_tbluser_auto_login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tbluser_meta`
--

DROP TABLE IF EXISTS `himalay_tbluser_meta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tbluser_meta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `staff_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `client_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `contact_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(191) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  `candidate_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`umeta_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tbluser_meta`
--

LOCK TABLES `himalay_tbluser_meta` WRITE;
/*!40000 ALTER TABLE `himalay_tbluser_meta` DISABLE KEYS */;
INSERT INTO `himalay_tbluser_meta` VALUES (1,1,0,0,'recent_searches','[\"mus\",\"mu\"]',0);
/*!40000 ALTER TABLE `himalay_tbluser_meta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblvault`
--

DROP TABLE IF EXISTS `himalay_tblvault`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblvault` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `server_address` varchar(191) NOT NULL,
  `port` int(11) DEFAULT NULL,
  `username` varchar(191) NOT NULL,
  `password` mediumtext NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `creator` int(11) NOT NULL,
  `creator_name` varchar(100) DEFAULT NULL,
  `visibility` tinyint(1) NOT NULL DEFAULT 1,
  `share_in_projects` tinyint(1) NOT NULL DEFAULT 0,
  `last_updated` datetime DEFAULT NULL,
  `last_updated_from` varchar(100) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblvault`
--

LOCK TABLES `himalay_tblvault` WRITE;
/*!40000 ALTER TABLE `himalay_tblvault` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblvault` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblviews_tracking`
--

DROP TABLE IF EXISTS `himalay_tblviews_tracking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblviews_tracking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(40) NOT NULL,
  `date` datetime NOT NULL,
  `view_ip` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblviews_tracking`
--

LOCK TABLES `himalay_tblviews_tracking` WRITE;
/*!40000 ALTER TABLE `himalay_tblviews_tracking` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblviews_tracking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblware_body_type`
--

DROP TABLE IF EXISTS `himalay_tblware_body_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblware_body_type` (
  `body_type_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `body_code` varchar(100) DEFAULT NULL,
  `body_name` text DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  `display` int(1) DEFAULT NULL COMMENT 'display 1: display (yes)  0: not displayed (no)',
  `note` text DEFAULT NULL,
  PRIMARY KEY (`body_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblware_body_type`
--

LOCK TABLES `himalay_tblware_body_type` WRITE;
/*!40000 ALTER TABLE `himalay_tblware_body_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblware_body_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblware_color`
--

DROP TABLE IF EXISTS `himalay_tblware_color`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblware_color` (
  `color_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `color_code` varchar(100) DEFAULT NULL,
  `color_name` varchar(100) DEFAULT NULL,
  `color_hex` text DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  `display` int(1) DEFAULT NULL COMMENT 'display 1: display (yes)  0: not displayed (no)',
  `note` text DEFAULT NULL,
  PRIMARY KEY (`color_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblware_color`
--

LOCK TABLES `himalay_tblware_color` WRITE;
/*!40000 ALTER TABLE `himalay_tblware_color` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblware_color` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblware_commodity_type`
--

DROP TABLE IF EXISTS `himalay_tblware_commodity_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblware_commodity_type` (
  `commodity_type_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `commondity_code` varchar(100) DEFAULT NULL,
  `commondity_name` text DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  `display` int(1) DEFAULT NULL COMMENT 'display 1: display (yes)  0: not displayed (no)',
  `note` text DEFAULT NULL,
  PRIMARY KEY (`commodity_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblware_commodity_type`
--

LOCK TABLES `himalay_tblware_commodity_type` WRITE;
/*!40000 ALTER TABLE `himalay_tblware_commodity_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblware_commodity_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblware_size_type`
--

DROP TABLE IF EXISTS `himalay_tblware_size_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblware_size_type` (
  `size_type_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `size_code` varchar(100) DEFAULT NULL,
  `size_name` text DEFAULT NULL,
  `size_symbol` text DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  `display` int(1) DEFAULT NULL COMMENT 'display 1: display (yes)  0: not displayed (no)',
  `note` text DEFAULT NULL,
  PRIMARY KEY (`size_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblware_size_type`
--

LOCK TABLES `himalay_tblware_size_type` WRITE;
/*!40000 ALTER TABLE `himalay_tblware_size_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblware_size_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblware_style_type`
--

DROP TABLE IF EXISTS `himalay_tblware_style_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblware_style_type` (
  `style_type_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `style_code` varchar(100) DEFAULT NULL,
  `style_barcode` text DEFAULT NULL,
  `style_name` text DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  `display` int(1) DEFAULT NULL COMMENT 'display 1: display (yes)  0: not displayed (no)',
  `note` text DEFAULT NULL,
  PRIMARY KEY (`style_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblware_style_type`
--

LOCK TABLES `himalay_tblware_style_type` WRITE;
/*!40000 ALTER TABLE `himalay_tblware_style_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblware_style_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblware_unit_type`
--

DROP TABLE IF EXISTS `himalay_tblware_unit_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblware_unit_type` (
  `unit_type_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `unit_code` varchar(100) DEFAULT NULL,
  `unit_name` text DEFAULT NULL,
  `unit_symbol` text DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  `display` int(1) DEFAULT NULL COMMENT 'display 1: display (yes)  0: not displayed (no)',
  `note` text DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `unit_measure_type` varchar(100) DEFAULT 'reference',
  `bigger_ratio` decimal(15,5) DEFAULT 0.00000,
  `smaller_ratio` decimal(15,5) DEFAULT 0.00000,
  `rounding` decimal(15,5) DEFAULT 0.00000,
  PRIMARY KEY (`unit_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblware_unit_type`
--

LOCK TABLES `himalay_tblware_unit_type` WRITE;
/*!40000 ALTER TABLE `himalay_tblware_unit_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblware_unit_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblwarehouse`
--

DROP TABLE IF EXISTS `himalay_tblwarehouse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblwarehouse` (
  `warehouse_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `warehouse_code` varchar(100) DEFAULT NULL,
  `warehouse_name` text DEFAULT NULL,
  `warehouse_address` text DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  `display` int(1) DEFAULT NULL COMMENT 'display 1: display (yes)  0: not displayed (no)',
  `note` text DEFAULT NULL,
  `city` text DEFAULT NULL,
  `state` text DEFAULT NULL,
  `zip_code` text DEFAULT NULL,
  `country` text DEFAULT NULL,
  `hide_warehouse_when_out_of_stock` int(11) DEFAULT 0 COMMENT ' 1: yes  0: no',
  PRIMARY KEY (`warehouse_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblwarehouse`
--

LOCK TABLES `himalay_tblwarehouse` WRITE;
/*!40000 ALTER TABLE `himalay_tblwarehouse` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblwarehouse` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblweb_to_lead`
--

DROP TABLE IF EXISTS `himalay_tblweb_to_lead`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblweb_to_lead` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `form_key` varchar(32) NOT NULL,
  `lead_source` int(11) NOT NULL,
  `lead_status` int(11) NOT NULL,
  `notify_lead_imported` int(11) NOT NULL DEFAULT 1,
  `notify_type` varchar(20) DEFAULT NULL,
  `notify_ids` longtext DEFAULT NULL,
  `responsible` int(11) NOT NULL DEFAULT 0,
  `name` varchar(191) NOT NULL,
  `form_data` longtext DEFAULT NULL,
  `recaptcha` int(11) NOT NULL DEFAULT 0,
  `submit_btn_name` varchar(40) DEFAULT NULL,
  `submit_btn_text_color` varchar(10) DEFAULT '#ffffff',
  `submit_btn_bg_color` varchar(10) DEFAULT '#84c529',
  `success_submit_msg` mediumtext DEFAULT NULL,
  `submit_action` int(11) DEFAULT 0,
  `lead_name_prefix` varchar(255) DEFAULT NULL,
  `submit_redirect_url` longtext DEFAULT NULL,
  `language` varchar(40) DEFAULT NULL,
  `allow_duplicate` int(11) NOT NULL DEFAULT 1,
  `mark_public` int(11) NOT NULL DEFAULT 0,
  `track_duplicate_field` varchar(20) DEFAULT NULL,
  `track_duplicate_field_and` varchar(20) DEFAULT NULL,
  `create_task_on_duplicate` int(11) NOT NULL DEFAULT 0,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblweb_to_lead`
--

LOCK TABLES `himalay_tblweb_to_lead` WRITE;
/*!40000 ALTER TABLE `himalay_tblweb_to_lead` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblweb_to_lead` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblweb_to_recruitment`
--

DROP TABLE IF EXISTS `himalay_tblweb_to_recruitment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblweb_to_recruitment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `campaign_code` varchar(200) DEFAULT NULL,
  `campaign_name` varchar(200) DEFAULT NULL,
  `cp_proposal` text DEFAULT NULL,
  `cp_position` int(11) DEFAULT NULL,
  `cp_department` int(11) DEFAULT NULL,
  `cp_amount_recruiment` int(11) DEFAULT NULL,
  `cp_form_work` varchar(45) DEFAULT NULL,
  `cp_workplace` varchar(255) DEFAULT NULL,
  `cp_salary_from` decimal(15,0) DEFAULT NULL,
  `cp_salary_to` decimal(15,0) DEFAULT NULL,
  `cp_from_date` date DEFAULT NULL,
  `cp_to_date` date DEFAULT NULL,
  `cp_reason_recruitment` text DEFAULT NULL,
  `cp_job_description` text DEFAULT NULL,
  `cp_manager` text DEFAULT NULL,
  `cp_follower` text DEFAULT NULL,
  `cp_ages_from` int(11) DEFAULT NULL,
  `cp_ages_to` int(11) DEFAULT NULL,
  `cp_gender` varchar(10) DEFAULT NULL,
  `cp_height` float DEFAULT NULL,
  `cp_weight` float DEFAULT NULL,
  `cp_literacy` varchar(200) DEFAULT NULL,
  `cp_experience` varchar(200) DEFAULT NULL,
  `cp_add_from` int(11) DEFAULT NULL,
  `cp_date_add` date DEFAULT NULL,
  `cp_status` int(11) DEFAULT NULL,
  `nation` varchar(15) DEFAULT NULL,
  `nationality` varchar(15) DEFAULT NULL,
  `religion` varchar(15) DEFAULT NULL,
  `marital_status` varchar(15) DEFAULT NULL,
  `birthplace` varchar(200) DEFAULT NULL,
  `home_town` varchar(200) DEFAULT NULL,
  `resident` varchar(200) DEFAULT NULL,
  `current_accommodation` varchar(200) DEFAULT NULL,
  `cp_desired_salary` varchar(10) DEFAULT NULL,
  `specialized` varchar(100) DEFAULT NULL,
  `training_form` varchar(50) DEFAULT NULL,
  `training_places` varchar(50) DEFAULT NULL,
  `lead_source` varchar(10) DEFAULT NULL,
  `lead_status` varchar(10) DEFAULT NULL,
  `notify_ids_staff` text DEFAULT NULL,
  `notify_ids_roles` text DEFAULT NULL,
  `form_key` varchar(32) DEFAULT NULL,
  `notify_lead_imported` int(11) DEFAULT 1,
  `notify_type` varchar(20) DEFAULT NULL,
  `notify_ids` mediumtext DEFAULT NULL,
  `responsible` int(11) DEFAULT 0,
  `name` varchar(191) DEFAULT NULL,
  `form_data` mediumtext DEFAULT NULL,
  `recaptcha` int(11) DEFAULT 0,
  `submit_btn_name` varchar(40) DEFAULT NULL,
  `success_submit_msg` text DEFAULT NULL,
  `language` varchar(40) DEFAULT NULL,
  `allow_duplicate` int(11) DEFAULT 1,
  `mark_public` int(11) DEFAULT 0,
  `track_duplicate_field` varchar(20) DEFAULT NULL,
  `track_duplicate_field_and` varchar(20) DEFAULT NULL,
  `create_task_on_duplicate` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblweb_to_recruitment`
--

LOCK TABLES `himalay_tblweb_to_recruitment` WRITE;
/*!40000 ALTER TABLE `himalay_tblweb_to_recruitment` DISABLE KEYS */;
INSERT INTO `himalay_tblweb_to_recruitment` VALUES (1,'','','',0,0,1,'','',0,0,'0000-00-00','0000-00-00','','','','',15,60,'',1,40,'','',0,'0000-00-00',0,'','','','','','','','','','','','','','','','','941a152470ec9f091952247d6790020f',0,'','',0,'recruitment_form','[{\"label\":\"Croatia\",\"value\":\"55\"},{\"label\":\"Cuba\",\"value\":\"56\"},{\"label\":\"Curacao\",\"value\":\"57\"},{\"label\":\"Cyprus\",\"value\":\"58\"},{\"label\":\"Czech Republic\",\"value\":\"59\"},{\"label\":\"Democratic Republic of the Congo\",\"value\":\"60\"},{\"label\":\"Denmark\",\"value\":\"61\"},{\"label\":\"Djibouti\",\"value\":\"62\"},{\"label\":\"Dominica\",\"value\":\"63\"},{\"label\":\"Dominican Republic\",\"value\":\"64\"},{\"label\":\"Ecuador\",\"value\":\"65\"},{\"label\":\"Egypt\",\"value\":\"66\"},{\"label\":\"El Salvador\",\"value\":\"67\"},{\"label\":\"Equatorial Guinea\",\"value\":\"68\"},{\"label\":\"Eritrea\",\"value\":\"69\"},{\"label\":\"Estonia\",\"value\":\"70\"},{\"label\":\"Ethiopia\",\"value\":\"71\"},{\"label\":\"Falkland Islands (Malvinas)\",\"value\":\"72\"},{\"label\":\"Faroe Islands\",\"value\":\"73\"},{\"label\":\"Fiji\",\"value\":\"74\"},{\"label\":\"Finland\",\"value\":\"75\"},{\"label\":\"France\",\"value\":\"76\"},{\"label\":\"French Guiana\",\"value\":\"77\"},{\"label\":\"French Polynesia\",\"value\":\"78\"},{\"label\":\"French Southern Territories\",\"value\":\"79\"},{\"label\":\"Gabon\",\"value\":\"80\"},{\"label\":\"Gambia\",\"value\":\"81\"},{\"label\":\"Georgia\",\"value\":\"82\"},{\"label\":\"Germany\",\"value\":\"83\"},{\"label\":\"Ghana\",\"value\":\"84\"},{\"label\":\"Gibraltar\",\"value\":\"85\"},{\"label\":\"Greece\",\"value\":\"86\"},{\"label\":\"Greenland\",\"value\":\"87\"},{\"label\":\"Grenada\",\"value\":\"88\"},{\"label\":\"Guadaloupe\",\"value\":\"89\"},{\"label\":\"Guam\",\"value\":\"90\"},{\"label\":\"Guatemala\",\"value\":\"91\"},{\"label\":\"Guernsey\",\"value\":\"92\"},{\"label\":\"Guinea\",\"value\":\"93\"},{\"label\":\"Guinea-Bissau\",\"value\":\"94\"},{\"label\":\"Guyana\",\"value\":\"95\"},{\"label\":\"Haiti\",\"value\":\"96\"},{\"label\":\"Heard Island and McDonald Islands\",\"value\":\"97\"},{\"label\":\"Honduras\",\"value\":\"98\"},{\"label\":\"Hong Kong\",\"value\":\"99\"},{\"label\":\"Hungary\",\"value\":\"100\"},{\"label\":\"Iceland\",\"value\":\"101\"},{\"label\":\"India\",\"value\":\"102\"},{\"label\":\"Indonesia\",\"value\":\"103\"},{\"label\":\"Iran\",\"value\":\"104\"},{\"label\":\"Iraq\",\"value\":\"105\"},{\"label\":\"Ireland\",\"value\":\"106\"},{\"label\":\"Isle of Man\",\"value\":\"107\"},{\"label\":\"Israel\",\"value\":\"108\"},{\"label\":\"Italy\",\"value\":\"109\"},{\"label\":\"Jamaica\",\"value\":\"110\"},{\"label\":\"Japan\",\"value\":\"111\"},{\"label\":\"Jersey\",\"value\":\"112\"},{\"label\":\"Jordan\",\"value\":\"113\"},{\"label\":\"Kazakhstan\",\"value\":\"114\"},{\"label\":\"Kenya\",\"value\":\"115\"},{\"label\":\"Kiribati\",\"value\":\"116\"},{\"label\":\"Kosovo\",\"value\":\"117\"},{\"label\":\"Kuwait\",\"value\":\"118\"},{\"label\":\"Kyrgyzstan\",\"value\":\"119\"},{\"label\":\"Laos\",\"value\":\"120\"},{\"label\":\"Latvia\",\"value\":\"121\"},{\"label\":\"Lebanon\",\"value\":\"122\"},{\"label\":\"Lesotho\",\"value\":\"123\"},{\"label\":\"Liberia\",\"value\":\"124\"},{\"label\":\"Libya\",\"value\":\"125\"},{\"label\":\"Liechtenstein\",\"value\":\"126\"},{\"label\":\"Lithuania\",\"value\":\"127\"},{\"label\":\"Luxembourg\",\"value\":\"128\"},{\"label\":\"Macao\",\"value\":\"129\"},{\"label\":\"North Macedonia\",\"value\":\"130\"},{\"label\":\"Madagascar\",\"value\":\"131\"},{\"label\":\"Malawi\",\"value\":\"132\"},{\"label\":\"Malaysia\",\"value\":\"133\"},{\"label\":\"Maldives\",\"value\":\"134\"},{\"label\":\"Mali\",\"value\":\"135\"},{\"label\":\"Malta\",\"value\":\"136\"},{\"label\":\"Marshall Islands\",\"value\":\"137\"},{\"label\":\"Martinique\",\"value\":\"138\"},{\"label\":\"Mauritania\",\"value\":\"139\"},{\"label\":\"Mauritius\",\"value\":\"140\"},{\"label\":\"Mayotte\",\"value\":\"141\"},{\"label\":\"Mexico\",\"value\":\"142\"},{\"label\":\"Micronesia\",\"value\":\"143\"},{\"label\":\"Moldava\",\"value\":\"144\"},{\"label\":\"Monaco\",\"value\":\"145\"},{\"label\":\"Mongolia\",\"value\":\"146\"},{\"label\":\"Montenegro\",\"value\":\"147\"},{\"label\":\"Montserrat\",\"value\":\"148\"},{\"label\":\"Morocco\",\"value\":\"149\"},{\"label\":\"Mozambique\",\"value\":\"150\"},{\"label\":\"Myanmar (Burma)\",\"value\":\"151\"},{\"label\":\"Namibia\",\"value\":\"152\"},{\"label\":\"Nauru\",\"value\":\"153\"},{\"label\":\"Nepal\",\"value\":\"154\"},{\"label\":\"Netherlands\",\"value\":\"155\"},{\"label\":\"New Caledonia\",\"value\":\"156\"},{\"label\":\"New Zealand\",\"value\":\"157\"},{\"label\":\"Nicaragua\",\"value\":\"158\"},{\"label\":\"Niger\",\"value\":\"159\"},{\"label\":\"Nigeria\",\"value\":\"160\"},{\"label\":\"Niue\",\"value\":\"161\"},{\"label\":\"Norfolk Island\",\"value\":\"162\"},{\"label\":\"North Korea\",\"value\":\"163\"},{\"label\":\"Northern Mariana Islands\",\"value\":\"164\"},{\"label\":\"Norway\",\"value\":\"165\"},{\"label\":\"Oman\",\"value\":\"166\"},{\"label\":\"Pakistan\",\"value\":\"167\"},{\"label\":\"Palau\",\"value\":\"168\"},{\"label\":\"Palestine\",\"value\":\"169\"},{\"label\":\"Panama\",\"value\":\"170\"},{\"label\":\"Papua New Guinea\",\"value\":\"171\"},{\"label\":\"Paraguay\",\"value\":\"172\"},{\"label\":\"Peru\",\"value\":\"173\"},{\"label\":\"Phillipines\",\"value\":\"174\"},{\"label\":\"Pitcairn\",\"value\":\"175\"},{\"label\":\"Poland\",\"value\":\"176\"},{\"label\":\"Portugal\",\"value\":\"177\"},{\"label\":\"Puerto Rico\",\"value\":\"178\"},{\"label\":\"Qatar\",\"value\":\"179\"},{\"label\":\"Reunion\",\"value\":\"180\"},{\"label\":\"Romania\",\"value\":\"181\"},{\"label\":\"Russia\",\"value\":\"182\"},{\"label\":\"Rwanda\",\"value\":\"183\"},{\"label\":\"Saint Barthelemy\",\"value\":\"184\"},{\"label\":\"Saint Helena\",\"value\":\"185\"},{\"label\":\"Saint Kitts and Nevis\",\"value\":\"186\"},{\"label\":\"Saint Lucia\",\"value\":\"187\"},{\"label\":\"Saint Martin\",\"value\":\"188\"},{\"label\":\"Saint Pierre and Miquelon\",\"value\":\"189\"},{\"label\":\"Saint Vincent and the Grenadines\",\"value\":\"190\"},{\"label\":\"Samoa\",\"value\":\"191\"},{\"label\":\"San Marino\",\"value\":\"192\"},{\"label\":\"Sao Tome and Principe\",\"value\":\"193\"},{\"label\":\"Saudi Arabia\",\"value\":\"194\"},{\"label\":\"Senegal\",\"value\":\"195\"},{\"label\":\"Serbia\",\"value\":\"196\"},{\"label\":\"Seychelles\",\"value\":\"197\"},{\"label\":\"Sierra Leone\",\"value\":\"198\"},{\"label\":\"Singapore\",\"value\":\"199\"},{\"label\":\"Sint Maarten\",\"value\":\"200\"},{\"label\":\"Slovakia\",\"value\":\"201\"},{\"label\":\"Slovenia\",\"value\":\"202\"},{\"label\":\"Solomon Islands\",\"value\":\"203\"},{\"label\":\"Somalia\",\"value\":\"204\"},{\"label\":\"South Africa\",\"value\":\"205\"},{\"label\":\"South Georgia and the South Sandwich Islands\",\"value\":\"206\"},{\"label\":\"South Korea\",\"value\":\"207\"},{\"label\":\"South Sudan\",\"value\":\"208\"},{\"label\":\"Spain\",\"value\":\"209\"},{\"label\":\"Sri Lanka\",\"value\":\"210\"},{\"label\":\"Sudan\",\"value\":\"211\"},{\"label\":\"Suriname\",\"value\":\"212\"},{\"label\":\"Svalbard and Jan Mayen\",\"value\":\"213\"},{\"label\":\"Swaziland\",\"value\":\"214\"},{\"label\":\"Sweden\",\"value\":\"215\"},{\"label\":\"Switzerland\",\"value\":\"216\"},{\"label\":\"Syria\",\"value\":\"217\"},{\"label\":\"Taiwan\",\"value\":\"218\"},{\"label\":\"Tajikistan\",\"value\":\"219\"},{\"label\":\"Tanzania\",\"value\":\"220\"},{\"label\":\"Thailand\",\"value\":\"221\"},{\"label\":\"Timor-Leste (East Timor)\",\"value\":\"222\"},{\"label\":\"Togo\",\"value\":\"223\"},{\"label\":\"Tokelau\",\"value\":\"224\"},{\"label\":\"Tonga\",\"value\":\"225\"},{\"label\":\"Trinidad and Tobago\",\"value\":\"226\"},{\"label\":\"Tunisia\",\"value\":\"227\"},{\"label\":\"Turkey\",\"value\":\"228\"},{\"label\":\"Turkmenistan\",\"value\":\"229\"},{\"label\":\"Turks and Caicos Islands\",\"value\":\"230\"},{\"label\":\"Tuvalu\",\"value\":\"231\"},{\"label\":\"Uganda\",\"value\":\"232\"},{\"label\":\"Ukraine\",\"value\":\"233\"},{\"label\":\"United Arab Emirates\",\"value\":\"234\"},{\"label\":\"United Kingdom\",\"value\":\"235\"},{\"label\":\"United States\",\"value\":\"236\"},{\"label\":\"United States Minor Outlying Islands\",\"value\":\"237\"},{\"label\":\"Uruguay\",\"value\":\"238\"},{\"label\":\"Uzbekistan\",\"value\":\"239\"},{\"label\":\"Vanuatu\",\"value\":\"240\"},{\"label\":\"Vatican City\",\"value\":\"241\"},{\"label\":\"Venezuela\",\"value\":\"242\"},{\"label\":\"Vietnam\",\"value\":\"243\",\"selected\":true},{\"label\":\"Virgin Islands, British\",\"value\":\"244\"},{\"label\":\"Virgin Islands, US\",\"value\":\"245\"},{\"label\":\"Wallis and Futuna\",\"value\":\"246\"},{\"label\":\"Western Sahara\",\"value\":\"247\"},{\"label\":\"Yemen\",\"value\":\"248\"},{\"label\":\"Zambia\",\"value\":\"249\"},{\"label\":\"Zimbabwe\",\"value\":\"250\"}]},{\"type\":\"text\",\"label\":\"_national\",\"className\":\"form-control\",\"name\":\"nation\",\"subtype\":\"text\"},{\"type\":\"text\",\"label\":\"_religion\",\"className\":\"form-control\",\"name\":\"religion\",\"subtype\":\"text\"},{\"type\":\"text\",\"label\":\"_phone\",\"className\":\"form-control\",\"name\":\"phonenumber\",\"subtype\":\"text\"},{\"type\":\"select\",\"label\":\"_diploma\",\"className\":\"form-control\",\"name\":\"diploma\",\"values\":[{\"label\":\"\",\"value\":\"\"},{\"label\":\"master_s_degree\",\"value\":\"0\"},{\"label\":\"Ph_D\",\"value\":\"1\"},{\"label\":\"bachelor\",\"value\":\"2\"},{\"label\":\"university\",\"value\":\"3\"},{\"label\":\"vocational_colleges\",\"value\":\"4\"},{\"label\":\"vocational\",\"value\":\"5\"},{\"label\":\"high_school\",\"value\":\"6\"}]},{\"type\":\"text\",\"label\":\"training_places\",\"className\":\"form-control\",\"name\":\"training_places\",\"subtype\":\"text\"},{\"type\":\"text\",\"label\":\"specialized\",\"className\":\"form-control\",\"name\":\"specialized\",\"subtype\":\"text\"},{\"type\":\"text\",\"label\":\"forms_of_training\",\"className\":\"form-control\",\"name\":\"training_form\",\"subtype\":\"text\"},{\"type\":\"text\",\"label\":\"issue_date_identification_card\",\"className\":\"form-control fc-datepicker\",\"name\":\"days_for_identity\",\"subtype\":\"text\"}]',0,'sent','sent_successfully','',0,0,'','',0),(2,'','','',0,0,1,'','',0,0,'0000-00-00','0000-00-00','','','','',15,60,'',1,40,'','',0,'0000-00-00',0,'','','','','','','','','','','','','','','','','8e20d3beb8b43484ff8c014025877290',0,'','',0,'recruitment_form','[{\"label\":\"Croatia\",\"value\":\"55\"},{\"label\":\"Cuba\",\"value\":\"56\"},{\"label\":\"Curacao\",\"value\":\"57\"},{\"label\":\"Cyprus\",\"value\":\"58\"},{\"label\":\"Czech Republic\",\"value\":\"59\"},{\"label\":\"Democratic Republic of the Congo\",\"value\":\"60\"},{\"label\":\"Denmark\",\"value\":\"61\"},{\"label\":\"Djibouti\",\"value\":\"62\"},{\"label\":\"Dominica\",\"value\":\"63\"},{\"label\":\"Dominican Republic\",\"value\":\"64\"},{\"label\":\"Ecuador\",\"value\":\"65\"},{\"label\":\"Egypt\",\"value\":\"66\"},{\"label\":\"El Salvador\",\"value\":\"67\"},{\"label\":\"Equatorial Guinea\",\"value\":\"68\"},{\"label\":\"Eritrea\",\"value\":\"69\"},{\"label\":\"Estonia\",\"value\":\"70\"},{\"label\":\"Ethiopia\",\"value\":\"71\"},{\"label\":\"Falkland Islands (Malvinas)\",\"value\":\"72\"},{\"label\":\"Faroe Islands\",\"value\":\"73\"},{\"label\":\"Fiji\",\"value\":\"74\"},{\"label\":\"Finland\",\"value\":\"75\"},{\"label\":\"France\",\"value\":\"76\"},{\"label\":\"French Guiana\",\"value\":\"77\"},{\"label\":\"French Polynesia\",\"value\":\"78\"},{\"label\":\"French Southern Territories\",\"value\":\"79\"},{\"label\":\"Gabon\",\"value\":\"80\"},{\"label\":\"Gambia\",\"value\":\"81\"},{\"label\":\"Georgia\",\"value\":\"82\"},{\"label\":\"Germany\",\"value\":\"83\"},{\"label\":\"Ghana\",\"value\":\"84\"},{\"label\":\"Gibraltar\",\"value\":\"85\"},{\"label\":\"Greece\",\"value\":\"86\"},{\"label\":\"Greenland\",\"value\":\"87\"},{\"label\":\"Grenada\",\"value\":\"88\"},{\"label\":\"Guadaloupe\",\"value\":\"89\"},{\"label\":\"Guam\",\"value\":\"90\"},{\"label\":\"Guatemala\",\"value\":\"91\"},{\"label\":\"Guernsey\",\"value\":\"92\"},{\"label\":\"Guinea\",\"value\":\"93\"},{\"label\":\"Guinea-Bissau\",\"value\":\"94\"},{\"label\":\"Guyana\",\"value\":\"95\"},{\"label\":\"Haiti\",\"value\":\"96\"},{\"label\":\"Heard Island and McDonald Islands\",\"value\":\"97\"},{\"label\":\"Honduras\",\"value\":\"98\"},{\"label\":\"Hong Kong\",\"value\":\"99\"},{\"label\":\"Hungary\",\"value\":\"100\"},{\"label\":\"Iceland\",\"value\":\"101\"},{\"label\":\"India\",\"value\":\"102\"},{\"label\":\"Indonesia\",\"value\":\"103\"},{\"label\":\"Iran\",\"value\":\"104\"},{\"label\":\"Iraq\",\"value\":\"105\"},{\"label\":\"Ireland\",\"value\":\"106\"},{\"label\":\"Isle of Man\",\"value\":\"107\"},{\"label\":\"Israel\",\"value\":\"108\"},{\"label\":\"Italy\",\"value\":\"109\"},{\"label\":\"Jamaica\",\"value\":\"110\"},{\"label\":\"Japan\",\"value\":\"111\"},{\"label\":\"Jersey\",\"value\":\"112\"},{\"label\":\"Jordan\",\"value\":\"113\"},{\"label\":\"Kazakhstan\",\"value\":\"114\"},{\"label\":\"Kenya\",\"value\":\"115\"},{\"label\":\"Kiribati\",\"value\":\"116\"},{\"label\":\"Kosovo\",\"value\":\"117\"},{\"label\":\"Kuwait\",\"value\":\"118\"},{\"label\":\"Kyrgyzstan\",\"value\":\"119\"},{\"label\":\"Laos\",\"value\":\"120\"},{\"label\":\"Latvia\",\"value\":\"121\"},{\"label\":\"Lebanon\",\"value\":\"122\"},{\"label\":\"Lesotho\",\"value\":\"123\"},{\"label\":\"Liberia\",\"value\":\"124\"},{\"label\":\"Libya\",\"value\":\"125\"},{\"label\":\"Liechtenstein\",\"value\":\"126\"},{\"label\":\"Lithuania\",\"value\":\"127\"},{\"label\":\"Luxembourg\",\"value\":\"128\"},{\"label\":\"Macao\",\"value\":\"129\"},{\"label\":\"North Macedonia\",\"value\":\"130\"},{\"label\":\"Madagascar\",\"value\":\"131\"},{\"label\":\"Malawi\",\"value\":\"132\"},{\"label\":\"Malaysia\",\"value\":\"133\"},{\"label\":\"Maldives\",\"value\":\"134\"},{\"label\":\"Mali\",\"value\":\"135\"},{\"label\":\"Malta\",\"value\":\"136\"},{\"label\":\"Marshall Islands\",\"value\":\"137\"},{\"label\":\"Martinique\",\"value\":\"138\"},{\"label\":\"Mauritania\",\"value\":\"139\"},{\"label\":\"Mauritius\",\"value\":\"140\"},{\"label\":\"Mayotte\",\"value\":\"141\"},{\"label\":\"Mexico\",\"value\":\"142\"},{\"label\":\"Micronesia\",\"value\":\"143\"},{\"label\":\"Moldava\",\"value\":\"144\"},{\"label\":\"Monaco\",\"value\":\"145\"},{\"label\":\"Mongolia\",\"value\":\"146\"},{\"label\":\"Montenegro\",\"value\":\"147\"},{\"label\":\"Montserrat\",\"value\":\"148\"},{\"label\":\"Morocco\",\"value\":\"149\"},{\"label\":\"Mozambique\",\"value\":\"150\"},{\"label\":\"Myanmar (Burma)\",\"value\":\"151\"},{\"label\":\"Namibia\",\"value\":\"152\"},{\"label\":\"Nauru\",\"value\":\"153\"},{\"label\":\"Nepal\",\"value\":\"154\"},{\"label\":\"Netherlands\",\"value\":\"155\"},{\"label\":\"New Caledonia\",\"value\":\"156\"},{\"label\":\"New Zealand\",\"value\":\"157\"},{\"label\":\"Nicaragua\",\"value\":\"158\"},{\"label\":\"Niger\",\"value\":\"159\"},{\"label\":\"Nigeria\",\"value\":\"160\"},{\"label\":\"Niue\",\"value\":\"161\"},{\"label\":\"Norfolk Island\",\"value\":\"162\"},{\"label\":\"North Korea\",\"value\":\"163\"},{\"label\":\"Northern Mariana Islands\",\"value\":\"164\"},{\"label\":\"Norway\",\"value\":\"165\"},{\"label\":\"Oman\",\"value\":\"166\"},{\"label\":\"Pakistan\",\"value\":\"167\"},{\"label\":\"Palau\",\"value\":\"168\"},{\"label\":\"Palestine\",\"value\":\"169\"},{\"label\":\"Panama\",\"value\":\"170\"},{\"label\":\"Papua New Guinea\",\"value\":\"171\"},{\"label\":\"Paraguay\",\"value\":\"172\"},{\"label\":\"Peru\",\"value\":\"173\"},{\"label\":\"Phillipines\",\"value\":\"174\"},{\"label\":\"Pitcairn\",\"value\":\"175\"},{\"label\":\"Poland\",\"value\":\"176\"},{\"label\":\"Portugal\",\"value\":\"177\"},{\"label\":\"Puerto Rico\",\"value\":\"178\"},{\"label\":\"Qatar\",\"value\":\"179\"},{\"label\":\"Reunion\",\"value\":\"180\"},{\"label\":\"Romania\",\"value\":\"181\"},{\"label\":\"Russia\",\"value\":\"182\"},{\"label\":\"Rwanda\",\"value\":\"183\"},{\"label\":\"Saint Barthelemy\",\"value\":\"184\"},{\"label\":\"Saint Helena\",\"value\":\"185\"},{\"label\":\"Saint Kitts and Nevis\",\"value\":\"186\"},{\"label\":\"Saint Lucia\",\"value\":\"187\"},{\"label\":\"Saint Martin\",\"value\":\"188\"},{\"label\":\"Saint Pierre and Miquelon\",\"value\":\"189\"},{\"label\":\"Saint Vincent and the Grenadines\",\"value\":\"190\"},{\"label\":\"Samoa\",\"value\":\"191\"},{\"label\":\"San Marino\",\"value\":\"192\"},{\"label\":\"Sao Tome and Principe\",\"value\":\"193\"},{\"label\":\"Saudi Arabia\",\"value\":\"194\"},{\"label\":\"Senegal\",\"value\":\"195\"},{\"label\":\"Serbia\",\"value\":\"196\"},{\"label\":\"Seychelles\",\"value\":\"197\"},{\"label\":\"Sierra Leone\",\"value\":\"198\"},{\"label\":\"Singapore\",\"value\":\"199\"},{\"label\":\"Sint Maarten\",\"value\":\"200\"},{\"label\":\"Slovakia\",\"value\":\"201\"},{\"label\":\"Slovenia\",\"value\":\"202\"},{\"label\":\"Solomon Islands\",\"value\":\"203\"},{\"label\":\"Somalia\",\"value\":\"204\"},{\"label\":\"South Africa\",\"value\":\"205\"},{\"label\":\"South Georgia and the South Sandwich Islands\",\"value\":\"206\"},{\"label\":\"South Korea\",\"value\":\"207\"},{\"label\":\"South Sudan\",\"value\":\"208\"},{\"label\":\"Spain\",\"value\":\"209\"},{\"label\":\"Sri Lanka\",\"value\":\"210\"},{\"label\":\"Sudan\",\"value\":\"211\"},{\"label\":\"Suriname\",\"value\":\"212\"},{\"label\":\"Svalbard and Jan Mayen\",\"value\":\"213\"},{\"label\":\"Swaziland\",\"value\":\"214\"},{\"label\":\"Sweden\",\"value\":\"215\"},{\"label\":\"Switzerland\",\"value\":\"216\"},{\"label\":\"Syria\",\"value\":\"217\"},{\"label\":\"Taiwan\",\"value\":\"218\"},{\"label\":\"Tajikistan\",\"value\":\"219\"},{\"label\":\"Tanzania\",\"value\":\"220\"},{\"label\":\"Thailand\",\"value\":\"221\"},{\"label\":\"Timor-Leste (East Timor)\",\"value\":\"222\"},{\"label\":\"Togo\",\"value\":\"223\"},{\"label\":\"Tokelau\",\"value\":\"224\"},{\"label\":\"Tonga\",\"value\":\"225\"},{\"label\":\"Trinidad and Tobago\",\"value\":\"226\"},{\"label\":\"Tunisia\",\"value\":\"227\"},{\"label\":\"Turkey\",\"value\":\"228\"},{\"label\":\"Turkmenistan\",\"value\":\"229\"},{\"label\":\"Turks and Caicos Islands\",\"value\":\"230\"},{\"label\":\"Tuvalu\",\"value\":\"231\"},{\"label\":\"Uganda\",\"value\":\"232\"},{\"label\":\"Ukraine\",\"value\":\"233\"},{\"label\":\"United Arab Emirates\",\"value\":\"234\"},{\"label\":\"United Kingdom\",\"value\":\"235\"},{\"label\":\"United States\",\"value\":\"236\"},{\"label\":\"United States Minor Outlying Islands\",\"value\":\"237\"},{\"label\":\"Uruguay\",\"value\":\"238\"},{\"label\":\"Uzbekistan\",\"value\":\"239\"},{\"label\":\"Vanuatu\",\"value\":\"240\"},{\"label\":\"Vatican City\",\"value\":\"241\"},{\"label\":\"Venezuela\",\"value\":\"242\"},{\"label\":\"Vietnam\",\"value\":\"243\",\"selected\":true},{\"label\":\"Virgin Islands, British\",\"value\":\"244\"},{\"label\":\"Virgin Islands, US\",\"value\":\"245\"},{\"label\":\"Wallis and Futuna\",\"value\":\"246\"},{\"label\":\"Western Sahara\",\"value\":\"247\"},{\"label\":\"Yemen\",\"value\":\"248\"},{\"label\":\"Zambia\",\"value\":\"249\"},{\"label\":\"Zimbabwe\",\"value\":\"250\"}]},{\"type\":\"text\",\"label\":\"_national\",\"className\":\"form-control\",\"name\":\"nation\",\"subtype\":\"text\"},{\"type\":\"text\",\"label\":\"_religion\",\"className\":\"form-control\",\"name\":\"religion\",\"subtype\":\"text\"},{\"type\":\"text\",\"label\":\"_phone\",\"className\":\"form-control\",\"name\":\"phonenumber\",\"subtype\":\"text\"},{\"type\":\"select\",\"label\":\"_diploma\",\"className\":\"form-control\",\"name\":\"diploma\",\"values\":[{\"label\":\"\",\"value\":\"\"},{\"label\":\"master_s_degree\",\"value\":\"0\"},{\"label\":\"Ph_D\",\"value\":\"1\"},{\"label\":\"bachelor\",\"value\":\"2\"},{\"label\":\"university\",\"value\":\"3\"},{\"label\":\"vocational_colleges\",\"value\":\"4\"},{\"label\":\"vocational\",\"value\":\"5\"},{\"label\":\"high_school\",\"value\":\"6\"}]},{\"type\":\"text\",\"label\":\"training_places\",\"className\":\"form-control\",\"name\":\"training_places\",\"subtype\":\"text\"},{\"type\":\"text\",\"label\":\"specialized\",\"className\":\"form-control\",\"name\":\"specialized\",\"subtype\":\"text\"},{\"type\":\"text\",\"label\":\"forms_of_training\",\"className\":\"form-control\",\"name\":\"training_form\",\"subtype\":\"text\"},{\"type\":\"text\",\"label\":\"issue_date_identification_card\",\"className\":\"form-control fc-datepicker\",\"name\":\"days_for_identity\",\"subtype\":\"text\"}]',0,'sent','sent_successfully','',0,0,'','',0);
/*!40000 ALTER TABLE `himalay_tblweb_to_recruitment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblwh_activity_log`
--

DROP TABLE IF EXISTS `himalay_tblwh_activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblwh_activity_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(45) NOT NULL,
  `staffid` int(11) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `note` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblwh_activity_log`
--

LOCK TABLES `himalay_tblwh_activity_log` WRITE;
/*!40000 ALTER TABLE `himalay_tblwh_activity_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblwh_activity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblwh_approval_details`
--

DROP TABLE IF EXISTS `himalay_tblwh_approval_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblwh_approval_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(45) NOT NULL,
  `staffid` varchar(45) DEFAULT NULL,
  `approve` varchar(45) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `approve_action` varchar(255) DEFAULT NULL,
  `reject_action` varchar(255) DEFAULT NULL,
  `approve_value` varchar(255) DEFAULT NULL,
  `reject_value` varchar(255) DEFAULT NULL,
  `staff_approve` int(11) DEFAULT NULL,
  `action` varchar(45) DEFAULT NULL,
  `sender` int(11) DEFAULT NULL,
  `date_send` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblwh_approval_details`
--

LOCK TABLES `himalay_tblwh_approval_details` WRITE;
/*!40000 ALTER TABLE `himalay_tblwh_approval_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblwh_approval_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblwh_approval_setting`
--

DROP TABLE IF EXISTS `himalay_tblwh_approval_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblwh_approval_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `related` varchar(255) NOT NULL,
  `setting` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblwh_approval_setting`
--

LOCK TABLES `himalay_tblwh_approval_setting` WRITE;
/*!40000 ALTER TABLE `himalay_tblwh_approval_setting` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblwh_approval_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblwh_brand`
--

DROP TABLE IF EXISTS `himalay_tblwh_brand`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblwh_brand` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblwh_brand`
--

LOCK TABLES `himalay_tblwh_brand` WRITE;
/*!40000 ALTER TABLE `himalay_tblwh_brand` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblwh_brand` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblwh_custom_fields`
--

DROP TABLE IF EXISTS `himalay_tblwh_custom_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblwh_custom_fields` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `custom_fields_id` int(11) DEFAULT NULL,
  `warehouse_id` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblwh_custom_fields`
--

LOCK TABLES `himalay_tblwh_custom_fields` WRITE;
/*!40000 ALTER TABLE `himalay_tblwh_custom_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblwh_custom_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblwh_goods_delivery_activity_log`
--

DROP TABLE IF EXISTS `himalay_tblwh_goods_delivery_activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblwh_goods_delivery_activity_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(100) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `additional_data` text DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `staffid` int(11) DEFAULT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblwh_goods_delivery_activity_log`
--

LOCK TABLES `himalay_tblwh_goods_delivery_activity_log` WRITE;
/*!40000 ALTER TABLE `himalay_tblwh_goods_delivery_activity_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblwh_goods_delivery_activity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblwh_inventory_serial_numbers`
--

DROP TABLE IF EXISTS `himalay_tblwh_inventory_serial_numbers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblwh_inventory_serial_numbers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `commodity_id` int(11) NOT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `inventory_manage_id` int(11) DEFAULT NULL,
  `serial_number` varchar(255) DEFAULT NULL,
  `is_used` varchar(20) DEFAULT 'no',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblwh_inventory_serial_numbers`
--

LOCK TABLES `himalay_tblwh_inventory_serial_numbers` WRITE;
/*!40000 ALTER TABLE `himalay_tblwh_inventory_serial_numbers` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblwh_inventory_serial_numbers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblwh_loss_adjustment`
--

DROP TABLE IF EXISTS `himalay_tblwh_loss_adjustment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblwh_loss_adjustment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(15) DEFAULT NULL,
  `addfrom` int(11) DEFAULT NULL,
  `reason` longtext DEFAULT NULL,
  `time` datetime DEFAULT NULL,
  `date_create` date NOT NULL,
  `status` int(11) NOT NULL,
  `warehouses` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblwh_loss_adjustment`
--

LOCK TABLES `himalay_tblwh_loss_adjustment` WRITE;
/*!40000 ALTER TABLE `himalay_tblwh_loss_adjustment` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblwh_loss_adjustment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblwh_loss_adjustment_detail`
--

DROP TABLE IF EXISTS `himalay_tblwh_loss_adjustment_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblwh_loss_adjustment_detail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `items` int(11) DEFAULT NULL,
  `unit` int(11) DEFAULT NULL,
  `current_number` int(15) DEFAULT NULL,
  `updates_number` int(15) DEFAULT NULL,
  `loss_adjustment` int(11) DEFAULT NULL,
  `expiry_date` text DEFAULT NULL,
  `lot_number` text DEFAULT NULL,
  `commodity_name` text DEFAULT NULL,
  `serial_number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblwh_loss_adjustment_detail`
--

LOCK TABLES `himalay_tblwh_loss_adjustment_detail` WRITE;
/*!40000 ALTER TABLE `himalay_tblwh_loss_adjustment_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblwh_loss_adjustment_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblwh_model`
--

DROP TABLE IF EXISTS `himalay_tblwh_model`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblwh_model` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` text DEFAULT NULL,
  `brand_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`brand_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblwh_model`
--

LOCK TABLES `himalay_tblwh_model` WRITE;
/*!40000 ALTER TABLE `himalay_tblwh_model` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblwh_model` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblwh_omni_shipments`
--

DROP TABLE IF EXISTS `himalay_tblwh_omni_shipments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblwh_omni_shipments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cart_id` int(11) DEFAULT NULL,
  `shipment_number` varchar(100) DEFAULT NULL,
  `planned_shipping_date` datetime DEFAULT NULL,
  `shipment_status` varchar(50) DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `goods_delivery_id` int(11) DEFAULT NULL,
  `shipment_hash` varchar(32) DEFAULT NULL,
  `order_id` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblwh_omni_shipments`
--

LOCK TABLES `himalay_tblwh_omni_shipments` WRITE;
/*!40000 ALTER TABLE `himalay_tblwh_omni_shipments` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblwh_omni_shipments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblwh_order_return_details`
--

DROP TABLE IF EXISTS `himalay_tblwh_order_return_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblwh_order_return_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_return_id` int(11) NOT NULL,
  `rel_type_detail_id` int(11) DEFAULT NULL,
  `commodity_code` int(11) DEFAULT NULL,
  `commodity_name` text DEFAULT NULL,
  `quantity` decimal(15,2) DEFAULT 0.00,
  `unit_id` int(11) DEFAULT NULL,
  `unit_price` decimal(15,2) DEFAULT 0.00,
  `sub_total` decimal(15,2) DEFAULT 0.00,
  `tax_id` text DEFAULT NULL,
  `tax_rate` text DEFAULT NULL,
  `tax_name` text DEFAULT NULL,
  `total_amount` decimal(15,2) DEFAULT 0.00,
  `discount` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `total_after_discount` decimal(15,2) DEFAULT 0.00,
  `reason_return` varchar(200) DEFAULT NULL,
  `purchase_price` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblwh_order_return_details`
--

LOCK TABLES `himalay_tblwh_order_return_details` WRITE;
/*!40000 ALTER TABLE `himalay_tblwh_order_return_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblwh_order_return_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblwh_order_returns`
--

DROP TABLE IF EXISTS `himalay_tblwh_order_returns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblwh_order_returns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(50) NOT NULL COMMENT 'manual, sales_return_order, purchasing_return_order',
  `return_type` varchar(50) DEFAULT NULL COMMENT 'manual, partially, fully',
  `company_id` int(11) DEFAULT NULL,
  `company_name` varchar(500) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phonenumber` varchar(20) DEFAULT NULL,
  `order_number` varchar(500) DEFAULT NULL,
  `order_date` datetime DEFAULT NULL,
  `number_of_item` decimal(15,2) DEFAULT 0.00,
  `order_total` decimal(15,2) DEFAULT 0.00,
  `order_return_number` varchar(200) DEFAULT NULL,
  `order_return_name` varchar(500) DEFAULT NULL,
  `fee_return_order` decimal(15,2) DEFAULT 0.00,
  `refund_loyaty_point` int(11) DEFAULT 0,
  `subtotal` decimal(15,2) DEFAULT 0.00,
  `total_amount` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `additional_discount` decimal(15,2) DEFAULT 0.00,
  `adjustment_amount` decimal(15,2) DEFAULT 0.00,
  `total_after_discount` decimal(15,2) DEFAULT 0.00,
  `return_policies_information` text DEFAULT NULL,
  `admin_note` text DEFAULT NULL,
  `approval` int(11) DEFAULT 0,
  `datecreated` datetime DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `currency` int(11) DEFAULT NULL,
  `receipt_delivery_id` int(1) DEFAULT 0,
  `return_reason` longtext DEFAULT NULL,
  `status` varchar(30) DEFAULT 'draft',
  `discount_type` text DEFAULT NULL,
  `receipt_delivery_type` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblwh_order_returns`
--

LOCK TABLES `himalay_tblwh_order_returns` WRITE;
/*!40000 ALTER TABLE `himalay_tblwh_order_returns` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblwh_order_returns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblwh_order_returns_refunds`
--

DROP TABLE IF EXISTS `himalay_tblwh_order_returns_refunds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblwh_order_returns_refunds` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `order_return_id` int(11) DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `refunded_on` date DEFAULT NULL,
  `payment_mode` varchar(40) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `amount` decimal(15,2) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblwh_order_returns_refunds`
--

LOCK TABLES `himalay_tblwh_order_returns_refunds` WRITE;
/*!40000 ALTER TABLE `himalay_tblwh_order_returns_refunds` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblwh_order_returns_refunds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblwh_packing_list_details`
--

DROP TABLE IF EXISTS `himalay_tblwh_packing_list_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblwh_packing_list_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `packing_list_id` int(11) NOT NULL,
  `delivery_detail_id` int(11) DEFAULT NULL,
  `commodity_code` int(11) DEFAULT NULL,
  `commodity_name` text DEFAULT NULL,
  `quantity` decimal(15,2) DEFAULT 0.00,
  `unit_id` int(11) DEFAULT NULL,
  `unit_price` decimal(15,2) DEFAULT 0.00,
  `sub_total` decimal(15,2) DEFAULT 0.00,
  `tax_id` text DEFAULT NULL,
  `tax_rate` text DEFAULT NULL,
  `tax_name` text DEFAULT NULL,
  `total_amount` decimal(15,2) DEFAULT 0.00,
  `discount` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `total_after_discount` decimal(15,2) DEFAULT 0.00,
  `serial_number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblwh_packing_list_details`
--

LOCK TABLES `himalay_tblwh_packing_list_details` WRITE;
/*!40000 ALTER TABLE `himalay_tblwh_packing_list_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblwh_packing_list_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblwh_packing_lists`
--

DROP TABLE IF EXISTS `himalay_tblwh_packing_lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblwh_packing_lists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `delivery_note_id` int(11) DEFAULT NULL,
  `packing_list_number` varchar(100) DEFAULT NULL,
  `packing_list_name` varchar(200) DEFAULT NULL,
  `width` decimal(15,2) DEFAULT 0.00,
  `height` decimal(15,2) DEFAULT 0.00,
  `lenght` decimal(15,2) DEFAULT 0.00,
  `weight` decimal(15,2) DEFAULT 0.00,
  `volume` decimal(15,2) DEFAULT 0.00,
  `clientid` int(11) DEFAULT NULL,
  `subtotal` decimal(15,2) DEFAULT 0.00,
  `total_amount` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `additional_discount` decimal(15,2) DEFAULT 0.00,
  `total_after_discount` decimal(15,2) DEFAULT 0.00,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT NULL,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT NULL,
  `client_note` text DEFAULT NULL,
  `admin_note` text DEFAULT NULL,
  `approval` int(11) DEFAULT 0,
  `datecreated` datetime DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `type_of_packing_list` varchar(100) DEFAULT 'total',
  `delivery_status` varchar(100) DEFAULT 'wh_ready_to_deliver',
  `shipping_fee` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblwh_packing_lists`
--

LOCK TABLES `himalay_tblwh_packing_lists` WRITE;
/*!40000 ALTER TABLE `himalay_tblwh_packing_lists` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblwh_packing_lists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblwh_series`
--

DROP TABLE IF EXISTS `himalay_tblwh_series`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblwh_series` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` text DEFAULT NULL,
  `model_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`model_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblwh_series`
--

LOCK TABLES `himalay_tblwh_series` WRITE;
/*!40000 ALTER TABLE `himalay_tblwh_series` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblwh_series` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblwh_staff_warehouses`
--

DROP TABLE IF EXISTS `himalay_tblwh_staff_warehouses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblwh_staff_warehouses` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblwh_staff_warehouses`
--

LOCK TABLES `himalay_tblwh_staff_warehouses` WRITE;
/*!40000 ALTER TABLE `himalay_tblwh_staff_warehouses` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblwh_staff_warehouses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblwh_sub_group`
--

DROP TABLE IF EXISTS `himalay_tblwh_sub_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblwh_sub_group` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sub_group_code` varchar(100) DEFAULT NULL,
  `sub_group_name` text DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  `display` int(1) DEFAULT NULL COMMENT 'display 1: display (yes)  0: not displayed (no)',
  `note` text DEFAULT NULL,
  `group_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblwh_sub_group`
--

LOCK TABLES `himalay_tblwh_sub_group` WRITE;
/*!40000 ALTER TABLE `himalay_tblwh_sub_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblwh_sub_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblwhatsapp_api_debug_log`
--

DROP TABLE IF EXISTS `himalay_tblwhatsapp_api_debug_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblwhatsapp_api_debug_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `api_endpoint` varchar(255) DEFAULT NULL,
  `phone_number_id` varchar(255) DEFAULT NULL,
  `access_token` text DEFAULT NULL,
  `business_account_id` varchar(255) DEFAULT NULL,
  `response_code` varchar(4) NOT NULL,
  `response_data` text NOT NULL,
  `send_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`send_json`)),
  `message_category` varchar(50) NOT NULL,
  `category_params` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`category_params`)),
  `merge_field_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`merge_field_data`)),
  `recorded_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblwhatsapp_api_debug_log`
--

LOCK TABLES `himalay_tblwhatsapp_api_debug_log` WRITE;
/*!40000 ALTER TABLE `himalay_tblwhatsapp_api_debug_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblwhatsapp_api_debug_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblwhatsapp_templates`
--

DROP TABLE IF EXISTS `himalay_tblwhatsapp_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblwhatsapp_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_id` bigint(20) unsigned NOT NULL COMMENT 'id from api',
  `template_name` varchar(255) NOT NULL,
  `language` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  `category` varchar(100) NOT NULL,
  `header_data_format` varchar(10) NOT NULL,
  `header_data_text` text DEFAULT NULL,
  `header_params_count` int(11) NOT NULL,
  `body_data` text NOT NULL,
  `body_params_count` int(11) NOT NULL,
  `footer_data` text DEFAULT NULL,
  `footer_params_count` int(11) NOT NULL,
  `buttons_data` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `template_id` (`template_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblwhatsapp_templates`
--

LOCK TABLES `himalay_tblwhatsapp_templates` WRITE;
/*!40000 ALTER TABLE `himalay_tblwhatsapp_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblwhatsapp_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblwhatsapp_templates_mapping`
--

DROP TABLE IF EXISTS `himalay_tblwhatsapp_templates_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblwhatsapp_templates_mapping` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_id` int(11) NOT NULL,
  `category` varchar(100) NOT NULL,
  `send_to` varchar(50) NOT NULL,
  `header_params` varchar(255) NOT NULL,
  `body_params` varchar(255) NOT NULL,
  `footer_params` varchar(255) NOT NULL,
  `active` tinyint(4) NOT NULL DEFAULT 1,
  `debug_mode` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblwhatsapp_templates_mapping`
--

LOCK TABLES `himalay_tblwhatsapp_templates_mapping` WRITE;
/*!40000 ALTER TABLE `himalay_tblwhatsapp_templates_mapping` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblwhatsapp_templates_mapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblwork_shift`
--

DROP TABLE IF EXISTS `himalay_tblwork_shift`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblwork_shift` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shift_code` varchar(45) NOT NULL,
  `shift_name` varchar(200) NOT NULL,
  `shift_type` varchar(200) NOT NULL,
  `department` varchar(45) DEFAULT NULL,
  `position` varchar(45) DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  `staff` text DEFAULT NULL,
  `date_create` date DEFAULT NULL,
  `from_date` date DEFAULT NULL,
  `to_date` date DEFAULT NULL,
  `shifts_detail` text NOT NULL,
  `type_shiftwork` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblwork_shift`
--

LOCK TABLES `himalay_tblwork_shift` WRITE;
/*!40000 ALTER TABLE `himalay_tblwork_shift` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblwork_shift` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblwork_shift_detail`
--

DROP TABLE IF EXISTS `himalay_tblwork_shift_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblwork_shift_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `shift_id` int(11) DEFAULT NULL,
  `work_shift_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblwork_shift_detail`
--

LOCK TABLES `himalay_tblwork_shift_detail` WRITE;
/*!40000 ALTER TABLE `himalay_tblwork_shift_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblwork_shift_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblwork_shift_detail_day_name`
--

DROP TABLE IF EXISTS `himalay_tblwork_shift_detail_day_name`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblwork_shift_detail_day_name` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `day_name` varchar(45) DEFAULT NULL,
  `shift_id` int(11) DEFAULT NULL,
  `work_shift_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblwork_shift_detail_day_name`
--

LOCK TABLES `himalay_tblwork_shift_detail_day_name` WRITE;
/*!40000 ALTER TABLE `himalay_tblwork_shift_detail_day_name` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblwork_shift_detail_day_name` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblwork_shift_detail_number_day`
--

DROP TABLE IF EXISTS `himalay_tblwork_shift_detail_number_day`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblwork_shift_detail_number_day` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `number` int(11) DEFAULT NULL,
  `shift_id` int(11) DEFAULT NULL,
  `work_shift_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblwork_shift_detail_number_day`
--

LOCK TABLES `himalay_tblwork_shift_detail_number_day` WRITE;
/*!40000 ALTER TABLE `himalay_tblwork_shift_detail_number_day` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblwork_shift_detail_number_day` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himalay_tblworkload_dayoff`
--

DROP TABLE IF EXISTS `himalay_tblworkload_dayoff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himalay_tblworkload_dayoff` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reason` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `addedfrom` int(11) NOT NULL,
  `datecreated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himalay_tblworkload_dayoff`
--

LOCK TABLES `himalay_tblworkload_dayoff` WRITE;
/*!40000 ALTER TABLE `himalay_tblworkload_dayoff` DISABLE KEYS */;
/*!40000 ALTER TABLE `himalay_tblworkload_dayoff` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-14 20:37:48
