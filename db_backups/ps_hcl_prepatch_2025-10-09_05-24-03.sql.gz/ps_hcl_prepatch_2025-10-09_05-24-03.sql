/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.5.27-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: ps_hcl
-- ------------------------------------------------------
-- Server version	10.5.27-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `hcl_tblacc_account_history`
--

DROP TABLE IF EXISTS `hcl_tblacc_account_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcl_tblacc_account_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account` int(11) NOT NULL,
  `debit` decimal(15,2) NOT NULL DEFAULT 0.00,
  `credit` decimal(15,2) NOT NULL DEFAULT 0.00,
  `description` text DEFAULT NULL,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(45) DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `customer` int(11) DEFAULT NULL,
  `reconcile` int(11) NOT NULL DEFAULT 0,
  `split` int(11) NOT NULL DEFAULT 0,
  `item` int(11) DEFAULT NULL,
  `paid` int(1) NOT NULL DEFAULT 0,
  `date` date DEFAULT NULL,
  `tax` int(11) DEFAULT NULL,
  `payslip_type` varchar(45) DEFAULT NULL,
  `vendor` int(11) DEFAULT NULL,
  `itemable_id` int(11) DEFAULT NULL,
  `cleared` int(11) NOT NULL DEFAULT 0,
  `sub_type` varchar(45) DEFAULT NULL,
  `bill_item` int(11) NOT NULL DEFAULT 0,
  `number` varchar(100) DEFAULT NULL,
  `issue` int(11) NOT NULL DEFAULT 0,
  `added_from_reconcile` int(11) NOT NULL DEFAULT 0,
  `bank_reconcile` int(11) NOT NULL DEFAULT 0,
  `currency_rate` decimal(15,6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcl_tblacc_account_history`
--

LOCK TABLES `hcl_tblacc_account_history` WRITE;
/*!40000 ALTER TABLE `hcl_tblacc_account_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `hcl_tblacc_account_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcl_tblacc_account_type_details`
--

DROP TABLE IF EXISTS `hcl_tblacc_account_type_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcl_tblacc_account_type_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_type_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `note` text DEFAULT NULL,
  `statement_of_cash_flows` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcl_tblacc_account_type_details`
--

LOCK TABLES `hcl_tblacc_account_type_details` WRITE;
/*!40000 ALTER TABLE `hcl_tblacc_account_type_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `hcl_tblacc_account_type_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcl_tblacc_accounts`
--

DROP TABLE IF EXISTS `hcl_tblacc_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcl_tblacc_accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `key_name` varchar(255) DEFAULT NULL,
  `number` varchar(45) DEFAULT NULL,
  `parent_account` int(11) DEFAULT NULL,
  `account_type_id` int(11) NOT NULL,
  `account_detail_type_id` int(11) NOT NULL,
  `balance` decimal(15,2) DEFAULT NULL,
  `balance_as_of` date DEFAULT NULL,
  `description` text DEFAULT NULL,
  `default_account` int(11) NOT NULL DEFAULT 0,
  `active` int(11) NOT NULL DEFAULT 1,
  `access_token` text DEFAULT NULL,
  `account_id` varchar(255) DEFAULT NULL,
  `plaid_status` tinyint(5) NOT NULL DEFAULT 0 COMMENT '1=>verified, 0=>not verified',
  `plaid_account_name` varchar(255) DEFAULT NULL,
  `bank_account` text DEFAULT NULL,
  `bank_routing` text DEFAULT NULL,
  `address_line_1` text DEFAULT NULL,
  `address_line_2` text DEFAULT NULL,
  `bank_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcl_tblacc_accounts`
--

LOCK TABLES `hcl_tblacc_accounts` WRITE;
/*!40000 ALTER TABLE `hcl_tblacc_accounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `hcl_tblacc_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcl_tblacc_bank_reconciles`
--

DROP TABLE IF EXISTS `hcl_tblacc_bank_reconciles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcl_tblacc_bank_reconciles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account` int(11) NOT NULL,
  `opening_balance` decimal(15,2) NOT NULL DEFAULT 0.00,
  `beginning_balance` decimal(15,2) NOT NULL,
  `ending_balance` decimal(15,2) NOT NULL,
  `ending_date` date NOT NULL,
  `finish` int(11) NOT NULL DEFAULT 0,
  `debits_for_period` decimal(15,2) NOT NULL,
  `credits_for_period` decimal(15,2) NOT NULL,
  `dateadded` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcl_tblacc_bank_reconciles`
--

LOCK TABLES `hcl_tblacc_bank_reconciles` WRITE;
/*!40000 ALTER TABLE `hcl_tblacc_bank_reconciles` DISABLE KEYS */;
/*!40000 ALTER TABLE `hcl_tblacc_bank_reconciles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcl_tblacc_banking_rule_details`
--

DROP TABLE IF EXISTS `hcl_tblacc_banking_rule_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcl_tblacc_banking_rule_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rule_id` int(11) NOT NULL,
  `type` varchar(45) DEFAULT NULL,
  `subtype` varchar(45) DEFAULT NULL,
  `text` varchar(255) DEFAULT NULL,
  `subtype_amount` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcl_tblacc_banking_rule_details`
--

LOCK TABLES `hcl_tblacc_banking_rule_details` WRITE;
/*!40000 ALTER TABLE `hcl_tblacc_banking_rule_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `hcl_tblacc_banking_rule_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcl_tblacc_banking_rules`
--

DROP TABLE IF EXISTS `hcl_tblacc_banking_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcl_tblacc_banking_rules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `transaction` varchar(45) DEFAULT NULL,
  `following` varchar(45) DEFAULT NULL,
  `then` varchar(45) DEFAULT NULL,
  `payment_account` int(11) DEFAULT NULL,
  `deposit_to` int(11) DEFAULT NULL,
  `auto_add` int(11) NOT NULL DEFAULT 0,
  `mapping_type` varchar(25) DEFAULT NULL,
  `account` int(11) DEFAULT NULL,
  `split_percentage` text DEFAULT NULL,
  `split_amount` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcl_tblacc_banking_rules`
--

LOCK TABLES `hcl_tblacc_banking_rules` WRITE;
/*!40000 ALTER TABLE `hcl_tblacc_banking_rules` DISABLE KEYS */;
/*!40000 ALTER TABLE `hcl_tblacc_banking_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcl_tblacc_bill_mappings`
--

DROP TABLE IF EXISTS `hcl_tblacc_bill_mappings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcl_tblacc_bill_mappings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bill_id` int(11) DEFAULT NULL,
  `type` varchar(25) DEFAULT NULL,
  `account` int(11) DEFAULT NULL,
  `amount` decimal(15,2) DEFAULT NULL,
  `item_id` int(11) NOT NULL DEFAULT 0,
  `qty` decimal(15,2) NOT NULL DEFAULT 0.00,
  `cost` decimal(15,2) NOT NULL DEFAULT 0.00,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcl_tblacc_bill_mappings`
--

LOCK TABLES `hcl_tblacc_bill_mappings` WRITE;
/*!40000 ALTER TABLE `hcl_tblacc_bill_mappings` DISABLE KEYS */;
/*!40000 ALTER TABLE `hcl_tblacc_bill_mappings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcl_tblacc_budget_details`
--

DROP TABLE IF EXISTS `hcl_tblacc_budget_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcl_tblacc_budget_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `budget_id` int(11) NOT NULL,
  `month` int(11) NOT NULL,
  `year` int(11) NOT NULL,
  `account` int(11) DEFAULT NULL,
  `amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcl_tblacc_budget_details`
--

LOCK TABLES `hcl_tblacc_budget_details` WRITE;
/*!40000 ALTER TABLE `hcl_tblacc_budget_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `hcl_tblacc_budget_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcl_tblacc_budgets`
--

DROP TABLE IF EXISTS `hcl_tblacc_budgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcl_tblacc_budgets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `year` int(11) NOT NULL,
  `name` varchar(200) DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  `data_source` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcl_tblacc_budgets`
--

LOCK TABLES `hcl_tblacc_budgets` WRITE;
/*!40000 ALTER TABLE `hcl_tblacc_budgets` DISABLE KEYS */;
/*!40000 ALTER TABLE `hcl_tblacc_budgets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcl_tblacc_check_details`
--

DROP TABLE IF EXISTS `hcl_tblacc_check_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcl_tblacc_check_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `check_id` int(11) DEFAULT NULL,
  `bill` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcl_tblacc_check_details`
--

LOCK TABLES `hcl_tblacc_check_details` WRITE;
/*!40000 ALTER TABLE `hcl_tblacc_check_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `hcl_tblacc_check_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcl_tblacc_checks`
--

DROP TABLE IF EXISTS `hcl_tblacc_checks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcl_tblacc_checks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(25) DEFAULT NULL,
  `amount` decimal(15,2) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `memo` varchar(255) DEFAULT NULL,
  `dateadded` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `bank_account` int(11) NOT NULL,
  `number` int(11) NOT NULL,
  `signed` int(11) NOT NULL DEFAULT 0,
  `include_company_name_address` int(11) NOT NULL DEFAULT 1,
  `include_routing_account_numbers` int(11) NOT NULL DEFAULT 1,
  `bill` int(11) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `zip` varchar(15) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `issue` int(11) DEFAULT NULL,
  `include_check_number` int(11) NOT NULL DEFAULT 1,
  `include_bank_name` int(11) NOT NULL DEFAULT 1,
  `bank_name` varchar(255) DEFAULT NULL,
  `address_line_1` text DEFAULT NULL,
  `address_line_2` text DEFAULT NULL,
  `vendor_city` varchar(100) DEFAULT NULL,
  `vendor_zip` varchar(15) DEFAULT NULL,
  `vendor_state` varchar(50) DEFAULT NULL,
  `vendor_address` text DEFAULT NULL,
  `reason_for_void` text DEFAULT NULL,
  `bill_items` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcl_tblacc_checks`
--

LOCK TABLES `hcl_tblacc_checks` WRITE;
/*!40000 ALTER TABLE `hcl_tblacc_checks` DISABLE KEYS */;
/*!40000 ALTER TABLE `hcl_tblacc_checks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcl_tblacc_checks_printed`
--

DROP TABLE IF EXISTS `hcl_tblacc_checks_printed`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcl_tblacc_checks_printed` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `check_id` int(11) DEFAULT NULL,
  `bank_account` int(11) DEFAULT NULL,
  `first_check_number` int(11) DEFAULT NULL,
  `printed_at` datetime DEFAULT NULL,
  `printed_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcl_tblacc_checks_printed`
--

LOCK TABLES `hcl_tblacc_checks_printed` WRITE;
/*!40000 ALTER TABLE `hcl_tblacc_checks_printed` DISABLE KEYS */;
/*!40000 ALTER TABLE `hcl_tblacc_checks_printed` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcl_tblacc_expense_category_mapping_details`
--

DROP TABLE IF EXISTS `hcl_tblacc_expense_category_mapping_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcl_tblacc_expense_category_mapping_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_mapping_id` int(11) NOT NULL,
  `payment_mode_id` int(11) NOT NULL,
  `payment_account` int(11) NOT NULL DEFAULT 0,
  `deposit_to` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcl_tblacc_expense_category_mapping_details`
--

LOCK TABLES `hcl_tblacc_expense_category_mapping_details` WRITE;
/*!40000 ALTER TABLE `hcl_tblacc_expense_category_mapping_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `hcl_tblacc_expense_category_mapping_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcl_tblacc_expense_category_mappings`
--

DROP TABLE IF EXISTS `hcl_tblacc_expense_category_mappings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcl_tblacc_expense_category_mappings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `payment_account` int(11) NOT NULL DEFAULT 0,
  `deposit_to` int(11) NOT NULL DEFAULT 0,
  `preferred_payment_method` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcl_tblacc_expense_category_mappings`
--

LOCK TABLES `hcl_tblacc_expense_category_mappings` WRITE;
/*!40000 ALTER TABLE `hcl_tblacc_expense_category_mappings` DISABLE KEYS */;
/*!40000 ALTER TABLE `hcl_tblacc_expense_category_mappings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcl_tblacc_income_statement_modifications`
--

DROP TABLE IF EXISTS `hcl_tblacc_income_statement_modifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcl_tblacc_income_statement_modifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `account` int(11) DEFAULT NULL,
  `active` int(11) NOT NULL DEFAULT 1,
  `account_type` int(11) DEFAULT NULL,
  `options` text DEFAULT NULL,
  `dateadded` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `type` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcl_tblacc_income_statement_modifications`
--

LOCK TABLES `hcl_tblacc_income_statement_modifications` WRITE;
/*!40000 ALTER TABLE `hcl_tblacc_income_statement_modifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `hcl_tblacc_income_statement_modifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcl_tblacc_item_automatics`
--

DROP TABLE IF EXISTS `hcl_tblacc_item_automatics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcl_tblacc_item_automatics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL,
  `inventory_asset_account` int(11) NOT NULL DEFAULT 0,
  `income_account` int(11) NOT NULL DEFAULT 0,
  `expense_account` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcl_tblacc_item_automatics`
--

LOCK TABLES `hcl_tblacc_item_automatics` WRITE;
/*!40000 ALTER TABLE `hcl_tblacc_item_automatics` DISABLE KEYS */;
/*!40000 ALTER TABLE `hcl_tblacc_item_automatics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcl_tblacc_journal_entries`
--

DROP TABLE IF EXISTS `hcl_tblacc_journal_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcl_tblacc_journal_entries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `number` varchar(45) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `journal_date` date DEFAULT NULL,
  `amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `reference` varchar(100) DEFAULT NULL,
  `recurring` int(11) NOT NULL DEFAULT 0,
  `recurring_type` varchar(10) DEFAULT NULL,
  `custom_recurring` tinyint(1) NOT NULL DEFAULT 0,
  `cycles` int(11) NOT NULL DEFAULT 0,
  `total_cycles` int(11) NOT NULL DEFAULT 0,
  `is_recurring_from` int(11) DEFAULT NULL,
  `last_recurring_date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcl_tblacc_journal_entries`
--

LOCK TABLES `hcl_tblacc_journal_entries` WRITE;
/*!40000 ALTER TABLE `hcl_tblacc_journal_entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `hcl_tblacc_journal_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcl_tblacc_matched_transactions`
--

DROP TABLE IF EXISTS `hcl_tblacc_matched_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcl_tblacc_matched_transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_history_id` int(11) DEFAULT NULL,
  `history_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(255) DEFAULT NULL,
  `amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `company` int(11) DEFAULT NULL,
  `reconcile` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcl_tblacc_matched_transactions`
--

LOCK TABLES `hcl_tblacc_matched_transactions` WRITE;
/*!40000 ALTER TABLE `hcl_tblacc_matched_transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `hcl_tblacc_matched_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcl_tblacc_pay_bill_details`
--

DROP TABLE IF EXISTS `hcl_tblacc_pay_bill_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcl_tblacc_pay_bill_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pay_bill` int(11) DEFAULT NULL,
  `bill_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcl_tblacc_pay_bill_details`
--

LOCK TABLES `hcl_tblacc_pay_bill_details` WRITE;
/*!40000 ALTER TABLE `hcl_tblacc_pay_bill_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `hcl_tblacc_pay_bill_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcl_tblacc_pay_bill_item_paid`
--

DROP TABLE IF EXISTS `hcl_tblacc_pay_bill_item_paid`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcl_tblacc_pay_bill_item_paid` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pay_bill_id` int(11) NOT NULL DEFAULT 0,
  `item_id` int(11) DEFAULT NULL,
  `item_name` varchar(255) DEFAULT NULL,
  `item_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `amount_paid` decimal(15,2) NOT NULL DEFAULT 0.00,
  `check_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcl_tblacc_pay_bill_item_paid`
--

LOCK TABLES `hcl_tblacc_pay_bill_item_paid` WRITE;
/*!40000 ALTER TABLE `hcl_tblacc_pay_bill_item_paid` DISABLE KEYS */;
/*!40000 ALTER TABLE `hcl_tblacc_pay_bill_item_paid` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcl_tblacc_pay_bills`
--

DROP TABLE IF EXISTS `hcl_tblacc_pay_bills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcl_tblacc_pay_bills` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `expense` int(11) DEFAULT NULL,
  `amount` decimal(15,2) DEFAULT NULL,
  `reference_no` varchar(100) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `dateadded` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `company` int(11) DEFAULT NULL,
  `account_debit` int(11) DEFAULT NULL,
  `account_credit` int(11) DEFAULT NULL,
  `bill` int(11) NOT NULL DEFAULT 0,
  `vendor` int(11) NOT NULL DEFAULT 0,
  `pay_number` int(11) DEFAULT NULL,
  `payment_method` varchar(255) DEFAULT NULL,
  `bill_items` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcl_tblacc_pay_bills`
--

LOCK TABLES `hcl_tblacc_pay_bills` WRITE;
/*!40000 ALTER TABLE `hcl_tblacc_pay_bills` DISABLE KEYS */;
/*!40000 ALTER TABLE `hcl_tblacc_pay_bills` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcl_tblacc_payment_mode_mappings`
--

DROP TABLE IF EXISTS `hcl_tblacc_payment_mode_mappings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcl_tblacc_payment_mode_mappings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `payment_mode_id` int(11) NOT NULL,
  `payment_account` int(11) NOT NULL DEFAULT 0,
  `deposit_to` int(11) NOT NULL DEFAULT 0,
  `expense_payment_account` int(11) NOT NULL DEFAULT 0,
  `expense_deposit_to` int(11) NOT NULL DEFAULT 0,
  `credit_note_refund_payment_account` int(11) NOT NULL DEFAULT 0,
  `credit_note_refund_deposit_to` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcl_tblacc_payment_mode_mappings`
--

LOCK TABLES `hcl_tblacc_payment_mode_mappings` WRITE;
/*!40000 ALTER TABLE `hcl_tblacc_payment_mode_mappings` DISABLE KEYS */;
/*!40000 ALTER TABLE `hcl_tblacc_payment_mode_mappings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcl_tblacc_plaid_transaction_logs`
--

DROP TABLE IF EXISTS `hcl_tblacc_plaid_transaction_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcl_tblacc_plaid_transaction_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bank_id` int(11) DEFAULT NULL,
  `last_updated` date DEFAULT NULL,
  `transaction_count` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `addedFrom` int(11) DEFAULT NULL,
  `company` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcl_tblacc_plaid_transaction_logs`
--

LOCK TABLES `hcl_tblacc_plaid_transaction_logs` WRITE;
/*!40000 ALTER TABLE `hcl_tblacc_plaid_transaction_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `hcl_tblacc_plaid_transaction_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcl_tblacc_print_later`
--

DROP TABLE IF EXISTS `hcl_tblacc_print_later`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcl_tblacc_print_later` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(45) DEFAULT NULL,
  `account` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcl_tblacc_print_later`
--

LOCK TABLES `hcl_tblacc_print_later` WRITE;
/*!40000 ALTER TABLE `hcl_tblacc_print_later` DISABLE KEYS */;
/*!40000 ALTER TABLE `hcl_tblacc_print_later` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcl_tblacc_reconciles`
--

DROP TABLE IF EXISTS `hcl_tblacc_reconciles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcl_tblacc_reconciles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account` int(11) NOT NULL,
  `beginning_balance` decimal(15,2) NOT NULL,
  `ending_balance` decimal(15,2) NOT NULL,
  `ending_date` date NOT NULL,
  `expense_date` date DEFAULT NULL,
  `service_charge` decimal(15,2) DEFAULT NULL,
  `expense_account` int(11) DEFAULT NULL,
  `income_date` date DEFAULT NULL,
  `interest_earned` decimal(15,2) DEFAULT NULL,
  `income_account` int(11) DEFAULT NULL,
  `finish` int(11) NOT NULL DEFAULT 0,
  `opening_balance` int(11) NOT NULL DEFAULT 0,
  `debits_for_period` decimal(15,2) DEFAULT NULL,
  `credits_for_period` decimal(15,2) DEFAULT NULL,
  `dateadded` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcl_tblacc_reconciles`
--

LOCK TABLES `hcl_tblacc_reconciles` WRITE;
/*!40000 ALTER TABLE `hcl_tblacc_reconciles` DISABLE KEYS */;
/*!40000 ALTER TABLE `hcl_tblacc_reconciles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcl_tblacc_tax_mappings`
--

DROP TABLE IF EXISTS `hcl_tblacc_tax_mappings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcl_tblacc_tax_mappings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tax_id` int(11) NOT NULL,
  `payment_account` int(11) NOT NULL DEFAULT 0,
  `deposit_to` int(11) NOT NULL DEFAULT 0,
  `expense_payment_account` int(11) NOT NULL DEFAULT 0,
  `expense_deposit_to` int(11) NOT NULL DEFAULT 0,
  `purchase_payment_account` int(11) NOT NULL DEFAULT 0,
  `purchase_deposit_to` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcl_tblacc_tax_mappings`
--

LOCK TABLES `hcl_tblacc_tax_mappings` WRITE;
/*!40000 ALTER TABLE `hcl_tblacc_tax_mappings` DISABLE KEYS */;
/*!40000 ALTER TABLE `hcl_tblacc_tax_mappings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcl_tblacc_transaction_bankings`
--

DROP TABLE IF EXISTS `hcl_tblacc_transaction_bankings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcl_tblacc_transaction_bankings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `withdrawals` decimal(15,2) NOT NULL DEFAULT 0.00,
  `deposits` decimal(15,2) NOT NULL DEFAULT 0.00,
  `payee` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `transaction_id` varchar(150) DEFAULT NULL,
  `bank_id` int(11) DEFAULT NULL,
  `status` tinyint(5) NOT NULL DEFAULT 0 COMMENT '1=>posted, 2=>pending',
  `matched` int(11) NOT NULL DEFAULT 0,
  `reconcile` int(11) NOT NULL DEFAULT 0,
  `adjusted` int(11) NOT NULL DEFAULT 0,
  `is_imported` int(11) NOT NULL DEFAULT 0,
  `banking_rule` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcl_tblacc_transaction_bankings`
--

LOCK TABLES `hcl_tblacc_transaction_bankings` WRITE;
/*!40000 ALTER TABLE `hcl_tblacc_transaction_bankings` DISABLE KEYS */;
/*!40000 ALTER TABLE `hcl_tblacc_transaction_bankings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcl_tblacc_transfers`
--

DROP TABLE IF EXISTS `hcl_tblacc_transfers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcl_tblacc_transfers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transfer_funds_from` int(11) NOT NULL,
  `transfer_funds_to` int(11) NOT NULL,
  `transfer_amount` decimal(15,2) DEFAULT NULL,
  `date` varchar(45) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcl_tblacc_transfers`
--

LOCK TABLES `hcl_tblacc_transfers` WRITE;
/*!40000 ALTER TABLE `hcl_tblacc_transfers` DISABLE KEYS */;
/*!40000 ALTER TABLE `hcl_tblacc_transfers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcl_tblaccount_planning`
--

DROP TABLE IF EXISTS `hcl_tblaccount_planning`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcl_tblaccount_planning` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) NOT NULL,
  `vision` varchar(255) DEFAULT NULL,
  `mission` varchar(255) DEFAULT NULL,
  `lead_generation` varchar(45) DEFAULT NULL,
  `current_service_know_pmax` varchar(45) DEFAULT NULL,
  `current_service_facebook` varchar(45) DEFAULT NULL,
  `current_service_sem` varchar(45) DEFAULT NULL,
  `objectives` varchar(255) DEFAULT NULL,
  `threat` varchar(255) DEFAULT NULL,
  `opportunity` varchar(255) DEFAULT NULL,
  `criteria_to_success` varchar(255) DEFAULT NULL,
  `constraints` varchar(255) DEFAULT NULL,
  `data_tree` longtext DEFAULT NULL,
  `latest_update` date DEFAULT NULL,
  `new_update` date DEFAULT NULL,
  `product` varchar(255) DEFAULT NULL,
  `sale_channel_online` varchar(255) DEFAULT NULL,
  `sale_channel_offline` varchar(255) DEFAULT NULL,
  `revenue_next_year` varchar(255) DEFAULT NULL,
  `wallet_share` varchar(255) DEFAULT NULL,
  `client_status` varchar(255) DEFAULT NULL,
  `bcg_model` varchar(255) DEFAULT NULL,
  `margin` varchar(255) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcl_tblaccount_planning`
--

LOCK TABLES `hcl_tblaccount_planning` WRITE;
/*!40000 ALTER TABLE `hcl_tblaccount_planning` DISABLE KEYS */;
/*!40000 ALTER TABLE `hcl_tblaccount_planning` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcl_tblaccount_planning_current_service`
--

DROP TABLE IF EXISTS `hcl_tblaccount_planning_current_service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcl_tblaccount_planning_current_service` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_planning_id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `potential` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcl_tblaccount_planning_current_service`
--

LOCK TABLES `hcl_tblaccount_planning_current_service` WRITE;
/*!40000 ALTER TABLE `hcl_tblaccount_planning_current_service` DISABLE KEYS */;
/*!40000 ALTER TABLE `hcl_tblaccount_planning_current_service` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcl_tblaccount_planning_financial`
--

DROP TABLE IF EXISTS `hcl_tblaccount_planning_financial`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcl_tblaccount_planning_financial` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_planning_id` int(11) NOT NULL,
  `year` varchar(45) DEFAULT NULL,
  `revenue` varchar(255) DEFAULT NULL,
  `sales_spent` varchar(255) DEFAULT NULL,
  `traffic` varchar(255) DEFAULT NULL,
  `loss` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcl_tblaccount_planning_financial`
--

LOCK TABLES `hcl_tblaccount_planning_financial` WRITE;
/*!40000 ALTER TABLE `hcl_tblaccount_planning_financial` DISABLE KEYS */;
/*!40000 ALTER TABLE `hcl_tblaccount_planning_financial` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcl_tblaccount_planning_items`
--

DROP TABLE IF EXISTS `hcl_tblaccount_planning_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcl_tblaccount_planning_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_planning_id` int(11) NOT NULL,
  `objective_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `datecreated` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcl_tblaccount_planning_items`
--

LOCK TABLES `hcl_tblaccount_planning_items` WRITE;
/*!40000 ALTER TABLE `hcl_tblaccount_planning_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `hcl_tblaccount_planning_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcl_tblaccount_planning_marketing_activities`
--

DROP TABLE IF EXISTS `hcl_tblaccount_planning_marketing_activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcl_tblaccount_planning_marketing_activities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_planning_id` int(11) NOT NULL,
  `item` varchar(255) DEFAULT NULL,
  `reference` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcl_tblaccount_planning_marketing_activities`
--

LOCK TABLES `hcl_tblaccount_planning_marketing_activities` WRITE;
/*!40000 ALTER TABLE `hcl_tblaccount_planning_marketing_activities` DISABLE KEYS */;
/*!40000 ALTER TABLE `hcl_tblaccount_planning_marketing_activities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcl_tblaccount_planning_objective`
--

DROP TABLE IF EXISTS `hcl_tblaccount_planning_objective`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcl_tblaccount_planning_objective` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_planning_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `datecreated` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcl_tblaccount_planning_objective`
--

LOCK TABLES `hcl_tblaccount_planning_objective` WRITE;
/*!40000 ALTER TABLE `hcl_tblaccount_planning_objective` DISABLE KEYS */;
/*!40000 ALTER TABLE `hcl_tblaccount_planning_objective` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcl_tblaccount_planning_service_ability_offering`
--

DROP TABLE IF EXISTS `hcl_tblaccount_planning_service_ability_offering`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcl_tblaccount_planning_service_ability_offering` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_planning_id` int(11) NOT NULL,
  `service` varchar(255) DEFAULT NULL,
  `potential` varchar(255) DEFAULT NULL,
  `scale` varchar(255) DEFAULT NULL,
  `convert` varchar(255) DEFAULT NULL,
  `prioritization` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcl_tblaccount_planning_service_ability_offering`
--

LOCK TABLES `hcl_tblaccount_planning_service_ability_offering` WRITE;
/*!40000 ALTER TABLE `hcl_tblaccount_planning_service_ability_offering` DISABLE KEYS */;
/*!40000 ALTER TABLE `hcl_tblaccount_planning_service_ability_offering` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcl_tblaccount_planning_task`
--

DROP TABLE IF EXISTS `hcl_tblaccount_planning_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcl_tblaccount_planning_task` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL,
  `account_planning_id` int(11) DEFAULT NULL,
  `action_needed` varchar(255) NOT NULL,
  `prioritization` varchar(255) DEFAULT NULL,
  `pic` varchar(255) DEFAULT NULL,
  `deadline` date DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `objective` varchar(255) DEFAULT NULL,
  `item` varchar(255) DEFAULT NULL,
  `convert_to_task` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcl_tblaccount_planning_task`
--

LOCK TABLES `hcl_tblaccount_planning_task` WRITE;
/*!40000 ALTER TABLE `hcl_tblaccount_planning_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `hcl_tblaccount_planning_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcl_tblaccount_planning_team`
--

DROP TABLE IF EXISTS `hcl_tblaccount_planning_team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcl_tblaccount_planning_team` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_planning_id` int(11) NOT NULL,
  `rel_id` varchar(45) NOT NULL,
  `rel_type` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcl_tblaccount_planning_team`
--

LOCK TABLES `hcl_tblaccount_planning_team` WRITE;
/*!40000 ALTER TABLE `hcl_tblaccount_planning_team` DISABLE KEYS */;
/*!40000 ALTER TABLE `hcl_tblaccount_planning_team` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-09  5:24:03
