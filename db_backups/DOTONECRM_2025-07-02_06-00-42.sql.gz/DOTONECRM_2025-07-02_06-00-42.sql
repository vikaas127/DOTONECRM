/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.13-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: DOTONECRM
-- ------------------------------------------------------
-- Server version	10.11.13-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tblacc_account_history`
--

DROP TABLE IF EXISTS `tblacc_account_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblacc_account_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account` int(11) NOT NULL,
  `debit` decimal(15,2) NOT NULL DEFAULT 0.00,
  `credit` decimal(15,2) NOT NULL DEFAULT 0.00,
  `description` text DEFAULT NULL,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(45) DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `customer` int(11) DEFAULT NULL,
  `reconcile` int(11) NOT NULL DEFAULT 0,
  `split` int(11) NOT NULL DEFAULT 0,
  `item` int(11) DEFAULT NULL,
  `paid` int(1) NOT NULL DEFAULT 0,
  `date` date DEFAULT NULL,
  `tax` int(11) DEFAULT NULL,
  `payslip_type` varchar(45) DEFAULT NULL,
  `vendor` int(11) DEFAULT NULL,
  `itemable_id` int(11) DEFAULT NULL,
  `cleared` int(11) NOT NULL DEFAULT 0,
  `sub_type` varchar(45) DEFAULT NULL,
  `bill_item` int(11) NOT NULL DEFAULT 0,
  `number` varchar(100) DEFAULT NULL,
  `issue` int(11) NOT NULL DEFAULT 0,
  `added_from_reconcile` int(11) NOT NULL DEFAULT 0,
  `bank_reconcile` int(11) NOT NULL DEFAULT 0,
  `currency_rate` decimal(15,6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_account_history`
--

LOCK TABLES `tblacc_account_history` WRITE;
/*!40000 ALTER TABLE `tblacc_account_history` DISABLE KEYS */;
INSERT INTO `tblacc_account_history` VALUES
(1,1,0.00,0.00,'',1,'invoice','2025-06-27 13:15:14',0,4,0,66,0,1,'2025-06-27',0,NULL,NULL,1,0,NULL,0,NULL,0,0,0,0.000000),
(2,66,0.00,0.00,'',1,'invoice','2025-06-27 13:15:14',0,4,0,1,0,1,'2025-06-27',0,NULL,NULL,1,0,NULL,0,NULL,0,0,0,0.000000);
/*!40000 ALTER TABLE `tblacc_account_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblacc_account_type_details`
--

DROP TABLE IF EXISTS `tblacc_account_type_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblacc_account_type_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_type_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `note` text DEFAULT NULL,
  `statement_of_cash_flows` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=200 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_account_type_details`
--

LOCK TABLES `tblacc_account_type_details` WRITE;
/*!40000 ALTER TABLE `tblacc_account_type_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblacc_account_type_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblacc_accounts`
--

DROP TABLE IF EXISTS `tblacc_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblacc_accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `key_name` varchar(255) DEFAULT NULL,
  `number` varchar(45) DEFAULT NULL,
  `parent_account` int(11) DEFAULT NULL,
  `account_type_id` int(11) NOT NULL,
  `account_detail_type_id` int(11) NOT NULL,
  `balance` decimal(15,2) DEFAULT NULL,
  `balance_as_of` date DEFAULT NULL,
  `description` text DEFAULT NULL,
  `default_account` int(11) NOT NULL DEFAULT 0,
  `active` int(11) NOT NULL DEFAULT 1,
  `access_token` text DEFAULT NULL,
  `account_id` varchar(255) DEFAULT NULL,
  `plaid_status` tinyint(5) NOT NULL DEFAULT 0 COMMENT '1=>verified, 0=>not verified',
  `plaid_account_name` varchar(255) DEFAULT NULL,
  `bank_account` text DEFAULT NULL,
  `bank_routing` text DEFAULT NULL,
  `address_line_1` text DEFAULT NULL,
  `address_line_2` text DEFAULT NULL,
  `bank_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_accounts`
--

LOCK TABLES `tblacc_accounts` WRITE;
/*!40000 ALTER TABLE `tblacc_accounts` DISABLE KEYS */;
INSERT INTO `tblacc_accounts` VALUES
(1,'','acc_accounts_receivable',NULL,NULL,1,1,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(2,'','acc_accrued_holiday_payable',NULL,NULL,9,61,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(3,'','acc_accrued_liabilities',NULL,NULL,8,44,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(4,'','acc_accrued_non_current_liabilities',NULL,NULL,9,62,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(5,'','acc_accumulated_depreciation_on_property_plant_and_equipment',NULL,NULL,4,22,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(6,'','acc_allowance_for_bad_debts',NULL,NULL,2,2,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(7,'','acc_amortisation_expense',NULL,NULL,14,106,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(8,'','acc_assets_held_for_sale',NULL,NULL,5,32,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(9,'','acc_available_for_sale_assets_short_term',NULL,NULL,2,3,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(10,'','acc_bad_debts',NULL,NULL,14,108,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(11,'','acc_bank_charges',NULL,NULL,14,109,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(12,'','acc_billable_expense_income',NULL,NULL,11,89,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(13,'','acc_cash_and_cash_equivalents',NULL,NULL,3,15,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(14,'','acc_change_in_inventory_cos',NULL,NULL,13,100,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(15,'','acc_commissions_and_fees',NULL,NULL,14,111,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(16,'','acc_cost_of_sales',NULL,NULL,13,104,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(17,'','acc_deferred_tax_assets',NULL,NULL,5,33,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(18,'','acc_direct_labour_cos',NULL,NULL,13,100,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(19,'','acc_discounts_given_cos',NULL,NULL,13,100,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(20,'','acc_dividend_disbursed',NULL,NULL,10,69,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(21,'','acc_dividend_income',NULL,NULL,12,92,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(22,'','acc_dividends_payable',NULL,NULL,8,48,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(23,'','acc_dues_and_subscriptions',NULL,NULL,14,113,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(24,'','acc_equipment_rental',NULL,NULL,14,114,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(25,'','acc_equity_in_earnings_of_subsidiaries',NULL,NULL,10,70,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(26,'','acc_freight_and_delivery_cos',NULL,NULL,13,100,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(27,'','acc_goodwill',NULL,NULL,5,34,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(28,'','acc_income_tax_expense',NULL,NULL,14,116,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(29,'','acc_income_tax_payable',NULL,NULL,8,50,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(30,'','acc_insurance_disability',NULL,NULL,14,117,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(31,'','acc_insurance_general',NULL,NULL,14,117,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(32,'','acc_insurance_liability',NULL,NULL,14,117,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(33,'','acc_intangibles',NULL,NULL,5,35,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(34,'','acc_interest_expense',NULL,NULL,14,118,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(35,'','acc_interest_income',NULL,NULL,12,93,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(36,'','acc_inventory',NULL,NULL,2,5,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(37,'','acc_inventory_asset',NULL,NULL,2,5,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(38,'','acc_legal_and_professional_fees',NULL,NULL,14,119,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(39,'','acc_liabilities_related_to_assets_held_for_sale',NULL,NULL,9,63,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(40,'','acc_long_term_debt',NULL,NULL,9,64,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(41,'','acc_long_term_investments',NULL,NULL,5,38,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(42,'','acc_loss_on_discontinued_operations_net_of_tax',NULL,NULL,14,120,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(43,'','acc_loss_on_disposal_of_assets',NULL,NULL,12,94,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(44,'','acc_management_compensation',NULL,NULL,14,121,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(45,'','acc_materials_cos',NULL,NULL,13,100,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(46,'','acc_meals_and_entertainment',NULL,NULL,14,122,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(47,'','acc_office_expenses',NULL,NULL,14,123,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(48,'','acc_other_cos',NULL,NULL,13,100,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(49,'','acc_other_comprehensive_income',NULL,NULL,10,73,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(50,'','acc_other_general_and_administrative_expenses',NULL,NULL,14,123,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(51,'','acc_other_operating_income_expenses',NULL,NULL,12,97,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(52,'','acc_other_selling_expenses',NULL,NULL,14,125,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(53,'','acc_other_type_of_expenses_advertising_expenses',NULL,NULL,14,105,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(54,'','acc_overhead_cos',NULL,NULL,13,100,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(55,'','acc_payroll_clearing',NULL,NULL,8,55,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(56,'','acc_payroll_expenses',NULL,NULL,14,126,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(57,'','acc_payroll_liabilities',NULL,NULL,8,56,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(58,'','acc_prepaid_expenses',NULL,NULL,2,11,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(59,'','acc_property_plant_and_equipment',NULL,NULL,4,26,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(60,'','acc_purchases',NULL,NULL,14,130,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(61,'','acc_reconciliation_discrepancies',NULL,NULL,15,139,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(62,'','acc_rent_or_lease_payments',NULL,NULL,14,127,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(63,'','acc_repair_and_maintenance',NULL,NULL,14,128,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(64,'','acc_retained_earnings',NULL,NULL,10,80,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(65,'','acc_revenue_general',NULL,NULL,11,86,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(66,'','acc_sales',NULL,NULL,11,89,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(67,'','acc_sales_retail',NULL,NULL,11,87,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(68,'','acc_sales_wholesale',NULL,NULL,11,88,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(69,'','acc_sales_of_product_income',NULL,NULL,11,89,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(70,'','acc_share_capital',NULL,NULL,10,81,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(71,'','acc_shipping_and_delivery_expense',NULL,NULL,14,129,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(72,'','acc_short_term_debit',NULL,NULL,8,54,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(73,'','acc_stationery_and_printing',NULL,NULL,14,123,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(74,'','acc_subcontractors_cos',NULL,NULL,13,100,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(75,'','acc_supplies',NULL,NULL,14,130,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(76,'','acc_travel_expenses_general_and_admin_expenses',NULL,NULL,14,132,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(77,'','acc_travel_expenses_selling_expense',NULL,NULL,14,133,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(78,'','acc_unapplied_cash_payment_income',NULL,NULL,11,91,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(79,'','acc_uncategorised_asset',NULL,NULL,2,10,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(80,'','acc_uncategorised_expense',NULL,NULL,14,124,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(81,'','acc_uncategorised_income',NULL,NULL,11,89,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(82,'','acc_undeposited_funds',NULL,NULL,2,13,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(83,'','acc_unrealised_loss_on_securities_net_of_tax',NULL,NULL,12,99,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(84,'','acc_utilities',NULL,NULL,14,135,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(85,'','acc_wage_expenses',NULL,NULL,14,126,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(86,'','acc_credit_card',NULL,NULL,7,43,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(87,'','acc_accounts_payable',NULL,NULL,6,42,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(88,'','acc_opening_balance_equity',NULL,NULL,10,71,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `tblacc_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblacc_bank_reconciles`
--

DROP TABLE IF EXISTS `tblacc_bank_reconciles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblacc_bank_reconciles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account` int(11) NOT NULL,
  `opening_balance` decimal(15,2) NOT NULL DEFAULT 0.00,
  `beginning_balance` decimal(15,2) NOT NULL,
  `ending_balance` decimal(15,2) NOT NULL,
  `ending_date` date NOT NULL,
  `finish` int(11) NOT NULL DEFAULT 0,
  `debits_for_period` decimal(15,2) NOT NULL,
  `credits_for_period` decimal(15,2) NOT NULL,
  `dateadded` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_bank_reconciles`
--

LOCK TABLES `tblacc_bank_reconciles` WRITE;
/*!40000 ALTER TABLE `tblacc_bank_reconciles` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblacc_bank_reconciles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblacc_banking_rule_details`
--

DROP TABLE IF EXISTS `tblacc_banking_rule_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblacc_banking_rule_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rule_id` int(11) NOT NULL,
  `type` varchar(45) DEFAULT NULL,
  `subtype` varchar(45) DEFAULT NULL,
  `text` varchar(255) DEFAULT NULL,
  `subtype_amount` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_banking_rule_details`
--

LOCK TABLES `tblacc_banking_rule_details` WRITE;
/*!40000 ALTER TABLE `tblacc_banking_rule_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblacc_banking_rule_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblacc_banking_rules`
--

DROP TABLE IF EXISTS `tblacc_banking_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblacc_banking_rules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `transaction` varchar(45) DEFAULT NULL,
  `following` varchar(45) DEFAULT NULL,
  `then` varchar(45) DEFAULT NULL,
  `payment_account` int(11) DEFAULT NULL,
  `deposit_to` int(11) DEFAULT NULL,
  `auto_add` int(11) NOT NULL DEFAULT 0,
  `mapping_type` varchar(25) DEFAULT NULL,
  `account` int(11) DEFAULT NULL,
  `split_percentage` text DEFAULT NULL,
  `split_amount` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_banking_rules`
--

LOCK TABLES `tblacc_banking_rules` WRITE;
/*!40000 ALTER TABLE `tblacc_banking_rules` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblacc_banking_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblacc_bill_mappings`
--

DROP TABLE IF EXISTS `tblacc_bill_mappings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblacc_bill_mappings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bill_id` int(11) DEFAULT NULL,
  `type` varchar(25) DEFAULT NULL,
  `account` int(11) DEFAULT NULL,
  `amount` decimal(15,2) DEFAULT NULL,
  `item_id` int(11) NOT NULL DEFAULT 0,
  `qty` decimal(15,2) NOT NULL DEFAULT 0.00,
  `cost` decimal(15,2) NOT NULL DEFAULT 0.00,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_bill_mappings`
--

LOCK TABLES `tblacc_bill_mappings` WRITE;
/*!40000 ALTER TABLE `tblacc_bill_mappings` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblacc_bill_mappings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblacc_budget_details`
--

DROP TABLE IF EXISTS `tblacc_budget_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblacc_budget_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `budget_id` int(11) NOT NULL,
  `month` int(11) NOT NULL,
  `year` int(11) NOT NULL,
  `account` int(11) DEFAULT NULL,
  `amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_budget_details`
--

LOCK TABLES `tblacc_budget_details` WRITE;
/*!40000 ALTER TABLE `tblacc_budget_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblacc_budget_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblacc_budgets`
--

DROP TABLE IF EXISTS `tblacc_budgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblacc_budgets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `year` int(11) NOT NULL,
  `name` varchar(200) DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  `data_source` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_budgets`
--

LOCK TABLES `tblacc_budgets` WRITE;
/*!40000 ALTER TABLE `tblacc_budgets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblacc_budgets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblacc_check_details`
--

DROP TABLE IF EXISTS `tblacc_check_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblacc_check_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `check_id` int(11) DEFAULT NULL,
  `bill` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_check_details`
--

LOCK TABLES `tblacc_check_details` WRITE;
/*!40000 ALTER TABLE `tblacc_check_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblacc_check_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblacc_checks`
--

DROP TABLE IF EXISTS `tblacc_checks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblacc_checks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(25) DEFAULT NULL,
  `amount` decimal(15,2) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `memo` varchar(255) DEFAULT NULL,
  `dateadded` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `bank_account` int(11) NOT NULL,
  `number` int(11) NOT NULL,
  `signed` int(11) NOT NULL DEFAULT 0,
  `include_company_name_address` int(11) NOT NULL DEFAULT 1,
  `include_routing_account_numbers` int(11) NOT NULL DEFAULT 1,
  `bill` int(11) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `zip` varchar(15) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `issue` int(11) DEFAULT NULL,
  `include_check_number` int(11) NOT NULL DEFAULT 1,
  `include_bank_name` int(11) NOT NULL DEFAULT 1,
  `bank_name` varchar(255) DEFAULT NULL,
  `address_line_1` text DEFAULT NULL,
  `address_line_2` text DEFAULT NULL,
  `vendor_city` varchar(100) DEFAULT NULL,
  `vendor_zip` varchar(15) DEFAULT NULL,
  `vendor_state` varchar(50) DEFAULT NULL,
  `vendor_address` text DEFAULT NULL,
  `reason_for_void` text DEFAULT NULL,
  `bill_items` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_checks`
--

LOCK TABLES `tblacc_checks` WRITE;
/*!40000 ALTER TABLE `tblacc_checks` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblacc_checks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblacc_checks_printed`
--

DROP TABLE IF EXISTS `tblacc_checks_printed`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblacc_checks_printed` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `check_id` int(11) DEFAULT NULL,
  `bank_account` int(11) DEFAULT NULL,
  `first_check_number` int(11) DEFAULT NULL,
  `printed_at` datetime DEFAULT NULL,
  `printed_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_checks_printed`
--

LOCK TABLES `tblacc_checks_printed` WRITE;
/*!40000 ALTER TABLE `tblacc_checks_printed` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblacc_checks_printed` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblacc_expense_category_mapping_details`
--

DROP TABLE IF EXISTS `tblacc_expense_category_mapping_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblacc_expense_category_mapping_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_mapping_id` int(11) NOT NULL,
  `payment_mode_id` int(11) NOT NULL,
  `payment_account` int(11) NOT NULL DEFAULT 0,
  `deposit_to` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_expense_category_mapping_details`
--

LOCK TABLES `tblacc_expense_category_mapping_details` WRITE;
/*!40000 ALTER TABLE `tblacc_expense_category_mapping_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblacc_expense_category_mapping_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblacc_expense_category_mappings`
--

DROP TABLE IF EXISTS `tblacc_expense_category_mappings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblacc_expense_category_mappings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `payment_account` int(11) NOT NULL DEFAULT 0,
  `deposit_to` int(11) NOT NULL DEFAULT 0,
  `preferred_payment_method` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_expense_category_mappings`
--

LOCK TABLES `tblacc_expense_category_mappings` WRITE;
/*!40000 ALTER TABLE `tblacc_expense_category_mappings` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblacc_expense_category_mappings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblacc_income_statement_modifications`
--

DROP TABLE IF EXISTS `tblacc_income_statement_modifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblacc_income_statement_modifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `account` int(11) DEFAULT NULL,
  `active` int(11) NOT NULL DEFAULT 1,
  `account_type` int(11) DEFAULT NULL,
  `options` text DEFAULT NULL,
  `dateadded` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `type` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_income_statement_modifications`
--

LOCK TABLES `tblacc_income_statement_modifications` WRITE;
/*!40000 ALTER TABLE `tblacc_income_statement_modifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblacc_income_statement_modifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblacc_item_automatics`
--

DROP TABLE IF EXISTS `tblacc_item_automatics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblacc_item_automatics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL,
  `inventory_asset_account` int(11) NOT NULL DEFAULT 0,
  `income_account` int(11) NOT NULL DEFAULT 0,
  `expense_account` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_item_automatics`
--

LOCK TABLES `tblacc_item_automatics` WRITE;
/*!40000 ALTER TABLE `tblacc_item_automatics` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblacc_item_automatics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblacc_journal_entries`
--

DROP TABLE IF EXISTS `tblacc_journal_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblacc_journal_entries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `number` varchar(45) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `journal_date` date DEFAULT NULL,
  `amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `reference` varchar(100) DEFAULT NULL,
  `recurring` int(11) NOT NULL DEFAULT 0,
  `recurring_type` varchar(10) DEFAULT NULL,
  `custom_recurring` tinyint(1) NOT NULL DEFAULT 0,
  `cycles` int(11) NOT NULL DEFAULT 0,
  `total_cycles` int(11) NOT NULL DEFAULT 0,
  `is_recurring_from` int(11) DEFAULT NULL,
  `last_recurring_date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_journal_entries`
--

LOCK TABLES `tblacc_journal_entries` WRITE;
/*!40000 ALTER TABLE `tblacc_journal_entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblacc_journal_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblacc_matched_transactions`
--

DROP TABLE IF EXISTS `tblacc_matched_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblacc_matched_transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_history_id` int(11) DEFAULT NULL,
  `history_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(255) DEFAULT NULL,
  `amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `company` int(11) DEFAULT NULL,
  `reconcile` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_matched_transactions`
--

LOCK TABLES `tblacc_matched_transactions` WRITE;
/*!40000 ALTER TABLE `tblacc_matched_transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblacc_matched_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblacc_pay_bill_details`
--

DROP TABLE IF EXISTS `tblacc_pay_bill_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblacc_pay_bill_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pay_bill` int(11) DEFAULT NULL,
  `bill_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_pay_bill_details`
--

LOCK TABLES `tblacc_pay_bill_details` WRITE;
/*!40000 ALTER TABLE `tblacc_pay_bill_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblacc_pay_bill_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblacc_pay_bill_item_paid`
--

DROP TABLE IF EXISTS `tblacc_pay_bill_item_paid`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblacc_pay_bill_item_paid` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pay_bill_id` int(11) NOT NULL DEFAULT 0,
  `item_id` int(11) DEFAULT NULL,
  `item_name` varchar(255) DEFAULT NULL,
  `item_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `amount_paid` decimal(15,2) NOT NULL DEFAULT 0.00,
  `check_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_pay_bill_item_paid`
--

LOCK TABLES `tblacc_pay_bill_item_paid` WRITE;
/*!40000 ALTER TABLE `tblacc_pay_bill_item_paid` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblacc_pay_bill_item_paid` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblacc_pay_bills`
--

DROP TABLE IF EXISTS `tblacc_pay_bills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblacc_pay_bills` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `expense` int(11) DEFAULT NULL,
  `amount` decimal(15,2) DEFAULT NULL,
  `reference_no` varchar(100) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `dateadded` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `company` int(11) DEFAULT NULL,
  `account_debit` int(11) DEFAULT NULL,
  `account_credit` int(11) DEFAULT NULL,
  `bill` int(11) NOT NULL DEFAULT 0,
  `vendor` int(11) NOT NULL DEFAULT 0,
  `pay_number` int(11) DEFAULT NULL,
  `payment_method` varchar(255) DEFAULT NULL,
  `bill_items` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_pay_bills`
--

LOCK TABLES `tblacc_pay_bills` WRITE;
/*!40000 ALTER TABLE `tblacc_pay_bills` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblacc_pay_bills` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblacc_payment_mode_mappings`
--

DROP TABLE IF EXISTS `tblacc_payment_mode_mappings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblacc_payment_mode_mappings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `payment_mode_id` int(11) NOT NULL,
  `payment_account` int(11) NOT NULL DEFAULT 0,
  `deposit_to` int(11) NOT NULL DEFAULT 0,
  `expense_payment_account` int(11) NOT NULL DEFAULT 0,
  `expense_deposit_to` int(11) NOT NULL DEFAULT 0,
  `credit_note_refund_payment_account` int(11) NOT NULL DEFAULT 0,
  `credit_note_refund_deposit_to` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_payment_mode_mappings`
--

LOCK TABLES `tblacc_payment_mode_mappings` WRITE;
/*!40000 ALTER TABLE `tblacc_payment_mode_mappings` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblacc_payment_mode_mappings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblacc_plaid_transaction_logs`
--

DROP TABLE IF EXISTS `tblacc_plaid_transaction_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblacc_plaid_transaction_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bank_id` int(11) DEFAULT NULL,
  `last_updated` date DEFAULT NULL,
  `transaction_count` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `addedFrom` int(11) DEFAULT NULL,
  `company` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_plaid_transaction_logs`
--

LOCK TABLES `tblacc_plaid_transaction_logs` WRITE;
/*!40000 ALTER TABLE `tblacc_plaid_transaction_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblacc_plaid_transaction_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblacc_print_later`
--

DROP TABLE IF EXISTS `tblacc_print_later`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblacc_print_later` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(45) DEFAULT NULL,
  `account` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_print_later`
--

LOCK TABLES `tblacc_print_later` WRITE;
/*!40000 ALTER TABLE `tblacc_print_later` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblacc_print_later` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblacc_reconciles`
--

DROP TABLE IF EXISTS `tblacc_reconciles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblacc_reconciles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account` int(11) NOT NULL,
  `beginning_balance` decimal(15,2) NOT NULL,
  `ending_balance` decimal(15,2) NOT NULL,
  `ending_date` date NOT NULL,
  `expense_date` date DEFAULT NULL,
  `service_charge` decimal(15,2) DEFAULT NULL,
  `expense_account` int(11) DEFAULT NULL,
  `income_date` date DEFAULT NULL,
  `interest_earned` decimal(15,2) DEFAULT NULL,
  `income_account` int(11) DEFAULT NULL,
  `finish` int(11) NOT NULL DEFAULT 0,
  `opening_balance` int(11) NOT NULL DEFAULT 0,
  `debits_for_period` decimal(15,2) DEFAULT NULL,
  `credits_for_period` decimal(15,2) DEFAULT NULL,
  `dateadded` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_reconciles`
--

LOCK TABLES `tblacc_reconciles` WRITE;
/*!40000 ALTER TABLE `tblacc_reconciles` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblacc_reconciles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblacc_tax_mappings`
--

DROP TABLE IF EXISTS `tblacc_tax_mappings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblacc_tax_mappings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tax_id` int(11) NOT NULL,
  `payment_account` int(11) NOT NULL DEFAULT 0,
  `deposit_to` int(11) NOT NULL DEFAULT 0,
  `expense_payment_account` int(11) NOT NULL DEFAULT 0,
  `expense_deposit_to` int(11) NOT NULL DEFAULT 0,
  `purchase_payment_account` int(11) NOT NULL DEFAULT 0,
  `purchase_deposit_to` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_tax_mappings`
--

LOCK TABLES `tblacc_tax_mappings` WRITE;
/*!40000 ALTER TABLE `tblacc_tax_mappings` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblacc_tax_mappings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblacc_transaction_bankings`
--

DROP TABLE IF EXISTS `tblacc_transaction_bankings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblacc_transaction_bankings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `withdrawals` decimal(15,2) NOT NULL DEFAULT 0.00,
  `deposits` decimal(15,2) NOT NULL DEFAULT 0.00,
  `payee` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `transaction_id` varchar(150) DEFAULT NULL,
  `bank_id` int(11) DEFAULT NULL,
  `status` tinyint(5) NOT NULL DEFAULT 0 COMMENT '1=>posted, 2=>pending',
  `matched` int(11) NOT NULL DEFAULT 0,
  `reconcile` int(11) NOT NULL DEFAULT 0,
  `adjusted` int(11) NOT NULL DEFAULT 0,
  `is_imported` int(11) NOT NULL DEFAULT 0,
  `banking_rule` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_transaction_bankings`
--

LOCK TABLES `tblacc_transaction_bankings` WRITE;
/*!40000 ALTER TABLE `tblacc_transaction_bankings` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblacc_transaction_bankings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblacc_transfers`
--

DROP TABLE IF EXISTS `tblacc_transfers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblacc_transfers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transfer_funds_from` int(11) NOT NULL,
  `transfer_funds_to` int(11) NOT NULL,
  `transfer_amount` decimal(15,2) DEFAULT NULL,
  `date` varchar(45) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_transfers`
--

LOCK TABLES `tblacc_transfers` WRITE;
/*!40000 ALTER TABLE `tblacc_transfers` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblacc_transfers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblaccount_planning`
--

DROP TABLE IF EXISTS `tblaccount_planning`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblaccount_planning` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) NOT NULL,
  `vision` varchar(255) DEFAULT NULL,
  `mission` varchar(255) DEFAULT NULL,
  `lead_generation` varchar(45) DEFAULT NULL,
  `current_service_know_pmax` varchar(45) DEFAULT NULL,
  `current_service_facebook` varchar(45) DEFAULT NULL,
  `current_service_sem` varchar(45) DEFAULT NULL,
  `objectives` varchar(255) DEFAULT NULL,
  `threat` varchar(255) DEFAULT NULL,
  `opportunity` varchar(255) DEFAULT NULL,
  `criteria_to_success` varchar(255) DEFAULT NULL,
  `constraints` varchar(255) DEFAULT NULL,
  `data_tree` longtext DEFAULT NULL,
  `latest_update` date DEFAULT NULL,
  `new_update` date DEFAULT NULL,
  `product` varchar(255) DEFAULT NULL,
  `sale_channel_online` varchar(255) DEFAULT NULL,
  `sale_channel_offline` varchar(255) DEFAULT NULL,
  `revenue_next_year` varchar(255) DEFAULT NULL,
  `wallet_share` varchar(255) DEFAULT NULL,
  `client_status` varchar(255) DEFAULT NULL,
  `bcg_model` varchar(255) DEFAULT NULL,
  `margin` varchar(255) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblaccount_planning`
--

LOCK TABLES `tblaccount_planning` WRITE;
/*!40000 ALTER TABLE `tblaccount_planning` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblaccount_planning` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblaccount_planning_current_service`
--

DROP TABLE IF EXISTS `tblaccount_planning_current_service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblaccount_planning_current_service` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_planning_id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `potential` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblaccount_planning_current_service`
--

LOCK TABLES `tblaccount_planning_current_service` WRITE;
/*!40000 ALTER TABLE `tblaccount_planning_current_service` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblaccount_planning_current_service` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblaccount_planning_financial`
--

DROP TABLE IF EXISTS `tblaccount_planning_financial`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblaccount_planning_financial` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_planning_id` int(11) NOT NULL,
  `year` varchar(45) DEFAULT NULL,
  `revenue` varchar(255) DEFAULT NULL,
  `sales_spent` varchar(255) DEFAULT NULL,
  `traffic` varchar(255) DEFAULT NULL,
  `loss` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblaccount_planning_financial`
--

LOCK TABLES `tblaccount_planning_financial` WRITE;
/*!40000 ALTER TABLE `tblaccount_planning_financial` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblaccount_planning_financial` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblaccount_planning_items`
--

DROP TABLE IF EXISTS `tblaccount_planning_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblaccount_planning_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_planning_id` int(11) NOT NULL,
  `objective_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `datecreated` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblaccount_planning_items`
--

LOCK TABLES `tblaccount_planning_items` WRITE;
/*!40000 ALTER TABLE `tblaccount_planning_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblaccount_planning_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblaccount_planning_marketing_activities`
--

DROP TABLE IF EXISTS `tblaccount_planning_marketing_activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblaccount_planning_marketing_activities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_planning_id` int(11) NOT NULL,
  `item` varchar(255) DEFAULT NULL,
  `reference` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblaccount_planning_marketing_activities`
--

LOCK TABLES `tblaccount_planning_marketing_activities` WRITE;
/*!40000 ALTER TABLE `tblaccount_planning_marketing_activities` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblaccount_planning_marketing_activities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblaccount_planning_objective`
--

DROP TABLE IF EXISTS `tblaccount_planning_objective`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblaccount_planning_objective` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_planning_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `datecreated` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblaccount_planning_objective`
--

LOCK TABLES `tblaccount_planning_objective` WRITE;
/*!40000 ALTER TABLE `tblaccount_planning_objective` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblaccount_planning_objective` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblaccount_planning_service_ability_offering`
--

DROP TABLE IF EXISTS `tblaccount_planning_service_ability_offering`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblaccount_planning_service_ability_offering` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_planning_id` int(11) NOT NULL,
  `service` varchar(255) DEFAULT NULL,
  `potential` varchar(255) DEFAULT NULL,
  `scale` varchar(255) DEFAULT NULL,
  `convert` varchar(255) DEFAULT NULL,
  `prioritization` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblaccount_planning_service_ability_offering`
--

LOCK TABLES `tblaccount_planning_service_ability_offering` WRITE;
/*!40000 ALTER TABLE `tblaccount_planning_service_ability_offering` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblaccount_planning_service_ability_offering` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblaccount_planning_task`
--

DROP TABLE IF EXISTS `tblaccount_planning_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblaccount_planning_task` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL,
  `account_planning_id` int(11) DEFAULT NULL,
  `action_needed` varchar(255) NOT NULL,
  `prioritization` varchar(255) DEFAULT NULL,
  `pic` varchar(255) DEFAULT NULL,
  `deadline` date DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `objective` varchar(255) DEFAULT NULL,
  `item` varchar(255) DEFAULT NULL,
  `convert_to_task` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblaccount_planning_task`
--

LOCK TABLES `tblaccount_planning_task` WRITE;
/*!40000 ALTER TABLE `tblaccount_planning_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblaccount_planning_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblaccount_planning_team`
--

DROP TABLE IF EXISTS `tblaccount_planning_team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblaccount_planning_team` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_planning_id` int(11) NOT NULL,
  `rel_id` varchar(45) NOT NULL,
  `rel_type` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblaccount_planning_team`
--

LOCK TABLES `tblaccount_planning_team` WRITE;
/*!40000 ALTER TABLE `tblaccount_planning_team` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblaccount_planning_team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblactivity_log`
--

DROP TABLE IF EXISTS `tblactivity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblactivity_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` longtext NOT NULL,
  `date` datetime NOT NULL,
  `staffid` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `staffid` (`staffid`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblactivity_log`
--

LOCK TABLES `tblactivity_log` WRITE;
/*!40000 ALTER TABLE `tblactivity_log` DISABLE KEYS */;
INSERT INTO `tblactivity_log` VALUES
(1,'Non Existing User Tried to Login [Email: info.vikaasyadav@gmail.com, Is Staff Member: No, IP: 157.48.80.182]','2025-06-25 21:13:25',NULL),
(2,'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 157.48.80.182]','2025-06-25 21:13:36','Vikas Yadav'),
(3,'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 157.48.80.182]','2025-06-25 22:54:38','Vikas Yadav'),
(4,'New Client Created [ID: 1, From Staff: 1]','2025-06-25 23:46:11','Vikas Yadav'),
(5,'Contact Created [ID: 1]','2025-06-25 23:46:56','Vikas Yadav'),
(6,'User Successfully Logged In [User Id: 1, Is Staff Member: No, IP: 157.48.80.182]','2025-06-25 23:47:45','Dayanand yadav'),
(7,'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 157.48.80.182]','2025-06-25 23:51:22','Vikas Yadav'),
(8,'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 157.48.80.182]','2025-06-26 05:52:55','Vikas Yadav'),
(9,'New Currency Added [ID: INR]','2025-06-26 06:03:11','Vikas Yadav'),
(10,'Currency Deleted [2]','2025-06-26 06:03:23','Vikas Yadav'),
(11,'User Successfully Logged In [User Id: 1, Is Staff Member: No, IP: 157.48.80.182]','2025-06-26 06:59:48','Dayanand yadav'),
(12,'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 157.48.82.220]','2025-06-26 12:14:21','Vikas Yadav'),
(13,'Non Existing User Tried to Login [Email: sales@techdotbit.com, Is Staff Member: Yes, IP: 106.219.224.219]','2025-06-26 13:30:19',NULL),
(14,'Non Existing User Tried to Login [Email: sales@techdotbit.com, Is Staff Member: Yes, IP: 106.219.224.219]','2025-06-26 13:30:28',NULL),
(15,'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 157.48.82.220]','2025-06-26 15:44:39','Vikas Yadav'),
(16,'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 157.48.82.220]','2025-06-26 15:57:10','Vikas Yadav'),
(17,'Contact Created [ID: 2]','2025-06-26 17:11:40',NULL),
(18,'New Client Created [ID: 2]','2025-06-26 17:11:40',NULL),
(19,'User Successfully Logged In [User Id: 2, Is Staff Member: No, IP: 157.48.82.220]','2025-06-26 17:11:40','Dayanand Sweden'),
(20,'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 157.48.82.220]','2025-06-26 19:58:35','Vikas Yadav'),
(21,'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 157.48.221.10]','2025-06-27 06:47:36','Vikas Yadav'),
(22,'Failed Login Attempt [Email: info.vikaasyadav@gmail.com, Is Staff Member: No, IP: 2409:40d4:10cd:43f8:f408:13f9:e02c:5190]','2025-06-27 10:39:19',NULL),
(23,'Failed Login Attempt [Email: info.vikaasyadav@gmail.com, Is Staff Member: Yes, IP: 2409:40d4:10cd:43f8:f408:13f9:e02c:5190]','2025-06-27 10:39:37',NULL),
(24,'Failed Login Attempt [Email: info.vikaasyadav@gmail.com, Is Staff Member: Yes, IP: 2409:40d4:10cd:43f8:f408:13f9:e02c:5190]','2025-06-27 10:39:44',NULL),
(25,'User Successfully Logged In [User Id: 2, Is Staff Member: No, IP: 2409:40d4:10cd:43f8:f408:13f9:e02c:5190]','2025-06-27 10:57:07','Dayanand Sweden'),
(26,'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 2409:40d4:10cd:43f8:f408:13f9:e02c:5190]','2025-06-27 11:02:09','Dayanand Sweden'),
(27,'Failed Login Attempt [Email: info.vikaasyadav@gmail.com, Is Staff Member: No, IP: 2409:40d4:10cd:43f8:f408:13f9:e02c:5190]','2025-06-27 11:32:14','Vikas Yadav'),
(28,'User Successfully Logged In [User Id: 2, Is Staff Member: No, IP: 2409:40d4:10cd:43f8:f408:13f9:e02c:5190]','2025-06-27 11:32:24','Dayanand Sweden'),
(29,'Contact Created [ID: 3]','2025-06-27 11:57:11',NULL),
(30,'New Client Created [ID: 3]','2025-06-27 11:57:11',NULL),
(31,'User Successfully Logged In [User Id: 3, Is Staff Member: No, IP: 2409:40d4:10cd:43f8:f408:13f9:e02c:5190]','2025-06-27 11:57:11','Dayanand yadav'),
(32,'User Successfully Logged In [User Id: 3, Is Staff Member: No, IP: 2409:40d4:10cd:43f8:f408:13f9:e02c:5190]','2025-06-27 12:01:57','Dayanand yadav'),
(33,'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 2409:40d4:10cd:43f8:f408:13f9:e02c:5190]','2025-06-27 12:03:06','Vikas Yadav'),
(34,'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 2409:40d4:10cd:43f8:f408:13f9:e02c:5190]','2025-06-27 12:54:06','Vikas Yadav'),
(35,'Contact Created [ID: 4]','2025-06-27 12:54:54',NULL),
(36,'New Client Created [ID: 4]','2025-06-27 12:54:55',NULL),
(37,'User Successfully Logged In [User Id: 4, Is Staff Member: No, IP: 2409:40d4:10cd:43f8:f408:13f9:e02c:5190]','2025-06-27 12:54:55','Dayanand yadav'),
(38,'Failed Login Attempt [Email: info.vikaasyadav@gmail.com, Is Staff Member: Yes, IP: 2409:40d4:10cd:43f8:f408:13f9:e02c:5190]','2025-06-27 15:16:39',NULL),
(39,'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 2409:40d4:10cd:43f8:f408:13f9:e02c:5190]','2025-06-27 15:16:46','Vikas Yadav'),
(40,'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 2409:40d4:10cd:43f8:ccef:f512:e762:56b2]','2025-06-28 08:24:50','Vikas Yadav'),
(41,'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 2409:40d4:10cd:43f8:ccef:f512:e762:56b2]','2025-06-29 08:44:49','Vikas Yadav'),
(42,'User Successfully Logged In [User Id: 4, Is Staff Member: No, IP: 2409:40d4:10cd:43f8:ccef:f512:e762:56b2]','2025-06-29 10:34:08','Dayanand yadav'),
(43,'User Successfully Logged In [User Id: 4, Is Staff Member: No, IP: 2405:201:4018:225d:9952:89b6:f4e2:c984]','2025-07-01 16:36:42','Dayanand yadav'),
(44,'Failed Login Attempt [Email: info.vikaasyadav@gmail.com, Is Staff Member: No, IP: 2405:201:4018:225d:9952:89b6:f4e2:c984]','2025-07-01 16:37:19',NULL),
(45,'Failed Login Attempt [Email: info.vikaasyadav@gmail.com, Is Staff Member: Yes, IP: 2405:201:4018:225d:9952:89b6:f4e2:c984]','2025-07-01 16:37:35',NULL),
(46,'Failed Login Attempt [Email: info.vikaasyadav@gmail.com, Is Staff Member: Yes, IP: 2405:201:4018:225d:9952:89b6:f4e2:c984]','2025-07-01 16:37:38',NULL),
(47,'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 2405:201:4018:225d:9952:89b6:f4e2:c984]','2025-07-01 16:37:45','Vikas Yadav'),
(48,'User Successfully Logged In [User Id: 4, Is Staff Member: No, IP: 2405:201:4018:225d:9952:89b6:f4e2:c984]','2025-07-01 16:40:29','Dayanand yadav'),
(49,'Contact Created [ID: 5]','2025-07-01 17:24:38',NULL),
(50,'New Client Created [ID: 5]','2025-07-01 17:24:38',NULL),
(51,'User Successfully Logged In [User Id: 5, Is Staff Member: No, IP: 2405:201:4018:225d:25a3:777b:1fb8:f323]','2025-07-01 17:24:38','Vishal Shankar'),
(52,'Non Existing User Tried to Login [Email: sales@techdotbit.com, Is Staff Member: Yes, IP: 2405:201:4018:225d:25a3:777b:1fb8:f323]','2025-07-01 17:26:26','Vishal Shankar'),
(53,'Non Existing User Tried to Login [Email: sales@techdotbit.com, Is Staff Member: Yes, IP: 2405:201:4018:225d:25a3:777b:1fb8:f323]','2025-07-01 17:26:41','Vishal Shankar');
/*!40000 ALTER TABLE `tblactivity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblaffiliate_m_affiliates`
--

DROP TABLE IF EXISTS `tblaffiliate_m_affiliates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblaffiliate_m_affiliates` (
  `affiliate_id` int(11) NOT NULL AUTO_INCREMENT,
  `affiliate_slug` varchar(255) NOT NULL,
  `group_id` varchar(255) DEFAULT NULL,
  `contact_id` int(11) NOT NULL,
  `total_earnings` decimal(10,2) DEFAULT 0.00,
  `balance` decimal(10,2) DEFAULT 0.00,
  `status` varchar(255) DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`affiliate_id`),
  UNIQUE KEY `unique_tbl_contact_id` (`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblaffiliate_m_affiliates`
--

LOCK TABLES `tblaffiliate_m_affiliates` WRITE;
/*!40000 ALTER TABLE `tblaffiliate_m_affiliates` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblaffiliate_m_affiliates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblaffiliate_m_commissions`
--

DROP TABLE IF EXISTS `tblaffiliate_m_commissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblaffiliate_m_commissions` (
  `commission_id` int(11) NOT NULL AUTO_INCREMENT,
  `referral_id` int(11) NOT NULL,
  `affiliate_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `payment_id` int(11) DEFAULT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `rule_info` varchar(255) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`commission_id`),
  KEY `fk_tbl_commission_referral_id` (`referral_id`),
  KEY `fk_tbl_commission_affiliate_id` (`affiliate_id`),
  CONSTRAINT `fk_tbl_commission_affiliate_id` FOREIGN KEY (`affiliate_id`) REFERENCES `tblaffiliate_m_affiliates` (`affiliate_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tbl_commission_referral_id` FOREIGN KEY (`referral_id`) REFERENCES `tblaffiliate_m_referrals` (`referral_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblaffiliate_m_commissions`
--

LOCK TABLES `tblaffiliate_m_commissions` WRITE;
/*!40000 ALTER TABLE `tblaffiliate_m_commissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblaffiliate_m_commissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblaffiliate_m_payouts`
--

DROP TABLE IF EXISTS `tblaffiliate_m_payouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblaffiliate_m_payouts` (
  `payout_id` int(11) NOT NULL AUTO_INCREMENT,
  `affiliate_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `note_for_affiliate` text DEFAULT NULL,
  `note_for_admin` text DEFAULT NULL,
  `payout_method` varchar(255) NOT NULL,
  `status` varchar(255) DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`payout_id`),
  KEY `fk_tbl_afm_payout_affiliate_id` (`affiliate_id`),
  CONSTRAINT `fk_tbl_afm_payout_affiliate_id` FOREIGN KEY (`affiliate_id`) REFERENCES `tblaffiliate_m_affiliates` (`affiliate_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblaffiliate_m_payouts`
--

LOCK TABLES `tblaffiliate_m_payouts` WRITE;
/*!40000 ALTER TABLE `tblaffiliate_m_payouts` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblaffiliate_m_payouts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblaffiliate_m_referrals`
--

DROP TABLE IF EXISTS `tblaffiliate_m_referrals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblaffiliate_m_referrals` (
  `referral_id` int(11) NOT NULL AUTO_INCREMENT,
  `affiliate_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `ua` text DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`referral_id`),
  UNIQUE KEY `unique_tbl_client_id` (`client_id`),
  KEY `fk_tbl_referral_affiliate_id` (`affiliate_id`),
  CONSTRAINT `fk_tbl_referral_affiliate_id` FOREIGN KEY (`affiliate_id`) REFERENCES `tblaffiliate_m_affiliates` (`affiliate_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblaffiliate_m_referrals`
--

LOCK TABLES `tblaffiliate_m_referrals` WRITE;
/*!40000 ALTER TABLE `tblaffiliate_m_referrals` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblaffiliate_m_referrals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblaffiliate_m_tracking`
--

DROP TABLE IF EXISTS `tblaffiliate_m_tracking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblaffiliate_m_tracking` (
  `tracking_id` int(11) NOT NULL AUTO_INCREMENT,
  `affiliate_slug` varchar(255) NOT NULL,
  `rel_type` varchar(255) NOT NULL,
  `rel_id` int(11) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phonenumber` varchar(255) DEFAULT NULL,
  `metadata` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`tracking_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblaffiliate_m_tracking`
--

LOCK TABLES `tblaffiliate_m_tracking` WRITE;
/*!40000 ALTER TABLE `tblaffiliate_m_tracking` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblaffiliate_m_tracking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblannouncements`
--

DROP TABLE IF EXISTS `tblannouncements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblannouncements` (
  `announcementid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `message` mediumtext DEFAULT NULL,
  `showtousers` int(11) NOT NULL,
  `showtostaff` int(11) NOT NULL,
  `showname` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  `userid` varchar(100) NOT NULL,
  PRIMARY KEY (`announcementid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblannouncements`
--

LOCK TABLES `tblannouncements` WRITE;
/*!40000 ALTER TABLE `tblannouncements` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblannouncements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblbonus_discipline`
--

DROP TABLE IF EXISTS `tblbonus_discipline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblbonus_discipline` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `id_criteria` varchar(200) DEFAULT NULL,
  `type` int(3) NOT NULL,
  `apply_for` varchar(50) DEFAULT NULL,
  `from_time` datetime DEFAULT NULL,
  `lever_bonus` int(11) DEFAULT NULL,
  `approver` int(11) DEFAULT NULL,
  `url_file` longtext DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `id_admin` int(3) DEFAULT NULL,
  `status` int(3) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblbonus_discipline`
--

LOCK TABLES `tblbonus_discipline` WRITE;
/*!40000 ALTER TABLE `tblbonus_discipline` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblbonus_discipline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblbonus_discipline_detail`
--

DROP TABLE IF EXISTS `tblbonus_discipline_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblbonus_discipline_detail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_bonus_discipline` int(11) NOT NULL,
  `from_time` datetime DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `department_id` longtext DEFAULT NULL,
  `lever_bonus` int(11) DEFAULT NULL,
  `formality` varchar(50) DEFAULT NULL,
  `formality_value` varchar(100) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblbonus_discipline_detail`
--

LOCK TABLES `tblbonus_discipline_detail` WRITE;
/*!40000 ALTER TABLE `tblbonus_discipline_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblbonus_discipline_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblcheck_in_out`
--

DROP TABLE IF EXISTS `tblcheck_in_out`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblcheck_in_out` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `type_check` int(11) DEFAULT NULL,
  `type` varchar(5) NOT NULL DEFAULT 'W',
  `route_point_id` int(11) DEFAULT NULL,
  `workplace_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcheck_in_out`
--

LOCK TABLES `tblcheck_in_out` WRITE;
/*!40000 ALTER TABLE `tblcheck_in_out` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblcheck_in_out` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblchecklist`
--

DROP TABLE IF EXISTS `tblchecklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblchecklist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `group_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblchecklist`
--

LOCK TABLES `tblchecklist` WRITE;
/*!40000 ALTER TABLE `tblchecklist` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblchecklist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblchecklist_allocation`
--

DROP TABLE IF EXISTS `tblchecklist_allocation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblchecklist_allocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `group_id` int(11) DEFAULT NULL,
  `staffid` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblchecklist_allocation`
--

LOCK TABLES `tblchecklist_allocation` WRITE;
/*!40000 ALTER TABLE `tblchecklist_allocation` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblchecklist_allocation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblclients`
--

DROP TABLE IF EXISTS `tblclients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblclients` (
  `userid` int(11) NOT NULL AUTO_INCREMENT,
  `company` varchar(191) DEFAULT NULL,
  `vat` varchar(50) DEFAULT NULL,
  `phonenumber` varchar(30) DEFAULT NULL,
  `country` int(11) NOT NULL DEFAULT 0,
  `city` varchar(100) DEFAULT NULL,
  `zip` varchar(15) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `address` varchar(191) DEFAULT NULL,
  `website` varchar(150) DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `active` int(11) NOT NULL DEFAULT 1,
  `leadid` int(11) DEFAULT NULL,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT 0,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT 0,
  `longitude` varchar(191) DEFAULT NULL,
  `latitude` varchar(191) DEFAULT NULL,
  `default_language` varchar(40) DEFAULT NULL,
  `default_currency` int(11) NOT NULL DEFAULT 0,
  `show_primary_contact` int(11) NOT NULL DEFAULT 0,
  `stripe_id` varchar(40) DEFAULT NULL,
  `registration_confirmed` int(11) NOT NULL DEFAULT 1,
  `addedfrom` int(11) NOT NULL DEFAULT 0,
  `balance` decimal(15,2) DEFAULT NULL,
  `balance_as_of` date DEFAULT NULL,
  `loy_point` decimal(10,0) DEFAULT 0,
  `sector` varchar(255) DEFAULT NULL,
  `industry` varchar(255) DEFAULT NULL,
  `continue_from_date` date DEFAULT NULL,
  PRIMARY KEY (`userid`),
  KEY `country` (`country`),
  KEY `leadid` (`leadid`),
  KEY `company` (`company`),
  KEY `active` (`active`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblclients`
--

LOCK TABLES `tblclients` WRITE;
/*!40000 ALTER TABLE `tblclients` DISABLE KEYS */;
INSERT INTO `tblclients` VALUES
(1,'FECUNI','','08888810575',102,'Pune','411009','Maharashtra','C 25 sector 24, noida, 201301, IN','','2025-06-25 23:46:11',1,NULL,'C 25 sector 24, noida, 201301, IN','Pune','Maharashtra','411009',102,'C 25 sector 24, noida, 201301, IN','Pune','Maharashtra','411009',102,NULL,NULL,'',0,0,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL),
(2,'Minera software Solution ,Sweden','123448',NULL,0,NULL,NULL,NULL,NULL,NULL,'2025-06-26 17:11:40',1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL,NULL,'english',0,0,NULL,1,0,NULL,NULL,0,'manufacturing','apparel_and_garments','2025-06-26'),
(3,'INDIA TECH','23456787654',NULL,0,NULL,NULL,NULL,NULL,NULL,'2025-06-27 11:57:11',1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL,NULL,'english',0,0,NULL,1,0,NULL,NULL,0,'manufacturing','food_and_beverage','2025-06-27'),
(4,'Audi','12345765',NULL,0,NULL,NULL,NULL,NULL,NULL,'2025-06-27 12:49:24',1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL,NULL,'english',0,0,NULL,1,0,NULL,NULL,0,'manufacturing','cosmetics_and_personal_care','2025-06-27'),
(5,'tata','',NULL,0,NULL,NULL,NULL,NULL,NULL,'2025-07-01 17:24:38',1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL,NULL,'english',0,0,NULL,1,0,NULL,NULL,0,'','','0000-00-00');
/*!40000 ALTER TABLE `tblclients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblconsent_purposes`
--

DROP TABLE IF EXISTS `tblconsent_purposes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblconsent_purposes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `last_updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblconsent_purposes`
--

LOCK TABLES `tblconsent_purposes` WRITE;
/*!40000 ALTER TABLE `tblconsent_purposes` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblconsent_purposes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblconsents`
--

DROP TABLE IF EXISTS `tblconsents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblconsents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action` varchar(10) NOT NULL,
  `date` datetime NOT NULL,
  `ip` varchar(40) NOT NULL,
  `contact_id` int(11) NOT NULL DEFAULT 0,
  `lead_id` int(11) NOT NULL DEFAULT 0,
  `description` mediumtext DEFAULT NULL,
  `opt_in_purpose_description` mediumtext DEFAULT NULL,
  `purpose_id` int(11) NOT NULL,
  `staff_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `purpose_id` (`purpose_id`),
  KEY `contact_id` (`contact_id`),
  KEY `lead_id` (`lead_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblconsents`
--

LOCK TABLES `tblconsents` WRITE;
/*!40000 ALTER TABLE `tblconsents` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblconsents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblcontact_permissions`
--

DROP TABLE IF EXISTS `tblcontact_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblcontact_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permission_id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcontact_permissions`
--

LOCK TABLES `tblcontact_permissions` WRITE;
/*!40000 ALTER TABLE `tblcontact_permissions` DISABLE KEYS */;
INSERT INTO `tblcontact_permissions` VALUES
(1,1,1),
(2,2,1),
(3,3,1),
(4,4,1),
(5,5,1),
(6,6,1),
(7,311301,1),
(8,311302,1),
(9,1,2),
(10,2,2),
(11,3,2),
(12,4,2),
(13,5,2),
(14,6,2),
(15,1,3),
(16,2,3),
(17,3,3),
(18,4,3),
(19,5,3),
(20,6,3),
(21,311301,3),
(22,311302,3),
(23,1,4),
(24,2,4),
(25,3,4),
(26,4,4),
(27,5,4),
(28,6,4),
(29,311301,4),
(30,311302,4),
(31,1,5),
(32,2,5),
(33,3,5),
(34,4,5),
(35,5,5),
(36,6,5),
(37,311301,5),
(38,311302,5);
/*!40000 ALTER TABLE `tblcontact_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblcontacts`
--

DROP TABLE IF EXISTS `tblcontacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblcontacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `is_primary` int(11) NOT NULL DEFAULT 1,
  `firstname` varchar(191) NOT NULL,
  `lastname` varchar(191) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phonenumber` varchar(100) NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `new_pass_key` varchar(32) DEFAULT NULL,
  `new_pass_key_requested` datetime DEFAULT NULL,
  `email_verified_at` datetime DEFAULT NULL,
  `email_verification_key` varchar(32) DEFAULT NULL,
  `email_verification_sent_at` datetime DEFAULT NULL,
  `last_ip` varchar(40) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_password_change` datetime DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `profile_image` varchar(191) DEFAULT NULL,
  `direction` varchar(3) DEFAULT NULL,
  `invoice_emails` tinyint(1) NOT NULL DEFAULT 1,
  `estimate_emails` tinyint(1) NOT NULL DEFAULT 1,
  `credit_note_emails` tinyint(1) NOT NULL DEFAULT 1,
  `contract_emails` tinyint(1) NOT NULL DEFAULT 1,
  `task_emails` tinyint(1) NOT NULL DEFAULT 1,
  `project_emails` tinyint(1) NOT NULL DEFAULT 1,
  `ticket_emails` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `firstname` (`firstname`),
  KEY `lastname` (`lastname`),
  KEY `email` (`email`),
  KEY `is_primary` (`is_primary`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcontacts`
--

LOCK TABLES `tblcontacts` WRITE;
/*!40000 ALTER TABLE `tblcontacts` DISABLE KEYS */;
INSERT INTO `tblcontacts` VALUES
(1,1,1,'Dayanand','yadav','sales@techdotbit.com','','','2025-06-25 23:46:56','$2a$08$e23JGTdR69bMBa.F7eTJzeITNEHfLD5.YBQ3E/.m47h23xSRtXAse',NULL,NULL,'2025-06-05 12:59:12',NULL,NULL,'157.48.80.182','2025-06-26 06:59:48',NULL,1,NULL,'',1,1,1,1,1,1,1),
(2,2,1,'Dayanand','Sweden','info.vikaasyadav@gmail.com','+9108233081931',NULL,'2025-06-26 17:11:40','$2a$08$7PkYjviBVdhUFeqZ9yznfO2bJQWPCa51bZ4EOd35CZFhlRcjxf58m',NULL,NULL,'2025-06-05 12:59:12','78c841253560ab49371b2d778b54f267',NULL,'2409:40d4:10cd:43f8:f408:13f9:e02c:5190','2025-06-27 11:32:24',NULL,1,NULL,NULL,1,1,1,1,1,1,1),
(3,3,1,'Dayanand','yadav','india@techdotbit.com','+9108233081931',NULL,'2025-06-27 11:57:11','$2a$08$pInCZBnduv2ct5k1m95x5.jlwZHmFx4MkEzrCnRUGiRWcddiFjI76',NULL,NULL,'2025-06-05 12:59:12','70d5b615d0ec56206f8b468525658e95',NULL,'2409:40d4:10cd:43f8:f408:13f9:e02c:5190','2025-06-27 12:01:57',NULL,1,NULL,NULL,1,1,1,1,1,1,1),
(4,4,1,'Dayanand','yadav','audi@techdotbit.com','+9108233081931',NULL,'2025-06-27 12:49:24','$2a$08$zh.xBiT9VPaWJilyBr.N..SsJEIny1Ld1PpSL7449wq2E5zeHZ5VK',NULL,NULL,'2025-06-05 12:59:12','828f9638a7733cc086ab02f54260dc90',NULL,'2405:201:4018:225d:9952:89b6:f4e2:c984','2025-07-01 16:40:29',NULL,1,NULL,NULL,1,1,1,1,1,1,1),
(5,5,1,'Vishal','Shankar','vishalshankar2004@gmail.com','+9107903518911',NULL,'2025-07-01 17:24:38','$2a$08$2/l4G1F.jrPSUvTcrhVuVuzy21ZoHtqKPQgYu562ykuIqN5Hq6ady',NULL,NULL,'2025-06-05 12:59:12','a040f09d8872e70294092bfb82749604',NULL,'2405:201:4018:225d:25a3:777b:1fb8:f323','2025-07-01 17:24:38',NULL,1,NULL,NULL,1,1,1,1,1,1,1);
/*!40000 ALTER TABLE `tblcontacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblcontract_comments`
--

DROP TABLE IF EXISTS `tblcontract_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblcontract_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` longtext DEFAULT NULL,
  `contract_id` int(11) NOT NULL,
  `staffid` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcontract_comments`
--

LOCK TABLES `tblcontract_comments` WRITE;
/*!40000 ALTER TABLE `tblcontract_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblcontract_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblcontract_renewals`
--

DROP TABLE IF EXISTS `tblcontract_renewals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblcontract_renewals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contractid` int(11) NOT NULL,
  `old_start_date` date NOT NULL,
  `new_start_date` date NOT NULL,
  `old_end_date` date DEFAULT NULL,
  `new_end_date` date DEFAULT NULL,
  `old_value` decimal(15,2) DEFAULT NULL,
  `new_value` decimal(15,2) DEFAULT NULL,
  `date_renewed` datetime NOT NULL,
  `renewed_by` varchar(100) NOT NULL,
  `renewed_by_staff_id` int(11) NOT NULL DEFAULT 0,
  `is_on_old_expiry_notified` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcontract_renewals`
--

LOCK TABLES `tblcontract_renewals` WRITE;
/*!40000 ALTER TABLE `tblcontract_renewals` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblcontract_renewals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblcontracts`
--

DROP TABLE IF EXISTS `tblcontracts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblcontracts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` longtext DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `subject` varchar(191) DEFAULT NULL,
  `client` int(11) NOT NULL,
  `datestart` date DEFAULT NULL,
  `dateend` date DEFAULT NULL,
  `contract_type` int(11) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  `isexpirynotified` int(11) NOT NULL DEFAULT 0,
  `contract_value` decimal(15,2) DEFAULT NULL,
  `trash` tinyint(1) DEFAULT 0,
  `not_visible_to_client` tinyint(1) NOT NULL DEFAULT 0,
  `hash` varchar(32) DEFAULT NULL,
  `signed` tinyint(1) NOT NULL DEFAULT 0,
  `signature` varchar(40) DEFAULT NULL,
  `marked_as_signed` tinyint(1) NOT NULL DEFAULT 0,
  `acceptance_firstname` varchar(50) DEFAULT NULL,
  `acceptance_lastname` varchar(50) DEFAULT NULL,
  `acceptance_email` varchar(100) DEFAULT NULL,
  `acceptance_date` datetime DEFAULT NULL,
  `acceptance_ip` varchar(40) DEFAULT NULL,
  `short_link` varchar(100) DEFAULT NULL,
  `last_sent_at` datetime DEFAULT NULL,
  `contacts_sent_to` mediumtext DEFAULT NULL,
  `last_sign_reminder_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `client` (`client`),
  KEY `contract_type` (`contract_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcontracts`
--

LOCK TABLES `tblcontracts` WRITE;
/*!40000 ALTER TABLE `tblcontracts` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblcontracts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblcontracts_types`
--

DROP TABLE IF EXISTS `tblcontracts_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblcontracts_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcontracts_types`
--

LOCK TABLES `tblcontracts_types` WRITE;
/*!40000 ALTER TABLE `tblcontracts_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblcontracts_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblcountries`
--

DROP TABLE IF EXISTS `tblcountries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblcountries` (
  `country_id` int(11) NOT NULL AUTO_INCREMENT,
  `iso2` char(2) DEFAULT NULL,
  `short_name` varchar(80) NOT NULL DEFAULT '',
  `long_name` varchar(80) NOT NULL DEFAULT '',
  `iso3` char(3) DEFAULT NULL,
  `numcode` varchar(6) DEFAULT NULL,
  `un_member` varchar(12) DEFAULT NULL,
  `calling_code` varchar(8) DEFAULT NULL,
  `cctld` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`country_id`)
) ENGINE=InnoDB AUTO_INCREMENT=251 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcountries`
--

LOCK TABLES `tblcountries` WRITE;
/*!40000 ALTER TABLE `tblcountries` DISABLE KEYS */;
INSERT INTO `tblcountries` VALUES
(1,'AF','Afghanistan','Islamic Republic of Afghanistan','AFG','004','yes','93','.af'),
(2,'AX','Aland Islands','&Aring;land Islands','ALA','248','no','358','.ax'),
(3,'AL','Albania','Republic of Albania','ALB','008','yes','355','.al'),
(4,'DZ','Algeria','People\'s Democratic Republic of Algeria','DZA','012','yes','213','.dz'),
(5,'AS','American Samoa','American Samoa','ASM','016','no','1+684','.as'),
(6,'AD','Andorra','Principality of Andorra','AND','020','yes','376','.ad'),
(7,'AO','Angola','Republic of Angola','AGO','024','yes','244','.ao'),
(8,'AI','Anguilla','Anguilla','AIA','660','no','1+264','.ai'),
(9,'AQ','Antarctica','Antarctica','ATA','010','no','672','.aq'),
(10,'AG','Antigua and Barbuda','Antigua and Barbuda','ATG','028','yes','1+268','.ag'),
(11,'AR','Argentina','Argentine Republic','ARG','032','yes','54','.ar'),
(12,'AM','Armenia','Republic of Armenia','ARM','051','yes','374','.am'),
(13,'AW','Aruba','Aruba','ABW','533','no','297','.aw'),
(14,'AU','Australia','Commonwealth of Australia','AUS','036','yes','61','.au'),
(15,'AT','Austria','Republic of Austria','AUT','040','yes','43','.at'),
(16,'AZ','Azerbaijan','Republic of Azerbaijan','AZE','031','yes','994','.az'),
(17,'BS','Bahamas','Commonwealth of The Bahamas','BHS','044','yes','1+242','.bs'),
(18,'BH','Bahrain','Kingdom of Bahrain','BHR','048','yes','973','.bh'),
(19,'BD','Bangladesh','People\'s Republic of Bangladesh','BGD','050','yes','880','.bd'),
(20,'BB','Barbados','Barbados','BRB','052','yes','1+246','.bb'),
(21,'BY','Belarus','Republic of Belarus','BLR','112','yes','375','.by'),
(22,'BE','Belgium','Kingdom of Belgium','BEL','056','yes','32','.be'),
(23,'BZ','Belize','Belize','BLZ','084','yes','501','.bz'),
(24,'BJ','Benin','Republic of Benin','BEN','204','yes','229','.bj'),
(25,'BM','Bermuda','Bermuda Islands','BMU','060','no','1+441','.bm'),
(26,'BT','Bhutan','Kingdom of Bhutan','BTN','064','yes','975','.bt'),
(27,'BO','Bolivia','Plurinational State of Bolivia','BOL','068','yes','591','.bo'),
(28,'BQ','Bonaire, Sint Eustatius and Saba','Bonaire, Sint Eustatius and Saba','BES','535','no','599','.bq'),
(29,'BA','Bosnia and Herzegovina','Bosnia and Herzegovina','BIH','070','yes','387','.ba'),
(30,'BW','Botswana','Republic of Botswana','BWA','072','yes','267','.bw'),
(31,'BV','Bouvet Island','Bouvet Island','BVT','074','no','NONE','.bv'),
(32,'BR','Brazil','Federative Republic of Brazil','BRA','076','yes','55','.br'),
(33,'IO','British Indian Ocean Territory','British Indian Ocean Territory','IOT','086','no','246','.io'),
(34,'BN','Brunei','Brunei Darussalam','BRN','096','yes','673','.bn'),
(35,'BG','Bulgaria','Republic of Bulgaria','BGR','100','yes','359','.bg'),
(36,'BF','Burkina Faso','Burkina Faso','BFA','854','yes','226','.bf'),
(37,'BI','Burundi','Republic of Burundi','BDI','108','yes','257','.bi'),
(38,'KH','Cambodia','Kingdom of Cambodia','KHM','116','yes','855','.kh'),
(39,'CM','Cameroon','Republic of Cameroon','CMR','120','yes','237','.cm'),
(40,'CA','Canada','Canada','CAN','124','yes','1','.ca'),
(41,'CV','Cape Verde','Republic of Cape Verde','CPV','132','yes','238','.cv'),
(42,'KY','Cayman Islands','The Cayman Islands','CYM','136','no','1+345','.ky'),
(43,'CF','Central African Republic','Central African Republic','CAF','140','yes','236','.cf'),
(44,'TD','Chad','Republic of Chad','TCD','148','yes','235','.td'),
(45,'CL','Chile','Republic of Chile','CHL','152','yes','56','.cl'),
(46,'CN','China','People\'s Republic of China','CHN','156','yes','86','.cn'),
(47,'CX','Christmas Island','Christmas Island','CXR','162','no','61','.cx'),
(48,'CC','Cocos (Keeling) Islands','Cocos (Keeling) Islands','CCK','166','no','61','.cc'),
(49,'CO','Colombia','Republic of Colombia','COL','170','yes','57','.co'),
(50,'KM','Comoros','Union of the Comoros','COM','174','yes','269','.km'),
(51,'CG','Congo','Republic of the Congo','COG','178','yes','242','.cg'),
(52,'CK','Cook Islands','Cook Islands','COK','184','some','682','.ck'),
(53,'CR','Costa Rica','Republic of Costa Rica','CRI','188','yes','506','.cr'),
(54,'CI','Cote d\'ivoire (Ivory Coast)','Republic of C&ocirc;te D\'Ivoire (Ivory Coast)','CIV','384','yes','225','.ci'),
(55,'HR','Croatia','Republic of Croatia','HRV','191','yes','385','.hr'),
(56,'CU','Cuba','Republic of Cuba','CUB','192','yes','53','.cu'),
(57,'CW','Curacao','Cura&ccedil;ao','CUW','531','no','599','.cw'),
(58,'CY','Cyprus','Republic of Cyprus','CYP','196','yes','357','.cy'),
(59,'CZ','Czech Republic','Czech Republic','CZE','203','yes','420','.cz'),
(60,'CD','Democratic Republic of the Congo','Democratic Republic of the Congo','COD','180','yes','243','.cd'),
(61,'DK','Denmark','Kingdom of Denmark','DNK','208','yes','45','.dk'),
(62,'DJ','Djibouti','Republic of Djibouti','DJI','262','yes','253','.dj'),
(63,'DM','Dominica','Commonwealth of Dominica','DMA','212','yes','1+767','.dm'),
(64,'DO','Dominican Republic','Dominican Republic','DOM','214','yes','1+809, 8','.do'),
(65,'EC','Ecuador','Republic of Ecuador','ECU','218','yes','593','.ec'),
(66,'EG','Egypt','Arab Republic of Egypt','EGY','818','yes','20','.eg'),
(67,'SV','El Salvador','Republic of El Salvador','SLV','222','yes','503','.sv'),
(68,'GQ','Equatorial Guinea','Republic of Equatorial Guinea','GNQ','226','yes','240','.gq'),
(69,'ER','Eritrea','State of Eritrea','ERI','232','yes','291','.er'),
(70,'EE','Estonia','Republic of Estonia','EST','233','yes','372','.ee'),
(71,'ET','Ethiopia','Federal Democratic Republic of Ethiopia','ETH','231','yes','251','.et'),
(72,'FK','Falkland Islands (Malvinas)','The Falkland Islands (Malvinas)','FLK','238','no','500','.fk'),
(73,'FO','Faroe Islands','The Faroe Islands','FRO','234','no','298','.fo'),
(74,'FJ','Fiji','Republic of Fiji','FJI','242','yes','679','.fj'),
(75,'FI','Finland','Republic of Finland','FIN','246','yes','358','.fi'),
(76,'FR','France','French Republic','FRA','250','yes','33','.fr'),
(77,'GF','French Guiana','French Guiana','GUF','254','no','594','.gf'),
(78,'PF','French Polynesia','French Polynesia','PYF','258','no','689','.pf'),
(79,'TF','French Southern Territories','French Southern Territories','ATF','260','no',NULL,'.tf'),
(80,'GA','Gabon','Gabonese Republic','GAB','266','yes','241','.ga'),
(81,'GM','Gambia','Republic of The Gambia','GMB','270','yes','220','.gm'),
(82,'GE','Georgia','Georgia','GEO','268','yes','995','.ge'),
(83,'DE','Germany','Federal Republic of Germany','DEU','276','yes','49','.de'),
(84,'GH','Ghana','Republic of Ghana','GHA','288','yes','233','.gh'),
(85,'GI','Gibraltar','Gibraltar','GIB','292','no','350','.gi'),
(86,'GR','Greece','Hellenic Republic','GRC','300','yes','30','.gr'),
(87,'GL','Greenland','Greenland','GRL','304','no','299','.gl'),
(88,'GD','Grenada','Grenada','GRD','308','yes','1+473','.gd'),
(89,'GP','Guadaloupe','Guadeloupe','GLP','312','no','590','.gp'),
(90,'GU','Guam','Guam','GUM','316','no','1+671','.gu'),
(91,'GT','Guatemala','Republic of Guatemala','GTM','320','yes','502','.gt'),
(92,'GG','Guernsey','Guernsey','GGY','831','no','44','.gg'),
(93,'GN','Guinea','Republic of Guinea','GIN','324','yes','224','.gn'),
(94,'GW','Guinea-Bissau','Republic of Guinea-Bissau','GNB','624','yes','245','.gw'),
(95,'GY','Guyana','Co-operative Republic of Guyana','GUY','328','yes','592','.gy'),
(96,'HT','Haiti','Republic of Haiti','HTI','332','yes','509','.ht'),
(97,'HM','Heard Island and McDonald Islands','Heard Island and McDonald Islands','HMD','334','no','NONE','.hm'),
(98,'HN','Honduras','Republic of Honduras','HND','340','yes','504','.hn'),
(99,'HK','Hong Kong','Hong Kong','HKG','344','no','852','.hk'),
(100,'HU','Hungary','Hungary','HUN','348','yes','36','.hu'),
(101,'IS','Iceland','Republic of Iceland','ISL','352','yes','354','.is'),
(102,'IN','India','Republic of India','IND','356','yes','91','.in'),
(103,'ID','Indonesia','Republic of Indonesia','IDN','360','yes','62','.id'),
(104,'IR','Iran','Islamic Republic of Iran','IRN','364','yes','98','.ir'),
(105,'IQ','Iraq','Republic of Iraq','IRQ','368','yes','964','.iq'),
(106,'IE','Ireland','Ireland','IRL','372','yes','353','.ie'),
(107,'IM','Isle of Man','Isle of Man','IMN','833','no','44','.im'),
(108,'IL','Israel','State of Israel','ISR','376','yes','972','.il'),
(109,'IT','Italy','Italian Republic','ITA','380','yes','39','.jm'),
(110,'JM','Jamaica','Jamaica','JAM','388','yes','1+876','.jm'),
(111,'JP','Japan','Japan','JPN','392','yes','81','.jp'),
(112,'JE','Jersey','The Bailiwick of Jersey','JEY','832','no','44','.je'),
(113,'JO','Jordan','Hashemite Kingdom of Jordan','JOR','400','yes','962','.jo'),
(114,'KZ','Kazakhstan','Republic of Kazakhstan','KAZ','398','yes','7','.kz'),
(115,'KE','Kenya','Republic of Kenya','KEN','404','yes','254','.ke'),
(116,'KI','Kiribati','Republic of Kiribati','KIR','296','yes','686','.ki'),
(117,'XK','Kosovo','Republic of Kosovo','---','---','some','381',''),
(118,'KW','Kuwait','State of Kuwait','KWT','414','yes','965','.kw'),
(119,'KG','Kyrgyzstan','Kyrgyz Republic','KGZ','417','yes','996','.kg'),
(120,'LA','Laos','Lao People\'s Democratic Republic','LAO','418','yes','856','.la'),
(121,'LV','Latvia','Republic of Latvia','LVA','428','yes','371','.lv'),
(122,'LB','Lebanon','Republic of Lebanon','LBN','422','yes','961','.lb'),
(123,'LS','Lesotho','Kingdom of Lesotho','LSO','426','yes','266','.ls'),
(124,'LR','Liberia','Republic of Liberia','LBR','430','yes','231','.lr'),
(125,'LY','Libya','Libya','LBY','434','yes','218','.ly'),
(126,'LI','Liechtenstein','Principality of Liechtenstein','LIE','438','yes','423','.li'),
(127,'LT','Lithuania','Republic of Lithuania','LTU','440','yes','370','.lt'),
(128,'LU','Luxembourg','Grand Duchy of Luxembourg','LUX','442','yes','352','.lu'),
(129,'MO','Macao','The Macao Special Administrative Region','MAC','446','no','853','.mo'),
(130,'MK','North Macedonia','Republic of North Macedonia','MKD','807','yes','389','.mk'),
(131,'MG','Madagascar','Republic of Madagascar','MDG','450','yes','261','.mg'),
(132,'MW','Malawi','Republic of Malawi','MWI','454','yes','265','.mw'),
(133,'MY','Malaysia','Malaysia','MYS','458','yes','60','.my'),
(134,'MV','Maldives','Republic of Maldives','MDV','462','yes','960','.mv'),
(135,'ML','Mali','Republic of Mali','MLI','466','yes','223','.ml'),
(136,'MT','Malta','Republic of Malta','MLT','470','yes','356','.mt'),
(137,'MH','Marshall Islands','Republic of the Marshall Islands','MHL','584','yes','692','.mh'),
(138,'MQ','Martinique','Martinique','MTQ','474','no','596','.mq'),
(139,'MR','Mauritania','Islamic Republic of Mauritania','MRT','478','yes','222','.mr'),
(140,'MU','Mauritius','Republic of Mauritius','MUS','480','yes','230','.mu'),
(141,'YT','Mayotte','Mayotte','MYT','175','no','262','.yt'),
(142,'MX','Mexico','United Mexican States','MEX','484','yes','52','.mx'),
(143,'FM','Micronesia','Federated States of Micronesia','FSM','583','yes','691','.fm'),
(144,'MD','Moldava','Republic of Moldova','MDA','498','yes','373','.md'),
(145,'MC','Monaco','Principality of Monaco','MCO','492','yes','377','.mc'),
(146,'MN','Mongolia','Mongolia','MNG','496','yes','976','.mn'),
(147,'ME','Montenegro','Montenegro','MNE','499','yes','382','.me'),
(148,'MS','Montserrat','Montserrat','MSR','500','no','1+664','.ms'),
(149,'MA','Morocco','Kingdom of Morocco','MAR','504','yes','212','.ma'),
(150,'MZ','Mozambique','Republic of Mozambique','MOZ','508','yes','258','.mz'),
(151,'MM','Myanmar (Burma)','Republic of the Union of Myanmar','MMR','104','yes','95','.mm'),
(152,'NA','Namibia','Republic of Namibia','NAM','516','yes','264','.na'),
(153,'NR','Nauru','Republic of Nauru','NRU','520','yes','674','.nr'),
(154,'NP','Nepal','Federal Democratic Republic of Nepal','NPL','524','yes','977','.np'),
(155,'NL','Netherlands','Kingdom of the Netherlands','NLD','528','yes','31','.nl'),
(156,'NC','New Caledonia','New Caledonia','NCL','540','no','687','.nc'),
(157,'NZ','New Zealand','New Zealand','NZL','554','yes','64','.nz'),
(158,'NI','Nicaragua','Republic of Nicaragua','NIC','558','yes','505','.ni'),
(159,'NE','Niger','Republic of Niger','NER','562','yes','227','.ne'),
(160,'NG','Nigeria','Federal Republic of Nigeria','NGA','566','yes','234','.ng'),
(161,'NU','Niue','Niue','NIU','570','some','683','.nu'),
(162,'NF','Norfolk Island','Norfolk Island','NFK','574','no','672','.nf'),
(163,'KP','North Korea','Democratic People\'s Republic of Korea','PRK','408','yes','850','.kp'),
(164,'MP','Northern Mariana Islands','Northern Mariana Islands','MNP','580','no','1+670','.mp'),
(165,'NO','Norway','Kingdom of Norway','NOR','578','yes','47','.no'),
(166,'OM','Oman','Sultanate of Oman','OMN','512','yes','968','.om'),
(167,'PK','Pakistan','Islamic Republic of Pakistan','PAK','586','yes','92','.pk'),
(168,'PW','Palau','Republic of Palau','PLW','585','yes','680','.pw'),
(169,'PS','Palestine','State of Palestine (or Occupied Palestinian Territory)','PSE','275','some','970','.ps'),
(170,'PA','Panama','Republic of Panama','PAN','591','yes','507','.pa'),
(171,'PG','Papua New Guinea','Independent State of Papua New Guinea','PNG','598','yes','675','.pg'),
(172,'PY','Paraguay','Republic of Paraguay','PRY','600','yes','595','.py'),
(173,'PE','Peru','Republic of Peru','PER','604','yes','51','.pe'),
(174,'PH','Philippines','Republic of the Philippines','PHL','608','yes','63','.ph'),
(175,'PN','Pitcairn','Pitcairn','PCN','612','no','NONE','.pn'),
(176,'PL','Poland','Republic of Poland','POL','616','yes','48','.pl'),
(177,'PT','Portugal','Portuguese Republic','PRT','620','yes','351','.pt'),
(178,'PR','Puerto Rico','Commonwealth of Puerto Rico','PRI','630','no','1+939','.pr'),
(179,'QA','Qatar','State of Qatar','QAT','634','yes','974','.qa'),
(180,'RE','Reunion','R&eacute;union','REU','638','no','262','.re'),
(181,'RO','Romania','Romania','ROU','642','yes','40','.ro'),
(182,'RU','Russia','Russian Federation','RUS','643','yes','7','.ru'),
(183,'RW','Rwanda','Republic of Rwanda','RWA','646','yes','250','.rw'),
(184,'BL','Saint Barthelemy','Saint Barth&eacute;lemy','BLM','652','no','590','.bl'),
(185,'SH','Saint Helena','Saint Helena, Ascension and Tristan da Cunha','SHN','654','no','290','.sh'),
(186,'KN','Saint Kitts and Nevis','Federation of Saint Christopher and Nevis','KNA','659','yes','1+869','.kn'),
(187,'LC','Saint Lucia','Saint Lucia','LCA','662','yes','1+758','.lc'),
(188,'MF','Saint Martin','Saint Martin','MAF','663','no','590','.mf'),
(189,'PM','Saint Pierre and Miquelon','Saint Pierre and Miquelon','SPM','666','no','508','.pm'),
(190,'VC','Saint Vincent and the Grenadines','Saint Vincent and the Grenadines','VCT','670','yes','1+784','.vc'),
(191,'WS','Samoa','Independent State of Samoa','WSM','882','yes','685','.ws'),
(192,'SM','San Marino','Republic of San Marino','SMR','674','yes','378','.sm'),
(193,'ST','Sao Tome and Principe','Democratic Republic of S&atilde;o Tom&eacute; and Pr&iacute;ncipe','STP','678','yes','239','.st'),
(194,'SA','Saudi Arabia','Kingdom of Saudi Arabia','SAU','682','yes','966','.sa'),
(195,'SN','Senegal','Republic of Senegal','SEN','686','yes','221','.sn'),
(196,'RS','Serbia','Republic of Serbia','SRB','688','yes','381','.rs'),
(197,'SC','Seychelles','Republic of Seychelles','SYC','690','yes','248','.sc'),
(198,'SL','Sierra Leone','Republic of Sierra Leone','SLE','694','yes','232','.sl'),
(199,'SG','Singapore','Republic of Singapore','SGP','702','yes','65','.sg'),
(200,'SX','Sint Maarten','Sint Maarten','SXM','534','no','1+721','.sx'),
(201,'SK','Slovakia','Slovak Republic','SVK','703','yes','421','.sk'),
(202,'SI','Slovenia','Republic of Slovenia','SVN','705','yes','386','.si'),
(203,'SB','Solomon Islands','Solomon Islands','SLB','090','yes','677','.sb'),
(204,'SO','Somalia','Somali Republic','SOM','706','yes','252','.so'),
(205,'ZA','South Africa','Republic of South Africa','ZAF','710','yes','27','.za'),
(206,'GS','South Georgia and the South Sandwich Islands','South Georgia and the South Sandwich Islands','SGS','239','no','500','.gs'),
(207,'KR','South Korea','Republic of Korea','KOR','410','yes','82','.kr'),
(208,'SS','South Sudan','Republic of South Sudan','SSD','728','yes','211','.ss'),
(209,'ES','Spain','Kingdom of Spain','ESP','724','yes','34','.es'),
(210,'LK','Sri Lanka','Democratic Socialist Republic of Sri Lanka','LKA','144','yes','94','.lk'),
(211,'SD','Sudan','Republic of the Sudan','SDN','729','yes','249','.sd'),
(212,'SR','Suriname','Republic of Suriname','SUR','740','yes','597','.sr'),
(213,'SJ','Svalbard and Jan Mayen','Svalbard and Jan Mayen','SJM','744','no','47','.sj'),
(214,'SZ','Swaziland','Kingdom of Swaziland','SWZ','748','yes','268','.sz'),
(215,'SE','Sweden','Kingdom of Sweden','SWE','752','yes','46','.se'),
(216,'CH','Switzerland','Swiss Confederation','CHE','756','yes','41','.ch'),
(217,'SY','Syria','Syrian Arab Republic','SYR','760','yes','963','.sy'),
(218,'TW','Taiwan','Republic of China (Taiwan)','TWN','158','former','886','.tw'),
(219,'TJ','Tajikistan','Republic of Tajikistan','TJK','762','yes','992','.tj'),
(220,'TZ','Tanzania','United Republic of Tanzania','TZA','834','yes','255','.tz'),
(221,'TH','Thailand','Kingdom of Thailand','THA','764','yes','66','.th'),
(222,'TL','Timor-Leste (East Timor)','Democratic Republic of Timor-Leste','TLS','626','yes','670','.tl'),
(223,'TG','Togo','Togolese Republic','TGO','768','yes','228','.tg'),
(224,'TK','Tokelau','Tokelau','TKL','772','no','690','.tk'),
(225,'TO','Tonga','Kingdom of Tonga','TON','776','yes','676','.to'),
(226,'TT','Trinidad and Tobago','Republic of Trinidad and Tobago','TTO','780','yes','1+868','.tt'),
(227,'TN','Tunisia','Republic of Tunisia','TUN','788','yes','216','.tn'),
(228,'TR','Turkey','Republic of Turkey','TUR','792','yes','90','.tr'),
(229,'TM','Turkmenistan','Turkmenistan','TKM','795','yes','993','.tm'),
(230,'TC','Turks and Caicos Islands','Turks and Caicos Islands','TCA','796','no','1+649','.tc'),
(231,'TV','Tuvalu','Tuvalu','TUV','798','yes','688','.tv'),
(232,'UG','Uganda','Republic of Uganda','UGA','800','yes','256','.ug'),
(233,'UA','Ukraine','Ukraine','UKR','804','yes','380','.ua'),
(234,'AE','United Arab Emirates','United Arab Emirates','ARE','784','yes','971','.ae'),
(235,'GB','United Kingdom','United Kingdom of Great Britain and Nothern Ireland','GBR','826','yes','44','.uk'),
(236,'US','United States','United States of America','USA','840','yes','1','.us'),
(237,'UM','United States Minor Outlying Islands','United States Minor Outlying Islands','UMI','581','no','NONE','NONE'),
(238,'UY','Uruguay','Eastern Republic of Uruguay','URY','858','yes','598','.uy'),
(239,'UZ','Uzbekistan','Republic of Uzbekistan','UZB','860','yes','998','.uz'),
(240,'VU','Vanuatu','Republic of Vanuatu','VUT','548','yes','678','.vu'),
(241,'VA','Vatican City','State of the Vatican City','VAT','336','no','39','.va'),
(242,'VE','Venezuela','Bolivarian Republic of Venezuela','VEN','862','yes','58','.ve'),
(243,'VN','Vietnam','Socialist Republic of Vietnam','VNM','704','yes','84','.vn'),
(244,'VG','Virgin Islands, British','British Virgin Islands','VGB','092','no','1+284','.vg'),
(245,'VI','Virgin Islands, US','Virgin Islands of the United States','VIR','850','no','1+340','.vi'),
(246,'WF','Wallis and Futuna','Wallis and Futuna','WLF','876','no','681','.wf'),
(247,'EH','Western Sahara','Western Sahara','ESH','732','no','212','.eh'),
(248,'YE','Yemen','Republic of Yemen','YEM','887','yes','967','.ye'),
(249,'ZM','Zambia','Republic of Zambia','ZMB','894','yes','260','.zm'),
(250,'ZW','Zimbabwe','Republic of Zimbabwe','ZWE','716','yes','263','.zw');
/*!40000 ALTER TABLE `tblcountries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblcreditnote_refunds`
--

DROP TABLE IF EXISTS `tblcreditnote_refunds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblcreditnote_refunds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `credit_note_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `refunded_on` date NOT NULL,
  `payment_mode` varchar(40) NOT NULL,
  `note` mediumtext DEFAULT NULL,
  `amount` decimal(15,2) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcreditnote_refunds`
--

LOCK TABLES `tblcreditnote_refunds` WRITE;
/*!40000 ALTER TABLE `tblcreditnote_refunds` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblcreditnote_refunds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblcreditnotes`
--

DROP TABLE IF EXISTS `tblcreditnotes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblcreditnotes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clientid` int(11) NOT NULL,
  `deleted_customer_name` varchar(100) DEFAULT NULL,
  `number` int(11) NOT NULL,
  `prefix` varchar(50) DEFAULT NULL,
  `number_format` int(11) NOT NULL DEFAULT 1,
  `datecreated` datetime NOT NULL,
  `date` date NOT NULL,
  `adminnote` mediumtext DEFAULT NULL,
  `terms` mediumtext DEFAULT NULL,
  `clientnote` mediumtext DEFAULT NULL,
  `currency` int(11) NOT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `total_tax` decimal(15,2) NOT NULL DEFAULT 0.00,
  `total` decimal(15,2) NOT NULL,
  `adjustment` decimal(15,2) DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `project_id` int(11) NOT NULL DEFAULT 0,
  `discount_percent` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `discount_type` varchar(30) NOT NULL,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT NULL,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT NULL,
  `include_shipping` tinyint(1) NOT NULL,
  `show_shipping_on_credit_note` tinyint(1) NOT NULL DEFAULT 1,
  `show_quantity_as` int(11) NOT NULL DEFAULT 1,
  `reference_no` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `currency` (`currency`),
  KEY `clientid` (`clientid`),
  KEY `project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcreditnotes`
--

LOCK TABLES `tblcreditnotes` WRITE;
/*!40000 ALTER TABLE `tblcreditnotes` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblcreditnotes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblcredits`
--

DROP TABLE IF EXISTS `tblcredits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblcredits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) NOT NULL,
  `credit_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `date_applied` datetime NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcredits`
--

LOCK TABLES `tblcredits` WRITE;
/*!40000 ALTER TABLE `tblcredits` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblcredits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblcurrencies`
--

DROP TABLE IF EXISTS `tblcurrencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblcurrencies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `decimal_separator` varchar(5) DEFAULT NULL,
  `thousand_separator` varchar(5) DEFAULT NULL,
  `placement` varchar(10) DEFAULT NULL,
  `isdefault` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcurrencies`
--

LOCK TABLES `tblcurrencies` WRITE;
/*!40000 ALTER TABLE `tblcurrencies` DISABLE KEYS */;
INSERT INTO `tblcurrencies` VALUES
(1,'$','USD','.',',','before',0),
(3,'₹','INR','.',',','before',1);
/*!40000 ALTER TABLE `tblcurrencies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblcurrency_rate_logs`
--

DROP TABLE IF EXISTS `tblcurrency_rate_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblcurrency_rate_logs` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `from_currency_id` int(11) DEFAULT NULL,
  `from_currency_name` varchar(100) DEFAULT NULL,
  `from_currency_rate` decimal(15,6) NOT NULL DEFAULT 0.000000,
  `to_currency_id` int(11) DEFAULT NULL,
  `to_currency_name` varchar(100) DEFAULT NULL,
  `to_currency_rate` decimal(15,6) NOT NULL DEFAULT 0.000000,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcurrency_rate_logs`
--

LOCK TABLES `tblcurrency_rate_logs` WRITE;
/*!40000 ALTER TABLE `tblcurrency_rate_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblcurrency_rate_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblcurrency_rates`
--

DROP TABLE IF EXISTS `tblcurrency_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblcurrency_rates` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `from_currency_id` int(11) DEFAULT NULL,
  `from_currency_name` varchar(100) DEFAULT NULL,
  `from_currency_rate` decimal(15,6) NOT NULL DEFAULT 0.000000,
  `to_currency_id` int(11) DEFAULT NULL,
  `to_currency_name` varchar(100) DEFAULT NULL,
  `to_currency_rate` decimal(15,6) NOT NULL DEFAULT 0.000000,
  `date_updated` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcurrency_rates`
--

LOCK TABLES `tblcurrency_rates` WRITE;
/*!40000 ALTER TABLE `tblcurrency_rates` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblcurrency_rates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblcustomer_admins`
--

DROP TABLE IF EXISTS `tblcustomer_admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblcustomer_admins` (
  `staff_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `date_assigned` mediumtext NOT NULL,
  KEY `customer_id` (`customer_id`),
  KEY `staff_id` (`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcustomer_admins`
--

LOCK TABLES `tblcustomer_admins` WRITE;
/*!40000 ALTER TABLE `tblcustomer_admins` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblcustomer_admins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblcustomer_groups`
--

DROP TABLE IF EXISTS `tblcustomer_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblcustomer_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupid` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `groupid` (`groupid`),
  KEY `customer_id` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcustomer_groups`
--

LOCK TABLES `tblcustomer_groups` WRITE;
/*!40000 ALTER TABLE `tblcustomer_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblcustomer_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblcustomers_groups`
--

DROP TABLE IF EXISTS `tblcustomers_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblcustomers_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcustomers_groups`
--

LOCK TABLES `tblcustomers_groups` WRITE;
/*!40000 ALTER TABLE `tblcustomers_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblcustomers_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblcustomfields`
--

DROP TABLE IF EXISTS `tblcustomfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblcustomfields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldto` varchar(30) DEFAULT NULL,
  `name` varchar(150) NOT NULL,
  `slug` varchar(150) NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT 0,
  `type` varchar(20) NOT NULL,
  `options` longtext DEFAULT NULL,
  `display_inline` tinyint(1) NOT NULL DEFAULT 0,
  `field_order` int(11) DEFAULT 0,
  `active` int(11) NOT NULL DEFAULT 1,
  `show_on_pdf` int(11) NOT NULL DEFAULT 0,
  `show_on_ticket_form` tinyint(1) NOT NULL DEFAULT 0,
  `only_admin` tinyint(1) NOT NULL DEFAULT 0,
  `show_on_table` tinyint(1) NOT NULL DEFAULT 0,
  `show_on_client_portal` int(11) NOT NULL DEFAULT 0,
  `disalow_client_to_edit` int(11) NOT NULL DEFAULT 0,
  `bs_column` int(11) NOT NULL DEFAULT 12,
  `default_value` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcustomfields`
--

LOCK TABLES `tblcustomfields` WRITE;
/*!40000 ALTER TABLE `tblcustomfields` DISABLE KEYS */;
INSERT INTO `tblcustomfields` VALUES
(1,'tasks','Estimate hour','tasks_estimate_hour',0,'number','',0,0,1,0,0,0,0,0,0,12,NULL);
/*!40000 ALTER TABLE `tblcustomfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblcustomfieldsvalues`
--

DROP TABLE IF EXISTS `tblcustomfieldsvalues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblcustomfieldsvalues` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `relid` int(11) NOT NULL,
  `fieldid` int(11) NOT NULL,
  `fieldto` varchar(15) NOT NULL,
  `value` mediumtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `relid` (`relid`),
  KEY `fieldto` (`fieldto`),
  KEY `fieldid` (`fieldid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcustomfieldsvalues`
--

LOCK TABLES `tblcustomfieldsvalues` WRITE;
/*!40000 ALTER TABLE `tblcustomfieldsvalues` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblcustomfieldsvalues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblday_off`
--

DROP TABLE IF EXISTS `tblday_off`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblday_off` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `off_reason` varchar(255) NOT NULL,
  `off_type` varchar(100) NOT NULL,
  `break_date` date NOT NULL,
  `timekeeping` varchar(45) DEFAULT NULL,
  `department` varchar(45) DEFAULT NULL,
  `position` varchar(45) DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  `repeat_by_year` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblday_off`
--

LOCK TABLES `tblday_off` WRITE;
/*!40000 ALTER TABLE `tblday_off` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblday_off` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbldepartments`
--

DROP TABLE IF EXISTS `tbldepartments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbldepartments` (
  `departmentid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `imap_username` varchar(191) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `email_from_header` tinyint(1) NOT NULL DEFAULT 0,
  `host` varchar(150) DEFAULT NULL,
  `password` longtext DEFAULT NULL,
  `encryption` varchar(3) DEFAULT NULL,
  `folder` varchar(191) NOT NULL DEFAULT 'INBOX',
  `delete_after_import` int(11) NOT NULL DEFAULT 0,
  `calendar_id` longtext DEFAULT NULL,
  `hidefromclient` tinyint(1) NOT NULL DEFAULT 0,
  `manager_id` int(11) DEFAULT 0,
  `parent_id` int(11) DEFAULT 0,
  PRIMARY KEY (`departmentid`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbldepartments`
--

LOCK TABLES `tbldepartments` WRITE;
/*!40000 ALTER TABLE `tbldepartments` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbldepartments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbldismissed_announcements`
--

DROP TABLE IF EXISTS `tbldismissed_announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbldismissed_announcements` (
  `dismissedannouncementid` int(11) NOT NULL AUTO_INCREMENT,
  `announcementid` int(11) NOT NULL,
  `staff` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  PRIMARY KEY (`dismissedannouncementid`),
  KEY `announcementid` (`announcementid`),
  KEY `staff` (`staff`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbldismissed_announcements`
--

LOCK TABLES `tbldismissed_announcements` WRITE;
/*!40000 ALTER TABLE `tbldismissed_announcements` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbldismissed_announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblemailtemplates`
--

DROP TABLE IF EXISTS `tblemailtemplates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblemailtemplates` (
  `emailtemplateid` int(11) NOT NULL AUTO_INCREMENT,
  `type` longtext NOT NULL,
  `slug` varchar(100) NOT NULL,
  `language` varchar(40) DEFAULT NULL,
  `name` longtext NOT NULL,
  `subject` longtext NOT NULL,
  `message` longtext NOT NULL,
  `fromname` longtext NOT NULL,
  `fromemail` varchar(100) DEFAULT NULL,
  `plaintext` int(11) NOT NULL DEFAULT 0,
  `active` tinyint(4) NOT NULL DEFAULT 0,
  `order` int(11) NOT NULL,
  PRIMARY KEY (`emailtemplateid`)
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblemailtemplates`
--

LOCK TABLES `tblemailtemplates` WRITE;
/*!40000 ALTER TABLE `tblemailtemplates` DISABLE KEYS */;
INSERT INTO `tblemailtemplates` VALUES
(1,'client','new-client-created','english','New Contact Added/Registered (Welcome Email)','Welcome aboard','Dear {contact_firstname} {contact_lastname}<br /><br />Thank you for registering on the <strong>{companyname}</strong> CRM System.<br /><br />We just wanted to say welcome.<br /><br />Please contact us if you need any help.<br /><br />Click here to view your profile: <a href=\"{crm_url}\">{crm_url}</a><br /><br />Kind Regards, <br />{email_signature}<br /><br />(This is an automated email, so please don\'t reply to this email address)','{companyname} | CRM','',0,1,0),
(2,'invoice','invoice-send-to-client','english','Send Invoice to Customer','Invoice with number {invoice_number} created','<span style=\"font-size: 12pt;\">Dear {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">We have prepared the following invoice for you: <strong># {invoice_number}</strong></span><br /><br /><span style=\"font-size: 12pt;\"><strong>Invoice status</strong>: {invoice_status}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the invoice on the following link: <a href=\"{invoice_link}\">{invoice_number}</a></span><br /><br /><span style=\"font-size: 12pt;\">Please contact us for more information.</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),
(3,'ticket','new-ticket-opened-admin','english','New Ticket Opened (Opened by Staff, Sent to Customer)','New Support Ticket Opened','<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">New support ticket has been opened.</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject:</strong> {ticket_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Department:</strong> {ticket_department}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority:</strong> {ticket_priority}<br /></span><br /><span style=\"font-size: 12pt;\"><strong>Ticket message:</strong></span><br /><span style=\"font-size: 12pt;\">{ticket_message}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_public_url}\">#{ticket_id}</a><br /><br />Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),
(4,'ticket','ticket-reply','english','Ticket Reply (Sent to Customer)','New Ticket Reply','<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">You have a new ticket reply to ticket <a href=\"{ticket_public_url}\">#{ticket_id}</a></span><br /><br /><span style=\"font-size: 12pt;\"><strong>Ticket Subject:</strong> {ticket_subject}<br /></span><br /><span style=\"font-size: 12pt;\"><strong>Ticket message:</strong></span><br /><span style=\"font-size: 12pt;\">{ticket_message}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_public_url}\">#{ticket_id}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),
(5,'ticket','ticket-autoresponse','english','New Ticket Opened - Autoresponse','New Support Ticket Opened','<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">Thank you for contacting our support team. A support ticket has now been opened for your request. You will be notified when a response is made by email.</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject:</strong> {ticket_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Department</strong>: {ticket_department}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority:</strong> {ticket_priority}</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Ticket message:</strong></span><br /><span style=\"font-size: 12pt;\">{ticket_message}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_public_url}\">#{ticket_id}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),
(6,'invoice','invoice-payment-recorded','english','Invoice Payment Recorded (Sent to Customer)','Invoice Payment Recorded','<span style=\"font-size: 12pt;\">Hello {contact_firstname}&nbsp;{contact_lastname}<br /><br /></span>Thank you for the payment. Find the payment details below:<br /><br />-------------------------------------------------<br /><br />Amount:&nbsp;<strong>{payment_total}<br /></strong>Date:&nbsp;<strong>{payment_date}</strong><br />Invoice number:&nbsp;<span style=\"font-size: 12pt;\"><strong># {invoice_number}<br /><br /></strong></span>-------------------------------------------------<br /><br />You can always view the invoice for this payment at the following link:&nbsp;<a href=\"{invoice_link}\"><span style=\"font-size: 12pt;\">{invoice_number}</span></a><br /><br />We are looking forward working with you.<br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),
(7,'invoice','invoice-overdue-notice','english','Invoice Overdue Notice','Invoice Overdue Notice - {invoice_number}','<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">This is an overdue notice for invoice <strong># {invoice_number}</strong></span><br /><br /><span style=\"font-size: 12pt;\">This invoice was due: {invoice_duedate}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the invoice on the following link: <a href=\"{invoice_link}\">{invoice_number}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),
(8,'invoice','invoice-already-send','english','Invoice Already Sent to Customer','Invoice # {invoice_number} ','<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">At your request, here is the invoice with number <strong># {invoice_number}</strong></span><br /><br /><span style=\"font-size: 12pt;\">You can view the invoice on the following link: <a href=\"{invoice_link}\">{invoice_number}</a></span><br /><br /><span style=\"font-size: 12pt;\">Please contact us for more information.</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),
(9,'ticket','new-ticket-created-staff','english','New Ticket Created (Opened by Customer, Sent to Staff Members)','New Ticket Created','<p><span style=\"font-size: 12pt;\">A new support ticket has been opened.</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject</strong>: {ticket_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Department</strong>: {ticket_department}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority</strong>: {ticket_priority}<br /></span><br /><span style=\"font-size: 12pt;\"><strong>Ticket message:</strong></span><br /><span style=\"font-size: 12pt;\">{ticket_message}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_url}\">#{ticket_id}</a></span><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span></p>','{companyname} | CRM','',0,1,0),
(10,'estimate','estimate-send-to-client','english','Send Estimate to Customer','Estimate # {estimate_number} created','<span style=\"font-size: 12pt;\">Dear {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">Please find the attached estimate <strong># {estimate_number}</strong></span><br /><br /><span style=\"font-size: 12pt;\"><strong>Estimate status:</strong> {estimate_status}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the estimate on the following link: <a href=\"{estimate_link}\">{estimate_number}</a></span><br /><br /><span style=\"font-size: 12pt;\">We look forward to your communication.</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}<br /></span>','{companyname} | CRM','',0,1,0),
(11,'ticket','ticket-reply-to-admin','english','Ticket Reply (Sent to Staff)','New Support Ticket Reply','<span style=\"font-size: 12pt;\">A new support ticket reply from {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject</strong>: {ticket_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Department</strong>: {ticket_department}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority</strong>: {ticket_priority}</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Ticket message:</strong></span><br /><span style=\"font-size: 12pt;\">{ticket_message}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_url}\">#{ticket_id}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),
(12,'estimate','estimate-already-send','english','Estimate Already Sent to Customer','Estimate # {estimate_number} ','<span style=\"font-size: 12pt;\">Dear {contact_firstname} {contact_lastname}</span><br /> <br /><span style=\"font-size: 12pt;\">Thank you for your estimate request.</span><br /> <br /><span style=\"font-size: 12pt;\">You can view the estimate on the following link: <a href=\"{estimate_link}\">{estimate_number}</a></span><br /> <br /><span style=\"font-size: 12pt;\">Please contact us for more information.</span><br /> <br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),
(13,'contract','contract-expiration','english','Contract Expiration Reminder (Sent to Customer Contacts)','Contract Expiration Reminder','<span style=\"font-size: 12pt;\">Dear {client_company}</span><br /><br /><span style=\"font-size: 12pt;\">This is a reminder that the following contract will expire soon:</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject:</strong> {contract_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Description:</strong> {contract_description}</span><br /><span style=\"font-size: 12pt;\"><strong>Date Start:</strong> {contract_datestart}</span><br /><span style=\"font-size: 12pt;\"><strong>Date End:</strong> {contract_dateend}</span><br /><br /><span style=\"font-size: 12pt;\">Please contact us for more information.</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),
(14,'tasks','task-assigned','english','New Task Assigned (Sent to Staff)','New Task Assigned to You - {task_name}','<span style=\"font-size: 12pt;\">Dear {staff_firstname}</span><br /><br /><span style=\"font-size: 12pt;\">You have been assigned to a new task:</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Name:</strong> {task_name}<br /></span><strong>Start Date:</strong> {task_startdate}<br /><span style=\"font-size: 12pt;\"><strong>Due date:</strong> {task_duedate}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority:</strong> {task_priority}<br /><br /></span><span style=\"font-size: 12pt;\"><span>You can view the task on the following link</span>: <a href=\"{task_link}\">{task_name}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),
(15,'tasks','task-added-as-follower','english','Staff Member Added as Follower on Task (Sent to Staff)','You are added as follower on task - {task_name}','<span style=\"font-size: 12pt;\">Hi {staff_firstname}<br /></span><br /><span style=\"font-size: 12pt;\">You have been added as follower on the following task:</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Name:</strong> {task_name}</span><br /><span style=\"font-size: 12pt;\"><strong>Start date:</strong> {task_startdate}</span><br /><br /><span>You can view the task on the following link</span><span>: </span><a href=\"{task_link}\">{task_name}</a><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),
(16,'tasks','task-commented','english','New Comment on Task (Sent to Staff)','New Comment on Task - {task_name}','Dear {staff_firstname}<br /><br />A comment has been made on the following task:<br /><br /><strong>Name:</strong> {task_name}<br /><strong>Comment:</strong> {task_comment}<br /><br />You can view the task on the following link: <a href=\"{task_link}\">{task_name}</a><br /><br />Kind Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),
(17,'tasks','task-added-attachment','english','New Attachment(s) on Task (Sent to Staff)','New Attachment on Task - {task_name}','Hi {staff_firstname}<br /><br /><strong>{task_user_take_action}</strong> added an attachment on the following task:<br /><br /><strong>Name:</strong> {task_name}<br /><br />You can view the task on the following link: <a href=\"{task_link}\">{task_name}</a><br /><br />Kind Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),
(18,'estimate','estimate-declined-to-staff','english','Estimate Declined (Sent to Staff)','Customer Declined Estimate','<span style=\"font-size: 12pt;\">Hi</span><br /> <br /><span style=\"font-size: 12pt;\">Customer ({client_company}) declined estimate with number <strong># {estimate_number}</strong></span><br /> <br /><span style=\"font-size: 12pt;\">You can view the estimate on the following link: <a href=\"{estimate_link}\">{estimate_number}</a></span><br /> <br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),
(19,'estimate','estimate-accepted-to-staff','english','Estimate Accepted (Sent to Staff)','Customer Accepted Estimate','<span style=\"font-size: 12pt;\">Hi</span><br /> <br /><span style=\"font-size: 12pt;\">Customer ({client_company}) accepted estimate with number <strong># {estimate_number}</strong></span><br /> <br /><span style=\"font-size: 12pt;\">You can view the estimate on the following link: <a href=\"{estimate_link}\">{estimate_number}</a></span><br /> <br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),
(20,'proposals','proposal-client-accepted','english','Customer Action - Accepted (Sent to Staff)','Customer Accepted Proposal','<div>Hi<br /> <br />Client <strong>{proposal_proposal_to}</strong> accepted the following proposal:<br /> <br /><strong>Number:</strong> {proposal_number}<br /><strong>Subject</strong>: {proposal_subject}<br /><strong>Total</strong>: {proposal_total}<br /> <br />View the proposal on the following link: <a href=\"{proposal_link}\">{proposal_number}</a><br /> <br />Kind Regards,<br />{email_signature}</div>\r\n<div>&nbsp;</div>\r\n<div>&nbsp;</div>\r\n<div>&nbsp;</div>','{companyname} | CRM','',0,1,0),
(21,'proposals','proposal-send-to-customer','english','Send Proposal to Customer','Proposal With Number {proposal_number} Created','Dear {proposal_proposal_to}<br /><br />Please find our attached proposal.<br /><br />This proposal is valid until: {proposal_open_till}<br />You can view the proposal on the following link: <a href=\"{proposal_link}\">{proposal_number}</a><br /><br />Please don\'t hesitate to comment online if you have any questions.<br /><br />We look forward to your communication.<br /><br />Kind Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),
(22,'proposals','proposal-client-declined','english','Customer Action - Declined (Sent to Staff)','Client Declined Proposal','Hi<br /> <br />Customer <strong>{proposal_proposal_to}</strong> declined the proposal <strong>{proposal_subject}</strong><br /> <br />View the proposal on the following link <a href=\"{proposal_link}\">{proposal_number}</a>&nbsp;or from the admin area.<br /> <br />Kind Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),
(23,'proposals','proposal-client-thank-you','english','Thank You Email (Sent to Customer After Accept)','Thank for you accepting proposal','Dear {proposal_proposal_to}<br /> <br />Thank for for accepting the proposal.<br /> <br />We look forward to doing business with you.<br /> <br />We will contact you as soon as possible<br /> <br />Kind Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),
(24,'proposals','proposal-comment-to-client','english','New Comment Â (Sent to Customer/Lead)','New Proposal Comment','Dear {proposal_proposal_to}<br /> <br />A new comment has been made on the following proposal: <strong>{proposal_number}</strong><br /> <br />You can view and reply to the comment on the following link: <a href=\"{proposal_link}\">{proposal_number}</a><br /> <br />Kind Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),
(25,'proposals','proposal-comment-to-admin','english','New Comment (Sent to Staff) ','New Proposal Comment','Hi<br /> <br />A new comment has been made to the proposal <strong>{proposal_subject}</strong><br /> <br />You can view and reply to the comment on the following link: <a href=\"{proposal_link}\">{proposal_number}</a>&nbsp;or from the admin area.<br /> <br />{email_signature}','{companyname} | CRM','',0,1,0),
(26,'estimate','estimate-thank-you-to-customer','english','Thank You Email (Sent to Customer After Accept)','Thank for you accepting estimate','<span style=\"font-size: 12pt;\">Dear {contact_firstname} {contact_lastname}</span><br /> <br /><span style=\"font-size: 12pt;\">Thank for for accepting the estimate.</span><br /> <br /><span style=\"font-size: 12pt;\">We look forward to doing business with you.</span><br /> <br /><span style=\"font-size: 12pt;\">We will contact you as soon as possible.</span><br /> <br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),
(27,'tasks','task-deadline-notification','english','Task Deadline Reminder - Sent to Assigned Members','Task Deadline Reminder','Hi {staff_firstname}&nbsp;{staff_lastname}<br /><br />This is an automated email from {companyname}.<br /><br />The task <strong>{task_name}</strong> deadline is on <strong>{task_duedate}</strong>. <br />This task is still not finished.<br /><br />You can view the task on the following link: <a href=\"{task_link}\">{task_name}</a><br /><br />Kind Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),
(28,'contract','send-contract','english','Send Contract to Customer','Contract - {contract_subject}','<p><span style=\"font-size: 12pt;\">Hi&nbsp;{contact_firstname}&nbsp;{contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">Please find the <a href=\"{contract_link}\">{contract_subject}</a> attached.<br /><br />Description: {contract_description}<br /><br /></span><span style=\"font-size: 12pt;\">Looking forward to hear from you.</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span></p>','{companyname} | CRM','',0,1,0),
(29,'invoice','invoice-payment-recorded-to-staff','english','Invoice Payment Recorded (Sent to Staff)','New Invoice Payment','<span style=\"font-size: 12pt;\">Hi</span><br /><br /><span style=\"font-size: 12pt;\">Customer recorded payment for invoice <strong># {invoice_number}</strong></span><br /> <br /><span style=\"font-size: 12pt;\">You can view the invoice on the following link: <a href=\"{invoice_link}\">{invoice_number}</a></span><br /> <br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),
(30,'ticket','auto-close-ticket','english','Auto Close Ticket','Ticket Auto Closed','<p><span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">Ticket {ticket_subject} has been auto close due to inactivity.</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Ticket #</strong>: <a href=\"{ticket_public_url}\">{ticket_id}</a></span><br /><span style=\"font-size: 12pt;\"><strong>Department</strong>: {ticket_department}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority:</strong> {ticket_priority}</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span></p>','{companyname} | CRM','',0,1,0),
(31,'project','new-project-discussion-created-to-staff','english','New Project Discussion (Sent to Project Members)','New Project Discussion Created - {project_name}','<p>Hi {staff_firstname}<br /><br />New project discussion created from <strong>{discussion_creator}</strong><br /><br /><strong>Subject:</strong> {discussion_subject}<br /><strong>Description:</strong> {discussion_description}<br /><br />You can view the discussion on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a><br /><br />Kind Regards,<br />{email_signature}</p>','{companyname} | CRM','',0,1,0),
(32,'project','new-project-discussion-created-to-customer','english','New Project Discussion (Sent to Customer Contacts)','New Project Discussion Created - {project_name}','<p>Hello {contact_firstname} {contact_lastname}<br /><br />New project discussion created from <strong>{discussion_creator}</strong><br /><br /><strong>Subject:</strong> {discussion_subject}<br /><strong>Description:</strong> {discussion_description}<br /><br />You can view the discussion on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a><br /><br />Kind Regards,<br />{email_signature}</p>','{companyname} | CRM','',0,1,0),
(33,'project','new-project-file-uploaded-to-customer','english','New Project File(s) Uploaded (Sent to Customer Contacts)','New Project File(s) Uploaded - {project_name}','<p>Hello {contact_firstname} {contact_lastname}<br /><br />New project file is uploaded on <strong>{project_name}</strong> from <strong>{file_creator}</strong><br /><br />You can view the project on the following link: <a href=\"{project_link}\">{project_name}</a><br /><br />To view the file in our CRM you can click on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a><br /><br />Kind Regards,<br />{email_signature}</p>','{companyname} | CRM','',0,1,0),
(34,'project','new-project-file-uploaded-to-staff','english','New Project File(s) Uploaded (Sent to Project Members)','New Project File(s) Uploaded - {project_name}','<p>Hello&nbsp;{staff_firstname}</p>\r\n<p>New project&nbsp;file is uploaded on&nbsp;<strong>{project_name}</strong> from&nbsp;<strong>{file_creator}</strong></p>\r\n<p>You can view the project on the following link: <a href=\"{project_link}\">{project_name}<br /></a><br />To view&nbsp;the file you can click on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a></p>\r\n<p>Kind Regards,<br />{email_signature}</p>','{companyname} | CRM','',0,1,0),
(35,'project','new-project-discussion-comment-to-customer','english','New Discussion Comment  (Sent to Customer Contacts)','New Discussion Comment','<p><span style=\"font-size: 12pt;\">Hello {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">New discussion comment has been made on <strong>{discussion_subject}</strong> from <strong>{comment_creator}</strong></span><br /><br /><span style=\"font-size: 12pt;\"><strong>Discussion subject:</strong> {discussion_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Comment</strong>: {discussion_comment}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the discussion on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span></p>','{companyname} | CRM','',0,1,0),
(36,'project','new-project-discussion-comment-to-staff','english','New Discussion Comment (Sent to Project Members)','New Discussion Comment','<p>Hi {staff_firstname}<br /><br />New discussion comment has been made on <strong>{discussion_subject}</strong> from <strong>{comment_creator}</strong><br /><br /><strong>Discussion subject:</strong> {discussion_subject}<br /><strong>Comment:</strong> {discussion_comment}<br /><br />You can view the discussion on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a><br /><br />Kind Regards,<br />{email_signature}</p>','{companyname} | CRM','',0,1,0),
(37,'project','staff-added-as-project-member','english','Staff Added as Project Member','New project assigned to you','<p>Hi {staff_firstname}<br /><br />New project has been assigned to you.<br /><br />You can view the project on the following link <a href=\"{project_link}\">{project_name}</a><br /><br />{email_signature}</p>','{companyname} | CRM','',0,1,0),
(38,'estimate','estimate-expiry-reminder','english','Estimate Expiration Reminder','Estimate Expiration Reminder','<p><span style=\"font-size: 12pt;\">Hello {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">The estimate with <strong># {estimate_number}</strong> will expire on <strong>{estimate_expirydate}</strong></span><br /><br /><span style=\"font-size: 12pt;\">You can view the estimate on the following link: <a href=\"{estimate_link}\">{estimate_number}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span></p>','{companyname} | CRM','',0,1,0),
(39,'proposals','proposal-expiry-reminder','english','Proposal Expiration Reminder','Proposal Expiration Reminder','<p>Hello {proposal_proposal_to}<br /><br />The proposal {proposal_number}&nbsp;will expire on <strong>{proposal_open_till}</strong><br /><br />You can view the proposal on the following link: <a href=\"{proposal_link}\">{proposal_number}</a><br /><br />Kind Regards,<br />{email_signature}</p>','{companyname} | CRM','',0,1,0),
(40,'staff','new-staff-created','english','New Staff Created (Welcome Email)','You are added as staff member','Hi {staff_firstname}<br /><br />You are added as member on our CRM.<br /><br />Please use the following logic credentials:<br /><br /><strong>Email:</strong> {staff_email}<br /><strong>Password:</strong> {password}<br /><br />Click <a href=\"{admin_url}\">here </a>to login in the dashboard.<br /><br />Best Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),
(41,'client','contact-forgot-password','english','Forgot Password','Create New Password','<h2>Create a new password</h2>\r\nForgot your password?<br /> To create a new password, just follow this link:<br /> <br /><a href=\"{reset_password_url}\">Reset Password</a><br /> <br /> You received this email, because it was requested by a {companyname}&nbsp;user. This is part of the procedure to create a new password on the system. If you DID NOT request a new password then please ignore this email and your password will remain the same. <br /><br /> {email_signature}','{companyname} | CRM','',0,1,0),
(42,'client','contact-password-reseted','english','Password Reset - Confirmation','Your password has been changed','<strong><span style=\"font-size: 14pt;\">You have changed your password.</span><br /></strong><br /> Please, keep it in your records so you don\'t forget it.<br /> <br /> Your email address for login is: {contact_email}<br /><br />If this wasnt you, please contact us.<br /><br />{email_signature}','{companyname} | CRM','',0,1,0),
(43,'client','contact-set-password','english','Set New Password','Set new password on {companyname} ','<h2><span style=\"font-size: 14pt;\">Setup your new password on {companyname}</span></h2>\r\nPlease use the following link to set up your new password:<br /><br /><a href=\"{set_password_url}\">Set new password</a><br /><br />Keep it in your records so you don\'t forget it.<br /><br />Please set your new password in <strong>48 hours</strong>. After that, you won\'t be able to set your password because this link will expire.<br /><br />You can login at: <a href=\"{crm_url}\">{crm_url}</a><br />Your email address for login: {contact_email}<br /><br />{email_signature}','{companyname} | CRM','',0,1,0),
(44,'staff','staff-forgot-password','english','Forgot Password','Create New Password','<h2><span style=\"font-size: 14pt;\">Create a new password</span></h2>\r\nForgot your password?<br /> To create a new password, just follow this link:<br /> <br /><a href=\"{reset_password_url}\">Reset Password</a><br /> <br /> You received this email, because it was requested by a <strong>{companyname}</strong>&nbsp;user. This is part of the procedure to create a new password on the system. If you DID NOT request a new password then please ignore this email and your password will remain the same. <br /><br /> {email_signature}','{companyname} | CRM','',0,1,0),
(45,'staff','staff-password-reseted','english','Password Reset - Confirmation','Your password has been changed','<span style=\"font-size: 14pt;\"><strong>You have changed your password.<br /></strong></span><br /> Please, keep it in your records so you don\'t forget it.<br /> <br /> Your email address for login is: {staff_email}<br /><br /> If this wasnt you, please contact us.<br /><br />{email_signature}','{companyname} | CRM','',0,1,0),
(46,'project','assigned-to-project','english','New Project Created (Sent to Customer Contacts)','New Project Created','<p>Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}</p>\r\n<p>New project is assigned to your company.<br /><br /><strong>Project Name:</strong>&nbsp;{project_name}<br /><strong>Project Start Date:</strong>&nbsp;{project_start_date}</p>\r\n<p>You can view the project on the following link:&nbsp;<a href=\"{project_link}\">{project_name}</a></p>\r\n<p>We are looking forward hearing from you.<br /><br />Kind Regards,<br />{email_signature}</p>','{companyname} | CRM','',0,1,0),
(47,'tasks','task-added-attachment-to-contacts','english','New Attachment(s) on Task (Sent to Customer Contacts)','New Attachment on Task - {task_name}','<span>Hi {contact_firstname} {contact_lastname}</span><br /><br /><strong>{task_user_take_action}</strong><span> added an attachment on the following task:</span><br /><br /><strong>Name:</strong><span> {task_name}</span><br /><br /><span>You can view the task on the following link: </span><a href=\"{task_link}\">{task_name}</a><br /><br /><span>Kind Regards,</span><br /><span>{email_signature}</span>','{companyname} | CRM','',0,1,0),
(48,'tasks','task-commented-to-contacts','english','New Comment on Task (Sent to Customer Contacts)','New Comment on Task - {task_name}','<span>Dear {contact_firstname} {contact_lastname}</span><br /><br /><span>A comment has been made on the following task:</span><br /><br /><strong>Name:</strong><span> {task_name}</span><br /><strong>Comment:</strong><span> {task_comment}</span><br /><br /><span>You can view the task on the following link: </span><a href=\"{task_link}\">{task_name}</a><br /><br /><span>Kind Regards,</span><br /><span>{email_signature}</span>','{companyname} | CRM','',0,1,0),
(49,'leads','new-lead-assigned','english','New Lead Assigned to Staff Member','New lead assigned to you','<p>Hello {lead_assigned}<br /><br />New lead is assigned to you.<br /><br /><strong>Lead Name:</strong>&nbsp;{lead_name}<br /><strong>Lead Email:</strong>&nbsp;{lead_email}<br /><br />You can view the lead on the following link: <a href=\"{lead_link}\">{lead_name}</a><br /><br />Kind Regards,<br />{email_signature}</p>','{companyname} | CRM','',0,1,0),
(50,'client','client-statement','english','Statement - Account Summary','Account Statement from {statement_from} to {statement_to}','Dear {contact_firstname} {contact_lastname}, <br /><br />Its been a great experience working with you.<br /><br />Attached with this email is a list of all transactions for the period between {statement_from} to {statement_to}<br /><br />For your information your account balance due is total:&nbsp;{statement_balance_due}<br /><br />Please contact us if you need more information.<br /> <br />Kind Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),
(51,'ticket','ticket-assigned-to-admin','english','New Ticket Assigned (Sent to Staff)','New support ticket has been assigned to you','<p><span style=\"font-size: 12pt;\">Hi</span></p>\r\n<p><span style=\"font-size: 12pt;\">A new support ticket&nbsp;has been assigned to you.</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject</strong>: {ticket_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Department</strong>: {ticket_department}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority</strong>: {ticket_priority}</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Ticket message:</strong></span><br /><span style=\"font-size: 12pt;\">{ticket_message}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_url}\">#{ticket_id}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span></p>','{companyname} | CRM','',0,1,0),
(52,'client','new-client-registered-to-admin','english','New Customer Registration (Sent to admins)','New Customer Registration','Hello.<br /><br />New customer registration on your customer portal:<br /><br /><strong>Firstname:</strong>&nbsp;{contact_firstname}<br /><strong>Lastname:</strong>&nbsp;{contact_lastname}<br /><strong>Company:</strong>&nbsp;{client_company}<br /><strong>Email:</strong>&nbsp;{contact_email}<br /><br />Best Regards','{companyname} | CRM','',0,1,0),
(53,'leads','new-web-to-lead-form-submitted','english','Web to lead form submitted - Sent to lead','{lead_name} - We Received Your Request','Hello {lead_name}.<br /><br /><strong>Your request has been received.</strong><br /><br />This email is to let you know that we received your request and we will get back to you as soon as possible with more information.<br /><br />Best Regards,<br />{email_signature}','{companyname} | CRM','',0,0,0),
(54,'staff','two-factor-authentication','english','Two Factor Authentication','Confirm Your Login','<p>Hi {staff_firstname}</p>\r\n<p style=\"text-align: left;\">You received this email because you have enabled two factor authentication in your account.<br />Use the following code to confirm your login:</p>\r\n<p style=\"text-align: left;\"><span style=\"font-size: 18pt;\"><strong>{two_factor_auth_code}<br /><br /></strong><span style=\"font-size: 12pt;\">{email_signature}</span><strong><br /><br /><br /><br /></strong></span></p>','{companyname} | CRM','',0,1,0),
(55,'project','project-finished-to-customer','english','Project Marked as Finished (Sent to Customer Contacts)','Project Marked as Finished','<p>Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}</p>\r\n<p>You are receiving this email because project&nbsp;<strong>{project_name}</strong> has been marked as finished. This project is assigned under your company and we just wanted to keep you up to date.<br /><br />You can view the project on the following link:&nbsp;<a href=\"{project_link}\">{project_name}</a></p>\r\n<p>If you have any questions don\'t hesitate to contact us.<br /><br />Kind Regards,<br />{email_signature}</p>','{companyname} | CRM','',0,1,0),
(56,'credit_note','credit-note-send-to-client','english','Send Credit Note To Email','Credit Note With Number #{credit_note_number} Created','Dear&nbsp;{contact_firstname}&nbsp;{contact_lastname}<br /><br />We have attached the credit note with number <strong>#{credit_note_number} </strong>for your reference.<br /><br /><strong>Date:</strong>&nbsp;{credit_note_date}<br /><strong>Total Amount:</strong>&nbsp;{credit_note_total}<br /><br /><span style=\"font-size: 12pt;\">Please contact us for more information.</span><br /> <br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),
(57,'tasks','task-status-change-to-staff','english','Task Status Changed (Sent to Staff)','Task Status Changed','<span style=\"font-size: 12pt;\">Hi {staff_firstname}</span><br /><br /><span style=\"font-size: 12pt;\"><strong>{task_user_take_action}</strong> marked task as <strong>{task_status}</strong></span><br /><br /><span style=\"font-size: 12pt;\"><strong>Name:</strong> {task_name}</span><br /><span style=\"font-size: 12pt;\"><strong>Due date:</strong> {task_duedate}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the task on the following link: <a href=\"{task_link}\">{task_name}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),
(58,'tasks','task-status-change-to-contacts','english','Task Status Changed (Sent to Customer Contacts)','Task Status Changed','<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\"><strong>{task_user_take_action}</strong> marked task as <strong>{task_status}</strong></span><br /><br /><span style=\"font-size: 12pt;\"><strong>Name:</strong> {task_name}</span><br /><span style=\"font-size: 12pt;\"><strong>Due date:</strong> {task_duedate}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the task on the following link: <a href=\"{task_link}\">{task_name}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),
(59,'staff','reminder-email-staff','english','Staff Reminder Email','You Have a New Reminder!','<p>Hello&nbsp;{staff_firstname}<br /><br /><strong>You have a new reminder&nbsp;linked to&nbsp;{staff_reminder_relation_name}!<br /><br />Reminder description:</strong><br />{staff_reminder_description}<br /><br />Click <a href=\"{staff_reminder_relation_link}\">here</a> to view&nbsp;<a href=\"{staff_reminder_relation_link}\">{staff_reminder_relation_name}</a><br /><br />Best Regards<br /><br /></p>','{companyname} | CRM','',0,1,0),
(60,'contract','contract-comment-to-client','english','New Comment Â (Sent to Customer Contacts)','New Contract Comment','Dear {contact_firstname} {contact_lastname}<br /> <br />A new comment has been made on the following contract: <strong>{contract_subject}</strong><br /> <br />You can view and reply to the comment on the following link: <a href=\"{contract_link}\">{contract_subject}</a><br /> <br />Kind Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),
(61,'contract','contract-comment-to-admin','english','New Comment (Sent to Staff) ','New Contract Comment','Hi {staff_firstname}<br /><br />A new comment has been made to the contract&nbsp;<strong>{contract_subject}</strong><br /><br />You can view and reply to the comment on the following link: <a href=\"{contract_link}\">{contract_subject}</a>&nbsp;or from the admin area.<br /><br />{email_signature}','{companyname} | CRM','',0,1,0),
(62,'subscriptions','send-subscription','english','Send Subscription to Customer','Subscription Created','Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}<br /><br />We have prepared the subscription&nbsp;<strong>{subscription_name}</strong> for your company.<br /><br />Click <a href=\"{subscription_link}\">here</a> to review the subscription and subscribe.<br /><br />Best Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),
(63,'subscriptions','subscription-payment-failed','english','Subscription Payment Failed','Your most recent invoice payment failed','Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}<br /><br br=\"\" />Unfortunately, your most recent invoice payment for&nbsp;<strong>{subscription_name}</strong> was declined.<br /><br />This could be due to a change in your card number, your card expiring,<br />cancellation of your credit card, or the card issuer not recognizing the<br />payment and therefore taking action to prevent it.<br /><br />Please update your payment information as soon as possible by logging in here:<br /><a href=\"{crm_url}/login\">{crm_url}/login</a><br /><br />Best Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),
(64,'subscriptions','subscription-canceled','english','Subscription Canceled (Sent to customer primary contact)','Your subscription has been canceled','Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}<br /><br />Your subscription&nbsp;<strong>{subscription_name} </strong>has been canceled, if you have any questions don\'t hesitate to contact us.<br /><br />It was a pleasure doing business with you.<br /><br />Best Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),
(65,'subscriptions','subscription-payment-succeeded','english','Subscription Payment Succeeded (Sent to customer primary contact)','Subscription  Payment Receipt - {subscription_name}','Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}<br /><br />This email is to let you know that we received your payment for subscription&nbsp;<strong>{subscription_name}&nbsp;</strong>of&nbsp;<strong><span>{payment_total}<br /><br /></span></strong>The invoice associated with it is now with status&nbsp;<strong>{invoice_status}<br /></strong><br />Thank you for your confidence.<br /><br />Best Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),
(66,'contract','contract-expiration-to-staff','english','Contract Expiration Reminder (Sent to Staff)','Contract Expiration Reminder','Hi {staff_firstname}<br /><br /><span style=\"font-size: 12pt;\">This is a reminder that the following contract will expire soon:</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject:</strong> {contract_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Description:</strong> {contract_description}</span><br /><span style=\"font-size: 12pt;\"><strong>Date Start:</strong> {contract_datestart}</span><br /><span style=\"font-size: 12pt;\"><strong>Date End:</strong> {contract_dateend}</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),
(67,'gdpr','gdpr-removal-request','english','Removal Request From Contact (Sent to administrators)','Data Removal Request Received','Hello&nbsp;{staff_firstname}&nbsp;{staff_lastname}<br /><br />Data removal has been requested by&nbsp;{contact_firstname} {contact_lastname}<br /><br />You can review this request and take proper actions directly from the admin area.','{companyname} | CRM','',0,1,0),
(68,'gdpr','gdpr-removal-request-lead','english','Removal Request From Lead (Sent to administrators)','Data Removal Request Received','Hello&nbsp;{staff_firstname}&nbsp;{staff_lastname}<br /><br />Data removal has been requested by {lead_name}<br /><br />You can review this request and take proper actions directly from the admin area.<br /><br />To view the lead inside the admin area click here:&nbsp;<a href=\"{lead_link}\">{lead_link}</a>','{companyname} | CRM','',0,1,0),
(69,'client','client-registration-confirmed','english','Customer Registration Confirmed','Your registration is confirmed','<p>Dear {contact_firstname} {contact_lastname}<br /><br />We just wanted to let you know that your registration at&nbsp;{companyname} is successfully confirmed and your account is now active.<br /><br />You can login at&nbsp;<a href=\"{crm_url}\">{crm_url}</a> with the email and password you provided during registration.<br /><br />Please contact us if you need any help.<br /><br />Kind Regards, <br />{email_signature}</p>\r\n<p><br />(This is an automated email, so please don\'t reply to this email address)</p>','{companyname} | CRM','',0,1,0),
(70,'contract','contract-signed-to-staff','english','Contract Signed (Sent to Staff)','Customer Signed a Contract','Hi {staff_firstname}<br /><br />A contract with subject&nbsp;<strong>{contract_subject} </strong>has been successfully signed by the customer.<br /><br />You can view the contract at the following link: <a href=\"{contract_link}\">{contract_subject}</a>&nbsp;or from the admin area.<br /><br />{email_signature}','{companyname} | CRM','',0,1,0),
(71,'subscriptions','customer-subscribed-to-staff','english','Customer Subscribed to a Subscription (Sent to administrators and subscription creator)','Customer Subscribed to a Subscription','The customer <strong>{client_company}</strong> subscribed to a subscription with name&nbsp;<strong>{subscription_name}</strong><br /><br /><strong>ID</strong>:&nbsp;{subscription_id}<br /><strong>Subscription name</strong>:&nbsp;{subscription_name}<br /><strong>Subscription description</strong>:&nbsp;{subscription_description}<br /><br />You can view the subscription by clicking <a href=\"{subscription_link}\">here</a><br />\r\n<div style=\"text-align: center;\"><span style=\"font-size: 10pt;\">&nbsp;</span></div>\r\nBest Regards,<br />{email_signature}<br /><br /><span style=\"font-size: 10pt;\"><span style=\"color: #999999;\">You are receiving this email because you are either administrator or you are creator of the subscription.</span></span>','{companyname} | CRM','',0,1,0),
(72,'client','contact-verification-email','english','Email Verification (Sent to Contact After Registration)','Verify Email Address','<p>Hello&nbsp;{contact_firstname}<br /><br />Please click the button below to verify your email address.<br /><br /><a href=\"{email_verification_url}\">Verify Email Address</a><br /><br />If you did not create an account, no further action is required</p>\r\n<p><br />{email_signature}</p>','{companyname} | CRM','',0,1,0),
(73,'client','new-customer-profile-file-uploaded-to-staff','english','New Customer Profile File(s) Uploaded (Sent to Staff)','Customer Uploaded New File(s) in Profile','Hi!<br /><br />New file(s) is uploaded into the customer ({client_company}) profile by&nbsp;{contact_firstname}<br /><br />You can check the uploaded files into the admin area by clicking <a href=\"{customer_profile_files_admin_link}\">here</a> or at the following link:&nbsp;{customer_profile_files_admin_link}<br /><br />{email_signature}','{companyname} | CRM','',0,1,0),
(74,'staff','event-notification-to-staff','english','Event Notification (Calendar)','Upcoming Event - {event_title}','Hi {staff_firstname}! <br /><br />This is a reminder for event <a href=\\\"{event_link}\\\">{event_title}</a> scheduled at {event_start_date}. <br /><br />Regards.','','',0,1,0),
(75,'subscriptions','subscription-payment-requires-action','english','Credit Card Authorization Required - SCA','Important: Confirm your subscription {subscription_name} payment','<p>Hello {contact_firstname}</p>\r\n<p><strong>Your bank sometimes requires an additional step to make sure an online transaction was authorized.</strong><br /><br />Because of European regulation to protect consumers, many online payments now require two-factor authentication. Your bank ultimately decides when authentication is required to confirm a payment, but you may notice this step when you start paying for a service or when the cost changes.<br /><br />In order to pay the subscription <strong>{subscription_name}</strong>, you will need to&nbsp;confirm your payment by clicking on the follow link: <strong><a href=\"{subscription_authorize_payment_link}\">{subscription_authorize_payment_link}</a></strong><br /><br />To view the subscription, please click at the following link: <a href=\"{subscription_link}\"><span>{subscription_link}</span></a><br />or you can login in our dedicated area here: <a href=\"{crm_url}/login\">{crm_url}/login</a> in case you want to update your credit card or view the subscriptions you are subscribed.<br /><br />Best Regards,<br />{email_signature}</p>','{companyname} | CRM','',0,1,0),
(76,'invoice','invoice-due-notice','english','Invoice Due Notice','Your {invoice_number} will be due soon','<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}<br /><br /></span>You invoice <span style=\"font-size: 12pt;\"><strong># {invoice_number} </strong>will be due on <strong>{invoice_duedate}</strong></span><br /><br /><span style=\"font-size: 12pt;\">You can view the invoice on the following link: <a href=\"{invoice_link}\">{invoice_number}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),
(77,'estimate_request','estimate-request-submitted-to-staff','english','Estimate Request Submitted (Sent to Staff)','New Estimate Request Submitted','<span> Hello,&nbsp;</span><br /><br />{estimate_request_email} submitted an estimate request via the {estimate_request_form_name} form.<br /><br />You can view the request at the following link: <a href=\"{estimate_request_link}\">{estimate_request_link}</a><br /><br />==<br /><br />{estimate_request_submitted_data}<br /><br />Kind Regards,<br /><span>{email_signature}</span>','{companyname} | CRM','',0,1,0),
(78,'estimate_request','estimate-request-assigned','english','Estimate Request Assigned (Sent to Staff)','New Estimate Request Assigned','<span> Hello {estimate_request_assigned},&nbsp;</span><br /><br />Estimate request #{estimate_request_id} has been assigned to you.<br /><br />You can view the request at the following link: <a href=\"{estimate_request_link}\">{estimate_request_link}</a><br /><br />Kind Regards,<br /><span>{email_signature}</span>','{companyname} | CRM','',0,1,0),
(79,'estimate_request','estimate-request-received-to-user','english','Estimate Request Received (Sent to User)','Estimate Request Received','Hello,<br /><br /><strong>Your request has been received.</strong><br /><br />This email is to let you know that we received your request and we will get back to you as soon as possible with more information.<br /><br />Best Regards,<br />{email_signature}','{companyname} | CRM','',0,0,0),
(80,'notifications','non-billed-tasks-reminder','english','Non-billed tasks reminder (sent to selected staff members)','Action required: Completed tasks are not billed','Hello {staff_firstname}<br><br>The following tasks are marked as complete but not yet billed:<br><br>{unbilled_tasks_list}<br><br>Kind Regards,<br><br>{email_signature}','{companyname} | CRM','',0,1,0),
(81,'invoice','invoices-batch-payments','english','Invoices Payments Recorded in Batch (Sent to Customer)','We have received your payments','Hello {contact_firstname} {contact_lastname}<br><br>Thank you for the payments. Please find the payments details below:<br><br>{batch_payments_list}<br><br>We are looking forward working with you.<br><br>Kind Regards,<br><br>{email_signature}','{companyname} | CRM','',0,1,0),
(82,'contract','contract-sign-reminder','english','Contract Sign Reminder (Sent to Customer)','Contract Sign Reminder','<p>Hello {contact_firstname} {contact_lastname}<br /><br />This is a reminder to review and sign the contract:<a href=\"{contract_link}\">{contract_subject}</a></p><p>You can view and sign by visiting: <a href=\"{contract_link}\">{contract_subject}</a></p><p><br />We are looking forward working with you.<br /><br />Kind Regards,<br /><br />{email_signature}</p>','{companyname} | CRM','',0,1,0),
(83,'timesheets_attendance_mgt','attendance_notice','english','Attendance notice','Timesheets - Attendance notice','{staff_name} {type_check} at {date_time}','{companyname} | CRM',NULL,0,1,0),
(84,'timesheets_attendance_mgt','send_request_approval','english','Send request approval','Timesheets - Send request approval to approver','Hi {approver}! <br>-{staff_name} has created an apply for leave and requires your approval. Please go to this link for details and approval: {link}','{companyname} | CRM',NULL,0,1,0),
(85,'timesheets_attendance_mgt','remind_user_check_in','english','Remind user check in','Timesheets - Remind user check in','Remind you to check in today to record the start time of the shift {date_time}','{companyname} | CRM',NULL,0,1,0),
(86,'timesheets_attendance_mgt','new_leave_application_send_to_notification_recipient','english','New application (Send to notification recipient)','Timesheets - New application - Send to notification recipient','{staff_name} created a new application {link} at {date_time}','{companyname} | CRM',NULL,0,1,0),
(87,'client','affiliate_management_payout_updated','english','Affiliate Payout Request Update','An update regarding your payout request','Dear {contact_firstname},<br/><br/>\n    We hope this message finds you well.\n    <br/>\n    We wanted to inform you about the latest status of your payout request, identified by reference number <b>#{payout_id}</b>. \n    <br/><br/>\n    Amount: {payout_amount}<br/>\n    Status: {payout_status}<br/>\n    Note: {payout_note_for_affiliate}<br/>\n    Created: {payout_created_at}<br/>\n    <br/><br/>\n    If you have any questions or need further clarification, please do not hesitate to reach out. We are here to assist you in any way possible.<br/><br/>\n    \n    Best regards,<br/>\n    {email_signature}','{companyname} | CRM',NULL,0,1,0),
(88,'client','affiliate_management_signup_through_affiliate_link','english','Successful Signup through Affiliate Link','Congratulations on a successful signup!','Dear {contact_firstname},<br/><br/>\n    We are delighted to inform you that someone has successfully signed up using your affiliate link.\n    <br/><br/>\n    Company/Contact: {referral_name}<br/>\n    Date: {referral_created_at}<br/>\n    <br/><br/>\n    While this signup may not have resulted in an immediate transaction, your efforts are highly valued. We appreciate your contribution to our community and anticipate further success in the future.\n    <br/><br/>\n    If you have any questions or need additional information, please feel free to reach out.\n    <br/><br/>\n    Best regards,<br/>\n    {email_signature}','{companyname} | CRM',NULL,0,1,0),
(89,'client','affiliate_management_successful_referral_commission','english','Successful Referral Commission Notification','A referral commission received!','Dear {contact_firstname},<br/><br/>\n    We are thrilled to inform you that your referral has resulted in a successful transaction, earning you a commission.\n    <br/><br/>\n    Company/Contact: {referral_name}<br/>\n    Transaction Amount: {payment_amount}<br/>\n    Commission Earned: {commission_amount}<br/>\n    New Balance: {affiliate_balance}<br/>\n    Date: {commission_created_at}<br/>\n    <br/><br/>\n    We appreciate your efforts and look forward to more successful collaborations. Should you have any questions or require further information, feel free to reach out.\n    <br/><br/>\n    Best regards,<br/>\n    {email_signature}','{companyname} | CRM',NULL,0,1,0),
(90,'staff','affiliate_management_new_payout_request_for_admin','english','Affiliate Payout Request','You have new affiliate payout request','Dear Admin,<br/><br/>\n    I wanted to inform you about a new payout request, identified by reference number <b>#{payout_id}</b>. \n    <br/><br/>\n    Affiliate: {affiliate_name}<br/>\n    Amount: {payout_amount}<br/>\n    Status: {payout_status}<br/>\n    Note: {payout_note_for_admin}<br/>\n    Created: {payout_created_at}<br/>\n    <br/><br/>    \n    Best regards,<br/>\n    {email_signature}','{companyname} | CRM',NULL,0,1,0),
(91,'staff','affiliate_management_payout_updated_for_admin','english','Affiliate Payout Request Updated','You marked payout: #{payout_id} as {payout_status}','Dear Admin,<br/><br/>\n    I wanted to update you about the recent update to a payout request, identified by reference number <b>#{payout_id}</b>. \n    <br/><br/>\n    Affiliate: {affiliate_name}<br/>\n    Amount: {payout_amount}<br/>\n    Status: {payout_status}<br/><br/>\n    Admin Note: {payout_note_for_admin}<br/>\n    Note: {payout_note_for_affiliate}<br/>\n    Created: {payout_created_at}<br/>\n    <br/><br/>    \n    Best regards,<br/>\n    {email_signature}','{companyname} | CRM',NULL,0,1,0),
(92,'staff','affiliate_management_new_affiliate_signup_for_admin','english','New Affiliate Signup','A new affiliate signup','Dear Admin,<br/><br/>\n    I wanted to inform you about a new affiliate signup, identified by reference number <b>#{affiliate_slug}</b>. \n    <br/><br/>\n    Affiliate: {affiliate_name}<br/>\n    Status: {affiliate_status}<br/>\n    Created: {affiliate_created_at}<br/>\n    <br/><br/>    \n    Best regards,<br/>\n    {email_signature}','{companyname} | CRM',NULL,0,1,0),
(93,'client','affiliate_management_referral_commission_reversal','english','Referral Commission Reversal Notification','A referral commission was reversed!','Dear {contact_firstname},<br/><br/>\n    We regret to inform you that the commission previously awarded for your referral has been reversed due to reversal or removal of the rewarded payment.\n    <br/><br/>\n    Company/Contact: {referral_name}<br/>\n    Comission ID: {commission_id}<br/>\n    Amount Reversed: {commission_amount}<br/>\n    New Balance: {affiliate_balance}<br/>\n    Date of commission: {commission_created_at}<br/>\n    <br/><br/>\n    We appreciate your efforts and look forward to more successful collaborations. Should you have any questions or require further information, feel free to reach out.\n    <br/><br/>\n    Best regards,<br/>\n    {email_signature}','{companyname} | CRM',NULL,0,1,0),
(94,'inventory_warning','inventory-warning-to-staff','english','Inventory warning (Sent to staff)','Inventory warning','Hi {staff_name}! <br /><br />This is a inventory warning<br />{<span 12pt=\"\">notification_content</span>}. <br /><br />Regards.','{companyname} | CRM',NULL,0,1,0),
(95,'client','company-instance-deployed','english','Deployed CRM instance','Company CRM Instance created successfully','Dear {contact_firstname},<br/><br/>\n    I am writing to inform you that we have successfully deployed a CRM instance for your company <b>{instance_name}</b>. \n    <br/><br/>\n    You can access your instance at <b>{instance_admin_url}</b>. Kindly log in with your current email and the respective password. \n    <br/><br/>\n    Your customer can access from <b>{instance_url}</b>.<br/><br/>\n    Please let us know if you have any questions or concerns. We are always happy to help.<br/><br/>\n    \n    Best regards,<br/>\n    {email_signature}','{companyname} | CRM',NULL,0,1,0),
(96,'staff','company-instance-deployed-for-admin','english','Deployed CRM instance for admin','A CRM Instance was deployed','Dear Super Admin,<br/><br/>\n\n    I am writing to inform you that a new instance <b>({instance_name})</b> has been created on your platform for <b>{client_company}</b>. You can check the instance at <b>{instance_url}</b>.\n    <br/><br/>\n    Best regards.<br/>\n    {email_signature}','{companyname} | CRM',NULL,0,1,0),
(97,'client','company-instance-removed','english','Removed CRM instance','Company CRM Instance removed','\n    Dear {contact_firstname},<br/><br/>\n    \n    I am writing to inform you that your company <b>{instance_name}</b> has been removed successfully. \n    <br/><br/>\n    If this is not from you or your staff, kindly reach out to us.\n    <br/><br/>\n    Best regards,<br/>\n    {email_signature}','{companyname} | CRM',NULL,0,1,0),
(98,'staff','company-instance-removed-for-admin','english','Removed CRM instance for admin','Company CRM Instance removed successfully','Dear Super Admin,<br/><br/>\n\n    I am writing to inform you that an instance has been removed from your platform for <b>{client_company}</b>. The name of the instance is <b>{instance_name}</b>.\n    <br/><br/>\n    Best regards.<br/>\n    {email_signature}','{companyname} | CRM',NULL,0,1,0),
(99,'client','company-instance-auto-removal-notice','english','Auto removal of inactive CRM instance','Important Notice: Your Company CRM Instance Will Be Removed in {period_left}','\n    Dear {contact_firstname},<br/><br/>\n    \n    I am writing to inform you that your CRM instance <b>{instance_name} ({instance_slug})</b> has not been accessed by any staff for the past {inactive_period}. \n    <br/><br/>\n    Your CRM will be permanently removed in {period_left}. \n    To prevent removal of <b>{instance_name}</b>, \n    kindly login directly now through your staff login page: <a href=\"{instance_admin_url}\">{instance_admin_url}</a> or through your billing portal: <a href=\"{site_login_url}\">{site_login_url}</a>.\n    <br/><br/>\n    Best regards,<br/>\n    {email_signature}','{companyname} | CRM',NULL,0,1,0),
(100,'staff','company-instance-custom-domain-request-for-admin','english','Custom domain request for admin','New Custom Domain Request','Dear Super Admin,<br/><br/>\n    I am writing to inform you that you have a new custom domain linking request for <b>{instance_name}</b>. \n    <br/>\n    Tenant ID: {instance_slug}<br/>\n    Custom domain: {instance_custom_domain}<br/>\n    Customer: {contact_firstname} - {contact_email}\n    <br/><br/>\n    You can access the instance directly from <b>{admin_url}saas/companies/edit/{instance_id}</b>.\n    <br/><br/>\n    Best regards,<br/>\n    {email_signature}','{companyname} | CRM',NULL,0,1,0),
(101,'client','company-instance-custom-domain-approved','english','Custom domain approved','Custom Domain Added Successfully','Dear {contact_firstname},<br/><br/>\n    I am writing to inform you that we have successfully link your custom domain ( {instance_custom_domain} ) to your company <b>{instance_name}</b>. \n    <br/><br/>\n    You can access your instance at <b>{instance_admin_url}</b>.\n    <br/><br/>\n    Your customer can access from <b>{instance_url}</b>.<br/><br/>\n    {extra_note}<br/>\n    Please let us know if you have any questions or concerns. We are always happy to help.<br/><br/>\n    Best regards,<br/>\n    {email_signature}','{companyname} | CRM',NULL,0,1,0),
(102,'client','company-instance-custom-domain-rejected','english','Custom domain cancelled','Custom Domain Request Cancelled','Dear {contact_firstname},<br/><br/>\n    I am writing to inform you that we are unable to link your custom domain ( {instance_custom_domain} ) to your company <b>{instance_name}</b> due to the following reason: \n    <br/>\n    {extra_note}\n    <br/><br/>\n    Please ensure you have followed the instructions for linking the domain as stated outlined on your dashboard.\n    <br/><br/>\n    You can always request new domain at your earliest convenient time.<br/><br/>\n    Best regards,<br/>\n    {email_signature}','{companyname} | CRM',NULL,0,1,0);
/*!40000 ALTER TABLE `tblemailtemplates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblestimate_request_forms`
--

DROP TABLE IF EXISTS `tblestimate_request_forms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblestimate_request_forms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `form_key` varchar(32) NOT NULL,
  `type` varchar(100) NOT NULL,
  `name` varchar(191) NOT NULL,
  `form_data` longtext DEFAULT NULL,
  `recaptcha` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL,
  `submit_btn_name` varchar(100) DEFAULT NULL,
  `submit_btn_bg_color` varchar(10) DEFAULT '#84c529',
  `submit_btn_text_color` varchar(10) DEFAULT '#ffffff',
  `success_submit_msg` mediumtext DEFAULT NULL,
  `submit_action` int(11) DEFAULT 0,
  `submit_redirect_url` longtext DEFAULT NULL,
  `language` varchar(100) DEFAULT NULL,
  `dateadded` datetime DEFAULT NULL,
  `notify_type` varchar(100) DEFAULT NULL,
  `notify_ids` longtext DEFAULT NULL,
  `responsible` int(11) DEFAULT NULL,
  `notify_request_submitted` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblestimate_request_forms`
--

LOCK TABLES `tblestimate_request_forms` WRITE;
/*!40000 ALTER TABLE `tblestimate_request_forms` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblestimate_request_forms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblestimate_request_status`
--

DROP TABLE IF EXISTS `tblestimate_request_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblestimate_request_status` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `statusorder` int(11) DEFAULT NULL,
  `color` varchar(10) DEFAULT NULL,
  `flag` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblestimate_request_status`
--

LOCK TABLES `tblestimate_request_status` WRITE;
/*!40000 ALTER TABLE `tblestimate_request_status` DISABLE KEYS */;
INSERT INTO `tblestimate_request_status` VALUES
(1,'Cancelled',1,'#808080','cancelled'),
(2,'Processing',2,'#007bff','processing'),
(3,'Completed',3,'#28a745','completed');
/*!40000 ALTER TABLE `tblestimate_request_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblestimate_requests`
--

DROP TABLE IF EXISTS `tblestimate_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblestimate_requests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `submission` longtext NOT NULL,
  `last_status_change` datetime DEFAULT NULL,
  `date_estimated` datetime DEFAULT NULL,
  `from_form_id` int(11) DEFAULT NULL,
  `assigned` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `default_language` int(11) NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblestimate_requests`
--

LOCK TABLES `tblestimate_requests` WRITE;
/*!40000 ALTER TABLE `tblestimate_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblestimate_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblestimates`
--

DROP TABLE IF EXISTS `tblestimates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblestimates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sent` tinyint(1) NOT NULL DEFAULT 0,
  `datesend` datetime DEFAULT NULL,
  `clientid` int(11) NOT NULL,
  `deleted_customer_name` varchar(100) DEFAULT NULL,
  `project_id` int(11) NOT NULL DEFAULT 0,
  `number` int(11) NOT NULL,
  `prefix` varchar(50) DEFAULT NULL,
  `number_format` int(11) NOT NULL DEFAULT 0,
  `hash` varchar(32) DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `date` date NOT NULL,
  `expirydate` date DEFAULT NULL,
  `currency` int(11) NOT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `total_tax` decimal(15,2) NOT NULL DEFAULT 0.00,
  `total` decimal(15,2) NOT NULL,
  `adjustment` decimal(15,2) DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `clientnote` mediumtext DEFAULT NULL,
  `adminnote` mediumtext DEFAULT NULL,
  `discount_percent` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `discount_type` varchar(30) DEFAULT NULL,
  `invoiceid` int(11) DEFAULT NULL,
  `invoiced_date` datetime DEFAULT NULL,
  `terms` mediumtext DEFAULT NULL,
  `reference_no` varchar(100) DEFAULT NULL,
  `sale_agent` int(11) NOT NULL DEFAULT 0,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT NULL,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT NULL,
  `include_shipping` tinyint(1) NOT NULL,
  `show_shipping_on_estimate` tinyint(1) NOT NULL DEFAULT 1,
  `show_quantity_as` int(11) NOT NULL DEFAULT 1,
  `pipeline_order` int(11) DEFAULT 1,
  `is_expiry_notified` int(11) NOT NULL DEFAULT 0,
  `acceptance_firstname` varchar(50) DEFAULT NULL,
  `acceptance_lastname` varchar(50) DEFAULT NULL,
  `acceptance_email` varchar(100) DEFAULT NULL,
  `acceptance_date` datetime DEFAULT NULL,
  `acceptance_ip` varchar(40) DEFAULT NULL,
  `signature` varchar(40) DEFAULT NULL,
  `short_link` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `currency` (`currency`),
  KEY `project_id` (`project_id`),
  KEY `sale_agent` (`sale_agent`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblestimates`
--

LOCK TABLES `tblestimates` WRITE;
/*!40000 ALTER TABLE `tblestimates` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblestimates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblevents`
--

DROP TABLE IF EXISTS `tblevents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblevents` (
  `eventid` int(11) NOT NULL AUTO_INCREMENT,
  `title` longtext NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `userid` int(11) NOT NULL,
  `start` datetime NOT NULL,
  `end` datetime DEFAULT NULL,
  `public` int(11) NOT NULL DEFAULT 0,
  `color` varchar(10) DEFAULT NULL,
  `isstartnotified` tinyint(1) NOT NULL DEFAULT 0,
  `reminder_before` int(11) NOT NULL DEFAULT 0,
  `reminder_before_type` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`eventid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblevents`
--

LOCK TABLES `tblevents` WRITE;
/*!40000 ALTER TABLE `tblevents` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblevents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblexpenses`
--

DROP TABLE IF EXISTS `tblexpenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblexpenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` int(11) NOT NULL,
  `currency` int(11) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `tax` int(11) DEFAULT NULL,
  `tax2` int(11) NOT NULL DEFAULT 0,
  `reference_no` varchar(100) DEFAULT NULL,
  `note` mediumtext DEFAULT NULL,
  `expense_name` varchar(191) DEFAULT NULL,
  `clientid` int(11) NOT NULL,
  `project_id` int(11) NOT NULL DEFAULT 0,
  `billable` int(11) DEFAULT 0,
  `invoiceid` int(11) DEFAULT NULL,
  `paymentmode` varchar(50) DEFAULT NULL,
  `date` date NOT NULL,
  `recurring_type` varchar(10) DEFAULT NULL,
  `repeat_every` int(11) DEFAULT NULL,
  `recurring` int(11) NOT NULL DEFAULT 0,
  `cycles` int(11) NOT NULL DEFAULT 0,
  `total_cycles` int(11) NOT NULL DEFAULT 0,
  `custom_recurring` int(11) NOT NULL DEFAULT 0,
  `last_recurring_date` date DEFAULT NULL,
  `create_invoice_billable` tinyint(1) DEFAULT NULL,
  `send_invoice_to_customer` tinyint(1) NOT NULL,
  `recurring_from` int(11) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  `addedfrom` int(11) NOT NULL,
  `vendor` int(11) DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `date_paid` date DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `is_bill` int(11) NOT NULL DEFAULT 0,
  `reason_for_void` text DEFAULT NULL,
  `voided` int(11) NOT NULL DEFAULT 0,
  `approved` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `project_id` (`project_id`),
  KEY `category` (`category`),
  KEY `currency` (`currency`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblexpenses`
--

LOCK TABLES `tblexpenses` WRITE;
/*!40000 ALTER TABLE `tblexpenses` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblexpenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblexpenses_categories`
--

DROP TABLE IF EXISTS `tblexpenses_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblexpenses_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblexpenses_categories`
--

LOCK TABLES `tblexpenses_categories` WRITE;
/*!40000 ALTER TABLE `tblexpenses_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblexpenses_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblfiles`
--

DROP TABLE IF EXISTS `tblfiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblfiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) NOT NULL,
  `file_name` varchar(191) NOT NULL,
  `filetype` varchar(40) DEFAULT NULL,
  `visible_to_customer` int(11) NOT NULL DEFAULT 0,
  `attachment_key` varchar(32) DEFAULT NULL,
  `external` varchar(40) DEFAULT NULL,
  `external_link` mediumtext DEFAULT NULL,
  `thumbnail_link` mediumtext DEFAULT NULL COMMENT 'For external usage',
  `staffid` int(11) NOT NULL,
  `contact_id` int(11) DEFAULT 0,
  `task_comment_id` int(11) NOT NULL DEFAULT 0,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblfiles`
--

LOCK TABLES `tblfiles` WRITE;
/*!40000 ALTER TABLE `tblfiles` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblfiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblfilter_defaults`
--

DROP TABLE IF EXISTS `tblfilter_defaults`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblfilter_defaults` (
  `filter_id` int(10) unsigned NOT NULL,
  `staff_id` int(11) NOT NULL,
  `identifier` varchar(191) NOT NULL,
  `view` varchar(191) NOT NULL,
  KEY `filter_id` (`filter_id`),
  KEY `staff_id` (`staff_id`),
  CONSTRAINT `tblfilter_defaults_ibfk_1` FOREIGN KEY (`filter_id`) REFERENCES `tblfilters` (`id`) ON DELETE CASCADE,
  CONSTRAINT `tblfilter_defaults_ibfk_2` FOREIGN KEY (`staff_id`) REFERENCES `tblstaff` (`staffid`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblfilter_defaults`
--

LOCK TABLES `tblfilter_defaults` WRITE;
/*!40000 ALTER TABLE `tblfilter_defaults` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblfilter_defaults` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblfilters`
--

DROP TABLE IF EXISTS `tblfilters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblfilters` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `builder` mediumtext NOT NULL,
  `staff_id` int(10) unsigned NOT NULL,
  `identifier` varchar(191) NOT NULL,
  `is_shared` tinyint(3) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblfilters`
--

LOCK TABLES `tblfilters` WRITE;
/*!40000 ALTER TABLE `tblfilters` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblfilters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblform_question_box`
--

DROP TABLE IF EXISTS `tblform_question_box`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblform_question_box` (
  `boxid` int(11) NOT NULL AUTO_INCREMENT,
  `boxtype` varchar(10) NOT NULL,
  `questionid` int(11) NOT NULL,
  PRIMARY KEY (`boxid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblform_question_box`
--

LOCK TABLES `tblform_question_box` WRITE;
/*!40000 ALTER TABLE `tblform_question_box` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblform_question_box` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblform_question_box_description`
--

DROP TABLE IF EXISTS `tblform_question_box_description`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblform_question_box_description` (
  `questionboxdescriptionid` int(11) NOT NULL AUTO_INCREMENT,
  `description` longtext NOT NULL,
  `boxid` longtext NOT NULL,
  `questionid` int(11) NOT NULL,
  PRIMARY KEY (`questionboxdescriptionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblform_question_box_description`
--

LOCK TABLES `tblform_question_box_description` WRITE;
/*!40000 ALTER TABLE `tblform_question_box_description` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblform_question_box_description` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblform_questions`
--

DROP TABLE IF EXISTS `tblform_questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblform_questions` (
  `questionid` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) DEFAULT NULL,
  `question` longtext NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT 0,
  `question_order` int(11) NOT NULL,
  PRIMARY KEY (`questionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblform_questions`
--

LOCK TABLES `tblform_questions` WRITE;
/*!40000 ALTER TABLE `tblform_questions` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblform_questions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblform_results`
--

DROP TABLE IF EXISTS `tblform_results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblform_results` (
  `resultid` int(11) NOT NULL AUTO_INCREMENT,
  `boxid` int(11) NOT NULL,
  `boxdescriptionid` int(11) DEFAULT NULL,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) DEFAULT NULL,
  `questionid` int(11) NOT NULL,
  `answer` mediumtext DEFAULT NULL,
  `resultsetid` int(11) NOT NULL,
  PRIMARY KEY (`resultid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblform_results`
--

LOCK TABLES `tblform_results` WRITE;
/*!40000 ALTER TABLE `tblform_results` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblform_results` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblgdpr_requests`
--

DROP TABLE IF EXISTS `tblgdpr_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblgdpr_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clientid` int(11) NOT NULL DEFAULT 0,
  `contact_id` int(11) NOT NULL DEFAULT 0,
  `lead_id` int(11) NOT NULL DEFAULT 0,
  `request_type` varchar(191) DEFAULT NULL,
  `status` varchar(40) DEFAULT NULL,
  `request_date` datetime NOT NULL,
  `request_from` varchar(150) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblgdpr_requests`
--

LOCK TABLES `tblgdpr_requests` WRITE;
/*!40000 ALTER TABLE `tblgdpr_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblgdpr_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblgoods_delivery`
--

DROP TABLE IF EXISTS `tblgoods_delivery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblgoods_delivery` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rel_type` int(11) DEFAULT NULL COMMENT 'type goods delivery',
  `rel_document` int(11) DEFAULT NULL COMMENT 'document id of goods delivery',
  `customer_code` text DEFAULT NULL,
  `customer_name` varchar(100) DEFAULT NULL,
  `to_` varchar(100) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL COMMENT 'the reason delivery',
  `staff_id` int(11) DEFAULT NULL COMMENT 'salesman',
  `date_c` date DEFAULT NULL,
  `date_add` date DEFAULT NULL,
  `goods_delivery_code` varchar(100) DEFAULT NULL COMMENT 'số chứng từ xuất kho',
  `warehouse_id` int(11) DEFAULT NULL,
  `total_money` varchar(200) DEFAULT NULL,
  `approval` int(11) DEFAULT 0 COMMENT 'status approval ',
  `addedfrom` int(11) DEFAULT NULL,
  `total_discount` varchar(100) DEFAULT NULL,
  `after_discount` varchar(100) DEFAULT NULL,
  `invoice_id` varchar(100) DEFAULT NULL,
  `project` text DEFAULT NULL,
  `type` text DEFAULT NULL,
  `department` int(11) DEFAULT NULL,
  `requester` int(11) DEFAULT NULL,
  `invoice_no` text DEFAULT NULL,
  `pr_order_id` int(11) DEFAULT NULL,
  `type_of_delivery` varchar(100) DEFAULT 'total',
  `additional_discount` decimal(15,2) DEFAULT 0.00,
  `sub_total` decimal(15,2) DEFAULT 0.00,
  `delivery_status` varchar(100) DEFAULT 'ready_for_packing',
  `shipping_fee` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblgoods_delivery`
--

LOCK TABLES `tblgoods_delivery` WRITE;
/*!40000 ALTER TABLE `tblgoods_delivery` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblgoods_delivery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblgoods_delivery_detail`
--

DROP TABLE IF EXISTS `tblgoods_delivery_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblgoods_delivery_detail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `goods_delivery_id` int(11) NOT NULL,
  `commodity_code` varchar(100) DEFAULT NULL,
  `commodity_name` text DEFAULT NULL,
  `warehouse_id` text DEFAULT NULL,
  `unit_id` text DEFAULT NULL,
  `quantities` text DEFAULT NULL,
  `unit_price` varchar(100) DEFAULT NULL,
  `total_money` varchar(200) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `discount` varchar(100) DEFAULT NULL,
  `discount_money` varchar(100) DEFAULT NULL,
  `available_quantity` varchar(100) DEFAULT NULL,
  `tax_id` varchar(100) DEFAULT NULL,
  `total_after_discount` varchar(100) DEFAULT NULL,
  `expiry_date` text DEFAULT NULL,
  `lot_number` text DEFAULT NULL,
  `guarantee_period` text DEFAULT NULL,
  `tax_rate` text DEFAULT NULL,
  `tax_name` text DEFAULT NULL,
  `sub_total` decimal(15,2) DEFAULT 0.00,
  `packing_qty` decimal(15,2) DEFAULT 0.00,
  `serial_number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblgoods_delivery_detail`
--

LOCK TABLES `tblgoods_delivery_detail` WRITE;
/*!40000 ALTER TABLE `tblgoods_delivery_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblgoods_delivery_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblgoods_delivery_invoices_pr_orders`
--

DROP TABLE IF EXISTS `tblgoods_delivery_invoices_pr_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblgoods_delivery_invoices_pr_orders` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) DEFAULT NULL COMMENT 'goods_delivery_id',
  `rel_type` int(11) DEFAULT NULL COMMENT 'invoice_id or purchase order id',
  `type` varchar(100) DEFAULT NULL COMMENT 'invoice,  purchase_orders',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblgoods_delivery_invoices_pr_orders`
--

LOCK TABLES `tblgoods_delivery_invoices_pr_orders` WRITE;
/*!40000 ALTER TABLE `tblgoods_delivery_invoices_pr_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblgoods_delivery_invoices_pr_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblgoods_receipt`
--

DROP TABLE IF EXISTS `tblgoods_receipt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblgoods_receipt` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `supplier_code` varchar(100) DEFAULT NULL,
  `supplier_name` text DEFAULT NULL,
  `deliver_name` text DEFAULT NULL,
  `buyer_id` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `pr_order_id` int(11) DEFAULT NULL COMMENT 'code puchase request agree',
  `date_c` date DEFAULT NULL,
  `date_add` date DEFAULT NULL,
  `goods_receipt_code` varchar(100) DEFAULT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `total_tax_money` varchar(100) DEFAULT NULL,
  `total_goods_money` varchar(100) DEFAULT NULL,
  `value_of_inventory` varchar(100) DEFAULT NULL,
  `total_money` varchar(100) DEFAULT NULL COMMENT 'total_money = total_tax_money +total_goods_money ',
  `addedfrom` int(11) DEFAULT NULL,
  `approval` int(11) DEFAULT 0,
  `project` text DEFAULT NULL,
  `type` text DEFAULT NULL,
  `department` int(11) DEFAULT NULL,
  `requester` int(11) DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `invoice_no` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblgoods_receipt`
--

LOCK TABLES `tblgoods_receipt` WRITE;
/*!40000 ALTER TABLE `tblgoods_receipt` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblgoods_receipt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblgoods_receipt_detail`
--

DROP TABLE IF EXISTS `tblgoods_receipt_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblgoods_receipt_detail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `goods_receipt_id` int(11) NOT NULL,
  `commodity_code` varchar(100) DEFAULT NULL,
  `commodity_name` text DEFAULT NULL,
  `warehouse_id` text DEFAULT NULL,
  `unit_id` text DEFAULT NULL,
  `quantities` text DEFAULT NULL,
  `unit_price` varchar(100) DEFAULT NULL,
  `tax` varchar(100) DEFAULT NULL,
  `tax_money` varchar(100) DEFAULT NULL,
  `goods_money` varchar(100) DEFAULT NULL,
  `date_manufacture` date DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `note` text DEFAULT NULL,
  `discount` varchar(100) DEFAULT NULL,
  `discount_money` varchar(100) DEFAULT NULL,
  `lot_number` varchar(100) DEFAULT NULL,
  `tax_rate` text DEFAULT NULL,
  `sub_total` decimal(15,2) DEFAULT 0.00,
  `tax_name` text DEFAULT NULL,
  `serial_number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblgoods_receipt_detail`
--

LOCK TABLES `tblgoods_receipt_detail` WRITE;
/*!40000 ALTER TABLE `tblgoods_receipt_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblgoods_receipt_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblgoods_transaction_detail`
--

DROP TABLE IF EXISTS `tblgoods_transaction_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblgoods_transaction_detail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `goods_receipt_id` int(11) DEFAULT NULL COMMENT 'id_goods_receipt_id or goods_delivery_id',
  `goods_id` int(11) NOT NULL COMMENT ' is id commodity',
  `old_quantity` varchar(100) DEFAULT NULL,
  `quantity` varchar(100) DEFAULT NULL,
  `date_add` datetime DEFAULT NULL,
  `commodity_id` int(11) NOT NULL,
  `warehouse_id` text NOT NULL,
  `note` text DEFAULT NULL,
  `status` int(2) DEFAULT NULL COMMENT '1:Goods receipt note 2:Goods delivery note',
  `purchase_price` varchar(100) DEFAULT NULL,
  `price` varchar(100) DEFAULT NULL,
  `expiry_date` text DEFAULT NULL,
  `lot_number` text DEFAULT NULL,
  `from_stock_name` int(11) DEFAULT NULL,
  `to_stock_name` int(11) DEFAULT NULL,
  `serial_number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`,`commodity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblgoods_transaction_detail`
--

LOCK TABLES `tblgoods_transaction_detail` WRITE;
/*!40000 ALTER TABLE `tblgoods_transaction_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblgoods_transaction_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblgroup_checklist`
--

DROP TABLE IF EXISTS `tblgroup_checklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblgroup_checklist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(100) NOT NULL,
  `meta` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblgroup_checklist`
--

LOCK TABLES `tblgroup_checklist` WRITE;
/*!40000 ALTER TABLE `tblgroup_checklist` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblgroup_checklist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblgroup_checklist_allocation`
--

DROP TABLE IF EXISTS `tblgroup_checklist_allocation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblgroup_checklist_allocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(100) NOT NULL,
  `meta` varchar(100) DEFAULT NULL,
  `staffid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblgroup_checklist_allocation`
--

LOCK TABLES `tblgroup_checklist_allocation` WRITE;
/*!40000 ALTER TABLE `tblgroup_checklist_allocation` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblgroup_checklist_allocation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_allocation_asset`
--

DROP TABLE IF EXISTS `tblhr_allocation_asset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhr_allocation_asset` (
  `allocation_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) unsigned NOT NULL,
  `asset_name` varchar(100) DEFAULT NULL,
  `assets_amount` int(11) unsigned NOT NULL,
  `status_allocation` int(11) unsigned DEFAULT 0 COMMENT '1: Allocated 0: Unallocated',
  PRIMARY KEY (`allocation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_allocation_asset`
--

LOCK TABLES `tblhr_allocation_asset` WRITE;
/*!40000 ALTER TABLE `tblhr_allocation_asset` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_allocation_asset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_allowance_type`
--

DROP TABLE IF EXISTS `tblhr_allowance_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhr_allowance_type` (
  `type_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type_name` varchar(200) NOT NULL,
  `allowance_val` decimal(15,2) NOT NULL,
  `taxable` tinyint(1) NOT NULL,
  PRIMARY KEY (`type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_allowance_type`
--

LOCK TABLES `tblhr_allowance_type` WRITE;
/*!40000 ALTER TABLE `tblhr_allowance_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_allowance_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_checklist_allocation`
--

DROP TABLE IF EXISTS `tblhr_checklist_allocation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhr_checklist_allocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `group_id` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_checklist_allocation`
--

LOCK TABLES `tblhr_checklist_allocation` WRITE;
/*!40000 ALTER TABLE `tblhr_checklist_allocation` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_checklist_allocation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_contract_template`
--

DROP TABLE IF EXISTS `tblhr_contract_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhr_contract_template` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text DEFAULT NULL,
  `job_position` longtext DEFAULT NULL,
  `content` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_contract_template`
--

LOCK TABLES `tblhr_contract_template` WRITE;
/*!40000 ALTER TABLE `tblhr_contract_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_contract_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_dependent_person`
--

DROP TABLE IF EXISTS `tblhr_dependent_person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhr_dependent_person` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staffid` int(11) unsigned DEFAULT NULL,
  `dependent_name` varchar(100) DEFAULT NULL,
  `relationship` varchar(100) DEFAULT NULL,
  `dependent_bir` date DEFAULT NULL,
  `start_month` date DEFAULT NULL,
  `end_month` date DEFAULT NULL,
  `dependent_iden` varchar(20) NOT NULL,
  `reason` longtext DEFAULT NULL,
  `status` int(11) unsigned DEFAULT 0,
  `status_comment` longtext DEFAULT NULL,
  PRIMARY KEY (`id`,`dependent_iden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_dependent_person`
--

LOCK TABLES `tblhr_dependent_person` WRITE;
/*!40000 ALTER TABLE `tblhr_dependent_person` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_dependent_person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_education`
--

DROP TABLE IF EXISTS `tblhr_education`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhr_education` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `programe_id` int(11) DEFAULT NULL,
  `training_programs_name` text NOT NULL,
  `training_places` text DEFAULT NULL,
  `training_time_from` datetime DEFAULT NULL,
  `training_time_to` datetime DEFAULT NULL,
  `date_create` datetime DEFAULT NULL,
  `training_result` varchar(150) DEFAULT NULL,
  `degree` varchar(150) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_education`
--

LOCK TABLES `tblhr_education` WRITE;
/*!40000 ALTER TABLE `tblhr_education` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_education` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_group_checklist_allocation`
--

DROP TABLE IF EXISTS `tblhr_group_checklist_allocation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhr_group_checklist_allocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(100) NOT NULL,
  `meta` varchar(100) DEFAULT NULL,
  `staffid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_group_checklist_allocation`
--

LOCK TABLES `tblhr_group_checklist_allocation` WRITE;
/*!40000 ALTER TABLE `tblhr_group_checklist_allocation` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_group_checklist_allocation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_job_p`
--

DROP TABLE IF EXISTS `tblhr_job_p`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhr_job_p` (
  `job_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `job_name` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`job_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_job_p`
--

LOCK TABLES `tblhr_job_p` WRITE;
/*!40000 ALTER TABLE `tblhr_job_p` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_job_p` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_job_position`
--

DROP TABLE IF EXISTS `tblhr_job_position`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhr_job_position` (
  `position_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `position_name` varchar(200) NOT NULL,
  `job_position_description` text DEFAULT NULL,
  `job_p_id` int(11) unsigned NOT NULL,
  `position_code` varchar(50) DEFAULT NULL,
  `department_id` text DEFAULT NULL,
  PRIMARY KEY (`position_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_job_position`
--

LOCK TABLES `tblhr_job_position` WRITE;
/*!40000 ALTER TABLE `tblhr_job_position` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_job_position` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_jp_interview_training`
--

DROP TABLE IF EXISTS `tblhr_jp_interview_training`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhr_jp_interview_training` (
  `training_process_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `job_position_id` longtext DEFAULT NULL,
  `training_name` varchar(100) DEFAULT NULL,
  `training_type` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `date_add` datetime DEFAULT NULL,
  `position_training_id` text DEFAULT NULL,
  `mint_point` int(11) DEFAULT NULL,
  `additional_training` varchar(100) DEFAULT '',
  `staff_id` text DEFAULT NULL,
  `time_to_start` date DEFAULT NULL,
  `time_to_end` date DEFAULT NULL,
  PRIMARY KEY (`training_process_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_jp_interview_training`
--

LOCK TABLES `tblhr_jp_interview_training` WRITE;
/*!40000 ALTER TABLE `tblhr_jp_interview_training` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_jp_interview_training` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_jp_salary_scale`
--

DROP TABLE IF EXISTS `tblhr_jp_salary_scale`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhr_jp_salary_scale` (
  `salary_scale_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `job_position_id` int(11) unsigned NOT NULL,
  `rel_type` varchar(100) DEFAULT NULL COMMENT 'salary:allowance:insurance',
  `rel_id` int(11) DEFAULT NULL,
  `value` text DEFAULT NULL,
  PRIMARY KEY (`salary_scale_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_jp_salary_scale`
--

LOCK TABLES `tblhr_jp_salary_scale` WRITE;
/*!40000 ALTER TABLE `tblhr_jp_salary_scale` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_jp_salary_scale` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_knowedge_base_article_feedback`
--

DROP TABLE IF EXISTS `tblhr_knowedge_base_article_feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhr_knowedge_base_article_feedback` (
  `articleanswerid` int(11) NOT NULL AUTO_INCREMENT,
  `articleid` int(11) NOT NULL,
  `answer` int(11) NOT NULL,
  `ip` varchar(40) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`articleanswerid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_knowedge_base_article_feedback`
--

LOCK TABLES `tblhr_knowedge_base_article_feedback` WRITE;
/*!40000 ALTER TABLE `tblhr_knowedge_base_article_feedback` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_knowedge_base_article_feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_knowledge_base`
--

DROP TABLE IF EXISTS `tblhr_knowledge_base`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhr_knowledge_base` (
  `articleid` int(11) NOT NULL AUTO_INCREMENT,
  `articlegroup` int(11) NOT NULL,
  `subject` mediumtext NOT NULL,
  `description` text NOT NULL,
  `slug` mediumtext NOT NULL,
  `active` tinyint(4) NOT NULL,
  `datecreated` datetime NOT NULL,
  `article_order` int(11) NOT NULL DEFAULT 0,
  `staff_article` int(11) NOT NULL DEFAULT 0,
  `question_answers` int(11) DEFAULT 0,
  `file_name` varchar(255) DEFAULT '',
  `curator` varchar(11) DEFAULT '',
  `benchmark` int(11) DEFAULT 0,
  `score` int(11) DEFAULT 0,
  PRIMARY KEY (`articleid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_knowledge_base`
--

LOCK TABLES `tblhr_knowledge_base` WRITE;
/*!40000 ALTER TABLE `tblhr_knowledge_base` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_knowledge_base` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_knowledge_base_groups`
--

DROP TABLE IF EXISTS `tblhr_knowledge_base_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhr_knowledge_base_groups` (
  `groupid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `group_slug` text DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `active` tinyint(4) NOT NULL,
  `color` varchar(10) DEFAULT '#28B8DA',
  `group_order` int(11) DEFAULT 0,
  PRIMARY KEY (`groupid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_knowledge_base_groups`
--

LOCK TABLES `tblhr_knowledge_base_groups` WRITE;
/*!40000 ALTER TABLE `tblhr_knowledge_base_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_knowledge_base_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_list_staff_quitting_work`
--

DROP TABLE IF EXISTS `tblhr_list_staff_quitting_work`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhr_list_staff_quitting_work` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staffid` int(11) DEFAULT NULL,
  `staff_name` text DEFAULT NULL,
  `department_name` text DEFAULT NULL,
  `role_name` text DEFAULT NULL,
  `email` text DEFAULT NULL,
  `dateoff` datetime DEFAULT NULL,
  `approval` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_list_staff_quitting_work`
--

LOCK TABLES `tblhr_list_staff_quitting_work` WRITE;
/*!40000 ALTER TABLE `tblhr_list_staff_quitting_work` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_list_staff_quitting_work` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_p_t_form_question_box`
--

DROP TABLE IF EXISTS `tblhr_p_t_form_question_box`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhr_p_t_form_question_box` (
  `boxid` int(11) NOT NULL AUTO_INCREMENT,
  `boxtype` varchar(10) NOT NULL,
  `questionid` int(11) NOT NULL,
  PRIMARY KEY (`boxid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_p_t_form_question_box`
--

LOCK TABLES `tblhr_p_t_form_question_box` WRITE;
/*!40000 ALTER TABLE `tblhr_p_t_form_question_box` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_p_t_form_question_box` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_p_t_form_question_box_description`
--

DROP TABLE IF EXISTS `tblhr_p_t_form_question_box_description`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhr_p_t_form_question_box_description` (
  `questionboxdescriptionid` int(11) NOT NULL AUTO_INCREMENT,
  `description` mediumtext NOT NULL,
  `boxid` mediumtext NOT NULL,
  `questionid` int(11) NOT NULL,
  `correct` int(11) DEFAULT 1 COMMENT '0: correct 1: incorrect',
  PRIMARY KEY (`questionboxdescriptionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_p_t_form_question_box_description`
--

LOCK TABLES `tblhr_p_t_form_question_box_description` WRITE;
/*!40000 ALTER TABLE `tblhr_p_t_form_question_box_description` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_p_t_form_question_box_description` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_p_t_form_results`
--

DROP TABLE IF EXISTS `tblhr_p_t_form_results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhr_p_t_form_results` (
  `resultid` int(11) NOT NULL AUTO_INCREMENT,
  `boxid` int(11) NOT NULL,
  `boxdescriptionid` int(11) DEFAULT NULL,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) DEFAULT NULL,
  `questionid` int(11) NOT NULL,
  `answer` text DEFAULT NULL,
  `resultsetid` int(11) NOT NULL,
  PRIMARY KEY (`resultid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_p_t_form_results`
--

LOCK TABLES `tblhr_p_t_form_results` WRITE;
/*!40000 ALTER TABLE `tblhr_p_t_form_results` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_p_t_form_results` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_p_t_surveyresultsets`
--

DROP TABLE IF EXISTS `tblhr_p_t_surveyresultsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhr_p_t_surveyresultsets` (
  `resultsetid` int(11) NOT NULL AUTO_INCREMENT,
  `trainingid` int(11) NOT NULL,
  `ip` varchar(40) NOT NULL,
  `useragent` varchar(150) NOT NULL,
  `date` datetime NOT NULL,
  `staff_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`resultsetid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_p_t_surveyresultsets`
--

LOCK TABLES `tblhr_p_t_surveyresultsets` WRITE;
/*!40000 ALTER TABLE `tblhr_p_t_surveyresultsets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_p_t_surveyresultsets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_payroll_option`
--

DROP TABLE IF EXISTS `tblhr_payroll_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhr_payroll_option` (
  `option_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(200) NOT NULL,
  `option_val` longtext DEFAULT NULL,
  `auto` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`option_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_payroll_option`
--

LOCK TABLES `tblhr_payroll_option` WRITE;
/*!40000 ALTER TABLE `tblhr_payroll_option` DISABLE KEYS */;
INSERT INTO `tblhr_payroll_option` VALUES
(1,'integrated_hrprofile','0',1),
(2,'integrated_timesheets','0',1),
(3,'integration_actual_workday','W,B',1),
(4,'integration_paid_leave','AL,HO,EB',1),
(5,'integration_unpaid_leave','U,SI,UB,P',1),
(6,'standard_working_time','160',1),
(7,'integrated_commissions','0',1),
(8,'hrp_customize_staff_payslip_column','0',1);
/*!40000 ALTER TABLE `tblhr_payroll_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_position_training`
--

DROP TABLE IF EXISTS `tblhr_position_training`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhr_position_training` (
  `training_id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` mediumtext NOT NULL,
  `training_type` int(11) unsigned NOT NULL,
  `slug` mediumtext NOT NULL,
  `description` text DEFAULT NULL,
  `viewdescription` text DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `redirect_url` varchar(100) DEFAULT NULL,
  `send` tinyint(1) NOT NULL DEFAULT 0,
  `onlyforloggedin` int(11) DEFAULT 0,
  `fromname` varchar(100) DEFAULT NULL,
  `iprestrict` tinyint(1) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `hash` varchar(32) NOT NULL,
  `mint_point` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`training_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_position_training`
--

LOCK TABLES `tblhr_position_training` WRITE;
/*!40000 ALTER TABLE `tblhr_position_training` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_position_training` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_position_training_question_form`
--

DROP TABLE IF EXISTS `tblhr_position_training_question_form`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhr_position_training_question_form` (
  `questionid` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) DEFAULT NULL,
  `question` mediumtext NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT 0,
  `question_order` int(11) NOT NULL,
  `point` int(11) NOT NULL,
  PRIMARY KEY (`questionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_position_training_question_form`
--

LOCK TABLES `tblhr_position_training_question_form` WRITE;
/*!40000 ALTER TABLE `tblhr_position_training_question_form` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_position_training_question_form` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_procedure_retire`
--

DROP TABLE IF EXISTS `tblhr_procedure_retire`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhr_procedure_retire` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_name` text DEFAULT NULL,
  `option_name` text DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `people_handle_id` int(11) NOT NULL,
  `procedure_retire_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_procedure_retire`
--

LOCK TABLES `tblhr_procedure_retire` WRITE;
/*!40000 ALTER TABLE `tblhr_procedure_retire` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_procedure_retire` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_procedure_retire_manage`
--

DROP TABLE IF EXISTS `tblhr_procedure_retire_manage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhr_procedure_retire_manage` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name_procedure_retire` text NOT NULL,
  `department` varchar(250) NOT NULL,
  `datecreator` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_procedure_retire_manage`
--

LOCK TABLES `tblhr_procedure_retire_manage` WRITE;
/*!40000 ALTER TABLE `tblhr_procedure_retire_manage` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_procedure_retire_manage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_procedure_retire_of_staff`
--

DROP TABLE IF EXISTS `tblhr_procedure_retire_of_staff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhr_procedure_retire_of_staff` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) DEFAULT NULL,
  `option_name` text DEFAULT NULL,
  `status` int(11) DEFAULT 0,
  `staffid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_procedure_retire_of_staff`
--

LOCK TABLES `tblhr_procedure_retire_of_staff` WRITE;
/*!40000 ALTER TABLE `tblhr_procedure_retire_of_staff` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_procedure_retire_of_staff` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_procedure_retire_of_staff_by_id`
--

DROP TABLE IF EXISTS `tblhr_procedure_retire_of_staff_by_id`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhr_procedure_retire_of_staff_by_id` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_name` text DEFAULT NULL,
  `people_handle_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_procedure_retire_of_staff_by_id`
--

LOCK TABLES `tblhr_procedure_retire_of_staff_by_id` WRITE;
/*!40000 ALTER TABLE `tblhr_procedure_retire_of_staff_by_id` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_procedure_retire_of_staff_by_id` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_profile_option`
--

DROP TABLE IF EXISTS `tblhr_profile_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhr_profile_option` (
  `option_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(200) NOT NULL,
  `option_val` longtext DEFAULT NULL,
  `auto` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`option_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_profile_option`
--

LOCK TABLES `tblhr_profile_option` WRITE;
/*!40000 ALTER TABLE `tblhr_profile_option` DISABLE KEYS */;
INSERT INTO `tblhr_profile_option` VALUES
(1,'job_position_prefix','#JOB',1),
(2,'job_position_number','1',1),
(3,'contract_code_prefix','#CONTRACT',1),
(4,'contract_code_number','1',1),
(5,'staff_code_prefix','EC',1),
(6,'staff_code_number','1',1);
/*!40000 ALTER TABLE `tblhr_profile_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_rec_transfer_records`
--

DROP TABLE IF EXISTS `tblhr_rec_transfer_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhr_rec_transfer_records` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `firstname` varchar(100) DEFAULT NULL,
  `lastname` varchar(100) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `gender` varchar(11) DEFAULT NULL,
  `staff_identifi` varchar(20) DEFAULT NULL,
  `creator` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_rec_transfer_records`
--

LOCK TABLES `tblhr_rec_transfer_records` WRITE;
/*!40000 ALTER TABLE `tblhr_rec_transfer_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_rec_transfer_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_salary_form`
--

DROP TABLE IF EXISTS `tblhr_salary_form`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhr_salary_form` (
  `form_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `form_name` varchar(200) NOT NULL,
  `salary_val` decimal(15,2) NOT NULL,
  `tax` tinyint(1) NOT NULL,
  PRIMARY KEY (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_salary_form`
--

LOCK TABLES `tblhr_salary_form` WRITE;
/*!40000 ALTER TABLE `tblhr_salary_form` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_salary_form` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_staff_contract`
--

DROP TABLE IF EXISTS `tblhr_staff_contract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhr_staff_contract` (
  `id_contract` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `contract_code` varchar(200) NOT NULL,
  `name_contract` int(11) NOT NULL,
  `staff` int(11) NOT NULL,
  `start_valid` date DEFAULT NULL,
  `end_valid` date DEFAULT NULL,
  `contract_status` varchar(100) DEFAULT NULL,
  `sign_day` date DEFAULT NULL,
  `staff_delegate` int(11) DEFAULT NULL,
  `hourly_or_month` longtext DEFAULT NULL,
  `content` longtext DEFAULT NULL,
  `hash` varchar(32) DEFAULT NULL,
  `signature` varchar(40) DEFAULT NULL,
  `signer` int(11) DEFAULT NULL,
  `staff_signature` varchar(40) DEFAULT NULL,
  `staff_sign_day` date DEFAULT NULL,
  PRIMARY KEY (`id_contract`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_staff_contract`
--

LOCK TABLES `tblhr_staff_contract` WRITE;
/*!40000 ALTER TABLE `tblhr_staff_contract` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_staff_contract` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_staff_contract_detail`
--

DROP TABLE IF EXISTS `tblhr_staff_contract_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhr_staff_contract_detail` (
  `contract_detail_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staff_contract_id` int(11) unsigned NOT NULL,
  `type` text DEFAULT NULL,
  `rel_type` text DEFAULT NULL,
  `rel_value` decimal(15,2) DEFAULT 0.00,
  `since_date` date DEFAULT NULL,
  `contract_note` text DEFAULT NULL,
  PRIMARY KEY (`contract_detail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_staff_contract_detail`
--

LOCK TABLES `tblhr_staff_contract_detail` WRITE;
/*!40000 ALTER TABLE `tblhr_staff_contract_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_staff_contract_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_staff_contract_type`
--

DROP TABLE IF EXISTS `tblhr_staff_contract_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhr_staff_contract_type` (
  `id_contracttype` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name_contracttype` varchar(200) NOT NULL,
  `description` longtext DEFAULT NULL,
  `duration` int(11) DEFAULT NULL,
  `unit` varchar(20) DEFAULT NULL,
  `insurance` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id_contracttype`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_staff_contract_type`
--

LOCK TABLES `tblhr_staff_contract_type` WRITE;
/*!40000 ALTER TABLE `tblhr_staff_contract_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_staff_contract_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_training_allocation`
--

DROP TABLE IF EXISTS `tblhr_training_allocation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhr_training_allocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `training_process_id` varchar(100) NOT NULL,
  `staffid` int(11) DEFAULT NULL,
  `training_type` int(11) DEFAULT NULL,
  `date_add` datetime DEFAULT NULL,
  `training_name` varchar(150) DEFAULT NULL,
  `jp_interview_training_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_training_allocation`
--

LOCK TABLES `tblhr_training_allocation` WRITE;
/*!40000 ALTER TABLE `tblhr_training_allocation` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_training_allocation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_type_of_trainings`
--

DROP TABLE IF EXISTS `tblhr_type_of_trainings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhr_type_of_trainings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_type_of_trainings`
--

LOCK TABLES `tblhr_type_of_trainings` WRITE;
/*!40000 ALTER TABLE `tblhr_type_of_trainings` DISABLE KEYS */;
INSERT INTO `tblhr_type_of_trainings` VALUES
(1,'Basic training');
/*!40000 ALTER TABLE `tblhr_type_of_trainings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_views_tracking`
--

DROP TABLE IF EXISTS `tblhr_views_tracking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhr_views_tracking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(40) NOT NULL,
  `date` datetime NOT NULL,
  `view_ip` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_views_tracking`
--

LOCK TABLES `tblhr_views_tracking` WRITE;
/*!40000 ALTER TABLE `tblhr_views_tracking` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_views_tracking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_workplace`
--

DROP TABLE IF EXISTS `tblhr_workplace`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhr_workplace` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `workplace_address` varchar(400) DEFAULT NULL,
  `latitude` double DEFAULT NULL,
  `longitude` double DEFAULT NULL,
  `default` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_workplace`
--

LOCK TABLES `tblhr_workplace` WRITE;
/*!40000 ALTER TABLE `tblhr_workplace` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_workplace` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhrp_bonus_kpi`
--

DROP TABLE IF EXISTS `tblhrp_bonus_kpi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhrp_bonus_kpi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `month_bonus_kpi` varchar(45) DEFAULT NULL,
  `staffid` int(11) DEFAULT NULL,
  `bonus_kpi` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhrp_bonus_kpi`
--

LOCK TABLES `tblhrp_bonus_kpi` WRITE;
/*!40000 ALTER TABLE `tblhrp_bonus_kpi` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhrp_bonus_kpi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhrp_commissions`
--

DROP TABLE IF EXISTS `tblhrp_commissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhrp_commissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `month` date NOT NULL,
  `commission_amount` decimal(15,2) DEFAULT NULL,
  `rel_type` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhrp_commissions`
--

LOCK TABLES `tblhrp_commissions` WRITE;
/*!40000 ALTER TABLE `tblhrp_commissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhrp_commissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhrp_company_contributions_list`
--

DROP TABLE IF EXISTS `tblhrp_company_contributions_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhrp_company_contributions_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(200) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `rate` decimal(15,2) DEFAULT NULL,
  `basis` varchar(200) DEFAULT NULL,
  `earn_inclusion` varchar(200) DEFAULT NULL,
  `earn_exclusion` varchar(200) DEFAULT NULL,
  `earnings_max` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhrp_company_contributions_list`
--

LOCK TABLES `tblhrp_company_contributions_list` WRITE;
/*!40000 ALTER TABLE `tblhrp_company_contributions_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhrp_company_contributions_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhrp_customize_staff_payslip_columns`
--

DROP TABLE IF EXISTS `tblhrp_customize_staff_payslip_columns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhrp_customize_staff_payslip_columns` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `column_name` text DEFAULT NULL,
  `order_number` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhrp_customize_staff_payslip_columns`
--

LOCK TABLES `tblhrp_customize_staff_payslip_columns` WRITE;
/*!40000 ALTER TABLE `tblhrp_customize_staff_payslip_columns` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhrp_customize_staff_payslip_columns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhrp_earnings_list`
--

DROP TABLE IF EXISTS `tblhrp_earnings_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhrp_earnings_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(200) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `short_name` varchar(200) DEFAULT NULL,
  `taxable` decimal(15,2) DEFAULT NULL,
  `basis_type` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhrp_earnings_list`
--

LOCK TABLES `tblhrp_earnings_list` WRITE;
/*!40000 ALTER TABLE `tblhrp_earnings_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhrp_earnings_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhrp_earnings_list_hr_records`
--

DROP TABLE IF EXISTS `tblhrp_earnings_list_hr_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhrp_earnings_list_hr_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(200) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `short_name` varchar(200) DEFAULT NULL,
  `taxable` decimal(15,2) DEFAULT NULL,
  `basis_type` varchar(200) DEFAULT NULL,
  `rel_type` varchar(200) DEFAULT NULL,
  `rel_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhrp_earnings_list_hr_records`
--

LOCK TABLES `tblhrp_earnings_list_hr_records` WRITE;
/*!40000 ALTER TABLE `tblhrp_earnings_list_hr_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhrp_earnings_list_hr_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhrp_employees_timeshee_leaves`
--

DROP TABLE IF EXISTS `tblhrp_employees_timeshee_leaves`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhrp_employees_timeshee_leaves` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `month` date NOT NULL,
  `day_1` text DEFAULT '',
  `day_2` text DEFAULT '',
  `day_3` text DEFAULT '',
  `day_4` text DEFAULT '',
  `day_5` text DEFAULT '',
  `day_6` text DEFAULT '',
  `day_7` text DEFAULT '',
  `day_8` text DEFAULT '',
  `day_9` text DEFAULT '',
  `day_10` text DEFAULT '',
  `day_11` text DEFAULT '',
  `day_12` text DEFAULT '',
  `day_13` text DEFAULT '',
  `day_14` text DEFAULT '',
  `day_15` text DEFAULT '',
  `day_16` text DEFAULT '',
  `day_17` text DEFAULT '',
  `day_18` text DEFAULT '',
  `day_19` text DEFAULT '',
  `day_20` text DEFAULT '',
  `day_21` text DEFAULT '',
  `day_22` text DEFAULT '',
  `day_23` text DEFAULT '',
  `day_24` text DEFAULT '',
  `day_25` text DEFAULT '',
  `day_26` text DEFAULT '',
  `day_27` text DEFAULT '',
  `day_28` text DEFAULT '',
  `day_29` text DEFAULT '',
  `day_30` text DEFAULT '',
  `day_31` text DEFAULT '',
  `paid_leave` decimal(15,2) DEFAULT NULL,
  `unpaid_leave` decimal(15,2) DEFAULT NULL,
  `rel_type` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhrp_employees_timeshee_leaves`
--

LOCK TABLES `tblhrp_employees_timeshee_leaves` WRITE;
/*!40000 ALTER TABLE `tblhrp_employees_timeshee_leaves` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhrp_employees_timeshee_leaves` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhrp_employees_timesheets`
--

DROP TABLE IF EXISTS `tblhrp_employees_timesheets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhrp_employees_timesheets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `month` date NOT NULL,
  `day_1` decimal(15,2) DEFAULT 0.00,
  `day_2` decimal(15,2) DEFAULT 0.00,
  `day_3` decimal(15,2) DEFAULT 0.00,
  `day_4` decimal(15,2) DEFAULT 0.00,
  `day_5` decimal(15,2) DEFAULT 0.00,
  `day_6` decimal(15,2) DEFAULT 0.00,
  `day_7` decimal(15,2) DEFAULT 0.00,
  `day_8` decimal(15,2) DEFAULT 0.00,
  `day_9` decimal(15,2) DEFAULT 0.00,
  `day_10` decimal(15,2) DEFAULT 0.00,
  `day_11` decimal(15,2) DEFAULT 0.00,
  `day_12` decimal(15,2) DEFAULT 0.00,
  `day_13` decimal(15,2) DEFAULT 0.00,
  `day_14` decimal(15,2) DEFAULT 0.00,
  `day_15` decimal(15,2) DEFAULT 0.00,
  `day_16` decimal(15,2) DEFAULT 0.00,
  `day_17` decimal(15,2) DEFAULT 0.00,
  `day_18` decimal(15,2) DEFAULT 0.00,
  `day_19` decimal(15,2) DEFAULT 0.00,
  `day_20` decimal(15,2) DEFAULT 0.00,
  `day_21` decimal(15,2) DEFAULT 0.00,
  `day_22` decimal(15,2) DEFAULT 0.00,
  `day_23` decimal(15,2) DEFAULT 0.00,
  `day_24` decimal(15,2) DEFAULT 0.00,
  `day_25` decimal(15,2) DEFAULT 0.00,
  `day_26` decimal(15,2) DEFAULT 0.00,
  `day_27` decimal(15,2) DEFAULT 0.00,
  `day_28` decimal(15,2) DEFAULT 0.00,
  `day_29` decimal(15,2) DEFAULT 0.00,
  `day_30` decimal(15,2) DEFAULT 0.00,
  `day_31` decimal(15,2) DEFAULT 0.00,
  `standard_workday` decimal(15,2) DEFAULT NULL,
  `actual_workday` decimal(15,2) DEFAULT NULL,
  `paid_leave` decimal(15,2) DEFAULT NULL,
  `unpaid_leave` decimal(15,2) DEFAULT NULL,
  `rel_type` varchar(100) DEFAULT NULL,
  `actual_workday_probation` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhrp_employees_timesheets`
--

LOCK TABLES `tblhrp_employees_timesheets` WRITE;
/*!40000 ALTER TABLE `tblhrp_employees_timesheets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhrp_employees_timesheets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhrp_employees_value`
--

DROP TABLE IF EXISTS `tblhrp_employees_value`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhrp_employees_value` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `month` date NOT NULL,
  `job_title` varchar(200) DEFAULT NULL,
  `income_tax_number` varchar(200) DEFAULT NULL,
  `residential_address` text DEFAULT NULL,
  `income_rebate_code` varchar(200) DEFAULT NULL,
  `income_tax_rate` varchar(200) DEFAULT NULL,
  `probationary_contracts` longtext DEFAULT NULL,
  `primary_contracts` longtext DEFAULT NULL,
  `rel_type` varchar(100) DEFAULT NULL,
  `probationary_effective` date DEFAULT NULL,
  `probationary_expiration` date DEFAULT NULL,
  `primary_effective` date DEFAULT NULL,
  `primary_expiration` date DEFAULT NULL,
  `bank_name` varchar(500) DEFAULT NULL,
  `account_number` varchar(200) DEFAULT NULL,
  `epf_no` text DEFAULT NULL,
  `social_security_no` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhrp_employees_value`
--

LOCK TABLES `tblhrp_employees_value` WRITE;
/*!40000 ALTER TABLE `tblhrp_employees_value` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhrp_employees_value` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhrp_income_tax_rates`
--

DROP TABLE IF EXISTS `tblhrp_income_tax_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhrp_income_tax_rates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tax_bracket_value_from` decimal(15,2) DEFAULT NULL,
  `tax_bracket_value_to` decimal(15,2) DEFAULT NULL,
  `tax_rate` decimal(15,2) DEFAULT NULL,
  `equivalent_value` decimal(15,2) DEFAULT NULL,
  `effective_rate` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhrp_income_tax_rates`
--

LOCK TABLES `tblhrp_income_tax_rates` WRITE;
/*!40000 ALTER TABLE `tblhrp_income_tax_rates` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhrp_income_tax_rates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhrp_income_tax_rebates`
--

DROP TABLE IF EXISTS `tblhrp_income_tax_rebates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhrp_income_tax_rebates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(200) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `value` decimal(15,2) DEFAULT NULL,
  `total` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhrp_income_tax_rebates`
--

LOCK TABLES `tblhrp_income_tax_rebates` WRITE;
/*!40000 ALTER TABLE `tblhrp_income_tax_rebates` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhrp_income_tax_rebates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhrp_income_taxs`
--

DROP TABLE IF EXISTS `tblhrp_income_taxs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhrp_income_taxs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `month` date NOT NULL,
  `gross_amount` decimal(15,2) DEFAULT NULL,
  `total_deduction_amount` decimal(15,2) DEFAULT NULL,
  `income_tax` decimal(15,2) DEFAULT NULL,
  `payslip_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhrp_income_taxs`
--

LOCK TABLES `tblhrp_income_taxs` WRITE;
/*!40000 ALTER TABLE `tblhrp_income_taxs` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhrp_income_taxs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhrp_insurance_list`
--

DROP TABLE IF EXISTS `tblhrp_insurance_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhrp_insurance_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(200) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `rate` decimal(15,2) DEFAULT NULL,
  `basis` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhrp_insurance_list`
--

LOCK TABLES `tblhrp_insurance_list` WRITE;
/*!40000 ALTER TABLE `tblhrp_insurance_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhrp_insurance_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhrp_payroll_columns`
--

DROP TABLE IF EXISTS `tblhrp_payroll_columns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhrp_payroll_columns` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `column_key` text DEFAULT NULL,
  `taking_method` text DEFAULT NULL COMMENT 'get from system, caculator, constant... ',
  `function_name` text DEFAULT NULL COMMENT 'get value for method system',
  `value_related_to` text DEFAULT NULL COMMENT 'salary, allowance value...',
  `display_with_staff` varchar(10) DEFAULT 'true',
  `description` text DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `staff_id_created` int(11) NOT NULL,
  `order_display` int(11) DEFAULT NULL,
  `is_edit` varchar(100) DEFAULT 'yes',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhrp_payroll_columns`
--

LOCK TABLES `tblhrp_payroll_columns` WRITE;
/*!40000 ALTER TABLE `tblhrp_payroll_columns` DISABLE KEYS */;
INSERT INTO `tblhrp_payroll_columns` VALUES
(1,'Staff ID','system','staff_id','','true','Staff ID','2025-06-25 21:33:29',1,1,'no'),
(2,'Payslip Number','system','pay_slip_number','','true','Pay Slip Number','2025-06-25 21:33:29',1,2,'no'),
(3,'Payment Run Date','system','payment_run_date','','true','Payment Run Date','2025-06-25 21:33:29',1,3,'no'),
(4,'Employee Number','system','employee_number','','true','Employee Number','2025-06-25 21:33:29',1,4,'no'),
(5,'Employee Name','system','employee_name','','true','Employee Name','2025-06-25 21:33:29',1,5,'no'),
(6,'Deparment Name','system','dept_name','','true','Dept name Name','2025-06-25 21:33:29',1,6,'no'),
(7,'Standard Working Time','system','standard_workday','','true','Standard working time of the month (hours)','2025-06-25 21:33:29',1,7,'no'),
(8,'Actual Working Time of Formal contract','system','actual_workday','','true','Actual working time (hours)','2025-06-25 21:33:29',1,8,'no'),
(9,'Actual Working Time of Probation contract','system','actual_workday_probation','','true','Actual Working Time of Probation contract (hours)','2025-06-25 21:33:29',1,9,'no'),
(10,'Paid Leave Time','system','paid_leave','','true','Paid Leave Time (hours)','2025-06-25 21:33:29',1,10,'no'),
(11,'Unpaid Leave Time','system','unpaid_leave','','true','Unpaid Leave Time (hours)','2025-06-25 21:33:29',1,11,'no'),
(12,'Salary of the probationary contract','caculator','salary_of_the_probationary_contract','','true','Salary of the probationary contract','2025-06-25 21:33:29',1,12,'no'),
(13,'Salary of the formal contract','caculator','salary_of_the_formal_contract','','true','Salary of the formal contract','2025-06-25 21:33:29',1,13,'no'),
(14,'Gross Pay','caculator','gross_pay','','true','Gross Pay','2025-06-25 21:33:29',1,14,'no'),
(15,'Total Deductions','caculator','total_deductions','','true','Total Deductions','2025-06-25 21:33:29',1,15,'no'),
(16,'Total Insurance','caculator','total_insurance','','true','Total Insurance','2025-06-25 21:33:29',1,16,'no'),
(17,'Income Tax Rebate Code','system','it_rebate_code','','true','IT Rebate Code','2025-06-25 21:33:29',1,17,'no'),
(18,'Income Tax Rebate Value','system','it_rebate_value','','true','IT Rebate Value','2025-06-25 21:33:29',1,18,'no'),
(19,'Taxable salary','caculator','taxable_salary','','true','Taxable salary','2025-06-25 21:33:29',1,19,'no'),
(20,'Income Tax code','system','income_tax_code','','true','Income Tax code','2025-06-25 21:33:29',1,20,'no'),
(21,'Personal Income Tax','system','income_tax_paye','','true','Personal Income Tax','2025-06-25 21:33:29',1,21,'no'),
(22,'Commission Amount','system','commission_amount','','true','Commission','2025-06-25 21:33:29',1,22,'no'),
(23,'Bonus Kpi','system','bonus_kpi','','true','Bonus Kpi','2025-06-25 21:33:29',1,23,'no'),
(24,'Net Pay','caculator','net_pay','','true','Net Pay','2025-06-25 21:33:29',1,24,'no'),
(25,'Total Cost','caculator','total_cost','','true','Total cost','2025-06-25 21:33:29',1,25,'no'),
(26,'Total hours by tasks','system','total_hours_by_tasks','','true','Total hours by tasks','2025-06-25 21:33:29',1,16,'no'),
(27,'Salary from tasks','system','salary_from_tasks','','true','Salary from tasks','2025-06-25 21:33:29',1,16,'no'),
(28,'Bank Name','system','bank_name','','true','Bank Name','2025-06-25 21:33:29',1,17,'no'),
(29,'Account Number','system','account_number','','true','Account Number','2025-06-25 21:33:29',1,17,'no'),
(30,'EPF No','system','epf_no','','true','EPF No','2025-06-25 21:33:29',1,17,'no'),
(31,'Social Security No','system','social_security_no','','true','Social Security No','2025-06-25 21:33:29',1,17,'no');
/*!40000 ALTER TABLE `tblhrp_payroll_columns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhrp_payslip_details`
--

DROP TABLE IF EXISTS `tblhrp_payslip_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhrp_payslip_details` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `payslip_id` int(11) DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `month` date NOT NULL,
  `pay_slip_number` text DEFAULT NULL,
  `payment_run_date` date NOT NULL,
  `employee_number` text DEFAULT NULL,
  `employee_name` text DEFAULT NULL,
  `dept_name` text DEFAULT NULL,
  `standard_workday` decimal(15,2) DEFAULT 0.00,
  `actual_workday` decimal(15,2) DEFAULT 0.00,
  `paid_leave` decimal(15,2) DEFAULT 0.00,
  `unpaid_leave` decimal(15,2) DEFAULT 0.00,
  `gross_pay` decimal(15,2) DEFAULT 0.00,
  `income_tax_paye` decimal(15,2) DEFAULT 0.00,
  `total_deductions` decimal(15,2) DEFAULT 0.00,
  `net_pay` decimal(15,2) DEFAULT 0.00,
  `it_rebate_code` text DEFAULT NULL,
  `it_rebate_value` decimal(15,2) DEFAULT 0.00,
  `income_tax_code` text DEFAULT NULL,
  `commission_amount` decimal(15,2) DEFAULT 0.00,
  `bonus_kpi` decimal(15,2) DEFAULT 0.00,
  `total_cost` decimal(15,2) DEFAULT 0.00,
  `total_insurance` decimal(15,2) DEFAULT 0.00,
  `json_data` longtext DEFAULT NULL,
  `salary_of_the_probationary_contract` decimal(15,2) DEFAULT 0.00,
  `salary_of_the_formal_contract` decimal(15,2) DEFAULT 0.00,
  `taxable_salary` decimal(15,2) DEFAULT 0.00,
  `actual_workday_probation` decimal(15,2) DEFAULT 0.00,
  `total_hours_by_tasks` decimal(15,2) DEFAULT 0.00,
  `salary_from_tasks` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhrp_payslip_details`
--

LOCK TABLES `tblhrp_payslip_details` WRITE;
/*!40000 ALTER TABLE `tblhrp_payslip_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhrp_payslip_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhrp_payslip_pdf_templates`
--

DROP TABLE IF EXISTS `tblhrp_payslip_pdf_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhrp_payslip_pdf_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text DEFAULT NULL,
  `payslip_template_id` int(11) DEFAULT NULL,
  `content` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhrp_payslip_pdf_templates`
--

LOCK TABLES `tblhrp_payslip_pdf_templates` WRITE;
/*!40000 ALTER TABLE `tblhrp_payslip_pdf_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhrp_payslip_pdf_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhrp_payslip_templates`
--

DROP TABLE IF EXISTS `tblhrp_payslip_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhrp_payslip_templates` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `templates_name` varchar(100) NOT NULL,
  `payslip_columns` longtext DEFAULT NULL,
  `payslip_id_copy` int(11) unsigned NOT NULL,
  `department_id` longtext DEFAULT NULL,
  `role_employees` longtext DEFAULT NULL,
  `staff_employees` longtext DEFAULT NULL,
  `payslip_template_data` longtext DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `staff_id_created` int(11) NOT NULL,
  `cell_data` longtext DEFAULT NULL,
  `except_staff` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhrp_payslip_templates`
--

LOCK TABLES `tblhrp_payslip_templates` WRITE;
/*!40000 ALTER TABLE `tblhrp_payslip_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhrp_payslip_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhrp_payslips`
--

DROP TABLE IF EXISTS `tblhrp_payslips`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhrp_payslips` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `payslip_name` varchar(100) NOT NULL,
  `payslip_template_id` int(11) DEFAULT NULL,
  `payslip_month` date NOT NULL,
  `staff_id_created` int(11) NOT NULL,
  `date_created` datetime NOT NULL,
  `payslip_data` longtext DEFAULT NULL,
  `file_name` text DEFAULT NULL,
  `payslip_status` varchar(100) DEFAULT 'payslip_opening',
  `payslip_range` varchar(500) DEFAULT NULL,
  `pdf_template_id` int(11) DEFAULT NULL,
  `from_currency_id` int(11) DEFAULT 0,
  `from_currency_name` varchar(100) DEFAULT NULL,
  `from_currency_rate` decimal(15,6) NOT NULL DEFAULT 1.000000,
  `to_currency_id` int(11) DEFAULT 0,
  `to_currency_name` varchar(100) DEFAULT NULL,
  `to_currency_rate` decimal(15,6) NOT NULL DEFAULT 1.000000,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhrp_payslips`
--

LOCK TABLES `tblhrp_payslips` WRITE;
/*!40000 ALTER TABLE `tblhrp_payslips` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhrp_payslips` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhrp_salary_deductions`
--

DROP TABLE IF EXISTS `tblhrp_salary_deductions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhrp_salary_deductions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `month` date NOT NULL,
  `deduction_list` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhrp_salary_deductions`
--

LOCK TABLES `tblhrp_salary_deductions` WRITE;
/*!40000 ALTER TABLE `tblhrp_salary_deductions` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhrp_salary_deductions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhrp_salary_deductions_list`
--

DROP TABLE IF EXISTS `tblhrp_salary_deductions_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhrp_salary_deductions_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(200) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `rate` decimal(15,2) DEFAULT NULL,
  `basis` varchar(200) DEFAULT NULL,
  `earn_inclusion` varchar(200) DEFAULT NULL,
  `earn_exclusion` varchar(200) DEFAULT NULL,
  `earnings_max` decimal(15,2) DEFAULT NULL,
  `tax` decimal(15,2) DEFAULT NULL,
  `annual_tax_limit` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhrp_salary_deductions_list`
--

LOCK TABLES `tblhrp_salary_deductions_list` WRITE;
/*!40000 ALTER TABLE `tblhrp_salary_deductions_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhrp_salary_deductions_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhrp_staff_insurances`
--

DROP TABLE IF EXISTS `tblhrp_staff_insurances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhrp_staff_insurances` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `month` date NOT NULL,
  `insurance_list` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhrp_staff_insurances`
--

LOCK TABLES `tblhrp_staff_insurances` WRITE;
/*!40000 ALTER TABLE `tblhrp_staff_insurances` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhrp_staff_insurances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblinternal_delivery_note`
--

DROP TABLE IF EXISTS `tblinternal_delivery_note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblinternal_delivery_note` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `internal_delivery_name` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `date_c` date DEFAULT NULL,
  `date_add` date DEFAULT NULL,
  `internal_delivery_code` varchar(100) DEFAULT NULL,
  `approval` int(11) DEFAULT 0 COMMENT 'status approval ',
  `addedfrom` int(11) DEFAULT NULL,
  `total_amount` decimal(15,2) DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblinternal_delivery_note`
--

LOCK TABLES `tblinternal_delivery_note` WRITE;
/*!40000 ALTER TABLE `tblinternal_delivery_note` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblinternal_delivery_note` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblinternal_delivery_note_detail`
--

DROP TABLE IF EXISTS `tblinternal_delivery_note_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblinternal_delivery_note_detail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `internal_delivery_id` int(11) NOT NULL,
  `commodity_code` varchar(100) DEFAULT NULL,
  `from_stock_name` text DEFAULT NULL,
  `to_stock_name` text DEFAULT NULL,
  `unit_id` text DEFAULT NULL,
  `available_quantity` text DEFAULT NULL,
  `quantities` text DEFAULT NULL,
  `unit_price` varchar(100) DEFAULT NULL,
  `into_money` varchar(100) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `commodity_name` text DEFAULT NULL,
  `serial_number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblinternal_delivery_note_detail`
--

LOCK TABLES `tblinternal_delivery_note_detail` WRITE;
/*!40000 ALTER TABLE `tblinternal_delivery_note_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblinternal_delivery_note_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblinventory_commodity_min`
--

DROP TABLE IF EXISTS `tblinventory_commodity_min`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblinventory_commodity_min` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `commodity_id` int(11) NOT NULL,
  `commodity_code` varchar(100) DEFAULT NULL,
  `commodity_name` varchar(100) DEFAULT NULL,
  `inventory_number_min` varchar(100) DEFAULT NULL,
  `inventory_number_max` varchar(100) DEFAULT '0',
  PRIMARY KEY (`id`,`commodity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblinventory_commodity_min`
--

LOCK TABLES `tblinventory_commodity_min` WRITE;
/*!40000 ALTER TABLE `tblinventory_commodity_min` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblinventory_commodity_min` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblinventory_manage`
--

DROP TABLE IF EXISTS `tblinventory_manage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblinventory_manage` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `warehouse_id` int(11) NOT NULL,
  `commodity_id` int(11) NOT NULL,
  `inventory_number` varchar(100) DEFAULT NULL,
  `date_manufacture` date DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `lot_number` varchar(100) DEFAULT NULL,
  `purchase_price` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`,`commodity_id`,`warehouse_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblinventory_manage`
--

LOCK TABLES `tblinventory_manage` WRITE;
/*!40000 ALTER TABLE `tblinventory_manage` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblinventory_manage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblinvoicepaymentrecords`
--

DROP TABLE IF EXISTS `tblinvoicepaymentrecords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblinvoicepaymentrecords` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoiceid` int(11) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `paymentmode` varchar(40) DEFAULT NULL,
  `paymentmethod` varchar(191) DEFAULT NULL,
  `date` date NOT NULL,
  `daterecorded` datetime NOT NULL,
  `note` mediumtext DEFAULT NULL,
  `transactionid` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `invoiceid` (`invoiceid`),
  KEY `paymentmethod` (`paymentmethod`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblinvoicepaymentrecords`
--

LOCK TABLES `tblinvoicepaymentrecords` WRITE;
/*!40000 ALTER TABLE `tblinvoicepaymentrecords` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblinvoicepaymentrecords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblinvoices`
--

DROP TABLE IF EXISTS `tblinvoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblinvoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sent` tinyint(1) NOT NULL DEFAULT 0,
  `datesend` datetime DEFAULT NULL,
  `clientid` int(11) NOT NULL,
  `deleted_customer_name` varchar(100) DEFAULT NULL,
  `number` int(11) NOT NULL,
  `prefix` varchar(50) DEFAULT NULL,
  `number_format` int(11) NOT NULL DEFAULT 0,
  `datecreated` datetime NOT NULL,
  `date` date NOT NULL,
  `duedate` date DEFAULT NULL,
  `currency` int(11) NOT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `total_tax` decimal(15,2) NOT NULL DEFAULT 0.00,
  `total` decimal(15,2) NOT NULL,
  `adjustment` decimal(15,2) DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `hash` varchar(32) NOT NULL,
  `status` int(11) DEFAULT 1,
  `clientnote` mediumtext DEFAULT NULL,
  `adminnote` mediumtext DEFAULT NULL,
  `last_overdue_reminder` date DEFAULT NULL,
  `last_due_reminder` date DEFAULT NULL,
  `cancel_overdue_reminders` int(11) NOT NULL DEFAULT 0,
  `allowed_payment_modes` longtext DEFAULT NULL,
  `token` longtext DEFAULT NULL,
  `discount_percent` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `discount_type` varchar(30) NOT NULL,
  `recurring` int(11) NOT NULL DEFAULT 0,
  `recurring_type` varchar(10) DEFAULT NULL,
  `custom_recurring` tinyint(1) NOT NULL DEFAULT 0,
  `cycles` int(11) NOT NULL DEFAULT 0,
  `total_cycles` int(11) NOT NULL DEFAULT 0,
  `is_recurring_from` int(11) DEFAULT NULL,
  `last_recurring_date` date DEFAULT NULL,
  `terms` mediumtext DEFAULT NULL,
  `sale_agent` int(11) NOT NULL DEFAULT 0,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT NULL,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT NULL,
  `include_shipping` tinyint(1) NOT NULL,
  `show_shipping_on_invoice` tinyint(1) NOT NULL DEFAULT 1,
  `show_quantity_as` int(11) NOT NULL DEFAULT 1,
  `project_id` int(11) DEFAULT 0,
  `subscription_id` int(11) NOT NULL DEFAULT 0,
  `perfex_saas_packageid` int(11) DEFAULT NULL,
  `short_link` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `currency` (`currency`),
  KEY `clientid` (`clientid`),
  KEY `project_id` (`project_id`),
  KEY `sale_agent` (`sale_agent`),
  KEY `total` (`total`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblinvoices`
--

LOCK TABLES `tblinvoices` WRITE;
/*!40000 ALTER TABLE `tblinvoices` DISABLE KEYS */;
INSERT INTO `tblinvoices` VALUES
(1,0,NULL,4,NULL,1,'INV-',1,'2025-06-27 13:15:14','2025-06-27','2025-06-27',3,0.00,0.00,0.00,0.00,0,'1a07048a992caccd24309ef5572d456a',2,NULL,NULL,NULL,NULL,0,'a:1:{i:0;s:1:\"1\";}',NULL,0.00,0.00,'',1,NULL,0,0,0,NULL,NULL,NULL,0,'','','','',0,NULL,NULL,NULL,NULL,NULL,0,1,1,0,0,1,NULL);
/*!40000 ALTER TABLE `tblinvoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblitem_tax`
--

DROP TABLE IF EXISTS `tblitem_tax`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblitem_tax` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemid` int(11) NOT NULL,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) NOT NULL,
  `taxrate` decimal(15,2) NOT NULL,
  `taxname` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `itemid` (`itemid`),
  KEY `rel_id` (`rel_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblitem_tax`
--

LOCK TABLES `tblitem_tax` WRITE;
/*!40000 ALTER TABLE `tblitem_tax` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblitem_tax` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblitemable`
--

DROP TABLE IF EXISTS `tblitemable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblitemable` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(15) NOT NULL,
  `description` longtext NOT NULL,
  `long_description` longtext DEFAULT NULL,
  `qty` decimal(15,2) NOT NULL,
  `rate` decimal(15,2) NOT NULL,
  `unit` varchar(40) DEFAULT NULL,
  `item_order` int(11) DEFAULT NULL,
  `wh_delivered_quantity` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`),
  KEY `qty` (`qty`),
  KEY `rate` (`rate`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblitemable`
--

LOCK TABLES `tblitemable` WRITE;
/*!40000 ALTER TABLE `tblitemable` DISABLE KEYS */;
INSERT INTO `tblitemable` VALUES
(1,1,'invoice','Subscription to Starter Plan','',1.00,0.00,'',1,0.00);
/*!40000 ALTER TABLE `tblitemable` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblitems`
--

DROP TABLE IF EXISTS `tblitems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblitems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` longtext NOT NULL,
  `long_description` mediumtext DEFAULT NULL,
  `rate` decimal(15,2) NOT NULL,
  `tax` int(11) DEFAULT NULL,
  `tax2` int(11) DEFAULT NULL,
  `unit` varchar(40) DEFAULT NULL,
  `group_id` int(11) NOT NULL DEFAULT 0,
  `product_type` varchar(100) DEFAULT NULL,
  `description_internal_transfers` text DEFAULT NULL,
  `description_receipts` text DEFAULT NULL,
  `description_delivery_orders` text DEFAULT NULL,
  `customer_lead_time` decimal(15,2) DEFAULT 0.00,
  `replenish_on_order` varchar(100) DEFAULT NULL,
  `supplier_taxes_id` text DEFAULT NULL,
  `description_sale` text DEFAULT NULL,
  `invoice_policy` varchar(100) DEFAULT 'ordered_quantities',
  `purchase_unit_measure` int(11) DEFAULT NULL,
  `can_be_sold` varchar(100) DEFAULT 'can_be_sold',
  `can_be_purchased` varchar(100) DEFAULT 'can_be_purchased',
  `can_be_manufacturing` varchar(100) DEFAULT 'can_be_manufacturing',
  `manufacture` varchar(100) DEFAULT NULL,
  `manufacturing_lead_time` decimal(15,2) DEFAULT 0.00,
  `weight` decimal(15,2) DEFAULT 0.00,
  `volume` decimal(15,2) DEFAULT 0.00,
  `hs_code` varchar(200) DEFAULT NULL,
  `commodity_code` varchar(100) NOT NULL,
  `commodity_barcode` text DEFAULT NULL,
  `commodity_type` int(11) DEFAULT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `origin` varchar(100) DEFAULT NULL,
  `color_id` int(11) DEFAULT NULL,
  `style_id` int(11) DEFAULT NULL,
  `model_id` int(11) DEFAULT NULL,
  `size_id` int(11) DEFAULT NULL,
  `unit_id` int(11) DEFAULT NULL,
  `sku_code` varchar(200) DEFAULT NULL,
  `sku_name` varchar(200) DEFAULT NULL,
  `purchase_price` decimal(15,2) DEFAULT NULL,
  `sub_group` varchar(200) DEFAULT NULL,
  `commodity_name` varchar(200) NOT NULL,
  `color` text DEFAULT NULL,
  `guarantee` text DEFAULT NULL,
  `profif_ratio` text DEFAULT NULL,
  `active` int(11) DEFAULT 1,
  `long_descriptions` longtext DEFAULT NULL,
  `without_checking_warehouse` int(11) DEFAULT 0,
  `series_id` text DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `attributes` longtext DEFAULT NULL,
  `parent_attributes` longtext DEFAULT NULL,
  `can_be_inventory` varchar(100) DEFAULT 'can_be_inventory',
  PRIMARY KEY (`id`),
  KEY `tax` (`tax`),
  KEY `tax2` (`tax2`),
  KEY `group_id` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblitems`
--

LOCK TABLES `tblitems` WRITE;
/*!40000 ALTER TABLE `tblitems` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblitems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblitems_groups`
--

DROP TABLE IF EXISTS `tblitems_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblitems_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `commodity_group_code` varchar(100) DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  `display` int(1) DEFAULT NULL,
  `note` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblitems_groups`
--

LOCK TABLES `tblitems_groups` WRITE;
/*!40000 ALTER TABLE `tblitems_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblitems_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblknowedge_base_article_feedback`
--

DROP TABLE IF EXISTS `tblknowedge_base_article_feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblknowedge_base_article_feedback` (
  `articleanswerid` int(11) NOT NULL AUTO_INCREMENT,
  `articleid` int(11) NOT NULL,
  `answer` int(11) NOT NULL,
  `ip` varchar(40) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`articleanswerid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblknowedge_base_article_feedback`
--

LOCK TABLES `tblknowedge_base_article_feedback` WRITE;
/*!40000 ALTER TABLE `tblknowedge_base_article_feedback` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblknowedge_base_article_feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblknowledge_base`
--

DROP TABLE IF EXISTS `tblknowledge_base`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblknowledge_base` (
  `articleid` int(11) NOT NULL AUTO_INCREMENT,
  `articlegroup` int(11) NOT NULL,
  `subject` longtext NOT NULL,
  `description` mediumtext NOT NULL,
  `slug` longtext NOT NULL,
  `active` tinyint(4) NOT NULL,
  `datecreated` datetime NOT NULL,
  `article_order` int(11) NOT NULL DEFAULT 0,
  `staff_article` int(11) NOT NULL DEFAULT 0,
  `question_answers` int(11) DEFAULT 0,
  `file_name` varchar(255) DEFAULT '',
  `curator` varchar(11) DEFAULT '',
  `benchmark` int(11) DEFAULT 0,
  `score` int(11) DEFAULT 0,
  PRIMARY KEY (`articleid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblknowledge_base`
--

LOCK TABLES `tblknowledge_base` WRITE;
/*!40000 ALTER TABLE `tblknowledge_base` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblknowledge_base` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblknowledge_base_groups`
--

DROP TABLE IF EXISTS `tblknowledge_base_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblknowledge_base_groups` (
  `groupid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `group_slug` mediumtext DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `active` tinyint(4) NOT NULL,
  `color` varchar(10) DEFAULT '#28B8DA',
  `group_order` int(11) DEFAULT 0,
  PRIMARY KEY (`groupid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblknowledge_base_groups`
--

LOCK TABLES `tblknowledge_base_groups` WRITE;
/*!40000 ALTER TABLE `tblknowledge_base_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblknowledge_base_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbllead_activity_log`
--

DROP TABLE IF EXISTS `tbllead_activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbllead_activity_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `leadid` int(11) NOT NULL,
  `description` longtext NOT NULL,
  `additional_data` mediumtext DEFAULT NULL,
  `date` datetime NOT NULL,
  `staffid` int(11) NOT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `custom_activity` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbllead_activity_log`
--

LOCK TABLES `tbllead_activity_log` WRITE;
/*!40000 ALTER TABLE `tbllead_activity_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbllead_activity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbllead_integration_emails`
--

DROP TABLE IF EXISTS `tbllead_integration_emails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbllead_integration_emails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` longtext DEFAULT NULL,
  `body` longtext DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  `leadid` int(11) NOT NULL,
  `emailid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbllead_integration_emails`
--

LOCK TABLES `tbllead_integration_emails` WRITE;
/*!40000 ALTER TABLE `tbllead_integration_emails` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbllead_integration_emails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblleads`
--

DROP TABLE IF EXISTS `tblleads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblleads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(65) DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `company` varchar(191) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `country` int(11) NOT NULL DEFAULT 0,
  `zip` varchar(15) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `assigned` int(11) NOT NULL DEFAULT 0,
  `dateadded` datetime NOT NULL,
  `from_form_id` int(11) NOT NULL DEFAULT 0,
  `status` int(11) NOT NULL,
  `source` int(11) NOT NULL,
  `lastcontact` datetime DEFAULT NULL,
  `dateassigned` date DEFAULT NULL,
  `last_status_change` datetime DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `website` varchar(150) DEFAULT NULL,
  `leadorder` int(11) DEFAULT 1,
  `phonenumber` varchar(50) DEFAULT NULL,
  `date_converted` datetime DEFAULT NULL,
  `lost` tinyint(1) NOT NULL DEFAULT 0,
  `junk` int(11) NOT NULL DEFAULT 0,
  `last_lead_status` int(11) NOT NULL DEFAULT 0,
  `is_imported_from_email_integration` tinyint(1) NOT NULL DEFAULT 0,
  `email_integration_uid` varchar(30) DEFAULT NULL,
  `is_public` tinyint(1) NOT NULL DEFAULT 0,
  `default_language` varchar(40) DEFAULT NULL,
  `client_id` int(11) NOT NULL DEFAULT 0,
  `lead_value` decimal(15,2) DEFAULT NULL,
  `vat` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `company` (`company`),
  KEY `email` (`email`),
  KEY `assigned` (`assigned`),
  KEY `status` (`status`),
  KEY `source` (`source`),
  KEY `lastcontact` (`lastcontact`),
  KEY `dateadded` (`dateadded`),
  KEY `leadorder` (`leadorder`),
  KEY `from_form_id` (`from_form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblleads`
--

LOCK TABLES `tblleads` WRITE;
/*!40000 ALTER TABLE `tblleads` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblleads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblleads_email_integration`
--

DROP TABLE IF EXISTS `tblleads_email_integration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblleads_email_integration` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'the ID always must be 1',
  `active` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `imap_server` varchar(100) NOT NULL,
  `password` longtext NOT NULL,
  `check_every` int(11) NOT NULL DEFAULT 5,
  `responsible` int(11) NOT NULL,
  `lead_source` int(11) NOT NULL,
  `lead_status` int(11) NOT NULL,
  `encryption` varchar(3) DEFAULT NULL,
  `folder` varchar(100) NOT NULL,
  `last_run` varchar(50) DEFAULT NULL,
  `notify_lead_imported` tinyint(1) NOT NULL DEFAULT 1,
  `notify_lead_contact_more_times` tinyint(1) NOT NULL DEFAULT 1,
  `notify_type` varchar(20) DEFAULT NULL,
  `notify_ids` longtext DEFAULT NULL,
  `mark_public` int(11) NOT NULL DEFAULT 0,
  `only_loop_on_unseen_emails` tinyint(1) NOT NULL DEFAULT 1,
  `delete_after_import` int(11) NOT NULL DEFAULT 0,
  `create_task_if_customer` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblleads_email_integration`
--

LOCK TABLES `tblleads_email_integration` WRITE;
/*!40000 ALTER TABLE `tblleads_email_integration` DISABLE KEYS */;
INSERT INTO `tblleads_email_integration` VALUES
(1,0,'','','',10,0,0,0,'tls','INBOX','',1,1,'assigned','',0,1,0,1);
/*!40000 ALTER TABLE `tblleads_email_integration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblleads_sources`
--

DROP TABLE IF EXISTS `tblleads_sources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblleads_sources` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblleads_sources`
--

LOCK TABLES `tblleads_sources` WRITE;
/*!40000 ALTER TABLE `tblleads_sources` DISABLE KEYS */;
INSERT INTO `tblleads_sources` VALUES
(2,'Facebook'),
(1,'Google');
/*!40000 ALTER TABLE `tblleads_sources` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblleads_status`
--

DROP TABLE IF EXISTS `tblleads_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblleads_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `statusorder` int(11) DEFAULT NULL,
  `color` varchar(10) DEFAULT '#28B8DA',
  `isdefault` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblleads_status`
--

LOCK TABLES `tblleads_status` WRITE;
/*!40000 ALTER TABLE `tblleads_status` DISABLE KEYS */;
INSERT INTO `tblleads_status` VALUES
(1,'Customer',1000,'#7cb342',1);
/*!40000 ALTER TABLE `tblleads_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblleave_of_the_year`
--

DROP TABLE IF EXISTS `tblleave_of_the_year`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblleave_of_the_year` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `value` double DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblleave_of_the_year`
--

LOCK TABLES `tblleave_of_the_year` WRITE;
/*!40000 ALTER TABLE `tblleave_of_the_year` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblleave_of_the_year` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblloy_card`
--

DROP TABLE IF EXISTS `tblloy_card`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblloy_card` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `add_from` int(11) NOT NULL,
  `date_create` date DEFAULT NULL,
  `subject_card` int(2) DEFAULT 0,
  `client_name` int(2) DEFAULT 0,
  `membership` int(2) DEFAULT 0,
  `company_name` int(2) DEFAULT 0,
  `member_since` int(2) DEFAULT 0,
  `custom_field` int(2) DEFAULT 0,
  `custom_field_content` varchar(200) DEFAULT NULL,
  `text_color` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblloy_card`
--

LOCK TABLES `tblloy_card` WRITE;
/*!40000 ALTER TABLE `tblloy_card` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblloy_card` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblloy_mbs_program`
--

DROP TABLE IF EXISTS `tblloy_mbs_program`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblloy_mbs_program` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `program_name` varchar(200) NOT NULL,
  `add_from` int(11) NOT NULL,
  `date_create` date DEFAULT NULL,
  `voucher_code` text NOT NULL,
  `discount` varchar(30) DEFAULT NULL,
  `discount_percent` int(5) DEFAULT NULL,
  `loyalty_point_from` decimal(15,0) DEFAULT NULL,
  `loyalty_point_to` decimal(15,0) DEFAULT NULL,
  `membership` text NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `note` text DEFAULT NULL,
  `voucher_value` decimal(15,2) DEFAULT 0.00,
  `formal` int(1) DEFAULT 1,
  `minium_purchase` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblloy_mbs_program`
--

LOCK TABLES `tblloy_mbs_program` WRITE;
/*!40000 ALTER TABLE `tblloy_mbs_program` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblloy_mbs_program` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblloy_mbs_rule`
--

DROP TABLE IF EXISTS `tblloy_mbs_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblloy_mbs_rule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `add_from` int(11) NOT NULL,
  `date_create` date DEFAULT NULL,
  `client_group` int(11) DEFAULT NULL,
  `client` text NOT NULL,
  `loyalty_point_from` decimal(15,0) DEFAULT NULL,
  `loyalty_point_to` decimal(15,0) DEFAULT NULL,
  `card` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblloy_mbs_rule`
--

LOCK TABLES `tblloy_mbs_rule` WRITE;
/*!40000 ALTER TABLE `tblloy_mbs_rule` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblloy_mbs_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblloy_program_detail`
--

DROP TABLE IF EXISTS `tblloy_program_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblloy_program_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mbs_program` int(11) NOT NULL,
  `rel_type` varchar(30) NOT NULL,
  `rel_id` text NOT NULL,
  `percent` int(5) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblloy_program_detail`
--

LOCK TABLES `tblloy_program_detail` WRITE;
/*!40000 ALTER TABLE `tblloy_program_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblloy_program_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblloy_redeem_log`
--

DROP TABLE IF EXISTS `tblloy_redeem_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblloy_redeem_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client` int(11) NOT NULL,
  `cart` int(11) DEFAULT NULL,
  `invoice` int(11) DEFAULT NULL,
  `time` datetime DEFAULT NULL,
  `old_point` decimal(10,0) DEFAULT NULL,
  `new_point` decimal(10,0) DEFAULT NULL,
  `redeep_from` decimal(10,0) DEFAULT NULL,
  `redeep_to` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblloy_redeem_log`
--

LOCK TABLES `tblloy_redeem_log` WRITE;
/*!40000 ALTER TABLE `tblloy_redeem_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblloy_redeem_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblloy_redemp_detail`
--

DROP TABLE IF EXISTS `tblloy_redemp_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblloy_redemp_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `loy_rule` int(11) NOT NULL,
  `rule_name` varchar(200) NOT NULL,
  `point_from` decimal(15,0) DEFAULT NULL,
  `point_to` decimal(15,0) DEFAULT NULL,
  `point_weight` decimal(15,2) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblloy_redemp_detail`
--

LOCK TABLES `tblloy_redemp_detail` WRITE;
/*!40000 ALTER TABLE `tblloy_redemp_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblloy_redemp_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblloy_rule`
--

DROP TABLE IF EXISTS `tblloy_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblloy_rule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(200) NOT NULL,
  `add_from` int(11) NOT NULL,
  `date_create` date DEFAULT NULL,
  `enable` int(2) DEFAULT 0,
  `redeemp_type` varchar(15) DEFAULT NULL,
  `min_poin_to_redeem` decimal(15,0) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `rule_base` varchar(30) DEFAULT NULL,
  `minium_purchase` decimal(15,0) DEFAULT NULL,
  `poin_awarded` decimal(15,0) DEFAULT NULL,
  `purchase_value` decimal(15,0) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `redeem_portal` int(1) DEFAULT 0,
  `redeem_pos` int(1) DEFAULT 0,
  `client_group` int(11) DEFAULT 0,
  `client` text NOT NULL,
  `max_amount_received` int(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblloy_rule`
--

LOCK TABLES `tblloy_rule` WRITE;
/*!40000 ALTER TABLE `tblloy_rule` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblloy_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblloy_rule_detail`
--

DROP TABLE IF EXISTS `tblloy_rule_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblloy_rule_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `loy_rule` int(11) NOT NULL,
  `rel_type` varchar(30) NOT NULL,
  `rel_id` text NOT NULL,
  `loyalty_point` decimal(15,0) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblloy_rule_detail`
--

LOCK TABLES `tblloy_rule_detail` WRITE;
/*!40000 ALTER TABLE `tblloy_rule_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblloy_rule_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblloy_transation`
--

DROP TABLE IF EXISTS `tblloy_transation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblloy_transation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference` varchar(30) NOT NULL,
  `invoice` int(11) DEFAULT NULL,
  `client` int(11) NOT NULL,
  `add_from` int(11) DEFAULT NULL,
  `date_create` datetime DEFAULT NULL,
  `loyalty_point` decimal(15,0) DEFAULT NULL,
  `type` varchar(30) DEFAULT NULL,
  `note` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblloy_transation`
--

LOCK TABLES `tblloy_transation` WRITE;
/*!40000 ALTER TABLE `tblloy_transation` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblloy_transation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmail_attachment`
--

DROP TABLE IF EXISTS `tblmail_attachment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblmail_attachment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `mail_id` int(11) NOT NULL,
  `file_name` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `file_type` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `type` varchar(45) NOT NULL DEFAULT 'inbox',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmail_attachment`
--

LOCK TABLES `tblmail_attachment` WRITE;
/*!40000 ALTER TABLE `tblmail_attachment` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblmail_attachment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmail_inbox`
--

DROP TABLE IF EXISTS `tblmail_inbox`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblmail_inbox` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `from_staff_id` int(11) NOT NULL DEFAULT 0,
  `to_staff_id` int(11) NOT NULL DEFAULT 0,
  `to` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `cc` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `bcc` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `sender_name` varchar(150) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `subject` mediumtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `body` mediumtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `has_attachment` tinyint(1) NOT NULL DEFAULT 0,
  `date_received` datetime NOT NULL,
  `read` tinyint(1) NOT NULL DEFAULT 0,
  `folder` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT 'inbox',
  `stared` tinyint(1) NOT NULL DEFAULT 0,
  `important` tinyint(1) NOT NULL DEFAULT 0,
  `trash` tinyint(1) NOT NULL DEFAULT 0,
  `from_email` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmail_inbox`
--

LOCK TABLES `tblmail_inbox` WRITE;
/*!40000 ALTER TABLE `tblmail_inbox` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblmail_inbox` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmail_outbox`
--

DROP TABLE IF EXISTS `tblmail_outbox`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblmail_outbox` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sender_staff_id` int(11) NOT NULL DEFAULT 0,
  `to` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `cc` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `bcc` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `sender_name` varchar(150) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `subject` mediumtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `body` mediumtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `has_attachment` tinyint(1) NOT NULL DEFAULT 0,
  `date_sent` datetime NOT NULL,
  `stared` tinyint(1) NOT NULL DEFAULT 0,
  `important` tinyint(1) NOT NULL DEFAULT 0,
  `trash` tinyint(1) NOT NULL DEFAULT 0,
  `reply_from_id` int(11) DEFAULT NULL,
  `reply_type` varchar(45) NOT NULL DEFAULT 'inbox',
  `draft` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmail_outbox`
--

LOCK TABLES `tblmail_outbox` WRITE;
/*!40000 ALTER TABLE `tblmail_outbox` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblmail_outbox` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmail_queue`
--

DROP TABLE IF EXISTS `tblmail_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblmail_queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `engine` varchar(40) DEFAULT NULL,
  `email` varchar(191) NOT NULL,
  `cc` mediumtext DEFAULT NULL,
  `bcc` mediumtext DEFAULT NULL,
  `message` longtext NOT NULL,
  `alt_message` longtext DEFAULT NULL,
  `status` enum('pending','sending','sent','failed') DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `headers` mediumtext DEFAULT NULL,
  `attachments` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmail_queue`
--

LOCK TABLES `tblmail_queue` WRITE;
/*!40000 ALTER TABLE `tblmail_queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblmail_queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmanage_leave`
--

DROP TABLE IF EXISTS `tblmanage_leave`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblmanage_leave` (
  `leave_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_staff` int(11) NOT NULL,
  `leave_date` int(11) DEFAULT NULL,
  `leave_year` int(11) DEFAULT NULL,
  `accumulated_leave` int(11) DEFAULT NULL,
  `seniority_leave` int(11) DEFAULT NULL,
  `borrow_leave` int(11) DEFAULT NULL,
  `actual_leave` int(11) DEFAULT NULL,
  `expected_leave` int(11) DEFAULT NULL,
  PRIMARY KEY (`leave_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmanage_leave`
--

LOCK TABLES `tblmanage_leave` WRITE;
/*!40000 ALTER TABLE `tblmanage_leave` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblmanage_leave` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmigrations`
--

DROP TABLE IF EXISTS `tblmigrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblmigrations` (
  `version` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmigrations`
--

LOCK TABLES `tblmigrations` WRITE;
/*!40000 ALTER TABLE `tblmigrations` DISABLE KEYS */;
INSERT INTO `tblmigrations` VALUES
(310);
/*!40000 ALTER TABLE `tblmigrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmilestones`
--

DROP TABLE IF EXISTS `tblmilestones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblmilestones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `description_visible_to_customer` tinyint(1) DEFAULT 0,
  `start_date` date DEFAULT NULL,
  `due_date` date NOT NULL,
  `project_id` int(11) NOT NULL,
  `color` varchar(10) DEFAULT NULL,
  `milestone_order` int(11) NOT NULL DEFAULT 0,
  `datecreated` date NOT NULL,
  `hide_from_customer` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmilestones`
--

LOCK TABLES `tblmilestones` WRITE;
/*!40000 ALTER TABLE `tblmilestones` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblmilestones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmodules`
--

DROP TABLE IF EXISTS `tblmodules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblmodules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module_name` varchar(55) NOT NULL,
  `installed_version` varchar(11) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmodules`
--

LOCK TABLES `tblmodules` WRITE;
/*!40000 ALTER TABLE `tblmodules` DISABLE KEYS */;
INSERT INTO `tblmodules` VALUES
(1,'hr_payroll','1.0.9',1),
(2,'manufacturing','1.0.5',1),
(3,'hr_profile','1.0.9',1),
(4,'account_planning','1.0.0',1),
(5,'mailbox','2.0.1',1),
(6,'timesheets','1.1.9',1),
(7,'accounting','1.3.4',1),
(8,'user_mention','1.0.2',1),
(9,'affiliate_management','1.0.6',1),
(10,'loyalty','1.0.0',1),
(11,'warehouse','1.3.9',1),
(12,'resource_workload','1.0.7',1),
(13,'menu_setup','2.3.0',1),
(14,'perfex_saas','0.3.3',1),
(15,'perfex_office_theme','1.2.6',1);
/*!40000 ALTER TABLE `tblmodules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmrp_bill_of_material_details`
--

DROP TABLE IF EXISTS `tblmrp_bill_of_material_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblmrp_bill_of_material_details` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `bill_of_material_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL COMMENT 'Only Product variant do not get parent Product',
  `product_qty` decimal(15,2) DEFAULT 0.00,
  `unit_id` int(11) DEFAULT NULL,
  `apply_on_variants` text DEFAULT NULL,
  `operation_id` int(11) DEFAULT NULL,
  `display_order` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmrp_bill_of_material_details`
--

LOCK TABLES `tblmrp_bill_of_material_details` WRITE;
/*!40000 ALTER TABLE `tblmrp_bill_of_material_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblmrp_bill_of_material_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmrp_bill_of_materials`
--

DROP TABLE IF EXISTS `tblmrp_bill_of_materials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblmrp_bill_of_materials` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `bom_code` varchar(100) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `product_variant_id` int(11) DEFAULT NULL,
  `product_qty` decimal(15,2) DEFAULT 0.00,
  `unit_id` int(11) DEFAULT NULL,
  `routing_id` int(11) DEFAULT NULL,
  `bom_type` varchar(100) DEFAULT NULL,
  `ready_to_produce` varchar(200) DEFAULT NULL,
  `consumption` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmrp_bill_of_materials`
--

LOCK TABLES `tblmrp_bill_of_materials` WRITE;
/*!40000 ALTER TABLE `tblmrp_bill_of_materials` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblmrp_bill_of_materials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmrp_bom_changes_logs`
--

DROP TABLE IF EXISTS `tblmrp_bom_changes_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblmrp_bom_changes_logs` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `manufacturing_order_id` int(11) DEFAULT NULL,
  `parent_product_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `unit_id` int(11) DEFAULT 0,
  `change_type` text DEFAULT NULL,
  `change_quantity` decimal(15,2) DEFAULT 0.00,
  `created_at` datetime DEFAULT NULL,
  `staff_id` int(11) DEFAULT 0,
  `description` text DEFAULT NULL,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` text DEFAULT NULL COMMENT 'receipt_note, delivery_note',
  `check_availability` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmrp_bom_changes_logs`
--

LOCK TABLES `tblmrp_bom_changes_logs` WRITE;
/*!40000 ALTER TABLE `tblmrp_bom_changes_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblmrp_bom_changes_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmrp_manufacturing_order_details`
--

DROP TABLE IF EXISTS `tblmrp_manufacturing_order_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblmrp_manufacturing_order_details` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `manufacturing_order_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `unit_id` int(11) DEFAULT NULL,
  `qty_to_consume` decimal(15,2) DEFAULT 0.00,
  `qty_reserved` decimal(15,2) DEFAULT 0.00,
  `qty_done` decimal(15,2) DEFAULT 0.00,
  `check_inventory_qty` varchar(10) DEFAULT NULL,
  `warehouse_id` text DEFAULT NULL,
  `lot_number` text DEFAULT NULL,
  `expiry_date` text DEFAULT NULL,
  `available_quantity` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmrp_manufacturing_order_details`
--

LOCK TABLES `tblmrp_manufacturing_order_details` WRITE;
/*!40000 ALTER TABLE `tblmrp_manufacturing_order_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblmrp_manufacturing_order_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmrp_manufacturing_orders`
--

DROP TABLE IF EXISTS `tblmrp_manufacturing_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblmrp_manufacturing_orders` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `manufacturing_order_code` varchar(100) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL COMMENT 'Only Product variant do not get parent Product',
  `product_qty` decimal(15,2) DEFAULT 0.00,
  `unit_id` int(11) DEFAULT NULL,
  `bom_id` int(11) DEFAULT NULL,
  `routing_id` int(11) DEFAULT NULL,
  `date_deadline` datetime DEFAULT NULL,
  `date_plan_from` datetime DEFAULT NULL,
  `date_planned_start` datetime DEFAULT NULL,
  `date_planned_finished` datetime DEFAULT NULL,
  `status` varchar(100) DEFAULT 'draft',
  `material_availability_status` varchar(100) DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `components_warehouse_id` text DEFAULT NULL,
  `finished_products_warehouse_id` text DEFAULT NULL,
  `purchase_request_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmrp_manufacturing_orders`
--

LOCK TABLES `tblmrp_manufacturing_orders` WRITE;
/*!40000 ALTER TABLE `tblmrp_manufacturing_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblmrp_manufacturing_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmrp_option`
--

DROP TABLE IF EXISTS `tblmrp_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblmrp_option` (
  `option_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(200) NOT NULL,
  `option_val` longtext DEFAULT NULL,
  `auto` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`option_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmrp_option`
--

LOCK TABLES `tblmrp_option` WRITE;
/*!40000 ALTER TABLE `tblmrp_option` DISABLE KEYS */;
INSERT INTO `tblmrp_option` VALUES
(1,'bom_prefix','#BOM_',1),
(2,'bom_number','1',1),
(3,'routing_prefix','#RO_',1),
(4,'routing_number','1',1),
(5,'mo_prefix','#MO_',1),
(6,'mo_number','1',1),
(7,'cost_hour','0',1);
/*!40000 ALTER TABLE `tblmrp_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmrp_routing_details`
--

DROP TABLE IF EXISTS `tblmrp_routing_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblmrp_routing_details` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `routing_id` int(11) NOT NULL,
  `operation` varchar(200) DEFAULT NULL,
  `work_center_id` int(11) DEFAULT NULL,
  `duration_computation` varchar(200) DEFAULT NULL,
  `based_on` decimal(15,2) DEFAULT 0.00,
  `default_duration` decimal(15,2) DEFAULT 0.00,
  `start_next_operation` varchar(200) DEFAULT NULL,
  `quantity_process` decimal(15,2) DEFAULT 0.00,
  `description` text DEFAULT NULL,
  `display_order` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmrp_routing_details`
--

LOCK TABLES `tblmrp_routing_details` WRITE;
/*!40000 ALTER TABLE `tblmrp_routing_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblmrp_routing_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmrp_routings`
--

DROP TABLE IF EXISTS `tblmrp_routings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblmrp_routings` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `routing_code` varchar(200) DEFAULT NULL,
  `routing_name` varchar(200) DEFAULT NULL,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmrp_routings`
--

LOCK TABLES `tblmrp_routings` WRITE;
/*!40000 ALTER TABLE `tblmrp_routings` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblmrp_routings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmrp_scrap`
--

DROP TABLE IF EXISTS `tblmrp_scrap`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblmrp_scrap` (
  `ScrapID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `manufacturing_order_id` int(11) NOT NULL,
  `product_id` int(255) NOT NULL,
  `unit_id` int(255) NOT NULL,
  `scrap_type` enum('component','finished_good') NOT NULL,
  `estimated_quantity` decimal(10,2) DEFAULT NULL,
  `actual_quantity` decimal(10,2) NOT NULL,
  `cost_allocation` decimal(10,2) DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`ScrapID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmrp_scrap`
--

LOCK TABLES `tblmrp_scrap` WRITE;
/*!40000 ALTER TABLE `tblmrp_scrap` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblmrp_scrap` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmrp_unit_measure_categories`
--

DROP TABLE IF EXISTS `tblmrp_unit_measure_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblmrp_unit_measure_categories` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `category_name` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmrp_unit_measure_categories`
--

LOCK TABLES `tblmrp_unit_measure_categories` WRITE;
/*!40000 ALTER TABLE `tblmrp_unit_measure_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblmrp_unit_measure_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmrp_work_centers`
--

DROP TABLE IF EXISTS `tblmrp_work_centers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblmrp_work_centers` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `work_center_name` varchar(200) DEFAULT NULL,
  `work_center_code` varchar(200) DEFAULT NULL,
  `working_hours` varchar(200) DEFAULT NULL,
  `time_efficiency` decimal(15,2) DEFAULT 0.00,
  `capacity` decimal(15,2) DEFAULT 0.00,
  `oee_target` decimal(15,2) DEFAULT 0.00,
  `time_start` decimal(15,2) DEFAULT 0.00,
  `time_stop` decimal(15,2) DEFAULT 0.00,
  `costs_hour` decimal(15,2) DEFAULT 0.00,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmrp_work_centers`
--

LOCK TABLES `tblmrp_work_centers` WRITE;
/*!40000 ALTER TABLE `tblmrp_work_centers` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblmrp_work_centers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmrp_work_order_details`
--

DROP TABLE IF EXISTS `tblmrp_work_order_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblmrp_work_order_details` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `work_order_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `to_consume` decimal(15,2) DEFAULT 0.00,
  `reserved` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmrp_work_order_details`
--

LOCK TABLES `tblmrp_work_order_details` WRITE;
/*!40000 ALTER TABLE `tblmrp_work_order_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblmrp_work_order_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmrp_work_order_time_trackings`
--

DROP TABLE IF EXISTS `tblmrp_work_order_time_trackings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblmrp_work_order_time_trackings` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `work_order_id` int(11) NOT NULL,
  `from_date` datetime DEFAULT NULL,
  `to_date` datetime DEFAULT NULL,
  `duration` decimal(15,2) DEFAULT 0.00,
  `staff_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmrp_work_order_time_trackings`
--

LOCK TABLES `tblmrp_work_order_time_trackings` WRITE;
/*!40000 ALTER TABLE `tblmrp_work_order_time_trackings` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblmrp_work_order_time_trackings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmrp_work_orders`
--

DROP TABLE IF EXISTS `tblmrp_work_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblmrp_work_orders` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `manufacturing_order_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `qty_produced` decimal(15,2) DEFAULT 0.00,
  `qty_production` decimal(15,2) DEFAULT 0.00,
  `qty_producing` decimal(15,2) DEFAULT 0.00,
  `unit_id` int(11) DEFAULT NULL,
  `routing_detail_id` int(11) DEFAULT NULL,
  `operation_name` text DEFAULT NULL,
  `work_center_id` int(11) DEFAULT NULL,
  `date_planned_start` datetime DEFAULT NULL,
  `date_planned_finished` datetime DEFAULT NULL,
  `date_start` datetime DEFAULT NULL,
  `date_finished` datetime DEFAULT NULL,
  `duration_expected` decimal(15,2) DEFAULT 0.00,
  `real_duration` decimal(15,2) DEFAULT 0.00,
  `status` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmrp_work_orders`
--

LOCK TABLES `tblmrp_work_orders` WRITE;
/*!40000 ALTER TABLE `tblmrp_work_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblmrp_work_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmrp_working_hour_time_off`
--

DROP TABLE IF EXISTS `tblmrp_working_hour_time_off`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblmrp_working_hour_time_off` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `working_hour_id` int(11) NOT NULL,
  `reason` varchar(200) DEFAULT NULL,
  `starting_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmrp_working_hour_time_off`
--

LOCK TABLES `tblmrp_working_hour_time_off` WRITE;
/*!40000 ALTER TABLE `tblmrp_working_hour_time_off` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblmrp_working_hour_time_off` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmrp_working_hour_times`
--

DROP TABLE IF EXISTS `tblmrp_working_hour_times`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblmrp_working_hour_times` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `working_hour_id` int(11) NOT NULL,
  `working_hour_name` varchar(200) DEFAULT NULL,
  `day_of_week` varchar(100) DEFAULT NULL,
  `day_period` varchar(100) DEFAULT NULL,
  `work_from` time DEFAULT NULL,
  `work_to` time DEFAULT NULL,
  `starting_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmrp_working_hour_times`
--

LOCK TABLES `tblmrp_working_hour_times` WRITE;
/*!40000 ALTER TABLE `tblmrp_working_hour_times` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblmrp_working_hour_times` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmrp_working_hours`
--

DROP TABLE IF EXISTS `tblmrp_working_hours`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblmrp_working_hours` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `working_hour_name` varchar(200) DEFAULT NULL,
  `hours_per_day` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmrp_working_hours`
--

LOCK TABLES `tblmrp_working_hours` WRITE;
/*!40000 ALTER TABLE `tblmrp_working_hours` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblmrp_working_hours` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblnewsfeed_comment_likes`
--

DROP TABLE IF EXISTS `tblnewsfeed_comment_likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblnewsfeed_comment_likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `postid` int(11) NOT NULL,
  `commentid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `dateliked` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblnewsfeed_comment_likes`
--

LOCK TABLES `tblnewsfeed_comment_likes` WRITE;
/*!40000 ALTER TABLE `tblnewsfeed_comment_likes` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblnewsfeed_comment_likes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblnewsfeed_post_comments`
--

DROP TABLE IF EXISTS `tblnewsfeed_post_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblnewsfeed_post_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` mediumtext DEFAULT NULL,
  `userid` int(11) NOT NULL,
  `postid` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblnewsfeed_post_comments`
--

LOCK TABLES `tblnewsfeed_post_comments` WRITE;
/*!40000 ALTER TABLE `tblnewsfeed_post_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblnewsfeed_post_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblnewsfeed_post_likes`
--

DROP TABLE IF EXISTS `tblnewsfeed_post_likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblnewsfeed_post_likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `postid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `dateliked` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblnewsfeed_post_likes`
--

LOCK TABLES `tblnewsfeed_post_likes` WRITE;
/*!40000 ALTER TABLE `tblnewsfeed_post_likes` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblnewsfeed_post_likes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblnewsfeed_posts`
--

DROP TABLE IF EXISTS `tblnewsfeed_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblnewsfeed_posts` (
  `postid` int(11) NOT NULL AUTO_INCREMENT,
  `creator` int(11) NOT NULL,
  `datecreated` datetime NOT NULL,
  `visibility` varchar(100) NOT NULL,
  `content` mediumtext NOT NULL,
  `pinned` int(11) NOT NULL,
  `datepinned` datetime DEFAULT NULL,
  PRIMARY KEY (`postid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblnewsfeed_posts`
--

LOCK TABLES `tblnewsfeed_posts` WRITE;
/*!40000 ALTER TABLE `tblnewsfeed_posts` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblnewsfeed_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblnotes`
--

DROP TABLE IF EXISTS `tblnotes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblnotes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `date_contacted` datetime DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblnotes`
--

LOCK TABLES `tblnotes` WRITE;
/*!40000 ALTER TABLE `tblnotes` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblnotes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblnotifications`
--

DROP TABLE IF EXISTS `tblnotifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblnotifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `isread` int(11) NOT NULL DEFAULT 0,
  `isread_inline` tinyint(1) NOT NULL DEFAULT 0,
  `date` datetime NOT NULL,
  `description` mediumtext NOT NULL,
  `fromuserid` int(11) NOT NULL,
  `fromclientid` int(11) NOT NULL DEFAULT 0,
  `from_fullname` varchar(100) NOT NULL,
  `touserid` int(11) NOT NULL,
  `fromcompany` int(11) DEFAULT NULL,
  `link` longtext DEFAULT NULL,
  `additional_data` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblnotifications`
--

LOCK TABLES `tblnotifications` WRITE;
/*!40000 ALTER TABLE `tblnotifications` DISABLE KEYS */;
INSERT INTO `tblnotifications` VALUES
(1,1,0,'2025-06-26 07:01:51','perfex_saas_not_customer_create_instance',0,1,'Dayanand yadav',1,NULL,'clients/client/1','a:1:{i:0;s:6:\"FECUNI\";}'),
(2,1,0,'2025-06-27 10:57:12','perfex_saas_not_customer_create_instance',0,2,'Dayanand Sweden',1,NULL,'clients/client/2','a:1:{i:0;s:32:\"Minera software Solution ,Sweden\";}'),
(3,1,0,'2025-06-27 11:59:33','perfex_saas_not_customer_create_instance',0,3,'Dayanand yadav',1,NULL,'clients/client/3','a:1:{i:0;s:10:\"INDIA TECH\";}'),
(4,1,0,'2025-06-27 13:12:22','perfex_saas_not_customer_create_instance',0,4,'Dayanand yadav',1,NULL,'clients/client/4','a:1:{i:0;s:4:\"Audi\";}'),
(5,0,0,'2025-07-01 17:29:51','perfex_saas_not_customer_create_instance',0,5,'Vishal Shankar',1,NULL,'clients/client/5','a:1:{i:0;s:4:\"tata\";}');
/*!40000 ALTER TABLE `tblnotifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbloptions`
--

DROP TABLE IF EXISTS `tbloptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbloptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `value` longtext NOT NULL,
  `autoload` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=753 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbloptions`
--

LOCK TABLES `tbloptions` WRITE;
/*!40000 ALTER TABLE `tbloptions` DISABLE KEYS */;
INSERT INTO `tbloptions` VALUES
(1,'dateformat','Y-m-d|%Y-%m-%d',1),
(2,'companyname','',1),
(3,'services','1',1),
(4,'maximum_allowed_ticket_attachments','4',1),
(5,'ticket_attachments_file_extensions','.jpg,.png,.pdf,.doc,.zip,.rar',1),
(6,'staff_access_only_assigned_departments','1',1),
(7,'use_knowledge_base','1',1),
(8,'smtp_email','shreyasharma@techdotbit.com',1),
(9,'smtp_password','0a26136a71885c0ec40fbe909e05aabb32fcffce3c4748d3f352b421117900419a409e2a4ffdfaaa87e2d5b9d575792fe6a0510ae3beb78252eebd5d4b619625qNOn0Ajr+E3EF8mkdSB/l6PcvBgQ1sVFcOERZPFwOS4=',1),
(10,'company_info_format','{company_name}<br />\r\n      {address}<br />\r\n      {city} {state}<br />\r\n      {country_code} {zip_code}<br />\r\n      {vat_number_with_label}',0),
(11,'smtp_port','587',1),
(12,'smtp_host','smtp.hostinger.com',1),
(13,'smtp_email_charset','utf-8',1),
(14,'default_timezone','Asia/Kolkata',1),
(15,'clients_default_theme','perfex',1),
(16,'company_logo','',1),
(17,'tables_pagination_limit','25',1),
(18,'main_domain','',1),
(19,'allow_registration','1',1),
(20,'knowledge_base_without_registration','1',1),
(21,'email_signature','DOT ONE TEAM',1),
(22,'default_staff_role','1',1),
(23,'newsfeed_maximum_files_upload','10',1),
(24,'contract_expiration_before','4',1),
(25,'invoice_prefix','INV-',1),
(26,'decimal_separator','.',1),
(27,'thousand_separator',',',1),
(28,'invoice_company_name','',1),
(29,'invoice_company_address','',1),
(30,'invoice_company_city','',1),
(31,'invoice_company_country_code','',1),
(32,'invoice_company_postal_code','',1),
(33,'invoice_company_phonenumber','',1),
(34,'view_invoice_only_logged_in','0',1),
(35,'invoice_number_format','1',1),
(36,'next_invoice_number','2',0),
(37,'active_language','english',1),
(38,'invoice_number_decrement_on_delete','1',1),
(39,'automatically_send_invoice_overdue_reminder_after','1',1),
(40,'automatically_resend_invoice_overdue_reminder_after','3',1),
(41,'expenses_auto_operations_hour','21',1),
(42,'delete_only_on_last_invoice','1',1),
(43,'delete_only_on_last_estimate','1',1),
(44,'create_invoice_from_recurring_only_on_paid_invoices','0',1),
(45,'allow_payment_amount_to_be_modified','1',1),
(46,'rtl_support_client','0',1),
(47,'limit_top_search_bar_results_to','10',1),
(48,'estimate_prefix','EST-',1),
(49,'next_estimate_number','1',0),
(50,'estimate_number_decrement_on_delete','1',1),
(51,'estimate_number_format','1',1),
(52,'estimate_auto_convert_to_invoice_on_client_accept','1',1),
(53,'exclude_estimate_from_client_area_with_draft_status','1',1),
(54,'rtl_support_admin','0',1),
(55,'last_cron_run','1751173203',1),
(56,'show_sale_agent_on_estimates','1',1),
(57,'show_sale_agent_on_invoices','1',1),
(58,'predefined_terms_invoice','',1),
(59,'predefined_terms_estimate','',1),
(60,'default_task_priority','2',1),
(61,'dropbox_app_key','',1),
(62,'show_expense_reminders_on_calendar','1',1),
(63,'only_show_contact_tickets','1',1),
(64,'predefined_clientnote_invoice','',1),
(65,'predefined_clientnote_estimate','',1),
(66,'custom_pdf_logo_image_url','',1),
(67,'favicon','',1),
(68,'invoice_due_after','30',1),
(69,'google_api_key','',1),
(70,'google_calendar_main_calendar','',1),
(71,'default_tax','a:0:{}',1),
(72,'show_invoices_on_calendar','1',1),
(73,'show_estimates_on_calendar','1',1),
(74,'show_contracts_on_calendar','1',1),
(75,'show_tasks_on_calendar','1',1),
(76,'show_customer_reminders_on_calendar','1',1),
(77,'output_client_pdfs_from_admin_area_in_client_language','0',1),
(78,'show_lead_reminders_on_calendar','1',1),
(79,'send_estimate_expiry_reminder_before','4',1),
(80,'leads_default_source','',1),
(81,'leads_default_status','',1),
(82,'proposal_expiry_reminder_enabled','1',1),
(83,'send_proposal_expiry_reminder_before','4',1),
(84,'default_contact_permissions','a:8:{i:0;s:1:\"1\";i:1;s:1:\"2\";i:2;s:1:\"3\";i:3;s:1:\"4\";i:4;s:1:\"5\";i:5;s:1:\"6\";i:6;s:6:\"311301\";i:7;s:6:\"311302\";}',1),
(85,'pdf_logo_width','150',1),
(86,'access_tickets_to_none_staff_members','0',1),
(87,'customer_default_country','102',1),
(88,'view_estimate_only_logged_in','0',1),
(89,'show_status_on_pdf_ei','1',1),
(90,'email_piping_only_replies','0',1),
(91,'email_piping_only_registered','0',1),
(92,'default_view_calendar','dayGridMonth',1),
(93,'email_piping_default_priority','2',1),
(94,'total_to_words_lowercase','0',1),
(95,'show_tax_per_item','1',1),
(96,'total_to_words_enabled','0',1),
(97,'receive_notification_on_new_ticket','1',0),
(98,'autoclose_tickets_after','0',1),
(99,'media_max_file_size_upload','10',1),
(100,'client_staff_add_edit_delete_task_comments_first_hour','0',1),
(101,'show_projects_on_calendar','1',1),
(102,'leads_kanban_limit','50',1),
(103,'tasks_reminder_notification_before','2',1),
(104,'pdf_font','freesans',1),
(105,'pdf_table_heading_color','#323a45',1),
(106,'pdf_table_heading_text_color','#ffffff',1),
(107,'pdf_font_size','10',1),
(108,'default_leads_kanban_sort','leadorder',1),
(109,'default_leads_kanban_sort_type','asc',1),
(110,'allowed_files','.png,.jpg,.pdf,.doc,.docx,.xls,.xlsx,.zip,.rar,.txt',1),
(111,'show_all_tasks_for_project_member','1',1),
(112,'email_protocol','smtp',1),
(113,'calendar_first_day','0',1),
(114,'recaptcha_secret_key','',1),
(115,'show_help_on_setup_menu','1',1),
(116,'show_proposals_on_calendar','1',1),
(117,'smtp_encryption','tls',1),
(118,'recaptcha_site_key','',1),
(119,'smtp_username','shreyasharma@techdotbit.com',1),
(120,'auto_stop_tasks_timers_on_new_timer','1',1),
(121,'notification_when_customer_pay_invoice','1',1),
(122,'calendar_invoice_color','#FF6F00',1),
(123,'calendar_estimate_color','#FF6F00',1),
(124,'calendar_proposal_color','#84c529',1),
(125,'new_task_auto_assign_current_member','1',1),
(126,'calendar_reminder_color','#03A9F4',1),
(127,'calendar_contract_color','#B72974',1),
(128,'calendar_project_color','#B72974',1),
(129,'update_info_message','',1),
(130,'show_estimate_reminders_on_calendar','1',1),
(131,'show_invoice_reminders_on_calendar','1',1),
(132,'show_proposal_reminders_on_calendar','1',1),
(133,'proposal_due_after','7',1),
(134,'allow_customer_to_change_ticket_status','0',1),
(135,'lead_lock_after_convert_to_customer','0',1),
(136,'default_proposals_pipeline_sort','pipeline_order',1),
(137,'default_proposals_pipeline_sort_type','asc',1),
(138,'default_estimates_pipeline_sort','pipeline_order',1),
(139,'default_estimates_pipeline_sort_type','asc',1),
(140,'use_recaptcha_customers_area','0',1),
(141,'remove_decimals_on_zero','0',1),
(142,'remove_tax_name_from_item_table','0',1),
(143,'pdf_format_invoice','A4-PORTRAIT',1),
(144,'pdf_format_estimate','A4-PORTRAIT',1),
(145,'pdf_format_proposal','A4-PORTRAIT',1),
(146,'pdf_format_payment','A4-PORTRAIT',1),
(147,'pdf_format_contract','A4-PORTRAIT',1),
(148,'swap_pdf_info','0',1),
(149,'exclude_invoice_from_client_area_with_draft_status','1',1),
(150,'cron_has_run_from_cli','1',1),
(151,'hide_cron_is_required_message','0',0),
(152,'auto_assign_customer_admin_after_lead_convert','1',1),
(153,'show_transactions_on_invoice_pdf','1',1),
(154,'show_pay_link_to_invoice_pdf','1',1),
(155,'tasks_kanban_limit','50',1),
(156,'purchase_key','',1),
(157,'estimates_pipeline_limit','50',1),
(158,'proposals_pipeline_limit','50',1),
(159,'proposal_number_prefix','PRO-',1),
(160,'number_padding_prefixes','6',1),
(161,'show_page_number_on_pdf','0',1),
(162,'calendar_events_limit','4',1),
(163,'show_setup_menu_item_only_on_hover','0',1),
(164,'company_requires_vat_number_field','1',1),
(165,'company_is_required','1',1),
(166,'allow_contact_to_delete_files','0',1),
(167,'company_vat','',1),
(168,'di','1750847029',1),
(169,'invoice_auto_operations_hour','21',1),
(170,'use_minified_files','1',1),
(171,'only_own_files_contacts','0',1),
(172,'allow_primary_contact_to_view_edit_billing_and_shipping','0',1),
(173,'estimate_due_after','7',1),
(174,'staff_members_open_tickets_to_all_contacts','1',1),
(175,'time_format','24',1),
(176,'delete_activity_log_older_then','1',1),
(177,'disable_language','0',1),
(178,'company_state','',1),
(179,'email_header','DOT ONE TEAM',1),
(180,'show_pdf_signature_invoice','1',0),
(181,'show_pdf_signature_estimate','1',0),
(182,'signature_image','',0),
(183,'email_footer','DOT ONE TEAM',1),
(184,'exclude_proposal_from_client_area_with_draft_status','1',1),
(185,'pusher_app_key','',1),
(186,'pusher_app_secret','',1),
(187,'pusher_app_id','',1),
(188,'pusher_realtime_notifications','0',1),
(189,'pdf_format_statement','A4-PORTRAIT',1),
(190,'pusher_cluster','',1),
(191,'show_table_export_button','to_all',1),
(192,'allow_staff_view_proposals_assigned','1',1),
(193,'show_cloudflare_notice','1',0),
(194,'task_modal_class','modal-lg',1),
(195,'lead_modal_class','modal-lg',1),
(196,'show_timesheets_overview_all_members_notice_admins','0',1),
(197,'desktop_notifications','0',1),
(198,'hide_notified_reminders_from_calendar','1',0),
(199,'customer_info_format','{company_name}<br />\r\n      {street}<br />\r\n      {city} {state}<br />\r\n      {country_code} {zip_code}<br />\r\n      {vat_number_with_label}',0),
(200,'timer_started_change_status_in_progress','1',0),
(201,'default_ticket_reply_status','3',1),
(202,'default_task_status','auto',1),
(203,'email_queue_skip_with_attachments','1',1),
(204,'email_queue_enabled','0',1),
(205,'last_email_queue_retry','1751173203',1),
(206,'auto_dismiss_desktop_notifications_after','0',1),
(207,'proposal_info_format','{proposal_to}<br />\r\n      {address}<br />\r\n      {city} {state}<br />\r\n      {country_code} {zip_code}<br />\r\n      {phone}<br />\r\n      {email}',0),
(208,'ticket_replies_order','asc',1),
(209,'new_recurring_invoice_action','generate_and_send',0),
(210,'bcc_emails','',0),
(211,'email_templates_language_checks','',0),
(212,'proposal_accept_identity_confirmation','1',0),
(213,'estimate_accept_identity_confirmation','1',0),
(214,'new_task_auto_follower_current_member','0',1),
(215,'task_biillable_checked_on_creation','1',1),
(216,'predefined_clientnote_credit_note','',1),
(217,'predefined_terms_credit_note','',1),
(218,'next_credit_note_number','1',1),
(219,'credit_note_prefix','CN-',1),
(220,'credit_note_number_decrement_on_delete','1',1),
(221,'pdf_format_credit_note','A4-PORTRAIT',1),
(222,'show_pdf_signature_credit_note','1',0),
(223,'show_credit_note_reminders_on_calendar','1',1),
(224,'show_amount_due_on_invoice','1',1),
(225,'show_total_paid_on_invoice','1',1),
(226,'show_credits_applied_on_invoice','1',1),
(227,'staff_members_create_inline_lead_status','1',1),
(228,'staff_members_create_inline_customer_groups','1',1),
(229,'staff_members_create_inline_ticket_services','1',1),
(230,'staff_members_save_tickets_predefined_replies','1',1),
(231,'staff_members_create_inline_contract_types','1',1),
(232,'staff_members_create_inline_expense_categories','1',1),
(233,'show_project_on_credit_note','1',1),
(234,'proposals_auto_operations_hour','21',1),
(235,'estimates_auto_operations_hour','21',1),
(236,'contracts_auto_operations_hour','21',1),
(237,'credit_note_number_format','1',1),
(238,'allow_non_admin_members_to_import_leads','0',1),
(239,'e_sign_legal_text','By clicking on \"Sign\", I consent to be legally bound by this electronic representation of my signature.',1),
(240,'show_pdf_signature_contract','1',1),
(241,'view_contract_only_logged_in','0',1),
(242,'show_subscriptions_in_customers_area','1',1),
(243,'calendar_only_assigned_tasks','0',1),
(244,'after_subscription_payment_captured','send_invoice_and_receipt',1),
(245,'mail_engine','phpmailer',1),
(246,'gdpr_enable_terms_and_conditions','0',1),
(247,'privacy_policy','',1),
(248,'terms_and_conditions','',1),
(249,'gdpr_enable_terms_and_conditions_lead_form','0',1),
(250,'gdpr_enable_terms_and_conditions_ticket_form','0',1),
(251,'gdpr_contact_enable_right_to_be_forgotten','0',1),
(252,'show_gdpr_in_customers_menu','1',1),
(253,'show_gdpr_link_in_footer','1',1),
(254,'enable_gdpr','0',1),
(255,'gdpr_on_forgotten_remove_invoices_credit_notes','0',1),
(256,'gdpr_on_forgotten_remove_estimates','0',1),
(257,'gdpr_enable_consent_for_contacts','0',1),
(258,'gdpr_consent_public_page_top_block','',1),
(259,'gdpr_page_top_information_block','',1),
(260,'gdpr_enable_lead_public_form','0',1),
(261,'gdpr_show_lead_custom_fields_on_public_form','0',1),
(262,'gdpr_lead_attachments_on_public_form','0',1),
(263,'gdpr_enable_consent_for_leads','0',1),
(264,'gdpr_lead_enable_right_to_be_forgotten','0',1),
(265,'allow_staff_view_invoices_assigned','1',1),
(266,'gdpr_data_portability_leads','0',1),
(267,'gdpr_lead_data_portability_allowed','',1),
(268,'gdpr_contact_data_portability_allowed','',1),
(269,'gdpr_data_portability_contacts','0',1),
(270,'allow_staff_view_estimates_assigned','1',1),
(271,'gdpr_after_lead_converted_delete','0',1),
(272,'gdpr_show_terms_and_conditions_in_footer','0',1),
(273,'save_last_order_for_tables','0',1),
(274,'company_logo_dark','',1),
(275,'customers_register_require_confirmation','0',1),
(276,'allow_non_admin_staff_to_delete_ticket_attachments','0',1),
(277,'receive_notification_on_new_ticket_replies','1',0),
(278,'google_client_id','',1),
(279,'enable_google_picker','1',1),
(280,'show_ticket_reminders_on_calendar','1',1),
(281,'ticket_import_reply_only','0',1),
(282,'visible_customer_profile_tabs','a:19:{s:7:\"profile\";b:0;s:8:\"contacts\";b:0;s:5:\"notes\";b:1;s:9:\"statement\";b:1;s:8:\"invoices\";b:1;s:8:\"payments\";b:1;s:9:\"proposals\";b:1;s:12:\"credit_notes\";b:1;s:9:\"estimates\";b:1;s:13:\"subscriptions\";b:1;s:8:\"expenses\";b:1;s:9:\"contracts\";b:1;s:8:\"projects\";b:1;s:5:\"tasks\";b:1;s:7:\"tickets\";b:1;s:11:\"attachments\";b:1;s:5:\"vault\";b:1;s:9:\"reminders\";b:1;s:3:\"map\";b:1;}',0),
(283,'show_project_on_invoice','1',1),
(284,'show_project_on_estimate','1',1),
(285,'staff_members_create_inline_lead_source','1',1),
(286,'lead_unique_validation','[\"email\"]',1),
(287,'last_upgrade_copy_data','',1),
(288,'custom_js_admin_scripts','',1),
(289,'custom_js_customer_scripts','0',1),
(290,'stripe_webhook_id','',1),
(291,'stripe_webhook_signing_secret','',1),
(292,'stripe_ideal_webhook_id','',1),
(293,'stripe_ideal_webhook_signing_secret','',1),
(294,'show_php_version_notice','1',0),
(295,'recaptcha_ignore_ips','',1),
(296,'show_task_reminders_on_calendar','1',1),
(297,'customer_settings','true',1),
(298,'tasks_reminder_notification_hour','21',1),
(299,'allow_primary_contact_to_manage_other_contacts','0',1),
(300,'items_table_amounts_exclude_currency_symbol','1',1),
(301,'round_off_task_timer_option','0',1),
(302,'round_off_task_timer_time','5',1),
(303,'bitly_access_token','',1),
(304,'enable_support_menu_badges','0',1),
(305,'attach_invoice_to_payment_receipt_email','0',1),
(306,'invoice_due_notice_before','2',1),
(307,'invoice_due_notice_resend_after','0',1),
(308,'_leads_settings','true',1),
(309,'show_estimate_request_in_customers_area','0',1),
(310,'gdpr_enable_terms_and_conditions_estimate_request_form','0',1),
(311,'identification_key','19730308581750866216685c1928b9351',1),
(312,'automatically_stop_task_timer_after_hours','8',1),
(313,'automatically_assign_ticket_to_first_staff_responding','0',1),
(314,'reminder_for_completed_but_not_billed_tasks','0',1),
(315,'staff_notify_completed_but_not_billed_tasks','',1),
(316,'reminder_for_completed_but_not_billed_tasks_days','',1),
(317,'tasks_reminder_notification_last_notified_day','',1),
(318,'staff_related_ticket_notification_to_assignee_only','0',1),
(319,'show_pdf_signature_proposal','1',1),
(320,'enable_honeypot_spam_validation','1',1),
(321,'microsoft_mail_client_id','',1),
(322,'microsoft_mail_client_secret','',1),
(323,'microsoft_mail_azure_tenant_id','',1),
(324,'google_mail_client_id','',1),
(325,'google_mail_client_secret','',1),
(326,'google_mail_refresh_token','',1),
(327,'microsoft_mail_refresh_token','',1),
(328,'automatically_set_logged_in_staff_sales_agent','1',1),
(329,'contract_sign_reminder_every_days','0',1),
(330,'last_updated_date','',1),
(331,'v310_incompatible_tables','[]',1),
(332,'upgraded_from_version','',0),
(333,'sms_clickatell_api_key','',1),
(334,'sms_clickatell_active','0',1),
(335,'sms_clickatell_initialized','1',1),
(336,'sms_msg91_sender_id','',1),
(337,'sms_msg91_api_type','api',1),
(338,'sms_msg91_auth_key','',1),
(339,'sms_msg91_active','0',1),
(340,'sms_msg91_initialized','1',1),
(341,'sms_twilio_account_sid','',1),
(342,'sms_twilio_auth_token','',1),
(343,'sms_twilio_phone_number','',1),
(344,'sms_twilio_sender_id','',1),
(345,'sms_twilio_active','0',1),
(346,'sms_twilio_initialized','1',1),
(347,'cr_date_cronjob_currency_rates','2025-06-28',1),
(348,'cr_automatically_get_currency_rate','1',1),
(349,'cr_global_amount_expiration','0',1),
(350,'hr_profile_hide_menu','1',1),
(351,'account_planning_enabled','1',1),
(352,'mailbox_verification_id','MTIzNA==',1),
(353,'mailbox_last_verification','1750867445',1),
(354,'mailbox_product_token','product_token',1),
(355,'mailbox_enabled','1',1),
(356,'mailbox_imap_server','',1),
(357,'mailbox_encryption','',1),
(358,'mailbox_folder_scan','Inbox',1),
(359,'mailbox_check_every','3',1),
(360,'mailbox_only_loop_on_unseen_emails','1',1),
(361,'acc_first_month_of_financial_year','January',1),
(362,'acc_first_month_of_tax_year','same_as_financial_year',1),
(363,'acc_accounting_method','accrual',1),
(364,'acc_close_the_books','0',1),
(365,'acc_allow_changes_after_viewing','allow_changes_after_viewing_a_warning',1),
(366,'acc_close_book_password','',1),
(367,'acc_close_book_passwordr','',1),
(368,'acc_enable_account_numbers','0',1),
(369,'acc_show_account_numbers','0',1),
(370,'acc_closing_date','',1),
(371,'acc_add_default_account','1',1),
(372,'acc_add_default_account_new','0',1),
(373,'acc_invoice_automatic_conversion','1',1),
(374,'acc_payment_automatic_conversion','1',1),
(375,'acc_credit_note_automatic_conversion','1',1),
(376,'acc_credit_note_refund_automatic_conversion','1',1),
(377,'acc_expense_automatic_conversion','1',1),
(378,'acc_tax_automatic_conversion','1',1),
(379,'acc_invoice_payment_account','66',1),
(380,'acc_invoice_deposit_to','1',1),
(381,'acc_payment_payment_account','1',1),
(382,'acc_payment_deposit_to','13',1),
(383,'acc_credit_note_payment_account','1',1),
(384,'acc_credit_note_deposit_to','13',1),
(385,'acc_credit_note_refund_payment_account','1',1),
(386,'acc_credit_note_refund_deposit_to','13',1),
(387,'acc_expense_payment_account','13',1),
(388,'acc_expense_deposit_to','80',1),
(389,'acc_tax_payment_account','29',1),
(390,'acc_tax_deposit_to','1',1),
(391,'acc_expense_tax_payment_account','13',1),
(392,'acc_expense_tax_deposit_to','29',1),
(393,'acc_active_payment_mode_mapping','1',1),
(394,'acc_active_expense_category_mapping','1',1),
(395,'acc_payment_expense_automatic_conversion','1',1),
(396,'acc_payment_sale_automatic_conversion','1',1),
(397,'acc_expense_payment_payment_account','1',1),
(398,'acc_expense_payment_deposit_to','1',1),
(399,'acc_pl_total_insurance_automatic_conversion','1',1),
(400,'acc_pl_total_insurance_payment_account','13',1),
(401,'acc_pl_total_insurance_deposit_to','32',1),
(402,'acc_pl_tax_paye_automatic_conversion','1',1),
(403,'acc_pl_tax_paye_payment_account','13',1),
(404,'acc_pl_tax_paye_deposit_to','28',1),
(405,'acc_pl_net_pay_automatic_conversion','1',1),
(406,'acc_pl_net_pay_payment_account','13',1),
(407,'acc_pl_net_pay_deposit_to','56',1),
(408,'acc_wh_stock_import_automatic_conversion','1',1),
(409,'acc_wh_stock_import_payment_account','87',1),
(410,'acc_wh_stock_import_deposit_to','37',1),
(411,'acc_wh_stock_export_automatic_conversion','1',1),
(412,'acc_wh_stock_export_payment_account','37',1),
(413,'acc_wh_stock_export_deposit_to','1',1),
(414,'acc_wh_loss_adjustment_automatic_conversion','1',1),
(415,'acc_wh_decrease_payment_account','37',1),
(416,'acc_wh_decrease_deposit_to','1',1),
(417,'acc_wh_increase_payment_account','87',1),
(418,'acc_wh_increase_deposit_to','37',1),
(419,'acc_wh_opening_stock_automatic_conversion','1',1),
(420,'acc_wh_opening_stock_payment_account','88',1),
(421,'acc_wh_opening_stock_deposit_to','37',1),
(422,'acc_pur_order_automatic_conversion','1',1),
(423,'acc_pur_order_payment_account','13',1),
(424,'acc_pur_order_deposit_to','80',1),
(425,'acc_pur_payment_automatic_conversion','1',1),
(426,'acc_pur_payment_payment_account','16',1),
(427,'acc_pur_payment_deposit_to','37',1),
(428,'acc_mrp_manufacturing_order_automatic_conversion','1',1),
(429,'acc_mrp_material_cost_payment_account','13',1),
(430,'acc_mrp_material_cost_deposit_to','45',1),
(431,'acc_mrp_labour_cost_payment_account','13',1),
(432,'acc_mrp_labour_cost_deposit_to','18',1),
(433,'acc_pur_order_return_automatic_conversion','1',1),
(434,'acc_pur_order_return_payment_account','80',1),
(435,'acc_pur_order_return_deposit_to','13',1),
(436,'acc_pur_refund_automatic_conversion','1',1),
(437,'acc_pur_refund_payment_account','37',1),
(438,'acc_pur_refund_deposit_to','16',1),
(439,'acc_pur_invoice_automatic_conversion','1',1),
(440,'acc_pur_invoice_payment_account','13',1),
(441,'acc_pur_invoice_deposit_to','80',1),
(442,'acc_omni_sales_order_return_automatic_conversion','1',1),
(443,'acc_omni_sales_order_return_payment_account','1',1),
(444,'acc_omni_sales_order_return_deposit_to','66',1),
(445,'acc_omni_sales_refund_automatic_conversion','1',1),
(446,'acc_omni_sales_refund_payment_account','13',1),
(447,'acc_omni_sales_refund_deposit_to','1',1),
(448,'acc_routing_number_icon_a','a',1),
(449,'acc_routing_number_icon_b','a',1),
(450,'acc_bank_account_icon_a','a',1),
(451,'acc_bank_account_icon_b','a',1),
(452,'acc_current_check_no_icon_a','a',1),
(453,'acc_current_check_no_icon_b','a',1),
(454,'acc_check_type','type_1',1),
(455,'acc_fe_asset_automatic_conversion','1',1),
(456,'acc_fe_asset_payment_account','13',1),
(457,'acc_fe_asset_deposit_to','1',1),
(458,'acc_fe_license_automatic_conversion','1',1),
(459,'acc_fe_license_payment_account','13',1),
(460,'acc_fe_license_deposit_to','1',1),
(461,'acc_fe_consumable_automatic_conversion','1',1),
(462,'acc_fe_consumable_payment_account','13',1),
(463,'acc_fe_consumable_deposit_to','1',1),
(464,'acc_fe_component_automatic_conversion','1',1),
(465,'acc_fe_component_payment_account','13',1),
(466,'acc_fe_component_deposit_to','1',1),
(467,'acc_fe_maintenance_automatic_conversion','1',1),
(468,'acc_fe_maintenance_payment_account','13',1),
(469,'acc_fe_maintenance_deposit_to','1',1),
(470,'acc_fe_depreciation_automatic_conversion','1',1),
(471,'acc_fe_depreciation_payment_account','13',1),
(472,'acc_fe_depreciation_deposit_to','1',1),
(473,'acc_wh_stock_export_profit_payment_account','66',1),
(474,'acc_wh_stock_export_profit_deposit_to','1',1),
(475,'update_bank_account_v124','1',1),
(476,'update_income_statement_modifications_v125','1',1),
(477,'acc_enable_income_statement_modifications','0',1),
(478,'acc_invoice_discount_payment_account','1',1),
(479,'acc_invoice_discount_deposit_to','19',1),
(480,'acc_pur_tax_automatic_conversion','1',1),
(481,'acc_pur_tax_payment_account','13',1),
(482,'acc_pur_tax_deposit_to','29',1),
(483,'acc_wh_stock_import_return_automatic_conversion','0',1),
(484,'acc_wh_stock_import_return_payment_account','1',1),
(485,'acc_wh_stock_import_return_deposit_to','37',1),
(486,'acc_wh_stock_export_profit_automatic_conversion','1',1),
(487,'affiliate_management_auto_approve_signup','1',1),
(488,'affiliate_management_save_referral_client_info','1',1),
(489,'affiliate_management_groups','{\"general\":{\"name\":\"General\",\"settings\":{\"affiliate_management_commission_enabled\":\"1\",\"affiliate_management_commission_rule\":\"first-invoice-payment\",\"affiliate_management_commission_type\":\"percent\",\"affiliate_management_commission_amount\":\"15\",\"affiliate_management_commission_cap\":\"-1\",\"affiliate_management_payout_min\":\"50\",\"affiliate_management_payout_methods\":\"bank, paypal\"}}}',1),
(490,'affiliate_management_join_page_content','\n                    <div class=\"jumbotron text-center\">\n                        <h1>Welcome to Our Affiliate Program!</h1>\n                        <p>Join us and start earning today.</p>\n                        <a href=\"{SIGNUP_LINK}\" class=\"btn btn-primary btn-lg\">Join Now</a>\n                    </div>\n                    <div id=\"referral\" class=\"row\">\n                        <div class=\"col-md-6\">\n                            <h2>Referral Program</h2>\n                            <p>Join our referral program and start earning rewards!</p>\n                            <p>Earn {COMMISSION_AMOUNT} on every referral\'s first payment.</p>\n                            <p>Minimum payout is {MIN_PAYOUT}.</p>\n                        </div>\n                        <div class=\"col-md-6\">\n                            <h2>How It Works</h2>\n                            <p>1. Register for the affiliate program.</p>\n                            <p>2. Share your referral link with friends and colleagues.</p>\n                            <p>3. When someone signs up using your link and makes their first payment, you earn {COMMISSION_AMOUNT}.</p>\n                            <p>4. Once your earnings reach {MIN_PAYOUT}, you can request a payout.</p>\n                        </div>\n                    </div>\n                ',1),
(491,'affiliate_management_affiliate_model','first-click',1),
(492,'affiliate_management_enable_referral_removal','0',1),
(493,'loyalty_setting','1',1),
(494,'warehouse_selling_price_rule_profif_ratio','0',1),
(495,'profit_rate_by_purchase_price_sale','0',1),
(496,'warehouse_the_fractional_part','0',1),
(497,'warehouse_integer_part','0',1),
(498,'auto_create_goods_received','0',1),
(499,'auto_create_goods_delivery','0',1),
(500,'goods_receipt_warehouse','0',1),
(501,'barcode_with_sku_code','0',1),
(502,'revert_goods_receipt_goods_delivery','0',1),
(503,'cancelled_invoice_reverse_inventory_delivery_voucher','0',1),
(504,'uncancelled_invoice_create_inventory_delivery_voucher','0',1),
(505,'inventory_auto_operations_hour','0',1),
(506,'automatically_send_items_expired_before','0',1),
(507,'inventorys_cronjob_active','0',1),
(508,'inventory_cronjob_notification_recipients','',1),
(509,'inventory_received_number_prefix','NK',1),
(510,'next_inventory_received_mumber','1',1),
(511,'inventory_delivery_number_prefix','XK',1),
(512,'next_inventory_delivery_mumber','1',1),
(513,'internal_delivery_number_prefix','ID',1),
(514,'next_internal_delivery_mumber','1',1),
(515,'item_sku_prefix','',1),
(516,'goods_receipt_required_po','0',1),
(517,'goods_delivery_required_po','0',1),
(518,'goods_delivery_pdf_display','0',1),
(519,'display_product_name_when_print_barcode','0',1),
(520,'show_item_cf_on_pdf','0',1),
(521,'goods_delivery_pdf_display_outstanding','0',1),
(522,'goods_delivery_pdf_display_warehouse_lotnumber_bottom_infor','0',1),
(523,'packing_list_number_prefix','PL',1),
(524,'next_packing_list_number','1',1),
(525,'wh_return_request_within_x_day','30',1),
(526,'wh_fee_for_return_order','0',1),
(527,'wh_return_policies_information','',1),
(528,'wh_refund_loyaty_point','1',1),
(529,'order_return_number_prefix','ReReturn',1),
(530,'next_order_return_number','1',1),
(531,'e_order_return_number_prefix','DEReturn',1),
(532,'e_next_order_return_number','1',1),
(533,'warehouse_receive_return_order ','0',1),
(534,'wh_display_shipment_on_client_portal','1',1),
(535,'wh_on_total_items','200',1),
(536,'wh_products_by_serial','1',1),
(537,'wh_shortened_form_pdf','0',1),
(538,'wh_show_price_when_print_barcode','1',1),
(539,'notify_customer_when_change_delivery_status','1',1),
(540,'wh_hide_shipping_fee','0',1),
(541,'lot_number_prefix','LOT',1),
(542,'next_lot_number','1',1),
(543,'auto_generate_lotnumber','0',1),
(544,'custom_name_for_meter','m',1),
(545,'custom_name_for_kg','kg',1),
(546,'custom_name_for_m3','m3',1),
(547,'packing_list_pdf_display_rate','1',1),
(548,'packing_list_pdf_display_tax','1',1),
(549,'packing_list_pdf_display_subtotal','1',1),
(550,'packing_list_pdf_display_discount_percent','1',1),
(551,'packing_list_pdf_display_discount_amount','1',1),
(552,'packing_list_pdf_display_totalpayment','1',1),
(553,'packing_list_pdf_display_summary','1',1),
(554,'standard_workload','8',1),
(555,'aside_menu_active','[]',1),
(556,'setup_menu_active','[]',1),
(557,'perfex_saas_enable_auto_trial','1',1),
(558,'perfex_saas_autocreate_first_company','1',1),
(559,'perfex_saas_reserved_slugs','www,app,deal,controller,master,ww3,hack,dotone,techdotbit',1),
(560,'perfex_saas_control_client_menu','1',1),
(561,'perfex_saas_cron_cache','{\"last_proccessed_instance_id\":0,\"cron_last_success_runtime\":1751173203,\"package-update\":[\"2\",\"1\",\"3\",\"4\"],\"module-update-single-tenant\":[\"tata\"]}',1),
(562,'perfex_saas_tenants_seed_tables','[\"tblcountries\",\"tblcurrencies\",\"tblcustomfields\",\"tblemailtemplates\",\"tblleads_email_integration\",\"tblleads_sources\",\"tblleads_status\",\"tblmigrations\",\"tblroles\",\"tbltickets_priorities\",\"tbltickets_status\"]',1),
(563,'perfex_saas_sensitive_options','[\"acc_close_book_password\",\"acc_close_book_passwordr\",\"bitly_access_token\",\"company_logo\",\"company_logo_dark\",\"company_state\",\"company_vat\",\"dropbox_app_key\",\"favicon\",\"google_api_key\",\"google_client_id\",\"google_mail_client_id\",\"google_mail_client_secret\",\"google_mail_refresh_token\",\"identification_key\",\"invoice_company_address\",\"invoice_company_city\",\"invoice_company_country_code\",\"invoice_company_name\",\"invoice_company_phonenumber\",\"invoice_company_postal_code\",\"mailbox_product_token\",\"mailbox_verification_id\",\"main_domain\",\"microsoft_mail_azure_tenant_id\",\"microsoft_mail_client_id\",\"microsoft_mail_client_secret\",\"microsoft_mail_refresh_token\",\"paymentmethod_authorize_acceptjs_api_login_id\",\"paymentmethod_authorize_acceptjs_api_transaction_key\",\"paymentmethod_authorize_acceptjs_public_key\",\"paymentmethod_instamojo_api_key\",\"paymentmethod_instamojo_auth_token\",\"paymentmethod_mollie_api_key\",\"paymentmethod_paypal_braintree_api_private_key\",\"paymentmethod_paypal_braintree_api_public_key\",\"paymentmethod_paypal_braintree_merchant_id\",\"paymentmethod_paypal_checkout_client_id\",\"paymentmethod_paypal_checkout_secret\",\"paymentmethod_paypal_password\",\"paymentmethod_payu_money_key\",\"paymentmethod_stripe_api_publishable_key\",\"paymentmethod_stripe_api_secret_key\",\"paymentmethod_stripe_ideal_api_publishable_key\",\"paymentmethod_stripe_ideal_api_secret_key\",\"paymentmethod_two_checkout_secret_key\",\"purchase_key\",\"pusher_app_id\",\"pusher_app_key\",\"pusher_app_secret\",\"recaptcha_secret_key\",\"recaptcha_site_key\",\"sms_clickatell_api_key\",\"sms_msg91_auth_key\",\"sms_msg91_sender_id\",\"sms_twilio_auth_token\",\"sms_twilio_sender_id\",\"smtp_password\",\"stripe_ideal_webhook_id\",\"stripe_ideal_webhook_signing_secret\",\"stripe_webhook_id\",\"stripe_webhook_signing_secret\"]',1),
(564,'perfex_saas_enable_single_package_mode','1',1),
(565,'perfex_saas_enable_client_menu_in_bridge','1',1),
(566,'perfex_saas_enable_custom_module_request','1',1),
(567,'perfex_saas_enable_deploy_splash_screen','1',1),
(568,'perfex_saas_deploy_splash_screen_theme','verbose',1),
(569,'perfex_saas_enable_client_menu_in_interim_pages','0',1),
(570,'perfex_saas_client_bridge_account_menu_position','setup',1),
(571,'perfex_saas_registered_global_active_modules','[]',1),
(572,'perfex_saas_masked_settings_pages','',1),
(573,'perfex_saas_autolaunch_instance','new',1),
(574,'perfex_saas_restricted_clients_id','[\"\"]',1),
(575,'perfex_saas_tenant_seeding_source','master',1),
(576,'perfex_saas_instance_delete_pending_days','0',1),
(577,'perfex_saas_allow_customer_cancel_subscription','1',1),
(578,'perfex_saas_enable_api','1',1),
(579,'perfex_saas_api_allow_public_access_to_doc','1',1),
(580,'perfex_saas_enable_client_bridge','1',1),
(581,'perfex_saas_enable_cross_domain_bridge','0',1),
(582,'perfex_saas_enable_instance_switch','1',1),
(583,'perfex_saas_enable_package_grouping','1',1),
(584,'perfex_saas_custom_domain_guide','<p><strong>For Linking Your Root Domain (e.g., yourbusiness.com):<br></strong></p>\r\n<ol>\r\n<li>\r\n<p><strong>Get Your Domain:</strong> Purchase your domain name from a registrar like Namecheap or GoDaddy (or any of your choice), if you haven\'t already.</p>\r\n</li>\r\n<li>\r\n<p><strong>Access DNS Records:</strong> Log in to your domain registrar\'s website and find the DNS settings section.</p>\r\n</li>\r\n<li>\r\n<p><strong>Configure DNS Settings for Root Domain:<br></strong></p>\r\n<ul>\r\n<li>Add a new \"A Record\" for the root domain:<br>\r\n<ul>\r\n<li><strong>Host:</strong> @</li>\r\n<li><strong>Value:</strong> {ip_address}</li>\r\n<li><strong>TTL:</strong> Automatic<br><br></li>\r\n</ul>\r\n</li>\r\n<li>Add another \"A Record\" for the \"www\" version (optional):<br>\r\n<ul>\r\n<li><strong>Host:</strong> www</li>\r\n<li><strong>Value:</strong> {ip_address}</li>\r\n<li><strong>TTL:</strong> Automatic<br><br></li>\r\n</ul>\r\n</li>\r\n</ul>\r\n</li>\r\n<li>\r\n<p><strong>Wait for Changes:</strong> Allow up to 48 hours for the changes to propagate across the internet.</p>\r\n</li>\r\n<li>\r\n<p><strong>Done!:</strong> Once propagated, both your root domain and optional \"www\" version will be linked to your SaaS platform.<br><br><br></p>\r\n</li>\r\n</ol>\r\n<p><strong>For Linking a Subdomain (e.g., crm.yourbusiness.com):<br></strong></p>\r\n<ol>\r\n<li>\r\n<p><strong>Create Your Subdomain:</strong></p>\r\n<ul>\r\n<li>In the DNS settings section of your registrar\'s website, find the option to create a subdomain.<br><br></li>\r\n<li>Enter \"crm\" (or your desired prefix) as the subdomain.<br><br></li>\r\n</ul>\r\n</li>\r\n<li>\r\n<p><strong>Access DNS Records:</strong></p>\r\n<ul>\r\n<li>Once the subdomain is created, locate the DNS settings for the subdomain.<br><br></li>\r\n</ul>\r\n</li>\r\n<li>\r\n<p><strong>Configure DNS Settings for Subdomain:</strong></p>\r\n<ul>\r\n<li>Add a new \"CNAME Record\" for the subdomain:<br>\r\n<ul>\r\n<li><strong>Host:</strong> crm (or your chosen prefix)</li>\r\n<li><strong>Value:</strong> {subdomain}</li>\r\n<li><strong>TTL:</strong> Automatic<br><br></li>\r\n</ul>\r\n</li>\r\n<li>Add another \"CNAME Record\" for the \"www\" version (optional):<br>\r\n<ul>\r\n<li><strong>Host:</strong> <a href=\"http://www.crm\">www.crm</a> (or your chosen prefix)</li>\r\n<li><strong>Value:</strong> {subdomain}</li>\r\n<li><strong>TTL:</strong> Automatic<br><br></li>\r\n</ul>\r\n</li>\r\n</ul>\r\n</li>\r\n<li>\r\n<p><strong>Wait for Changes:</strong> Allow up to 48 hours for the changes to propagate.</p>\r\n</li>\r\n<li>\r\n<p><strong>Test Your Subdomain:</strong> After propagation, enter the subdomain URL (e.g., crm.yourbusiness.com) into a browser to ensure it loads correctly.</p>\r\n</li>\r\n</ol>',1),
(585,'paymentmethod_affiliate_management_gateway_active','0',1),
(586,'paymentmethod_affiliate_management_gateway_label','Affiliate Earnings',1),
(587,'paymentmethod_affiliate_management_gateway_currencies','USD',0),
(588,'paymentmethod_affiliate_management_gateway_default_selected','1',1),
(589,'paymentmethod_affiliate_management_gateway_initialized','1',1),
(590,'paymentmethod_authorize_acceptjs_active','0',1),
(591,'paymentmethod_authorize_acceptjs_label','Authorize.net Accept.js',1),
(592,'paymentmethod_authorize_acceptjs_public_key','',0),
(593,'paymentmethod_authorize_acceptjs_api_login_id','',0),
(594,'paymentmethod_authorize_acceptjs_api_transaction_key','',0),
(595,'paymentmethod_authorize_acceptjs_description_dashboard','Payment for Invoice {invoice_number}',0),
(596,'paymentmethod_authorize_acceptjs_currencies','USD',0),
(597,'paymentmethod_authorize_acceptjs_test_mode_enabled','0',0),
(598,'paymentmethod_authorize_acceptjs_default_selected','1',1),
(599,'paymentmethod_authorize_acceptjs_initialized','1',1),
(600,'paymentmethod_instamojo_active','0',1),
(601,'paymentmethod_instamojo_label','Instamojo',1),
(602,'paymentmethod_instamojo_fee_fixed','0',0),
(603,'paymentmethod_instamojo_fee_percent','0',0),
(604,'paymentmethod_instamojo_api_key','',0),
(605,'paymentmethod_instamojo_auth_token','',0),
(606,'paymentmethod_instamojo_description_dashboard','Payment for Invoice {invoice_number}',0),
(607,'paymentmethod_instamojo_currencies','INR',0),
(608,'paymentmethod_instamojo_test_mode_enabled','1',0),
(609,'paymentmethod_instamojo_default_selected','1',1),
(610,'paymentmethod_instamojo_initialized','1',1),
(611,'paymentmethod_mollie_active','0',1),
(612,'paymentmethod_mollie_label','Mollie',1),
(613,'paymentmethod_mollie_api_key','',0),
(614,'paymentmethod_mollie_description_dashboard','Payment for Invoice {invoice_number}',0),
(615,'paymentmethod_mollie_currencies','EUR',0),
(616,'paymentmethod_mollie_test_mode_enabled','1',0),
(617,'paymentmethod_mollie_default_selected','1',1),
(618,'paymentmethod_mollie_initialized','1',1),
(619,'paymentmethod_paypal_braintree_active','0',1),
(620,'paymentmethod_paypal_braintree_label','Braintree',1),
(621,'paymentmethod_paypal_braintree_merchant_id','',0),
(622,'paymentmethod_paypal_braintree_api_public_key','',0),
(623,'paymentmethod_paypal_braintree_api_private_key','',0),
(624,'paymentmethod_paypal_braintree_currencies','USD',0),
(625,'paymentmethod_paypal_braintree_paypal_enabled','1',0),
(626,'paymentmethod_paypal_braintree_test_mode_enabled','1',0),
(627,'paymentmethod_paypal_braintree_default_selected','1',1),
(628,'paymentmethod_paypal_braintree_initialized','1',1),
(629,'paymentmethod_paypal_checkout_active','0',1),
(630,'paymentmethod_paypal_checkout_label','Paypal Smart Checkout',1),
(631,'paymentmethod_paypal_checkout_fee_fixed','0',0),
(632,'paymentmethod_paypal_checkout_fee_percent','0',0),
(633,'paymentmethod_paypal_checkout_client_id','',0),
(634,'paymentmethod_paypal_checkout_secret','',0),
(635,'paymentmethod_paypal_checkout_payment_description','Payment for Invoice {invoice_number}',0),
(636,'paymentmethod_paypal_checkout_currencies','USD,CAD,EUR',0),
(637,'paymentmethod_paypal_checkout_test_mode_enabled','1',0),
(638,'paymentmethod_paypal_checkout_default_selected','1',1),
(639,'paymentmethod_paypal_checkout_initialized','1',1),
(640,'paymentmethod_paypal_active','0',1),
(641,'paymentmethod_paypal_label','Paypal',1),
(642,'paymentmethod_paypal_fee_fixed','0',0),
(643,'paymentmethod_paypal_fee_percent','0',0),
(644,'paymentmethod_paypal_username','',0),
(645,'paymentmethod_paypal_password','',0),
(646,'paymentmethod_paypal_signature','',0),
(647,'paymentmethod_paypal_description_dashboard','Payment for Invoice {invoice_number}',0),
(648,'paymentmethod_paypal_currencies','EUR,USD',0),
(649,'paymentmethod_paypal_test_mode_enabled','1',0),
(650,'paymentmethod_paypal_default_selected','1',1),
(651,'paymentmethod_paypal_initialized','1',1),
(652,'paymentmethod_payu_money_active','0',1),
(653,'paymentmethod_payu_money_label','PayU Money',1),
(654,'paymentmethod_payu_money_fee_fixed','0',0),
(655,'paymentmethod_payu_money_fee_percent','0',0),
(656,'paymentmethod_payu_money_key','',0),
(657,'paymentmethod_payu_money_salt','',0),
(658,'paymentmethod_payu_money_description_dashboard','Payment for Invoice {invoice_number}',0),
(659,'paymentmethod_payu_money_currencies','INR',0),
(660,'paymentmethod_payu_money_test_mode_enabled','1',0),
(661,'paymentmethod_payu_money_default_selected','1',1),
(662,'paymentmethod_payu_money_initialized','1',1),
(663,'paymentmethod_stripe_active','0',1),
(664,'paymentmethod_stripe_label','Stripe Checkout',1),
(665,'paymentmethod_stripe_fee_fixed','0',0),
(666,'paymentmethod_stripe_fee_percent','0',0),
(667,'paymentmethod_stripe_api_publishable_key','',0),
(668,'paymentmethod_stripe_api_secret_key','',0),
(669,'paymentmethod_stripe_description_dashboard','Payment for Invoice {invoice_number}',0),
(670,'paymentmethod_stripe_currencies','USD,CAD',0),
(671,'paymentmethod_stripe_allow_primary_contact_to_update_credit_card','1',0),
(672,'paymentmethod_stripe_default_selected','1',1),
(673,'paymentmethod_stripe_initialized','1',1),
(674,'paymentmethod_stripe_ideal_active','0',1),
(675,'paymentmethod_stripe_ideal_label','Stripe iDEAL',1),
(676,'paymentmethod_stripe_ideal_api_secret_key','',0),
(677,'paymentmethod_stripe_ideal_api_publishable_key','',0),
(678,'paymentmethod_stripe_ideal_description_dashboard','Payment for Invoice {invoice_number}',0),
(679,'paymentmethod_stripe_ideal_statement_descriptor','Payment for Invoice {invoice_number}',0),
(680,'paymentmethod_stripe_ideal_currencies','EUR',0),
(681,'paymentmethod_stripe_ideal_default_selected','1',1),
(682,'paymentmethod_stripe_ideal_initialized','1',1),
(683,'paymentmethod_two_checkout_active','0',1),
(684,'paymentmethod_two_checkout_label','2Checkout',1),
(685,'paymentmethod_two_checkout_fee_fixed','0',0),
(686,'paymentmethod_two_checkout_fee_percent','0',0),
(687,'paymentmethod_two_checkout_merchant_code','',0),
(688,'paymentmethod_two_checkout_secret_key','',0),
(689,'paymentmethod_two_checkout_description','Payment for Invoice {invoice_number}',0),
(690,'paymentmethod_two_checkout_currencies','USD, EUR, GBP',0),
(691,'paymentmethod_two_checkout_test_mode_enabled','1',0),
(692,'paymentmethod_two_checkout_default_selected','1',1),
(693,'paymentmethod_two_checkout_initialized','1',1),
(694,'perfex_saas_demo_instance_last_reset_time','1751128802',1),
(695,'perfex_saas_require_invoice_payment_status','[\"\",\"4\"]',1),
(696,'perfex_saas_deferred_billing_status','6',1),
(697,'perfex_saas_landing_page_url','',1),
(698,'perfex_saas_landing_page_url_mode','proxy',1),
(699,'perfex_saas_clients_default_theme_whitelabel_name','perfex',1),
(700,'perfex_saas_seeding_tenant','',1),
(701,'perfex_saas_custom_module_request_form','',1),
(702,'perfex_saas_custom_modules_name','{\"account_planning\":\"Account Planning\",\"accounting\":\"Accounting and Bookkeeping\",\"affiliate_management\":\"Affiliate Management\",\"appointly\":\"Appointly\",\"aws_integration\":\"AWS S3 Integration\",\"exports\":\"CSV Export Manager\",\"loyalty\":\"Customer Loyalty & Membership\",\"backup\":\"Database Backup\",\"facebook_leads_integration\":\"Facebook leads integration\",\"fixed_equipment\":\"Fixed Equipment Management\",\"fleet\":\"Fleet Management\",\"flexstage\":\"Flex Stage - Event Manager\",\"flexibackup\":\"Flexi Backup\",\"goals\":\"Goals\",\"hr_payroll\":\"HR Payroll\",\"hr_profile\":\"HR Records\",\"si_lead_followup\":\"Lead Follow up Scheduler\",\"mailbox\":\"Mailbox\",\"mailflow\":\"MailFlow - Customers & Leads Newsletter\",\"si_custom_status\":\"Manage Custom Statuses\",\"manufacturing\":\"Manufacturing Management\",\"ma\":\"Marketing Automation\",\"menu_setup\":\"Menu Setup\",\"mfa\":\"Multi-factor authentication\",\"perfex_office_theme\":\"Office Flat Pro Theme\",\"omni_sales\":\"Omni Sales\",\"project_roadmap\":\"Project Roadmap\",\"purchase\":\"Purchase\",\"quickbooks_integration\":\"Quickbooks integration\",\"recruitment\":\"Recruitment\",\"resource_workload\":\"Staff workload\",\"surveys\":\"Surveys\",\"theme_style\":\"Theme Style\",\"timesheets\":\"Timesheet Attendance Management\",\"user_mention\":\"User Mention\",\"warehouse\":\"Warehouse\",\"webhooks\":\"Webhooks\",\"whatsapp_api\":\"WhatsApp Cloud API Business Integration module\",\"whatsbot\":\"WhatsBot\"}',1),
(703,'perfex_saas_modules_marketplace','{\"account_planning\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"accounting\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"affiliate_management\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"appointly\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"aws_integration\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"exports\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"loyalty\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"backup\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"facebook_leads_integration\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"fixed_equipment\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"fleet\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"flexstage\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"flexibackup\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"goals\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"hr_payroll\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"hr_profile\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"si_lead_followup\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"mailbox\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"mailflow\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"si_custom_status\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"manufacturing\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"ma\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"menu_setup\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"mfa\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"perfex_office_theme\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"omni_sales\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"project_roadmap\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"purchase\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"quickbooks_integration\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"recruitment\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"resource_workload\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"surveys\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"theme_style\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"timesheets\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"user_mention\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"warehouse\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"webhooks\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"whatsapp_api\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"whatsbot\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"}}',1),
(704,'perfex_saas_custom_service_request_form','',1),
(705,'perfex_saas_custom_services','[\"\"]',1),
(706,'perfex_saas_cpanel_login_domain','',1),
(707,'perfex_saas_cpanel_port','2083',1),
(708,'perfex_saas_cpanel_username','',1),
(709,'perfex_saas_cpanel_password','53b11bf7b542d0d2445ed2ab711e618825eae2d3f5e25e467f9ea562b96587f2f41f3d897330100107f1fb38b0f11f9a8ca3b307d1131038c11599d6d267b7feYZFAJ/ikyrUzuoe/bty2PV1/hA/aD09W1gxKb6yeBuA=',1),
(710,'perfex_saas_cpanel_db_prefix','',1),
(711,'perfex_saas_cpanel_enable_addondomain','0',1),
(712,'perfex_saas_cpanel_addondomain_mode','all',1),
(713,'perfex_saas_cpanel_primary_domain','82.29.165.22',1),
(714,'perfex_saas_cpanel_document_root','/var/www/html/',1),
(715,'perfex_saas_plesk_host','',1),
(716,'perfex_saas_plesk_primary_domain','82.29.165.22',1),
(717,'perfex_saas_plesk_username','',1),
(718,'perfex_saas_plesk_password','c76ea3144182b0350ec3e4900448bce1d8ca7ff6dd53463bbd532f66c101197a99ce8ed327e3dffe08daec23665ce0021469a4c4ac380edb25ef2206d6deeb036pOTHlf0t/fte+l3VeYDFlSrJz3ZNyrh0tDSytcPOUw=',1),
(719,'perfex_saas_plesk_enable_aliasdomain','0',1),
(720,'perfex_saas_plesk_addondomain_mode','all',1),
(721,'perfex_saas_mysql_root_enabled','1',1),
(722,'perfex_saas_mysql_root_host','localhost',1),
(723,'perfex_saas_mysql_root_port','3306',1),
(724,'perfex_saas_mysql_root_username','dotadmin',1),
(725,'perfex_saas_mysql_root_password','0ea0d3680be25b790e7c33582f032144f9621bd12ed8ddfa329ffe82271754fbc820ce405049e711ab5c608b781978b51929a77ec7fb4f454ffdfc9055736d68dzvNwUFPeFE3QeOlciWUbvp0mu1lMT93fa0pLt5jEEFlz4tRZSNiaqDe4idCkPQW',1),
(726,'perfex_saas_mysql_root_enable_separate_user','1',1),
(727,'perfex_saas_after_first_instance_redirect_url','',1),
(728,'perfex_saas_trial_expire_page_url','',1),
(729,'perfex_saas_client_restriction_mode','',1),
(730,'perfex_saas_trial_notification_day','0',1),
(731,'perfex_saas_demo_instance','[\"\"]',1),
(732,'perfex_saas_demo_instance_reset_hour','24',1),
(733,'perfex_saas_alternative_base_host','',1),
(734,'perfex_saas_route_id','',1),
(735,'perfex_saas_cpanel_enabled','1',1),
(736,'sms_trigger_invoice_overdue_notice','',0),
(737,'sms_trigger_invoice_due_notice','',0),
(738,'sms_trigger_invoice_payment_recorded','',0),
(739,'sms_trigger_estimate_expiration_reminder','',0),
(740,'sms_trigger_proposal_expiration_reminder','',0),
(741,'sms_trigger_proposal_new_comment_to_customer','',0),
(742,'sms_trigger_proposal_new_comment_to_staff','',0),
(743,'sms_trigger_contract_new_comment_to_customer','',0),
(744,'sms_trigger_contract_new_comment_to_staff','',0),
(745,'sms_trigger_contract_expiration_reminder','',0),
(746,'sms_trigger_contract_sign_reminder_to_customer','',0),
(747,'sms_trigger_staff_reminder','',0),
(748,'perfex_office_theme_customers','1',1),
(749,'perfex_saas_enable_subdomain_input_on_signup_form','1',1),
(750,'perfex_saas_enable_customdomain_input_on_signup_form','1',1),
(751,'perfex_saas_force_redirect_to_dashboard','1',1),
(752,'required_register_fields','[\"contact_firstname\",\"contact_lastname\"]',1);
/*!40000 ALTER TABLE `tbloptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblp_t_form_question_box_description`
--

DROP TABLE IF EXISTS `tblp_t_form_question_box_description`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblp_t_form_question_box_description` (
  `questionboxdescriptionid` int(11) NOT NULL AUTO_INCREMENT,
  `description` mediumtext NOT NULL,
  `boxid` mediumtext NOT NULL,
  `questionid` int(11) NOT NULL,
  `correct` int(11) DEFAULT 1 COMMENT '0: correct 1: incorrect',
  PRIMARY KEY (`questionboxdescriptionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblp_t_form_question_box_description`
--

LOCK TABLES `tblp_t_form_question_box_description` WRITE;
/*!40000 ALTER TABLE `tblp_t_form_question_box_description` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblp_t_form_question_box_description` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblpayment_attempts`
--

DROP TABLE IF EXISTS `tblpayment_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblpayment_attempts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference` varchar(100) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `amount` double NOT NULL,
  `fee` double NOT NULL,
  `payment_gateway` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblpayment_attempts`
--

LOCK TABLES `tblpayment_attempts` WRITE;
/*!40000 ALTER TABLE `tblpayment_attempts` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblpayment_attempts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblpayment_modes`
--

DROP TABLE IF EXISTS `tblpayment_modes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblpayment_modes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `show_on_pdf` int(11) NOT NULL DEFAULT 0,
  `invoices_only` int(11) NOT NULL DEFAULT 0,
  `expenses_only` int(11) NOT NULL DEFAULT 0,
  `selected_by_default` int(11) NOT NULL DEFAULT 1,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblpayment_modes`
--

LOCK TABLES `tblpayment_modes` WRITE;
/*!40000 ALTER TABLE `tblpayment_modes` DISABLE KEYS */;
INSERT INTO `tblpayment_modes` VALUES
(1,'Bank',NULL,0,0,0,1,1);
/*!40000 ALTER TABLE `tblpayment_modes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblperfex_saas_api_users`
--

DROP TABLE IF EXISTS `tblperfex_saas_api_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblperfex_saas_api_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `token` varchar(150) NOT NULL,
  `permissions` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pf_api_users_token` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblperfex_saas_api_users`
--

LOCK TABLES `tblperfex_saas_api_users` WRITE;
/*!40000 ALTER TABLE `tblperfex_saas_api_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblperfex_saas_api_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblperfex_saas_client_metadata`
--

DROP TABLE IF EXISTS `tblperfex_saas_client_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblperfex_saas_client_metadata` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clientid` int(11) NOT NULL,
  `metadata` text DEFAULT NULL COMMENT 'Extra data',
  PRIMARY KEY (`id`),
  UNIQUE KEY `clientid` (`clientid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblperfex_saas_client_metadata`
--

LOCK TABLES `tblperfex_saas_client_metadata` WRITE;
/*!40000 ALTER TABLE `tblperfex_saas_client_metadata` DISABLE KEYS */;
INSERT INTO `tblperfex_saas_client_metadata` VALUES
(1,1,'{\"trial_period_start\":\"2025-06-26\",\"trial_period_ends\":\"2025-07-03\",\"trial_package_id\":\"1\",\"trial_cancelled\":\"\",\"last_cancelled_invoice\":\"\",\"subscription_id\":\"\",\"magic_code\":\"9c1f25426679dc831c53f33cef2586a6160e100ee565ff2cd7e47107504e5f62605abbcd1e1019bac45ac5a4e3fd226468506e19c964692f6970cbfc69b2cf2bR4VpO0IQ216Tendj2xnIi3/Z+/bh7+VPK0YsrVeUNInsN40TgAAt2sq1UvYa/RtA\"}'),
(2,2,'{\"trial_period_start\":\"2025-06-27\",\"trial_period_ends\":\"2025-07-04\",\"trial_package_id\":\"1\",\"trial_cancelled\":\"\",\"last_cancelled_invoice\":\"\",\"subscription_id\":\"\",\"magic_code\":\"d1628ec7bbb77e3e68c92ee77f2c0fc80ee394deb7c61fafac07292e535f4f87f5cb9b98a8b594d9872efeb27e960696659f375abeb8a4d5ab86eb88ee0c9de8/Ps2N2k2dBNXTjoXO4pCJKZg9DpIErZ1wqWSwpZv9X0dnSRGUFL2DHwUuKIWhbNF\"}'),
(3,3,'{\"trial_period_start\":\"2025-06-27\",\"trial_period_ends\":\"2025-07-04\",\"trial_package_id\":\"1\",\"trial_cancelled\":\"\",\"last_cancelled_invoice\":\"\",\"subscription_id\":\"\",\"magic_code\":\"5f45ffdc173c4737d71041c0fda3e2596fc2b17f36804e3cf54a4747d5b72ae1f129637e05686f6b74bf819279a89e07afc5e3fc0a5cbcea75ee03fd5355911cPh9dgfLloYQ5D3ro6L37nDFdqE9uIk3qWs8DcwgFyEkJXTXy7tuQq4kox6dWtQ9Y\"}'),
(4,4,'{\"trial_period_start\":\"2025-06-27\",\"trial_period_ends\":\"2025-07-04\",\"trial_package_id\":\"1\",\"trial_cancelled\":\"true\",\"last_cancelled_invoice\":\"\",\"subscription_id\":\"\",\"last_cancelled_invoice_recurring\":null,\"magic_code\":\"ba44c20ee1eec03836822bc8931815f15730c84986bd53425d063a1a7cfddd80ac8090dda9a324fbf675b0128fc21b26e8a0c5bdce7eef481dd201fc18fa421c1wEbLxt9Az9FVxNmsUuHEiiamV1yx0tf7+X4aOe5RMDikr2ktDtZhyNx2wH2hFnN\"}'),
(5,5,'{\"trial_period_start\":\"2025-07-01\",\"trial_period_ends\":\"2025-07-08\",\"trial_package_id\":\"1\",\"trial_cancelled\":\"\",\"last_cancelled_invoice\":\"\",\"subscription_id\":\"\",\"magic_code\":\"e7464683cc8a675d7ba21d94bdf40d85263375583039ba847c3f91851b9398e961b902e0f63efd10866450a400a610cbcd079fe2fb259cd43b69d12cccdd2680wD2PLBm2hmWyjKftRS14tBLqTpQ4lMl1iMzhvg9EoO+X28chNa7HZtFJ2Gkl18TQ\"}');
/*!40000 ALTER TABLE `tblperfex_saas_client_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblperfex_saas_companies`
--

DROP TABLE IF EXISTS `tblperfex_saas_companies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblperfex_saas_companies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clientid` int(11) NOT NULL,
  `slug` varchar(30) NOT NULL,
  `name` varchar(100) NOT NULL,
  `status` enum('active','inactive','disabled','banned','pending','deploying','pending-delete') NOT NULL DEFAULT 'pending',
  `status_note` text DEFAULT NULL,
  `dsn` text DEFAULT NULL,
  `custom_domain` varchar(150) DEFAULT NULL,
  `metadata` text DEFAULT NULL COMMENT 'Extra data',
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblperfex_saas_companies`
--

LOCK TABLES `tblperfex_saas_companies` WRITE;
/*!40000 ALTER TABLE `tblperfex_saas_companies` DISABLE KEYS */;
INSERT INTO `tblperfex_saas_companies` VALUES
(1,1,'fecuni','FECUNI','active','','c22deb9c8e099235d432eecea2dbaf404d94faa52e7bfb914915a462845d12113c00d5c724c08b3fd85b9e635764d3133f81728bf998cbda65c920cbcd074965LzU0MITu/LFM6/qWcxhJvLZEDaDzzT3y7GpJfVGRmASabd+gU/vMVz3Sdk2ZdoejU51ZOO1MxZNbeCrrJOpm9ZEQkk8W/NRopdjwCqk7k8ifoPNE8qYO3EmsY0VIoCAzrJmgGC11wgg8eTVCp4dwjA==','','{\"disabled_modules\":[],\"storage\":{\"upload_size_in_bytes\":330,\"media_size_in_bytes\":0,\"total\":330}}','2025-06-26 07:01:14','2025-06-26 01:35:02'),
(2,2,'minera','Minera software Solution ,Sweden','active','','76d878b9e436a58560387dd9e0cd6f37751db97da285243bc8cdcbe61e9a14e5cba3a812afa083cb90b108858fc741a64a1ceff5b5082b510a52097bcfee89fd/unPPQ4dLxTBidv9OPhZxb4C5XKPicu8PWYl+whWOG8CIiLSAJitp6skBnXD/9KG5Gp83iHZGJ8D91eXblSE5Kex61U6FUMfEV/z7Ggv0p60vBv6MLxEewmNxcxvy1ob8vW9WcaPY9y1kaN2n/0Now==',NULL,'{\"storage\":{\"upload_size_in_bytes\":300,\"media_size_in_bytes\":0,\"total\":300}}','2025-06-27 10:57:07','2025-06-27 06:50:02'),
(3,3,'indiatech','INDIA TECH','active','','c18074c8bedbad7ddcac3a54b6e18f07b5d70f7df6528e2fe14dcef9f6ddc1396bb88e4c59f650d51a05b947c83e5fbf83bf8c0aa9ee8e1f3875951064823f45L7haWF3gsVYcFx9CNRYvsdp+6mWRliYzkcP4AZzQIismAUwXOiAu9PNJ9QHF9/FmPSTSrJtt2QNi+VrBuOYliup3ZnWd06wscr9HNBMXwxXK/qvChouFr8aTA2chkDcY+TaLeC6ITINmdLVeqbBR3g==',NULL,'[]','2025-06-27 11:59:30','2025-06-27 06:29:33'),
(4,4,'audi','Audi','active',NULL,'719d049a3ec7edb5ec26c1a017d72bee5e5c46abe90c0581b886e78ed6df357d76b402eb264731c1c8cbdc5652e8b3e73bbe6947c964483cfc47fb624579f2b7+vn4g9fFmT7dOHO8FlZFAJLY8qDFvqpMFWJJkOwYTrFgODFBQcEG3jFy6oznyLmPiI6lvh5iHE1QT8ExzpJMqg4e62YZDcwftkoDehEhGlId/CWKtJ2kikjmjEbc93Xo','','{\"admin_approved_modules\":[\"\",\"account_planning\",\"accounting\",\"affiliate_management\",\"appointly\",\"aws_integration\",\"exports\",\"loyalty\",\"backup\",\"facebook_leads_integration\",\"fixed_equipment\",\"fleet\",\"flexstage\",\"flexibackup\",\"goals\",\"hr_payroll\",\"hr_profile\",\"si_lead_followup\",\"mailbox\",\"mailflow\",\"si_custom_status\",\"manufacturing\",\"ma\",\"menu_setup\",\"mfa\",\"perfex_office_theme\",\"omni_sales\",\"project_roadmap\",\"purchase\",\"quickbooks_integration\",\"recruitment\",\"resource_workload\",\"surveys\",\"theme_style\",\"timesheets\",\"user_mention\",\"warehouse\",\"webhooks\",\"whatsapp_api\",\"whatsbot\"],\"admin_disabled_modules\":[\"\",\"appointly\",\"aws_integration\"],\"admin_disabled_default_modules\":[\"\"],\"storage\":{\"upload_size_in_bytes\":300,\"media_size_in_bytes\":0,\"total\":300}}','2025-06-27 13:12:19','2025-06-27 08:05:02'),
(5,5,'tata','tata','active','','9f614fb4079f65703e3d608b9cfa66c31e8716bdbf11180d1f59f08de78cde1de18ffa5eb0a46a44cd3ddf6376a9e53e33b9c114cb511ea6bff57b5c730a1eda5T9bBbRU3EEsf5IoiTjLPBjSQpKm7tLm5laALgt3NB/iGrb2hk4B2Nl+zavyYXBRwyReZrEKZjWt4WCGmyXvGGovVowoyQK6Ti8IkRv+WVqB3luvWngowrSlzji1RVP7',NULL,'[]','2025-07-01 17:29:40','2025-07-01 11:59:51');
/*!40000 ALTER TABLE `tblperfex_saas_companies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblperfex_saas_packages`
--

DROP TABLE IF EXISTS `tblperfex_saas_packages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblperfex_saas_packages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `slug` varchar(150) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT 0.00,
  `bill_interval` varchar(150) DEFAULT NULL,
  `is_default` int(11) NOT NULL DEFAULT 0,
  `is_private` int(11) NOT NULL DEFAULT 0,
  `db_scheme` varchar(50) DEFAULT NULL,
  `db_pools` text DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `modules` text DEFAULT NULL,
  `metadata` text DEFAULT NULL COMMENT 'Extra data such as modules that are shown on package view list',
  `trial_period` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblperfex_saas_packages`
--

LOCK TABLES `tblperfex_saas_packages` WRITE;
/*!40000 ALTER TABLE `tblperfex_saas_packages` DISABLE KEYS */;
INSERT INTO `tblperfex_saas_packages` VALUES
(1,'Starter Plan','<ul>\n<li>\n<p>Up to 3 users</p>\n</li>\n<li>\n<p>Core ERP Modules (CRM, HRM, Inventory, Billing)</p>\n</li>\n<li>\n<p>Basic Analytics Dashboard</p>\n</li>\n<li>\n<p>Email &amp; Chat Support</p>\n</li>\n<li>\n<p>1GB File Storage</p>\n</li>\n</ul>','starter-plan',0.00,NULL,1,0,'mysql_root','e858f2091203869bfa129dac92f0ddbab055b3462faecfb064167f8b8e5a682c67650e22c74a1449717cb2e79f20cfdee3641c0ceee9688339595d1c60c2e6ff1EZ40VXgh762dHTbCmJOuGm6/ZljH1OiToSDHcvJOvE=',1,'[\"\",\"\",\"account_planning\",\"accounting\",\"affiliate_management\",\"appointly\",\"aws_integration\",\"exports\",\"loyalty\",\"backup\",\"facebook_leads_integration\",\"fixed_equipment\",\"goals\",\"si_lead_followup\",\"mailbox\",\"mailflow\",\"si_custom_status\",\"ma\",\"menu_setup\",\"mfa\",\"omni_sales\",\"project_roadmap\",\"purchase\",\"resource_workload\",\"surveys\",\"theme_style\",\"timesheets\",\"user_mention\",\"webhooks\"]','{\"invoice\":{\"recurring\":\"1\",\"repeat_every_custom\":\"1\",\"repeat_type_custom\":\"day\",\"allowed_payment_modes\":[\"1\"],\"sale_agent\":\"\"},\"client_theme\":\"single\",\"enable_subdomain\":\"1\",\"show_modules_list\":\"yes\",\"show_limits_on_package\":\"yes_3\",\"disabled_default_modules\":[\"\",\"contracts\",\"credit_notes\",\"custom_fields\",\"estimate_request\",\"estimates\",\"expenses\",\"invoices\",\"items\",\"knowledge_base\",\"leads\",\"payments\",\"projects\",\"proposals\",\"reports\",\"subscriptions\",\"tasks\",\"tickets\"],\"max_instance_limit\":\"1\",\"limitations_unit_price\":{\"tenant_instance\":\"\",\"staff\":\"1000\",\"clients\":\"1000\",\"contacts\":\"0\",\"contracts\":\"\",\"invoices\":\"1000\",\"estimates\":\"1000\",\"creditnotes\":\"\",\"proposals\":\"\",\"projects\":\"\",\"tasks\":\"\",\"tickets\":\"\",\"leads\":\"\",\"items\":\"2000\"},\"resource_limit_period\":\"billing_cycle\",\"limitations\":{\"staff\":\"3\",\"clients\":\"5\",\"contacts\":\"-1\",\"contracts\":\"-1\",\"invoices\":\"5\",\"estimates\":\"5\",\"creditnotes\":\"-1\",\"proposals\":\"-1\",\"projects\":\"2\",\"tasks\":\"10\",\"tickets\":\"-1\",\"leads\":\"-1\",\"items\":\"5\"},\"storage_limit\":{\"size\":\"1\",\"unit\":\"GB\",\"unit_price\":\"5000\"},\"dashboard_quota_visibility\":\"yes\",\"hidden_quota_widgets\":[\"\"],\"hidden_app_tabs\":{\"settings\":[\"\"],\"customer_profile\":[\"\"],\"project\":[\"\"]},\"allow_customization\":\"yes\",\"disable_module_marketplace\":\"no\",\"disable_service_marketplace\":\"no\",\"assigned_clients\":[\"\"],\"seeding_tenant\":\"\",\"auto_remove_inactive_instance\":\"no\",\"auto_remove_inactive_instance_days\":\"30\",\"enable_custom_domain\":\"\",\"is_liftetime_deal\":\"\"}',7),
(2,'Growth Plan','<p><strong>Ideal for growing businesses with expanding needs</strong></p>\n<p><strong>Everything in Starter, plus:</strong></p>\n<ul>\n<li>\n<p>Up to 10 users</p>\n</li>\n<li>\n<p>Custom Fields &amp; Roles</p>\n</li>\n<li>\n<p>Mobile App Access (iOS/Android)</p>\n</li>\n<li>\n<p>Automated Notifications &amp; Reminders</p>\n</li>\n<li>\n<p>API Access (Limited)</p>\n</li>\n<li>\n<p>10GB File Storage</p>\n</li>\n<li>\n<p>Basic Vision AI Tools (e.g., Attendance via Face Recognition)</p>\n</li>\n</ul>','growth-plan',12000.00,NULL,0,0,'mysql_root','b89df83e71a61e70306380976f90e87a8896d06d65b405193396c33712712f4a43eb02d95b437771d20cbcf4800b329101764d8874af3df038f57040cd190780GH1qtAMz00M5SWAWgRsm9psqRHeLqt5EQVNp5P6JvDs=',1,'[\"\",\"account_planning\",\"accounting\",\"affiliate_management\",\"appointly\",\"aws_integration\",\"exports\",\"loyalty\",\"backup\",\"facebook_leads_integration\",\"fixed_equipment\",\"fleet\",\"flexstage\",\"flexibackup\",\"goals\",\"hr_payroll\",\"hr_profile\",\"si_lead_followup\",\"mailbox\",\"mailflow\",\"si_custom_status\",\"manufacturing\",\"ma\",\"menu_setup\",\"mfa\",\"perfex_office_theme\",\"omni_sales\",\"project_roadmap\",\"purchase\",\"quickbooks_integration\",\"recruitment\",\"resource_workload\",\"surveys\",\"theme_style\",\"timesheets\",\"user_mention\",\"warehouse\",\"webhooks\",\"whatsapp_api\",\"whatsbot\"]','{\"invoice\":{\"recurring\":\"1\",\"repeat_every_custom\":\"1\",\"repeat_type_custom\":\"day\",\"allowed_payment_modes\":[\"1\"],\"sale_agent\":\"\"},\"client_theme\":\"single\",\"enable_subdomain\":\"1\",\"show_modules_list\":\"yes\",\"show_limits_on_package\":\"yes_3\",\"disabled_default_modules\":[\"\"],\"max_instance_limit\":\"1\",\"limitations_unit_price\":{\"tenant_instance\":\"\",\"staff\":\"\",\"clients\":\"\",\"contacts\":\"\",\"contracts\":\"\",\"invoices\":\"2000\",\"estimates\":\"\",\"creditnotes\":\"\",\"proposals\":\"\",\"projects\":\"\",\"tasks\":\"\",\"tickets\":\"\",\"leads\":\"\",\"items\":\"\"},\"resource_limit_period\":\"lifetime\",\"limitations\":{\"staff\":\"10\",\"clients\":\"15\",\"contacts\":\"-1\",\"contracts\":\"-1\",\"invoices\":\"100\",\"estimates\":\"100\",\"creditnotes\":\"-1\",\"proposals\":\"-1\",\"projects\":\"150\",\"tasks\":\"-1\",\"tickets\":\"-1\",\"leads\":\"-1\",\"items\":\"-1\"},\"storage_limit\":{\"size\":\"-1\",\"unit\":\"MB\",\"unit_price\":\"\"},\"dashboard_quota_visibility\":\"limited-only\",\"hidden_quota_widgets\":[\"\"],\"hidden_app_tabs\":{\"settings\":[\"\"],\"customer_profile\":[\"\"],\"project\":[\"\"]},\"allow_customization\":\"yes\",\"disable_module_marketplace\":\"no\",\"disable_service_marketplace\":\"no\",\"assigned_clients\":[\"\"],\"seeding_tenant\":\"\",\"auto_remove_inactive_instance\":\"no\",\"auto_remove_inactive_instance_days\":\"30\",\"enable_custom_domain\":\"\",\"is_liftetime_deal\":\"\"}',7),
(3,'Business Pro Plan','<p><strong>Built for mid-sized enterprises needing automation &amp; AI</strong></p>\n<p><strong>Everything in Growth, plus:</strong></p>\n<ul>\n<li>\n<ul>\n<li>\n<p>Unlimited users (upto 15 )</p>\n</li>\n<li>\n<p>Advanced Modules (Project Mgmt, Asset Mgmt, Payroll)</p>\n</li>\n<li>\n<p>AI Reports &amp; Forecasting</p>\n</li>\n<li>\n<p>Advanced Vision AI Tools (e.g., Student/Employee Tracking, CCTV Monitoring Integration)</p>\n</li>\n<li>\n<p>Role-Based Access Control</p>\n</li>\n<li>\n<p>50GB File Storage</p>\n</li>\n<li>\n<p>Priority Support with WhatsApp</p>\n</li>\n</ul>\n</li>\n</ul>','growth_plan_3',18000.00,NULL,0,0,'mysql_root','dbb1e2b681f6636bb130e0db6740a1ac8ff6f3f907e518d24603ae52f4624b2e41a35ad6968df72763f52b15f46a5d854b49b3042df255868501586bcf7a06a5b80mHKbW6EX1d8ZO1U1i/JUSc2zu4yjlfDaluGlqLLE=',1,'[\"\",\"account_planning\",\"accounting\",\"affiliate_management\",\"appointly\",\"aws_integration\",\"exports\",\"loyalty\",\"backup\",\"facebook_leads_integration\",\"fixed_equipment\",\"fleet\",\"flexstage\",\"flexibackup\",\"goals\",\"hr_payroll\",\"hr_profile\",\"si_lead_followup\",\"mailbox\",\"mailflow\",\"si_custom_status\",\"manufacturing\",\"ma\",\"menu_setup\",\"mfa\",\"perfex_office_theme\",\"omni_sales\",\"project_roadmap\",\"purchase\",\"quickbooks_integration\",\"recruitment\",\"resource_workload\",\"surveys\",\"theme_style\",\"timesheets\",\"user_mention\",\"warehouse\",\"webhooks\",\"whatsapp_api\",\"whatsbot\"]','{\"invoice\":{\"recurring\":\"1\",\"repeat_every_custom\":\"1\",\"repeat_type_custom\":\"day\",\"allowed_payment_modes\":[\"1\"],\"sale_agent\":\"\"},\"client_theme\":\"single\",\"enable_subdomain\":\"1\",\"show_modules_list\":\"yes\",\"show_limits_on_package\":\"yes_3\",\"disabled_default_modules\":[\"\"],\"max_instance_limit\":\"1\",\"limitations_unit_price\":{\"tenant_instance\":\"\",\"staff\":\"\",\"clients\":\"\",\"contacts\":\"\",\"contracts\":\"\",\"invoices\":\"2000\",\"estimates\":\"\",\"creditnotes\":\"\",\"proposals\":\"\",\"projects\":\"\",\"tasks\":\"\",\"tickets\":\"\",\"leads\":\"\",\"items\":\"\"},\"resource_limit_period\":\"lifetime\",\"limitations\":{\"staff\":\"15\",\"clients\":\"150\",\"contacts\":\"-1\",\"contracts\":\"-1\",\"invoices\":\"150\",\"estimates\":\"148\",\"creditnotes\":\"-1\",\"proposals\":\"-1\",\"projects\":\"150\",\"tasks\":\"-1\",\"tickets\":\"-1\",\"leads\":\"-1\",\"items\":\"-1\"},\"storage_limit\":{\"size\":\"-1\",\"unit\":\"MB\",\"unit_price\":\"\"},\"dashboard_quota_visibility\":\"limited-only\",\"hidden_quota_widgets\":[\"\"],\"hidden_app_tabs\":{\"settings\":[\"\"],\"customer_profile\":[\"\"],\"project\":[\"\"]},\"allow_customization\":\"yes\",\"disable_module_marketplace\":\"no\",\"disable_service_marketplace\":\"no\",\"assigned_clients\":[\"\"],\"seeding_tenant\":\"\",\"auto_remove_inactive_instance\":\"no\",\"auto_remove_inactive_instance_days\":\"30\",\"enable_custom_domain\":\"\",\"is_liftetime_deal\":\"\"}',7),
(4,'Enterprise AI Plan – Custom Pricing','<h3><strong>Enterprise AI Plan</strong> &#8211; Custom Pricing</h3>\n<p><strong>Tailored for large institutions or government projects</strong></p>\n<p><strong>Everything in Pro, plus:</strong></p>\n<ul>\n<li>\n<p>Custom Module Development</p>\n</li>\n<li>\n<p>Dedicated Account Manager</p>\n</li>\n<li>\n<p>White-labeled Solution</p>\n</li>\n<li>\n<p>On-Premise or Private Cloud Deployment</p>\n</li>\n<li>\n<p>99.9% SLA Guarantee</p>\n</li>\n<li>\n<p>Unlimited Storage</p>\n</li>\n<li>\n<p>Full Vision AI Suite + Audio/Voice Processing</p>\n</li>\n<li>\n<p>24x7 Dedicated Support &amp; Training</p>\n</li>\n</ul>','business_pro_plan_4',22000.00,NULL,0,0,'mysql_root','828cb35e4a329dc2dcb590ff249306914e8359663646be5ff48f204328221e1117b657ac59de40da094e40f7505a8b8fc3e58050b15abc81f3210ebbf06c34abXTfzeeK1rZHV0b36ZuEa+pEf0H+j0XZOvhUNJEvpwug=',1,'[\"\",\"account_planning\",\"accounting\",\"affiliate_management\",\"appointly\",\"aws_integration\",\"exports\",\"loyalty\",\"backup\",\"facebook_leads_integration\",\"fixed_equipment\",\"fleet\",\"flexstage\",\"flexibackup\",\"goals\",\"hr_payroll\",\"hr_profile\",\"si_lead_followup\",\"mailbox\",\"mailflow\",\"si_custom_status\",\"manufacturing\",\"ma\",\"menu_setup\",\"mfa\",\"perfex_office_theme\",\"omni_sales\",\"project_roadmap\",\"purchase\",\"quickbooks_integration\",\"recruitment\",\"resource_workload\",\"surveys\",\"theme_style\",\"timesheets\",\"user_mention\",\"warehouse\",\"webhooks\",\"whatsapp_api\",\"whatsbot\"]','{\"invoice\":{\"recurring\":\"1\",\"repeat_every_custom\":\"1\",\"repeat_type_custom\":\"day\",\"allowed_payment_modes\":[\"1\"],\"sale_agent\":\"\"},\"client_theme\":\"single\",\"enable_subdomain\":\"1\",\"show_modules_list\":\"yes\",\"show_limits_on_package\":\"yes_3\",\"disabled_default_modules\":[\"\"],\"max_instance_limit\":\"1\",\"limitations_unit_price\":{\"tenant_instance\":\"\",\"staff\":\"\",\"clients\":\"\",\"contacts\":\"\",\"contracts\":\"\",\"invoices\":\"2000\",\"estimates\":\"\",\"creditnotes\":\"\",\"proposals\":\"\",\"projects\":\"\",\"tasks\":\"\",\"tickets\":\"\",\"leads\":\"\",\"items\":\"\"},\"resource_limit_period\":\"lifetime\",\"limitations\":{\"staff\":\"20\",\"clients\":\"200\",\"contacts\":\"-1\",\"contracts\":\"-1\",\"invoices\":\"200\",\"estimates\":\"200\",\"creditnotes\":\"-1\",\"proposals\":\"-1\",\"projects\":\"200\",\"tasks\":\"1000\",\"tickets\":\"-1\",\"leads\":\"-1\",\"items\":\"1000\"},\"storage_limit\":{\"size\":\"-1\",\"unit\":\"MB\",\"unit_price\":\"\"},\"dashboard_quota_visibility\":\"limited-only\",\"hidden_quota_widgets\":[\"\"],\"hidden_app_tabs\":{\"settings\":[\"\"],\"customer_profile\":[\"\"],\"project\":[\"\"]},\"allow_customization\":\"yes\",\"disable_module_marketplace\":\"no\",\"disable_service_marketplace\":\"no\",\"assigned_clients\":[\"\"],\"seeding_tenant\":\"\",\"auto_remove_inactive_instance\":\"no\",\"auto_remove_inactive_instance_days\":\"30\",\"enable_custom_domain\":\"\",\"is_liftetime_deal\":\"\"}',7);
/*!40000 ALTER TABLE `tblperfex_saas_packages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblpinned_projects`
--

DROP TABLE IF EXISTS `tblpinned_projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblpinned_projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblpinned_projects`
--

LOCK TABLES `tblpinned_projects` WRITE;
/*!40000 ALTER TABLE `tblpinned_projects` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblpinned_projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblposition_training_question_form`
--

DROP TABLE IF EXISTS `tblposition_training_question_form`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblposition_training_question_form` (
  `questionid` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) DEFAULT NULL,
  `question` mediumtext NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT 0,
  `question_order` int(11) NOT NULL,
  `point` int(11) NOT NULL,
  PRIMARY KEY (`questionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblposition_training_question_form`
--

LOCK TABLES `tblposition_training_question_form` WRITE;
/*!40000 ALTER TABLE `tblposition_training_question_form` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblposition_training_question_form` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblproject_activity`
--

DROP TABLE IF EXISTS `tblproject_activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblproject_activity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL DEFAULT 0,
  `contact_id` int(11) NOT NULL DEFAULT 0,
  `fullname` varchar(100) DEFAULT NULL,
  `visible_to_customer` int(11) NOT NULL DEFAULT 0,
  `description_key` varchar(191) NOT NULL COMMENT 'Language file key',
  `additional_data` mediumtext DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblproject_activity`
--

LOCK TABLES `tblproject_activity` WRITE;
/*!40000 ALTER TABLE `tblproject_activity` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblproject_activity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblproject_files`
--

DROP TABLE IF EXISTS `tblproject_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblproject_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file_name` varchar(191) NOT NULL,
  `original_file_name` longtext DEFAULT NULL,
  `subject` varchar(191) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `filetype` varchar(50) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  `last_activity` datetime DEFAULT NULL,
  `project_id` int(11) NOT NULL,
  `visible_to_customer` tinyint(1) DEFAULT 0,
  `staffid` int(11) NOT NULL,
  `contact_id` int(11) NOT NULL DEFAULT 0,
  `external` varchar(40) DEFAULT NULL,
  `external_link` mediumtext DEFAULT NULL,
  `thumbnail_link` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblproject_files`
--

LOCK TABLES `tblproject_files` WRITE;
/*!40000 ALTER TABLE `tblproject_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblproject_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblproject_members`
--

DROP TABLE IF EXISTS `tblproject_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblproject_members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`),
  KEY `staff_id` (`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblproject_members`
--

LOCK TABLES `tblproject_members` WRITE;
/*!40000 ALTER TABLE `tblproject_members` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblproject_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblproject_notes`
--

DROP TABLE IF EXISTS `tblproject_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblproject_notes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `content` mediumtext NOT NULL,
  `staff_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblproject_notes`
--

LOCK TABLES `tblproject_notes` WRITE;
/*!40000 ALTER TABLE `tblproject_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblproject_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblproject_settings`
--

DROP TABLE IF EXISTS `tblproject_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblproject_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `value` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblproject_settings`
--

LOCK TABLES `tblproject_settings` WRITE;
/*!40000 ALTER TABLE `tblproject_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblproject_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblprojectdiscussioncomments`
--

DROP TABLE IF EXISTS `tblprojectdiscussioncomments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblprojectdiscussioncomments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `discussion_id` int(11) NOT NULL,
  `discussion_type` varchar(10) NOT NULL,
  `parent` int(11) DEFAULT NULL,
  `created` datetime NOT NULL,
  `modified` datetime DEFAULT NULL,
  `content` mediumtext NOT NULL,
  `staff_id` int(11) NOT NULL,
  `contact_id` int(11) DEFAULT 0,
  `fullname` varchar(191) DEFAULT NULL,
  `file_name` varchar(191) DEFAULT NULL,
  `file_mime_type` varchar(70) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblprojectdiscussioncomments`
--

LOCK TABLES `tblprojectdiscussioncomments` WRITE;
/*!40000 ALTER TABLE `tblprojectdiscussioncomments` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblprojectdiscussioncomments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblprojectdiscussions`
--

DROP TABLE IF EXISTS `tblprojectdiscussions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblprojectdiscussions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `subject` varchar(191) NOT NULL,
  `description` mediumtext NOT NULL,
  `show_to_customer` tinyint(1) NOT NULL DEFAULT 0,
  `datecreated` datetime NOT NULL,
  `last_activity` datetime DEFAULT NULL,
  `staff_id` int(11) NOT NULL DEFAULT 0,
  `contact_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblprojectdiscussions`
--

LOCK TABLES `tblprojectdiscussions` WRITE;
/*!40000 ALTER TABLE `tblprojectdiscussions` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblprojectdiscussions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblprojects`
--

DROP TABLE IF EXISTS `tblprojects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblprojects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `clientid` int(11) NOT NULL,
  `billing_type` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `deadline` date DEFAULT NULL,
  `project_created` date NOT NULL,
  `date_finished` datetime DEFAULT NULL,
  `progress` int(11) DEFAULT 0,
  `progress_from_tasks` int(11) NOT NULL DEFAULT 1,
  `project_cost` decimal(15,2) DEFAULT NULL,
  `project_rate_per_hour` decimal(15,2) DEFAULT NULL,
  `estimated_hours` decimal(15,2) DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `contact_notification` int(11) DEFAULT 1,
  `notify_contacts` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblprojects`
--

LOCK TABLES `tblprojects` WRITE;
/*!40000 ALTER TABLE `tblprojects` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblprojects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblproposal_comments`
--

DROP TABLE IF EXISTS `tblproposal_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblproposal_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` longtext DEFAULT NULL,
  `proposalid` int(11) NOT NULL,
  `staffid` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblproposal_comments`
--

LOCK TABLES `tblproposal_comments` WRITE;
/*!40000 ALTER TABLE `tblproposal_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblproposal_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblproposals`
--

DROP TABLE IF EXISTS `tblproposals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblproposals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(191) DEFAULT NULL,
  `content` longtext DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `datecreated` datetime NOT NULL,
  `total` decimal(15,2) DEFAULT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `total_tax` decimal(15,2) NOT NULL DEFAULT 0.00,
  `adjustment` decimal(15,2) DEFAULT NULL,
  `discount_percent` decimal(15,2) NOT NULL,
  `discount_total` decimal(15,2) NOT NULL,
  `discount_type` varchar(30) DEFAULT NULL,
  `show_quantity_as` int(11) NOT NULL DEFAULT 1,
  `currency` int(11) NOT NULL,
  `open_till` date DEFAULT NULL,
  `date` date NOT NULL,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(40) DEFAULT NULL,
  `assigned` int(11) DEFAULT NULL,
  `hash` varchar(32) NOT NULL,
  `proposal_to` varchar(191) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  `country` int(11) NOT NULL DEFAULT 0,
  `zip` varchar(50) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `allow_comments` tinyint(1) NOT NULL DEFAULT 1,
  `status` int(11) NOT NULL,
  `estimate_id` int(11) DEFAULT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `date_converted` datetime DEFAULT NULL,
  `pipeline_order` int(11) DEFAULT 1,
  `is_expiry_notified` int(11) NOT NULL DEFAULT 0,
  `acceptance_firstname` varchar(50) DEFAULT NULL,
  `acceptance_lastname` varchar(50) DEFAULT NULL,
  `acceptance_email` varchar(100) DEFAULT NULL,
  `acceptance_date` datetime DEFAULT NULL,
  `acceptance_ip` varchar(40) DEFAULT NULL,
  `signature` varchar(40) DEFAULT NULL,
  `short_link` varchar(100) DEFAULT NULL,
  `processing` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblproposals`
--

LOCK TABLES `tblproposals` WRITE;
/*!40000 ALTER TABLE `tblproposals` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblproposals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblpur_vendor`
--

DROP TABLE IF EXISTS `tblpur_vendor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblpur_vendor` (
  `userid` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `company` varchar(200) DEFAULT NULL,
  `vat` varchar(200) DEFAULT NULL,
  `phonenumber` varchar(30) DEFAULT NULL,
  `country` int(11) NOT NULL DEFAULT 0,
  `city` varchar(100) DEFAULT NULL,
  `zip` varchar(15) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `website` varchar(150) DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `active` int(11) NOT NULL DEFAULT 1,
  `leadid` int(11) DEFAULT NULL,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT 0,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT 0,
  `longitude` varchar(191) DEFAULT NULL,
  `latitude` varchar(191) DEFAULT NULL,
  `default_language` varchar(40) DEFAULT NULL,
  `default_currency` int(11) NOT NULL DEFAULT 0,
  `show_primary_contact` int(11) NOT NULL DEFAULT 0,
  `stripe_id` varchar(40) DEFAULT NULL,
  `registration_confirmed` int(11) NOT NULL DEFAULT 1,
  `addedfrom` int(11) NOT NULL DEFAULT 0,
  `category` text DEFAULT NULL,
  `bank_detail` text DEFAULT NULL,
  `payment_terms` text DEFAULT NULL,
  `vendor_code` varchar(100) DEFAULT NULL,
  `return_within_day` int(11) DEFAULT NULL,
  `return_order_fee` decimal(15,2) DEFAULT NULL,
  `return_policies` text DEFAULT NULL,
  `balance` decimal(15,2) DEFAULT NULL,
  `balance_as_of` date DEFAULT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblpur_vendor`
--

LOCK TABLES `tblpur_vendor` WRITE;
/*!40000 ALTER TABLE `tblpur_vendor` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblpur_vendor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblrec_criteria`
--

DROP TABLE IF EXISTS `tblrec_criteria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblrec_criteria` (
  `criteria_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `criteria_type` varchar(45) NOT NULL,
  `criteria_title` varchar(200) NOT NULL,
  `group_criteria` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  `add_date` date DEFAULT NULL,
  `score_des1` text DEFAULT NULL,
  `score_des2` text DEFAULT NULL,
  `score_des3` text DEFAULT NULL,
  `score_des4` text DEFAULT NULL,
  `score_des5` text DEFAULT NULL,
  PRIMARY KEY (`criteria_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblrec_criteria`
--

LOCK TABLES `tblrec_criteria` WRITE;
/*!40000 ALTER TABLE `tblrec_criteria` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblrec_criteria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblrec_job_position`
--

DROP TABLE IF EXISTS `tblrec_job_position`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblrec_job_position` (
  `position_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `position_name` varchar(200) NOT NULL,
  `position_description` text DEFAULT NULL,
  PRIMARY KEY (`position_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblrec_job_position`
--

LOCK TABLES `tblrec_job_position` WRITE;
/*!40000 ALTER TABLE `tblrec_job_position` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblrec_job_position` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblrec_set_transfer_record`
--

DROP TABLE IF EXISTS `tblrec_set_transfer_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblrec_set_transfer_record` (
  `set_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `send_to` varchar(45) NOT NULL,
  `email_to` text DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  `add_date` date NOT NULL,
  `subject` text NOT NULL,
  `content` text DEFAULT NULL,
  `order` int(11) NOT NULL,
  PRIMARY KEY (`set_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblrec_set_transfer_record`
--

LOCK TABLES `tblrec_set_transfer_record` WRITE;
/*!40000 ALTER TABLE `tblrec_set_transfer_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblrec_set_transfer_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblrec_transfer_records`
--

DROP TABLE IF EXISTS `tblrec_transfer_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblrec_transfer_records` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `firstname` varchar(100) DEFAULT NULL,
  `lastname` varchar(100) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `gender` varchar(11) DEFAULT NULL,
  `staff_identifi` varchar(20) DEFAULT NULL,
  `creator` int(11) DEFAULT NULL,
  `datecreator` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblrec_transfer_records`
--

LOCK TABLES `tblrec_transfer_records` WRITE;
/*!40000 ALTER TABLE `tblrec_transfer_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblrec_transfer_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblrecords_meta`
--

DROP TABLE IF EXISTS `tblrecords_meta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblrecords_meta` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) DEFAULT NULL,
  `meta` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblrecords_meta`
--

LOCK TABLES `tblrecords_meta` WRITE;
/*!40000 ALTER TABLE `tblrecords_meta` DISABLE KEYS */;
INSERT INTO `tblrecords_meta` VALUES
(1,'staff_identifi','staff_identifi'),
(2,'firstname','firstname'),
(3,'email','email'),
(4,'phonenumber','phonenumber'),
(5,'facebook','facebook'),
(6,'skype','skype'),
(7,'birthday','birthday'),
(8,'birthplace','birthplace'),
(9,'home_town','home_town'),
(10,'marital_status','marital_status'),
(11,'nation','nation'),
(12,'religion','religion'),
(13,'identification','identification'),
(14,'days_for_identity','days_for_identity'),
(15,'place_of_issue','place_of_issue'),
(16,'resident','resident'),
(17,'current_address','current_address'),
(18,'literacy','literacy');
/*!40000 ALTER TABLE `tblrecords_meta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblrelated_items`
--

DROP TABLE IF EXISTS `tblrelated_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblrelated_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(30) NOT NULL,
  `item_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblrelated_items`
--

LOCK TABLES `tblrelated_items` WRITE;
/*!40000 ALTER TABLE `tblrelated_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblrelated_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblreminders`
--

DROP TABLE IF EXISTS `tblreminders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblreminders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` mediumtext DEFAULT NULL,
  `date` datetime NOT NULL,
  `isnotified` int(11) NOT NULL DEFAULT 0,
  `rel_id` int(11) NOT NULL,
  `staff` int(11) NOT NULL,
  `rel_type` varchar(40) NOT NULL,
  `notify_by_email` int(11) NOT NULL DEFAULT 1,
  `creator` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`),
  KEY `staff` (`staff`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblreminders`
--

LOCK TABLES `tblreminders` WRITE;
/*!40000 ALTER TABLE `tblreminders` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblreminders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblroles`
--

DROP TABLE IF EXISTS `tblroles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblroles` (
  `roleid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `permissions` longtext DEFAULT NULL,
  PRIMARY KEY (`roleid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblroles`
--

LOCK TABLES `tblroles` WRITE;
/*!40000 ALTER TABLE `tblroles` DISABLE KEYS */;
INSERT INTO `tblroles` VALUES
(1,'Employee',NULL);
/*!40000 ALTER TABLE `tblroles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblsales_activity`
--

DROP TABLE IF EXISTS `tblsales_activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblsales_activity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_type` varchar(20) DEFAULT NULL,
  `rel_id` int(11) NOT NULL,
  `description` mediumtext NOT NULL,
  `additional_data` mediumtext DEFAULT NULL,
  `staffid` varchar(11) DEFAULT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblsales_activity`
--

LOCK TABLES `tblsales_activity` WRITE;
/*!40000 ALTER TABLE `tblsales_activity` DISABLE KEYS */;
INSERT INTO `tblsales_activity` VALUES
(1,'invoice',1,'invoice_activity_created','','0','','2025-06-27 13:15:14');
/*!40000 ALTER TABLE `tblsales_activity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblscheduled_emails`
--

DROP TABLE IF EXISTS `tblscheduled_emails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblscheduled_emails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(15) NOT NULL,
  `scheduled_at` datetime NOT NULL,
  `contacts` varchar(197) NOT NULL,
  `cc` mediumtext DEFAULT NULL,
  `attach_pdf` tinyint(1) NOT NULL DEFAULT 1,
  `template` varchar(197) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblscheduled_emails`
--

LOCK TABLES `tblscheduled_emails` WRITE;
/*!40000 ALTER TABLE `tblscheduled_emails` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblscheduled_emails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblservices`
--

DROP TABLE IF EXISTS `tblservices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblservices` (
  `serviceid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`serviceid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblservices`
--

LOCK TABLES `tblservices` WRITE;
/*!40000 ALTER TABLE `tblservices` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblservices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblsessions`
--

DROP TABLE IF EXISTS `tblsessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblsessions` (
  `id` varchar(128) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT 0,
  `data` blob NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ci_sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblsessions`
--

LOCK TABLES `tblsessions` WRITE;
/*!40000 ALTER TABLE `tblsessions` DISABLE KEYS */;
INSERT INTO `tblsessions` VALUES
('001c5e73a98d2a17442f5cf01ba49ef945723942','127.0.0.1',1750911610,'__ci_last_regenerate|i:1750911609;red_url|s:21:\"https://82.29.165.22/\";'),
('001eda2ccddd8d146b9e41ed97ae16659e62b09d','2a02:4780:12:bfc5::1',1751150102,'__ci_last_regenerate|i:1751150102;'),
('002fe115db43aa8ca3ba44176132b0c4127040c8','82.29.165.22',1750871102,'__ci_last_regenerate|i:1750871102;'),
('003442925de15a552eea7a627f5414935631507b','82.29.165.22',1750960808,'__ci_last_regenerate|i:1750960802;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('00551de0803be8c19b9d3859eeba07cbea4c26e5','82.29.165.22',1750944901,'__ci_last_regenerate|i:1750944901;'),
('00c4ab04173bb586d0b0691c70d3997824366caa','82.29.165.22',1750996806,'__ci_last_regenerate|i:1750996802;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('00cfd672c43d35e7c21061e8623f885c93387d6f','82.29.165.22',1750870501,'__ci_last_regenerate|i:1750870501;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('00d98727650966664dccf523c8c03485fd8afc04','157.48.80.182',1750869177,'__ci_last_regenerate|i:1750869177;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;'),
('00f49f36523bd53d2106c968f5eca0b7a5f974f4','127.0.0.1',1750854707,'__ci_last_regenerate|i:1750854707;red_url|s:21:\"https://82.29.165.22/\";'),
('010d39c2a3731da0bf72e8dd75bbed53c8e3f6dc','157.48.82.220',1750922841,'__ci_last_regenerate|i:1750922841;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('013e24c27d28dc32099d320be2b3373d29301742','127.0.0.1',1750875407,'__ci_last_regenerate|i:1750875407;red_url|s:21:\"https://82.29.165.22/\";'),
('016d2f6aca5b0e6495a004851f96e3784e21d022','127.0.0.1',1750888007,'__ci_last_regenerate|i:1750888007;red_url|s:21:\"https://82.29.165.22/\";'),
('018da29523c372b98830b7520146e1f2a4767249','2a02:4780:12:bfc5::1',1751085302,'__ci_last_regenerate|i:1751085302;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('018e1c92808cfca0dabba4d9660c8bd5fbbb9832','2a02:4780:12:bfc5::1',1751038501,'__ci_last_regenerate|i:1751038501;'),
('01cea6dabe30e6cbc23429b58f2b52f4d0bec286','45.135.193.162',1750884427,'__ci_last_regenerate|i:1750884427;red_url|s:21:\"https://82.29.165.22/\";'),
('01f4c7066822cd75800183bf72f3f71fc60540de','2a02:4780:12:bfc5::1',1751067302,'__ci_last_regenerate|i:1751067302;'),
('02115542be840e33a72ac443a49b1bfd3d0138db','127.0.0.1',1750938710,'__ci_last_regenerate|i:1750938710;red_url|s:21:\"https://82.29.165.22/\";'),
('023fa3897d7921b3fbde6a56293f617fbcef4b69','45.135.193.162',1750884427,'__ci_last_regenerate|i:1750884427;red_url|s:21:\"https://82.29.165.22/\";'),
('02b88904f5e200bf6224eedc11b5334a046033dd','127.0.0.1',1750862210,'__ci_last_regenerate|i:1750862210;red_url|s:21:\"https://82.29.165.22/\";'),
('02cf8dbf6212509004fa3e3bfedb855320ef8476','82.29.165.22',1750980604,'__ci_last_regenerate|i:1750980601;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('032a80a330109d1441d2e70f6401cd7bd5b2e9db','82.29.165.22',1750853401,'__ci_last_regenerate|i:1750853401;'),
('03391cf03e3aed7f3f91735ed7fa375d6018638c','2a02:4780:12:bfc5::1',1751115002,'__ci_last_regenerate|i:1751115002;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('034b674e9efbc6d26d7fd7774455f7a3c95a0e9f','127.0.0.1',1750939676,'__ci_last_regenerate|i:1750939676;red_url|s:21:\"https://82.29.165.22/\";'),
('0384f2ce79198769b9163ad390a19f106be43e7a','2a02:4780:12:bfc5::1',1751132703,'__ci_last_regenerate|i:1751132702;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('03972cbc7d30a839d9d12c5c0df2a16be8ddc509','82.29.165.22',1750927504,'__ci_last_regenerate|i:1750927502;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('03c0a6e3b5d7a9b87ec8d255ebae363935422ae6','2a02:4780:12:bfc5::1',1751049302,'__ci_last_regenerate|i:1751049302;'),
('03cb4e344698d79a36d3d980577b308066c62ff5','45.135.193.162',1750884424,'__ci_last_regenerate|i:1750884424;red_url|s:21:\"https://82.29.165.22/\";'),
('03ddcc6ea284997aede44097317e5967aa85d478','82.29.165.22',1750926904,'__ci_last_regenerate|i:1750926901;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('03fc189b3ce27a3a16392347180b5bbec68dcaa3','82.29.165.22',1750871701,'__ci_last_regenerate|i:1750871701;'),
('043915f6d27e95b5588bee1470ec6f54f34161c3','157.48.80.182',1750902534,'__ci_last_regenerate|i:1750902534;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;'),
('04746d6b6dd514e61925fa16c68cfbade44b2ec9','82.29.165.22',1750852502,'__ci_last_regenerate|i:1750852502;'),
('048801b62cbff29b59105aa1f084be7471715073','82.29.165.22',1750978807,'__ci_last_regenerate|i:1750978803;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('0507e25d945914af0173b3cc377f456ead078d59','127.0.0.1',1750882208,'__ci_last_regenerate|i:1750882208;red_url|s:21:\"https://82.29.165.22/\";'),
('0549eafb9f9f92a73ee7bee8afa1b4bc1047c8e3','2409:40d4:10cd:43f8:f408:13f9:e02c:5190',1751011371,'__ci_last_regenerate|i:1751011371;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"old\";}'),
('057237aa9ea7b565b5c80b53a186b458901e465b','107.172.195.209',1751021279,'__ci_last_regenerate|i:1751021276;red_url|s:22:\"https://techdotbit.in/\";'),
('057313cb4e05f11fad4252f1c63e97e4c691734f','82.29.165.22',1750895102,'__ci_last_regenerate|i:1750895102;'),
('05deb6ff5936ff016260e3b1a516aab6140cd746','2a02:4780:12:bfc5::1',1751011502,'__ci_last_regenerate|i:1751011502;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('0628d8eecee803da79422fb34e4e5a9cd4af2a8c','2a02:4780:12:bfc5::1',1751049002,'__ci_last_regenerate|i:1751049001;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('06c39991a4df23a2417b61ab82c6400b2adf6ca7','82.29.165.22',1750996501,'__ci_last_regenerate|i:1750996501;'),
('06d8bc7586ecbcb601b72907272a3916c30eca48','207.46.13.64',1751151466,'__ci_last_regenerate|i:1751151464;'),
('0720e2191d327ac551002bf4dcb65c194b3262eb','127.0.0.1',1750903810,'__ci_last_regenerate|i:1750903810;red_url|s:21:\"https://82.29.165.22/\";'),
('072cadb8d0028aa50900afd43f70456f78266241','2a02:4780:12:bfc5::1',1751068502,'__ci_last_regenerate|i:1751068501;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('072f695104d1763b4bf85c1bb5bfd8dc47196a29','82.29.165.22',1750905604,'__ci_last_regenerate|i:1750905602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('07794abd55d623f01cf2aafc81daead16f0cb8cd','82.29.165.22',1750984804,'__ci_last_regenerate|i:1750984802;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('0794442b590258aafc84b9a523d7db87149abf1b','127.0.0.1',1750942804,'__ci_last_regenerate|i:1750942804;red_url|s:21:\"https://82.29.165.22/\";'),
('07b668b57f4ff873a87b5b40a25a1649234ecbc0','193.32.126.215',1750906622,'__ci_last_regenerate|i:1750906622;is_mobile|b:1;red_url|s:21:\"https://82.29.165.22/\";'),
('07c35f5d8806a839f7fea4863bbd2edb83021348','82.29.165.22',1750964407,'__ci_last_regenerate|i:1750964402;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('0805dcc5e2e4470dd5c12cdda8cdf97c67056e32','2a02:4780:12:bfc5::1',1751128502,'__ci_last_regenerate|i:1751128502;'),
('084aa43b8f53c0bb5704d5bb026a010b141f19b1','127.0.0.1',1750981607,'__ci_last_regenerate|i:1750981607;red_url|s:21:\"https://82.29.165.22/\";'),
('087075747471c7b92a9b43132a9fc39b7c91367a','2a02:4780:12:bfc5::1',1751013004,'__ci_last_regenerate|i:1751013003;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('08a3d14e9628946522af11d9d21cf188fa64485e','2a02:4780:12:bfc5::1',1751106602,'__ci_last_regenerate|i:1751106602;'),
('09299ee2b422772d9ac64b30f8a78d5b33261edf','127.0.0.1',1750990208,'__ci_last_regenerate|i:1750990208;red_url|s:21:\"https://82.29.165.22/\";'),
('092e417121e083a2ffad0ad9eea769849cfb5b9f','82.29.165.22',1750968604,'__ci_last_regenerate|i:1750968602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('0949b1b3692f920a69163812f0d6389035c8647b','2a02:4780:12:bfc5::1',1751086201,'__ci_last_regenerate|i:1751086201;'),
('09724759a2bf37bf5fd9810f7fb60429465505c0','2a02:4780:12:bfc5::1',1751101206,'__ci_last_regenerate|i:1751101204;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('09f8caaf0bb64ed52bfecc06ef39372046372290','127.0.0.1',1750986004,'__ci_last_regenerate|i:1750986003;red_url|s:21:\"https://82.29.165.22/\";'),
('0a0275da5c1ec013edaad485a090924225a0fd1f','127.0.0.1',1750974407,'__ci_last_regenerate|i:1750974407;red_url|s:21:\"https://82.29.165.22/\";'),
('0a051ea37317b761d4526a13f1ad634fa8d83ac9','2a02:4780:12:bfc5::1',1751044202,'__ci_last_regenerate|i:1751044202;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('0a068da74f49db41336273148b306f6d3fb2134b','2a02:4780:12:bfc5::1',1751070902,'__ci_last_regenerate|i:1751070901;'),
('0a1c99cacf321f97df0d9dc9a22d650cc04647e6','82.29.165.22',1750974603,'__ci_last_regenerate|i:1750974602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('0a4fb6d4a228bf054d622ed0799b2c51662c6ee6','82.29.165.22',1750913701,'__ci_last_regenerate|i:1750913701;'),
('0a50dbd3369bdeb490a05215ea47990863f56060','2a02:4780:12:bfc5::1',1751006403,'__ci_last_regenerate|i:1751006402;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('0a72ccfe79a9fc9bd2d404d06a0d50a38a82eed8','2a02:4780:12:bfc5::1',1751167802,'__ci_last_regenerate|i:1751167801;'),
('0a7e7e87a4144a7c5698201a99db362464601521','127.0.0.1',1750986306,'__ci_last_regenerate|i:1750986306;red_url|s:21:\"https://82.29.165.22/\";'),
('0a94f1b67ae203e021ca89f7c2afe36f4234b83d','127.0.0.1',1750992709,'__ci_last_regenerate|i:1750992709;red_url|s:21:\"https://82.29.165.22/\";'),
('0b983c1d0c8286ff08176f28c13eccf380550ee9','82.29.165.22',1750933805,'__ci_last_regenerate|i:1750933801;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('0bca72150bc3cf46832b51e6ffd179a52d4b8a13','2a02:4780:12:bfc5::1',1751017502,'__ci_last_regenerate|i:1751017501;'),
('0c5b46a5412b8d04c51ff7af36c4d657cc057bb3','82.29.165.22',1750862101,'__ci_last_regenerate|i:1750862101;'),
('0c6b8a8988ea17fd33581d47115e2409f7e53832','104.252.191.216',1751173616,'__ci_last_regenerate|i:1751173614;red_url|s:22:\"https://techdotbit.in/\";'),
('0c7839fddbed00b9de6dfb30c0c188cfb5cba26c','157.48.80.182',1750866166,'__ci_last_regenerate|i:1750866166;red_url|s:26:\"https://82.29.165.22/admin\";'),
('0c9876600f6229ad4b545998e2ff100632b7246f','127.0.0.1',1750917603,'__ci_last_regenerate|i:1750917603;red_url|s:21:\"https://82.29.165.22/\";'),
('0cb883f6e35040773912f8329a48020560a16c0d','2a02:4780:12:bfc5::1',1751120402,'__ci_last_regenerate|i:1751120402;'),
('0cdaa773e0e19270cb6ce3a202407d6920165bf9','2a02:4780:12:bfc5::1',1751091603,'__ci_last_regenerate|i:1751091603;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('0ce100497665f4c11885db54b4866450cc5445b6','2a02:4780:12:bfc5::1',1751050502,'__ci_last_regenerate|i:1751050501;'),
('0d129961ca1c3e0350a635d9b5ac87592a76fb36','82.29.165.22',1750859702,'__ci_last_regenerate|i:1750859702;'),
('0d195ae5f593f79adbc3ecf97c61a2d66084ad42','82.29.165.22',1750945204,'__ci_last_regenerate|i:1750945201;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('0d28c9f6ea15f30b8fa4d24e5597c6e4b2be7480','2a02:4780:12:bfc5::1',1751155502,'__ci_last_regenerate|i:1751155502;'),
('0d2cabb615c5f4d9201a68da1a0dcde0a0db48d0','2a02:4780:12:bfc5::1',1751023501,'__ci_last_regenerate|i:1751023501;'),
('0d45faf1aef0b427679d2a085134c7c885f63f60','127.0.0.1',1750936626,'__ci_last_regenerate|i:1750936626;red_url|s:21:\"https://82.29.165.22/\";'),
('0d9ad62d6bdccb31d0bd391dcb444231664b1f4d','2a02:4780:12:bfc5::1',1751028002,'__ci_last_regenerate|i:1751028002;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('0dc1166cc8582bd52b404c6bd9a608d41951c24f','127.0.0.1',1750890707,'__ci_last_regenerate|i:1750890707;red_url|s:21:\"https://82.29.165.22/\";'),
('0dc4f85d4e0cc49cdf7e9401d6f57974f742c422','127.0.0.1',1750953606,'__ci_last_regenerate|i:1750953606;red_url|s:21:\"https://82.29.165.22/\";'),
('0dcb0da285b3d20b8a1c49ada2e21214ba14338d','82.29.165.22',1750911004,'__ci_last_regenerate|i:1750911002;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('0df7c11da2088fac0ee76ed7edd8596fc1fbe165','82.29.165.22',1750926601,'__ci_last_regenerate|i:1750926601;'),
('0e1c3458351cd7d9cba857f62c99d796ea70d551','2a02:4780:12:bfc5::1',1751039402,'__ci_last_regenerate|i:1751039402;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('0e1dfc497f3a6a9eb99412dcf81af5fee1677c4a','2a02:4780:12:bfc5::1',1751133902,'__ci_last_regenerate|i:1751133902;'),
('0e61a7f7d37e1c71ed6da7fed910c18fd30e9377','2a02:4780:12:bfc5::1',1751127302,'__ci_last_regenerate|i:1751127302;'),
('0e80a8efd0b95874f64ada65c12337bccf1764b1','82.29.165.22',1750963201,'__ci_last_regenerate|i:1750963201;'),
('0e95741ae52fb20105d5c3f773c412dcf4d13263','82.29.165.22',1750920605,'__ci_last_regenerate|i:1750920602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('0e9c6f0e8a737483d80278c10a71bfadddc294bf','157.48.82.220',1750938054,'__ci_last_regenerate|i:1750938054;red_url|s:38:\"https://82.29.165.22/clients?companies\";'),
('0eaddc5ca875e879bf443f56d8591ad6b2821806','127.0.0.1',1750915907,'__ci_last_regenerate|i:1750915907;red_url|s:21:\"https://82.29.165.22/\";'),
('0eddca0e72a1a9759839daa9552b422d6649f0c4','2a02:4780:12:bfc5::1',1751143202,'__ci_last_regenerate|i:1751143202;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('0f5b48e975c11300d14950f17e7e791b453d771e','2a02:4780:12:bfc5::1',1751048102,'__ci_last_regenerate|i:1751048102;'),
('0f78cb1c4fda94fad7664366e6e898d7cfa4bb83','2a02:4780:12:bfc5::1',1751031602,'__ci_last_regenerate|i:1751031602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('0fd8aa08bff941acaa5281e9c8b836dd19f72939','2a02:4780:12:bfc5::1',1751151603,'__ci_last_regenerate|i:1751151603;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('0fd8aad724e0f643618b4ec016b14441ef9090d9','2a02:4780:12:bfc5::1',1751134203,'__ci_last_regenerate|i:1751134202;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('0feb3bde03bc686a9e7f490013bb8bdab7b00119','127.0.0.1',1750942007,'__ci_last_regenerate|i:1750942007;red_url|s:21:\"https://82.29.165.22/\";'),
('0ff96a8e72464b0754accf321f7eb0bb941253d5','2a02:4780:12:bfc5::1',1751171701,'__ci_last_regenerate|i:1751171701;'),
('100a7ad594814e5ecd33946a9c86ef6a91bfc97d','35.94.22.188',1751011957,'__ci_last_regenerate|i:1751011957;'),
('104164211c6bf515e51f71afa665c58c745fc21f','82.29.165.22',1750916704,'__ci_last_regenerate|i:1750916701;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('105496823f571c097f85faabf4312724a4689be8','2a02:4780:12:bfc5::1',1751171101,'__ci_last_regenerate|i:1751171101;'),
('10af7dbdfd9a84bdcc4297cef383666771b6aab4','82.29.165.22',1750947003,'__ci_last_regenerate|i:1750947001;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('10fee578a59b6be8c649b05a3268a2de0297e155','2a02:4780:12:bfc5::1',1751059502,'__ci_last_regenerate|i:1751059502;'),
('11565335b43389cbd84ec48bf40938232f075780','127.0.0.1',1750965710,'__ci_last_regenerate|i:1750965709;red_url|s:21:\"https://82.29.165.22/\";'),
('1160ca7352981592665986fb0ef5caf618e89c3c','2a02:4780:12:bfc5::1',1751118302,'__ci_last_regenerate|i:1751118302;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('11b1a6e281f962643b191141ea006e8e73659f05','157.48.82.220',1750920248,'__ci_last_regenerate|i:1750920248;red_url|s:38:\"https://82.29.165.22/clients?companies\";'),
('1218176b789d9459338c8535518d297941930d2b','82.29.165.22',1750952102,'__ci_last_regenerate|i:1750952102;'),
('1221fe8f1485c72ad0dc2fcc7d6463e2c4a12eb7','2409:40d4:10cd:43f8:ccef:f512:e762:56b2',1751101997,'__ci_last_regenerate|i:1751101997;staff_user_id|s:1:\"1\";staff_logged_in|b:1;red_url|s:39:\"https://techdotbit.in/clients?companies\";setup-menu-open|b:1;message-danger|s:0:\"\";__ci_vars|a:2:{s:14:\"message-danger\";s:3:\"old\";s:5:\"debug\";s:3:\"new\";}debug|s:852:\"<h1>Your SMTP settings are not set correctly here is the debug log.</h1><br />SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/TroubleshootingSMTP server error: Failed to connect to server SMTP code: 111 Additional SMTP info: Connection refused<br /><pre>\n\n</pre>Connection: opening to smtp.hostinger.com:587, timeout=30, options=array (\n  \'ssl\' => \n  array (\n    \'verify_peer\' => false,\n    \'verify_peer_name\' => false,\n    \'allow_self_signed\' => true,\n  ),\n)<br />Connection failed. Error #2: stream_socket_client(): Unable to connect to smtp.hostinger.com:587 (Connection refused) [/var/www/techdotbit.in/application/vendor/phpmailer/phpmailer/src/SMTP.php line 389]<br />SMTP ERROR: Failed to connect to server: Connection refused (111)<br />SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting<br />\";'),
('126d0540ce1dc16a124bade7f8e38be72de651c9','82.29.165.22',1750938901,'__ci_last_regenerate|i:1750938901;'),
('1284a2b9f98b4d2ac550bc5cc61bad673b64cde1','2a02:4780:12:bfc5::1',1751172602,'__ci_last_regenerate|i:1751172602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('12a831acd403888ef2271413fdff6f323fd4d748','139.162.193.29',1750997605,'__ci_last_regenerate|i:1750997605;'),
('12af7e46c2a4a8513d4503fcb155d08d787ebbea','82.29.165.22',1750903207,'__ci_last_regenerate|i:1750903201;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('12f7ccdcc0d19452ad6b099cc1ea26ac1dcd32ca','127.0.0.1',1750911067,'__ci_last_regenerate|i:1750911067;red_url|s:21:\"https://82.29.165.22/\";'),
('13020a8808321ffe0a4aae461e542b97778a8725','127.0.0.1',1750852310,'__ci_last_regenerate|i:1750852310;red_url|s:21:\"https://82.29.165.22/\";'),
('131f64c7959412318f91f194b4180a2ceb7b7232','127.0.0.1',1750996007,'__ci_last_regenerate|i:1750996007;red_url|s:21:\"https://82.29.165.22/\";'),
('13e9bd4e3f93469afe53e31744326965c444f4f1','82.29.165.22',1750857601,'__ci_last_regenerate|i:1750857601;'),
('13f0964fa26b1794ff54f20c7f749ac373916236','2a02:4780:12:bfc5::1',1751079902,'__ci_last_regenerate|i:1751079902;'),
('13f45966d3d45db9863b3ce88360154b2eb523da','127.0.0.1',1750978803,'__ci_last_regenerate|i:1750978803;red_url|s:21:\"https://82.29.165.22/\";'),
('143845dac6c620459c67f7c2e62056f8da92f181','35.94.22.188',1751011956,'__ci_last_regenerate|i:1751011956;red_url|s:22:\"https://techdotbit.in/\";'),
('143bf6fe1f7ab2617ec8b4b606b14261d28e9033','2a02:4780:12:bfc5::1',1751145902,'__ci_last_regenerate|i:1751145901;'),
('145260408b5c83fd049089cde62c7746958d3ef0','157.48.82.220',1750948493,'__ci_last_regenerate|i:1750948493;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('14b336dcbba50e97b24ab2c29c113fcbaff53945','2a02:4780:12:bfc5::1',1751078402,'__ci_last_regenerate|i:1751078401;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('14b6fea86f19f834886424d8687b577588b666c4','2a02:4780:12:bfc5::1',1751089202,'__ci_last_regenerate|i:1751089202;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('14ced5c3eb0dcaea75f9745cb38991ea3ebd9e35','82.29.165.22',1750922102,'__ci_last_regenerate|i:1750922102;'),
('14ed3b40c56b89270f5fe36db576c281ca411c24','82.29.165.22',1750914605,'__ci_last_regenerate|i:1750914602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('14fd24da6884570cea1f3d5671e8d9ee1efabb8b','2a02:4780:12:bfc5::1',1751165702,'__ci_last_regenerate|i:1751165702;'),
('15168899888e7c16669d474f19d44ea1ee38334c','127.0.0.1',1750949207,'__ci_last_regenerate|i:1750949207;red_url|s:21:\"https://82.29.165.22/\";'),
('1528c78a7f553c180e46f3d889b141307bdd9ad6','2a02:4780:12:bfc5::1',1751153702,'__ci_last_regenerate|i:1751153702;'),
('15412d01d6c5037274452e6386d2dfd3139cd5d4','127.0.0.1',1750954211,'__ci_last_regenerate|i:1750954211;red_url|s:21:\"https://82.29.165.22/\";'),
('155b3587945506aa28532220cd60c07ea5980a1b','2a02:4780:12:bfc5::1',1751113803,'__ci_last_regenerate|i:1751113803;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('15601c5a88e1de962f73bde8782a8b365129e68e','2a02:4780:12:bfc5::1',1751072702,'__ci_last_regenerate|i:1751072702;'),
('1568f644551988346f18235bc4242b13e50eebcd','127.0.0.1',1750850207,'__ci_last_regenerate|i:1750850207;red_url|s:21:\"https://82.29.165.22/\";'),
('15a90d729b0909840f7a38d3abba208b0b8105f4','82.29.165.22',1750882502,'__ci_last_regenerate|i:1750882502;'),
('15b9db11bea580db13a0187071beabe5e627a882','157.48.80.182',1750901209,'__ci_last_regenerate|i:1750901209;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";ps_slug|s:6:\"fecuni\";ps_plan|s:12:\"starter-plan\";red_url|s:38:\"https://82.29.165.22/clients?companies\";ps_custom_domain|s:6:\"fecuni\";'),
('15befd1c83fcc3e6f879f00703607b14b9e3984b','2a02:4780:12:bfc5::1',1751121902,'__ci_last_regenerate|i:1751121901;'),
('15c2689acf621aba62d934b54cf19496df4ccaff','2a02:4780:12:bfc5::1',1751019302,'__ci_last_regenerate|i:1751019302;'),
('15c9e172bded3f3722ad4267a608288985361fce','46.17.174.173',1751159560,'__ci_last_regenerate|i:1751159560;red_url|s:22:\"https://techdotbit.in/\";'),
('15d57a33910f36ea419b2c0d8ee936987550da1e','82.29.165.22',1750967401,'__ci_last_regenerate|i:1750967401;'),
('15f5c94a376eec42f89da26e82167cf22e074dee','82.29.165.22',1750900802,'__ci_last_regenerate|i:1750900801;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('1600e593543636d1906741be1a3a7b51a4966bbd','2a02:4780:12:bfc5::1',1751104502,'__ci_last_regenerate|i:1751104502;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('166a30b51ba23abf44a3dd3e86506381fe050aeb','127.0.0.1',1750856403,'__ci_last_regenerate|i:1750856403;red_url|s:21:\"https://82.29.165.22/\";'),
('16901bb3e1da394d45819805e6352702a1c12d37','127.0.0.1',1750955507,'__ci_last_regenerate|i:1750955507;red_url|s:21:\"https://82.29.165.22/\";'),
('16927c1a3e7a42cf2c260e5258d2d2593c65395b','2a02:4780:12:bfc5::1',1751006702,'__ci_last_regenerate|i:1751006701;'),
('16a63fae9015c6c77979c123f277eca41c3d0fc7','2a02:4780:12:bfc5::1',1751055302,'__ci_last_regenerate|i:1751055302;'),
('16aa41ff093cb527a0477eccebad37db3a257fc1','2a02:4780:12:bfc5::1',1751009101,'__ci_last_regenerate|i:1751009101;'),
('16add7d296ce8ca73871a3dc1bc6b661fa6609cf','2a02:4780:12:bfc5::1',1751157003,'__ci_last_regenerate|i:1751157003;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('16ec8243dea6dd9332ff1423ac318d3c70bec822','157.48.80.182',1750868101,'__ci_last_regenerate|i:1750868101;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;'),
('171e5220634b72e6783ff7903ef2419e30ade304','82.29.165.22',1750943704,'__ci_last_regenerate|i:1750943701;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('172e7e2a57099d01eec7976a7848b6544c62ca84','127.0.0.1',1750995410,'__ci_last_regenerate|i:1750995410;red_url|s:21:\"https://82.29.165.22/\";'),
('172f8cd1477177ea5f9cda16f112492ef4de0955','82.29.165.22',1750893302,'__ci_last_regenerate|i:1750893301;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('174d41ec4aa7a556af5d8501c2c450648ab5f777','127.0.0.1',1750929010,'__ci_last_regenerate|i:1750929010;red_url|s:21:\"https://82.29.165.22/\";'),
('17bfb819ebb705447b5609649bb5224cb6195103','2a02:4780:12:bfc5::1',1751002501,'__ci_last_regenerate|i:1751002501;'),
('17dcc3a11a0417fee04a3a15a7f2dec62ab1112d','127.0.0.1',1750964707,'__ci_last_regenerate|i:1750964707;red_url|s:21:\"https://82.29.165.22/\";'),
('17ddc5f17b01da77aa1d46c302b0777409b1bd16','127.0.0.1',1750944110,'__ci_last_regenerate|i:1750944110;red_url|s:21:\"https://82.29.165.22/\";'),
('1805819ddeff3c86d01a185e040c386a95b216bf','82.29.165.22',1750887001,'__ci_last_regenerate|i:1750887001;'),
('180ca973244ecc1ec41c21b927f3ee0b4860715b','127.0.0.1',1750853107,'__ci_last_regenerate|i:1750853107;red_url|s:21:\"https://82.29.165.22/\";'),
('182c7d35abc0054f13fdfeb6818def6dd7b147a5','2a02:4780:12:bfc5::1',1751076602,'__ci_last_regenerate|i:1751076602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('1840f26dc8cc92ccc7a073595fd0e85ebb661084','82.29.165.22',1750887902,'__ci_last_regenerate|i:1750887901;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('184652b288b3c8cc7799deb71affcc76c94a8627','2a02:4780:12:bfc5::1',1751126403,'__ci_last_regenerate|i:1751126402;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('1851b3a7021d5391be11ac42077d1ddd6b256022','2a02:4780:12:bfc5::1',1751103002,'__ci_last_regenerate|i:1751103001;'),
('185e9553073bc10e66b2b9a8fe30ebed29d35fba','157.48.82.220',1750920947,'__ci_last_regenerate|i:1750920947;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"old\";}'),
('18894c8b25d150e650f8fdc56b33af23134c934a','2a02:4780:12:bfc5::1',1751148302,'__ci_last_regenerate|i:1751148302;'),
('18e8bab1768cc6236cbf4f6901be2c2257ffe752','127.0.0.1',1750917110,'__ci_last_regenerate|i:1750917110;red_url|s:21:\"https://82.29.165.22/\";'),
('190378f8231766bb9a1005efb530d7db1b65fc78','127.0.0.1',1750901507,'__ci_last_regenerate|i:1750901507;red_url|s:21:\"https://82.29.165.22/\";'),
('190a4c699c0ceae98aac07968b07727efa9cace3','127.0.0.1',1750952210,'__ci_last_regenerate|i:1750952210;red_url|s:21:\"https://82.29.165.22/\";'),
('190d7ac606294c95768342277ad8210b6bebd051','82.29.165.22',1750874102,'__ci_last_regenerate|i:1750874102;'),
('193353d1ae1577a4db0c84bc3c3d2e3bd7760ee6','127.0.0.1',1750887107,'__ci_last_regenerate|i:1750887107;red_url|s:21:\"https://82.29.165.22/\";'),
('1946739b3f166685a3502ed21cae8f2ca99d2d16','127.0.0.1',1750924804,'__ci_last_regenerate|i:1750924804;red_url|s:21:\"https://82.29.165.22/\";'),
('194e5dbb1a19c8461fb71cb7077968930714c513','82.29.165.22',1750915203,'__ci_last_regenerate|i:1750915201;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('19820281f43d9d22935de8f291667d936478202a','127.0.0.1',1750860608,'__ci_last_regenerate|i:1750860608;red_url|s:21:\"https://82.29.165.22/\";'),
('19a1aee1861829244628202aed9caccab40929e9','2a02:4780:12:bfc5::1',1751052302,'__ci_last_regenerate|i:1751052302;'),
('19ba72bd0d110e17fca4a387f18bc376c427de9e','127.0.0.1',1750955810,'__ci_last_regenerate|i:1750955810;red_url|s:21:\"https://82.29.165.22/\";'),
('19e4471a23c4e36d6a7c55f2794f9187c6a75927','82.29.165.22',1750979101,'__ci_last_regenerate|i:1750979101;'),
('19f01bbdcc2eccc9becc0ce9dd8443bcaeeb380f','2a02:4780:12:bfc5::1',1751112901,'__ci_last_regenerate|i:1751112901;'),
('1a2ea7f2a2b5234c1a1b2caaebbda44ccd4810ca','2a02:4780:12:bfc5::1',1751071502,'__ci_last_regenerate|i:1751071501;'),
('1a4c70a9a7129c0faeba5924e58cbad4ffe20d8f','82.29.165.22',1750985702,'__ci_last_regenerate|i:1750985702;'),
('1a798a3289350773f50dd510b432e6b43028bded','82.29.165.22',1750896602,'__ci_last_regenerate|i:1750896602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('1ab20a9edf784d1783213ff66004fec811e292a9','82.29.165.22',1750953608,'__ci_last_regenerate|i:1750953602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('1ada5c1c209eaef182d4ac07b6f0e43cc6146795','54.164.157.105',1751087780,'__ci_last_regenerate|i:1751087779;'),
('1b0b679b9b6f1387bc3f13173deda3145dbcd136','157.48.82.220',1750923645,'__ci_last_regenerate|i:1750923645;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('1b0db2dbf070d76c8c4c52172dcacbf10be43c06','82.29.165.22',1750914902,'__ci_last_regenerate|i:1750914902;'),
('1b1ed9b9dd97bc9a9f921dace03d0b5af1669f64','127.0.0.1',1750888802,'__ci_last_regenerate|i:1750888802;red_url|s:21:\"https://82.29.165.22/\";'),
('1b41e105c118d8f0b8deae331646ab35e2545941','2a02:4780:12:bfc5::1',1751125202,'__ci_last_regenerate|i:1751125202;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('1b42fc978d1ebdea858478838d5efcdd86b3519b','2a02:4780:12:bfc5::1',1751054404,'__ci_last_regenerate|i:1751054403;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('1b7275ed24eb1c2b73f61036a00957f57fe8d71b','127.0.0.1',1750854110,'__ci_last_regenerate|i:1750854110;red_url|s:21:\"https://82.29.165.22/\";'),
('1b81ca59af1d977d177cd589cbb296630d767678','194.187.179.188',1750926602,'__ci_last_regenerate|i:1750926601;red_url|s:21:\"https://82.29.165.22/\";'),
('1be2356dda48416202b2b2b9d85d2590fc0620b4','2a02:4780:12:bfc5::1',1751028902,'__ci_last_regenerate|i:1751028902;'),
('1c14be6e0c7e93b0eb570c68fdef2b43a11a08db','2a02:4780:12:bfc5::1',1751137502,'__ci_last_regenerate|i:1751137501;'),
('1c26312f587714b8f4f8bc27f6074122d92ade6f','2a02:4780:12:bfc5::1',1751064902,'__ci_last_regenerate|i:1751064901;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('1c4414b10fef8b0f31b3a78e8fdb260c3f0fd4a3','82.29.165.22',1750958403,'__ci_last_regenerate|i:1750958401;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('1c516cdbf794677cd2772bdaad344be16b306cb1','82.29.165.22',1750850701,'__ci_last_regenerate|i:1750850701;'),
('1c58ef2d5fbadf61dac6ba5d89007e18ea65aaad','82.29.165.22',1750919701,'__ci_last_regenerate|i:1750919701;'),
('1c8d28beb0fb9589a66667b04132edd9c4378fcc','2a02:4780:12:bfc5::1',1751148902,'__ci_last_regenerate|i:1751148902;'),
('1cca51eb67f066ec92745e6834b427082a771d8c','82.29.165.22',1750983601,'__ci_last_regenerate|i:1750983601;'),
('1ce3a712182608a388ff9f43fd4d135bafd4b70e','185.12.250.58',1751132512,'__ci_last_regenerate|i:1751132512;'),
('1d30f361e5db85d6fc87452f6ec7e605cb2b7638','2a02:4780:12:bfc5::1',1751106002,'__ci_last_regenerate|i:1751106002;'),
('1d88af9b0ade889268762e711367aa327ee610ef','34.122.147.229',1751006123,'__ci_last_regenerate|i:1751006115;red_url|s:39:\"https://techdotbit.in/clients?companies\";'),
('1de2339fbcb034788e152818964ec60595409164','157.48.80.182',1750874509,'__ci_last_regenerate|i:1750874509;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";'),
('1df2d0aa74efdb7a42e546148fe7ef535afdf5d7','157.48.221.10',1750998223,'__ci_last_regenerate|i:1750998212;staff_user_id|s:1:\"1\";staff_logged_in|b:1;red_url|s:38:\"https://82.29.165.22/clients?companies\";'),
('1e73cbd14aebef35628464301da265d78c8199d2','82.29.165.22',1750973701,'__ci_last_regenerate|i:1750973701;'),
('1e7849beb769474d7da4fcbcc893a4d1113df500','2a02:4780:12:bfc5::1',1751135404,'__ci_last_regenerate|i:1751135403;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('1e7e02745ab31681a79db90f8aa9fc7e56e4a410','52.167.144.16',1751135523,'__ci_last_regenerate|i:1751135523;'),
('1e8167eb5c122393930434863bd30703c93ee83a','82.29.165.22',1750909204,'__ci_last_regenerate|i:1750909202;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('1ea6d87d5b719910af4a6d1b08b0504dee01ac30','127.0.0.1',1750987007,'__ci_last_regenerate|i:1750987007;red_url|s:21:\"https://82.29.165.22/\";'),
('1ed08b853f4f578e77293ceb9c3dd422a4f156ea','82.29.165.22',1750947904,'__ci_last_regenerate|i:1750947901;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('1efae6f7aac7e0e69b8cc1c96dcc5b3ed8ef12a8','2a02:4780:12:bfc5::1',1751028602,'__ci_last_regenerate|i:1751028602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('1efe498491decd01ceea6b67b6ed691863cd5eeb','157.48.82.220',1750921945,'__ci_last_regenerate|i:1750921945;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"old\";}'),
('1f02f7bd06537e26c1ae3bc3c5fe7881673e16d5','127.0.0.1',1750956710,'__ci_last_regenerate|i:1750956710;red_url|s:21:\"https://82.29.165.22/\";'),
('1f051c0976a6b9f1b05a9ad9c80b7d0839df0dcc','82.29.165.22',1750894203,'__ci_last_regenerate|i:1750894202;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('1f20d240caa4e2f68ae7a300c67d0e581175b20f','2a02:4780:12:bfc5::1',1751017202,'__ci_last_regenerate|i:1751017202;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('1f253c9a63a148f2202abb6d2d9a5815d7389377','127.0.0.1',1750946113,'__ci_last_regenerate|i:1750946113;red_url|s:21:\"https://82.29.165.22/\";'),
('1f255cb9762290ed79e9c15283db6078fd611925','2a02:247a:26d:1000::1',1751067025,'__ci_last_regenerate|i:1751067025;'),
('1f75df4fb96cf27eb4a5f9f8cc8837654f6e4f05','82.29.165.22',1750972204,'__ci_last_regenerate|i:1750972202;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('1f92446fee2b9dcf84f59176a83419770625ed7e','127.0.0.1',1750872110,'__ci_last_regenerate|i:1750872109;red_url|s:21:\"https://82.29.165.22/\";'),
('1f9cffcf8ff283fb7c0b46f97b4f88766471f394','127.0.0.1',1750965407,'__ci_last_regenerate|i:1750965407;red_url|s:21:\"https://82.29.165.22/\";'),
('1fb8d7e3bb135e8fa051f896ca8570d7cdf46421','2a02:4780:12:bfc5::1',1751088002,'__ci_last_regenerate|i:1751088002;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('1fcf683b46a96216a1285daf13149963bc6f85a1','127.0.0.1',1750964404,'__ci_last_regenerate|i:1750964403;red_url|s:21:\"https://82.29.165.22/\";'),
('2001686fd17a9e7cd4751f7252f6c6bb3614dc14','2a02:4780:12:bfc5::1',1751079302,'__ci_last_regenerate|i:1751079301;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('202c552ab61138870b4c7ef5db0bb66ce55a4c83','2a02:4780:12:bfc5::1',1751004602,'__ci_last_regenerate|i:1751004602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('20465cb58264f8547bdf8a8a422a3720243d6c95','2a02:4780:12:bfc5::1',1751122804,'__ci_last_regenerate|i:1751122803;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('20ade4bb83e791e1abc7b987fde3f9aaf2d4eb57','127.0.0.1',1750881603,'__ci_last_regenerate|i:1750881602;red_url|s:21:\"https://82.29.165.22/\";'),
('21014b2360c5547f7a4ded85573547d394cc0094','82.29.165.22',1750921501,'__ci_last_regenerate|i:1750921501;'),
('2179e05832ed843218a470ff84389bd40bce4b2d','2a02:4780:12:bfc5::1',1751085902,'__ci_last_regenerate|i:1751085902;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('218c1f14004805b2350efd5572cd356987d232b3','2a02:4780:12:bfc5::1',1751151901,'__ci_last_regenerate|i:1751151901;'),
('21aefd50e293d857d977a7111a37f82e71cebb94','82.29.165.22',1750911301,'__ci_last_regenerate|i:1750911301;'),
('21cba180771d852463597ea2eab42174e9cca4b3','157.48.80.182',1750874171,'__ci_last_regenerate|i:1750874171;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('21f0a24c03510b89a3b81bc412a3ad8f5d626a05','2a02:4780:12:bfc5::1',1751061302,'__ci_last_regenerate|i:1751061301;'),
('2228abf7aec49085d18bf15e626d9e6b1223faab','2a02:4780:12:bfc5::1',1751099102,'__ci_last_regenerate|i:1751099101;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('222dfeeb31d19d603cd49a97f8f0dd26f37c6882','2a02:4780:12:bfc5::1',1751013302,'__ci_last_regenerate|i:1751013301;'),
('2246d722f72c19ea52503858b51babb500a56d81','82.29.165.22',1750922701,'__ci_last_regenerate|i:1750922701;'),
('224dc3cd7cfa822e60fffaff92d7f0d9de6e3748','127.0.0.1',1750898807,'__ci_last_regenerate|i:1750898807;red_url|s:21:\"https://82.29.165.22/\";'),
('227473aba09b639aa4ca02fe7bb5671aa7bd9140','82.29.165.22',1750889701,'__ci_last_regenerate|i:1750889701;'),
('227a13015a61b31650e27698dad4ea5f23d1216e','127.0.0.1',1750909090,'__ci_last_regenerate|i:1750909090;red_url|s:21:\"https://82.29.165.22/\";'),
('22b59b927fba2e9fa0d747b5db1d91fda1d42445','127.0.0.1',1750923410,'__ci_last_regenerate|i:1750923410;red_url|s:21:\"https://82.29.165.22/\";'),
('22ff43c27fe122ae5a4699776348a02a1184b94a','127.0.0.1',1750907411,'__ci_last_regenerate|i:1750907410;red_url|s:21:\"https://82.29.165.22/\";'),
('23005003fa0e98bbc7c1c32183c5866629763fc0','2a02:4780:12:bfc5::1',1751109301,'__ci_last_regenerate|i:1751109301;'),
('23206bdd66abac4fe0bb003cf10eadd46d182edf','82.29.165.22',1750946407,'__ci_last_regenerate|i:1750946402;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('234a0f0e690e3357c46e6b27804b22f4c47fb158','82.29.165.22',1750935304,'__ci_last_regenerate|i:1750935301;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('235ce36ef92fe4f09a6c97c23a31e10d44e8c54f','82.29.165.22',1750872301,'__ci_last_regenerate|i:1750872301;'),
('23b19df98e1e3fecc124eced876eb2b1e6568994','205.169.39.171',1751099415,'__ci_last_regenerate|i:1751099396;red_url|s:39:\"https://techdotbit.in/clients?companies\";'),
('23d40ffddcaacad2da0e57d8b8487b0155d8ba35','157.230.167.165',1750929859,'__ci_last_regenerate|i:1750929859;'),
('23e0006c4e99a2576cecba0c228219c17f482fc1','82.29.165.22',1750889402,'__ci_last_regenerate|i:1750889402;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('241426b8b59414476b80af65f73146909a4457a9','2a02:4780:12:bfc5::1',1751047802,'__ci_last_regenerate|i:1751047802;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('24421f39cc90b8359a2da8be566c23de261fc5a0','82.29.165.22',1750956602,'__ci_last_regenerate|i:1750956602;'),
('24576fdce7db9cae78d6a483d094970957dc00a6','2a02:4780:12:bfc5::1',1751160002,'__ci_last_regenerate|i:1751160002;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('24773e838537c92fa8a342d6152be7192ac6afb8','127.0.0.1',1750876609,'__ci_last_regenerate|i:1750876609;red_url|s:21:\"https://82.29.165.22/\";'),
('24968887da49b87c8c13e614433214b15dfa7641','127.0.0.1',1750918910,'__ci_last_regenerate|i:1750918909;red_url|s:21:\"https://82.29.165.22/\";'),
('249b578a9891b2ad3b3f61a4ef5034e974cef937','2409:40d4:10cd:43f8:f408:13f9:e02c:5190',1751022794,'__ci_last_regenerate|i:1751022794;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"old\";}'),
('24b18a2d15649863df2fc08869c95794fbfa4653','82.29.165.22',1750896301,'__ci_last_regenerate|i:1750896301;'),
('24e289e2ee972e3f48468d5e7f8e63cfd9312865','2a02:4780:12:bfc5::1',1751136602,'__ci_last_regenerate|i:1751136602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('24f643f3253a7573fcfef5000a2a19c5db24df9b','127.0.0.1',1750891909,'__ci_last_regenerate|i:1750891909;red_url|s:21:\"https://82.29.165.22/\";'),
('251c2d0c163b7fb10f55f20c2391d97bd91c5fbd','82.29.165.22',1750934702,'__ci_last_regenerate|i:1750934701;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('2559a1cde68fc41ceb777e3b0a63be3f6e9d4260','157.48.82.220',1750948013,'__ci_last_regenerate|i:1750948013;red_url|s:38:\"https://82.29.165.22/clients?companies\";client_user_id|s:1:\"2\";contact_user_id|s:1:\"2\";client_logged_in|b:1;'),
('25694788c7b5a02cb682e724eefb217c429c142f','2a02:4780:12:bfc5::1',1751059802,'__ci_last_regenerate|i:1751059802;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('2571a514c1df9bd52ae94f9f8630057d1477510b','157.48.221.10',1750987840,'__ci_last_regenerate|i:1750987840;staff_user_id|s:1:\"1\";staff_logged_in|b:1;red_url|s:21:\"https://82.29.165.22/\";'),
('25878200cdf527fd673d69e8755b9d91672469c0','127.0.0.1',1750915007,'__ci_last_regenerate|i:1750915007;red_url|s:21:\"https://82.29.165.22/\";'),
('25b2bef2c83f78057977f9a856c461d11b0f41ad','2a02:4780:12:bfc5::1',1751019602,'__ci_last_regenerate|i:1751019602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('25d5061ceecb5b2ec5ea53c028a41ed641f06d19','127.0.0.1',1750899603,'__ci_last_regenerate|i:1750899603;red_url|s:21:\"https://82.29.165.22/\";'),
('2645e7a0301cf66b5c4c295ba0dadfb5d432e655','2a02:4780:12:bfc5::1',1751026501,'__ci_last_regenerate|i:1751026501;'),
('2666fac6719984c155c565352e2f53159a405a0a','82.29.165.22',1750907404,'__ci_last_regenerate|i:1750907402;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('267a79cc1693ff986ea3170e878c507937208311','82.29.165.22',1750920004,'__ci_last_regenerate|i:1750920001;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('26f1cfc52ca46e2acd9bfa1d4c66043a9881bc5c','127.0.0.1',1750947409,'__ci_last_regenerate|i:1750947409;red_url|s:21:\"https://82.29.165.22/\";'),
('2703d966b764b9301b7bd838bef746bf67f8e421','2a02:4780:12:bfc5::1',1751083502,'__ci_last_regenerate|i:1751083502;'),
('270ecae35585a052bfe9e990217a5e9b79fb7a9a','2a02:4780:12:bfc5::1',1751114403,'__ci_last_regenerate|i:1751114402;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('273e150c8d4bfebb24ef3aa04d84a824b674d001','82.29.165.22',1750888202,'__ci_last_regenerate|i:1750888202;'),
('275119ec4cf96034a37bfbae8469e22f3cc5939d','2a02:4780:12:bfc5::1',1751109902,'__ci_last_regenerate|i:1751109901;'),
('277674e4131ea5f33e19b45a93cda249e2150610','157.48.221.10',1750990614,'__ci_last_regenerate|i:1750990614;staff_user_id|s:1:\"1\";staff_logged_in|b:1;red_url|s:38:\"https://82.29.165.22/clients?companies\";'),
('2783183f27620e3ca3409df46e5603d42e4a50b2','2a02:4780:12:bfc5::1',1751073902,'__ci_last_regenerate|i:1751073902;'),
('2792fda70616aaed3b92fc73ab856e537c0d0037','127.0.0.1',1750943410,'__ci_last_regenerate|i:1750943410;red_url|s:21:\"https://82.29.165.22/\";'),
('27f60bc5de94507921c48b993b45ca394a0b2f9e','157.48.221.10',1751002732,'__ci_last_regenerate|i:1751002722;red_url|s:38:\"https://82.29.165.22/clients?companies\";'),
('280c70ddb8da1a502717ea78de2662b14e52dec2','127.0.0.1',1750914306,'__ci_last_regenerate|i:1750914306;red_url|s:21:\"https://82.29.165.22/\";'),
('2815026b9d45f64cd0863c6a9508d353d8b0e49c','2a02:4780:12:bfc5::1',1751161502,'__ci_last_regenerate|i:1751161502;'),
('281ac727012975705f861850f7b586e7e521ead7','127.0.0.1',1750971903,'__ci_last_regenerate|i:1750971903;red_url|s:21:\"https://82.29.165.22/\";'),
('282b15826dca43ac1b9a8b75d91d868606dea03e','2a02:4780:12:bfc5::1',1751138701,'__ci_last_regenerate|i:1751138701;'),
('286d1cf202b49c66ef76981f408ed0be8adab435','127.0.0.1',1750996804,'__ci_last_regenerate|i:1750996803;red_url|s:21:\"https://82.29.165.22/\";'),
('2873c3f19f0ef631dc20d7e19d886509436ee29f','82.29.165.22',1750998303,'__ci_last_regenerate|i:1750998301;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('28f4f17f4dba38f0687c2d20d0a8ff7d9c2a2dc9','82.29.165.22',1750905003,'__ci_last_regenerate|i:1750905002;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('29467c6f070f5039dcefa02086021a31eb0eedae','127.0.0.1',1750936928,'__ci_last_regenerate|i:1750936928;red_url|s:21:\"https://82.29.165.22/\";'),
('2946c096cd14c67177e55c1277f6cd41fdd2c499','2a02:4780:12:bfc5::1',1751130302,'__ci_last_regenerate|i:1751130302;'),
('296518b75d8d2d10cd7f5b366b15674b3bab3092','82.29.165.22',1750903803,'__ci_last_regenerate|i:1750903801;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('2965fdd0872cb01bff71970bf30718b0d70195dc','82.29.165.22',1750906501,'__ci_last_regenerate|i:1750906501;'),
('2987e45b3d6826dcb34f3adbb86261506972970e','82.29.165.22',1750923005,'__ci_last_regenerate|i:1750923002;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('29ac6cee4fea62f255c3ac2a9b76d59063540f84','2a02:4780:12:bfc5::1',1751046302,'__ci_last_regenerate|i:1751046301;'),
('29b54841a832e226cc3b4e75ecbff0a96a58bb75','127.0.0.1',1750990910,'__ci_last_regenerate|i:1750990910;red_url|s:21:\"https://82.29.165.22/\";'),
('29c3be2914d9003b521fdc523d5e5f64935ffe20','82.29.165.22',1750992301,'__ci_last_regenerate|i:1750992301;'),
('29eb18a335aa9b3cf9de717172a4ae567477c988','2a02:4780:12:bfc5::1',1751044502,'__ci_last_regenerate|i:1751044502;'),
('29f4227ce342c755d73d6eb0bfa300614d6cccba','127.0.0.1',1750985207,'__ci_last_regenerate|i:1750985207;red_url|s:21:\"https://82.29.165.22/\";'),
('2a18a4ff17de5901fafcbe4510ab296343f40d00','2409:40d4:10cd:43f8:f408:13f9:e02c:5190',1751022962,'__ci_last_regenerate|i:1751022794;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"old\";}'),
('2a21ad43a9b28d5085d994943032fa4b51ec6e31','127.0.0.1',1750863906,'__ci_last_regenerate|i:1750863906;red_url|s:21:\"https://82.29.165.22/\";'),
('2a3481e85257ed6caadc0df6c2e06d7f0b08a4cb','82.29.165.22',1750855802,'__ci_last_regenerate|i:1750855802;'),
('2a3b913686d8923a7f5fe109f4ac9533dbffe56e','82.29.165.22',1750981802,'__ci_last_regenerate|i:1750981802;'),
('2a5c0ea026d8bca111627f49456fa966016ec208','2a02:4780:12:bfc5::1',1751106302,'__ci_last_regenerate|i:1751106302;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('2a6bf47e253669e631ac5f1f070cc016182e4db1','2a02:4780:12:bfc5::1',1751085602,'__ci_last_regenerate|i:1751085601;'),
('2a8604bd337227ef762e8246dd0f9e0d3407f35a','82.29.165.22',1750851302,'__ci_last_regenerate|i:1750851302;'),
('2aa2cc044f4863613a7e897c4ae4bdc8b35b0ab5','2a02:4780:12:bfc5::1',1751056802,'__ci_last_regenerate|i:1751056802;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('2ac20c7896d6f29a483cd1abb66f931fa87dca49','82.29.165.22',1750864501,'__ci_last_regenerate|i:1750864501;'),
('2b028d9b33fe61a30c35f5d19ab010ec02de5c68','127.0.0.1',1750981010,'__ci_last_regenerate|i:1750981010;red_url|s:21:\"https://82.29.165.22/\";'),
('2b1a32e0bd9864ed670f08cd14eb3c55dcceb206','2a02:4780:12:bfc5::1',1751060702,'__ci_last_regenerate|i:1751060702;'),
('2b4c482cffe0141aefca11281b02f5e3374c955e','2a02:4780:12:bfc5::1',1751006101,'__ci_last_regenerate|i:1751006101;'),
('2b4ecc8004b3782b4275ea00100c0c41b735ab69','2001:bc8:1201:1d:ba2a:72ff:fee1:1d32',1751060354,'__ci_last_regenerate|i:1751060354;'),
('2b65c41eab06bcd401c9a358ca6fb072d8bc3473','2a02:4780:12:bfc5::1',1751149803,'__ci_last_regenerate|i:1751149802;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('2b6c4858345f899ae93d4cdf5ef507b20e88a69e','82.29.165.22',1750958702,'__ci_last_regenerate|i:1750958702;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('2ba16153873da89e7d91cf516a4730f7a34ec5a5','45.135.193.162',1750884428,'__ci_last_regenerate|i:1750884428;red_url|s:21:\"https://82.29.165.22/\";'),
('2bab066482dc7eae9466e08c76921a63e1371315','2a02:4780:12:bfc5::1',1751144102,'__ci_last_regenerate|i:1751144102;'),
('2bca3486d2106cf9f687e969ef6b31079bd256b1','2a02:4780:12:bfc5::1',1751119502,'__ci_last_regenerate|i:1751119501;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('2be1164889fc85a6ba9c88d0dfd6363628f71513','2a02:4780:12:bfc5::1',1751084104,'__ci_last_regenerate|i:1751084102;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('2be2a8adfa6ba2d0dc3e80eb3e1c8c4543424c7e','82.29.165.22',1750872901,'__ci_last_regenerate|i:1750872901;'),
('2c00ddc7871cf50c1178717cc6567648620e4005','127.0.0.1',1750945512,'__ci_last_regenerate|i:1750945511;red_url|s:21:\"https://82.29.165.22/\";'),
('2c51ff6500ec33051d015520b055fac7c0442d4e','82.29.165.22',1750947303,'__ci_last_regenerate|i:1750947302;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('2c7dfb53d577de03ec9f496a4dad957bf5f83b64','127.0.0.1',1750928707,'__ci_last_regenerate|i:1750928707;red_url|s:21:\"https://82.29.165.22/\";'),
('2ca6848f6d5504bb3dc1d96c59a2b89c802d8ba5','82.29.165.22',1750936203,'__ci_last_regenerate|i:1750936201;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('2cae47c55d33ad8f305ee1091652c284edfcf826','127.0.0.1',1750864609,'__ci_last_regenerate|i:1750864609;red_url|s:21:\"https://82.29.165.22/\";'),
('2cd5f1d519d225deedb7a3e26883198a844ce30b','82.29.165.22',1750947601,'__ci_last_regenerate|i:1750947601;'),
('2d1411382d0b00ee8cb3197bcb7827a49db70413','127.0.0.1',1750983407,'__ci_last_regenerate|i:1750983407;red_url|s:21:\"https://82.29.165.22/\";'),
('2d34456cf3f5bd5d4decfc7c31b1bc832f3a38f7','2a02:4780:12:bfc5::1',1751138102,'__ci_last_regenerate|i:1751138101;'),
('2d6095a07c80aa85137bf034717df5ebdb341d7d','127.0.0.1',1750937810,'__ci_last_regenerate|i:1750937810;red_url|s:21:\"https://82.29.165.22/\";'),
('2d614e6995fead6e08de0d17f44f95656a07f3a2','2a02:4780:12:bfc5::1',1751034602,'__ci_last_regenerate|i:1751034602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('2dbcdae69e8b0ff806e3cfcc7af3b285ad4ce0b8','103.58.96.228',1751005973,'__ci_last_regenerate|i:1751005968;red_url|s:27:\"https://techdotbit.in/admin\";'),
('2ddd08b7a3177cbe72410be2bf35420c465b83c6','2409:40d4:10cd:43f8:f408:13f9:e02c:5190',1751005885,'__ci_last_regenerate|i:1751005876;red_url|s:39:\"https://techdotbit.in/clients?companies\";client_user_id|s:1:\"3\";contact_user_id|s:1:\"3\";client_logged_in|b:1;perfex_saas_enable_auto_trial|s:1:\"0\";'),
('2e1d971fb4ad8705f76c5a613e6a8d4755294138','127.0.0.1',1750847810,'__ci_last_regenerate|i:1750847810;red_url|s:21:\"https://82.29.165.22/\";'),
('2e3dfecabdf7d0c0916e3b9504eac0f7d0bd3b8f','178.73.233.115',1751132512,'__ci_last_regenerate|i:1751132512;red_url|s:22:\"https://techdotbit.in/\";'),
('2e3f14e5f25b9ac7f2aff4ffe0596902b2416ca4','82.29.165.22',1750952404,'__ci_last_regenerate|i:1750952401;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('2e9478932d7df2c499454fc7926d1b6566b635c7','127.0.0.1',1750935110,'__ci_last_regenerate|i:1750935110;red_url|s:21:\"https://82.29.165.22/\";'),
('2e978848872e6ed3331165c08cd3fa9f0cd6cdca','127.0.0.1',1750855975,'__ci_last_regenerate|i:1750855975;red_url|s:21:\"https://82.29.165.22/\";'),
('2eb5433bdc6e766c1536e61974d89799dbf42e3b','82.29.165.22',1750937103,'__ci_last_regenerate|i:1750937101;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('2eea6d7770ed367786783af71cff5b3194730434','2a02:4780:12:bfc5::1',1751107202,'__ci_last_regenerate|i:1751107201;'),
('2f4491de498832ee20b311fb6244d42fe1af2c92','82.29.165.22',1750976402,'__ci_last_regenerate|i:1750976402;'),
('2f90b0954f1e66fe821dcda1e517eddd0232f8f2','127.0.0.1',1750913207,'__ci_last_regenerate|i:1750913207;red_url|s:21:\"https://82.29.165.22/\";'),
('2f97b3925ca9941885bdde924cd99c13bfda7f26','82.29.165.22',1750894501,'__ci_last_regenerate|i:1750894501;'),
('2fd02a86a6114b8658698180024ab7e379f1036e','82.29.165.22',1750965301,'__ci_last_regenerate|i:1750965301;'),
('3088e11d9f33fb8ff4b4eef681f2916056a6b844','178.128.18.34',1751060304,'__ci_last_regenerate|i:1751060304;'),
('308f4c04351d13155d0ce1b56b31ca3e21e5bf52','2a02:4780:12:bfc5::1',1751031003,'__ci_last_regenerate|i:1751031002;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('30aec8df5bdb0fd32590889a58b115a112780142','127.0.0.1',1750918607,'__ci_last_regenerate|i:1750918607;red_url|s:21:\"https://82.29.165.22/\";'),
('30d6b4863f279ae3edca7fe6c467ad995b9dbf6d','127.0.0.1',1750880807,'__ci_last_regenerate|i:1750880807;red_url|s:21:\"https://82.29.165.22/\";'),
('30e3f163f6827da5ee78aff5492210d3434152e4','2a02:4780:12:bfc5::1',1751061603,'__ci_last_regenerate|i:1751061602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('312bde7395717465641d41cd6ce021a7c1d3e620','127.0.0.1',1750877147,'__ci_last_regenerate|i:1750877147;red_url|s:21:\"https://82.29.165.22/\";'),
('31318daad6b0fad59fff99763e6186ed33c1b976','82.29.165.22',1750899602,'__ci_last_regenerate|i:1750899602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('316f8b0341c42e86e3c48f34398791512959eb8b','82.29.165.22',1750965603,'__ci_last_regenerate|i:1750965601;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('31741d04be4f16940dfaa222f90c5c69c52d655a','82.29.165.22',1750998903,'__ci_last_regenerate|i:1750998901;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('318c7cb69c0f7e353e433a019ee8a80375de0048','2a02:4780:12:bfc5::1',1751166302,'__ci_last_regenerate|i:1751166302;'),
('318ef88a5aa9aec0e08f16a28849faf8cb735c2b','2a02:4780:12:bfc5::1',1751107801,'__ci_last_regenerate|i:1751107801;'),
('319f787f6b1b384bc3ea709b807fec37a9dcff11','161.35.58.80',1751086200,'__ci_last_regenerate|i:1751086199;is_mobile|b:1;red_url|s:22:\"https://techdotbit.in/\";'),
('31e05caed6507b83145633c07797a2f1ac4c66d0','49.44.83.171',1751005962,'__ci_last_regenerate|i:1751005950;red_url|s:39:\"https://techdotbit.in/clients?companies\";'),
('31ec797794a0024efc8e575fe2af485bacb4def7','127.0.0.1',1750951558,'__ci_last_regenerate|i:1750951558;red_url|s:21:\"https://82.29.165.22/\";'),
('3206f8c2f9939908a12bac721e0a1573d66e7a8c','2a02:4780:12:bfc5::1',1751141702,'__ci_last_regenerate|i:1751141702;'),
('323ee5ffd6a5231fde3aa47e2b892f7931e7e7fa','127.0.0.1',1750853807,'__ci_last_regenerate|i:1750853807;red_url|s:21:\"https://82.29.165.22/\";'),
('32697281b815c0fe2fdee8694937c552228daf2c','2a02:4780:12:bfc5::1',1751010302,'__ci_last_regenerate|i:1751010302;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('32c011a16270e4232ff229a56f0e316ebf49f946','82.29.165.22',1750910406,'__ci_last_regenerate|i:1750910401;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('32fae0ca3405812252fafb23ed99ddeac913412f','2a02:4780:12:bfc5::1',1751129702,'__ci_last_regenerate|i:1751129702;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('33263496002a1de3abf9139247a92a31044a4d37','127.0.0.1',1750969907,'__ci_last_regenerate|i:1750969907;red_url|s:21:\"https://82.29.165.22/\";'),
('3331c2414cff450cee8e826519992fadb6a8e5bc','82.29.165.22',1750885501,'__ci_last_regenerate|i:1750885501;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('33a8cece60d12b8a8a21af5fe1cba372a07b9897','82.29.165.22',1750961702,'__ci_last_regenerate|i:1750961702;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('33bcf572ff6bf84925febaa161bf0dabdd6e5020','127.0.0.1',1750879008,'__ci_last_regenerate|i:1750879008;red_url|s:21:\"https://82.29.165.22/\";'),
('33c0b386dfecaf7975f7e72d49f9aa39897014c4','2a02:4780:12:bfc5::1',1751087102,'__ci_last_regenerate|i:1751087101;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('34145188e66acadcc4b72861463793c0fadfcdd9','82.29.165.22',1750868402,'__ci_last_regenerate|i:1750868401;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('341675f3fc2503cf62905bdc8a1138d5269e8581','82.29.165.22',1750860902,'__ci_last_regenerate|i:1750860902;'),
('349cb0fb727358a490d3c631a21c773204e25d4c','2a02:4780:12:bfc5::1',1751136301,'__ci_last_regenerate|i:1751136301;'),
('34b80c6c63a6c28e74d30900cdd7c5768de2fcd9','82.29.165.22',1750976703,'__ci_last_regenerate|i:1750976701;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('351e564afda38e92be9682297fa206607890d625','82.29.165.22',1750881002,'__ci_last_regenerate|i:1750881002;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('356d977dd4377fb6f5be3ee4db93e235102d0036','127.0.0.1',1750861907,'__ci_last_regenerate|i:1750861907;red_url|s:21:\"https://82.29.165.22/\";'),
('35830f4e100b3b5914bf38db7daa00e8fd06666e','82.29.165.22',1750863001,'__ci_last_regenerate|i:1750863001;'),
('35c18b710909399c895e54471000a94ef5ceb544','127.0.0.1',1750916210,'__ci_last_regenerate|i:1750916210;red_url|s:21:\"https://82.29.165.22/\";'),
('35e7cc129930cc75fc07611d6886c761fc569f1d','2a02:4780:12:bfc5::1',1751100901,'__ci_last_regenerate|i:1751100901;'),
('35fefabc292ff49de525facb2b56fb91a2e60d20','2a02:4780:12:bfc5::1',1751035202,'__ci_last_regenerate|i:1751035202;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('36371ae4925980e741a61e4ba6f9c8307b7af30f','2a02:4780:12:bfc5::1',1751064602,'__ci_last_regenerate|i:1751064602;'),
('3658bde724db572e14356f8572964688961da071','127.0.0.1',1750932305,'__ci_last_regenerate|i:1750932304;red_url|s:21:\"https://82.29.165.22/\";'),
('3685267fa82fb8dc406fcc1ecbcac7489ba54ce1','127.0.0.1',1750925410,'__ci_last_regenerate|i:1750925410;red_url|s:21:\"https://82.29.165.22/\";'),
('36c5c9ab251c2527602c0eab2bc72c1d60b7b2da','2a02:4780:12:bfc5::1',1751154302,'__ci_last_regenerate|i:1751154302;'),
('36d9857c030f4fb863ef9ee43424a218359baeea','127.0.0.1',1750897783,'__ci_last_regenerate|i:1750897782;red_url|s:21:\"https://82.29.165.22/\";'),
('36f2b06d89638c19057be514c4935278666b49bc','82.29.165.22',1750852201,'__ci_last_regenerate|i:1750852201;'),
('3702706215c925fe5ca633688154f97ab2d1517c','127.0.0.1',1750873010,'__ci_last_regenerate|i:1750873010;red_url|s:21:\"https://82.29.165.22/\";'),
('370bcd686942fa70a92aba23671bad2bac6de902','82.29.165.22',1750858801,'__ci_last_regenerate|i:1750858801;'),
('37a8e5d53d70fddb5f05292271ccd7496fba8c58','2a02:4780:12:bfc5::1',1751143501,'__ci_last_regenerate|i:1751143501;'),
('37cb4f784588bc2907dd023ea935c7847316b977','127.0.0.1',1750848780,'__ci_last_regenerate|i:1750848779;red_url|s:21:\"https://82.29.165.22/\";'),
('37cc8e45cde686295ec34687305f03bee7478e7a','127.0.0.1',1750857710,'__ci_last_regenerate|i:1750857710;red_url|s:21:\"https://82.29.165.22/\";'),
('37ec5cadfc1da859f023937a7f96a6e4349047a6','2a02:4780:12:bfc5::1',1751135701,'__ci_last_regenerate|i:1751135701;'),
('37fddbc947a3020fa28fbadc9b3c921f4908e07e','157.48.221.10',1750989522,'__ci_last_regenerate|i:1750989522;staff_user_id|s:1:\"1\";staff_logged_in|b:1;red_url|s:38:\"https://82.29.165.22/clients?companies\";'),
('38236e175d97c5044e95544e488bd68cc3917ab5','127.0.0.1',1750921807,'__ci_last_regenerate|i:1750921807;red_url|s:21:\"https://82.29.165.22/\";'),
('3860c40927ec45d868e01ad221523fa9a6dea545','2a02:4780:12:bfc5::1',1751071802,'__ci_last_regenerate|i:1751071802;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('3880ea052dc5161b545cb2dd348ea27f91fe27c7','2a02:4780:12:bfc5::1',1751147402,'__ci_last_regenerate|i:1751147402;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('3888ceecedde816d26a70004560c41ebc2fecba4','2a02:4780:12:bfc5::1',1751160301,'__ci_last_regenerate|i:1751160301;'),
('38c49e5ae01a6bb8fd7389a3ff76ba58ae3588a2','127.0.0.1',1750997409,'__ci_last_regenerate|i:1750997409;red_url|s:21:\"https://82.29.165.22/\";'),
('38dea63056d588dfa3397ac000c182896ba54ff1','2a02:4780:12:bfc5::1',1751018403,'__ci_last_regenerate|i:1751018402;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('392ac63568ccffc8b1409e269e86ae670912484a','2a02:4780:12:bfc5::1',1751029802,'__ci_last_regenerate|i:1751029802;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('39375dfd10173c5a7ac6756364f9dfcee0c1cec4','2a02:4780:12:bfc5::1',1751112602,'__ci_last_regenerate|i:1751112602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('398145e1ca783db902ea11f25be97e5c9be0cd37','127.0.0.1',1750879907,'__ci_last_regenerate|i:1750879907;red_url|s:21:\"https://82.29.165.22/\";'),
('39994b9a60ecb5d805b5a2df8c82bcbcc1dd22ae','2a02:4780:12:bfc5::1',1751001602,'__ci_last_regenerate|i:1751001602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('39afcef9bb24b8a060c38b61f52deb740e28b7fc','82.29.165.22',1750869302,'__ci_last_regenerate|i:1750869302;'),
('39c44e2bbc33042ec0153d1c4e721002d6f5d909','82.29.165.22',1750980003,'__ci_last_regenerate|i:1750980002;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('39e1681c84df62da275705bc796ff2e4db0912d6','45.56.110.54',1750929893,'__ci_last_regenerate|i:1750929893;red_url|s:21:\"https://82.29.165.22/\";'),
('3a29e8e573422d5f61600670a66b33d08a1890d0','2a02:4780:12:bfc5::1',1751001003,'__ci_last_regenerate|i:1751001003;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('3a50e39cf994da4ac2e78c40322f37a6860e665b','82.29.165.22',1750987501,'__ci_last_regenerate|i:1750987501;'),
('3a7f1334f9827a93e2737119aff0fb21cd46952f','82.29.165.22',1750884601,'__ci_last_regenerate|i:1750884601;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('3ae5532396e614ed80b51067b1113c3fa975ab7b','82.29.165.22',1750848001,'__ci_last_regenerate|i:1750848001;'),
('3b0d857f701e2064e674ee9bb886765381344e05','2a02:4780:12:bfc5::1',1751094003,'__ci_last_regenerate|i:1751094002;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('3b15b581837c297b1401e56cb2bce3fa2c91d657','82.29.165.22',1750989603,'__ci_last_regenerate|i:1750989602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('3b483e53687a3386dc5755bce56559b33c88e139','2a02:4780:12:bfc5::1',1751058901,'__ci_last_regenerate|i:1751058901;'),
('3bb5a53dbd6c2e9316fbf2def99c1111fda35482','82.29.165.22',1750986006,'__ci_last_regenerate|i:1750986001;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('3bd8f506a733e23906a4c3546e2e75a597e608f2','157.48.80.182',1750868842,'__ci_last_regenerate|i:1750868842;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";'),
('3be90eefc0d6b79c18677fedb40023ae768d7af7','160.30.44.120',1750859401,'__ci_last_regenerate|i:1750859401;red_url|s:21:\"https://82.29.165.22/\";'),
('3bf794e94ebc80a1300c5e542dde5ea42493e4fc','2a02:4780:12:bfc5::1',1751027403,'__ci_last_regenerate|i:1751027403;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('3c117155807de5b8cde0d5eab789771df9842715','2a02:4780:12:bfc5::1',1751103302,'__ci_last_regenerate|i:1751103302;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('3c2486d5c8134bc5cc8748ddbd7252d237635f85','2a02:4780:12:bfc5::1',1751093702,'__ci_last_regenerate|i:1751093702;'),
('3c351273ae490aa8dbe4792afa4d107da9cd8e3c','2a02:4780:12:bfc5::1',1751080802,'__ci_last_regenerate|i:1751080802;'),
('3c4a77a7fb46ca27d359a39ae20cca43efcea3e6','82.29.165.22',1750925102,'__ci_last_regenerate|i:1750925102;'),
('3c907c5aa57a7c23a79f2f607cbb646b520e82c3','82.29.165.22',1750982419,'__ci_last_regenerate|i:1750982405;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('3cbafa63dfabff7cf43ab904a6bb1ac44221f9c1','82.29.165.22',1750863901,'__ci_last_regenerate|i:1750863901;'),
('3cebc146dca33f94abdc7ecfec2b97d49a8252af','82.29.165.22',1750898701,'__ci_last_regenerate|i:1750898701;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('3d055d8e40876469cbf9afdfab50148d0f4431dd','82.29.165.22',1750939804,'__ci_last_regenerate|i:1750939801;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('3d08e08772e599592be6fad1f5c93ab7268ce481','82.29.165.22',1750891802,'__ci_last_regenerate|i:1750891802;'),
('3d55daa133c8f5c926ca75937e0f538c15e143ab','139.59.172.186',1751001025,'__ci_last_regenerate|i:1751001025;red_url|s:22:\"https://techdotbit.in/\";'),
('3d721c6ecbd261aae1a63e0f41b3fc7eb06de672','82.29.165.22',1750933205,'__ci_last_regenerate|i:1750933201;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('3d7e97aa23aa34efab450dfca18354082138e943','82.29.165.22',1750922405,'__ci_last_regenerate|i:1750922402;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('3d8cb858f2d99e57d0d087927ab31c4d5f116a00','157.48.80.182',1750867114,'__ci_last_regenerate|i:1750867114;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";'),
('3d9b38e8a72dbc180c9ae95d910d9508ca6a0385','82.29.165.22',1750988401,'__ci_last_regenerate|i:1750988401;'),
('3d9ed7af1c6fc3d7e4e77ae16c6bcfb5d4cf9124','127.0.0.1',1750920376,'__ci_last_regenerate|i:1750920376;red_url|s:21:\"https://82.29.165.22/\";'),
('3daeb385b89c727dc2b51e47b65bce87561ac076','82.29.165.22',1750909501,'__ci_last_regenerate|i:1750909501;'),
('3e046fb8d20b71dc7350fe667097760bdd78ec07','127.0.0.1',1750897007,'__ci_last_regenerate|i:1750897007;red_url|s:21:\"https://82.29.165.22/\";'),
('3e082383b33439c0c44d0e38b5b2e342373257e6','2a02:4780:12:bfc5::1',1751082001,'__ci_last_regenerate|i:1751082001;'),
('3e09a9337f97590151a4c6b8d85f3b2eb4ea9038','82.29.165.22',1750859102,'__ci_last_regenerate|i:1750859102;'),
('3e2f083465974e6c96789225fde1d807ce935fa3','2a02:4780:12:bfc5::1',1751133603,'__ci_last_regenerate|i:1751133602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('3e3d75dd101c7487cf09947cfcee92ed4708920b','103.4.250.130',1751006619,'__ci_last_regenerate|i:1751006618;red_url|s:22:\"https://techdotbit.in/\";'),
('3e54a08ae28aebc3a5dcb31ba43c6d6fe7e7745e','82.29.165.22',1750869003,'__ci_last_regenerate|i:1750869001;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('3e58d9d05696a24217621495587a56f32c6f745b','157.48.80.182',1750874979,'__ci_last_regenerate|i:1750874979;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;'),
('3e74330d5365e0c69f1cb5b082c958285f2de8f3','2a02:4780:12:bfc5::1',1751081401,'__ci_last_regenerate|i:1751081401;'),
('3e767b919b9ba6ad40a0d1b644d2cc8cbb1ac731','127.0.0.1',1750864306,'__ci_last_regenerate|i:1750864306;red_url|s:21:\"https://82.29.165.22/\";'),
('3e7b5312289843900daf29b445ddbe2b3ce1d765','127.0.0.1',1750875710,'__ci_last_regenerate|i:1750875710;red_url|s:21:\"https://82.29.165.22/\";'),
('3ea7d2a6d8d76e651bd6b1426f8f5fb79d377c12','206.168.34.47',1750890461,'__ci_last_regenerate|i:1750890461;'),
('3eb4830642556ae3114b6ca234a68e615218a6eb','2a02:4780:12:bfc5::1',1751063702,'__ci_last_regenerate|i:1751063702;'),
('3f240f34c1e2b32f2d279116b66d7f179537bf50','127.0.0.1',1750960310,'__ci_last_regenerate|i:1750960310;red_url|s:21:\"https://82.29.165.22/\";'),
('3f742b610c64259ab4ee49db1a6fd6608d8b5df9','82.29.165.22',1750861201,'__ci_last_regenerate|i:1750861201;'),
('3f7e07a59b2352d5b71fb0f44d30396c0b975c05','127.0.0.1',1750987310,'__ci_last_regenerate|i:1750987309;red_url|s:21:\"https://82.29.165.22/\";'),
('3f7e30e6d7355df7eb1edc9ac3e4f71b23be370b','127.0.0.1',1750889105,'__ci_last_regenerate|i:1750889105;red_url|s:21:\"https://82.29.165.22/\";'),
('3f835de07ff3b4eb0aa8fc4597266f1303ae022f','82.29.165.22',1750952702,'__ci_last_regenerate|i:1750952702;'),
('3f8f2f40d5529ba6e63361ec52eb552edfc666ed','82.29.165.22',1750904703,'__ci_last_regenerate|i:1750904701;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('3f9b141a251e6927052faabcd917c7d3b509bed6','2a02:4780:12:bfc5::1',1751108406,'__ci_last_regenerate|i:1751108404;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('3fd8365ca1fd9afb4bf2ecdc07babbd3f88f79de','127.0.0.1',1750980110,'__ci_last_regenerate|i:1750980110;red_url|s:21:\"https://82.29.165.22/\";'),
('4038d764242e8aa13b0e2f490dc4fbd996ec04e3','2409:40d4:10cd:43f8:5017:62cd:c7c:fed6',1751030667,'__ci_last_regenerate|i:1751030641;red_url|s:39:\"https://techdotbit.in/clients?companies\";'),
('40464288476f4468fdfdbef3658f0a82a883874b','157.48.82.220',1750919702,'__ci_last_regenerate|i:1750919702;red_url|s:38:\"https://82.29.165.22/clients?companies\";'),
('405e5c5ee3d476c6205b74dcacafe218b283be43','82.29.165.22',1750927801,'__ci_last_regenerate|i:1750927801;'),
('40766a9e44397c38df17278b591b43283c73f554','127.0.0.1',1750935908,'__ci_last_regenerate|i:1750935908;red_url|s:21:\"https://82.29.165.22/\";'),
('408559a7ce5f8dcd7ef3104ef8cb2d00c4918276','82.29.165.22',1750979701,'__ci_last_regenerate|i:1750979701;'),
('408df90aac80f9b372a02a0f9055222b01cd3bb5','2001:bc8:1201:1d:ba2a:72ff:fee1:1d32',1751060348,'__ci_last_regenerate|i:1751060348;'),
('40910d1fc12c5b78ce8d129c19619d78fd628209','127.0.0.1',1750959107,'__ci_last_regenerate|i:1750959107;red_url|s:21:\"https://82.29.165.22/\";'),
('40bbb8d52feef333d0235cceb11f7247475f988d','2a02:4780:12:bfc5::1',1751166902,'__ci_last_regenerate|i:1751166902;'),
('40f6f82913bb71a4f2e9ec23abd2afa7914ddd8f','127.0.0.1',1750939204,'__ci_last_regenerate|i:1750939204;red_url|s:21:\"https://82.29.165.22/\";'),
('410c8602855de490fd33607e53ca17fc972d13e5','82.29.165.22',1750917602,'__ci_last_regenerate|i:1750917602;'),
('417d7e5a9c7d96b7bf9918d62da095c482223e37','82.29.165.22',1750911902,'__ci_last_regenerate|i:1750911901;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('41ce53d03614311b32c7a10408d23840fbc26926','2a02:4780:12:bfc5::1',1751043602,'__ci_last_regenerate|i:1751043602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('4221bbbdfd184282032c6a388d63d43813aeff0b','82.29.165.22',1750977301,'__ci_last_regenerate|i:1750977301;'),
('42499e74398899b3681d30f1d379c8491756c3df','127.0.0.1',1750998110,'__ci_last_regenerate|i:1750998110;red_url|s:21:\"https://82.29.165.22/\";'),
('42606e64f0781c56d4cb9b959dd3d091f78db59f','2409:40d4:10cd:43f8:f408:13f9:e02c:5190',1751011103,'__ci_last_regenerate|i:1751011103;red_url|s:39:\"https://techdotbit.in/clients?companies\";client_user_id|s:1:\"4\";contact_user_id|s:1:\"4\";client_logged_in|b:1;perfex_saas_enable_auto_trial|s:1:\"0\";'),
('42a74997bd24f63301d6bbfa60ac8e75d882ea00','82.29.165.22',1750953902,'__ci_last_regenerate|i:1750953901;'),
('42d086da5ad96fb03a604fa8bde798e3d39a01e5','2a02:4780:12:bfc5::1',1751098802,'__ci_last_regenerate|i:1751098802;'),
('42d8c70a1f12d591a16a8e9c9aa67a383a5468b5','127.0.0.1',1750974709,'__ci_last_regenerate|i:1750974709;red_url|s:21:\"https://82.29.165.22/\";'),
('433d8c5f64ce9a54bca53742a4a03f80c3725158','82.29.165.22',1750964701,'__ci_last_regenerate|i:1750964701;'),
('434d8cca6c30d1cade999f958d9b5725d8e860a3','127.0.0.1',1750923107,'__ci_last_regenerate|i:1750923107;red_url|s:21:\"https://82.29.165.22/\";'),
('436b55707c3d939fe8ac7ccd2b3a3023238a9a57','82.29.165.22',1750934102,'__ci_last_regenerate|i:1750934102;'),
('4379a67f3debfa8c729cd86c9df4d38e279a1e53','35.94.22.188',1751011956,'__ci_last_regenerate|i:1751011956;is_mobile|b:1;red_url|s:22:\"https://techdotbit.in/\";'),
('437bc0b7a39bc830d22b6afe88731fdb82c98f25','157.48.80.182',1750901511,'__ci_last_regenerate|i:1750901511;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;'),
('437d472e338325130c6ea7cb9b27daa82a7776ae','127.0.0.1',1750900910,'__ci_last_regenerate|i:1750900909;red_url|s:21:\"https://82.29.165.22/\";'),
('438ad8ca8d902d083a52b014be2b411de1c39cf0','82.29.165.22',1750849801,'__ci_last_regenerate|i:1750849801;'),
('43d986bd004685a628cb155b7cd7b8aed35a6f2f','127.0.0.1',1750969310,'__ci_last_regenerate|i:1750969309;red_url|s:21:\"https://82.29.165.22/\";'),
('441030effb9faf7b519030f4ab82ef668240e757','2a02:4780:12:bfc5::1',1751173502,'__ci_last_regenerate|i:1751173501;'),
('444418c79d035f45ee11ffc44f93fd9f54ccccda','2a02:4780:12:bfc5::1',1751004302,'__ci_last_regenerate|i:1751004301;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('4445fd068e3e475482c457132df5e8327ff10284','127.0.0.1',1750948610,'__ci_last_regenerate|i:1750948610;red_url|s:21:\"https://82.29.165.22/\";'),
('445d98e7277e1b6eb59f05c739e3c8951525322d','82.29.165.22',1750992901,'__ci_last_regenerate|i:1750992901;'),
('44ce6da78c220d5a7495e77646384e15c4f0512e','82.29.165.22',1750959303,'__ci_last_regenerate|i:1750959301;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('44de9dbd9ee57bdb4e82956beeed1480f195b14d','127.0.0.1',1750857407,'__ci_last_regenerate|i:1750857407;red_url|s:21:\"https://82.29.165.22/\";'),
('45464e5948761b6af5adccd0d62b6e7bfbbf8fdb','82.29.165.22',1750893602,'__ci_last_regenerate|i:1750893602;'),
('454d323b3ec08e2af70c58c6b96a95338bf74e65','2a02:4780:12:bfc5::1',1751076902,'__ci_last_regenerate|i:1751076901;'),
('45734ea74375bf24dd311e260b035409119ed08a','2a02:4780:12:bfc5::1',1751018101,'__ci_last_regenerate|i:1751018101;'),
('45b358c09f84c294b4d0b0e154f56c63a699428e','127.0.0.1',1750962176,'__ci_last_regenerate|i:1750962175;red_url|s:21:\"https://82.29.165.22/\";'),
('45b3c6f67e0e18460c7d7f0eb89835dfeabe9c71','82.29.165.22',1750978502,'__ci_last_regenerate|i:1750978502;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('4616af9e6a496b9340c5d83a7f795f4060765038','82.29.165.22',1750974302,'__ci_last_regenerate|i:1750974302;'),
('464e6e086fa1cc82ab3f48c157c46cac36c29fee','182.239.102.215',1750874787,'__ci_last_regenerate|i:1750874787;red_url|s:21:\"https://82.29.165.22/\";'),
('465d7b5d32dac7243ac5e46b2be4ddd22dc20833','127.0.0.1',1750919810,'__ci_last_regenerate|i:1750919810;red_url|s:21:\"https://82.29.165.22/\";'),
('468145a8786d367b03c96e8198714085ad77db55','2409:40d4:10cd:43f8:f408:13f9:e02c:5190',1751009260,'__ci_last_regenerate|i:1751009260;red_url|s:39:\"https://techdotbit.in/clients?companies\";client_user_id|s:1:\"4\";contact_user_id|s:1:\"4\";client_logged_in|b:1;message-success|s:26:\"Thank your for registering\";__ci_vars|a:1:{s:15:\"message-success\";s:3:\"old\";}'),
('468b73d3f7c4f356e4057f3608400fb4eae44b30','127.0.0.1',1750972206,'__ci_last_regenerate|i:1750972206;red_url|s:21:\"https://82.29.165.22/\";'),
('46a81240a504485fe7fb38d3ca0f9bc297f25404','2a02:4780:12:bfc5::1',1751092502,'__ci_last_regenerate|i:1751092502;'),
('46b13e85f118422212ac4a36a45e95f806476d9d','2a02:4780:12:bfc5::1',1751162405,'__ci_last_regenerate|i:1751162403;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('46be58cb7582bdedde39cadde7d737980da12a85','69.67.183.108',1751000711,'__ci_last_regenerate|i:1751000711;red_url|s:22:\"https://techdotbit.in/\";'),
('46d0e571784bdaaf6f1bd79c68ab92178c03a13b','82.29.165.22',1750995301,'__ci_last_regenerate|i:1750995301;'),
('46d592fbd708948c150115dfc66fb2420e936499','82.29.165.22',1750880102,'__ci_last_regenerate|i:1750880101;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('4747d853eb6b03f1ff13ec00e8a523e38165b484','82.29.165.22',1750881301,'__ci_last_regenerate|i:1750881301;'),
('47483328075c442f67d49b0e7d0c09bbe86ea697','2a02:4780:12:bfc5::1',1751047205,'__ci_last_regenerate|i:1751047203;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('474b5636f7dbe4f5605f0163f533f1d0479922a7','2a02:4780:12:bfc5::1',1751137203,'__ci_last_regenerate|i:1751137202;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('475ea15bcbcad7f0a1ba08648ae5e124651b35bb','2a02:4780:12:bfc5::1',1751152802,'__ci_last_regenerate|i:1751152802;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('477294f8f85e3996fa33c9ea9532b530c7a1ab5d','82.29.165.22',1750921804,'__ci_last_regenerate|i:1750921801;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('47a6c94d4bda0257e0dc6c71a29e4350185ceeba','2a02:4780:12:bfc5::1',1751082901,'__ci_last_regenerate|i:1751082901;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('47b6545e739b29d5ccbb909f6ff11a20f9649a83','2a02:4780:12:bfc5::1',1751059202,'__ci_last_regenerate|i:1751059202;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('480ec69d33f03d7c61801950365a055ac940a8d6','127.0.0.1',1750971048,'__ci_last_regenerate|i:1750971048;red_url|s:21:\"https://82.29.165.22/\";'),
('481ebd44bf1cb01f68faea81bdf39736a77ba99d','127.0.0.1',1750933310,'__ci_last_regenerate|i:1750933310;red_url|s:21:\"https://82.29.165.22/\";'),
('482959bc81952128edd4401f72bfb236fdd235ab','2a02:4780:12:bfc5::1',1751158502,'__ci_last_regenerate|i:1751158502;'),
('488ab78b154eb652917506397c960b0c9bd30327','2a02:4780:12:bfc5::1',1751065802,'__ci_last_regenerate|i:1751065802;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('48dd219b9de744982eb7ad03421527abb9a49209','157.48.80.182',1750871095,'__ci_last_regenerate|i:1750871095;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('4910450abf1a71edf0695aaf3537d8e6089896e5','82.29.165.22',1750969203,'__ci_last_regenerate|i:1750969201;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('493daaa885f26645ae26353e97be0fac9f4c3339','2a02:4780:12:bfc5::1',1751138403,'__ci_last_regenerate|i:1751138402;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('4957f4f842a694b3e94b7c26ac3ac403f37906f7','82.29.165.22',1750896902,'__ci_last_regenerate|i:1750896902;'),
('49758b6f8360b7c3d7814b6fa8a7a1cebc370bba','2a02:4780:12:bfc5::1',1751020501,'__ci_last_regenerate|i:1751020501;'),
('499170d2cf5e49df27539fdc1cbeb6ca1609e4c2','127.0.0.1',1750874405,'__ci_last_regenerate|i:1750874403;red_url|s:21:\"https://82.29.165.22/\";'),
('49c9701ba5b19f3aa4f60c25326d90983561a2f6','2a02:4780:12:bfc5::1',1751008802,'__ci_last_regenerate|i:1751008802;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('49db24b5a5b0c934bfcdebf070c42916eddae081','34.222.24.232',1751013485,'__ci_last_regenerate|i:1751013478;red_url|s:39:\"https://techdotbit.in/clients?companies\";'),
('49e639c80e3b95615ebf867707bb07db25421563','127.0.0.1',1751002307,'__ci_last_regenerate|i:1751002307;red_url|s:21:\"https://82.29.165.22/\";'),
('49f9adb149ba928694240a6b954b20bf30cce72c','82.29.165.22',1750971902,'__ci_last_regenerate|i:1750971901;'),
('4a0e082aa0f95fc6a8230f1e85d88487479976c2','82.29.165.22',1750995605,'__ci_last_regenerate|i:1750995602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('4a4f53c80f720599d389724e15708afc3923b0ad','82.29.165.22',1750942201,'__ci_last_regenerate|i:1750942201;'),
('4a9fe913f17f4a4220ea5d5784a99a89c79e9110','82.29.165.22',1750956302,'__ci_last_regenerate|i:1750956301;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('4ad6c61e2d1273379d7cef2b491f05392d36c2a8','2a02:4780:12:bfc5::1',1751058003,'__ci_last_regenerate|i:1751058002;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('4b0c3e57060653c195f13d9a8fa5936e2694dcf0','82.29.165.22',1750928704,'__ci_last_regenerate|i:1750928701;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('4b15b0278005884f766750591971a661d809b95c','82.29.165.22',1750955403,'__ci_last_regenerate|i:1750955402;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('4b3af7b7ceb0b58069605e70fd21c2b425e9cf0e','2a02:4780:12:bfc5::1',1751003702,'__ci_last_regenerate|i:1751003702;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('4b482b523cdf02ad4f08b092875d92751bf0e8f3','127.0.0.1',1750865810,'__ci_last_regenerate|i:1750865810;red_url|s:21:\"https://82.29.165.22/\";'),
('4b9d37b582aa4ca3b2c117b907d81174d71e4950','2a02:4780:12:bfc5::1',1751116802,'__ci_last_regenerate|i:1751116802;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('4be7a0045be8a5bf3e40f700a3eb9130925afcf7','127.0.0.1',1750906007,'__ci_last_regenerate|i:1750906007;red_url|s:21:\"https://82.29.165.22/\";'),
('4bf9a18adaf4cf775357715c720050f6110185db','2a02:4780:12:bfc5::1',1751057702,'__ci_last_regenerate|i:1751057702;'),
('4c20cc88eb876c12926bd30dfded2e29987c0d08','82.29.165.22',1750932007,'__ci_last_regenerate|i:1750932002;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('4c5d24c9eb271e0f5ba31456c00d149ee4e0499d','82.29.165.22',1750941601,'__ci_last_regenerate|i:1750941601;'),
('4c8a766a70fb05416d4e7d76d40b9f500f6e67ef','2a02:4780:12:bfc5::1',1751052602,'__ci_last_regenerate|i:1751052602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('4c971f6290b05c79308fb22a93178c673127780a','127.0.0.1',1750847507,'__ci_last_regenerate|i:1750847507;red_url|s:21:\"https://82.29.165.22/\";'),
('4caf8737d57745b1bbb69af4b06078aa0cba1dc6','82.29.165.22',1750993501,'__ci_last_regenerate|i:1750993501;'),
('4cc81b7d83c57b89ac5d0387a175c19a68551c25','82.29.165.22',1750868702,'__ci_last_regenerate|i:1750868702;'),
('4cd29b6764586d746cd7454d1a389ea6ff409d1c','2a02:4780:12:bfc5::1',1751145603,'__ci_last_regenerate|i:1751145602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('4cfc518b6faef54de4caeb22d97f8f9df5118ef1','127.0.0.1',1750852804,'__ci_last_regenerate|i:1750852804;red_url|s:21:\"https://82.29.165.22/\";'),
('4d0e27b0e6cce5fc3d9b81473f6ddfb574c17acb','2a02:4780:12:bfc5::1',1751029203,'__ci_last_regenerate|i:1751029202;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('4d1ba9bbd2a156696868b4c3f05afb4a7c8fb8cb','2a02:4780:12:bfc5::1',1751033702,'__ci_last_regenerate|i:1751033702;'),
('4d2dd3abc91baa567010277160d64ef3d5743cc5','2a02:4780:12:bfc5::1',1751121602,'__ci_last_regenerate|i:1751121602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('4d38480f18d76fbbe18167c18314f27aa807491e','82.29.165.22',1750867801,'__ci_last_regenerate|i:1750867801;'),
('4d5a715aa136066c8095e3b957a848bf960d047c','82.29.165.22',1750859401,'__ci_last_regenerate|i:1750859401;'),
('4d8cd37f69c0769e03e46d3961d8f3b5d4657293','2a02:4780:12:bfc5::1',1751142602,'__ci_last_regenerate|i:1751142602;'),
('4d90fcbdb6357f926ed21e6ec13a86f590aeed33','82.29.165.22',1750950601,'__ci_last_regenerate|i:1750950601;'),
('4dc81e77dee801719ebe1e87daec25e24ec6d232','82.29.165.22',1750949703,'__ci_last_regenerate|i:1750949701;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('4dcf5ff47f178fc6aa2529c2f36a0645b5b63a1b','160.238.94.4',1751005962,'__ci_last_regenerate|i:1751005950;red_url|s:39:\"https://techdotbit.in/clients?companies\";'),
('4e0a6c79dd86d3fb296ccbd2315da7fd0203b7dc','2a02:4780:12:bfc5::1',1751170502,'__ci_last_regenerate|i:1751170501;'),
('4e4fcd504cd037f3bb61cd01374cfdaaa1fd634e','2a02:4780:12:bfc5::1',1751102402,'__ci_last_regenerate|i:1751102401;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('4e6a2fa5f04955b169e0e2463c4c27551a7148f6','127.0.0.1',1750993810,'__ci_last_regenerate|i:1750993810;red_url|s:21:\"https://82.29.165.22/\";'),
('4e8d9a98506355aca903c9d30b3b795e9fbfb9b5','127.0.0.1',1750871103,'__ci_last_regenerate|i:1750871103;red_url|s:21:\"https://82.29.165.22/\";'),
('4eac181b3b1340d19caea5a380df2cbf74df39f7','127.0.0.1',1750936211,'__ci_last_regenerate|i:1750936211;red_url|s:21:\"https://82.29.165.22/\";'),
('4ee503d404d6ff268bfd669a93a4154022257ee5','127.0.0.1',1750943108,'__ci_last_regenerate|i:1750943107;red_url|s:21:\"https://82.29.165.22/\";'),
('4f00f7d091c56dd15856d8f0698a05382c239fcc','127.0.0.1',1750930307,'__ci_last_regenerate|i:1750930307;red_url|s:21:\"https://82.29.165.22/\";'),
('4f0813eec518089ca77d06023b136ba806d6f043','82.29.165.22',1750987203,'__ci_last_regenerate|i:1750987201;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('4f144b17db1c3305422a3379e18fe0dcac8a961d','2a02:4780:12:bfc5::1',1751009403,'__ci_last_regenerate|i:1751009402;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('4f2d3492a5efbd43eb448bb9b5803eb123fe593f','2a02:4780:12:bfc5::1',1751100002,'__ci_last_regenerate|i:1751100002;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('4f35d04971816ff337fcc7f81137479764a90748','82.29.165.22',1750866001,'__ci_last_regenerate|i:1750866001;'),
('4f3c789eae527fc9dacf7ff37bc7b3b28932d588','127.0.0.1',1750869107,'__ci_last_regenerate|i:1750869107;red_url|s:21:\"https://82.29.165.22/\";'),
('4f510d68c9fa79c90ffb55fca758ddf0761b22e9','127.0.0.1',1750919507,'__ci_last_regenerate|i:1750919507;red_url|s:21:\"https://82.29.165.22/\";'),
('4f804e0c559402cabbf4f55585cb47f71e928d1d','157.48.82.220',1750946329,'__ci_last_regenerate|i:1750946329;red_url|s:38:\"https://82.29.165.22/clients?companies\";client_user_id|s:1:\"2\";contact_user_id|s:1:\"2\";client_logged_in|b:1;'),
('4f9bfb168f7a8f54f6e392b5157a13a685454c4b','81.17.21.242',1751027884,'__ci_last_regenerate|i:1751027884;red_url|s:22:\"https://techdotbit.in/\";'),
('4fcd815e569c401cbd7921ebe23201b94644ed2b','127.0.0.1',1750914003,'__ci_last_regenerate|i:1750914002;red_url|s:21:\"https://82.29.165.22/\";'),
('50096cddf6b087a1b843a5b90fefa1f705690397','127.0.0.1',1750899109,'__ci_last_regenerate|i:1750899109;red_url|s:21:\"https://82.29.165.22/\";'),
('501b895a015f4bf6d1dc7a50392569622af9daa2','45.135.193.162',1750884425,'__ci_last_regenerate|i:1750884425;red_url|s:21:\"https://82.29.165.22/\";'),
('506ebf8ceda25351478f83aa44f99dbf29d34d24','2a02:4780:12:bfc5::1',1751113202,'__ci_last_regenerate|i:1751113202;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('50d7c89a71928021824ba07edd4337e08bc91c07','2a02:4780:12:bfc5::1',1751083802,'__ci_last_regenerate|i:1751083801;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('50d9e7be0fd3294b84f38e7284cad24aae569ac3','82.29.165.22',1750939209,'__ci_last_regenerate|i:1750939202;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('50ec3a25095cd3db3851e186c4ac7338eb01450b','82.29.165.22',1750908606,'__ci_last_regenerate|i:1750908602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('50ee683f1ecc5aa2ae5b16101494200cb484dde6','2a02:4780:12:bfc5::1',1751077803,'__ci_last_regenerate|i:1751077802;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('5139364b202c0fc207b70b2553be57d1f1301839','2409:40d4:10cd:43f8:f408:13f9:e02c:5190',1751017977,'__ci_last_regenerate|i:1751017977;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;__ci_vars|a:1:{s:5:\"debug\";s:3:\"old\";}debug|s:457:\"<h1>Your SMTP settings are not set correctly here is the debug log.</h1><br />SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting<br /><pre>\n\n</pre>Connection: opening to smtp.hostinger.com:465, timeout=30, options=array()<br />Connection: opened<br />SERVER -> CLIENT: <br />Connection: closing due to error<br />Connection: closed<br />SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting<br />\";'),
('516c49354e16f68f3b28d15718d28d10760319e5','2a02:4780:12:bfc5::1',1751008502,'__ci_last_regenerate|i:1751008502;'),
('51ae2b1bacf96a5a525a028f2721ef1cd3b54ef0','2a02:4780:12:bfc5::1',1751014804,'__ci_last_regenerate|i:1751014802;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('51afa9269ccc551f4b6ee7c99a948cc9b692c081','82.29.165.22',1750937702,'__ci_last_regenerate|i:1750937701;'),
('51b6c73860168cbb745c39294283529d94e9b883','46.17.174.173',1751159560,'__ci_last_regenerate|i:1751159560;'),
('51ba72c5eca58afe998c1cfc5c2dda16a360908a','2a02:4780:12:bfc5::1',1751104802,'__ci_last_regenerate|i:1751104801;'),
('51bbf5ee4b0da8dbb5e90857fe03485015381fbb','2409:40d4:10cd:43f8:f408:13f9:e02c:5190',1751021126,'__ci_last_regenerate|i:1751021126;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"old\";}'),
('51d703b855f127533546bac869b6860171ffd822','82.29.165.22',1750976102,'__ci_last_regenerate|i:1750976101;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('520df7c3f3fa352b37057590f2c1c10915f6ebbd','161.35.146.141',1751077626,'__ci_last_regenerate|i:1751077623;red_url|s:22:\"https://techdotbit.in/\";'),
('522fb3a80871c4a0c74694134c588ccccbd7c050','127.0.0.1',1750866407,'__ci_last_regenerate|i:1750866407;red_url|s:21:\"https://82.29.165.22/\";'),
('524abf5a5a6f6498d5647ba47fa0dbb9f709e4a9','2a02:4780:12:bfc5::1',1751012402,'__ci_last_regenerate|i:1751012402;'),
('524f91919746767831f095102b4b1c946bab025b','127.0.0.1',1750917906,'__ci_last_regenerate|i:1750917906;red_url|s:21:\"https://82.29.165.22/\";'),
('529f5184203165d9d99a98e44f648d04c32f8126','2a02:4780:12:bfc5::1',1751111102,'__ci_last_regenerate|i:1751111101;'),
('52a3933e0279b2f286758a24a0afa7d5cbb866e3','2409:40d4:10cd:43f8:f408:13f9:e02c:5190',1751009351,'__ci_last_regenerate|i:1751009351;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('52ac33827964cd79654ef620cd2711a17634eaaa','127.0.0.1',1750906805,'__ci_last_regenerate|i:1750906805;red_url|s:21:\"https://82.29.165.22/\";'),
('52ef8575e26fdeaba0cbdef14668f12ee1183042','2a02:4780:12:bfc5::1',1751095501,'__ci_last_regenerate|i:1751095501;'),
('5305ee50a0d50066632df8602884dd515ac87391','2409:40d4:10cd:43f8:f408:13f9:e02c:5190',1751003015,'__ci_last_regenerate|i:1751003015;perfex_saas_enable_auto_trial|s:1:\"0\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";red_url|s:39:\"https://techdotbit.in/clients?companies\";'),
('537b629f835830b218ac54dbe85d5d6ece8ba13b','82.29.165.22',1750985404,'__ci_last_regenerate|i:1750985402;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('53949e233f6a935b5cd49bc17a41db280a102348','2a02:4780:12:bfc5::1',1751034002,'__ci_last_regenerate|i:1751034002;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('53a7338251e06abbf3ee42ceba04014a4b4645f4','125.167.116.76',1750849505,'__ci_last_regenerate|i:1750849505;red_url|s:21:\"https://82.29.165.22/\";'),
('53c074530098692275d3dfdf1b9722c0a41f4ab7','82.29.165.22',1750941904,'__ci_last_regenerate|i:1750941902;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('53d29baffdc622c4ca0daaa067bbde54acd79ded','82.29.165.22',1750901401,'__ci_last_regenerate|i:1750901401;'),
('5438bb34d0484281ca0706feb5a8a31d77b12fc4','127.0.0.1',1750896310,'__ci_last_regenerate|i:1750896310;red_url|s:21:\"https://82.29.165.22/\";'),
('545b25924d9f0ac73716cdc53d371771b53d2b95','2a02:4780:12:bfc5::1',1751053803,'__ci_last_regenerate|i:1751053802;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('5485acdf3525cd4016250f29d70cf58d8298b331','127.0.0.1',1750983710,'__ci_last_regenerate|i:1750983709;red_url|s:21:\"https://82.29.165.22/\";'),
('54ea19dd631aeb2c369b3ee4a0e95f1038c5406c','2a02:4780:12:bfc5::1',1751107502,'__ci_last_regenerate|i:1751107502;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('54eafdb31c60bec3ccc879ab3ec5884257533d94','82.29.165.22',1750877101,'__ci_last_regenerate|i:1750877101;'),
('54fcd14b3814878e43d34219ae648c4e46f35a92','2a02:4780:12:bfc5::1',1751066701,'__ci_last_regenerate|i:1751066701;'),
('5508e4e48c43bfa3e7bda4bc4ee7fc3527109284','82.29.165.22',1750960503,'__ci_last_regenerate|i:1750960501;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('5515f4b3f15ed2cc65cea8b92945d10e87f5b71f','127.0.0.1',1750983020,'__ci_last_regenerate|i:1750983020;red_url|s:21:\"https://82.29.165.22/\";'),
('554064f01e59548f21824913d779ffb9c9db24e6','82.29.165.22',1750888802,'__ci_last_regenerate|i:1750888802;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('55569fc48844db7ff78375c5403ed458e8a1f49e','161.35.166.17',1750949817,'__ci_last_regenerate|i:1750949814;red_url|s:21:\"https://82.29.165.22/\";'),
('558a0609931b084ac74756bb7c29449a10787599','82.29.165.22',1750944301,'__ci_last_regenerate|i:1750944301;'),
('55bdc38f300497350b614291e838fc6f607f1d4e','127.0.0.1',1750889807,'__ci_last_regenerate|i:1750889807;red_url|s:21:\"https://82.29.165.22/\";'),
('562790a23a7bc18600015c4ba87c715771d5104b','127.0.0.1',1750950307,'__ci_last_regenerate|i:1750950306;red_url|s:21:\"https://82.29.165.22/\";'),
('5669d5bd78a4beb9e3d3ffc92f0a0bc7995f1c87','82.29.165.22',1750869601,'__ci_last_regenerate|i:1750869601;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('56a0754fe76cdf266341b6d41fc6a793b5790f3f','127.0.0.1',1750995107,'__ci_last_regenerate|i:1750995107;red_url|s:21:\"https://82.29.165.22/\";'),
('56fe92e79083a5c11769657b395c61344be238f2','2a02:4780:12:bfc5::1',1751046602,'__ci_last_regenerate|i:1751046602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('570061cd352e6ad8a103b5e3e6136fa2b1185e34','159.89.237.85',1750930153,'__ci_last_regenerate|i:1750930153;red_url|s:21:\"https://82.29.165.22/\";'),
('57674a7148188a0234fc376d6535e571ada2e003','2a02:4780:12:bfc5::1',1751116502,'__ci_last_regenerate|i:1751116501;'),
('5775767d5189a0acdd7020c22f0f186db9c3d681','2a02:4780:12:bfc5::1',1751114702,'__ci_last_regenerate|i:1751114701;'),
('577d1e8bda7686ca7572396d192d5891c10fac3b','2a02:4780:12:bfc5::1',1751058602,'__ci_last_regenerate|i:1751058602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('577fc42cd42bf697efd585f8827bc23f6c27e848','2a02:4780:12:bfc5::1',1751110202,'__ci_last_regenerate|i:1751110202;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('5784200f49bce104c0f543d571965b4de2143983','82.29.165.22',1750973405,'__ci_last_regenerate|i:1750973402;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('57a0d7b124cc5ed2f78ff6ce5e449399ecdde132','127.0.0.1',1750913510,'__ci_last_regenerate|i:1750913510;red_url|s:21:\"https://82.29.165.22/\";'),
('57a47f42bc11f30b9be61406cd8ae1a12a6808f3','82.29.165.22',1750915802,'__ci_last_regenerate|i:1750915801;'),
('57c30de07be14dccdac8a545a46eabda91438223','2a02:4780:12:bfc5::1',1751152202,'__ci_last_regenerate|i:1751152202;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('57dc9e303b1ca9509c4232bf59ec4d4d6690964f','2a02:4780:12:bfc5::1',1751039701,'__ci_last_regenerate|i:1751039701;'),
('57e7dd25aed819865968ae44fd2e91374759c10a','82.29.165.22',1750998601,'__ci_last_regenerate|i:1750998601;'),
('5831c65322e63aac8f312c86d06835d37c0e85f5','127.0.0.1',1750882607,'__ci_last_regenerate|i:1750882607;red_url|s:21:\"https://82.29.165.22/\";'),
('58370343438ea9ae87a22f313c6416b5f55db029','2a02:4780:12:bfc5::1',1751019901,'__ci_last_regenerate|i:1751019901;'),
('583d49e42e273c896c5d4894a7b37018afb8063a','127.0.0.1',1750870678,'__ci_last_regenerate|i:1750870678;red_url|s:21:\"https://82.29.165.22/\";'),
('58a21802491df6dcad682ab090adc4dd790fa871','2a02:4780:12:bfc5::1',1751007902,'__ci_last_regenerate|i:1751007902;'),
('58cbf0320c0745ee03a82eb141d135a9d8db15d6','82.29.165.22',1750951202,'__ci_last_regenerate|i:1750951202;'),
('58e66b8dbb76a3423004a0199a4eb451c7f604cc','82.29.165.22',1750883701,'__ci_last_regenerate|i:1750883701;'),
('590659de7580035806883a0d3949939fee611d0a','127.0.0.1',1750957809,'__ci_last_regenerate|i:1750957809;red_url|s:21:\"https://82.29.165.22/\";'),
('590f8b326b40a1b4ce5eb2cd86273e1f1ec74311','127.0.0.1',1750921504,'__ci_last_regenerate|i:1750921503;red_url|s:21:\"https://82.29.165.22/\";'),
('592851d978d1569a9f5e0fe3450d9aed9ec17422','82.29.165.22',1750916103,'__ci_last_regenerate|i:1750916102;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('595d045cbacb65bdb708204068f4313306a78a21','157.48.80.182',1750866483,'__ci_last_regenerate|i:1750866483;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";'),
('599cb30629523e00372c2413219ea053aea04db0','82.29.165.22',1750985101,'__ci_last_regenerate|i:1750985101;'),
('59b00b93e4104d2f621ecf7dd7294ccfcd7d7044','2a02:4780:12:bfc5::1',1751011202,'__ci_last_regenerate|i:1751011201;'),
('59cd8054ecdf24937bb40532682d786947295786','2a02:4780:12:bfc5::1',1751077501,'__ci_last_regenerate|i:1751077501;'),
('59cf958b13aeb18fb5c4a86b49b2d4d86aadccf3','2a02:4780:12:bfc5::1',1751134502,'__ci_last_regenerate|i:1751134502;'),
('59e1194ff114d38fc9cf2c315a36181406cfdf0a','127.0.0.1',1750934807,'__ci_last_regenerate|i:1750934807;red_url|s:21:\"https://82.29.165.22/\";'),
('5a2a0ff6b74d05da1b251a80e3aa7a32e40e6b50','2a02:4780:12:bfc5::1',1751096402,'__ci_last_regenerate|i:1751096401;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('5a40cc0ea73c7c0ab6feac234ff5d94ad1a1eaa0','127.0.0.1',1750906310,'__ci_last_regenerate|i:1750906309;red_url|s:21:\"https://82.29.165.22/\";'),
('5a6b1b5d2c866f2c6f5edae937592fda1f0e0ffa','104.164.126.9',1751021261,'__ci_last_regenerate|i:1751021259;red_url|s:22:\"https://techdotbit.in/\";'),
('5a955e8168c3116af55880755f7d0ebcec30d689','2a02:4780:12:bfc5::1',1751080503,'__ci_last_regenerate|i:1751080502;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('5ab05e22c9b71306bddb00e917b0e5ce7af00dae','2a02:4780:12:bfc5::1',1751070302,'__ci_last_regenerate|i:1751070302;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('5b2afd8333ba1426b8b317b14d83ca5bf052f8b5','82.29.165.22',1750925703,'__ci_last_regenerate|i:1750925702;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('5b8353f245a97a90263180b99b31c534f5f02050','2a02:4780:12:bfc5::1',1751065203,'__ci_last_regenerate|i:1751065202;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('5b9f66cac3bcaa55bde94e629ec07ae58c17fe50','2a02:4780:12:bfc5::1',1751087702,'__ci_last_regenerate|i:1751087702;'),
('5bac25ff01fafd6331969c7b927b777a878acc37','82.29.165.22',1750988703,'__ci_last_regenerate|i:1750988701;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('5bd2b96bd1f0d2a8a178e3c033b494dea98f1e3c','82.29.165.22',1750921207,'__ci_last_regenerate|i:1750921202;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('5bd3eb15668364aec2cef31967566132856aed88','82.29.165.22',1750904102,'__ci_last_regenerate|i:1750904102;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('5beb687bc1dc83ff0a5c0c6e196e246a2c359000','45.135.193.162',1750884428,'__ci_last_regenerate|i:1750884428;red_url|s:21:\"https://82.29.165.22/\";'),
('5bf6d71fcc967f583d44bf5a7183424f6b5c9105','82.29.165.22',1750899002,'__ci_last_regenerate|i:1750899002;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('5c05386a25d9aa460fb8bf39ca6e99411374830d','127.0.0.1',1750879311,'__ci_last_regenerate|i:1750879311;red_url|s:21:\"https://82.29.165.22/\";'),
('5c1a9c3457b2339fdad5e3cb59ca9631938a2ace','127.0.0.1',1750858307,'__ci_last_regenerate|i:1750858307;red_url|s:21:\"https://82.29.165.22/\";'),
('5c283d2a898c909e784c8a4119f0fb9729818398','82.29.165.22',1750953004,'__ci_last_regenerate|i:1750953001;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('5c3fc624fa3b2e71b977f9f43a01f00f3c02c752','127.0.0.1',1750861007,'__ci_last_regenerate|i:1750861007;red_url|s:21:\"https://82.29.165.22/\";'),
('5c7dfde7e4aa86f60dda8c9cf14a7810495a5fab','2a02:4780:12:bfc5::1',1751081101,'__ci_last_regenerate|i:1751081101;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('5c9b657b2aa11eb328dad13d1978711344b6e1db','157.48.82.220',1750949588,'__ci_last_regenerate|i:1750949588;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;'),
('5ca3c7a572faca133fba6bd942aa90ab28a8ffc0','2a02:4780:12:bfc5::1',1751168702,'__ci_last_regenerate|i:1751168701;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('5ca41ae054bcf30c0629796e7686c375fc12cf6b','82.29.165.22',1750906204,'__ci_last_regenerate|i:1750906202;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('5d21c4a3113ae9d47eed0359e52e1b8a08418602','127.0.0.1',1750895207,'__ci_last_regenerate|i:1750895207;red_url|s:21:\"https://82.29.165.22/\";'),
('5d2eabc721f69c7c6967428904f48a0935224089','82.29.165.22',1750873501,'__ci_last_regenerate|i:1750873501;'),
('5d5b2ba7dd2390164b1df8667905c8040675212e','82.29.165.22',1750945501,'__ci_last_regenerate|i:1750945501;'),
('5d5fa25ef8939b709a8c3db5809e07b96baf074a','2a02:4780:12:bfc5::1',1751143802,'__ci_last_regenerate|i:1751143802;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('5d9e6435fd747fbfed638b232420463d155d9520','2a02:4780:12:bfc5::1',1751034901,'__ci_last_regenerate|i:1751034901;'),
('5dbd894c6418f97c9044b51665d938c9fc3000b3','2a02:4780:12:bfc5::1',1751101502,'__ci_last_regenerate|i:1751101502;'),
('5e41fe6b625a30094c41e6224047674c6fe2ed4a','127.0.0.1',1750876307,'__ci_last_regenerate|i:1750876307;red_url|s:21:\"https://82.29.165.22/\";'),
('5e50086029129c1cb853d616fb0f3334ae5e07db','2a02:4780:12:bfc5::1',1751094603,'__ci_last_regenerate|i:1751094603;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('5e58acaf527385628d9c33c84170cc24a884cb75','82.29.165.22',1750892702,'__ci_last_regenerate|i:1750892702;'),
('5e6e10b9967a8b4372bef7e5d54fd0c589ea816d','2a02:4780:12:bfc5::1',1751051701,'__ci_last_regenerate|i:1751051701;'),
('5e71d631a59523aae2230d93fdb0bdd2fbbe2989','82.29.165.22',1750872602,'__ci_last_regenerate|i:1750872602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('5e742d585e82a4640fb5d54facb5eb30f3d0c69b','82.29.165.22',1750874702,'__ci_last_regenerate|i:1750874702;'),
('5e7a0b716a28346993352c4c1b0962c94626a533','2a02:4780:12:bfc5::1',1751172003,'__ci_last_regenerate|i:1751172002;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('5ef8e8e331a6d7ad2dbb18f369980420b3d6ec53','2a02:4780:12:bfc5::1',1751056203,'__ci_last_regenerate|i:1751056202;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('5efb6c02e7894ef9ce89171412693b83e4035477','82.29.165.22',1750936802,'__ci_last_regenerate|i:1750936802;'),
('5f13a01a8ba5de4ed84e8d2940b86a33fe00312c','127.0.0.1',1750918208,'__ci_last_regenerate|i:1750918208;red_url|s:21:\"https://82.29.165.22/\";'),
('5f2a5a118ee55fa08bcbd0a4fd91c834c41ffdad','127.0.0.1',1750998707,'__ci_last_regenerate|i:1750998707;red_url|s:21:\"https://82.29.165.22/\";'),
('5f2c11e56f2e26d3a390ac5d09d6dbb7419eff43','2a02:4780:12:bfc5::1',1751005803,'__ci_last_regenerate|i:1751005802;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('5f6d03616bc3af36b511df02c558ea79ca674f94','2a02:4780:12:bfc5::1',1751166602,'__ci_last_regenerate|i:1751166601;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('5fc7955256b35349dcd413c654f2430ee75abd03','2a02:4780:12:bfc5::1',1751056502,'__ci_last_regenerate|i:1751056501;'),
('5fd1f91e652f68e52fec8c2d413f13b97505505a','82.29.165.22',1750847102,'__ci_last_regenerate|i:1750847102;'),
('5fe5c1a682a0d5dbeb410859ce0bfc1d02eb469e','139.162.193.186',1751014939,'__ci_last_regenerate|i:1751014939;'),
('600f9f1c8eff44f4031c879ff06c148fda7f97af','82.29.165.22',1750949104,'__ci_last_regenerate|i:1750949102;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('601fb96d34b55fd8a87dbbca34dc2d95653e3b5e','127.0.0.1',1750979409,'__ci_last_regenerate|i:1750979409;red_url|s:21:\"https://82.29.165.22/\";'),
('60750f0a943f8f2ba611cdf6c7848bb2c6661288','2a02:4780:12:bfc5::1',1751025901,'__ci_last_regenerate|i:1751025901;'),
('608ed43d35fb7f6acfe359deb4d0a4e439c45c0f','127.0.0.1',1750969007,'__ci_last_regenerate|i:1750969007;red_url|s:21:\"https://82.29.165.22/\";'),
('60b46e1f0f8abc926709cd9b00ec5d475d70ed83','82.29.165.22',1750882801,'__ci_last_regenerate|i:1750882801;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('6157486c6e88b9da50e130f19b4161a42c03c989','127.0.0.1',1750850510,'__ci_last_regenerate|i:1750850510;red_url|s:21:\"https://82.29.165.22/\";'),
('6169884c644f637c4bfe45b1e0c1be5311165bbd','82.29.165.22',1750878003,'__ci_last_regenerate|i:1750878001;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('618a9aa6f716ecb45fb1c586821603d9c2f47381','157.48.80.182',1750863729,'__ci_last_regenerate|i:1750863729;red_url|s:26:\"https://82.29.165.22/admin\";'),
('618ac025eb92c4cb57df4ac089b0159fa716032e','2409:40d4:10cd:43f8:ccef:f512:e762:56b2',1751080181,'__ci_last_regenerate|i:1751080181;staff_user_id|s:1:\"1\";staff_logged_in|b:1;red_url|s:39:\"https://techdotbit.in/clients?companies\";'),
('619fd76b2594afc5653765fe460416cbebb42fce','127.0.0.1',1750993507,'__ci_last_regenerate|i:1750993507;red_url|s:21:\"https://82.29.165.22/\";'),
('61c849961306777a22eb76fafd3e8646204ba5fd','82.29.165.22',1750983302,'__ci_last_regenerate|i:1750983302;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('620f4d161fd5782418bfbe82c94207e39bfd0b5d','2a02:4780:12:bfc5::1',1751163302,'__ci_last_regenerate|i:1751163302;'),
('6217c802c6ca5e113b417c87a9ad8839f7be2c7f','127.0.0.1',1750984675,'__ci_last_regenerate|i:1750984675;red_url|s:21:\"https://82.29.165.22/\";'),
('62408a5ab2843a9893f5b2cf2165c35b2fba4659','82.29.165.22',1750972502,'__ci_last_regenerate|i:1750972502;'),
('634610adf2ba49344ba8a96d173152946c37f6e0','2a02:4780:12:bfc5::1',1751139003,'__ci_last_regenerate|i:1751139002;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('637bf0b82504b1fbfaaeda49f83f084099617adc','82.29.165.22',1750995005,'__ci_last_regenerate|i:1750995002;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('6386997ef35c7f18174ace7dee6cbc9fa2724717','82.29.165.22',1750931702,'__ci_last_regenerate|i:1750931702;'),
('63af4e14bce113a27d96b543ff8b86c3e4c47437','2a02:4780:12:bfc5::1',1751149501,'__ci_last_regenerate|i:1751149501;'),
('63b5b6798c5259eb064d9e51cdc2137e7c9769e9','82.29.165.22',1750957804,'__ci_last_regenerate|i:1750957801;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('63f5a3fa1e24bacd06be54b56b6e22f35d6aa0b1','2a02:4780:12:bfc5::1',1751076302,'__ci_last_regenerate|i:1751076301;'),
('6403d40d578a640a251578d8fff337313c8ca847','2a02:4780:12:bfc5::1',1751100301,'__ci_last_regenerate|i:1751100301;'),
('6443ea9f3b766a6a5919a7ef5180886695159560','82.29.165.22',1750890902,'__ci_last_regenerate|i:1750890902;'),
('64592a0636a532f01874944d164838acf31d9184','82.29.165.22',1750946702,'__ci_last_regenerate|i:1750946702;'),
('646dd8fa15648760e037de1ea6134190e358ebcc','2a02:4780:12:bfc5::1',1751154003,'__ci_last_regenerate|i:1751154002;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('6470f47db02706589655c9b03cd499f15da45508','2a02:4780:12:bfc5::1',1751144702,'__ci_last_regenerate|i:1751144702;'),
('64b4252f862fc6138b8847f19d8fd48ae2e3e8a6','127.0.0.1',1750873607,'__ci_last_regenerate|i:1750873607;red_url|s:21:\"https://82.29.165.22/\";'),
('64c1b39edc6161c374173de798d12172995d46b4','82.29.165.22',1750986604,'__ci_last_regenerate|i:1750986602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('650b23af656bb3ba990af5910717f09d8b426798','127.0.0.1',1750868510,'__ci_last_regenerate|i:1750868510;red_url|s:21:\"https://82.29.165.22/\";'),
('651eeb4b59e91039bfd82e7741e6514679124051','127.0.0.1',1750908110,'__ci_last_regenerate|i:1750908110;red_url|s:21:\"https://82.29.165.22/\";'),
('65221f99e9460135e9b2dc8cf1e3ce93fc538600','82.29.165.22',1750849502,'__ci_last_regenerate|i:1750849502;'),
('65438b5d817133ecc86631af3491d3f9b42a71db','82.29.165.22',1750971001,'__ci_last_regenerate|i:1750971001;'),
('654fd5372e4d661dd6f2eef5b6341b01e936f983','82.29.165.22',1750983903,'__ci_last_regenerate|i:1750983901;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('656a8d11acd4b6bf988ae89e389380606139cdef','2a02:4780:12:bfc5::1',1751054702,'__ci_last_regenerate|i:1751054702;'),
('657db5f78e1d49bba4a33c9d537089092d2ba55e','82.29.165.22',1750898401,'__ci_last_regenerate|i:1750898401;'),
('659ea7a65bab82ba8cde6604a4fd799e97b0e035','127.0.0.1',1750960805,'__ci_last_regenerate|i:1750960805;red_url|s:21:\"https://82.29.165.22/\";'),
('65a6f98553d70ba218c2c100d908228b9c093e7a','2a02:4780:12:bfc5::1',1751080202,'__ci_last_regenerate|i:1751080201;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('65ae6173c8ac28c98a8199627b67ef34b6abdede','82.29.165.22',1750974902,'__ci_last_regenerate|i:1750974902;'),
('65d508881451eb69b5aafd4ac0aa2a1ef6145d78','157.48.82.220',1750922426,'__ci_last_regenerate|i:1750922426;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"old\";}'),
('65e589b5d00c08af21da3b6b7c53ef1de7343857','2409:40d4:10cd:43f8:ccef:f512:e762:56b2',1751104822,'__ci_last_regenerate|i:1751104822;staff_user_id|s:1:\"1\";staff_logged_in|b:1;red_url|s:39:\"https://techdotbit.in/clients?companies\";setup-menu-open|b:1;message-danger|s:0:\"\";__ci_vars|a:2:{s:14:\"message-danger\";s:3:\"old\";s:5:\"debug\";s:3:\"new\";}debug|s:1489:\"<h1>Your SMTP settings are not set correctly here is the debug log.</h1><br />SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting<br /><pre>\n\n</pre>Connection: opening to ssl://smtp.hostinger.com:465, timeout=30, options=array (\n  \'ssl\' => \n  array (\n    \'verify_peer\' => true,\n    \'verify_peer_name\' => false,\n    \'allow_self_signed\' => true,\n  ),\n)<br />Connection: opened<br />SERVER -> CLIENT: 220-srv810535.hstgr.cloud ESMTP Exim 4.98.1 #2 Sat, 28 Jun 2025 10:00:20 +0000 \r\n220-We do not authorize the use of this system to transport unsolicited, \r\n220 and/or bulk e-mail.\r\n<br />CLIENT -> SERVER: EHLO techdotbit.in\r\n<br />SERVER -> CLIENT: 250-srv810535.hstgr.cloud Hello techdotbit.in [2a02:4780:12:bfc5::1]\r\n250-SIZE 52428800\r\n250-LIMITS MAILMAX=1000 RCPTMAX=50000\r\n250-8BITMIME\r\n250-PIPELINING\r\n250-PIPECONNECT\r\n250-AUTH PLAIN LOGIN\r\n250 HELP\r\n<br />CLIENT -> SERVER: AUTH LOGIN\r\n<br />SERVER -> CLIENT: 334 VXNlcm5hbWU6\r\n<br />CLIENT -> SERVER: [credentials hidden]<br />SERVER -> CLIENT: 334 UGFzc3dvcmQ6\r\n<br />CLIENT -> SERVER: [credentials hidden]<br />SERVER -> CLIENT: 535 Incorrect authentication data\r\n<br />SMTP ERROR: Password command failed: 535 Incorrect authentication data\r\n<br />SMTP Error: Could not authenticate.<br />CLIENT -> SERVER: QUIT\r\n<br />SERVER -> CLIENT: 221 srv810535.hstgr.cloud closing connection\r\n<br />Connection: closed<br />SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting<br />\";'),
('66036480325d3b784e40edaac2915abc7daccf10','2409:40d4:10cd:43f8:ccef:f512:e762:56b2',1751102368,'__ci_last_regenerate|i:1751102368;staff_user_id|s:1:\"1\";staff_logged_in|b:1;red_url|s:39:\"https://techdotbit.in/clients?companies\";setup-menu-open|b:1;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('663e56c54891bd25b045a91529401030df65ce50','178.128.18.34',1751060304,'__ci_last_regenerate|i:1751060303;red_url|s:22:\"https://techdotbit.in/\";'),
('6667834dc36c2026a731200612980a3e6aa03d30','127.0.0.1',1750975809,'__ci_last_regenerate|i:1750975809;red_url|s:21:\"https://82.29.165.22/\";'),
('66861cf95232ff8abf5635f00cf1b9b11da47de6','82.29.165.22',1750864801,'__ci_last_regenerate|i:1750864801;'),
('6706c8a87dd03d8cc27099382a8b0e1fa6416cb9','127.0.0.1',1750894609,'__ci_last_regenerate|i:1750894609;red_url|s:21:\"https://82.29.165.22/\";'),
('6709fd7d4820c9d999955b7f993a0f42b4c741ef','127.0.0.1',1750929407,'__ci_last_regenerate|i:1750929407;red_url|s:21:\"https://82.29.165.22/\";'),
('677d6f475ad5784963e51d27f79c058297b6249b','2a02:4780:12:bfc5::1',1751154901,'__ci_last_regenerate|i:1751154901;'),
('677ddb1de500bfea97b237b39274c3344f0cf51c','82.29.165.22',1750948801,'__ci_last_regenerate|i:1750948801;'),
('67effcb59daaf47156cc0d5474b8c290f278c284','104.164.126.144',1751004593,'__ci_last_regenerate|i:1751004591;red_url|s:22:\"https://techdotbit.in/\";'),
('6843890a4bd395a500b5163c731cca36a9749c2e','82.29.165.22',1750857001,'__ci_last_regenerate|i:1750857001;'),
('68593d43824bd07982fe49c8604558866ca7dc77','2a02:4780:12:bfc5::1',1751063102,'__ci_last_regenerate|i:1751063102;'),
('686a83ce35821b5062ea694a99e650869a4ecef2','82.29.165.22',1750975803,'__ci_last_regenerate|i:1750975801;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('68740cc331b7bb4b5ad9133287ed4c96ed2f24e7','82.29.165.22',1750995902,'__ci_last_regenerate|i:1750995901;'),
('68a44bc1467812dcd71f83c0dbd08986b17efcf2','82.29.165.22',1750994102,'__ci_last_regenerate|i:1750994102;'),
('68ad549c78dc410df267a97c6bac4f08e28bac54','2a02:4780:12:bfc5::1',1751127002,'__ci_last_regenerate|i:1751127002;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('68cef4ea4755d96cbedfb36741bf01c29dd895cc','127.0.0.1',1750875010,'__ci_last_regenerate|i:1750875010;red_url|s:21:\"https://82.29.165.22/\";'),
('68e00038427809e58fbe80c5c690293739cec8ce','2a02:4780:12:bfc5::1',1751146203,'__ci_last_regenerate|i:1751146202;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('6998261ab101132361c824f16142d4a35d2dde2e','82.29.165.22',1750857302,'__ci_last_regenerate|i:1750857301;'),
('6a53ec30d3e797a13f0106b16bab6a678528db17','2a02:4780:12:bfc5::1',1751152501,'__ci_last_regenerate|i:1751152501;'),
('6a55138b09c5cc590cb75bb776cf380d61855adf','157.230.167.165',1750929858,'__ci_last_regenerate|i:1750929858;red_url|s:21:\"https://82.29.165.22/\";'),
('6a648e5a749ee0f059bd63db2dbc371e6ced07ec','82.29.165.22',1750955702,'__ci_last_regenerate|i:1750955701;'),
('6a93d41223d3cf36c0850e4daad30f29edd384e5','157.48.82.220',1750924502,'__ci_last_regenerate|i:1750924502;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('6aa4be7f68cb73ced6348978da77535c7c31b59e','127.0.0.1',1750904640,'__ci_last_regenerate|i:1750904640;red_url|s:21:\"https://82.29.165.22/\";'),
('6ab0fd05555aa6e01b4b87b6b988490467de20ce','127.0.0.1',1750884398,'__ci_last_regenerate|i:1750884398;red_url|s:21:\"https://82.29.165.22/\";'),
('6b1bce35f7c9359bf37067ba40da3f1a0f2f1c6a','2a02:4780:12:bfc5::1',1751046902,'__ci_last_regenerate|i:1751046902;'),
('6b56d7f5a11607cb115b4d219a849d11f43c2d06','82.29.165.22',1750885201,'__ci_last_regenerate|i:1750885201;'),
('6b753db5f3f9c7158ea59b82485a7d740d38b873','127.0.0.1',1750940207,'__ci_last_regenerate|i:1750940207;red_url|s:21:\"https://82.29.165.22/\";'),
('6b841deb569644c561f579ca40e00007153f9c8f','2409:40d4:10cd:43f8:f408:13f9:e02c:5190',1751006344,'__ci_last_regenerate|i:1751006342;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;'),
('6b9459082252d1127e91cf686002e7d10f8e3311','2a02:4780:12:bfc5::1',1751090701,'__ci_last_regenerate|i:1751090701;'),
('6b9c2ad77a3d46e71b70501e37b759a495a5955a','127.0.0.1',1750926707,'__ci_last_regenerate|i:1750926707;red_url|s:21:\"https://82.29.165.22/\";'),
('6badac9ef518d5a9ca83240c1bba15c1cdd0a499','82.29.165.22',1750961403,'__ci_last_regenerate|i:1750961401;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('6c16e7ceb714f70c8320021e64ca0de254328276','82.29.165.22',1750856702,'__ci_last_regenerate|i:1750856702;'),
('6c2d1928e9a524148fd511ecea37141ab7812e01','2a02:4780:12:bfc5::1',1751019003,'__ci_last_regenerate|i:1751019002;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('6c48ab9258fd46d608fdfd56b3923d41ade46639','2a02:4780:12:bfc5::1',1751132407,'__ci_last_regenerate|i:1751132402;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('6c602b6813c086741f4aca22710b6fbd1c4a8e85','127.0.0.1',1750957204,'__ci_last_regenerate|i:1750957204;red_url|s:21:\"https://82.29.165.22/\";'),
('6ce6562866778ebf6cff0f9a2055e90cdfd8074c','2a02:4780:12:bfc5::1',1751020802,'__ci_last_regenerate|i:1751020802;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('6ce69e6ec419c046edcfdbf3fbaf08dd6d341706','127.0.0.1',1750873910,'__ci_last_regenerate|i:1750873909;red_url|s:21:\"https://82.29.165.22/\";'),
('6ce7577ef4861c7caa98b94d53182d7b853801e7','82.29.165.22',1750884002,'__ci_last_regenerate|i:1750884002;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('6d2ae9c03da82b00ea23069c733e433de0b4ec20','82.29.165.22',1750876501,'__ci_last_regenerate|i:1750876501;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('6d3ad31ab9c05b47074b9d8484ff6e3f97d38826','82.29.165.22',1750887302,'__ci_last_regenerate|i:1750887301;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('6d6d095f83ba6f253298c69377b38d7b92aa6b72','157.48.80.182',1750867415,'__ci_last_regenerate|i:1750867415;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";'),
('6d6d59d32fc4d39882b904be6b4124ec89aac665','2409:40d4:10cd:43f8:ccef:f512:e762:56b2',1751173423,'__ci_last_regenerate|i:1751173423;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;red_url|s:39:\"https://techdotbit.in/clients?companies\";message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('6d6f60c479a2aaa8aa16430b5e21c568ba5ea5a4','127.0.0.1',1750931875,'__ci_last_regenerate|i:1750931875;red_url|s:21:\"https://82.29.165.22/\";'),
('6d9929eb6ea14387a6c5b5ec90d00d1f3c59ba04','82.29.165.22',1750996204,'__ci_last_regenerate|i:1750996202;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('6db1fa5e88176933d9f59ac400565c8355b5b54e','2a02:4780:12:bfc5::1',1751060402,'__ci_last_regenerate|i:1751060401;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('6deb2d8a58ec2ad36cd1f1fcf338e58a831e1ce1','127.0.0.1',1750892706,'__ci_last_regenerate|i:1750892706;red_url|s:21:\"https://82.29.165.22/\";'),
('6dfc4ce0323f2c39f1a4369b3ead2c835c554dee','127.0.0.1',1750911912,'__ci_last_regenerate|i:1750911912;red_url|s:21:\"https://82.29.165.22/\";'),
('6e4e79a57beb406e8c3f60948ae0c6f46b30ad49','157.48.221.10',1750952072,'__ci_last_regenerate|i:1750952072;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('6e6b1adb2d5d1ed38bcd35f090dde3d378e1c444','2a02:4780:12:bfc5::1',1751112301,'__ci_last_regenerate|i:1751112301;'),
('6e8562d0496dd4bdacf23bb6aae56127b8908b98','2a02:4780:12:bfc5::1',1751121301,'__ci_last_regenerate|i:1751121301;'),
('6e866db8a4ae0cad3ca79c53ba336ce957d85612','127.0.0.1',1750878303,'__ci_last_regenerate|i:1750878303;red_url|s:21:\"https://82.29.165.22/\";'),
('6e8c0fef49d68c8bc98af6e6af924a69d510af6f','127.0.0.1',1750997107,'__ci_last_regenerate|i:1750997107;red_url|s:21:\"https://82.29.165.22/\";'),
('6ea705cda2b8c81d4bec5a8cc880074eb5550cd8','82.29.165.22',1750989002,'__ci_last_regenerate|i:1750989002;'),
('6eae3b57770e107388bc36502178432517fb804a','2a02:4780:12:bfc5::1',1751075102,'__ci_last_regenerate|i:1751075101;'),
('6ecfa97c81af634b6e71b641b26644f40b3945b7','127.0.0.1',1750947711,'__ci_last_regenerate|i:1750947711;red_url|s:21:\"https://82.29.165.22/\";'),
('6f0534a08e2d7982e54cf93de778eff0c16b62c9','54.164.157.105',1751087779,'__ci_last_regenerate|i:1751087779;red_url|s:22:\"https://techdotbit.in/\";'),
('6f0dcf137ae128178b3597b7d7f2ec34f2a80424','2409:40d4:10cd:43f8:ccef:f512:e762:56b2',1751102699,'__ci_last_regenerate|i:1751102699;staff_user_id|s:1:\"1\";staff_logged_in|b:1;red_url|s:39:\"https://techdotbit.in/clients?companies\";setup-menu-open|b:1;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('6f53c62e49b2a65bb37fe832aa9e89ac328c30ac','2a02:4780:12:bfc5::1',1751148002,'__ci_last_regenerate|i:1751148001;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('6f592894e22d907753609c7526a28a13f3cdb673','82.29.165.22',1750944003,'__ci_last_regenerate|i:1750944002;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('6f736e969e4bc83f882765a26dc54e72e07dc3e9','157.48.221.10',1750988621,'__ci_last_regenerate|i:1750988621;staff_user_id|s:1:\"1\";staff_logged_in|b:1;red_url|s:38:\"https://82.29.165.22/clients?companies\";'),
('6fb46ba6ce46c6120073bb2f4417713655b693ed','82.29.165.22',1750986901,'__ci_last_regenerate|i:1750986901;'),
('6fc3cf87c27c81b52c67646db6804b25c03a43b8','82.29.165.22',1750885802,'__ci_last_regenerate|i:1750885802;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('6fc84fdd20e2967d9a01dacc9cff439a4bda2baf','178.128.18.34',1751068051,'__ci_last_regenerate|i:1751068051;'),
('6fcaba4c30b8246de513fe0b2e15b99be6bf4252','2a02:4780:12:bfc5::1',1751027701,'__ci_last_regenerate|i:1751027701;'),
('6fe7cddc32c56ef4f03bef7337f4c2c7e84547c8','82.29.165.22',1750867502,'__ci_last_regenerate|i:1750867502;'),
('6ff9859de6948c77fc0b122548d2c9b99eb3b7e6','127.0.0.1',1750975506,'__ci_last_regenerate|i:1750975506;red_url|s:21:\"https://82.29.165.22/\";'),
('6t3p9ql4ndhn7b5ijqu4im05qdig3jvl','2405:201:4018:225d:9952:89b6:f4e2:c984',1751368230,'__ci_last_regenerate|i:1751368099;client_user_id|s:1:\"4\";contact_user_id|s:1:\"4\";client_logged_in|b:1;'),
('7001a95655ec2fbca1057fd1a4bdfe15fdc52617','127.0.0.1',1750934210,'__ci_last_regenerate|i:1750934210;red_url|s:21:\"https://82.29.165.22/\";'),
('700b1e320e25f2914212e132628d7c19c47cf3f7','2a02:4780:12:bfc5::1',1751060102,'__ci_last_regenerate|i:1751060102;'),
('7016308d454be2bb94a78f35c65bdf4d7bb12a68','127.0.0.1',1750865507,'__ci_last_regenerate|i:1750865507;red_url|s:21:\"https://82.29.165.22/\";'),
('7033ef14d0796e24c349b2642ad1bc103ae6d23f','2a02:4780:12:bfc5::1',1751105702,'__ci_last_regenerate|i:1751105702;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('705196e9180b1a786b79c65301ed4a53cb97afb0','82.29.165.22',1750923605,'__ci_last_regenerate|i:1750923602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('706c701fc0e3e3cbae4f59d1b1c794392e20d479','82.29.165.22',1750935001,'__ci_last_regenerate|i:1750935001;'),
('70983f4c4e73ded064340a9cd920681dcccc4e4d','2a02:4780:12:bfc5::1',1751141402,'__ci_last_regenerate|i:1751141401;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('7132118f365f163dbad534a0bd77fae0a2ed337e','2a02:4780:12:bfc5::1',1751131803,'__ci_last_regenerate|i:1751131802;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('7143257fb47f1df2d67d5c168b17fcf9f8711310','82.29.165.22',1750901102,'__ci_last_regenerate|i:1750901102;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('716e047bdf9f0e955840541e10ecf5187c1a6170','82.29.165.22',1750968901,'__ci_last_regenerate|i:1750968901;'),
('7170689d47549d483950954a178f91ab4273f3af','2a02:4780:12:bfc5::1',1751108102,'__ci_last_regenerate|i:1751108102;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('717aad6060135bcda960ff518f37975e3063dc4d','82.29.165.22',1750866302,'__ci_last_regenerate|i:1750866301;'),
('717e115e3664f176fafe2bc99d91269f02766691','82.29.165.22',1750913102,'__ci_last_regenerate|i:1750913101;'),
('718c31581b5c83c63c80a598895087c7e74fcc74','2a02:4780:12:bfc5::1',1751066101,'__ci_last_regenerate|i:1751066101;'),
('718f773414966b5cba2323c1bc478dff1b1e0786','2a02:4780:12:bfc5::1',1751157901,'__ci_last_regenerate|i:1751157901;'),
('71904027662148580677057abcc792df5867648f','82.29.165.22',1750908901,'__ci_last_regenerate|i:1750908901;'),
('7190e2fbe776d83dcbfd3c256dee85d91d112aa4','127.0.0.1',1750893407,'__ci_last_regenerate|i:1750893407;red_url|s:21:\"https://82.29.165.22/\";'),
('71c6acd580519711bda614a95423c2ab4f207cb4','82.29.165.22',1750938302,'__ci_last_regenerate|i:1750938301;'),
('71db67081b2e0e3381388443f4c8da9a029ed51b','2a02:4780:12:bfc5::1',1751055602,'__ci_last_regenerate|i:1751055601;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('7203da5cfcf2dc4d7a1dd0fecacf18f727822bb4','127.0.0.1',1750877450,'__ci_last_regenerate|i:1750877450;red_url|s:21:\"https://82.29.165.22/\";'),
('7218c9739f1a45508c386884b8cfa85ddc2f3a56','127.0.0.1',1750898406,'__ci_last_regenerate|i:1750898406;red_url|s:21:\"https://82.29.165.22/\";'),
('7241d1f271240e1fb17dfdd40e871356733354fc','82.29.165.22',1750920301,'__ci_last_regenerate|i:1750920301;'),
('725e33967f999b603f3e4b5d5287f4c618ce93a7','82.29.165.22',1750971606,'__ci_last_regenerate|i:1750971603;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('726156d397b61a5383f74749753021da93f98f5c','2a02:4780:12:bfc5::1',1751036101,'__ci_last_regenerate|i:1751036101;'),
('726981c22cd651ccfa14d84a9c72ccdae21c20e0','104.252.191.40',1751172976,'__ci_last_regenerate|i:1751172974;red_url|s:22:\"https://techdotbit.in/\";'),
('72b6ba9e82975ccd96d2acd631912b0321a29852','2a02:4780:12:bfc5::1',1751132101,'__ci_last_regenerate|i:1751132101;'),
('730ff766809f1bdf3ac6dd16afb3ff8446a0821b','127.0.0.1',1750900607,'__ci_last_regenerate|i:1750900607;red_url|s:21:\"https://82.29.165.22/\";'),
('732029504086a1ae482e3d8d326c56c5644450c3','2a02:4780:12:bfc5::1',1751068201,'__ci_last_regenerate|i:1751068201;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('7342cd30f1689d87205c685784d399acb019ad04','82.29.165.22',1750929904,'__ci_last_regenerate|i:1750929901;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('73763c9a7941cdfbbbb9d1535e24e4b88d6669b1','159.89.237.85',1750930154,'__ci_last_regenerate|i:1750930154;'),
('73ce4dbd80f566dda4e008b6337a2bb4de60c2f0','2a02:4780:12:bfc5::1',1751013603,'__ci_last_regenerate|i:1751013602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('73d3354dc2458850ce307c42fe11a0bd70e0b46a','82.29.165.22',1750920902,'__ci_last_regenerate|i:1750920902;'),
('73db32768627fbaa2674193065897195ea951643','82.29.165.22',1750983004,'__ci_last_regenerate|i:1750983001;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('742d5eda80ac05145dc8d070c12767cc319367ca','2409:40d4:10cd:43f8:f408:13f9:e02c:5190',1751010139,'__ci_last_regenerate|i:1751010139;red_url|s:39:\"https://techdotbit.in/clients?companies\";client_user_id|s:1:\"4\";contact_user_id|s:1:\"4\";client_logged_in|b:1;'),
('74648e24a6854496e6c3c992cbf934f4499c5dcd','127.0.0.1',1750867507,'__ci_last_regenerate|i:1750867507;red_url|s:21:\"https://82.29.165.22/\";'),
('746c5018e3d2fca9b908d7ac28d7740601232cc1','127.0.0.1',1750937507,'__ci_last_regenerate|i:1750937507;red_url|s:21:\"https://82.29.165.22/\";'),
('748357202a6f1d5f1b67f3d07a15e31aa625277f','82.29.165.22',1750968006,'__ci_last_regenerate|i:1750968002;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('755d1027a42a629045acca57f96810a467ec1a0c','82.29.165.22',1750935607,'__ci_last_regenerate|i:1750935602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('756b6082611522239931b0a618e8f124241eb006','2a02:4780:12:bfc5::1',1751125802,'__ci_last_regenerate|i:1751125801;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('759db06a3fc0c883ee3df35bf1d56ed384cb8227','127.0.0.1',1750860003,'__ci_last_regenerate|i:1750860003;red_url|s:21:\"https://82.29.165.22/\";'),
('75e9792773a321889083ce39c90c1076027a1a55','2a02:4780:12:bfc5::1',1751015101,'__ci_last_regenerate|i:1751015101;'),
('7639665ff39ba1dc82e88b41d7a62b55f8956300','2a02:4780:12:bfc5::1',1751088902,'__ci_last_regenerate|i:1751088901;'),
('76456dba77e389e29f82c9244beb7c666abaaffb','2409:40d4:10cd:43f8:f408:13f9:e02c:5190',1751004125,'__ci_last_regenerate|i:1751004125;perfex_saas_enable_auto_trial|s:1:\"0\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";red_url|s:39:\"https://techdotbit.in/clients?companies\";'),
('76513ad2fd84dca2e66f834013211e545571bc17','2a02:4780:12:bfc5::1',1751124002,'__ci_last_regenerate|i:1751124002;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('7659cd377b823cb3e0f4bc62f9d5c073cc995f98','82.29.165.22',1750960202,'__ci_last_regenerate|i:1750960202;'),
('7689b74f48a8ad1b76739e90fb8d320f66be6836','127.0.0.1',1750899906,'__ci_last_regenerate|i:1750899906;red_url|s:21:\"https://82.29.165.22/\";'),
('76a4a73c01e9775778f7668bec3424ce1ed8c2d9','2a02:4780:12:bfc5::1',1751066403,'__ci_last_regenerate|i:1751066402;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('76e0af8db497ac5e6bad498f527260ed50cd6d4b','2a02:4780:12:bfc5::1',1751036403,'__ci_last_regenerate|i:1751036402;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('773aff6ebcd4be0abe1d1c404ef3cf2adbe9e082','54.164.157.105',1751087803,'__ci_last_regenerate|i:1751087798;red_url|s:39:\"https://techdotbit.in/clients?companies\";'),
('776ac29b878732183051be58b5e6b0b9333ab990','82.29.165.22',1750854901,'__ci_last_regenerate|i:1750854901;'),
('778e15e57181a1f8697403004f74d4994e2fe59f','82.29.165.22',1750886101,'__ci_last_regenerate|i:1750886101;'),
('77a35678927300f3cc93fa363f6b127f558a7b1a','2a02:4780:12:bfc5::1',1751119202,'__ci_last_regenerate|i:1751119202;'),
('77d7c9a128486bf52f12a37cfccd9ed4f356a0b0','127.0.0.1',1750941410,'__ci_last_regenerate|i:1750941410;red_url|s:21:\"https://82.29.165.22/\";'),
('77f2b2ac0c71ed29b0809eca4e99c9a45c98f5d0','42.98.61.110',1750984070,'__ci_last_regenerate|i:1750984070;red_url|s:21:\"https://82.29.165.22/\";'),
('781190b5c4bf035b4d772ad64dcf2fb6350a2204','82.29.165.22',1750858501,'__ci_last_regenerate|i:1750858501;'),
('7812e5bdc733638d3f549c3eac741c74baafa83c','2a02:4780:12:bfc5::1',1751134802,'__ci_last_regenerate|i:1751134802;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('781cdf03f92d7d7cdaef38b68bfc3393c9a0c5a8','127.0.0.1',1750965010,'__ci_last_regenerate|i:1750965009;red_url|s:21:\"https://82.29.165.22/\";'),
('78288704d7797a0d0b2f8e1537d0333122266e25','126.203.46.141',1750910242,'__ci_last_regenerate|i:1750910242;red_url|s:21:\"https://82.29.165.22/\";'),
('78590c27a44b22e4a8b5a5a4df0906f2e3cb0018','127.0.0.1',1750928404,'__ci_last_regenerate|i:1750928404;red_url|s:21:\"https://82.29.165.22/\";'),
('78628369540f721ad206de6548cc88c9216347e0','82.29.165.22',1750929304,'__ci_last_regenerate|i:1750929301;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('7863a697851e64b99f4d8322e6359a3f3acb548a','82.29.165.22',1750999203,'__ci_last_regenerate|i:1750999202;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('787ddd20ecdddd7a324b375ae66e15d11b88e1e4','34.22.151.137',1750847766,'__ci_last_regenerate|i:1750847766;red_url|s:21:\"https://82.29.165.22/\";'),
('7896196a229ca0a20165af06b7438fd3000e4d11','2a05:9403::5f9',1751050297,'__ci_last_regenerate|i:1751050297;is_mobile|b:1;'),
('78bf6872f64049d53328c9dad47cb8c72f596025','2a02:4780:12:bfc5::1',1751167201,'__ci_last_regenerate|i:1751167201;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('78eea92261cf6508a5697b83f3189afd7cb02f7f','82.29.165.22',1750992604,'__ci_last_regenerate|i:1750992601;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('79000a2ac9eb6b2cc3cd8125e7c35ed3b40765f2','2409:40d4:10cd:43f8:ccef:f512:e762:56b2',1751167335,'__ci_last_regenerate|i:1751167335;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;message-danger|s:0:\"\";__ci_vars|a:2:{s:14:\"message-danger\";s:3:\"old\";s:5:\"debug\";s:3:\"new\";}debug|s:1489:\"<h1>Your SMTP settings are not set correctly here is the debug log.</h1><br />SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting<br /><pre>\n\n</pre>Connection: opening to ssl://smtp.hostinger.com:465, timeout=30, options=array (\n  \'ssl\' => \n  array (\n    \'verify_peer\' => true,\n    \'verify_peer_name\' => false,\n    \'allow_self_signed\' => true,\n  ),\n)<br />Connection: opened<br />SERVER -> CLIENT: 220-srv810535.hstgr.cloud ESMTP Exim 4.98.1 #2 Sun, 29 Jun 2025 03:22:13 +0000 \r\n220-We do not authorize the use of this system to transport unsolicited, \r\n220 and/or bulk e-mail.\r\n<br />CLIENT -> SERVER: EHLO techdotbit.in\r\n<br />SERVER -> CLIENT: 250-srv810535.hstgr.cloud Hello techdotbit.in [2a02:4780:12:bfc5::1]\r\n250-SIZE 52428800\r\n250-LIMITS MAILMAX=1000 RCPTMAX=50000\r\n250-8BITMIME\r\n250-PIPELINING\r\n250-PIPECONNECT\r\n250-AUTH PLAIN LOGIN\r\n250 HELP\r\n<br />CLIENT -> SERVER: AUTH LOGIN\r\n<br />SERVER -> CLIENT: 334 VXNlcm5hbWU6\r\n<br />CLIENT -> SERVER: [credentials hidden]<br />SERVER -> CLIENT: 334 UGFzc3dvcmQ6\r\n<br />CLIENT -> SERVER: [credentials hidden]<br />SERVER -> CLIENT: 535 Incorrect authentication data\r\n<br />SMTP ERROR: Password command failed: 535 Incorrect authentication data\r\n<br />SMTP Error: Could not authenticate.<br />CLIENT -> SERVER: QUIT\r\n<br />SERVER -> CLIENT: 221 srv810535.hstgr.cloud closing connection\r\n<br />Connection: closed<br />SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting<br />\";'),
('7900a0fc058da53bbad6a22aee9503efde6ff367','82.29.165.22',1750876201,'__ci_last_regenerate|i:1750876201;'),
('7907846d82f2958e29f57bba7dd1c50d0c0d045e','127.0.0.1',1750976207,'__ci_last_regenerate|i:1750976207;red_url|s:21:\"https://82.29.165.22/\";'),
('792626074d03ace4812717e31fa44335f6aee301','2a02:4780:12:bfc5::1',1751166003,'__ci_last_regenerate|i:1751166002;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('793bc7dbf2e252bea633603f2970f9bfedc8e839','127.0.0.1',1750886577,'__ci_last_regenerate|i:1750886577;red_url|s:21:\"https://82.29.165.22/\";'),
('796b1a4f447615f778275943e6e1244a50328eb4','157.48.80.182',1750898622,'__ci_last_regenerate|i:1750898622;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;ps_slug|s:12:\"starter-plan\";message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('7992fd248fe2b3c7210bb7de90266afc6bd8d2dd','127.0.0.1',1750984180,'__ci_last_regenerate|i:1750984180;red_url|s:21:\"https://82.29.165.22/\";'),
('79c855bdb12933cca8b6bd67e8f8cf9fda123b57','2a02:4780:12:bfc5::1',1751129402,'__ci_last_regenerate|i:1751129402;'),
('7a2e481cf404557c529b9652a0f9c36ef4fcd004','185.89.156.166',1750912689,'__ci_last_regenerate|i:1750912689;red_url|s:21:\"https://82.29.165.22/\";'),
('7a4ded225d32c50a0733bbb8c4bc40c944ccaabb','127.0.0.1',1750978007,'__ci_last_regenerate|i:1750978007;red_url|s:21:\"https://82.29.165.22/\";'),
('7a92b519a4829517ce0eaeed322ae28a2e92ec2d','127.0.0.1',1750853409,'__ci_last_regenerate|i:1750853409;red_url|s:21:\"https://82.29.165.22/\";'),
('7a9d6e24646769d487463aa0994628564f351489','2a05:9403::5f9',1751050296,'__ci_last_regenerate|i:1751050296;is_mobile|b:1;red_url|s:22:\"https://techdotbit.in/\";'),
('7abbe69b53652e00a08aad98e78b3347db152a58','82.29.165.22',1750927201,'__ci_last_regenerate|i:1750927201;'),
('7ac426d83727a18397814b69f6b3c15c941b51ac','127.0.0.1',1750997807,'__ci_last_regenerate|i:1750997807;red_url|s:21:\"https://82.29.165.22/\";'),
('7b292753c505ce8215402d32029e12bde1b75f6a','82.29.165.22',1750910102,'__ci_last_regenerate|i:1750910102;'),
('7b603a72b7e734b95d300c243ccec28235ac5dcb','82.29.165.22',1751000701,'__ci_last_regenerate|i:1751000701;'),
('7b75759b4b8d129fdb9a4c51e997e2dec6e61fde','82.29.165.22',1751000104,'__ci_last_regenerate|i:1751000101;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('7b82e769a836e6da2eb57b4c6aa908403fc04fa2','82.29.165.22',1750903502,'__ci_last_regenerate|i:1750903502;'),
('7bbc5a65aae4e5221e12a7b39c1143bf36a7b625','2a02:4780:12:bfc5::1',1751118602,'__ci_last_regenerate|i:1751118602;'),
('7c8861f5b08304b4b1ed1eb00853ea6511dc0745','213.159.195.120',1750872124,'__ci_last_regenerate|i:1750872124;red_url|s:21:\"https://82.29.165.22/\";'),
('7cb17b31fb0dfd948818f3898ef4a1dd24633c07','82.29.165.22',1750893001,'__ci_last_regenerate|i:1750893001;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('7cf6e5c4d9e834e0b9039c746ffec82846c24850','82.29.165.22',1750941001,'__ci_last_regenerate|i:1750941001;'),
('7d02c156403f1dd55da37caec5d5c53fe559e52a','127.0.0.1',1750943807,'__ci_last_regenerate|i:1750943807;red_url|s:21:\"https://82.29.165.22/\";'),
('7d16c86a93b360c672512b8ec87ec1e63ad4e220','82.29.165.22',1750924502,'__ci_last_regenerate|i:1750924501;'),
('7d2efb55cf435994e96831be5bdc075709925149','2409:40d4:10cd:43f8:ccef:f512:e762:56b2',1751167663,'__ci_last_regenerate|i:1751167663;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('7d376910de6916c64158c5dbde916825d6eca438','2a02:4780:12:bfc5::1',1751051402,'__ci_last_regenerate|i:1751051402;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('7d481113ddd1a6eab824c0709e8d77452fd6aba7','82.29.165.22',1750896006,'__ci_last_regenerate|i:1750896006;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('7d573b92205dd30234bdc772a51e89543eebd11b','2409:40d4:10cd:43f8:f408:13f9:e02c:5190',1751006703,'__ci_last_regenerate|i:1751006703;perfex_saas_enable_auto_trial|s:1:\"0\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";client_user_id|s:1:\"2\";contact_user_id|s:1:\"2\";client_logged_in|b:1;'),
('7d6856ab72ba7bbdf12dd469fdd66f05e18c7549','82.29.165.22',1750926001,'__ci_last_regenerate|i:1750926001;'),
('7daefe7dc9079ea838fba940aeb5a386f077c244','82.29.165.22',1750979403,'__ci_last_regenerate|i:1750979402;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('7db02001c8f2dd1081bfdaaf9e83e99a655c428d','82.29.165.22',1750902305,'__ci_last_regenerate|i:1750902301;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('7db2e9b1632a93fef741dd86d7bd94b35a3ff67e','2a02:4780:12:bfc5::1',1751022902,'__ci_last_regenerate|i:1751022901;'),
('7dd090b30d3e3755715e8e04c4cfd72460e9772e','2409:40d4:10cd:43f8:f408:13f9:e02c:5190',1751011047,'__ci_last_regenerate|i:1751011047;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"old\";}'),
('7e66c1837020976af56871fa9b29758506671695','127.0.0.1',1750912307,'__ci_last_regenerate|i:1750912307;red_url|s:21:\"https://82.29.165.22/\";'),
('7e8c9fddb9cffa5c86833bcb5ed7801e78a8812d','82.29.165.22',1750918203,'__ci_last_regenerate|i:1750918202;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('7ea7306472f493aa04308297c4a437c3fd21edcd','2a02:4780:12:bfc5::1',1751124901,'__ci_last_regenerate|i:1751124901;'),
('7eb5b0867e53a559fac8f4c2a27ff465d5bf838b','2a02:4780:12:bfc5::1',1751070002,'__ci_last_regenerate|i:1751070001;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('7ef391e5d7e09ab4e93bbb349ddbf574237d5c2e','82.29.165.22',1750908302,'__ci_last_regenerate|i:1750908302;'),
('7ef7a89764f57b7d5b2e8a4c422dff3335494e6e','103.4.250.130',1751006626,'__ci_last_regenerate|i:1751006624;red_url|s:22:\"https://techdotbit.in/\";'),
('7fe26d369582e2695867671d4601294e82a3855b','2a02:4780:12:bfc5::1',1751099403,'__ci_last_regenerate|i:1751099402;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('803c7cd7d5137cf86bc6d8e43e6e4e4883d66ca1','82.29.165.22',1750975206,'__ci_last_regenerate|i:1750975202;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('803cb4de5902b625a91eb71e58c60ad30d5b314e','165.22.141.51',1750930899,'__ci_last_regenerate|i:1750930898;red_url|s:21:\"https://82.29.165.22/\";'),
('806f8a6fd5a67cc7a94999fd232ceac1a3efe70a','2409:40d4:10cd:43f8:f408:13f9:e02c:5190',1751005876,'__ci_last_regenerate|i:1751005876;red_url|s:39:\"https://techdotbit.in/clients?companies\";client_user_id|s:1:\"3\";contact_user_id|s:1:\"3\";client_logged_in|b:1;perfex_saas_enable_auto_trial|s:1:\"0\";'),
('80743134a11fbeb2486f1f519aa17e9866d6cb0e','2a02:4780:12:bfc5::1',1751097302,'__ci_last_regenerate|i:1751097302;'),
('809e3805a843374441a23bace1c9116ac2e993b4','2a02:4780:12:bfc5::1',1751075702,'__ci_last_regenerate|i:1751075702;'),
('809f0a2100dbe19e6c3e24588dba1d28c426e842','82.29.165.22',1750988102,'__ci_last_regenerate|i:1750988102;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('80a3b4c83f28a8f01ff00b70135b9895f231a399','82.29.165.22',1750989303,'__ci_last_regenerate|i:1750989301;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('80cf98a89c30a1da51da4c93177cef868790b0ce','2a02:4780:12:bfc5::1',1751104201,'__ci_last_regenerate|i:1751104201;'),
('8110e81dcc5bbb44937f9f936ab2b53c4cbe0231','82.29.165.22',1750962601,'__ci_last_regenerate|i:1750962601;'),
('8131a3ef1e176b50feeabe6458f97cfeecab5ce5','127.0.0.1',1750992407,'__ci_last_regenerate|i:1750992407;red_url|s:21:\"https://82.29.165.22/\";'),
('81451cf19e1ce55ce767ca0bfa4d300a896d338b','82.29.165.22',1750872001,'__ci_last_regenerate|i:1750872001;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('814a449c288e347aa7fe860b67f6cd7f0c82a2a5','2a02:4780:12:bfc5::1',1751041501,'__ci_last_regenerate|i:1751041501;'),
('81bcd6795b5dc51c10ebf08849281ceb987c9869','2a02:4780:12:bfc5::1',1751103902,'__ci_last_regenerate|i:1751103902;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('8203bd0d427be4fa0a0ce50ede4e23349c5ff2d1','82.29.165.22',1750958102,'__ci_last_regenerate|i:1750958102;'),
('82bf620c0e0f5c113210d1c14e18dfa47df6776b','2a02:4780:12:bfc5::1',1751114101,'__ci_last_regenerate|i:1751114101;'),
('82ec55aca481022a6dfe2defc3a5efb9cd1f651e','82.29.165.22',1750930802,'__ci_last_regenerate|i:1750930802;'),
('8316444ef1c33115c7ee76f09307e303ab2a85a5','2a02:4780:12:bfc5::1',1751096102,'__ci_last_regenerate|i:1751096102;'),
('831bd4122f96133541c168e7f30db46dbc33ce51','82.29.165.22',1750963803,'__ci_last_regenerate|i:1750963802;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('83404b3850496085f9b64d07187664e3bedcf70a','127.0.0.1',1750970210,'__ci_last_regenerate|i:1750970209;red_url|s:21:\"https://82.29.165.22/\";'),
('83463010dc14571bdde29b24c101c8097c4e50ae','44.234.152.25',1751074958,'__ci_last_regenerate|i:1751074957;is_mobile|b:1;red_url|s:22:\"https://techdotbit.in/\";'),
('835f7d53273716630c1aa8ffbf0ca26652bead3a','2a02:4780:12:bfc5::1',1751164203,'__ci_last_regenerate|i:1751164202;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('836f912e78afa2969211fb848019fcd787f36257','82.29.165.22',1750925404,'__ci_last_regenerate|i:1750925401;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('8373b1c3e68da63921ff6502b93815c74d410e6e','82.29.165.22',1750963503,'__ci_last_regenerate|i:1750963501;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('837a46ce1757d254a37625de711bf035e5bcd3eb','82.29.165.22',1750964101,'__ci_last_regenerate|i:1750964101;'),
('838778f2cc6a3471460578fed97aec01e4e98461','127.0.0.1',1750885203,'__ci_last_regenerate|i:1750885202;red_url|s:21:\"https://82.29.165.22/\";'),
('83cc8bc4ed55f9d272637350283a5e0aead438fa','82.29.165.22',1750883101,'__ci_last_regenerate|i:1750883101;'),
('841e3b70e5801accfb23e1e8c49724ad4fe9c278','127.0.0.1',1750924008,'__ci_last_regenerate|i:1750924007;red_url|s:21:\"https://82.29.165.22/\";'),
('843266fd80a0b200fc4f2e2066773ddd1f9bf6af','82.29.165.22',1751000403,'__ci_last_regenerate|i:1751000402;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('845c90f948060d89b7b2353bd98904a3b3ec78bf','82.29.165.22',1750917304,'__ci_last_regenerate|i:1750917301;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('8475c895a739c3e0f8220827f797601dcca5d104','157.48.82.220',1750933188,'__ci_last_regenerate|i:1750933188;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"old\";}'),
('847ee422caeaeca9186a866e9f59816a7a138313','2a02:4780:12:bfc5::1',1751086802,'__ci_last_regenerate|i:1751086802;'),
('84a76f97d0653e4e6f47016009a5868cd38fa8d0','2a02:4780:12:bfc5::1',1751018702,'__ci_last_regenerate|i:1751018701;'),
('84af1d7139aff294d75f6eee0a95da8462c03e93','127.0.0.1',1750902709,'__ci_last_regenerate|i:1750902709;red_url|s:21:\"https://82.29.165.22/\";'),
('853baa0f9e3dc3d4fbfa3a93e444ccded327b37d','2a02:4780:12:bfc5::1',1751094302,'__ci_last_regenerate|i:1751094302;'),
('85664fc1c249979454d77a78c82606ac15d1cea5','82.29.165.22',1750879202,'__ci_last_regenerate|i:1750879201;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('8596085d33963057b1063d891dfbf91db39d5e94','2a02:4780:12:bfc5::1',1751172901,'__ci_last_regenerate|i:1751172901;'),
('8599ddd39d50eb2b8917fea5c1d54137242cc084','157.48.80.182',1750867799,'__ci_last_regenerate|i:1750867799;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";'),
('85b68fcf3a73f61266c3b7bd83560e0559cca971','82.29.165.22',1750897201,'__ci_last_regenerate|i:1750897201;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('85e8b51952a54888fdff5f2d3fbdd4c7fb5458e1','2a02:4780:12:bfc5::1',1751173203,'__ci_last_regenerate|i:1751173202;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('85f47ad622e145ab3aa9dba26e8bfc9eb46a96b6','2a02:4780:12:bfc5::1',1751136002,'__ci_last_regenerate|i:1751136002;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('8630036828aa69371bc9f33cfb5591aa28432bbf','106.219.224.219',1750924829,'__ci_last_regenerate|i:1750924806;red_url|s:26:\"https://82.29.165.22/admin\";message-danger|s:25:\"Invalid email or password\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"old\";}'),
('8637483b08a8071044c865978b76896c83c8a71a','2a02:4780:12:bfc5::1',1751105103,'__ci_last_regenerate|i:1751105102;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('863902a29a36f91becade565518cdeefec5acd6a','2a02:4780:12:bfc5::1',1751061002,'__ci_last_regenerate|i:1751061002;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('866ab8a921bd922907f52979b6641a82de05ccc0','127.0.0.1',1750978310,'__ci_last_regenerate|i:1750978309;red_url|s:21:\"https://82.29.165.22/\";'),
('867d3a7403bb481e6c6b432b36e21677645390af','82.29.165.22',1750937403,'__ci_last_regenerate|i:1750937402;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('868c53b7399308f387f95823b0b31eac51ca564c','82.29.165.22',1750890002,'__ci_last_regenerate|i:1750890002;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('86bc44f4a14779a18c7f7f42ae80751efe525ad3','40.77.167.69',1751169435,'__ci_last_regenerate|i:1751169435;'),
('86d840773f1ea01377f584a83ef8af24dcf72624','139.162.193.29',1750997605,'__ci_last_regenerate|i:1750997605;red_url|s:21:\"https://82.29.165.22/\";'),
('86d8761643dca43abb1cee53ef88366ad2362564','157.48.80.182',1750869498,'__ci_last_regenerate|i:1750869498;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"old\";}'),
('86f454edd50a4c3424c8bbc6950054b67704e4d0','2a02:4780:12:bfc5::1',1751073302,'__ci_last_regenerate|i:1751073302;'),
('8712a1aeb1924150000b3ac278e3d8c97edbd41c','82.29.165.22',1750850102,'__ci_last_regenerate|i:1750850102;'),
('874c1e0176251a57dea4387fc1fb2c514511a404','82.29.165.22',1750965901,'__ci_last_regenerate|i:1750965901;'),
('8766c1d768b3fc521927f1c2c224bece34dc56dc','106.219.224.219',1750920741,'__ci_last_regenerate|i:1750920741;red_url|s:38:\"https://82.29.165.22/clients?companies\";'),
('8783b1e1cbebf9b7d9f4f4671f19ea1ba93dec48','82.29.165.22',1750977902,'__ci_last_regenerate|i:1750977902;'),
('87a6a7b5314952a54f3c30aa8394204d75050083','157.48.80.182',1750866805,'__ci_last_regenerate|i:1750866805;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";'),
('87ccb67ec80e5cb5f109a4cdfff5988ba300d3e3','127.0.0.1',1750988210,'__ci_last_regenerate|i:1750988210;red_url|s:21:\"https://82.29.165.22/\";'),
('87d6e7065880c78e14d9ad46e7fadc390f2dd9d9','82.29.165.22',1750869902,'__ci_last_regenerate|i:1750869901;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('87e9188ae64eab347664ab4759d01fc79b44433b','2a02:4780:12:bfc5::1',1751172302,'__ci_last_regenerate|i:1751172302;'),
('87f6bd6984f6a20a9dd2936d6f5c5a3ec861840b','82.29.165.22',1750902602,'__ci_last_regenerate|i:1750902601;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('88058f57d6c8b19e99711d9e9059e56c316a137f','82.29.165.22',1750997702,'__ci_last_regenerate|i:1750997702;'),
('880d3331125e106da6e9f8ca7343e0930f6d8692','82.29.165.22',1750923301,'__ci_last_regenerate|i:1750923301;'),
('8898e76cbf90ab625884df5545514d5b4093ea06','2a02:4780:12:bfc5::1',1751088301,'__ci_last_regenerate|i:1751088301;'),
('88a8c0478d153022ed618d023ae036785036c716','127.0.0.1',1750935605,'__ci_last_regenerate|i:1750935604;red_url|s:21:\"https://82.29.165.22/\";'),
('88e6d9883e286beaac86f9d3b4376913ef209ca8','82.29.165.22',1750991104,'__ci_last_regenerate|i:1750991101;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('88efc761dc571110d1570ce0bd77c6f25f1910ea','2a02:4780:12:bfc5::1',1751043002,'__ci_last_regenerate|i:1751043002;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('88fba7790b110bac9369e507370219aee223805b','2a02:4780:12:bfc5::1',1751042702,'__ci_last_regenerate|i:1751042702;'),
('8936a3030c8fab73969c94f73e5df52c5000ad90','82.29.165.22',1750908003,'__ci_last_regenerate|i:1750908001;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('895f90987dea219e6ba30d9d0a2128a3afd076d0','2409:40d4:10cd:43f8:ccef:f512:e762:56b2',1751079682,'__ci_last_regenerate|i:1751079682;staff_user_id|s:1:\"1\";staff_logged_in|b:1;red_url|s:39:\"https://techdotbit.in/clients?companies\";'),
('897001ed2bbcdd3462bef151746bc6bccaba67ad','82.29.165.22',1750998004,'__ci_last_regenerate|i:1750998001;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('89b9e7f31b7ed2910dae981a8fe163effa0c5cdb','82.29.165.22',1750857901,'__ci_last_regenerate|i:1750857901;'),
('89bcece753faa0087d7d55178544de4f658be196','82.29.165.22',1750907701,'__ci_last_regenerate|i:1750907701;'),
('89c634466bf2ea3fcdf8ffcb7c6c3ee1727eed24','2a02:4780:12:bfc5::1',1751147102,'__ci_last_regenerate|i:1751147102;'),
('89d64576ef0820fef49604e816f44f99617670d3','157.48.80.182',1750898303,'__ci_last_regenerate|i:1750898303;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"old\";}'),
('89ed01a4b9d9dfc66b1d4d4353111c604d2d8608','54.174.140.70',1751001298,'__ci_last_regenerate|i:1751001298;red_url|s:22:\"https://techdotbit.in/\";'),
('89fa0c4e51baa6ed419e439944baff339564c696','82.29.165.22',1750990502,'__ci_last_regenerate|i:1750990502;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('8a045cf2a62cf326ef09a83ead5ea4442efc0d2f','82.29.165.22',1750944605,'__ci_last_regenerate|i:1750944602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('8a12669a36f69dd5df109592ba032167453f3923','205.169.39.13',1751012585,'__ci_last_regenerate|i:1751012579;red_url|s:39:\"https://techdotbit.in/clients?companies\";'),
('8a1f68fd90c9819598785762ad506a323473c5e6','127.0.0.1',1750905409,'__ci_last_regenerate|i:1750905409;red_url|s:21:\"https://82.29.165.22/\";'),
('8a285b5ea631233397e9d0e1b506e0a9b2b0e049','82.29.165.22',1750871401,'__ci_last_regenerate|i:1750871401;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('8a385f5f1bf74fbf32068c9873145f2f28fed8e4','2a02:4780:12:bfc5::1',1751110501,'__ci_last_regenerate|i:1751110501;'),
('8ac6b71d41fd1e83f65681b1c1a2fe6a45a46df3','82.29.165.22',1750977003,'__ci_last_regenerate|i:1750977002;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('8ad59b8e4e8ed8f8a730b7bf8e5b28a28148b259','206.168.34.41',1750978220,'__ci_last_regenerate|i:1750978220;red_url|s:21:\"https://82.29.165.22/\";'),
('8ade8cbcd2efc30ea28982b81fb3e474e40e3950','127.0.0.1',1750963910,'__ci_last_regenerate|i:1750963910;red_url|s:21:\"https://82.29.165.22/\";'),
('8afdc60c63ad970acf433387511893987ca07f7e','2401:4900:838e:de27:c898:fcf3:3be5:9ab9',1751144467,'__ci_last_regenerate|i:1751144460;red_url|s:39:\"https://techdotbit.in/clients?companies\";'),
('8b3ae5c8f08a79aff45964829043de81377482a4','82.29.165.22',1750870201,'__ci_last_regenerate|i:1750870201;'),
('8b455aecd4bcc91596b112b0c6f20fb85fe0351a','2a02:4780:12:bfc5::1',1751071202,'__ci_last_regenerate|i:1751071202;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('8b985c77e8b61502d29f9cad731419f636a4361b','2a02:4780:12:bfc5::1',1751003102,'__ci_last_regenerate|i:1751003102;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('8bb6b28c614f6961523bdc3d02f9fe1f75920b2e','127.0.0.1',1750973810,'__ci_last_regenerate|i:1750973810;red_url|s:21:\"https://82.29.165.22/\";'),
('8bd5e4bc4b0a510e76ba7b893d87bf6a9bb63ebe','2a02:4780:12:bfc5::1',1751024701,'__ci_last_regenerate|i:1751024701;'),
('8c59fabef102e138897f568df23504c4419e7d44','2a02:4780:12:bfc5::1',1751096702,'__ci_last_regenerate|i:1751096702;'),
('8c5f462330b46fec8e4d065895c1df99a27f2828','82.29.165.22',1750878602,'__ci_last_regenerate|i:1750878602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('8caa4e4530f053f3370295ab53934e1f1a98b978','2a02:4780:12:bfc5::1',1751159701,'__ci_last_regenerate|i:1751159701;'),
('8cf3b774d409439f56dff0a60c385265ae499fe1','127.0.0.1',1750972607,'__ci_last_regenerate|i:1750972607;red_url|s:21:\"https://82.29.165.22/\";'),
('8cfc1ff7a535e94d37aa6f90c4c32d2ceb8abd71','127.0.0.1',1750989906,'__ci_last_regenerate|i:1750989906;red_url|s:21:\"https://82.29.165.22/\";'),
('8d0352c5b3b18f3cd51c68d553af6678c5c90194','2a02:4780:12:bfc5::1',1751012702,'__ci_last_regenerate|i:1751012701;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('8d11297d2b6b22d88eae1fd59c375f7af206810c','82.29.165.22',1750879502,'__ci_last_regenerate|i:1750879502;'),
('8d97f43d3384903087f03c7a4bec3795d2aa7f11','2a02:4780:12:bfc5::1',1751154602,'__ci_last_regenerate|i:1751154602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('8e1296c1434667a22fe7e95aaa251bdd81ff769e','82.29.165.22',1750999502,'__ci_last_regenerate|i:1750999501;'),
('8e17d59aebd36795312229cff343c786c3b98d41','2a02:4780:12:bfc5::1',1751057402,'__ci_last_regenerate|i:1751057402;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('8e4b32e2c10b5d66b975b9a29b257c19d64a3551','127.0.0.1',1750867810,'__ci_last_regenerate|i:1750867810;red_url|s:21:\"https://82.29.165.22/\";'),
('8e4d5f2cfc1789943fd6b099c9128122d0c518f3','2a02:4780:12:bfc5::1',1751109002,'__ci_last_regenerate|i:1751109002;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('8e5117b13436f6137e970cbf12c63ff62b6a347a','82.29.165.22',1750951803,'__ci_last_regenerate|i:1750951801;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('8e946a6c875c7083b638342a5d02761c61c06ec2','82.29.165.22',1750938604,'__ci_last_regenerate|i:1750938602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('8e9f7bba2d0dc07d1162532c3a0832b04e66a73b','2a02:4780:12:bfc5::1',1751078702,'__ci_last_regenerate|i:1751078702;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('8ed562dbb347cce9e72125034f70b33ba2753f49','2a02:4780:12:bfc5::1',1751037302,'__ci_last_regenerate|i:1751037302;'),
('8eea40e6bfa81a7cbaf76c6257ae9ebf972f9452','127.0.0.1',1750862807,'__ci_last_regenerate|i:1750862807;red_url|s:21:\"https://82.29.165.22/\";'),
('8f03cc22174bf7e498b6b8db16a25948ba7a6987','82.29.165.22',1750889102,'__ci_last_regenerate|i:1750889101;'),
('8f1f698ab2c07b78d2ea9034c3411772421afd55','2a02:4780:12:bfc5::1',1751118903,'__ci_last_regenerate|i:1751118902;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('8f3f830cb874d5703cf1751c4d4161d583a9816f','127.0.0.1',1750871807,'__ci_last_regenerate|i:1750871807;red_url|s:21:\"https://82.29.165.22/\";'),
('8f415dc6206cf071e3c33feff7261b10f6436f79','82.29.165.22',1750982702,'__ci_last_regenerate|i:1750982702;'),
('8f70e026d2b0f55cc2888c662b1837007ae3618a','82.29.165.22',1750912501,'__ci_last_regenerate|i:1750912501;'),
('8f752188f6db1abbe99f2971da9b6d7542edf440','2a02:4780:12:bfc5::1',1751171403,'__ci_last_regenerate|i:1751171402;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('8f896706dc446453d6c8074723280ba978a08b31','2a02:4780:12:bfc5::1',1751042402,'__ci_last_regenerate|i:1751042401;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('8fda2846f4a3659cbb62b8cd962578b90eeeb773','127.0.0.1',1750868207,'__ci_last_regenerate|i:1750868207;red_url|s:21:\"https://82.29.165.22/\";'),
('8fff19d442f708eb72aa8b4a205d064b16012971','2a02:4780:12:bfc5::1',1751027101,'__ci_last_regenerate|i:1751027101;'),
('901ed770d556a980f7b2ef53c0cdbb992df57892','2a02:4780:12:bfc5::1',1751050803,'__ci_last_regenerate|i:1751050803;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('9022624687f70b3f7e5c91b64082bc69ec28daf3','2a02:4780:12:bfc5::1',1751113501,'__ci_last_regenerate|i:1751113501;'),
('903bb6d970d8de3757b7832f77e14e983c021139','157.48.82.220',1750925048,'__ci_last_regenerate|i:1750924502;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";'),
('9040238aefd905456bfe625c5729bd63e49094c6','2a02:4780:12:bfc5::1',1751064002,'__ci_last_regenerate|i:1751064001;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('9051c354b4553b7389117dd9274b4ebe075910ba','127.0.0.1',1750941107,'__ci_last_regenerate|i:1750941107;red_url|s:21:\"https://82.29.165.22/\";'),
('90c77642f0b3f288ae091f71527a6d0ed3559fff','82.29.165.22',1750954502,'__ci_last_regenerate|i:1750954501;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('90d538061175fb25418a5383305ad97a0165aa8f','2a02:4780:12:bfc5::1',1751128202,'__ci_last_regenerate|i:1751128201;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('90ec7f5cc6af521947fd866e1aa5ffdf9fde4407','127.0.0.1',1750945010,'__ci_last_regenerate|i:1750945010;red_url|s:21:\"https://82.29.165.22/\";'),
('9130012e6aea34b5d130468a5cfc668d0f239282','127.0.0.1',1750957507,'__ci_last_regenerate|i:1750957507;red_url|s:21:\"https://82.29.165.22/\";'),
('91772b27093e68051d7e37b81ee7ddf7fd4ba3e3','127.0.0.1',1750972910,'__ci_last_regenerate|i:1750972909;red_url|s:21:\"https://82.29.165.22/\";'),
('91b2042eca5261b412ab643a2533d65b920cafd7','2409:40d4:10cd:43f8:f408:13f9:e02c:5190',1751017521,'__ci_last_regenerate|i:1751017521;red_url|s:39:\"https://techdotbit.in/clients?companies\";client_user_id|s:1:\"4\";contact_user_id|s:1:\"4\";client_logged_in|b:1;perfex_saas_enable_auto_trial|s:1:\"0\";'),
('91b7a032eaa19cbde04c4a3d49bc434125e5ab69','2a02:4780:12:bfc5::1',1751097602,'__ci_last_regenerate|i:1751097601;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('91f6a1eb9db9482fae99d25d7b73c0771b698094','2a02:4780:12:bfc5::1',1751038802,'__ci_last_regenerate|i:1751038802;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('92026344c2a6a3788648add965571ad9133b0e58','127.0.0.1',1750890109,'__ci_last_regenerate|i:1750890109;red_url|s:21:\"https://82.29.165.22/\";'),
('921d9cbd133b09532632609110cc6ff2530266de','82.29.165.22',1750929002,'__ci_last_regenerate|i:1750929002;'),
('923788238927c23c14f290325a4645670bcfc8d4','82.29.165.22',1750933502,'__ci_last_regenerate|i:1750933502;'),
('926217a49bd0be3722e920db07dfc6c60a3733c0','82.29.165.22',1750899301,'__ci_last_regenerate|i:1750899301;'),
('92af02050035e135de6466fe5c6220050dfb1959','82.29.165.22',1750897801,'__ci_last_regenerate|i:1750897801;'),
('92bce8bb00dc1fc7945515770c2b57b21367c576','82.29.165.22',1750928104,'__ci_last_regenerate|i:1750928102;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('92d5e0195c7b8102cc67e3483b980901edc5ee87','176.101.146.132',1750892738,'__ci_last_regenerate|i:1750892738;red_url|s:21:\"https://82.29.165.22/\";'),
('92d98f058f26a9fe7bed31949468f6da0e6941bd','82.29.165.22',1750957207,'__ci_last_regenerate|i:1750957202;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('92f426da2efcfd9cc89f1522fa3bc85d278978ba','82.29.165.22',1750895702,'__ci_last_regenerate|i:1750895701;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('92f4e6390f06c02407df76dcc2dac0058e657b04','2a02:4780:12:bfc5::1',1751014203,'__ci_last_regenerate|i:1751014202;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('930d04f7989132da4f0a90c835503d0780012af9','2a02:4780:12:bfc5::1',1751016301,'__ci_last_regenerate|i:1751016301;'),
('9328221a5f96c9a7f090059768e5699bdfae8af8','2a02:4780:12:bfc5::1',1751004901,'__ci_last_regenerate|i:1751004901;'),
('9341426e98bcd80d7f7ba8fd793a83a177871aa2','82.29.165.22',1750862701,'__ci_last_regenerate|i:1750862701;'),
('93535f29dccfc080afd0892d6f70979f53f59b42','82.29.165.22',1750994404,'__ci_last_regenerate|i:1750994401;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('940da10a351d156495551d5f68eacfb56e4cc9e3','82.29.165.22',1750906808,'__ci_last_regenerate|i:1750906802;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('9411f12e0ff79f15a8069d8c5f57ebf947b9f529','82.29.165.22',1750945804,'__ci_last_regenerate|i:1750945801;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('94170533bdf17d0a40da13497a2b0025daa175e7','127.0.0.1',1750922207,'__ci_last_regenerate|i:1750922207;red_url|s:21:\"https://82.29.165.22/\";'),
('94367388c9ea182b7f2ceaa957bf92100a6c3c1d','2a02:4780:12:bfc5::1',1751092203,'__ci_last_regenerate|i:1751092202;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('9466d663e73afb3780a428493413b4d253360ddb','157.48.80.182',1750868404,'__ci_last_regenerate|i:1750868404;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";'),
('94a27a88edbe0f381a9ea4f4ae202376ca7ca171','82.29.165.22',1750943104,'__ci_last_regenerate|i:1750943101;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('94ba3dfe580ea4d3b61f5d619908c178a1096d4a','127.0.0.1',1750982414,'__ci_last_regenerate|i:1750982413;red_url|s:21:\"https://82.29.165.22/\";'),
('94be938b0f6279b959465a5373c044495e76e263','82.29.165.22',1750847401,'__ci_last_regenerate|i:1750847401;'),
('94d77ad5ea6b0e2f011891b65c9979847be933a7','82.29.165.22',1750955104,'__ci_last_regenerate|i:1750955101;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('9516b3003440af0f3a4c2ff16e9ba2f489065cbc','2a02:4780:12:bfc5::1',1751120702,'__ci_last_regenerate|i:1751120701;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('9521fb2252b20f1427cf4b4922c09519dbdda833','2a02:4780:12:bfc5::1',1751089803,'__ci_last_regenerate|i:1751089802;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('95ee8067be5735422cdbb63f10367bc87d728d30','2a02:4780:12:bfc5::1',1751013902,'__ci_last_regenerate|i:1751013902;'),
('95fb45ccf7f98eb83057b121ef6e8f24c9833880','127.0.0.1',1750989603,'__ci_last_regenerate|i:1750989602;red_url|s:21:\"https://82.29.165.22/\";'),
('960e83026073c68f38ca68cf4f081e67d61b3eb8','127.0.0.1',1750942310,'__ci_last_regenerate|i:1750942309;red_url|s:21:\"https://82.29.165.22/\";'),
('96461a6a0c127afead58037c5e4046cdcfdbaf5f','157.48.80.182',1750872254,'__ci_last_regenerate|i:1750872254;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";'),
('965905a76333bc2bec455b5caa8ab165f5adb481','2a02:4780:12:bfc5::1',1751120102,'__ci_last_regenerate|i:1751120102;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('96595643aefd33e5a225cda0aed8fb2d7d98e9cc','2a02:4780:12:bfc5::1',1751048402,'__ci_last_regenerate|i:1751048402;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('966f2d33eb4b677379a6b899f441a0b87b90d9a5','2a02:4780:12:bfc5::1',1751095202,'__ci_last_regenerate|i:1751095202;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('96a0687b4215633bb3da788707d1c54883106cde','2a02:4780:12:bfc5::1',1751127902,'__ci_last_regenerate|i:1751127902;'),
('96c66e71b362d4216eb7ad63420d7bdeda129ae5','127.0.0.1',1750874708,'__ci_last_regenerate|i:1750874708;red_url|s:21:\"https://82.29.165.22/\";'),
('96cf3e930a91ecff373ec09a12d1415c67b573e7','2a02:4780:12:bfc5::1',1751140803,'__ci_last_regenerate|i:1751140803;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('9727825eec5b8a3254eeaa1dad44992c58ec38b9','2a02:4780:12:bfc5::1',1751164502,'__ci_last_regenerate|i:1751164502;'),
('97484f7d7a4f39d700fb078dbf936b7a1865780c','2a02:4780:12:bfc5::1',1751072102,'__ci_last_regenerate|i:1751072102;'),
('977fdbcb83f6e4c54720b2ab873d686b41fd771b','82.29.165.22',1750902001,'__ci_last_regenerate|i:1750902001;'),
('97a8ae82b0feff8cc5cff9a362297f6b41c56958','82.29.165.22',1750904401,'__ci_last_regenerate|i:1750904401;'),
('97c7d2b481498173f67364d2cbdfeaa7e615a63a','2a02:4780:12:bfc5::1',1751142002,'__ci_last_regenerate|i:1751142001;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('9819bf4fa86dba231d4d82e7e05e48c55980724b','2a02:4780:12:bfc5::1',1751156102,'__ci_last_regenerate|i:1751156102;'),
('982cf02103e11a9b3fc86f3cd43a71e93c9993b5','2a02:4780:12:bfc5::1',1751124302,'__ci_last_regenerate|i:1751124301;'),
('98471d7d82f505d85e99daabff8d1b5eef062755','2a02:4780:12:bfc5::1',1751145002,'__ci_last_regenerate|i:1751145001;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('98628c9d92ec95e8c7581efdacf4877f50707284','82.29.165.22',1750879801,'__ci_last_regenerate|i:1750879801;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('98f40b6c91e2d19360d38f957af3e8f27a92cde8','2a02:4780:12:bfc5::1',1751055902,'__ci_last_regenerate|i:1751055902;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('990aa50187a954fc462794fdaf8a1b37e136fc8a','2a02:4780:12:bfc5::1',1751024101,'__ci_last_regenerate|i:1751024101;'),
('992a264b97caf0beb3b39c95d5b7592d64fae74b','127.0.0.1',1750887409,'__ci_last_regenerate|i:1750887409;red_url|s:21:\"https://82.29.165.22/\";'),
('99347001298770fd8e9077b6a95d798dcec28087','81.17.21.242',1751038286,'__ci_last_regenerate|i:1751038285;red_url|s:22:\"https://techdotbit.in/\";'),
('99361f07ae010d63571a4cda09332ae3152fde81','2a02:4780:12:bfc5::1',1751040005,'__ci_last_regenerate|i:1751040003;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('9978038b74e67e5a2be1d5e2d913c5fea2f6b816','2a02:4780:12:bfc5::1',1751153102,'__ci_last_regenerate|i:1751153102;'),
('998af8f28a4ec3eb2b0acdaaa01b2640a29cd43b','127.0.0.1',1750996310,'__ci_last_regenerate|i:1750996310;red_url|s:21:\"https://82.29.165.22/\";'),
('9a0439211f8184233aad568d351881d7b6d14ed2','82.29.165.22',1750967703,'__ci_last_regenerate|i:1750967701;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('9a06df4f0f1239d7a743dcd817ab52a0b0df44a4','127.0.0.1',1750902407,'__ci_last_regenerate|i:1750902407;red_url|s:21:\"https://82.29.165.22/\";'),
('9a0aa8988fabb24c977cc65a2ea358038a970268','82.29.165.22',1750887601,'__ci_last_regenerate|i:1750887601;'),
('9a0fa03d9ee3d62f9e58be3665607609ffa47f6f','2a02:4780:12:bfc5::1',1751088603,'__ci_last_regenerate|i:1751088602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('9a910d66de9e34d9a559a82f01d8dfdc294a3e08','82.29.165.22',1750954801,'__ci_last_regenerate|i:1750954801;'),
('9afb74c016e15b941d067ca7ea897383922cc790','2409:40d4:10cd:43f8:ccef:f512:e762:56b2',1751092835,'__ci_last_regenerate|i:1751092835;staff_user_id|s:1:\"1\";staff_logged_in|b:1;red_url|s:39:\"https://techdotbit.in/clients?companies\";setup-menu-open|b:1;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('9b01e26bad03c5ff356eeacca63df765a7499f66','2a02:4780:12:bfc5::1',1751082602,'__ci_last_regenerate|i:1751082602;'),
('9b4eb6cf0bad098f5426f4216f468aa65eb24db9','82.29.165.22',1750966204,'__ci_last_regenerate|i:1750966201;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('9b6919825d6b232d56ec44ce68ba042ad3b400ed','82.29.165.22',1750923901,'__ci_last_regenerate|i:1750923901;'),
('9b9ab67457b7c2de5823fd02255a9ca41cb6e0eb','2a02:4780:12:bfc5::1',1751169302,'__ci_last_regenerate|i:1751169301;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('9b9c080541b7de8a8170f7e7a57e44f0ab5061d6','127.0.0.1',1750857009,'__ci_last_regenerate|i:1750857009;red_url|s:21:\"https://82.29.165.22/\";'),
('9ba2a36c6d182632485807216133e43d36712a61','2a02:4780:12:bfc5::1',1751150702,'__ci_last_regenerate|i:1751150702;'),
('9bcf9a0e7c789649250ff9ca52454eab9a819888','2a02:4780:12:bfc5::1',1751084702,'__ci_last_regenerate|i:1751084701;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('9bd5c0a768e6d1df82172aa9d0693a279b1cbafd','127.0.0.1',1750929710,'__ci_last_regenerate|i:1750929710;red_url|s:21:\"https://82.29.165.22/\";'),
('9c2a907673f95cbef2859f6592ab81b99c0ec408','2a02:4780:12:bfc5::1',1751036702,'__ci_last_regenerate|i:1751036701;'),
('9c31df0cf24ee87941fc0e211705f217a9cea937','127.0.0.1',1750907807,'__ci_last_regenerate|i:1750907807;red_url|s:21:\"https://82.29.165.22/\";'),
('9cf3f4d33d7079f5db7b86065b8003f96c0032d7','127.0.0.1',1750962707,'__ci_last_regenerate|i:1750962707;red_url|s:21:\"https://82.29.165.22/\";'),
('9cf50d7e0669bcc5ff3020eeaef5e50755d525ad','127.0.0.1',1750916807,'__ci_last_regenerate|i:1750916807;red_url|s:21:\"https://82.29.165.22/\";'),
('9d14823e67689d3a116bec0952b66f5967742f49','2a02:4780:12:bfc5::1',1751017802,'__ci_last_regenerate|i:1751017802;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('9d1f4aa0552779ce291cb5595c6f99c3eb7a80c3','82.29.165.22',1750968302,'__ci_last_regenerate|i:1750968301;'),
('9d88ca51b35158abd7f2cc767ef8800c03ade5f6','127.0.0.1',1750927607,'__ci_last_regenerate|i:1750927607;red_url|s:21:\"https://82.29.165.22/\";'),
('9db85914950c261d33ba9c4584d2037f9f1415fd','2a02:4780:12:bfc5::1',1751151002,'__ci_last_regenerate|i:1751151001;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('9dd3386a67ae1ba7315de54a6930797dbacb29cb','2a02:4780:12:bfc5::1',1751057102,'__ci_last_regenerate|i:1751057101;'),
('9dde559a24e7cc52d6e0eeafb9811a8150545aad','82.29.165.22',1750926304,'__ci_last_regenerate|i:1750926302;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('9e278052605b0ef969d07dce5292549674539d81','2a02:4780:12:bfc5::1',1751026202,'__ci_last_regenerate|i:1751026202;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('9e345385c6de823e918d89158521b96937f56d14','127.0.0.1',1750889407,'__ci_last_regenerate|i:1750889407;red_url|s:21:\"https://82.29.165.22/\";'),
('9e4938c21137c98a16fc0578a8b63ff6fc0d4e46','157.48.82.220',1750949265,'__ci_last_regenerate|i:1750949265;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('9e9420094c4086a9a5e7d061c2560da45caaccf1','2a02:4780:12:bfc5::1',1751103601,'__ci_last_regenerate|i:1751103601;'),
('9e9a6da20864a47bea0b377618342a8f147c5f96','127.0.0.1',1750849203,'__ci_last_regenerate|i:1750849203;red_url|s:21:\"https://82.29.165.22/\";'),
('9ea731e44e93ce2626ea80ebcacade5a856f032e','82.29.165.22',1750931104,'__ci_last_regenerate|i:1750931101;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('9ec80cc851171a5182cf2961fa4a32239aefb6d5','2a02:4780:12:bfc5::1',1751130603,'__ci_last_regenerate|i:1751130602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('9ed4f03f29666a5d62907e4c8eedd8dbb8e313fc','127.0.0.1',1750861310,'__ci_last_regenerate|i:1750861310;red_url|s:21:\"https://82.29.165.22/\";'),
('9edfeb0670db7a3d55706ecb008cd5f1965b88d1','82.29.165.22',1750970403,'__ci_last_regenerate|i:1750970401;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('9f0cdaddc7dda57fa2272f0e82d4594fb11a50fc','2a02:4780:12:bfc5::1',1751007605,'__ci_last_regenerate|i:1751007603;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('9f7bf6f66925fc97ec6dc12b7472660eac16d73f','127.0.0.1',1750848175,'__ci_last_regenerate|i:1750848174;red_url|s:21:\"https://82.29.165.22/\";'),
('9f8c20f0aa4fb59faf9428031e15b7607ac5ead7','212.104.124.211',1750933260,'__ci_last_regenerate|i:1750933259;red_url|s:21:\"https://82.29.165.22/\";'),
('9f9f269eda8767d7d90bcac909a8e4cb52fde234','82.29.165.22',1750865102,'__ci_last_regenerate|i:1750865102;'),
('9fc73e945ebf460df4ddc4283ffa75336a2f063a','2a02:4780:12:bfc5::1',1751121003,'__ci_last_regenerate|i:1751121002;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('a005e7cf387323cc8f220efa277f14a0502e4394','127.0.0.1',1750897310,'__ci_last_regenerate|i:1750897310;red_url|s:21:\"https://82.29.165.22/\";'),
('a0454688685edc2864f95ebd0c3c316acd7c6ab2','2a02:4780:12:bfc5::1',1751049603,'__ci_last_regenerate|i:1751049602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('a072787cb3b0a3cbea08db8e55b57f1c332774af','2a02:4780:12:bfc5::1',1751117101,'__ci_last_regenerate|i:1751117101;'),
('a099106c28d505af6488206a50d157fbe27a4670','2a02:4780:12:bfc5::1',1751133302,'__ci_last_regenerate|i:1751133302;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('a0b2e8acd0ce0268d6d7fcf711d64edbff0b556d','127.0.0.1',1750910733,'__ci_last_regenerate|i:1750910732;red_url|s:21:\"https://82.29.165.22/\";'),
('a0f7c89276182e25b0847ecfc93c04ad85dde95c','2a02:4780:12:bfc5::1',1751084401,'__ci_last_regenerate|i:1751084401;'),
('a1163a6e629b39da4ca6d5350feadb3f7fcf4970','2a02:4780:12:bfc5::1',1751004002,'__ci_last_regenerate|i:1751004002;'),
('a132c97e4e45a5dec4dec76a07c09c952e2dca88','2a02:4780:12:bfc5::1',1751044802,'__ci_last_regenerate|i:1751044801;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('a13d6010479c9151a85d9775fb0ec6f483f5c1df','127.0.0.1',1750930610,'__ci_last_regenerate|i:1750930610;red_url|s:21:\"https://82.29.165.22/\";'),
('a14f1fd0b4b9bfbba4f942e7c8bc7d7baf5057aa','82.29.165.22',1750991401,'__ci_last_regenerate|i:1750991401;'),
('a191d723af9938649bab692f86cf15b27bdd4698','2a02:4780:12:bfc5::1',1751062501,'__ci_last_regenerate|i:1751062501;'),
('a1925202b9be75c992ea1960b725404e6873fd57','2409:40d4:10cd:43f8:f408:13f9:e02c:5190',1751005559,'__ci_last_regenerate|i:1751005559;red_url|s:39:\"https://techdotbit.in/clients?companies\";'),
('a1da3efe8ac2cc5a2e775c210c8ad9c1af3de88f','82.29.165.22',1750865702,'__ci_last_regenerate|i:1750865702;'),
('a1ef0d0f2db72017fa1cc95ec380f8351d27e6ff','82.29.165.22',1750940703,'__ci_last_regenerate|i:1750940702;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('a1fa76d27ca4da2a48ba91412c9e764b3140c0aa','82.29.165.22',1750848601,'__ci_last_regenerate|i:1750848601;'),
('a21e97eddd46167db2460731fab0cf08371aab8b','54.174.140.70',1751001298,'__ci_last_regenerate|i:1751001298;'),
('a21f0da01adafd9b1602e89bd42e5e341dbb47dc','2409:40d4:10cd:43f8:ccef:f512:e762:56b2',1751095196,'__ci_last_regenerate|i:1751095196;staff_user_id|s:1:\"1\";staff_logged_in|b:1;red_url|s:39:\"https://techdotbit.in/clients?companies\";setup-menu-open|b:1;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('a225c80a914d15e93df5d272b0650692244d9336','82.29.165.22',1750864202,'__ci_last_regenerate|i:1750864201;'),
('a238ikgjvus2rk98p9ntiptoafa7o0bu','130.89.144.162',1751366653,'__ci_last_regenerate|i:1751366652;red_url|s:22:\"https://techdotbit.in/\";'),
('a2407f71f6b28b5696e8444d0abaac9bdf01f888','157.48.80.182',1750897994,'__ci_last_regenerate|i:1750897994;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;'),
('a25c2205fdd131b60bc5924d9718d7f8ff44fe21','127.0.0.1',1750903205,'__ci_last_regenerate|i:1750903204;red_url|s:21:\"https://82.29.165.22/\";'),
('a2879fc7d10b31b151a52a7d0031c72e485fc14f','127.0.0.1',1750882909,'__ci_last_regenerate|i:1750882909;red_url|s:21:\"https://82.29.165.22/\";'),
('a2d7d8624ae4f7d5f66bfe6691b7daecc88b73c0','82.29.165.22',1750900501,'__ci_last_regenerate|i:1750900501;'),
('a2e68f56723e6c6f1c341b2ab3209b889e884bc8','127.0.0.1',1750888309,'__ci_last_regenerate|i:1750888309;red_url|s:21:\"https://82.29.165.22/\";'),
('a31181243d6885edccbcfc59b851d1c2e570b1dc','82.29.165.22',1750901702,'__ci_last_regenerate|i:1750901701;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('a32c8dfe945c9645d456e70281f3e1e589bb9da7','82.29.165.22',1750972804,'__ci_last_regenerate|i:1750972802;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('a345f4f8bfc13ac3e04d11aa8a5190a19f5e9b8a','2409:40d4:10cd:43f8:ccef:f512:e762:56b2',1751168545,'__ci_last_regenerate|i:1751168545;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;red_url|s:39:\"https://techdotbit.in/clients?companies\";message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('a3679c95b46e8e14cf7d7a2fb46effeb164babfa','82.29.165.22',1750930504,'__ci_last_regenerate|i:1750930501;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('a37a0ac213c5430efc26f35cc3d644cbfc1b59a0','2a02:4780:12:bfc5::1',1751142302,'__ci_last_regenerate|i:1751142302;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('a3958c6c452b7adcb11cfab5827ecc753ab40557','2a02:4780:12:bfc5::1',1751016902,'__ci_last_regenerate|i:1751016902;'),
('a3a319a01e62c0fa1e74c5864d6dcfc4181caead','82.29.165.22',1750891201,'__ci_last_regenerate|i:1750891201;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('a40f23ca4d5840197c5f204858deac51f81e66b6','2a02:4780:12:bfc5::1',1751025603,'__ci_last_regenerate|i:1751025602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('a44b5dfa53d6d1746ca304993015008a0584e593','82.29.165.22',1750993805,'__ci_last_regenerate|i:1750993802;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('a44c1666a9d9698da3f638711807aeea82c2cb0b','2a02:4780:12:bfc5::1',1751156402,'__ci_last_regenerate|i:1751156401;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('a44ecf2e52bf5cc8027b0bdf323b322d47cf4694','127.0.0.1',1750885808,'__ci_last_regenerate|i:1750885808;red_url|s:21:\"https://82.29.165.22/\";'),
('a49710509dcdf1232c135b697c569d275358a7f8','2a02:4780:12:bfc5::1',1751074502,'__ci_last_regenerate|i:1751074501;'),
('a4a8d6d2cd0f3294a8b7774df7fcd259c5f2af11','82.29.165.22',1750916401,'__ci_last_regenerate|i:1750916401;'),
('a4e735599b05c185490ac71ce3e5da6f5e84f768','2a02:4780:12:bfc5::1',1751097902,'__ci_last_regenerate|i:1751097902;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('a4ee179deacf7e1928ada5f1ea0a297f5b976355','2a02:4780:12:bfc5::1',1751168102,'__ci_last_regenerate|i:1751168102;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('a5232f24d9de965a6b9724dcc39fc53354449443','82.29.165.22',1750886702,'__ci_last_regenerate|i:1750886702;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('a5509e1df9e8b15b106822027e1cc0d7453d89ce','2a02:4780:12:bfc5::1',1751031902,'__ci_last_regenerate|i:1751031902;'),
('a5888bd2e62e6616101a1b4c32010b89f5f917e7','127.0.0.1',1750963607,'__ci_last_regenerate|i:1750963607;red_url|s:21:\"https://82.29.165.22/\";'),
('a594bf3865706a7839348b0fe4c2209b8bb29848','127.0.0.1',1750895509,'__ci_last_regenerate|i:1750895509;red_url|s:21:\"https://82.29.165.22/\";'),
('a59adfd3aba4992317379b86bba85a047508555c','127.0.0.1',1750849506,'__ci_last_regenerate|i:1750849506;red_url|s:21:\"https://82.29.165.22/\";'),
('a5f198ef98b2a741f811a65243b83d147cd67564','82.29.165.22',1750866601,'__ci_last_regenerate|i:1750866601;'),
('a5fa5656805fe46f7d8b76b1b886d40f2f962575','2a02:4780:12:bfc5::1',1751043302,'__ci_last_regenerate|i:1751043302;'),
('a608c9e4670613bfc2c46b1322e0131100c28798','2409:40d4:10cd:43f8:f408:13f9:e02c:5190',1751009676,'__ci_last_regenerate|i:1751009676;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('a6133ee53492ba81157db5cac437045636a62591','127.0.0.1',1750982717,'__ci_last_regenerate|i:1750982717;red_url|s:21:\"https://82.29.165.22/\";'),
('a62c7e06b180f9780ef766b89a4e852fe542fcdf','127.0.0.1',1750968633,'__ci_last_regenerate|i:1750968633;red_url|s:21:\"https://82.29.165.22/\";'),
('a66d3f9438a83f2200af1a226b26cee85144111a','127.0.0.1',1750932608,'__ci_last_regenerate|i:1750932608;red_url|s:21:\"https://82.29.165.22/\";'),
('a685b276cf16202122fca23dbd5ced0101b4db41','2a02:4780:12:bfc5::1',1751163602,'__ci_last_regenerate|i:1751163602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('a69038c901f5fd901bf535cc76ac362378a24215','2a02:4780:12:bfc5::1',1751142902,'__ci_last_regenerate|i:1751142901;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('a6b734419414cebe79d2e7696f6e29c2243136be','127.0.0.1',1750925108,'__ci_last_regenerate|i:1750925107;red_url|s:21:\"https://82.29.165.22/\";'),
('a6c1261810c220c63654e6b999c7c777cd141792','2a02:4780:12:bfc5::1',1751126102,'__ci_last_regenerate|i:1751126102;'),
('a6c37cc9206d27437cb28f49c47790d363a5caff','2a02:4780:12:bfc5::1',1751163002,'__ci_last_regenerate|i:1751163002;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('a6c75c06d6e3bbe469cf1b59573823f94e42b03f','104.164.126.144',1751004602,'__ci_last_regenerate|i:1751004601;red_url|s:22:\"https://techdotbit.in/\";'),
('a6cee821ce38d450e7ecc54f983dbde196c8b557','2a02:4780:12:bfc5::1',1751022004,'__ci_last_regenerate|i:1751022002;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('a711e9666e0c5c55dcfcc623607ac1fdc809ba9b','82.29.165.22',1750873202,'__ci_last_regenerate|i:1750873202;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('a713b77cc5fdca5d66c8bf89a1e7979654a870b6','127.0.0.1',1750948307,'__ci_last_regenerate|i:1750948307;red_url|s:21:\"https://82.29.165.22/\";'),
('a7652cd9834ed2c1d84216a91a69c7bfe494e344','127.0.0.1',1750893896,'__ci_last_regenerate|i:1750893896;red_url|s:21:\"https://82.29.165.22/\";'),
('a79ff285f041b01a2b94d6822cd8f0753fb60f11','82.29.165.22',1750851001,'__ci_last_regenerate|i:1750851001;'),
('a7d3dd963e9c25517669e07d31ef08f860575c21','127.0.0.1',1750852007,'__ci_last_regenerate|i:1750852007;red_url|s:21:\"https://82.29.165.22/\";'),
('a7f953949ca85779f3632a3ccf74453913420ffd','82.29.165.22',1750942504,'__ci_last_regenerate|i:1750942501;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('a803d98c27159e90746ef0e88dbf6a84a28f18df','82.29.165.22',1750905301,'__ci_last_regenerate|i:1750905301;'),
('a809bf450a789a9d9e5d95d7b2d3d3f04c4703b1','82.29.165.22',1750978203,'__ci_last_regenerate|i:1750978201;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('a811ceb466fe6a68993f6e90b1320e48b33b636f','82.29.165.22',1750918805,'__ci_last_regenerate|i:1750918803;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('a820978b632139fe7f7a7bf8217f973d62935b81','82.29.165.22',1750977603,'__ci_last_regenerate|i:1750977601;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('a860f45fcdbdf2dcbb92ee57b4e67f35a84810d8','82.29.165.22',1750950904,'__ci_last_regenerate|i:1750950902;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('a89581dd2d90d45c42a71be1cc491902fe563486','82.29.165.22',1750982103,'__ci_last_regenerate|i:1750982101;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('a8a8164ed64a8862811ca89edef45f93ca42c62a','2a02:4780:12:bfc5::1',1751033102,'__ci_last_regenerate|i:1751033101;'),
('a8ba58dcc6b62b06f3f6eacd460f136420281714','2a02:4780:12:bfc5::1',1751148602,'__ci_last_regenerate|i:1751148602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('a8e1621e024e7372c086888e7aa97a9f3a0c8208','2a02:4780:12:bfc5::1',1751131501,'__ci_last_regenerate|i:1751131501;'),
('a900353192241cfbaa5e4fad3a8015645519b073','82.29.165.22',1750943402,'__ci_last_regenerate|i:1750943402;'),
('a9bff1d6edde62ce32e91532d39c9b0e2c43c472','82.29.165.22',1750851601,'__ci_last_regenerate|i:1750851601;'),
('a9c0d48672092206334fe13aba06d0ecd8ff3904','82.29.165.22',1750912205,'__ci_last_regenerate|i:1750912202;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('a9d7f83ea053234811c9ff5c167c2b891b709176','82.29.165.22',1750848302,'__ci_last_regenerate|i:1750848302;'),
('aa100de2213a49f0bd127113508309c8ee2ef2ae','82.29.165.22',1750959904,'__ci_last_regenerate|i:1750959901;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('aa17deb4eeda415780ef1b181396d74e34065e26','2a02:4780:12:bfc5::1',1751170803,'__ci_last_regenerate|i:1751170802;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('aa3f1603822f445af9a9517b36d5e5785f72eb6a','2409:40d4:10cd:43f8:f408:13f9:e02c:5190',1751005918,'__ci_last_regenerate|i:1751005898;client_user_id|s:1:\"3\";contact_user_id|s:1:\"3\";client_logged_in|b:1;'),
('aa55561c2c8ba199cdd0fead893812da37577d59','82.29.165.22',1750890602,'__ci_last_regenerate|i:1750890602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('aa8358ff45691afe4e93aa1ef6d599934eda1948','82.29.165.22',1750867201,'__ci_last_regenerate|i:1750867201;'),
('aa87594597d0e901b8afb3bee224e786ad53e790','127.0.0.1',1750961807,'__ci_last_regenerate|i:1750961807;red_url|s:21:\"https://82.29.165.22/\";'),
('aa9c3ef58cefc131b715a41fa6d3c930563ebe70','127.0.0.1',1750859510,'__ci_last_regenerate|i:1750859510;red_url|s:21:\"https://82.29.165.22/\";'),
('ab2f124b927aff286cc4666e08ef321cd30adc05','82.29.165.22',1750875001,'__ci_last_regenerate|i:1750875001;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('ab2f46b4d7e5f228725fd4248ca2c0982fab550b','2a02:4780:12:bfc5::1',1751011802,'__ci_last_regenerate|i:1751011802;'),
('ab7ad3ca4612cd9e2cbf9e008c2a8db1b0b1fff0','127.0.0.1',1750971351,'__ci_last_regenerate|i:1750971351;red_url|s:21:\"https://82.29.165.22/\";'),
('ab9aed3645d106e6a35ae5c7efa97fd1a3a58ecd','104.164.173.195',1751172991,'__ci_last_regenerate|i:1751172989;red_url|s:22:\"https://techdotbit.in/\";'),
('aba1efa8126f56be6543c3c22fa764406eaa5374','157.48.80.182',1750864243,'__ci_last_regenerate|i:1750864243;red_url|s:26:\"https://82.29.165.22/admin\";'),
('abca0300b3f0a3c9384eb2dbf81c61ce4b6411e8','127.0.0.1',1750933907,'__ci_last_regenerate|i:1750933907;red_url|s:21:\"https://82.29.165.22/\";'),
('ac12f1b186463cb657091a81ef7714536a4f5e06','2a02:4780:12:bfc5::1',1751001303,'__ci_last_regenerate|i:1751001302;'),
('ac3349b58a5bbc7cd0ce6810789d8ab401fce8a6','82.29.165.22',1750913404,'__ci_last_regenerate|i:1750913402;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('ac3390c9fb55b84614b169853a607354b4208807','2a02:4780:12:bfc5::1',1751002203,'__ci_last_regenerate|i:1751002202;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('ac7708976a6cc0232198a2495b22ac7fcbd3a26b','2a02:4780:12:bfc5::1',1751069402,'__ci_last_regenerate|i:1751069401;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('accb074784166cc0a1a651a120f90073d55368b9','2a02:4780:12:bfc5::1',1751153402,'__ci_last_regenerate|i:1751153402;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('acd9d03418e0b35fad86a15b7229c84db3ed3b44','2a02:4780:12:bfc5::1',1751101802,'__ci_last_regenerate|i:1751101801;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('ad59d6fef3ace53dfa7470908442a39749ce1ec1','2a02:4780:12:bfc5::1',1751033402,'__ci_last_regenerate|i:1751033402;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('ad5abcc0f3fa645704550d9768c07157b9c2e79a','82.29.165.22',1750878301,'__ci_last_regenerate|i:1750878301;'),
('ad8843b748a21da2a147273b62a9f60c11bd9b54','127.0.0.1',1750872707,'__ci_last_regenerate|i:1750872707;red_url|s:21:\"https://82.29.165.22/\";'),
('ada31af45c80115996c65152e92e0ece4ca61e87','82.29.165.22',1750981502,'__ci_last_regenerate|i:1750981501;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('ae5fe4e18548b98eece75c8297294f9ba1968c1f','127.0.0.1',1750952807,'__ci_last_regenerate|i:1750952807;red_url|s:21:\"https://82.29.165.22/\";'),
('ae934c7469437d7ce5bf6304031974111dab45dd','127.0.0.1',1750926110,'__ci_last_regenerate|i:1750926110;red_url|s:21:\"https://82.29.165.22/\";'),
('aead61d27dac1ccc475e8df909705ebad6b44e4a','103.196.9.18',1751173607,'__ci_last_regenerate|i:1751173606;red_url|s:22:\"https://techdotbit.in/\";'),
('aeb5376dc33196b55c7250b01b65507fc6c4bc1b','2a02:4780:12:bfc5::1',1751155211,'__ci_last_regenerate|i:1751155210;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('af3099714b7ba59ff627888c7491e156ebd37819','2a02:4780:12:bfc5::1',1751144403,'__ci_last_regenerate|i:1751144402;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('afaac5493a52e9f111266746ed79de5f9c1b1758','157.48.80.182',1750897679,'__ci_last_regenerate|i:1750897679;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('afcf2796e5d0d2475ff09e3dcef9344cda9a21e0','2a02:4780:12:bfc5::1',1751098502,'__ci_last_regenerate|i:1751098501;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('b0441b24affcc1aeb96b2ac087d72d78ed2f23e4','2a02:4780:12:bfc5::1',1751115902,'__ci_last_regenerate|i:1751115901;'),
('b046c79991f1bb2047e1796ab213e06e91b125e0','139.162.193.186',1751014938,'__ci_last_regenerate|i:1751014938;red_url|s:22:\"https://techdotbit.in/\";'),
('b0585dca475d63b4246b80db49f0b87575952593','2a02:4780:12:bfc5::1',1751041803,'__ci_last_regenerate|i:1751041802;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('b060034a29e3991a7feeb17c8058e2867417c3f9','2a02:4780:12:bfc5::1',1751089501,'__ci_last_regenerate|i:1751089501;'),
('b0751831524e29a46e8b2cb6d8c2364954c96124','82.29.165.22',1750849201,'__ci_last_regenerate|i:1750849201;'),
('b0d20f161f1804201833089c576a5f0784e9a24c','2a02:4780:12:bfc5::1',1751053202,'__ci_last_regenerate|i:1751053201;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('b114ce7c50f40fc44e2f2424d1813dc375d11d48','127.0.0.1',1750891607,'__ci_last_regenerate|i:1750891607;red_url|s:21:\"https://82.29.165.22/\";'),
('b1179474435a1e66ce6b69d3be061ef4bb04ee30','127.0.0.1',1750967207,'__ci_last_regenerate|i:1750967207;red_url|s:21:\"https://82.29.165.22/\";'),
('b13ce80170ca95a21a647c0d62be8d856fff1741','2a02:4780:12:bfc5::1',1751111701,'__ci_last_regenerate|i:1751111701;'),
('b14cb089baf23e30f1398749181d1d7fb6dcf867','127.0.0.1',1750880209,'__ci_last_regenerate|i:1750880209;red_url|s:21:\"https://82.29.165.22/\";'),
('b1545349ae01f4967aad7dc341708a00e51186d8','127.0.0.1',1750959410,'__ci_last_regenerate|i:1750959409;red_url|s:21:\"https://82.29.165.22/\";'),
('b162ba7042a65e1ea501a2492473257fb16a842e','2a02:4780:12:bfc5::1',1751068808,'__ci_last_regenerate|i:1751068808;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('b183aed933e2def49d0983f6156f82e707d7982a','157.48.221.10',1750950588,'__ci_last_regenerate|i:1750950588;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('b1cb782d2345ee220bdf1154ec8e6ad1965e4327','2a02:4780:12:bfc5::1',1751156702,'__ci_last_regenerate|i:1751156702;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('b1e4b26b5d3346bde5ef6e5dac270e70bb7ab7f1','82.29.165.22',1750855501,'__ci_last_regenerate|i:1750855501;'),
('b1f357818ee1caf6ef7daf6d439828584a3882e1','127.0.0.1',1750877752,'__ci_last_regenerate|i:1750877752;red_url|s:21:\"https://82.29.165.22/\";'),
('b227a6edfabd01599cf8cb7e9cdb7bcfa0ce6808','82.29.165.22',1750974004,'__ci_last_regenerate|i:1750974001;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('b2284a588d0a3ba34844815c0a3fcde7c9b63d69','157.48.80.182',1750899351,'__ci_last_regenerate|i:1750899351;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";ps_slug|s:6:\"fecuni\";ps_plan|s:12:\"starter-plan\";red_url|s:38:\"https://82.29.165.22/clients?companies\";ps_custom_domain|s:6:\"fecuni\";'),
('b235ee57613b04802d1f766770f0366354ddddc5','2a02:4780:12:bfc5::1',1751094902,'__ci_last_regenerate|i:1751094901;'),
('b24e3221046a39f6243e7e5e93fa48e1b3c2fe93','127.0.0.1',1750920682,'__ci_last_regenerate|i:1750920682;red_url|s:21:\"https://82.29.165.22/\";'),
('b268bf8437412b38a5ea559c64ec12729ea3ff03','206.168.34.47',1750890437,'__ci_last_regenerate|i:1750890437;red_url|s:21:\"https://82.29.165.22/\";'),
('b2849c49c5c685ac9a006e2f51cea476fcfcb407','82.29.165.22',1750895401,'__ci_last_regenerate|i:1750895401;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('b2a820d7ee636ab82ff4e70218e91e66bff897e2','2a02:4780:12:bfc5::1',1751010002,'__ci_last_regenerate|i:1751010001;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('b2c2410b111dab1fbb735407f4bca3d7b931f593','2a02:4780:12:bfc5::1',1751146802,'__ci_last_regenerate|i:1751146802;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('b2d18471df1ed2ba4d710d9d1b6dcb7ffacdca2c','43.135.144.81',1751136102,'__ci_last_regenerate|i:1751136102;is_mobile|b:1;red_url|s:22:\"https://techdotbit.in/\";'),
('b2ebb582fb8c6c8419e934ba4678f9be1179276b','82.29.165.22',1750997404,'__ci_last_regenerate|i:1750997402;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('b338fdec61583ea1f126f62546c1d5786b0b0f50','2a02:4780:12:bfc5::1',1751046003,'__ci_last_regenerate|i:1751046002;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('b34bb4aef318f488c046a9ccd7ad43952aa76bb0','82.29.165.22',1750930202,'__ci_last_regenerate|i:1750930202;'),
('b3a269ee7efeab71b856f70f521cc0c11c74d4d2','2a02:4780:12:bfc5::1',1751074204,'__ci_last_regenerate|i:1751074203;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('b3af167383d23ab0ca88c0edf214049cc9b7fe13','2a02:4780:12:bfc5::1',1751016002,'__ci_last_regenerate|i:1751016002;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('b3e105c3b0b3b2de123f880566eafbc439dcccab','107.172.195.209',1751021251,'__ci_last_regenerate|i:1751021250;red_url|s:22:\"https://techdotbit.in/\";'),
('b40070cb959271911f278975d6d3bf2dd28f9c15','82.29.165.22',1750990203,'__ci_last_regenerate|i:1750990201;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('b40894e5c026443725a2b6d6ae8ca276fb173a1e','2a02:4780:12:bfc5::1',1751087403,'__ci_last_regenerate|i:1751087402;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('b445226531870d94287b0f0f9189acfce1058085','2a02:4780:12:bfc5::1',1751098202,'__ci_last_regenerate|i:1751098202;'),
('b450cce25bcdc32af4c74f4fee1c89be2f3d1611','82.29.165.22',1750917002,'__ci_last_regenerate|i:1750917002;'),
('b4c82c423c535251870c9c3c57d86ef71e27ee87','82.29.165.22',1750957502,'__ci_last_regenerate|i:1750957502;'),
('b4d52d6a8fcc00bdb66a15f0a3309d70a32c4558','44.242.141.207',1751074871,'__ci_last_regenerate|i:1751074870;is_mobile|b:1;red_url|s:22:\"https://techdotbit.in/\";'),
('b51a070a2e26b32224420db559b77e550e4a7610','82.29.165.22',1750893901,'__ci_last_regenerate|i:1750893901;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('b530a0977f89c1d621f6f8cb667de528e3cbc1a1','2a02:4780:12:bfc5::1',1751003402,'__ci_last_regenerate|i:1751003402;'),
('b5a3e14a90679d10ba03aaca3a97fb8d9806e0f6','2a02:4780:12:bfc5::1',1751032202,'__ci_last_regenerate|i:1751032201;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('b5f4164a70a0871558e7fc21ba20f716fd58c136','2a02:4780:12:bfc5::1',1751031302,'__ci_last_regenerate|i:1751031302;'),
('b6026376f764322f5989cba488a8593700d141fe','127.0.0.1',1750966610,'__ci_last_regenerate|i:1750966609;red_url|s:21:\"https://82.29.165.22/\";'),
('b609f04d68b31b5451321167673dde1483d899f7','82.29.165.22',1750924205,'__ci_last_regenerate|i:1750924202;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('b6101ad4b1c5aaead835c2bbab696195829c32c6','82.29.165.22',1750853702,'__ci_last_regenerate|i:1750853702;'),
('b684bb86b18bcececf42a992a5ce5b0a656e7afc','2a02:4780:12:bfc5::1',1751133002,'__ci_last_regenerate|i:1751133002;'),
('b68c3e7c873670af93031ee1ac37ddd6c240bc9e','157.48.80.182',1750847066,'__ci_last_regenerate|i:1750847033;red_url|s:26:\"https://82.29.165.22/admin\";'),
('b6ac5a8aa50d83a4edd4a1f1f4a1f4e6deaaaa68','127.0.0.1',1750864911,'__ci_last_regenerate|i:1750864911;red_url|s:21:\"https://82.29.165.22/\";'),
('b6d747781d1a9b06709e6bdff14861cab9245834','127.0.0.1',1751001710,'__ci_last_regenerate|i:1751001710;red_url|s:21:\"https://82.29.165.22/\";'),
('b6f836a2720e934857a4674db6780daa3d96f7be','82.29.165.22',1750973101,'__ci_last_regenerate|i:1750973101;'),
('b70405822775cb8ea175b1ba0ab292be1e708e3f','82.29.165.22',1750848901,'__ci_last_regenerate|i:1750848901;'),
('b707695ef9f1657ba0ed0959ba4e7a6d5b6e8d3f','82.29.165.22',1750860002,'__ci_last_regenerate|i:1750860002;'),
('b724e111470c2d2e8382b645cae22978f177fe55','127.0.0.1',1750954675,'__ci_last_regenerate|i:1750954675;red_url|s:21:\"https://82.29.165.22/\";'),
('b72fcea0aff1e9ff497af96ac2cee7af6d8d53f9','2a02:4780:12:bfc5::1',1751130902,'__ci_last_regenerate|i:1751130902;'),
('b73a0bace6de1cea65ca8a0a3c11a1762a0b6c57','82.29.165.22',1750954204,'__ci_last_regenerate|i:1750954201;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('b753916e2e7bffb3259393e2092a20c699094828','2a02:4780:12:bfc5::1',1751157602,'__ci_last_regenerate|i:1751157602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('b754523345823c8af024b18e45d552056fba4ec8','2a02:4780:12:bfc5::1',1751146501,'__ci_last_regenerate|i:1751146501;'),
('b81c947a303ce022cb68fd653e2d4a970ba616c9','2a02:4780:12:bfc5::1',1751051101,'__ci_last_regenerate|i:1751051101;'),
('b878926e16818926a400e26f1d1f3eede2020fbb','82.29.165.22',1750861801,'__ci_last_regenerate|i:1750861801;'),
('b88fec3581c52b0d3951879878c34402f9e155c6','127.0.0.1',1750900209,'__ci_last_regenerate|i:1750900208;red_url|s:21:\"https://82.29.165.22/\";'),
('b8fe52d64655cd93e6eaf87987f86e572bd66653','2a02:4780:12:bfc5::1',1751015403,'__ci_last_regenerate|i:1751015402;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('b912c1f2aa258a93c31e63e0fc71f6e3368ddb23','82.29.165.22',1750959601,'__ci_last_regenerate|i:1750959601;'),
('b9413c015d97d73da4838c5450f8d00ea4893892','82.29.165.22',1750956004,'__ci_last_regenerate|i:1750956001;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('b941e7654946f101509c7bdac41aacfdf013f159','54.174.140.70',1751001313,'__ci_last_regenerate|i:1751001308;red_url|s:39:\"https://techdotbit.in/clients?companies\";'),
('b94f0e9c8a3966dbec4524dbcec716955e18def7','2a02:4780:12:bfc5::1',1751145302,'__ci_last_regenerate|i:1751145302;'),
('b9704f361ffa6bfefddd88cc47115a4f7988b67c','82.29.165.22',1750911603,'__ci_last_regenerate|i:1750911601;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('b97b38a0d1ce6ff6a4b11fbb22952f0bf56778ca','45.79.134.200',1750930334,'__ci_last_regenerate|i:1750930333;red_url|s:21:\"https://82.29.165.22/\";'),
('b9a344fbe573cc55190fbce592fec0b47495e4e4','82.29.165.22',1750984501,'__ci_last_regenerate|i:1750984501;'),
('b9fed0e4d0db477cf4b506187548588d0c9422d4','127.0.0.1',1750981910,'__ci_last_regenerate|i:1750981909;red_url|s:21:\"https://82.29.165.22/\";'),
('ba087e02512da0f91886c6dbefd01e4143239a12','2a02:4780:12:bfc5::1',1751038203,'__ci_last_regenerate|i:1751038202;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('ba55f379df754b917a5c50ff6eba599ad2e0df8f','2a02:4780:12:bfc5::1',1751062802,'__ci_last_regenerate|i:1751062802;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('ba62ef6bab2e6adfedb5d958424f12c09503139f','2a02:4780:12:bfc5::1',1751161802,'__ci_last_regenerate|i:1751161801;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('ba6fd8610fb722caeed33dc5971d03b2c91f562f','2a02:4780:12:bfc5::1',1751040901,'__ci_last_regenerate|i:1751040901;'),
('bab74b92da9f3edc08922fe7cae5142d45554015','2a02:4780:12:bfc5::1',1751070604,'__ci_last_regenerate|i:1751070603;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('bacb361218ea0cb70028b2a741e85e725d156666','127.0.0.1',1750870007,'__ci_last_regenerate|i:1750870007;red_url|s:21:\"https://82.29.165.22/\";'),
('bb3dcc0027880ee3744623577bdbbdac04e64223','127.0.0.1',1750960007,'__ci_last_regenerate|i:1750960007;red_url|s:21:\"https://82.29.165.22/\";'),
('bb683f59bef4f050d59fc01d6b3c212070e080b9','2a02:4780:12:bfc5::1',1751023803,'__ci_last_regenerate|i:1751023802;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('bb7390f4da295cd4cd0a2bbf9c791f0d255ebf9d','2a02:4780:12:bfc5::1',1751135102,'__ci_last_regenerate|i:1751135102;'),
('bb748895f43662dc580b8ba6793296690581cad7','2a02:4780:12:bfc5::1',1751122501,'__ci_last_regenerate|i:1751122501;'),
('bba0c0bd0d3d18c1defabfbdbbd7d5830956b19e','157.48.82.220',1750937700,'__ci_last_regenerate|i:1750937700;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('bc465bbe701555bef71cd86dfb94fa84e8bb5d47','2a02:4780:12:bfc5::1',1751102702,'__ci_last_regenerate|i:1751102702;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('bc491f3c25b39c8f39f6f00708e11c00d4048b87','127.0.0.1',1750979106,'__ci_last_regenerate|i:1750979106;red_url|s:21:\"https://82.29.165.22/\";'),
('bc4c43596dbd4c8c0f813cc45427a3edc562d4cd','40.77.167.149',1751112006,'__ci_last_regenerate|i:1751112006;'),
('bc7dac1afa7093f77c04d7cd0dd6e0aa8b7485a8','82.29.165.22',1750934404,'__ci_last_regenerate|i:1750934401;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('bc859432876c50274692b0ee4ca0f6e1160e1a55','82.29.165.22',1750936502,'__ci_last_regenerate|i:1750936501;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('bcb54ca795f153d4a3b11b7ac02652d2bf77928d','2a02:4780:12:bfc5::1',1751090102,'__ci_last_regenerate|i:1751090101;'),
('bcc0d78ed0e41c2aae4b7afba39181ffaa8b110a','104.252.191.216',1751173606,'__ci_last_regenerate|i:1751173605;red_url|s:22:\"https://techdotbit.in/\";'),
('bd7c770ee55c608c2a305f28a3d0d196ff4ac8b9','2a02:4780:12:bfc5::1',1751093102,'__ci_last_regenerate|i:1751093102;'),
('bd954d3cbcfd57e9f77731f16d8f272def537dbd','82.29.165.22',1750866902,'__ci_last_regenerate|i:1750866902;'),
('bdb03a83aebe78e82b34017290d249de8dbc38b1','82.29.165.22',1750914007,'__ci_last_regenerate|i:1750914001;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('bdbb860ec8b1f5b3623e453457277c2f083d0a60','2a02:4780:12:bfc5::1',1751010601,'__ci_last_regenerate|i:1751010601;'),
('bde5bff045e29cbe7cd1660a7a0397a897651117','127.0.0.1',1750950003,'__ci_last_regenerate|i:1750950003;red_url|s:21:\"https://82.29.165.22/\";'),
('be028622bf9930224806b305d18b3ebe2f73f9c2','43.135.144.81',1751136104,'__ci_last_regenerate|i:1751136104;is_mobile|b:1;'),
('be2d842cc8d45b9454b7b355285501451b073902','82.29.165.22',1750997101,'__ci_last_regenerate|i:1750997101;'),
('be51d24a6570eecd4c3a66459acdacb068f5cfb9','127.0.0.1',1750894307,'__ci_last_regenerate|i:1750894307;red_url|s:21:\"https://82.29.165.22/\";'),
('be53960a294dfe31dc0dd7ac769c2dcadd34efef','82.29.165.22',1750932605,'__ci_last_regenerate|i:1750932602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('be63293334743a659693edcf8cc63adbf89a1b85','2a02:4780:12:bfc5::1',1751065502,'__ci_last_regenerate|i:1751065501;'),
('be6fe1377ad54a2f4ff7cb7ac93c80b897c9c96f','82.29.165.22',1750909804,'__ci_last_regenerate|i:1750909801;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('be9293b290e3c3daca243b0d535c89918cf5a1de','127.0.0.1',1750958207,'__ci_last_regenerate|i:1750958207;red_url|s:21:\"https://82.29.165.22/\";'),
('bea2b17c1bc2a611deaa8c8db64396d68848a607','127.0.0.1',1750920985,'__ci_last_regenerate|i:1750920985;red_url|s:21:\"https://82.29.165.22/\";'),
('bec9f202919a1ec0998fba82f5f6120d50472cd4','106.219.224.219',1750924806,'__ci_last_regenerate|i:1750924806;red_url|s:38:\"https://82.29.165.22/clients?companies\";'),
('becde1151c5bd0b3be09aed89188f25f73f9afd6','2a02:4780:12:bfc5::1',1751124602,'__ci_last_regenerate|i:1751124602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('bf16b7575ef32a91e0eaaf459c3c7516e762051e','2a02:4780:12:bfc5::1',1751023202,'__ci_last_regenerate|i:1751023202;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('bf47984db058673266c3fa36c22943dc8aa20e79','157.48.80.182',1750875806,'__ci_last_regenerate|i:1750875664;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('bfa18f62c1b81080e6228e86df0c190d450f238f','2a02:4780:12:bfc5::1',1751021102,'__ci_last_regenerate|i:1751021101;'),
('bfa2cf35983c8c87785acda0cbf72109dbf24542','2a02:4780:12:bfc5::1',1751158803,'__ci_last_regenerate|i:1751158802;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('bfa8b531c9c9e4213b2fedbb7f88bc7848a5a3da','82.29.165.22',1750967102,'__ci_last_regenerate|i:1750967102;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('bffe26a473a88db477bca961811397c9a2739a5e','82.29.165.22',1750847701,'__ci_last_regenerate|i:1750847701;'),
('c0121d62af0296ed61fba1b189fefaaa7a19fd4f','2a02:4780:12:bfc5::1',1751081702,'__ci_last_regenerate|i:1751081702;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('c08ca26a1685b5b6b4c594b12397d39639094978','127.0.0.1',1750910404,'__ci_last_regenerate|i:1750910403;red_url|s:21:\"https://82.29.165.22/\";'),
('c0a6c4e63c4f6f3ad4d9817989204f2b289da5bf','2a02:4780:12:bfc5::1',1751032803,'__ci_last_regenerate|i:1751032802;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('c0b8ef10d24bdfc91907d214021112dff014aaa3','127.0.0.1',1750931207,'__ci_last_regenerate|i:1750931207;red_url|s:21:\"https://82.29.165.22/\";'),
('c15703a73cf2f9e5a33621c7c35fb612f56944b2','::1',1750999283,'__ci_last_regenerate|i:1750999283;red_url|s:21:\"https://82.29.165.22/\";'),
('c169ef18becc6d7465711d222050b85f6aad39fa','45.135.193.162',1750884424,'__ci_last_regenerate|i:1750884424;red_url|s:21:\"https://82.29.165.22/\";'),
('c175487a86ce0ffb0b38e8e871ba258123a8f04e','82.177.111.26',1750878506,'__ci_last_regenerate|i:1750878506;red_url|s:21:\"https://82.29.165.22/\";'),
('c1a600f6f88c8553cc3873f7f4cb63cf8bb59991','2a02:4780:12:bfc5::1',1751115301,'__ci_last_regenerate|i:1751115301;'),
('c1f231c3e2603b62389c5d9db6d20d281aed7609','82.29.165.22',1750970102,'__ci_last_regenerate|i:1750970102;'),
('c1fbfc1f53b3062ded0123bf5fa890eb51b54cf6','82.29.165.22',1750894802,'__ci_last_regenerate|i:1750894802;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('c23841da171639b5e1c5f972aa953b40445b9648','127.0.0.1',1750859207,'__ci_last_regenerate|i:1750859207;red_url|s:21:\"https://82.29.165.22/\";'),
('c2412bfcc3d54f53e70c73526a31c19a9ee4970b','2a02:4780:12:bfc5::1',1751123403,'__ci_last_regenerate|i:1751123402;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('c271d6b096e979ab55b64792541725d631566f61','127.0.0.1',1750881906,'__ci_last_regenerate|i:1750881906;red_url|s:21:\"https://82.29.165.22/\";'),
('c27be8cba54c4b1a8b094bf50c30246f4767fb44','127.0.0.1',1750855607,'__ci_last_regenerate|i:1750855607;red_url|s:21:\"https://82.29.165.22/\";'),
('c281d824ed3eedee70254946ef773c8d21558479','2a02:4780:12:bfc5::1',1751022302,'__ci_last_regenerate|i:1751022302;'),
('c292e3161b6dc1d2d66bcd8531ba481ab9450433','2001:bc8:1201:1d:ba2a:72ff:fee1:1d32',1751060355,'__ci_last_regenerate|i:1751060354;'),
('c2f88f188e1e95f12250c6d2c82cb88a917679fa','127.0.0.1',1750922510,'__ci_last_regenerate|i:1750922510;red_url|s:21:\"https://82.29.165.22/\";'),
('c32a3e1b8287eb199e90dce0fb29c9e3bac9dcf8','127.0.0.1',1750909910,'__ci_last_regenerate|i:1750909910;red_url|s:21:\"https://82.29.165.22/\";'),
('c341a7a06d246a29624e9c35ebb921f59073656e','82.29.165.22',1750881602,'__ci_last_regenerate|i:1750881602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('c34c41c67e08e74dcc0304cbfa8bd901dc9696a5','127.0.0.1',1750863110,'__ci_last_regenerate|i:1750863110;red_url|s:21:\"https://82.29.165.22/\";'),
('c351b0c95cc3c4309c23bf5e95ebff03157a71dd','82.29.165.22',1750932902,'__ci_last_regenerate|i:1750932901;'),
('c364609562b541638076b6578254990241196649','82.29.165.22',1750932303,'__ci_last_regenerate|i:1750932302;'),
('c36af1ccdc4de24a5bf428cf78d7d7883b47699a','2a02:4780:12:bfc5::1',1751069702,'__ci_last_regenerate|i:1751069702;'),
('c36c6a5cbf0f5d2dcb6df96d91c0cc38ad274ffa','2a02:4780:12:bfc5::1',1751073603,'__ci_last_regenerate|i:1751073602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('c39493520d9f1b0e27a2422869f22e3e0e857372','2a02:4780:12:bfc5::1',1751117702,'__ci_last_regenerate|i:1751117701;'),
('c39f74ba75f531520aa477d93803b32cbd4307f7','2a02:4780:12:bfc5::1',1751069102,'__ci_last_regenerate|i:1751069102;'),
('c3a1346ca4d4ef1625e4f4d746e1c358f554fc81','2a02:4780:12:bfc5::1',1751085002,'__ci_last_regenerate|i:1751085001;'),
('c47abe365714850f5a91f90ece9bfa3bb0195f04','127.0.0.1',1750905107,'__ci_last_regenerate|i:1750905107;red_url|s:21:\"https://82.29.165.22/\";'),
('c49c311d50a5dfb187212b53c4cff5bf2251f295','34.93.17.9',1750897782,'__ci_last_regenerate|i:1750897782;red_url|s:21:\"https://82.29.165.22/\";'),
('c4cb73e37eff1bddbb742bc49e482ce16f1d8e5b','165.227.226.98',1750922080,'__ci_last_regenerate|i:1750922080;red_url|s:21:\"https://82.29.165.22/\";'),
('c4e3142d97e73d118165e2df3d0125377a9007b6','127.0.0.1',1750903508,'__ci_last_regenerate|i:1750903507;red_url|s:21:\"https://82.29.165.22/\";'),
('c51790ae7830ac6e8c81435037b1ac07adca9517','2a02:4780:12:bfc5::1',1751053502,'__ci_last_regenerate|i:1751053502;'),
('c518aea3f8888b0603eb577bc9a88211d237ae9c','127.0.0.1',1750907108,'__ci_last_regenerate|i:1750907108;red_url|s:21:\"https://82.29.165.22/\";'),
('c5243f8c9fa7cb672c79748a6fc3a26c63841e77','2a02:4780:12:bfc5::1',1751041202,'__ci_last_regenerate|i:1751041202;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('c549d1e1fbc7728b7c4fc288b2fef1779c92d0c1','82.29.165.22',1750915502,'__ci_last_regenerate|i:1750915502;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('c55e150671faafc16fdb7830c8cef7d2d16180b7','127.0.0.1',1750993205,'__ci_last_regenerate|i:1750993205;red_url|s:21:\"https://82.29.165.22/\";'),
('c5d2cbe50d73dae9a6f314392925bd994fe4e105','82.29.165.22',1750853102,'__ci_last_regenerate|i:1750853102;'),
('c61356268e31476191d9bb24592f44cb484166d5','2a02:4780:12:bfc5::1',1751040302,'__ci_last_regenerate|i:1751040301;'),
('c618c3552d6b4ad1c10a8b977a9eaa28cbf37c29','82.29.165.22',1750890301,'__ci_last_regenerate|i:1750890301;'),
('c63161da6f175d48b8b217800ca3accfa762d29b','2409:40d4:10cd:43f8:ccef:f512:e762:56b2',1751109556,'__ci_last_regenerate|i:1751109556;staff_user_id|s:1:\"1\";staff_logged_in|b:1;red_url|s:39:\"https://techdotbit.in/clients?companies\";setup-menu-open|b:1;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('c671382c1c4c8b8de3ed551af7b5178ea1d08e43','82.29.165.22',1750858202,'__ci_last_regenerate|i:1750858202;'),
('c6918f5b43916acb97e7a7c00096059d2a8a5cd5','2a02:4780:12:bfc5::1',1751140502,'__ci_last_regenerate|i:1751140502;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('c720eda3d919465988d088e8550bfeb6c54c5296','2a02:4780:12:bfc5::1',1751077202,'__ci_last_regenerate|i:1751077202;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('c7582c27e886698c6c721e1ae47d021779325229','2a02:4780:12:bfc5::1',1751123102,'__ci_last_regenerate|i:1751123101;'),
('c78dc6d1eb48b0b750a7afd445204b8793e97249','82.29.165.22',1750919405,'__ci_last_regenerate|i:1750919402;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('c7a7e3768522fac83d366af0c6854c768f65359f','82.29.165.22',1750965003,'__ci_last_regenerate|i:1750965001;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('c7b4ee23ce44e6bb8d4f245a346b6cddae7b664a','35.94.22.188',1751011957,'__ci_last_regenerate|i:1751011957;is_mobile|b:1;'),
('c85a2a3df9d59575a26110fcd3e2d1ea216653d7','2a02:4780:12:bfc5::1',1751169002,'__ci_last_regenerate|i:1751169002;'),
('c85c3ee1fcad6efd92de5c10369dd729a3c97359','2a02:4780:12:bfc5::1',1751083203,'__ci_last_regenerate|i:1751083201;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('c86b67c047d90ca6bafdf0c10c81c165d6104bf1','127.0.0.1',1750869410,'__ci_last_regenerate|i:1750869410;red_url|s:21:\"https://82.29.165.22/\";'),
('c89c789c5f3e04c328f4fc68b6674eed0b495233','2a02:4780:12:bfc5::1',1751128802,'__ci_last_regenerate|i:1751128801;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('c8af865f7b4c96de36c04f15564be97606c16c47','82.29.165.22',1750928401,'__ci_last_regenerate|i:1750928401;'),
('c8bb996d2796dc154c5455395d2f03a68cf6e06c','178.128.18.34',1751068051,'__ci_last_regenerate|i:1751068051;red_url|s:22:\"https://techdotbit.in/\";'),
('c8bc73b1a933cabf54ffe6afc7b512d5c757a7cc','127.0.0.1',1750994207,'__ci_last_regenerate|i:1750994207;red_url|s:21:\"https://82.29.165.22/\";'),
('c8bf8b45a5ea2854c924df746ca8bd36201920a9','127.0.0.1',1750977468,'__ci_last_regenerate|i:1750977468;red_url|s:21:\"https://82.29.165.22/\";'),
('c8ee3ad7adae188e5ff8eacc0d4bb9fe8985b0b9','2a02:4780:12:bfc5::1',1751008203,'__ci_last_regenerate|i:1751008202;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('c960bb8e76706f24ae28b76ea0d6ec557ee3f1f0','82.29.165.22',1750959001,'__ci_last_regenerate|i:1750959001;'),
('c9a5a93db102243708679e874b7b3a9eb39c5195','45.135.193.162',1750884425,'__ci_last_regenerate|i:1750884425;red_url|s:21:\"https://82.29.165.22/\";'),
('c9ee5cbc30286acc5acc7168a7b7fd00a104cecf','2a02:4780:12:bfc5::1',1751074802,'__ci_last_regenerate|i:1751074802;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('ca1f3b03a5ab648cc47f47d36607a8ae0f6ada0b','2409:40d4:10cd:43f8:f408:13f9:e02c:5190',1751009991,'__ci_last_regenerate|i:1751009991;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('ca5754d3f64379428cfa584fc39e8356db4979be','82.29.165.22',1750880401,'__ci_last_regenerate|i:1750880401;'),
('ca6153fa64021d45e2087ea4393ca2aacfcfedb8','127.0.0.1',1750967509,'__ci_last_regenerate|i:1750967509;red_url|s:21:\"https://82.29.165.22/\";'),
('caaf9578f8c25e6c5263fbea5446c619e722b38b','2a02:4780:12:bfc5::1',1751161202,'__ci_last_regenerate|i:1751161202;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('cab72007f6114ba0156ea86dc2e780780f43c664','2a02:4780:12:bfc5::1',1751058301,'__ci_last_regenerate|i:1751058301;'),
('cadc5deffdebd5da839c38b8b4e330ccd822b3e3','2a02:4780:12:bfc5::1',1751082302,'__ci_last_regenerate|i:1751082302;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('caff5bdd72f7d4af6e9d9f9980b4066e8d5fe1be','2a02:4780:12:bfc5::1',1751020202,'__ci_last_regenerate|i:1751020202;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('cb04014fc4455291dfb56e7f4f336abd46937ca9','127.0.0.1',1750851107,'__ci_last_regenerate|i:1750851107;red_url|s:21:\"https://82.29.165.22/\";'),
('cb05803b35a3ded1b42a0d148b872c99344f1a93','2a02:4780:12:bfc5::1',1751072403,'__ci_last_regenerate|i:1751072402;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('cb0e3a57e431255728f5e8fcc9054ecf29d64391','82.29.165.22',1750918501,'__ci_last_regenerate|i:1750918501;'),
('cb222d763163830dfbfd01130340d3b0b6d47b15','82.29.165.22',1750970702,'__ci_last_regenerate|i:1750970702;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('cba21812fcf6808fa63cb1d90334ab01263f6387','2a02:4780:12:bfc5::1',1751099701,'__ci_last_regenerate|i:1751099701;'),
('cba85659d8d0daa43a3a6fe5f1467f504c2d446b','2a02:4780:12:bfc5::1',1751005502,'__ci_last_regenerate|i:1751005502;'),
('cbd0eeb6a388bf59796deea0fafd3fb02fae280e','127.0.0.1',1750884725,'__ci_last_regenerate|i:1750884725;red_url|s:21:\"https://82.29.165.22/\";'),
('cbef29204548378b7916015ad8d98b20fc8c8b99','2409:40d4:10cd:43f8:ccef:f512:e762:56b2',1751173448,'__ci_last_regenerate|i:1751173423;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;client_user_id|s:1:\"4\";contact_user_id|s:1:\"4\";client_logged_in|b:1;'),
('cc4fa064cfba03b2b28d124e4a4d671416f137b0','82.29.165.22',1750980302,'__ci_last_regenerate|i:1750980302;'),
('cc7ec815a10a2997765d98fbddd221a839dec388','82.29.165.22',1750941304,'__ci_last_regenerate|i:1750941302;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('cc83b15d5191b39e3268ea89eaf6843ba03e9054','2a02:4780:12:bfc5::1',1751158202,'__ci_last_regenerate|i:1751158202;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('cc8855595a1d56a2376e9861fd0489c348fabaad','2001:bc8:1201:1d:ba2a:72ff:fee1:1d32',1751060344,'__ci_last_regenerate|i:1751060339;red_url|s:39:\"https://techdotbit.in/clients?companies\";'),
('cc9d0567b13046cfb4055b476fe8860b06e16f16','82.29.165.22',1750884902,'__ci_last_regenerate|i:1750884902;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('ccb2397c0f0ef3c9ec8c8acd850f05f902cb81d7','82.29.165.22',1750931403,'__ci_last_regenerate|i:1750931402;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('cd249934764b658e5e067e3943beb9693ff59130','82.29.165.22',1750962001,'__ci_last_regenerate|i:1750962001;'),
('cd37066e4b03ece9c2ddb9f1776d4987bcfdebbb','127.0.0.1',1750871406,'__ci_last_regenerate|i:1750871406;red_url|s:21:\"https://82.29.165.22/\";'),
('cd56e246a1edae98baad72b3fc2ba05e1537c3dd','157.55.39.197',1751063594,'__ci_last_regenerate|i:1751063592;'),
('cd66331c95cc5b120b45ff1b07ba830674430980','2a02:4780:12:bfc5::1',1751115604,'__ci_last_regenerate|i:1751115603;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('cd6a13a7eeacdc59e9b7ce954c83db31bf62052b','82.29.165.22',1750990801,'__ci_last_regenerate|i:1750990801;'),
('cd6e718d5da4d8f80d793ecfadeb2c5dfded3472','82.29.165.22',1750953302,'__ci_last_regenerate|i:1750953301;'),
('cd74a14e1d74a5866df9ae4ca91c29e4e16118f5','2a02:4780:12:bfc5::1',1751165402,'__ci_last_regenerate|i:1751165402;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('cd8dbebc4afde6da5bb89270265d03ac174837b3','2a02:4780:12:bfc5::1',1751007302,'__ci_last_regenerate|i:1751007302;'),
('cda0e734b8587b91b323a38fed3571497305e5b1','127.0.0.1',1750927010,'__ci_last_regenerate|i:1750927010;red_url|s:21:\"https://82.29.165.22/\";'),
('cdcd34ec39d3b181104b4603c4f2cdc4470ae610','82.29.165.22',1750850402,'__ci_last_regenerate|i:1750850401;'),
('cddc6cdd64328ecf4430b3d44d8ad4e8cf0093f8','127.0.0.1',1750975204,'__ci_last_regenerate|i:1750975204;red_url|s:21:\"https://82.29.165.22/\";'),
('ce4bc5aded06873ee8800b43d48aa7c9bdd9f8af','2a02:4780:12:bfc5::1',1751037602,'__ci_last_regenerate|i:1751037602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('ce65fbd7ef2bff4c3b654b3bf5202326a6c34273','2a02:4780:12:bfc5::1',1751067602,'__ci_last_regenerate|i:1751067601;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('ce918f4f8756d7610ecd276f89ac594eb88dc7b8','127.0.0.1',1750849809,'__ci_last_regenerate|i:1750849809;red_url|s:21:\"https://82.29.165.22/\";'),
('ce9493e6c5ece42c7c9397ebe84ba8d30e5698b2','127.0.0.1',1750883507,'__ci_last_regenerate|i:1750883507;red_url|s:21:\"https://82.29.165.22/\";'),
('ce9ff2e46508e8352d01fc39c5c2c131c1068480','161.35.58.80',1751130239,'__ci_last_regenerate|i:1751130238;is_mobile|b:1;red_url|s:22:\"https://techdotbit.in/\";'),
('ceaef5c2c07ec4103cbcb27177162afbc9ac1fc9','2a02:4780:12:bfc5::1',1751052902,'__ci_last_regenerate|i:1751052902;'),
('cec9d3d0095fe69ebfa79a688cb50d2b704e072c','127.0.0.1',1750944707,'__ci_last_regenerate|i:1750944707;red_url|s:21:\"https://82.29.165.22/\";'),
('cecff5b2a91afa84392354469a5d545ab3dce60c','2409:40d4:10cd:43f8:ccef:f512:e762:56b2',1751101636,'__ci_last_regenerate|i:1751101636;staff_user_id|s:1:\"1\";staff_logged_in|b:1;red_url|s:39:\"https://techdotbit.in/clients?companies\";setup-menu-open|b:1;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('ceede8428fc9e98cd4cbc8108815b8e401f9f58e','127.0.0.1',1750891010,'__ci_last_regenerate|i:1750891009;red_url|s:21:\"https://82.29.165.22/\";'),
('cf60c8db9edc411067ab8d790d0ae08cb4299421','2a02:4780:12:bfc5::1',1751086502,'__ci_last_regenerate|i:1751086502;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('cf9eacf975d9ab7f4a256b01d7174cd0eb2e3d84','127.0.0.1',1750963010,'__ci_last_regenerate|i:1750963009;red_url|s:21:\"https://82.29.165.22/\";'),
('d01734632b641df91eaad9df2828359437ad55e0','2a02:4780:12:bfc5::1',1751029501,'__ci_last_regenerate|i:1751029501;'),
('d0256e7bb202ff681b828686cb2ead421889be27','2a02:4780:12:bfc5::1',1751045102,'__ci_last_regenerate|i:1751045102;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('d038996ad23eea733b880c4777f1ac7fae7cef77','172.241.152.236',1751136635,'__ci_last_regenerate|i:1751136634;red_url|s:22:\"https://techdotbit.in/\";'),
('d05eae19eeed1a9abed872d43277efed07aa9144','103.196.9.102',1751004591,'__ci_last_regenerate|i:1751004590;red_url|s:22:\"https://techdotbit.in/\";'),
('d09c451c4426f6616f9caca7a2168fc090421c87','127.0.0.1',1750989109,'__ci_last_regenerate|i:1750989109;red_url|s:21:\"https://82.29.165.22/\";'),
('d0ab0f6d4753096bd20d13c372a4dd3de45d96e0','82.29.165.22',1750905901,'__ci_last_regenerate|i:1750905901;'),
('d0f388754757046fda4fd95c45c6fddd6bc4c392','2a02:4780:12:bfc5::1',1751127602,'__ci_last_regenerate|i:1751127602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('d10be51387c3d02ea88c2047f210ec9bb9ac9c7e','82.29.165.22',1750987805,'__ci_last_regenerate|i:1750987801;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('d17d6e6c84d2a7a325833407ab8cee9bcd3724db','127.0.0.1',1750968004,'__ci_last_regenerate|i:1750968004;red_url|s:21:\"https://82.29.165.22/\";'),
('d1ee8d05e7f97b529c75f9e5210c603a0a33c04c','2a02:4780:12:bfc5::1',1751139302,'__ci_last_regenerate|i:1751139302;'),
('d221620d6d278bbb77a5b14578a290b9cbb8dfe4','2409:40d4:10cd:43f8:f408:13f9:e02c:5190',1751010713,'__ci_last_regenerate|i:1751010713;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"old\";}'),
('d23c71927286179a4ebb2ae5e119e662e19a947a','157.48.80.182',1750901814,'__ci_last_regenerate|i:1750901814;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;'),
('d250596cf6c0313dd843789ddee4d28dd6df69a2','127.0.0.1',1750878706,'__ci_last_regenerate|i:1750878706;red_url|s:21:\"https://82.29.165.22/\";'),
('d27668a083e56e3a42c610357bd6a1575b42171e','127.0.0.1',1750966307,'__ci_last_regenerate|i:1750966307;red_url|s:21:\"https://82.29.165.22/\";'),
('d28283e94b0388c24f0b8b245b80cea2ee408587','127.0.0.1',1750851410,'__ci_last_regenerate|i:1750851410;red_url|s:21:\"https://82.29.165.22/\";'),
('d2a9be14c60e13a5e17a27bd4e9145eac5178e92','2a02:4780:12:bfc5::1',1751155802,'__ci_last_regenerate|i:1751155801;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('d2ad90efbe721145fe05368c2ef8ecbb4ec2dcfd','127.0.0.1',1750968308,'__ci_last_regenerate|i:1750968308;red_url|s:21:\"https://82.29.165.22/\";'),
('d2ae1eea40d8d1c15dd67f8c62bdeda5a6da543b','82.29.165.22',1750865401,'__ci_last_regenerate|i:1750865401;'),
('d2b1565eef0e58ae198391e93dfb3b8b07e4c1f7','2a02:4780:12:bfc5::1',1751039101,'__ci_last_regenerate|i:1751039101;'),
('d2c60b926041edffb68ac39b75851b6afa9119f9','82.29.165.22',1750883402,'__ci_last_regenerate|i:1750883402;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('d2d1ba26a7536edcbbf9d854525963c2d3edb18b','2a02:4780:12:bfc5::1',1751090403,'__ci_last_regenerate|i:1751090402;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('d2eb7622ac9e6564b8aa02ff90c4a1372368c298','2a02:4780:12:bfc5::1',1751049902,'__ci_last_regenerate|i:1751049902;'),
('d2f2a783c0c3c43d3363259a2d063352c6b132e2','127.0.0.1',1750938407,'__ci_last_regenerate|i:1750938407;red_url|s:21:\"https://82.29.165.22/\";'),
('d319737b6f97e02a0f8e4fd07f632b189b38f723','82.29.165.22',1750878902,'__ci_last_regenerate|i:1750878902;'),
('d3357d70770f83357dafc98c9722161d11db0095','69.67.183.108',1751000713,'__ci_last_regenerate|i:1751000712;'),
('d343cb005e95914416c8b672188aa7a85d528e03','2a02:4780:12:bfc5::1',1751073002,'__ci_last_regenerate|i:1751073001;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('d378a0a1c8de446fb3969f97734d5ea73e54312a','127.0.0.1',1750885505,'__ci_last_regenerate|i:1750885505;red_url|s:21:\"https://82.29.165.22/\";'),
('d3ba5bbb716ea508322711d8eb2687b548d00f4b','82.29.165.22',1750900202,'__ci_last_regenerate|i:1750900201;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('d3e20dbaa815e2331a1cd9e5d2f5d88e41ffec80','82.29.165.22',1750891502,'__ci_last_regenerate|i:1750891501;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('d41048941cfea7d56e9939d2f0da935b16179162','2a02:4780:12:bfc5::1',1751150402,'__ci_last_regenerate|i:1751150402;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('d51b4c6d21933a85abf1f10ab4d53d7a93ca0ff3','2a02:4780:12:bfc5::1',1751021701,'__ci_last_regenerate|i:1751021701;'),
('d564161a4f181fe624604d9403aeb526ff164f67','2a02:4780:12:bfc5::1',1751116203,'__ci_last_regenerate|i:1751116202;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('d5e8b75c8cbd9dbd55ec6d2a4d37c41ad66cc401','127.0.0.1',1750896007,'__ci_last_regenerate|i:1750896007;red_url|s:21:\"https://82.29.165.22/\";'),
('d6cdaed628bca15d3a0c8879e9de889d20f5b065','2a02:4780:12:bfc5::1',1751055002,'__ci_last_regenerate|i:1751055002;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('d6f11ea868be2e138388515e217c3c916249a0f4','2a02:4780:12:bfc5::1',1751168401,'__ci_last_regenerate|i:1751168401;'),
('d73667e417f97a468c6034572e4d0417e0b25863','64.227.189.119',1751167824,'__ci_last_regenerate|i:1751167823;red_url|s:22:\"https://techdotbit.in/\";'),
('d79b8cd6ac4e7f55bd3ab56f5d87cbe156191d67','103.196.9.101',1751006619,'__ci_last_regenerate|i:1751006618;red_url|s:22:\"https://techdotbit.in/\";'),
('d7d82bb8399c1ed3501d4f17c30809579ab69762','2a02:4780:12:bfc5::1',1751102102,'__ci_last_regenerate|i:1751102102;'),
('d82789e349619c62b3dde4cd13736bf8b8681645','2a02:4780:12:bfc5::1',1751108701,'__ci_last_regenerate|i:1751108701;'),
('d8589fc3abe978940be8b210c29b8d7488b7e5f1','2a02:4780:12:bfc5::1',1751093402,'__ci_last_regenerate|i:1751093401;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('d86211b8f6249004f83c50acf69291990f412d99','82.29.165.22',1750884301,'__ci_last_regenerate|i:1750884301;'),
('d8684cbfc2629c0f59a77092b823ebcc6abea69b','82.29.165.22',1750969502,'__ci_last_regenerate|i:1750969502;'),
('d8ab3635540ae3e6868a3d164978883df27a4892','2a05:9403::5f9',1751050298,'__ci_last_regenerate|i:1751050298;red_url|s:22:\"https://techdotbit.in/\";'),
('d8c3736d4eb21cce78cc6ebc585c9465f354ef2c','2a02:4780:12:bfc5::1',1751141102,'__ci_last_regenerate|i:1751141102;'),
('d8d3bc45c2de4d4783f32af431d8550d2aca4db8','127.0.0.1',1751002610,'__ci_last_regenerate|i:1751002610;red_url|s:21:\"https://82.29.165.22/\";'),
('d94a0f8acc3e19d3153d97fc155a988bb0ac9258','2a02:4780:12:bfc5::1',1751042102,'__ci_last_regenerate|i:1751042102;'),
('d96b5348cf678000f732196d584ea7b3d235ecd9','82.29.165.22',1750892101,'__ci_last_regenerate|i:1750892101;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('d9cf3b49d9c8db35a4196339f740a8a8170f200b','2a02:4780:12:bfc5::1',1751091301,'__ci_last_regenerate|i:1751091301;'),
('d9d240b895376b5a11d6af8c2f038711ef1163e9','82.29.165.22',1750877402,'__ci_last_regenerate|i:1750877402;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('d9d9ba3a95df0b1aaf1ebf0eb22f52bfb615e8f5','82.29.165.22',1750855201,'__ci_last_regenerate|i:1750855201;'),
('d9f6fdae199e75dafb63e781d1ab41255953e8f3','2a02:4780:12:bfc5::1',1751012102,'__ci_last_regenerate|i:1751012101;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('d9fc931f9198df5416eca6d0b9809b682bb8d418','2a02:4780:12:bfc5::1',1751030102,'__ci_last_regenerate|i:1751030102;'),
('da435da44f168144500d6f11b93fce8d74493a8f','127.0.0.1',1750896613,'__ci_last_regenerate|i:1750896613;red_url|s:21:\"https://82.29.165.22/\";'),
('da68d4c85f6ad2342d7642fbf7621c2b6546b2e0','2a02:4780:12:bfc5::1',1751045702,'__ci_last_regenerate|i:1751045701;'),
('da68e4c2fc758bc6a46c44dbd166bdb6cad0982d','82.29.165.22',1750874402,'__ci_last_regenerate|i:1750874401;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('da8daf9de911f216737c17eaed13e56fb0c0468c','2a02:4780:12:bfc5::1',1751126702,'__ci_last_regenerate|i:1751126702;'),
('daa16ca1c9d06a62eef3367f4f54c6508a868306','34.93.17.9',1750897783,'__ci_last_regenerate|i:1750897783;'),
('dab9ab6f51fd5f66322eb8e36251e060e51af20b','2a02:4780:12:bfc5::1',1751137802,'__ci_last_regenerate|i:1751137802;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('dabb68792e7e79efd0aa139488054fd3072dac4d','127.0.0.1',1750980707,'__ci_last_regenerate|i:1750980707;red_url|s:21:\"https://82.29.165.22/\";'),
('dada8aa55dfb48c6e26fb9620dbc4abd367603a5','2a02:4780:12:bfc5::1',1751169902,'__ci_last_regenerate|i:1751169901;'),
('dae7122c068025b859ba426ed5e81306da23f024','82.29.165.22',1750860601,'__ci_last_regenerate|i:1750860601;'),
('daf24700721acb93467fb40272ccb62fb31b5423','127.0.0.1',1750925807,'__ci_last_regenerate|i:1750925807;red_url|s:21:\"https://82.29.165.22/\";'),
('db0c4b37ccc67349e1880e8f9c77aeec42cc594f','127.0.0.1',1750987907,'__ci_last_regenerate|i:1750987907;red_url|s:21:\"https://82.29.165.22/\";'),
('db1f6eee50c81a44c74985b9add151baf5d023d4','2a02:4780:12:bfc5::1',1751014502,'__ci_last_regenerate|i:1751014501;'),
('db2ef82fb1cfaa787b32f7ab1437d4d211253303','127.0.0.1',1750908486,'__ci_last_regenerate|i:1750908485;red_url|s:21:\"https://82.29.165.22/\";'),
('db49db291d743f2bd95ea4c8f58a5582940e2083','2a02:4780:12:bfc5::1',1751079604,'__ci_last_regenerate|i:1751079603;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('dbae5e54404e90e8d327418e05d988ce8fcd3192','2a02:4780:12:bfc5::1',1751111403,'__ci_last_regenerate|i:1751111403;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('dbbc6aa71443ea4321634d4e3271f32f3592cdba','82.29.165.22',1750897502,'__ci_last_regenerate|i:1750897501;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('dbef8a66f1da3ffd70c1941d43356a2dc087fdd9','127.0.0.1',1750951105,'__ci_last_regenerate|i:1750951105;red_url|s:21:\"https://82.29.165.22/\";'),
('dcd00928dc8635d04310cd5fba7b0781d25dbf3f','82.29.165.22',1750917904,'__ci_last_regenerate|i:1750917901;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('dcda1ecf624aae7670eb7135e047987981dbe761','2a02:4780:12:bfc5::1',1751122202,'__ci_last_regenerate|i:1751122202;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('dcf5eca2b4b72e1cbd08fb3a0eaf285a45915044','82.29.165.22',1750951504,'__ci_last_regenerate|i:1750951501;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('dd0cabc9258111ef2adbd250336e05ba97b7d47c','82.29.165.22',1750966803,'__ci_last_regenerate|i:1750966801;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('dd3df6b05985e08ab06a03d0dcc975c3787e115e','82.29.165.22',1750873802,'__ci_last_regenerate|i:1750873801;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('dd7f259df702ce24529a4c34aa4b753e530cac30','2a02:4780:12:bfc5::1',1751162102,'__ci_last_regenerate|i:1751162101;'),
('dd9c10055aa2c710b4b5f8133c2564b9e067196b','127.0.0.1',1750866710,'__ci_last_regenerate|i:1750866710;red_url|s:21:\"https://82.29.165.22/\";'),
('ddc48f78f06b41b06e7c3f2aa5b105ed6367d31a','127.0.0.1',1750953909,'__ci_last_regenerate|i:1750953909;red_url|s:21:\"https://82.29.165.22/\";'),
('ddca253706903931c0d896e3050eac94fff10800','127.0.0.1',1750915310,'__ci_last_regenerate|i:1750915310;red_url|s:21:\"https://82.29.165.22/\";'),
('de401b37d7fa7c74b50dc8c9af34bedc376257ff','127.0.0.1',1750961108,'__ci_last_regenerate|i:1750961108;red_url|s:21:\"https://82.29.165.22/\";'),
('de46112d924daad9384dd2a1e5892e2284b04340','2a02:4780:12:bfc5::1',1751164802,'__ci_last_regenerate|i:1751164802;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('de82f9ce0c06ec692e58a9fdb0a8794926557ea7','82.29.165.22',1750950001,'__ci_last_regenerate|i:1750950001;'),
('dea6959ee43d8e5bf96afcc207c3f75b8ebb6ab9','82.29.165.22',1750902902,'__ci_last_regenerate|i:1750902902;'),
('deb9c2c8b7837d02cae1f3de413a2c49da9d2658','127.0.0.1',1750950609,'__ci_last_regenerate|i:1750950609;red_url|s:21:\"https://82.29.165.22/\";'),
('defc3eaaca42f35efa415eedb19ba387a0f5fd8b','2a02:4780:12:bfc5::1',1751035803,'__ci_last_regenerate|i:1751035802;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('df3577586e849ba90ddd5584381db207969d12ed','82.29.165.22',1750940403,'__ci_last_regenerate|i:1750940401;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('df3a38eb43de755a039e4da266296bb00287efa7','127.0.0.1',1750991507,'__ci_last_regenerate|i:1750991507;red_url|s:21:\"https://82.29.165.22/\";'),
('df4a29c57f49aaee8a6e41d4de4a432ece349339','2a05:9403::5f9',1751050299,'__ci_last_regenerate|i:1751050299;'),
('df4ba976e17bb0f8e27d2ad8177d314431216bc7','2409:40d4:10cd:43f8:f408:13f9:e02c:5190',1751006850,'__ci_last_regenerate|i:1751006644;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";message-danger|s:0:\"\";__ci_vars|a:2:{s:14:\"message-danger\";s:3:\"old\";s:5:\"debug\";s:3:\"new\";}debug|s:457:\"<h1>Your SMTP settings are not set correctly here is the debug log.</h1><br />SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting<br /><pre>\n\n</pre>Connection: opening to smtp.hostinger.com:465, timeout=30, options=array()<br />Connection: opened<br />SERVER -> CLIENT: <br />Connection: closing due to error<br />Connection: closed<br />SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting<br />\";'),
('df7303aa0aede6b18408c20a8055ab3a14e08fdc','82.29.165.22',1750969804,'__ci_last_regenerate|i:1750969801;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('df82a02c9896229135517ae5515a2ee860805bb6','2a02:4780:12:bfc5::1',1751097002,'__ci_last_regenerate|i:1751097001;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('df92f3c3776a4dc75fefc6f4fadc2065911ce534','2a02:4780:12:bfc5::1',1751123702,'__ci_last_regenerate|i:1751123701;'),
('dfde865ed28a8369c372fcfc7064b61e6e09dd11','176.96.131.92',1750951065,'__ci_last_regenerate|i:1750951065;red_url|s:21:\"https://82.29.165.22/\";'),
('e0035bc906414bde2258128fc1e69f89c3af7026','127.0.0.1',1750953110,'__ci_last_regenerate|i:1750953110;red_url|s:21:\"https://82.29.165.22/\";'),
('e04347405116ff32ad36695ab11082a6254417f0','127.0.0.1',1750991810,'__ci_last_regenerate|i:1750991810;red_url|s:21:\"https://82.29.165.22/\";'),
('e0590f15cfd444be7db8d6e5cdb103470780fb11','82.29.165.22',1750876802,'__ci_last_regenerate|i:1750876802;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('e05c5782136297663f4d73a21bf99915084a164a','2a02:4780:12:bfc5::1',1751091002,'__ci_last_regenerate|i:1751091002;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('e0647e320d5b54badd6afa0ba3fe4e2db19d19fd','2a02:4780:12:bfc5::1',1751024402,'__ci_last_regenerate|i:1751024402;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('e0fa0458f4ee7d983c3910d168b012febac0ebc4','2a02:4780:12:bfc5::1',1751095803,'__ci_last_regenerate|i:1751095802;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('e0fc6f488b60b6b94a49657daf79200d001b8b30','127.0.0.1',1750988807,'__ci_last_regenerate|i:1750988807;red_url|s:21:\"https://82.29.165.22/\";'),
('e11b8f51b80286bf6b3740eb7460c8cc8bfca920','2a02:4780:12:bfc5::1',1751026802,'__ci_last_regenerate|i:1751026801;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('e11c5171855d5b92c4b75cd39351eed8ae596a7a','2a02:4780:12:bfc5::1',1751052002,'__ci_last_regenerate|i:1751052002;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('e13606fc904c757b6970fcb2a6cc3b6bdc74c71b','127.0.0.1',1750976874,'__ci_last_regenerate|i:1750976874;red_url|s:21:\"https://82.29.165.22/\";'),
('e165182b58995e264dc76574853dd88192ad22da','2a02:4780:12:bfc5::1',1751159101,'__ci_last_regenerate|i:1751159101;'),
('e1749a320bf75dc0b40438bd9d3e211f96dcb3b3','44.242.141.207',1751074879,'__ci_last_regenerate|i:1751074878;is_mobile|b:1;red_url|s:22:\"https://techdotbit.in/\";'),
('e1ac79ee698aa2520521e5b04dbde4172f2ca50d','82.29.165.22',1750861502,'__ci_last_regenerate|i:1750861501;'),
('e1e449eb6a021018568b2f6f5c88cdf745f38558','157.48.80.182',1750865842,'__ci_last_regenerate|i:1750865842;red_url|s:26:\"https://82.29.165.22/admin\";'),
('e1eacb1dad530e304008b5b917ee5215ebf7b253','82.29.165.22',1750929602,'__ci_last_regenerate|i:1750929602;'),
('e2274d66691b9a94f18d6ce1c4476f26f7a89cb3','2a02:4780:12:bfc5::1',1751149202,'__ci_last_regenerate|i:1751149202;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('e25bece67c7552f39623393336e07a048fa49280','82.29.165.22',1750949401,'__ci_last_regenerate|i:1750949401;'),
('e2f4e17ba5601ea99669da428f8380ac68ce1df4','157.48.80.182',1750902140,'__ci_last_regenerate|i:1750902140;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;'),
('e2fdd813d0875941280a6ad707e499ee5e0b0575','82.29.165.22',1750912805,'__ci_last_regenerate|i:1750912802;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('e3291fd9c471a72ae49718a1b9098efe7a110dd8','157.48.221.10',1751002722,'__ci_last_regenerate|i:1751002722;red_url|s:38:\"https://82.29.165.22/clients?companies\";'),
('e3d0a93fb9c914f3a903bf44c23edcf8a9574507','82.29.165.22',1750882202,'__ci_last_regenerate|i:1750882201;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('e3d0cce2cbc156c3c70d9b1123e59db1578cc77b','2a02:4780:12:bfc5::1',1751110803,'__ci_last_regenerate|i:1751110802;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('e3d149441573949090cab25b690e45df030c487a','2a02:4780:12:bfc5::1',1751009702,'__ci_last_regenerate|i:1751009702;'),
('e3ea6df98a10ab0e33753f7a15030721cfbfd9a7','2a02:4780:12:bfc5::1',1751062202,'__ci_last_regenerate|i:1751062202;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('e400b2f0a421a321991191a96fd3a75141e4184c','82.29.165.22',1750886402,'__ci_last_regenerate|i:1750886401;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('e41215d8965002ee277aafd96b29778998f904ef','82.29.165.22',1750868101,'__ci_last_regenerate|i:1750868101;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('e47a6163efd61c03962f47fa8c63ba1f03b3de6b','82.29.165.22',1750899902,'__ci_last_regenerate|i:1750899902;'),
('e47b48ae7cd4bf8a12deb33abcc3ef31cb88fd7f','127.0.0.1',1750892403,'__ci_last_regenerate|i:1750892402;red_url|s:21:\"https://82.29.165.22/\";'),
('e49fd90f158df83c668d0cd62dec9afba57643ba','2a02:4780:12:bfc5::1',1751136902,'__ci_last_regenerate|i:1751136902;'),
('e4df12ba6c66fce2b42927aa8812480ea08f8384','127.0.0.1',1750946703,'__ci_last_regenerate|i:1750946703;red_url|s:21:\"https://82.29.165.22/\";'),
('e4ed3555f76eb3c4904aeb1c7b8917f25062574d','45.56.110.54',1750929893,'__ci_last_regenerate|i:1750929893;'),
('e4f5e6a85005300a2147d754f1d5cda0e9452615','157.48.80.182',1750919269,'__ci_last_regenerate|i:1750919269;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;logged_in_as_client|b:1;magic_auth|a:2:{s:12:\"cross_domain\";i:0;s:10:\"source_url\";s:55:\"https://82.29.165.22/fecuni/ps/admin/billing/my_account\";}'),
('e5016a460a21e5b10f9ae562fea4e5beb76ae8de','157.48.221.10',1750952082,'__ci_last_regenerate|i:1750952072;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('e5106621a4a2c1f41b4ad122f1c8f6748b63a5f5','127.0.0.1',1750951907,'__ci_last_regenerate|i:1750951907;red_url|s:21:\"https://82.29.165.22/\";'),
('e51a123415a5e036ff34fb27c3501c254a3f2737','127.0.0.1',1750970746,'__ci_last_regenerate|i:1750970746;red_url|s:21:\"https://82.29.165.22/\";'),
('e524927e9e7533db4c712de11b9ef7c8b0628124','127.0.0.1',1750901810,'__ci_last_regenerate|i:1750901810;red_url|s:21:\"https://82.29.165.22/\";'),
('e52c7304494b77473dc9749bd737cb2e6ca48c0d','127.0.0.1',1750883809,'__ci_last_regenerate|i:1750883809;red_url|s:21:\"https://82.29.165.22/\";'),
('e53bfc61c9bf86df064c85b2e0e08a1a54acb4cd','2a02:4780:12:bfc5::1',1751030402,'__ci_last_regenerate|i:1751030402;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('e56c9b257eddd7572f6d15ba91a552bd619b99a7','82.29.165.22',1750991704,'__ci_last_regenerate|i:1750991701;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('e57ccff4922fd883de3e22167cacf51d72d6bf77','2a02:4780:12:bfc5::1',1751112005,'__ci_last_regenerate|i:1751112002;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('e597de4b0a0a09ab49b67954589d2f965af71e40','2409:40d4:10cd:43f8:f408:13f9:e02c:5190',1751008690,'__ci_last_regenerate|i:1751008690;perfex_saas_enable_auto_trial|s:1:\"0\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";client_user_id|s:1:\"2\";contact_user_id|s:1:\"2\";client_logged_in|b:1;'),
('e59d84f17d08db89936108da3e4229413f577902','82.29.165.22',1750984205,'__ci_last_regenerate|i:1750984203;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('e5a04689a04c9211656cf0ae6772816d0d727582','127.0.0.1',1750958510,'__ci_last_regenerate|i:1750958510;red_url|s:21:\"https://82.29.165.22/\";'),
('e6141e5abffabc470a1c03f027a544e8431f2edc','82.29.165.22',1750950304,'__ci_last_regenerate|i:1750950302;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('e636a9fe1a46134da1b9760f2f3d57043e37dea4','2a02:4780:12:bfc5::1',1751047502,'__ci_last_regenerate|i:1751047502;'),
('e64875b6d65c11d067fd886314d53b65a57e4609','2a02:4780:12:bfc5::1',1751079002,'__ci_last_regenerate|i:1751079002;'),
('e67f3c475f1a477815ab74504e10c4194d94cd1c','127.0.0.1',1750912610,'__ci_last_regenerate|i:1750912610;red_url|s:21:\"https://82.29.165.22/\";'),
('e6a2f67422f1af06d7777995b2df724f30201b54','82.29.165.22',1750860302,'__ci_last_regenerate|i:1750860302;'),
('e6a5ccc293d389bc998ae63f6871f25fcb641199','157.48.80.182',1750875305,'__ci_last_regenerate|i:1750875305;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('e6bcfa9fad5cf1a113e433fa1bc61995a5c25914','82.29.165.22',1750924807,'__ci_last_regenerate|i:1750924802;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('e6f36436bc06ca2a7867489a67f847881e4b3d59','2a02:4780:12:bfc5::1',1751063402,'__ci_last_regenerate|i:1751063402;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('e71ca8f3b8d03adf799c456494918c13ccfb9a96','2a02:4780:12:bfc5::1',1751100607,'__ci_last_regenerate|i:1751100602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('e727096af32020975a0aebbb8bc7d043b87a4028','2a02:4780:12:bfc5::1',1751139602,'__ci_last_regenerate|i:1751139601;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('e74a057aeb00661b942ba8e93eee5465f06ff820','2a02:4780:12:bfc5::1',1751035502,'__ci_last_regenerate|i:1751035502;'),
('e74ed00042622cc93341e5789d12d7f59fe96a8b','127.0.0.1',1750990607,'__ci_last_regenerate|i:1750990607;red_url|s:21:\"https://82.29.165.22/\";'),
('e75681c150d85235d48e2cd4494cca7d2013c30a','82.29.165.22',1750975502,'__ci_last_regenerate|i:1750975502;'),
('e781dfb751426168237ce32c3de4c2c54d779419','2a02:4780:12:bfc5::1',1751157301,'__ci_last_regenerate|i:1751157301;'),
('e7bfe60eabb1a0bc86af384503ea6d9522378acb','2a02:4780:12:bfc5::1',1751025003,'__ci_last_regenerate|i:1751025002;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('e7e2612a7832ce47a4afb86829ea7a812e3ea3e6','127.0.0.1',1750927910,'__ci_last_regenerate|i:1750927910;red_url|s:21:\"https://82.29.165.22/\";'),
('e7e6d09778fe2a36260325f008117bd1d6a27723','82.29.165.22',1750854601,'__ci_last_regenerate|i:1750854601;'),
('e80bec9ed834fb75fe750866fa82dcce274519f3','127.0.0.1',1750893009,'__ci_last_regenerate|i:1750893009;red_url|s:21:\"https://82.29.165.22/\";'),
('e81c3cf615dd135575f0b49d512aa3bd3fda6221','127.0.0.1',1750898104,'__ci_last_regenerate|i:1750898104;red_url|s:21:\"https://82.29.165.22/\";'),
('e85840723f988bc39d629586451dde0e59581a23','82.29.165.22',1750980902,'__ci_last_regenerate|i:1750980902;'),
('e8813378b8a0a307bc8e2ae9fa8135c9c523855e','82.29.165.22',1750971303,'__ci_last_regenerate|i:1750971301;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('e8c8deef108c359c1345735b826fda60503afe00','2a02:4780:12:bfc5::1',1751064302,'__ci_last_regenerate|i:1751064302;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('e8d7a11803567b28b8769000f35292b222b992e0','2a02:4780:12:bfc5::1',1751092802,'__ci_last_regenerate|i:1751092801;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('e937f852a1c2c0bc1ea845208a4e70b330e35f96','82.29.165.22',1750939501,'__ci_last_regenerate|i:1750939501;'),
('e990ae3701b5326e03ad796e654f5f882affcea2','127.0.0.1',1750881110,'__ci_last_regenerate|i:1750881109;red_url|s:21:\"https://82.29.165.22/\";'),
('e9bd6aac7b4ff03cfe3d9c243eb86ab2db526c3d','127.0.0.1',1750986609,'__ci_last_regenerate|i:1750986609;red_url|s:21:\"https://82.29.165.22/\";'),
('ea13ca894a845e95ca899f93dc2b08733ad8ae07','127.0.0.1',1750979807,'__ci_last_regenerate|i:1750979807;red_url|s:21:\"https://82.29.165.22/\";'),
('ea48630c64c88062b99e320ad3caeed8187357a9','82.29.165.22',1750875601,'__ci_last_regenerate|i:1750875601;'),
('ea746144ce34dcdde55f72884bf0997feb16838d','2a02:4780:12:bfc5::1',1751015701,'__ci_last_regenerate|i:1751015701;'),
('eaafe49c97ab0bb185b52f1129c8605298197e3b','2a02:4780:12:bfc5::1',1751163901,'__ci_last_regenerate|i:1751163901;'),
('eab616fa7f410f38e7240c79a0aa50feb64bdd7d','82.29.165.22',1750992003,'__ci_last_regenerate|i:1750992002;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('eabe94b40a214230ff826480e3b0c20ec5e54f51','2409:40d4:10cd:43f8:f408:13f9:e02c:5190',1751021129,'__ci_last_regenerate|i:1751021126;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('ead4280935071d03717b0dc72dfcd0c54a34629b','2a02:4780:12:bfc5::1',1751151302,'__ci_last_regenerate|i:1751151302;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('eb3972663eba7d92ec1cfbfb065c81a5c6f43821','2a02:4780:12:bfc5::1',1751165102,'__ci_last_regenerate|i:1751165102;'),
('eb531a4d48b669872dccedae6c72f0562d73953e','2a02:4780:12:bfc5::1',1751140202,'__ci_last_regenerate|i:1751140201;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('eba69500ae3e2120b6014fc9452d93b2f5912604','82.29.165.22',1750981203,'__ci_last_regenerate|i:1750981201;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('ebb55c1a138e470a5d76be3ce0e2b888bf66e545','82.29.165.22',1750892404,'__ci_last_regenerate|i:1750892404;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('ebc3cdf222972df1e452f58f40f2fb5a19af6e95','2a02:4780:12:bfc5::1',1751001901,'__ci_last_regenerate|i:1751001901;'),
('ebd2eb58861ba7ced4df2ce46f193ffc4b4b34b4','127.0.0.1',1750949510,'__ci_last_regenerate|i:1750949509;red_url|s:21:\"https://82.29.165.22/\";'),
('ebde6767d14808738a7ed070a03414e18ab67a39','2a02:4780:12:bfc5::1',1751016603,'__ci_last_regenerate|i:1751016602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('ebedd18c6be6163fc16ed8c6ec89283a621e29a5','127.0.0.1',1750940510,'__ci_last_regenerate|i:1750940510;red_url|s:21:\"https://82.29.165.22/\";'),
('ebf3e265bb03e531606c1ae7d010745264d7c5fd','127.0.0.1',1750867205,'__ci_last_regenerate|i:1750867204;red_url|s:21:\"https://82.29.165.22/\";'),
('ebfa76e22649f45ac6e413efc7aae06bbb8c0203','82.29.165.22',1750946102,'__ci_last_regenerate|i:1750946102;'),
('ec337475397f2e4a8e0538e220298bda5d9fff0c','2a02:4780:12:bfc5::1',1751028302,'__ci_last_regenerate|i:1751028302;'),
('ec5476750091e26385d1d275f7b718ccaae9b70b','2a02:4780:12:bfc5::1',1751005203,'__ci_last_regenerate|i:1751005202;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('ec6d725562adda4b7dec9a2cdc17008e9ffc0ce5','82.29.165.22',1750989901,'__ci_last_regenerate|i:1750989901;'),
('ec89e75e745182376e862d1f2943235c81e8025d','127.0.0.1',1750860306,'__ci_last_regenerate|i:1750860306;red_url|s:21:\"https://82.29.165.22/\";'),
('eca63d4ca8b352f7871fb05209932da1034980be','157.48.82.220',1750924034,'__ci_last_regenerate|i:1750924034;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"old\";}'),
('eccc9a5620a3e5e8bb08725eb2937e2b3e9e617a','82.29.165.22',1750854302,'__ci_last_regenerate|i:1750854301;'),
('ecea7de87d7c33f21d15970f24fa68b67922886c','34.222.24.232',1751013497,'__ci_last_regenerate|i:1751013490;is_mobile|b:1;red_url|s:39:\"https://techdotbit.in/clients?companies\";'),
('ecf2d965fa342d4aa16cea66e14fd8f0b61055a8','2a02:247a:26d:1000::1',1751067024,'__ci_last_regenerate|i:1751067024;red_url|s:22:\"https://techdotbit.in/\";'),
('ed48d54294b087be34da7b29f2b6a28eaf6ed7f9','82.29.165.22',1750888501,'__ci_last_regenerate|i:1750888501;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('ed997e232c4388d016f6cf3e2dde24baf4b250f9','82.29.165.22',1750856402,'__ci_last_regenerate|i:1750856402;'),
('ed9e00cd717ea616725d505aab1c1dc0593ccf6a','82.29.165.22',1750986301,'__ci_last_regenerate|i:1750986301;'),
('eda744ae0f7dcf43097d667fa2362700d654269e','82.29.165.22',1750962904,'__ci_last_regenerate|i:1750962901;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('edad24edd7dd48f841d1145e3e37e98ca16dff89','127.0.0.1',1750924390,'__ci_last_regenerate|i:1750924390;red_url|s:21:\"https://82.29.165.22/\";'),
('ede8f3f07a497af8f28ce5563622be696682f69c','2a02:4780:12:bfc5::1',1751032502,'__ci_last_regenerate|i:1751032502;'),
('ee6b7697280dd027d0607d0b942373dbee54e50c','2a02:4780:12:bfc5::1',1751170202,'__ci_last_regenerate|i:1751170202;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('eea07358b98ff22e3f527d6b0762397542a29c16','2a02:4780:12:bfc5::1',1751160902,'__ci_last_regenerate|i:1751160902;'),
('eece5995083352d187cf9d74ec36a9b2a2e77f39','2409:40d4:10cd:43f8:ccef:f512:e762:56b2',1751109562,'__ci_last_regenerate|i:1751109556;staff_user_id|s:1:\"1\";staff_logged_in|b:1;red_url|s:39:\"https://techdotbit.in/clients?companies\";setup-menu-open|s:0:\"\";message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('ef32e5ce5d5578b8f3f3c77eb458cdd3acaf4c6e','2a02:4780:12:bfc5::1',1751007002,'__ci_last_regenerate|i:1751007002;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('ef7ee2c1c296202d80070c934c70375b3c5bf66f','127.0.0.1',1750870310,'__ci_last_regenerate|i:1750870310;red_url|s:21:\"https://82.29.165.22/\";'),
('ef8f73f79b117caaea0668b315707cba06336bc5','2a02:4780:12:bfc5::1',1751030702,'__ci_last_regenerate|i:1751030702;'),
('efe107af03b32715bf2b4dc245d041a0f631b64a','2409:40d4:10cd:43f8:ccef:f512:e762:56b2',1751080641,'__ci_last_regenerate|i:1751080641;staff_user_id|s:1:\"1\";staff_logged_in|b:1;red_url|s:39:\"https://techdotbit.in/clients?companies\";setup-menu-open|b:1;message-danger|s:0:\"\";__ci_vars|a:2:{s:14:\"message-danger\";s:3:\"old\";s:5:\"debug\";s:3:\"new\";}debug|s:1074:\"<h1>Your SMTP settings are not set correctly here is the debug log.</h1><br />SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/TroubleshootingSMTP server error: Failed to connect to server<br /><pre>\n\n</pre>Connection: opening to ssl://smtp.hostinger.com:465, timeout=30, options=array()<br />Connection failed. Error #2: stream_socket_client(): Peer certificate CN=`autoconfig.srv810535.hstgr.cloud\' did not match expected CN=`smtp.hostinger.com\' [/var/www/techdotbit.in/application/vendor/phpmailer/phpmailer/src/SMTP.php line 389]<br />Connection failed. Error #2: stream_socket_client(): Failed to enable crypto [/var/www/techdotbit.in/application/vendor/phpmailer/phpmailer/src/SMTP.php line 389]<br />Connection failed. Error #2: stream_socket_client(): Unable to connect to ssl://smtp.hostinger.com:465 (Unknown error) [/var/www/techdotbit.in/application/vendor/phpmailer/phpmailer/src/SMTP.php line 389]<br />SMTP ERROR: Failed to connect to server:  (0)<br />SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting<br />\";'),
('efe47831c61022e4336d10ff9597cdf8d60cc54d','127.0.0.1',1750909607,'__ci_last_regenerate|i:1750909607;red_url|s:21:\"https://82.29.165.22/\";'),
('efe618a93e1608aa5169c593881ecc70466b3f26','2a02:4780:12:bfc5::1',1751040603,'__ci_last_regenerate|i:1751040602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('eff5bc8088439c62494af922150f5f0810c3c257','2a02:4780:12:bfc5::1',1751130004,'__ci_last_regenerate|i:1751130003;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('f06707188e8bb9355431daa58b53c1bd3142c8ba','2a02:4780:12:bfc5::1',1751105402,'__ci_last_regenerate|i:1751105401;'),
('f0a8f05f6ce06634d50ad73000a0078b7643ffab','127.0.0.1',1750933007,'__ci_last_regenerate|i:1750933007;red_url|s:21:\"https://82.29.165.22/\";'),
('f0b3f368c432a6317ccdbed7f026c76d3b07599f','2a02:4780:12:bfc5::1',1751022602,'__ci_last_regenerate|i:1751022602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('f0c8bec3f2ce60b570620b2de56f92c72fa5eb27','127.0.0.1',1750856706,'__ci_last_regenerate|i:1750856706;red_url|s:21:\"https://82.29.165.22/\";'),
('f0daca94d4de08bee248e725a50d9baeacddff59','45.79.134.200',1750929855,'__ci_last_regenerate|i:1750929855;red_url|s:21:\"https://82.29.165.22/\";'),
('f0f28e30974f498d34ad6455c8fcf5feb3c8deb1','2409:40d4:10cd:43f8:f408:13f9:e02c:5190',1751010452,'__ci_last_regenerate|i:1751010452;red_url|s:39:\"https://techdotbit.in/clients?companies\";client_user_id|s:1:\"4\";contact_user_id|s:1:\"4\";client_logged_in|b:1;perfex_saas_enable_auto_trial|s:1:\"0\";'),
('f0fb0cb835a0865ddcd982c97f0cd3bb8aaff138','2a02:4780:12:bfc5::1',1751129102,'__ci_last_regenerate|i:1751129102;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('f11029a21da32da17e1b6fa92ea93cd613ed8bdf','2409:40d4:10cd:43f8:f408:13f9:e02c:5190',1751018413,'__ci_last_regenerate|i:1751018413;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('f13b1b3441098e14cd2d501409d3dff0887a0778','2a02:4780:12:bfc5::1',1751067902,'__ci_last_regenerate|i:1751067902;'),
('f14d4162eafbc0b7970882f6f9295727de77f8ae','2a02:4780:12:bfc5::1',1751048702,'__ci_last_regenerate|i:1751048702;'),
('f16a9bd48fd51742c4a47bb1486d5afc8f68929a','2a02:4780:12:bfc5::1',1751147702,'__ci_last_regenerate|i:1751147702;'),
('f19f5d19b72592acbd45627de30d560636082639','82.29.165.22',1750875902,'__ci_last_regenerate|i:1750875901;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('f1ca863442f6cad5f7833664f0cfe4408bd4fbda','82.29.165.22',1750966502,'__ci_last_regenerate|i:1750966502;'),
('f1cdc691e41266f3eebf7cba5043fc786e09bbdd','45.135.193.162',1750884426,'__ci_last_regenerate|i:1750884426;red_url|s:21:\"https://82.29.165.22/\";'),
('f1e091e0323d53bd8f63ab69d5782abb30a086fd','206.168.34.41',1750978248,'__ci_last_regenerate|i:1750978248;'),
('f1f0f10b2cbccae314143dab4064f49304363fc3','82.29.165.22',1750851902,'__ci_last_regenerate|i:1750851902;'),
('f210080d8179cce32c5f321e49a953d05f3d3a5d','82.29.165.22',1750961101,'__ci_last_regenerate|i:1750961101;'),
('f2301708a0c70482f0aec33e8ff12b4fb7434568','2a02:4780:12:bfc5::1',1751117403,'__ci_last_regenerate|i:1751117402;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('f26a044515bc7a15792db8bdd94d7dc818eb720d','127.0.0.1',1750976509,'__ci_last_regenerate|i:1750976509;red_url|s:21:\"https://82.29.165.22/\";'),
('f28295ceaf25c19ab3b199e8db0b72d2d51e54f8','82.29.165.22',1750856101,'__ci_last_regenerate|i:1750856101;'),
('f2994c4386eccc990844940bb04856a79addf39c','2409:40d4:10cd:43f8:f408:13f9:e02c:5190',1751002027,'__ci_last_regenerate|i:1751002027;red_url|s:39:\"https://techdotbit.in/clients?companies\";'),
('f2c611a674b4fc620ef10dbe0b5a7789a8ce3c5c','2409:40d4:10cd:43f8:ccef:f512:e762:56b2',1751094648,'__ci_last_regenerate|i:1751094648;staff_user_id|s:1:\"1\";staff_logged_in|b:1;red_url|s:39:\"https://techdotbit.in/clients?companies\";setup-menu-open|b:1;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('f2d02a5391e87334e2609e7fa42f3967527b8054','2a02:4780:12:bfc5::1',1751091902,'__ci_last_regenerate|i:1751091902;'),
('f2f8dd0720706d880976d824ac9f96ec120389ac','127.0.0.1',1750999010,'__ci_last_regenerate|i:1750999010;red_url|s:21:\"https://82.29.165.22/\";'),
('f30a9f4767129f52a8f74a8d535644a5fa8e45ec','2a02:4780:12:bfc5::1',1751160602,'__ci_last_regenerate|i:1751160602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('f30e17a797c79c28eb56087d721cb23f0818a8f4','82.29.165.22',1750993206,'__ci_last_regenerate|i:1750993202;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('f30efcbe0f9149a195c96fce20285e63821eeb7d','157.48.221.10',1750998212,'__ci_last_regenerate|i:1750998212;staff_user_id|s:1:\"1\";staff_logged_in|b:1;red_url|s:38:\"https://82.29.165.22/clients?companies\";'),
('f341eb517351adda99588a0175f4cf8bdefb6739','82.29.165.22',1750956903,'__ci_last_regenerate|i:1750956901;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('f3494cf5803ba37936d166d7fa3dcc7c56855ff5','127.0.0.1',1750973507,'__ci_last_regenerate|i:1750973507;red_url|s:21:\"https://82.29.165.22/\";'),
('f3a038cd34b8712febf80a1f0b84e2844a9e386a','2a02:4780:12:bfc5::1',1751050202,'__ci_last_regenerate|i:1751050202;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('f42b52262aaac615801b524700d7d985451ec540','82.29.165.22',1750910701,'__ci_last_regenerate|i:1750910701;'),
('f42fa3b41ee0580e555c315990a65e09acaf5d3f','82.29.165.22',1750907101,'__ci_last_regenerate|i:1750907101;'),
('f483cc32115546e95432ba51281c16f27b9f8b32','127.0.0.1',1750947106,'__ci_last_regenerate|i:1750947106;red_url|s:21:\"https://82.29.165.22/\";'),
('f48dc6ee60dd058dd34a5e7a66cb1d86d7406791','2409:40d4:10cd:43f8:f408:13f9:e02c:5190',1751002329,'__ci_last_regenerate|i:1751002329;client_user_id|s:1:\"2\";contact_user_id|s:1:\"2\";client_logged_in|b:1;perfex_saas_enable_auto_trial|s:1:\"0\";red_url|s:27:\"https://techdotbit.in/admin\";'),
('f49f163c5f17d15726e69f5f2d476f099cbe0d09','82.29.165.22',1750854001,'__ci_last_regenerate|i:1750854001;'),
('f4ad8b2443498a20f8fb4ba30533c304d32d14dd','2409:40d4:10cd:43f8:f408:13f9:e02c:5190',1751007553,'__ci_last_regenerate|i:1751007553;perfex_saas_enable_auto_trial|s:1:\"0\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";client_user_id|s:1:\"2\";contact_user_id|s:1:\"2\";client_logged_in|b:1;'),
('f51bdc6a9fe5ab19d18c3b4001137c5333e884cd','82.29.165.22',1750942801,'__ci_last_regenerate|i:1750942801;'),
('f54010e0002cf9bfb8c68c98d5efcd0b65f1a14c','2a02:4780:12:bfc5::1',1751167502,'__ci_last_regenerate|i:1751167501;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('f55b7b3fccae46137d726f3b73e5256460c3f692','2a02:4780:12:bfc5::1',1751109602,'__ci_last_regenerate|i:1751109602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('f56242f214ec889cd9fee2962ef0d31a94d1c8ca','82.29.165.22',1750870803,'__ci_last_regenerate|i:1750870802;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('f5957d07cfda401ec5c7be755ba8eb33c1e53b01','127.0.0.1',1750848477,'__ci_last_regenerate|i:1750848477;red_url|s:21:\"https://82.29.165.22/\";'),
('f5a24dcddc45a33ba49b0c5548885dfa5a1b9e14','45.135.193.162',1750884424,'__ci_last_regenerate|i:1750884423;red_url|s:21:\"https://82.29.165.22/\";'),
('f5a524c3896797c09b4b5c57ac24e920a6ea1e8d','157.48.80.182',1750899040,'__ci_last_regenerate|i:1750899040;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";ps_slug|s:6:\"fecuni\";ps_plan|s:12:\"starter-plan\";red_url|s:38:\"https://82.29.165.22/clients?companies\";ps_custom_domain|s:6:\"fecuni\";message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"old\";}'),
('f5ce0fc397ceee89d1c4f1d5e8afa7280727e591','82.29.165.22',1750940101,'__ci_last_regenerate|i:1750940101;'),
('f5fc9fc89ae78c0f46304864697a13072e97d391','2409:40d4:10cd:43f8:f408:13f9:e02c:5190',1751003399,'__ci_last_regenerate|i:1751003399;perfex_saas_enable_auto_trial|s:1:\"0\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;red_url|s:39:\"https://techdotbit.in/clients?companies\";message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"old\";}'),
('f617d87426a98c514fcb578af77fcc197b6fce59','2a02:4780:12:bfc5::1',1751037002,'__ci_last_regenerate|i:1751037002;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('f625dc4af1dbe5762aa8b5f3960637f740eaffe2','82.29.165.22',1750935902,'__ci_last_regenerate|i:1750935901;'),
('f62d97907c209b030197875e4348ba65c140fc38','82.29.165.22',1750898102,'__ci_last_regenerate|i:1750898101;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('f62e76b3907c8f45abf3dba848e590e2da193fab','2a02:4780:12:bfc5::1',1751106903,'__ci_last_regenerate|i:1751106902;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('f6831a0159b438508b530fa4565f5f8576278088','82.29.165.22',1750881901,'__ci_last_regenerate|i:1750881901;'),
('f6b59303adb26bcddbe00c0f0a72c7dbf4f27d78','82.29.165.22',1750994701,'__ci_last_regenerate|i:1750994701;'),
('f6bfa781a62480f2676688e7f00b986d64674331','82.29.165.22',1750948201,'__ci_last_regenerate|i:1750948201;'),
('f6f0fb1d3d2f07b0c3120d839c98f42c485355e5','82.29.165.22',1750875302,'__ci_last_regenerate|i:1750875302;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('f730e200c01bc5c7b9b8792ee91f2ac5cefb0e2a','2001:bc8:1201:1d:ba2a:72ff:fee1:1d32',1751060353,'__ci_last_regenerate|i:1751060353;'),
('f73c2eaa617d5a6d9533f405db86b8c487ce2aed','2409:40d4:10cd:43f8:ccef:f512:e762:56b2',1751168022,'__ci_last_regenerate|i:1751168022;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;red_url|s:39:\"https://techdotbit.in/clients?companies\";'),
('f746bf962e94122f67e79916bfd2ef864ef696e6','127.0.0.1',1750914699,'__ci_last_regenerate|i:1750914699;red_url|s:21:\"https://82.29.165.22/\";'),
('f774015b808d4b4fd50f7cb77b25064dfe4319ee','2a02:4780:12:bfc5::1',1751159402,'__ci_last_regenerate|i:1751159402;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('f7775bf07e24e84089c1df2ecb387193c4659b71','2409:40d4:10cd:43f8:f408:13f9:e02c:5190',1751005072,'__ci_last_regenerate|i:1751005072;perfex_saas_enable_auto_trial|s:1:\"0\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";client_user_id|s:1:\"2\";contact_user_id|s:1:\"2\";client_logged_in|b:1;'),
('f7a2b8481b44d454e5df20d52086ccc1383e3b23','127.0.0.1',1750956407,'__ci_last_regenerate|i:1750956407;red_url|s:21:\"https://82.29.165.22/\";'),
('f855917e744617a27421277ee1c4586d87ae0fc5','127.0.0.1',1750954978,'__ci_last_regenerate|i:1750954978;red_url|s:21:\"https://82.29.165.22/\";'),
('f8aa6837cbf281328098b8b5598d65355295fa23','2a02:4780:12:bfc5::1',1751119802,'__ci_last_regenerate|i:1751119802;'),
('f8b3ee1a7354e75775178e820fe257d7f7bd1f16','127.0.0.1',1750961411,'__ci_last_regenerate|i:1750961411;red_url|s:21:\"https://82.29.165.22/\";'),
('f8e16cf2793ad93a4fa2af8e7f11fbc270533f8e','205.169.39.171',1751099374,'__ci_last_regenerate|i:1751099374;red_url|s:22:\"https://techdotbit.in/\";'),
('f8f0e855890c94d0deb813188a456365e0bee44c','2a02:4780:12:bfc5::1',1751162702,'__ci_last_regenerate|i:1751162702;'),
('f93dcf5fa6c695f0b8a893f5085eaa9c25a7849b','127.0.0.1',1750858610,'__ci_last_regenerate|i:1750858610;red_url|s:21:\"https://82.29.165.22/\";'),
('f945abd6fdcbdb63dc34a54d53812cb63e0c2f6d','2a02:4780:12:bfc5::1',1751076003,'__ci_last_regenerate|i:1751076002;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('f9632875f2a191377bd3be835a4b000a2b231db5','2a02:4780:12:bfc5::1',1751043902,'__ci_last_regenerate|i:1751043902;'),
('f9800401b102e36a4ae206449a57e779d3f10ba0','82.29.165.22',1750919103,'__ci_last_regenerate|i:1750919102;'),
('f9c8471b540f6faff41f7a4de87186bf19e93698','2a02:4780:12:bfc5::1',1751021402,'__ci_last_regenerate|i:1751021402;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('f9cff807d7e6fa07448dd9e218730863e7956f35','82.29.165.22',1750862401,'__ci_last_regenerate|i:1750862401;'),
('f9e3256007dba59f39c10a18d9718a11197412cf','82.29.165.22',1750880701,'__ci_last_regenerate|i:1750880701;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('f9ea4af34a888d58471a15101bf26b621ed7fb5a','82.29.165.22',1750914301,'__ci_last_regenerate|i:1750914301;'),
('f9f3860099baa6e0a042189a82cb9c682ad8daa5','127.0.0.1',1750855010,'__ci_last_regenerate|i:1750855010;red_url|s:21:\"https://82.29.165.22/\";'),
('fa024495fa260df0eaa0a905d3a6669e8fc1e186','2a02:4780:12:bfc5::1',1751139902,'__ci_last_regenerate|i:1751139902;'),
('fa32424fbff703b68347264a88f4903987f5b8cc','2a02:4780:12:bfc5::1',1751037901,'__ci_last_regenerate|i:1751037901;'),
('fa8350a8f010ba7315975674d68332742d24da6f','2409:40d4:10cd:43f8:f408:13f9:e02c:5190',1751020334,'__ci_last_regenerate|i:1751020334;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;message-danger|s:0:\"\";__ci_vars|a:2:{s:14:\"message-danger\";s:3:\"old\";s:5:\"debug\";s:3:\"new\";}debug|s:1765:\"<h1>Your SMTP settings are not set correctly here is the debug log.</h1><br />SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/TroubleshootingSMTP server error: QUIT command failed Detail: r�mƬl��/���6���221 srv810535.hstgr.cloud closing connection\r\n<br /><pre>\n\n</pre>Connection: opening to smtp.hostinger.com:587, timeout=30, options=array()<br />Connection: opened<br />SERVER -> CLIENT: 220-srv810535.hstgr.cloud ESMTP Exim 4.98.1 #2 Fri, 27 Jun 2025 10:32:13 +0000 \r\n220-We do not authorize the use of this system to transport unsolicited, \r\n220 and/or bulk e-mail.\r\n<br />CLIENT -> SERVER: EHLO techdotbit.in\r\n<br />SERVER -> CLIENT: 250-srv810535.hstgr.cloud Hello techdotbit.in [2a02:4780:12:bfc5::1]\r\n250-SIZE 52428800\r\n250-LIMITS MAILMAX=1000 RCPTMAX=50000\r\n250-8BITMIME\r\n250-PIPELINING\r\n250-PIPECONNECT\r\n250-AUTH PLAIN LOGIN\r\n250-STARTTLS\r\n250 HELP\r\n<br />CLIENT -> SERVER: STARTTLS\r\n<br />SERVER -> CLIENT: 220 TLS go ahead\r\n<br />Connection failed. Error #2: stream_socket_enable_crypto(): Peer certificate CN=`autoconfig.srv810535.hstgr.cloud\' did not match expected CN=`smtp.hostinger.com\' [/var/www/techdotbit.in/application/vendor/phpmailer/phpmailer/src/SMTP.php line 468]<br />SMTP Error: Could not connect to SMTP host. Connection failed. stream_socket_enable_crypto(): Peer certificate CN=`autoconfig.srv810535.hstgr.cloud\' did not match expected CN=`smtp.hostinger.com\'<br />CLIENT -> SERVER: QUIT\r\n<br />SERVER -> CLIENT: \0r�mƬl��/���6���221 srv810535.hstgr.cloud closing connection\r\n<br />SMTP ERROR: QUIT command failed: \0r�mƬl��/���6���221 srv810535.hstgr.cloud closing connection\r\n<br />Connection: closed<br />SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting<br />\";'),
('fa887c85cd1ed85714172f273f81efc36d21667b','2a02:4780:12:bfc5::1',1751061902,'__ci_last_regenerate|i:1751061902;'),
('fac358339e8d237e5a0bafd80005395a47625b05','127.0.0.1',1750994510,'__ci_last_regenerate|i:1750994509;red_url|s:21:\"https://82.29.165.22/\";'),
('fb56f689b1a1abc8fefc56fd58204a5f280a1164','127.0.0.1',1750904337,'__ci_last_regenerate|i:1750904337;red_url|s:21:\"https://82.29.165.22/\";'),
('fb5ea4c285dfbf21754413cae65bfee45448e1a1','127.0.0.1',1750908788,'__ci_last_regenerate|i:1750908788;red_url|s:21:\"https://82.29.165.22/\";'),
('fb84b48002b4151810c71f7f2be546e477ca7cae','2a02:4780:12:bfc5::1',1751067002,'__ci_last_regenerate|i:1751067002;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('fb8501ab4faabe803c70cdc29830c1ee2001ec1b','45.135.193.162',1750884426,'__ci_last_regenerate|i:1750884426;red_url|s:21:\"https://82.29.165.22/\";'),
('fb8e49f50d99d57ef31f2b0412f64516c8eab438','2a02:4780:12:bfc5::1',1751034301,'__ci_last_regenerate|i:1751034301;'),
('fbd60ffad191d1bcc679a9cabd660ed89ee706ad','2a02:4780:12:bfc5::1',1751054102,'__ci_last_regenerate|i:1751054101;'),
('fbe9d285bbf1dff10de9a3e843152bee08ff3d2a','2a02:4780:12:bfc5::1',1751078102,'__ci_last_regenerate|i:1751078102;'),
('fbeb4621c6277e3c669cdc6adc0b42a1835ad93e','82.29.165.22',1750877701,'__ci_last_regenerate|i:1750877701;'),
('fc2cb3d155af96f3cf16a12125fae49de954ff59','2409:40d4:10cd:43f8:f408:13f9:e02c:5190',1751005444,'__ci_last_regenerate|i:1751005444;perfex_saas_enable_auto_trial|s:1:\"0\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";client_user_id|s:1:\"2\";contact_user_id|s:1:\"2\";client_logged_in|b:1;'),
('fc6c6305d96340c69bd5f01919481dfbcfaf0681','82.29.165.22',1750948503,'__ci_last_regenerate|i:1750948501;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('fc718317df65708dd1b8c6bb60e25be2c0131d3d','82.29.165.22',1750962303,'__ci_last_regenerate|i:1750962301;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('fcab8ff90592b99f8c142006bdf75b82a74498fc','2a02:4780:12:bfc5::1',1751125502,'__ci_last_regenerate|i:1751125502;'),
('fcb412b98a9b520f1c5cf5e9e5c1ed38d41db5a5','2a02:4780:12:bfc5::1',1751169603,'__ci_last_regenerate|i:1751169602;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('fccffa7e2b40797b41589ed646cd5fbe87e1d149','2a02:4780:12:bfc5::1',1751118001,'__ci_last_regenerate|i:1751118001;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('fd44958d6b8c6f72764a4646c73a81b4c8cfdf48','2a02:4780:12:bfc5::1',1751131202,'__ci_last_regenerate|i:1751131202;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('fd4aedee67267296bc7c80654d63e36114b62567','82.29.165.22',1750938005,'__ci_last_regenerate|i:1750938002;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('fd6f6077bb479bad68c36b5d770fab5bf4eb2254','2a02:4780:12:bfc5::1',1751010902,'__ci_last_regenerate|i:1751010902;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('fd85c91978c39a38f57dcc65c9457aebfb88dfb4','104.164.173.195',1751172979,'__ci_last_regenerate|i:1751172978;red_url|s:22:\"https://techdotbit.in/\";'),
('fdef052b8e91be3adf3c33aaec56f0d54f7f89ea','127.0.0.1',1750931510,'__ci_last_regenerate|i:1750931510;red_url|s:21:\"https://82.29.165.22/\";'),
('fdefc444e4e4008dbfae02b25cc260792a42f0b7','2a02:4780:12:bfc5::1',1751025301,'__ci_last_regenerate|i:1751025301;'),
('fe1efb35b09c5bf1a6153e164f4ba215bd4e4e62','2a02:4780:12:bfc5::1',1751075402,'__ci_last_regenerate|i:1751075402;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('fe8c8cd3255bd2de894f900d63ebc69c74fb0596','2a02:4780:12:bfc5::1',1751045403,'__ci_last_regenerate|i:1751045403;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),
('feb6d3f3de6e75abdb87ff90b7ecdab9a57ab45a','127.0.0.1',1750985510,'__ci_last_regenerate|i:1750985509;red_url|s:21:\"https://82.29.165.22/\";'),
('ff9727b85f5097e6981e4948b46956e3bedfcd02','82.29.165.22',1750852802,'__ci_last_regenerate|i:1750852801;'),
('ffe9d093a3a6403c1a029966552bc97dbd30a6c4','127.0.0.1',1750886275,'__ci_last_regenerate|i:1750886275;red_url|s:21:\"https://82.29.165.22/\";'),
('ifqi122hdpvldosd7jp5e1ui0li80l1d','2405:201:4018:225d:9952:89b6:f4e2:c984',1751368588,'__ci_last_regenerate|i:1751368587;client_user_id|s:1:\"4\";contact_user_id|s:1:\"4\";client_logged_in|b:1;'),
('lhb16v5ce7cb5kaarj4pmop5lnltncn9','223.196.13.4',1751370984,'__ci_last_regenerate|i:1751370984;'),
('s6mmr11mq4muj6hp3estaehtps0346bb','49.205.94.165',1751370771,'__ci_last_regenerate|i:1751370760;red_url|s:39:\"https://techdotbit.in/clients?companies\";'),
('taam7b6lvrgqjgjt8v5irsg9op8ngfnv','2405:201:4018:225d:25a3:777b:1fb8:f323',1751371176,'__ci_last_regenerate|i:1751371176;red_url|s:27:\"https://techdotbit.in/admin\";ps_plan|s:12:\"starter-plan\";ps_slug|s:4:\"tata\";client_user_id|s:1:\"5\";contact_user_id|s:1:\"5\";client_logged_in|b:1;'),
('ugscalgpuhb0k574hlg03gguu0044bh5','130.89.144.162',1751366654,'__ci_last_regenerate|i:1751366654;'),
('ul0akrhb7beda0r6sevqegdag0v0179f','2405:201:4018:225d:9952:89b6:f4e2:c984',1751368587,'__ci_last_regenerate|i:1751368587;client_user_id|s:1:\"4\";contact_user_id|s:1:\"4\";client_logged_in|b:1;'),
('v82u8um17n792791kfj4jmgj6bljb7v7','2405:201:4018:225d:25a3:777b:1fb8:f323',1751371192,'__ci_last_regenerate|i:1751371176;red_url|s:27:\"https://techdotbit.in/admin\";client_user_id|s:1:\"5\";contact_user_id|s:1:\"5\";client_logged_in|b:1;perfex_saas_enable_auto_trial|s:1:\"0\";');
/*!40000 ALTER TABLE `tblsessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblsetting_asset_allocation`
--

DROP TABLE IF EXISTS `tblsetting_asset_allocation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblsetting_asset_allocation` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) DEFAULT NULL,
  `meta` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblsetting_asset_allocation`
--

LOCK TABLES `tblsetting_asset_allocation` WRITE;
/*!40000 ALTER TABLE `tblsetting_asset_allocation` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblsetting_asset_allocation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblsetting_training`
--

DROP TABLE IF EXISTS `tblsetting_training`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblsetting_training` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `training_type` int(11) NOT NULL,
  `position_training` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblsetting_training`
--

LOCK TABLES `tblsetting_training` WRITE;
/*!40000 ALTER TABLE `tblsetting_training` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblsetting_training` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblsetting_transfer_records`
--

DROP TABLE IF EXISTS `tblsetting_transfer_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblsetting_transfer_records` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) DEFAULT NULL,
  `meta` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblsetting_transfer_records`
--

LOCK TABLES `tblsetting_transfer_records` WRITE;
/*!40000 ALTER TABLE `tblsetting_transfer_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblsetting_transfer_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblshared_customer_files`
--

DROP TABLE IF EXISTS `tblshared_customer_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblshared_customer_files` (
  `file_id` int(11) NOT NULL,
  `contact_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblshared_customer_files`
--

LOCK TABLES `tblshared_customer_files` WRITE;
/*!40000 ALTER TABLE `tblshared_customer_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblshared_customer_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblshift_type`
--

DROP TABLE IF EXISTS `tblshift_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblshift_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shift_type_name` varchar(150) DEFAULT NULL,
  `color` varchar(50) DEFAULT NULL,
  `time_start` date DEFAULT NULL,
  `time_end` date DEFAULT NULL,
  `time_start_work` varchar(50) DEFAULT NULL,
  `time_end_work` varchar(50) DEFAULT NULL,
  `start_lunch_break_time` varchar(50) DEFAULT NULL,
  `end_lunch_break_time` varchar(50) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblshift_type`
--

LOCK TABLES `tblshift_type` WRITE;
/*!40000 ALTER TABLE `tblshift_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblshift_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblspam_filters`
--

DROP TABLE IF EXISTS `tblspam_filters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblspam_filters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(40) NOT NULL,
  `rel_type` varchar(10) NOT NULL,
  `value` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblspam_filters`
--

LOCK TABLES `tblspam_filters` WRITE;
/*!40000 ALTER TABLE `tblspam_filters` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblspam_filters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblstaff`
--

DROP TABLE IF EXISTS `tblstaff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblstaff` (
  `staffid` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `facebook` longtext DEFAULT NULL,
  `linkedin` longtext DEFAULT NULL,
  `phonenumber` varchar(30) DEFAULT NULL,
  `skype` varchar(50) DEFAULT NULL,
  `password` varchar(250) NOT NULL,
  `datecreated` datetime NOT NULL,
  `profile_image` varchar(191) DEFAULT NULL,
  `last_ip` varchar(40) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_activity` datetime DEFAULT NULL,
  `last_password_change` datetime DEFAULT NULL,
  `new_pass_key` varchar(32) DEFAULT NULL,
  `new_pass_key_requested` datetime DEFAULT NULL,
  `admin` int(11) NOT NULL DEFAULT 0,
  `role` int(11) DEFAULT NULL,
  `active` int(11) NOT NULL DEFAULT 1,
  `default_language` varchar(40) DEFAULT NULL,
  `direction` varchar(3) DEFAULT NULL,
  `media_path_slug` varchar(191) DEFAULT NULL,
  `is_not_staff` int(11) NOT NULL DEFAULT 0,
  `hourly_rate` decimal(15,2) NOT NULL DEFAULT 0.00,
  `two_factor_auth_enabled` tinyint(1) DEFAULT 0,
  `two_factor_auth_code` varchar(100) DEFAULT NULL,
  `two_factor_auth_code_requested` datetime DEFAULT NULL,
  `email_signature` mediumtext DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `birthplace` varchar(200) DEFAULT NULL,
  `sex` varchar(15) DEFAULT NULL,
  `marital_status` varchar(25) DEFAULT NULL,
  `nation` varchar(25) DEFAULT NULL,
  `religion` varchar(50) DEFAULT NULL,
  `identification` varchar(100) DEFAULT NULL,
  `days_for_identity` date DEFAULT NULL,
  `home_town` varchar(200) DEFAULT NULL,
  `resident` varchar(200) DEFAULT NULL,
  `current_address` varchar(200) DEFAULT NULL,
  `literacy` varchar(50) DEFAULT NULL,
  `orther_infor` text DEFAULT NULL,
  `job_position` int(11) DEFAULT NULL,
  `workplace` int(11) DEFAULT NULL,
  `place_of_issue` varchar(50) DEFAULT NULL,
  `account_number` varchar(50) DEFAULT NULL,
  `name_account` varchar(50) DEFAULT NULL,
  `issue_bank` varchar(200) DEFAULT NULL,
  `records_received` longtext DEFAULT NULL,
  `Personal_tax_code` varchar(50) DEFAULT NULL,
  `google_auth_secret` mediumtext DEFAULT NULL,
  `team_manage` int(11) DEFAULT 0,
  `staff_identifi` varchar(200) DEFAULT NULL,
  `status_work` varchar(100) DEFAULT NULL,
  `date_update` date DEFAULT NULL,
  `epf_no` text DEFAULT NULL,
  `social_security_no` text DEFAULT NULL,
  `mail_password` varchar(250) DEFAULT NULL,
  `mail_signature` varchar(250) DEFAULT NULL,
  `last_email_check` varchar(50) DEFAULT NULL,
  `token` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`staffid`),
  KEY `firstname` (`firstname`),
  KEY `lastname` (`lastname`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblstaff`
--

LOCK TABLES `tblstaff` WRITE;
/*!40000 ALTER TABLE `tblstaff` DISABLE KEYS */;
INSERT INTO `tblstaff` VALUES
(1,'info.vikaasyadav@gmail.com','Vikas','Yadav',NULL,NULL,NULL,NULL,'$2a$08$iVdiZvGItuLfkqKIXo3Gt.KwMpmFnO8RvJJS.nB0ABx3NNLI3PxMW','2025-06-25 10:23:49',NULL,'2405:201:4018:225d:9952:89b6:f4e2:c984','2025-07-01 16:37:45','2025-07-01 16:38:08',NULL,NULL,NULL,1,NULL,1,NULL,NULL,NULL,0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `tblstaff` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblstaff_departments`
--

DROP TABLE IF EXISTS `tblstaff_departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblstaff_departments` (
  `staffdepartmentid` int(11) NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `departmentid` int(11) NOT NULL,
  PRIMARY KEY (`staffdepartmentid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblstaff_departments`
--

LOCK TABLES `tblstaff_departments` WRITE;
/*!40000 ALTER TABLE `tblstaff_departments` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblstaff_departments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblstaff_permissions`
--

DROP TABLE IF EXISTS `tblstaff_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblstaff_permissions` (
  `staff_id` int(11) NOT NULL,
  `feature` varchar(40) NOT NULL,
  `capability` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblstaff_permissions`
--

LOCK TABLES `tblstaff_permissions` WRITE;
/*!40000 ALTER TABLE `tblstaff_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblstaff_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblstock_take`
--

DROP TABLE IF EXISTS `tblstock_take`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblstock_take` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `description` text DEFAULT NULL COMMENT 'the reason stock take',
  `warehouse_id` int(11) DEFAULT NULL,
  `date_stock_take` date DEFAULT NULL,
  `stock_take_code` varchar(100) DEFAULT NULL COMMENT 'số kiểm kê kho',
  `date_add` date DEFAULT NULL,
  `hour_add` date DEFAULT NULL,
  `staff_id` varchar(100) DEFAULT NULL,
  `approval` int(11) DEFAULT 0 COMMENT 'status approval ',
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblstock_take`
--

LOCK TABLES `tblstock_take` WRITE;
/*!40000 ALTER TABLE `tblstock_take` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblstock_take` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblstock_take_detail`
--

DROP TABLE IF EXISTS `tblstock_take_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblstock_take_detail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `stock_take_id` int(11) NOT NULL,
  `commodity_code` varchar(100) DEFAULT NULL,
  `commodity_name` text DEFAULT NULL,
  `unit_id` text DEFAULT NULL,
  `unit_price` varchar(100) DEFAULT NULL,
  `quantity_stock_take` varchar(100) DEFAULT NULL,
  `quantity_accounting_book` varchar(100) DEFAULT NULL,
  `quantity_change` varchar(100) DEFAULT NULL,
  `handling` text DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `approval` int(11) DEFAULT 0 COMMENT 'status approval ',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblstock_take_detail`
--

LOCK TABLES `tblstock_take_detail` WRITE;
/*!40000 ALTER TABLE `tblstock_take_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblstock_take_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblsubscriptions`
--

DROP TABLE IF EXISTS `tblsubscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblsubscriptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `description_in_item` tinyint(1) NOT NULL DEFAULT 0,
  `clientid` int(11) NOT NULL,
  `date` date DEFAULT NULL,
  `terms` mediumtext DEFAULT NULL,
  `currency` int(11) NOT NULL,
  `tax_id` int(11) NOT NULL DEFAULT 0,
  `stripe_tax_id` varchar(50) DEFAULT NULL,
  `tax_id_2` int(11) NOT NULL DEFAULT 0,
  `stripe_tax_id_2` varchar(50) DEFAULT NULL,
  `stripe_plan_id` mediumtext DEFAULT NULL,
  `stripe_subscription_id` mediumtext NOT NULL,
  `next_billing_cycle` bigint(20) DEFAULT NULL,
  `ends_at` bigint(20) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `project_id` int(11) NOT NULL DEFAULT 0,
  `hash` varchar(32) NOT NULL,
  `created` datetime NOT NULL,
  `created_from` int(11) NOT NULL,
  `date_subscribed` datetime DEFAULT NULL,
  `in_test_environment` int(11) DEFAULT NULL,
  `last_sent_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `currency` (`currency`),
  KEY `tax_id` (`tax_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblsubscriptions`
--

LOCK TABLES `tblsubscriptions` WRITE;
/*!40000 ALTER TABLE `tblsubscriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblsubscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltaggables`
--

DROP TABLE IF EXISTS `tbltaggables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbltaggables` (
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) NOT NULL,
  `tag_id` int(11) NOT NULL,
  `tag_order` int(11) NOT NULL DEFAULT 0,
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`),
  KEY `tag_id` (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltaggables`
--

LOCK TABLES `tbltaggables` WRITE;
/*!40000 ALTER TABLE `tbltaggables` DISABLE KEYS */;
INSERT INTO `tbltaggables` VALUES
(1,'invoice',1,1);
/*!40000 ALTER TABLE `tbltaggables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltags`
--

DROP TABLE IF EXISTS `tbltags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbltags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltags`
--

LOCK TABLES `tbltags` WRITE;
/*!40000 ALTER TABLE `tbltags` DISABLE KEYS */;
INSERT INTO `tbltags` VALUES
(1,'psaas');
/*!40000 ALTER TABLE `tbltags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltask_assigned`
--

DROP TABLE IF EXISTS `tbltask_assigned`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbltask_assigned` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `taskid` int(11) NOT NULL,
  `assigned_from` int(11) NOT NULL DEFAULT 0,
  `is_assigned_from_contact` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `taskid` (`taskid`),
  KEY `staffid` (`staffid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltask_assigned`
--

LOCK TABLES `tbltask_assigned` WRITE;
/*!40000 ALTER TABLE `tbltask_assigned` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltask_assigned` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltask_checklist_items`
--

DROP TABLE IF EXISTS `tbltask_checklist_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbltask_checklist_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `taskid` int(11) NOT NULL,
  `description` mediumtext NOT NULL,
  `finished` int(11) NOT NULL DEFAULT 0,
  `dateadded` datetime NOT NULL,
  `addedfrom` int(11) NOT NULL,
  `finished_from` int(11) DEFAULT 0,
  `list_order` int(11) NOT NULL DEFAULT 0,
  `assigned` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `taskid` (`taskid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltask_checklist_items`
--

LOCK TABLES `tbltask_checklist_items` WRITE;
/*!40000 ALTER TABLE `tbltask_checklist_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltask_checklist_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltask_comments`
--

DROP TABLE IF EXISTS `tbltask_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbltask_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` mediumtext NOT NULL,
  `taskid` int(11) NOT NULL,
  `staffid` int(11) NOT NULL,
  `contact_id` int(11) NOT NULL DEFAULT 0,
  `file_id` int(11) NOT NULL DEFAULT 0,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `file_id` (`file_id`),
  KEY `taskid` (`taskid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltask_comments`
--

LOCK TABLES `tbltask_comments` WRITE;
/*!40000 ALTER TABLE `tbltask_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltask_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltask_followers`
--

DROP TABLE IF EXISTS `tbltask_followers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbltask_followers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `taskid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltask_followers`
--

LOCK TABLES `tbltask_followers` WRITE;
/*!40000 ALTER TABLE `tbltask_followers` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltask_followers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltasks`
--

DROP TABLE IF EXISTS `tbltasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbltasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  `startdate` date NOT NULL,
  `duedate` date DEFAULT NULL,
  `datefinished` datetime DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `is_added_from_contact` tinyint(1) NOT NULL DEFAULT 0,
  `status` int(11) NOT NULL DEFAULT 0,
  `recurring_type` varchar(10) DEFAULT NULL,
  `repeat_every` int(11) DEFAULT NULL,
  `recurring` int(11) NOT NULL DEFAULT 0,
  `is_recurring_from` int(11) DEFAULT NULL,
  `cycles` int(11) NOT NULL DEFAULT 0,
  `total_cycles` int(11) NOT NULL DEFAULT 0,
  `custom_recurring` tinyint(1) NOT NULL DEFAULT 0,
  `last_recurring_date` date DEFAULT NULL,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(30) DEFAULT NULL,
  `is_public` tinyint(1) NOT NULL DEFAULT 0,
  `billable` tinyint(1) NOT NULL DEFAULT 0,
  `billed` tinyint(1) NOT NULL DEFAULT 0,
  `invoice_id` int(11) NOT NULL DEFAULT 0,
  `hourly_rate` decimal(15,2) NOT NULL DEFAULT 0.00,
  `milestone` int(11) DEFAULT 0,
  `kanban_order` int(11) DEFAULT 1,
  `milestone_order` int(11) NOT NULL DEFAULT 0,
  `visible_to_client` tinyint(1) NOT NULL DEFAULT 0,
  `deadline_notified` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`),
  KEY `milestone` (`milestone`),
  KEY `kanban_order` (`kanban_order`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltasks`
--

LOCK TABLES `tbltasks` WRITE;
/*!40000 ALTER TABLE `tbltasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltasks_checklist_templates`
--

DROP TABLE IF EXISTS `tbltasks_checklist_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbltasks_checklist_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltasks_checklist_templates`
--

LOCK TABLES `tbltasks_checklist_templates` WRITE;
/*!40000 ALTER TABLE `tbltasks_checklist_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltasks_checklist_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltaskstimers`
--

DROP TABLE IF EXISTS `tbltaskstimers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbltaskstimers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) NOT NULL,
  `start_time` varchar(64) NOT NULL,
  `end_time` varchar(64) DEFAULT NULL,
  `staff_id` int(11) NOT NULL,
  `hourly_rate` decimal(15,2) NOT NULL DEFAULT 0.00,
  `note` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `task_id` (`task_id`),
  KEY `staff_id` (`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltaskstimers`
--

LOCK TABLES `tbltaskstimers` WRITE;
/*!40000 ALTER TABLE `tbltaskstimers` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltaskstimers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltaxes`
--

DROP TABLE IF EXISTS `tbltaxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbltaxes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `taxrate` decimal(15,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltaxes`
--

LOCK TABLES `tbltaxes` WRITE;
/*!40000 ALTER TABLE `tbltaxes` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltaxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltemplates`
--

DROP TABLE IF EXISTS `tbltemplates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbltemplates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `type` varchar(100) NOT NULL,
  `addedfrom` int(11) NOT NULL,
  `content` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltemplates`
--

LOCK TABLES `tbltemplates` WRITE;
/*!40000 ALTER TABLE `tbltemplates` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltemplates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblticket_attachments`
--

DROP TABLE IF EXISTS `tblticket_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblticket_attachments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticketid` int(11) NOT NULL,
  `replyid` int(11) DEFAULT NULL,
  `file_name` varchar(191) NOT NULL,
  `filetype` varchar(50) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblticket_attachments`
--

LOCK TABLES `tblticket_attachments` WRITE;
/*!40000 ALTER TABLE `tblticket_attachments` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblticket_attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblticket_replies`
--

DROP TABLE IF EXISTS `tblticket_replies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblticket_replies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticketid` int(11) NOT NULL,
  `userid` int(11) DEFAULT NULL,
  `contactid` int(11) NOT NULL DEFAULT 0,
  `name` mediumtext DEFAULT NULL,
  `email` mediumtext DEFAULT NULL,
  `date` datetime NOT NULL,
  `message` mediumtext DEFAULT NULL,
  `attachment` int(11) DEFAULT NULL,
  `admin` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblticket_replies`
--

LOCK TABLES `tblticket_replies` WRITE;
/*!40000 ALTER TABLE `tblticket_replies` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblticket_replies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltickets`
--

DROP TABLE IF EXISTS `tbltickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbltickets` (
  `ticketid` int(11) NOT NULL AUTO_INCREMENT,
  `adminreplying` int(11) NOT NULL DEFAULT 0,
  `userid` int(11) NOT NULL,
  `contactid` int(11) NOT NULL DEFAULT 0,
  `merged_ticket_id` int(11) DEFAULT NULL,
  `email` mediumtext DEFAULT NULL,
  `name` mediumtext DEFAULT NULL,
  `department` int(11) NOT NULL,
  `priority` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `service` int(11) DEFAULT NULL,
  `ticketkey` varchar(32) NOT NULL,
  `subject` varchar(191) NOT NULL,
  `message` mediumtext DEFAULT NULL,
  `admin` int(11) DEFAULT NULL,
  `date` datetime NOT NULL,
  `project_id` int(11) NOT NULL DEFAULT 0,
  `lastreply` datetime DEFAULT NULL,
  `clientread` int(11) NOT NULL DEFAULT 0,
  `adminread` int(11) NOT NULL DEFAULT 0,
  `assigned` int(11) NOT NULL DEFAULT 0,
  `staff_id_replying` int(11) DEFAULT NULL,
  `cc` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`ticketid`),
  KEY `service` (`service`),
  KEY `department` (`department`),
  KEY `status` (`status`),
  KEY `userid` (`userid`),
  KEY `priority` (`priority`),
  KEY `project_id` (`project_id`),
  KEY `contactid` (`contactid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltickets`
--

LOCK TABLES `tbltickets` WRITE;
/*!40000 ALTER TABLE `tbltickets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltickets_pipe_log`
--

DROP TABLE IF EXISTS `tbltickets_pipe_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbltickets_pipe_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `email_to` varchar(100) NOT NULL,
  `name` varchar(191) NOT NULL,
  `subject` varchar(191) NOT NULL,
  `message` longtext NOT NULL,
  `email` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltickets_pipe_log`
--

LOCK TABLES `tbltickets_pipe_log` WRITE;
/*!40000 ALTER TABLE `tbltickets_pipe_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltickets_pipe_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltickets_predefined_replies`
--

DROP TABLE IF EXISTS `tbltickets_predefined_replies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbltickets_predefined_replies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `message` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltickets_predefined_replies`
--

LOCK TABLES `tbltickets_predefined_replies` WRITE;
/*!40000 ALTER TABLE `tbltickets_predefined_replies` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltickets_predefined_replies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltickets_priorities`
--

DROP TABLE IF EXISTS `tbltickets_priorities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbltickets_priorities` (
  `priorityid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`priorityid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltickets_priorities`
--

LOCK TABLES `tbltickets_priorities` WRITE;
/*!40000 ALTER TABLE `tbltickets_priorities` DISABLE KEYS */;
INSERT INTO `tbltickets_priorities` VALUES
(1,'Low'),
(2,'Medium'),
(3,'High');
/*!40000 ALTER TABLE `tbltickets_priorities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltickets_status`
--

DROP TABLE IF EXISTS `tbltickets_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbltickets_status` (
  `ticketstatusid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `isdefault` int(11) NOT NULL DEFAULT 0,
  `statuscolor` varchar(7) DEFAULT NULL,
  `statusorder` int(11) DEFAULT NULL,
  PRIMARY KEY (`ticketstatusid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltickets_status`
--

LOCK TABLES `tbltickets_status` WRITE;
/*!40000 ALTER TABLE `tbltickets_status` DISABLE KEYS */;
INSERT INTO `tbltickets_status` VALUES
(1,'Open',1,'#ff2d42',1),
(2,'In progress',1,'#22c55e',2),
(3,'Answered',1,'#2563eb',3),
(4,'On Hold',1,'#64748b',4),
(5,'Closed',1,'#03a9f4',5);
/*!40000 ALTER TABLE `tbltickets_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltimesheets_additional_timesheet`
--

DROP TABLE IF EXISTS `tbltimesheets_additional_timesheet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbltimesheets_additional_timesheet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `additional_day` varchar(45) NOT NULL,
  `status` varchar(45) NOT NULL,
  `timekeeping_type` varchar(50) DEFAULT NULL,
  `timekeeping_value` varchar(45) NOT NULL,
  `approver` int(11) NOT NULL,
  `creator` int(11) NOT NULL,
  `old_timekeeping` varchar(50) DEFAULT NULL,
  `time_in` varchar(45) DEFAULT NULL,
  `time_out` varchar(45) DEFAULT NULL,
  `overtime_setting` int(11) DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `staff_id` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltimesheets_additional_timesheet`
--

LOCK TABLES `tbltimesheets_additional_timesheet` WRITE;
/*!40000 ALTER TABLE `tbltimesheets_additional_timesheet` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltimesheets_additional_timesheet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltimesheets_approval_details`
--

DROP TABLE IF EXISTS `tbltimesheets_approval_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbltimesheets_approval_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(45) NOT NULL,
  `staffid` varchar(45) DEFAULT NULL,
  `approve` varchar(45) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `approve_action` varchar(255) DEFAULT NULL,
  `reject_action` varchar(255) DEFAULT NULL,
  `approve_value` varchar(255) DEFAULT NULL,
  `reject_value` varchar(255) DEFAULT NULL,
  `staff_approve` int(11) DEFAULT NULL,
  `action` varchar(45) DEFAULT NULL,
  `sender` int(11) DEFAULT NULL,
  `date_send` datetime DEFAULT NULL,
  `notification_recipient` longtext DEFAULT NULL,
  `approval_deadline` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltimesheets_approval_details`
--

LOCK TABLES `tbltimesheets_approval_details` WRITE;
/*!40000 ALTER TABLE `tbltimesheets_approval_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltimesheets_approval_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltimesheets_approval_setting`
--

DROP TABLE IF EXISTS `tbltimesheets_approval_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbltimesheets_approval_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `related` varchar(255) NOT NULL,
  `setting` longtext NOT NULL,
  `choose_when_approving` int(11) NOT NULL DEFAULT 0,
  `notification_recipient` longtext DEFAULT NULL,
  `number_day_approval` int(11) DEFAULT NULL,
  `departments` text DEFAULT NULL,
  `job_positions` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltimesheets_approval_setting`
--

LOCK TABLES `tbltimesheets_approval_setting` WRITE;
/*!40000 ALTER TABLE `tbltimesheets_approval_setting` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltimesheets_approval_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltimesheets_day_off`
--

DROP TABLE IF EXISTS `tbltimesheets_day_off`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbltimesheets_day_off` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `year` varchar(45) DEFAULT NULL,
  `total` varchar(45) DEFAULT NULL,
  `remain` varchar(45) DEFAULT NULL,
  `accumulated` varchar(45) DEFAULT NULL,
  `days_off` float DEFAULT 0,
  `type_of_leave` varchar(200) NOT NULL DEFAULT '8',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltimesheets_day_off`
--

LOCK TABLES `tbltimesheets_day_off` WRITE;
/*!40000 ALTER TABLE `tbltimesheets_day_off` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltimesheets_day_off` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltimesheets_go_bussiness_advance_payment`
--

DROP TABLE IF EXISTS `tbltimesheets_go_bussiness_advance_payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbltimesheets_go_bussiness_advance_payment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `requisition_leave` int(11) NOT NULL,
  `used_to` varchar(200) DEFAULT NULL,
  `amoun_of_money` varchar(200) DEFAULT NULL,
  `request_date` date DEFAULT NULL,
  `advance_payment_reason` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltimesheets_go_bussiness_advance_payment`
--

LOCK TABLES `tbltimesheets_go_bussiness_advance_payment` WRITE;
/*!40000 ALTER TABLE `tbltimesheets_go_bussiness_advance_payment` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltimesheets_go_bussiness_advance_payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltimesheets_latch_timesheet`
--

DROP TABLE IF EXISTS `tbltimesheets_latch_timesheet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbltimesheets_latch_timesheet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `month_latch` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltimesheets_latch_timesheet`
--

LOCK TABLES `tbltimesheets_latch_timesheet` WRITE;
/*!40000 ALTER TABLE `tbltimesheets_latch_timesheet` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltimesheets_latch_timesheet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltimesheets_leave`
--

DROP TABLE IF EXISTS `tbltimesheets_leave`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbltimesheets_leave` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `date_work` date NOT NULL,
  `value` text DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltimesheets_leave`
--

LOCK TABLES `tbltimesheets_leave` WRITE;
/*!40000 ALTER TABLE `tbltimesheets_leave` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltimesheets_leave` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltimesheets_log_send_notify`
--

DROP TABLE IF EXISTS `tbltimesheets_log_send_notify`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbltimesheets_log_send_notify` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sent` int(11) NOT NULL DEFAULT 0,
  `staffid` int(11) NOT NULL DEFAULT 0,
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  `type` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltimesheets_log_send_notify`
--

LOCK TABLES `tbltimesheets_log_send_notify` WRITE;
/*!40000 ALTER TABLE `tbltimesheets_log_send_notify` DISABLE KEYS */;
INSERT INTO `tbltimesheets_log_send_notify` VALUES
(1,1,0,'2025-06-25 00:00:00','approval_expiration'),
(2,1,0,'2025-06-26 00:00:00','approval_expiration'),
(3,1,0,'2025-06-27 00:00:00','approval_expiration'),
(4,1,0,'2025-06-28 00:00:00','approval_expiration'),
(5,1,0,'2025-06-29 00:00:00','approval_expiration');
/*!40000 ALTER TABLE `tbltimesheets_log_send_notify` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltimesheets_option`
--

DROP TABLE IF EXISTS `tbltimesheets_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbltimesheets_option` (
  `option_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(200) NOT NULL,
  `option_val` longtext DEFAULT NULL,
  `auto` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`option_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltimesheets_option`
--

LOCK TABLES `tbltimesheets_option` WRITE;
/*!40000 ALTER TABLE `tbltimesheets_option` DISABLE KEYS */;
INSERT INTO `tbltimesheets_option` VALUES
(1,'shift_applicable_object','',1),
(2,'timekeeping_form','timekeeping_manually',1),
(3,'timekeeping_manually_role','',1),
(4,'timekeeping_task_role','',1),
(5,'csv_clsx_role','',1),
(6,'attendance_notice_recipient','',1),
(7,'allows_updating_check_in_time','1',1),
(8,'allows_to_choose_an_older_date','0',1),
(9,'allow_attendance_by_coordinates','0',1),
(10,'googlemap_api_key','',1),
(11,'allow_attendance_by_route','0',1),
(12,'auto_checkout','0',1),
(13,'auto_checkout_type','1',1),
(14,'auto_checkout_value','1',1),
(15,'send_notification_if_check_in_forgotten','0',1),
(16,'send_notification_if_check_in_forgotten_value','30',1),
(17,'start_month_for_annual_leave_cycle','1',1),
(18,'start_year_for_annual_leave_cycle','2025',1),
(19,'hour_notification_approval_exp','3',1),
(20,'timekeeping_enable_valid_ip','0',1),
(21,'send_email_check_in_out_customer_location','0',1),
(22,'allow_employees_to_create_work_points','0',1),
(23,'type_of_leave_selected','8',1);
/*!40000 ALTER TABLE `tbltimesheets_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltimesheets_requisition_leave`
--

DROP TABLE IF EXISTS `tbltimesheets_requisition_leave`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbltimesheets_requisition_leave` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `subject` varchar(100) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `received_date` date DEFAULT NULL,
  `amount_received` text DEFAULT NULL,
  `approver_id` int(11) NOT NULL,
  `followers_id` int(11) DEFAULT NULL,
  `rel_type` int(11) NOT NULL COMMENT '1:Leave 2:Late_early 3:Go_out 4:Go_on_bussiness',
  `status` int(11) DEFAULT 0 COMMENT '0:Create 1:Approver 2:Reject',
  `place_of_business` longtext DEFAULT NULL,
  `type_of_leave` int(11) DEFAULT 0,
  `according_to_the_plan` int(11) DEFAULT 0,
  `handover_recipients` longtext DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `number_of_days` float DEFAULT NULL,
  `number_of_leaving_day` varchar(45) DEFAULT NULL,
  `type_of_leave_text` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`,`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltimesheets_requisition_leave`
--

LOCK TABLES `tbltimesheets_requisition_leave` WRITE;
/*!40000 ALTER TABLE `tbltimesheets_requisition_leave` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltimesheets_requisition_leave` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltimesheets_route`
--

DROP TABLE IF EXISTS `tbltimesheets_route`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbltimesheets_route` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `route_point_id` int(11) NOT NULL,
  `date_work` date NOT NULL,
  `order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltimesheets_route`
--

LOCK TABLES `tbltimesheets_route` WRITE;
/*!40000 ALTER TABLE `tbltimesheets_route` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltimesheets_route` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltimesheets_route_point`
--

DROP TABLE IF EXISTS `tbltimesheets_route_point`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbltimesheets_route_point` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `route_point_address` varchar(400) DEFAULT NULL,
  `latitude` varchar(30) DEFAULT NULL,
  `longitude` varchar(30) DEFAULT NULL,
  `distance` double DEFAULT NULL,
  `related_to` int(11) NOT NULL,
  `related_id` int(11) NOT NULL,
  `default` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltimesheets_route_point`
--

LOCK TABLES `tbltimesheets_route_point` WRITE;
/*!40000 ALTER TABLE `tbltimesheets_route_point` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltimesheets_route_point` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltimesheets_shift_sc`
--

DROP TABLE IF EXISTS `tbltimesheets_shift_sc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbltimesheets_shift_sc` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shift_symbol` varchar(45) NOT NULL,
  `time_start_work` varchar(45) NOT NULL,
  `time_end_work` varchar(45) NOT NULL,
  `start_lunch_break_time` varchar(45) NOT NULL,
  `end_lunch_break_time` varchar(45) NOT NULL,
  `late_latency_allowed` varchar(45) NOT NULL,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltimesheets_shift_sc`
--

LOCK TABLES `tbltimesheets_shift_sc` WRITE;
/*!40000 ALTER TABLE `tbltimesheets_shift_sc` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltimesheets_shift_sc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltimesheets_shiftwork_sc`
--

DROP TABLE IF EXISTS `tbltimesheets_shiftwork_sc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbltimesheets_shiftwork_sc` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `date_work` date NOT NULL,
  `shift` int(11) NOT NULL,
  `datecreated` datetime DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltimesheets_shiftwork_sc`
--

LOCK TABLES `tbltimesheets_shiftwork_sc` WRITE;
/*!40000 ALTER TABLE `tbltimesheets_shiftwork_sc` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltimesheets_shiftwork_sc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltimesheets_timekeeper_data`
--

DROP TABLE IF EXISTS `tbltimesheets_timekeeper_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbltimesheets_timekeeper_data` (
  `staff_identifi` varchar(25) NOT NULL,
  `time` datetime NOT NULL,
  `type` varchar(45) NOT NULL,
  PRIMARY KEY (`staff_identifi`,`time`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltimesheets_timekeeper_data`
--

LOCK TABLES `tbltimesheets_timekeeper_data` WRITE;
/*!40000 ALTER TABLE `tbltimesheets_timekeeper_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltimesheets_timekeeper_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltimesheets_timesheet`
--

DROP TABLE IF EXISTS `tbltimesheets_timesheet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbltimesheets_timesheet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `date_work` date NOT NULL,
  `value` text DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  `overtime_setting` int(11) DEFAULT NULL,
  `relate_id` int(11) DEFAULT NULL,
  `relate_type` varchar(25) DEFAULT NULL,
  `latch` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltimesheets_timesheet`
--

LOCK TABLES `tbltimesheets_timesheet` WRITE;
/*!40000 ALTER TABLE `tbltimesheets_timesheet` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltimesheets_timesheet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltimesheets_type_of_leave`
--

DROP TABLE IF EXISTS `tbltimesheets_type_of_leave`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbltimesheets_type_of_leave` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type_name` varchar(200) DEFAULT NULL,
  `slug` varchar(200) DEFAULT NULL,
  `symbol` varchar(5) DEFAULT NULL,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltimesheets_type_of_leave`
--

LOCK TABLES `tbltimesheets_type_of_leave` WRITE;
/*!40000 ALTER TABLE `tbltimesheets_type_of_leave` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltimesheets_type_of_leave` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltimesheets_valid_ip`
--

DROP TABLE IF EXISTS `tbltimesheets_valid_ip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbltimesheets_valid_ip` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ip` varchar(30) DEFAULT NULL,
  `enable` int(11) NOT NULL DEFAULT 1,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltimesheets_valid_ip`
--

LOCK TABLES `tbltimesheets_valid_ip` WRITE;
/*!40000 ALTER TABLE `tbltimesheets_valid_ip` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltimesheets_valid_ip` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltimesheets_workplace`
--

DROP TABLE IF EXISTS `tbltimesheets_workplace`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbltimesheets_workplace` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `workplace_address` varchar(400) DEFAULT NULL,
  `latitude` varchar(30) DEFAULT NULL,
  `longitude` varchar(30) DEFAULT NULL,
  `distance` double DEFAULT NULL,
  `default` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltimesheets_workplace`
--

LOCK TABLES `tbltimesheets_workplace` WRITE;
/*!40000 ALTER TABLE `tbltimesheets_workplace` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltimesheets_workplace` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltimesheets_workplace_assign`
--

DROP TABLE IF EXISTS `tbltimesheets_workplace_assign`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbltimesheets_workplace_assign` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `workplace_id` int(11) NOT NULL,
  `datecreator` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltimesheets_workplace_assign`
--

LOCK TABLES `tbltimesheets_workplace_assign` WRITE;
/*!40000 ALTER TABLE `tbltimesheets_workplace_assign` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltimesheets_workplace_assign` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltodos`
--

DROP TABLE IF EXISTS `tbltodos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbltodos` (
  `todoid` int(11) NOT NULL AUTO_INCREMENT,
  `description` mediumtext NOT NULL,
  `staffid` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  `finished` tinyint(1) NOT NULL,
  `datefinished` datetime DEFAULT NULL,
  `item_order` int(11) DEFAULT NULL,
  PRIMARY KEY (`todoid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltodos`
--

LOCK TABLES `tbltodos` WRITE;
/*!40000 ALTER TABLE `tbltodos` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltodos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltracked_mails`
--

DROP TABLE IF EXISTS `tbltracked_mails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbltracked_mails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` varchar(32) NOT NULL,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(40) NOT NULL,
  `date` datetime NOT NULL,
  `email` varchar(100) NOT NULL,
  `opened` tinyint(1) NOT NULL DEFAULT 0,
  `date_opened` datetime DEFAULT NULL,
  `subject` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltracked_mails`
--

LOCK TABLES `tbltracked_mails` WRITE;
/*!40000 ALTER TABLE `tbltracked_mails` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltracked_mails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltraining_allocation`
--

DROP TABLE IF EXISTS `tbltraining_allocation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbltraining_allocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `training_process_id` varchar(100) NOT NULL,
  `staffid` int(11) DEFAULT NULL,
  `training_type` int(11) DEFAULT NULL,
  `date_add` datetime DEFAULT NULL,
  `training_name` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltraining_allocation`
--

LOCK TABLES `tbltraining_allocation` WRITE;
/*!40000 ALTER TABLE `tbltraining_allocation` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltraining_allocation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltransfer_records_reception`
--

DROP TABLE IF EXISTS `tbltransfer_records_reception`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbltransfer_records_reception` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) DEFAULT NULL,
  `meta` varchar(50) DEFAULT NULL,
  `staffid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltransfer_records_reception`
--

LOCK TABLES `tbltransfer_records_reception` WRITE;
/*!40000 ALTER TABLE `tbltransfer_records_reception` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltransfer_records_reception` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltwocheckout_log`
--

DROP TABLE IF EXISTS `tbltwocheckout_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbltwocheckout_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference` varchar(64) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `amount` varchar(25) NOT NULL,
  `created_at` datetime NOT NULL,
  `attempt_reference` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `invoice_id` (`invoice_id`),
  CONSTRAINT `tbltwocheckout_log_ibfk_1` FOREIGN KEY (`invoice_id`) REFERENCES `tblinvoices` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltwocheckout_log`
--

LOCK TABLES `tbltwocheckout_log` WRITE;
/*!40000 ALTER TABLE `tbltwocheckout_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltwocheckout_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbluser_auto_login`
--

DROP TABLE IF EXISTS `tbluser_auto_login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbluser_auto_login` (
  `key_id` char(32) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_agent` varchar(150) NOT NULL,
  `last_ip` varchar(40) NOT NULL,
  `last_login` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `staff` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbluser_auto_login`
--

LOCK TABLES `tbluser_auto_login` WRITE;
/*!40000 ALTER TABLE `tbluser_auto_login` DISABLE KEYS */;
INSERT INTO `tbluser_auto_login` VALUES
('b7eb7a01e5b989ed4155f0ef4ed28c83',1,'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','157.48.80.182','2025-06-26 00:22:55',1),
('39823036f55604a98c7a975dd661f76d',1,'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','157.48.82.220','2025-06-26 06:44:21',1),
('3998ba2cb859056e0e1f0e0207076d8c',1,'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','157.48.82.220','2025-06-26 14:28:35',1),
('f7f0fb7f564d5556615071edfda5a241',2,'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2409:40d4:10cd:43f8:f408:13f9:e02c:5190','2025-06-27 05:27:07',0),
('3410c96287d842cf741c20a1dfc3b85b',1,'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2409:40d4:10cd:43f8:f408:13f9:e02c:5190','2025-06-27 05:32:09',1),
('78c328bfa782073106a6accc5dd590de',3,'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2409:40d4:10cd:43f8:f408:13f9:e02c:5190','2025-06-27 06:31:57',0),
('70c1fa4db94fac0fb967f01598b396cc',1,'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2409:40d4:10cd:43f8:f408:13f9:e02c:5190','2025-06-27 06:33:06',1),
('03e950af7ea972be6880bbcefac0f4f3',1,'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2409:40d4:10cd:43f8:f408:13f9:e02c:5190','2025-06-27 07:24:06',1),
('31456b4b9028ebcb2907b8139cd1d463',1,'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2409:40d4:10cd:43f8:f408:13f9:e02c:5190','2025-06-27 09:46:46',1),
('e5d88868f583414f6d36ad8304b48aef',4,'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2409:40d4:10cd:43f8:ccef:f512:e762:56b2','2025-06-29 05:04:08',0),
('898cd05adfc800d928f60faa2d124f00',4,'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2405:201:4018:225d:9952:89b6:f4e2:c984','2025-07-01 11:10:29',0);
/*!40000 ALTER TABLE `tbluser_auto_login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbluser_meta`
--

DROP TABLE IF EXISTS `tbluser_meta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbluser_meta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `staff_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `client_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `contact_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(191) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`umeta_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbluser_meta`
--

LOCK TABLES `tbluser_meta` WRITE;
/*!40000 ALTER TABLE `tbluser_meta` DISABLE KEYS */;
INSERT INTO `tbluser_meta` VALUES
(1,0,0,1,'consent_key','ef796d492556fb67e42dbabb9f08315c-25b217cdf952f1f63afde22ee244d8f8'),
(2,0,0,2,'consent_key','96bcd9fd526d4c0479ad3a3737adef09-9ef61aa2c96227584daaf2c42f47bbbb'),
(3,0,0,3,'consent_key','63ea3190ad3a654da8cf7de85a6b4ea5-3afac111169c88a9451b9107a5dee41e'),
(4,0,0,4,'consent_key','402c3b2c69b18c68bace97c95a3d9c95-291b6572a7361d83713c37fa23cbd0cd'),
(5,0,0,5,'consent_key','af472ab31bbda40f480f2b9620f07ff9-fc314ff2f097f6a0435ac2d667b7d150');
/*!40000 ALTER TABLE `tbluser_meta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblvault`
--

DROP TABLE IF EXISTS `tblvault`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblvault` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `server_address` varchar(191) NOT NULL,
  `port` int(11) DEFAULT NULL,
  `username` varchar(191) NOT NULL,
  `password` mediumtext NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `creator` int(11) NOT NULL,
  `creator_name` varchar(100) DEFAULT NULL,
  `visibility` tinyint(1) NOT NULL DEFAULT 1,
  `share_in_projects` tinyint(1) NOT NULL DEFAULT 0,
  `last_updated` datetime DEFAULT NULL,
  `last_updated_from` varchar(100) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblvault`
--

LOCK TABLES `tblvault` WRITE;
/*!40000 ALTER TABLE `tblvault` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblvault` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblviews_tracking`
--

DROP TABLE IF EXISTS `tblviews_tracking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblviews_tracking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(40) NOT NULL,
  `date` datetime NOT NULL,
  `view_ip` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblviews_tracking`
--

LOCK TABLES `tblviews_tracking` WRITE;
/*!40000 ALTER TABLE `tblviews_tracking` DISABLE KEYS */;
INSERT INTO `tblviews_tracking` VALUES
(1,1,'invoice','2025-06-27 13:16:37','2409:40d4:10cd:43f8:f408:13f9:e02c:5190');
/*!40000 ALTER TABLE `tblviews_tracking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblware_body_type`
--

DROP TABLE IF EXISTS `tblware_body_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblware_body_type` (
  `body_type_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `body_code` varchar(100) DEFAULT NULL,
  `body_name` text DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  `display` int(1) DEFAULT NULL COMMENT 'display 1: display (yes)  0: not displayed (no)',
  `note` text DEFAULT NULL,
  PRIMARY KEY (`body_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblware_body_type`
--

LOCK TABLES `tblware_body_type` WRITE;
/*!40000 ALTER TABLE `tblware_body_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblware_body_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblware_color`
--

DROP TABLE IF EXISTS `tblware_color`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblware_color` (
  `color_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `color_code` varchar(100) DEFAULT NULL,
  `color_name` varchar(100) DEFAULT NULL,
  `color_hex` text DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  `display` int(1) DEFAULT NULL COMMENT 'display 1: display (yes)  0: not displayed (no)',
  `note` text DEFAULT NULL,
  PRIMARY KEY (`color_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblware_color`
--

LOCK TABLES `tblware_color` WRITE;
/*!40000 ALTER TABLE `tblware_color` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblware_color` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblware_commodity_type`
--

DROP TABLE IF EXISTS `tblware_commodity_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblware_commodity_type` (
  `commodity_type_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `commondity_code` varchar(100) DEFAULT NULL,
  `commondity_name` text DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  `display` int(1) DEFAULT NULL COMMENT 'display 1: display (yes)  0: not displayed (no)',
  `note` text DEFAULT NULL,
  PRIMARY KEY (`commodity_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblware_commodity_type`
--

LOCK TABLES `tblware_commodity_type` WRITE;
/*!40000 ALTER TABLE `tblware_commodity_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblware_commodity_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblware_size_type`
--

DROP TABLE IF EXISTS `tblware_size_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblware_size_type` (
  `size_type_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `size_code` varchar(100) DEFAULT NULL,
  `size_name` text DEFAULT NULL,
  `size_symbol` text DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  `display` int(1) DEFAULT NULL COMMENT 'display 1: display (yes)  0: not displayed (no)',
  `note` text DEFAULT NULL,
  PRIMARY KEY (`size_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblware_size_type`
--

LOCK TABLES `tblware_size_type` WRITE;
/*!40000 ALTER TABLE `tblware_size_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblware_size_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblware_style_type`
--

DROP TABLE IF EXISTS `tblware_style_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblware_style_type` (
  `style_type_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `style_code` varchar(100) DEFAULT NULL,
  `style_barcode` text DEFAULT NULL,
  `style_name` text DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  `display` int(1) DEFAULT NULL COMMENT 'display 1: display (yes)  0: not displayed (no)',
  `note` text DEFAULT NULL,
  PRIMARY KEY (`style_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblware_style_type`
--

LOCK TABLES `tblware_style_type` WRITE;
/*!40000 ALTER TABLE `tblware_style_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblware_style_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblware_unit_type`
--

DROP TABLE IF EXISTS `tblware_unit_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblware_unit_type` (
  `unit_type_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `unit_code` varchar(100) DEFAULT NULL,
  `unit_name` text DEFAULT NULL,
  `unit_symbol` text DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  `display` int(1) DEFAULT NULL COMMENT 'display 1: display (yes)  0: not displayed (no)',
  `note` text DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `unit_measure_type` varchar(100) DEFAULT 'reference',
  `bigger_ratio` decimal(15,5) DEFAULT 0.00000,
  `smaller_ratio` decimal(15,5) DEFAULT 0.00000,
  `rounding` decimal(15,5) DEFAULT 0.00000,
  PRIMARY KEY (`unit_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblware_unit_type`
--

LOCK TABLES `tblware_unit_type` WRITE;
/*!40000 ALTER TABLE `tblware_unit_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblware_unit_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblwarehouse`
--

DROP TABLE IF EXISTS `tblwarehouse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblwarehouse` (
  `warehouse_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `warehouse_code` varchar(100) DEFAULT NULL,
  `warehouse_name` text DEFAULT NULL,
  `warehouse_address` text DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  `display` int(1) DEFAULT NULL COMMENT 'display 1: display (yes)  0: not displayed (no)',
  `note` text DEFAULT NULL,
  `city` text DEFAULT NULL,
  `state` text DEFAULT NULL,
  `zip_code` text DEFAULT NULL,
  `country` text DEFAULT NULL,
  `hide_warehouse_when_out_of_stock` int(11) DEFAULT 0 COMMENT ' 1: yes  0: no',
  PRIMARY KEY (`warehouse_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblwarehouse`
--

LOCK TABLES `tblwarehouse` WRITE;
/*!40000 ALTER TABLE `tblwarehouse` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblwarehouse` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblweb_to_lead`
--

DROP TABLE IF EXISTS `tblweb_to_lead`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblweb_to_lead` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `form_key` varchar(32) NOT NULL,
  `lead_source` int(11) NOT NULL,
  `lead_status` int(11) NOT NULL,
  `notify_lead_imported` int(11) NOT NULL DEFAULT 1,
  `notify_type` varchar(20) DEFAULT NULL,
  `notify_ids` longtext DEFAULT NULL,
  `responsible` int(11) NOT NULL DEFAULT 0,
  `name` varchar(191) NOT NULL,
  `form_data` longtext DEFAULT NULL,
  `recaptcha` int(11) NOT NULL DEFAULT 0,
  `submit_btn_name` varchar(40) DEFAULT NULL,
  `submit_btn_text_color` varchar(10) DEFAULT '#ffffff',
  `submit_btn_bg_color` varchar(10) DEFAULT '#84c529',
  `success_submit_msg` mediumtext DEFAULT NULL,
  `submit_action` int(11) DEFAULT 0,
  `lead_name_prefix` varchar(255) DEFAULT NULL,
  `submit_redirect_url` longtext DEFAULT NULL,
  `language` varchar(40) DEFAULT NULL,
  `allow_duplicate` int(11) NOT NULL DEFAULT 1,
  `mark_public` int(11) NOT NULL DEFAULT 0,
  `track_duplicate_field` varchar(20) DEFAULT NULL,
  `track_duplicate_field_and` varchar(20) DEFAULT NULL,
  `create_task_on_duplicate` int(11) NOT NULL DEFAULT 0,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblweb_to_lead`
--

LOCK TABLES `tblweb_to_lead` WRITE;
/*!40000 ALTER TABLE `tblweb_to_lead` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblweb_to_lead` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblwh_activity_log`
--

DROP TABLE IF EXISTS `tblwh_activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblwh_activity_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(45) NOT NULL,
  `staffid` int(11) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `note` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblwh_activity_log`
--

LOCK TABLES `tblwh_activity_log` WRITE;
/*!40000 ALTER TABLE `tblwh_activity_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblwh_activity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblwh_approval_details`
--

DROP TABLE IF EXISTS `tblwh_approval_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblwh_approval_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(45) NOT NULL,
  `staffid` varchar(45) DEFAULT NULL,
  `approve` varchar(45) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `approve_action` varchar(255) DEFAULT NULL,
  `reject_action` varchar(255) DEFAULT NULL,
  `approve_value` varchar(255) DEFAULT NULL,
  `reject_value` varchar(255) DEFAULT NULL,
  `staff_approve` int(11) DEFAULT NULL,
  `action` varchar(45) DEFAULT NULL,
  `sender` int(11) DEFAULT NULL,
  `date_send` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblwh_approval_details`
--

LOCK TABLES `tblwh_approval_details` WRITE;
/*!40000 ALTER TABLE `tblwh_approval_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblwh_approval_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblwh_approval_setting`
--

DROP TABLE IF EXISTS `tblwh_approval_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblwh_approval_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `related` varchar(255) NOT NULL,
  `setting` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblwh_approval_setting`
--

LOCK TABLES `tblwh_approval_setting` WRITE;
/*!40000 ALTER TABLE `tblwh_approval_setting` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblwh_approval_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblwh_brand`
--

DROP TABLE IF EXISTS `tblwh_brand`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblwh_brand` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblwh_brand`
--

LOCK TABLES `tblwh_brand` WRITE;
/*!40000 ALTER TABLE `tblwh_brand` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblwh_brand` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblwh_custom_fields`
--

DROP TABLE IF EXISTS `tblwh_custom_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblwh_custom_fields` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `custom_fields_id` int(11) DEFAULT NULL,
  `warehouse_id` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblwh_custom_fields`
--

LOCK TABLES `tblwh_custom_fields` WRITE;
/*!40000 ALTER TABLE `tblwh_custom_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblwh_custom_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblwh_goods_delivery_activity_log`
--

DROP TABLE IF EXISTS `tblwh_goods_delivery_activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblwh_goods_delivery_activity_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(100) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `additional_data` text DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `staffid` int(11) DEFAULT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblwh_goods_delivery_activity_log`
--

LOCK TABLES `tblwh_goods_delivery_activity_log` WRITE;
/*!40000 ALTER TABLE `tblwh_goods_delivery_activity_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblwh_goods_delivery_activity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblwh_inventory_serial_numbers`
--

DROP TABLE IF EXISTS `tblwh_inventory_serial_numbers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblwh_inventory_serial_numbers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `commodity_id` int(11) NOT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `inventory_manage_id` int(11) DEFAULT NULL,
  `serial_number` varchar(255) DEFAULT NULL,
  `is_used` varchar(20) DEFAULT 'no',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblwh_inventory_serial_numbers`
--

LOCK TABLES `tblwh_inventory_serial_numbers` WRITE;
/*!40000 ALTER TABLE `tblwh_inventory_serial_numbers` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblwh_inventory_serial_numbers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblwh_loss_adjustment`
--

DROP TABLE IF EXISTS `tblwh_loss_adjustment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblwh_loss_adjustment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(15) DEFAULT NULL,
  `addfrom` int(11) DEFAULT NULL,
  `reason` longtext DEFAULT NULL,
  `time` datetime DEFAULT NULL,
  `date_create` date NOT NULL,
  `status` int(11) NOT NULL,
  `warehouses` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblwh_loss_adjustment`
--

LOCK TABLES `tblwh_loss_adjustment` WRITE;
/*!40000 ALTER TABLE `tblwh_loss_adjustment` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblwh_loss_adjustment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblwh_loss_adjustment_detail`
--

DROP TABLE IF EXISTS `tblwh_loss_adjustment_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblwh_loss_adjustment_detail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `items` int(11) DEFAULT NULL,
  `unit` int(11) DEFAULT NULL,
  `current_number` int(15) DEFAULT NULL,
  `updates_number` int(15) DEFAULT NULL,
  `loss_adjustment` int(11) DEFAULT NULL,
  `expiry_date` text DEFAULT NULL,
  `lot_number` text DEFAULT NULL,
  `commodity_name` text DEFAULT NULL,
  `serial_number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblwh_loss_adjustment_detail`
--

LOCK TABLES `tblwh_loss_adjustment_detail` WRITE;
/*!40000 ALTER TABLE `tblwh_loss_adjustment_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblwh_loss_adjustment_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblwh_model`
--

DROP TABLE IF EXISTS `tblwh_model`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblwh_model` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` text DEFAULT NULL,
  `brand_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`brand_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblwh_model`
--

LOCK TABLES `tblwh_model` WRITE;
/*!40000 ALTER TABLE `tblwh_model` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblwh_model` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblwh_omni_shipments`
--

DROP TABLE IF EXISTS `tblwh_omni_shipments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblwh_omni_shipments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cart_id` int(11) DEFAULT NULL,
  `shipment_number` varchar(100) DEFAULT NULL,
  `planned_shipping_date` datetime DEFAULT NULL,
  `shipment_status` varchar(50) DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `goods_delivery_id` int(11) DEFAULT NULL,
  `shipment_hash` varchar(32) DEFAULT NULL,
  `order_id` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblwh_omni_shipments`
--

LOCK TABLES `tblwh_omni_shipments` WRITE;
/*!40000 ALTER TABLE `tblwh_omni_shipments` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblwh_omni_shipments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblwh_order_return_details`
--

DROP TABLE IF EXISTS `tblwh_order_return_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblwh_order_return_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_return_id` int(11) NOT NULL,
  `rel_type_detail_id` int(11) DEFAULT NULL,
  `commodity_code` int(11) DEFAULT NULL,
  `commodity_name` text DEFAULT NULL,
  `quantity` decimal(15,2) DEFAULT 0.00,
  `unit_id` int(11) DEFAULT NULL,
  `unit_price` decimal(15,2) DEFAULT 0.00,
  `sub_total` decimal(15,2) DEFAULT 0.00,
  `tax_id` text DEFAULT NULL,
  `tax_rate` text DEFAULT NULL,
  `tax_name` text DEFAULT NULL,
  `total_amount` decimal(15,2) DEFAULT 0.00,
  `discount` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `total_after_discount` decimal(15,2) DEFAULT 0.00,
  `reason_return` varchar(200) DEFAULT NULL,
  `purchase_price` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblwh_order_return_details`
--

LOCK TABLES `tblwh_order_return_details` WRITE;
/*!40000 ALTER TABLE `tblwh_order_return_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblwh_order_return_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblwh_order_returns`
--

DROP TABLE IF EXISTS `tblwh_order_returns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblwh_order_returns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(50) NOT NULL COMMENT 'manual, sales_return_order, purchasing_return_order',
  `return_type` varchar(50) DEFAULT NULL COMMENT 'manual, partially, fully',
  `company_id` int(11) DEFAULT NULL,
  `company_name` varchar(500) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phonenumber` varchar(20) DEFAULT NULL,
  `order_number` varchar(500) DEFAULT NULL,
  `order_date` datetime DEFAULT NULL,
  `number_of_item` decimal(15,2) DEFAULT 0.00,
  `order_total` decimal(15,2) DEFAULT 0.00,
  `order_return_number` varchar(200) DEFAULT NULL,
  `order_return_name` varchar(500) DEFAULT NULL,
  `fee_return_order` decimal(15,2) DEFAULT 0.00,
  `refund_loyaty_point` int(11) DEFAULT 0,
  `subtotal` decimal(15,2) DEFAULT 0.00,
  `total_amount` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `additional_discount` decimal(15,2) DEFAULT 0.00,
  `adjustment_amount` decimal(15,2) DEFAULT 0.00,
  `total_after_discount` decimal(15,2) DEFAULT 0.00,
  `return_policies_information` text DEFAULT NULL,
  `admin_note` text DEFAULT NULL,
  `approval` int(11) DEFAULT 0,
  `datecreated` datetime DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `receipt_delivery_id` int(1) DEFAULT 0,
  `currency` int(11) DEFAULT NULL,
  `return_reason` longtext DEFAULT NULL,
  `receipt_delivery_type` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblwh_order_returns`
--

LOCK TABLES `tblwh_order_returns` WRITE;
/*!40000 ALTER TABLE `tblwh_order_returns` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblwh_order_returns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblwh_packing_list_details`
--

DROP TABLE IF EXISTS `tblwh_packing_list_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblwh_packing_list_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `packing_list_id` int(11) NOT NULL,
  `delivery_detail_id` int(11) DEFAULT NULL,
  `commodity_code` int(11) DEFAULT NULL,
  `commodity_name` text DEFAULT NULL,
  `quantity` decimal(15,2) DEFAULT 0.00,
  `unit_id` int(11) DEFAULT NULL,
  `unit_price` decimal(15,2) DEFAULT 0.00,
  `sub_total` decimal(15,2) DEFAULT 0.00,
  `tax_id` text DEFAULT NULL,
  `tax_rate` text DEFAULT NULL,
  `tax_name` text DEFAULT NULL,
  `total_amount` decimal(15,2) DEFAULT 0.00,
  `discount` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `total_after_discount` decimal(15,2) DEFAULT 0.00,
  `serial_number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblwh_packing_list_details`
--

LOCK TABLES `tblwh_packing_list_details` WRITE;
/*!40000 ALTER TABLE `tblwh_packing_list_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblwh_packing_list_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblwh_packing_lists`
--

DROP TABLE IF EXISTS `tblwh_packing_lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblwh_packing_lists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `delivery_note_id` int(11) DEFAULT NULL,
  `packing_list_number` varchar(100) DEFAULT NULL,
  `packing_list_name` varchar(200) DEFAULT NULL,
  `width` decimal(15,2) DEFAULT 0.00,
  `height` decimal(15,2) DEFAULT 0.00,
  `lenght` decimal(15,2) DEFAULT 0.00,
  `weight` decimal(15,2) DEFAULT 0.00,
  `volume` decimal(15,2) DEFAULT 0.00,
  `clientid` int(11) DEFAULT NULL,
  `subtotal` decimal(15,2) DEFAULT 0.00,
  `total_amount` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `additional_discount` decimal(15,2) DEFAULT 0.00,
  `total_after_discount` decimal(15,2) DEFAULT 0.00,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT NULL,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT NULL,
  `client_note` text DEFAULT NULL,
  `admin_note` text DEFAULT NULL,
  `approval` int(11) DEFAULT 0,
  `datecreated` datetime DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `type_of_packing_list` varchar(100) DEFAULT 'total',
  `delivery_status` varchar(100) DEFAULT 'wh_ready_to_deliver',
  `shipping_fee` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblwh_packing_lists`
--

LOCK TABLES `tblwh_packing_lists` WRITE;
/*!40000 ALTER TABLE `tblwh_packing_lists` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblwh_packing_lists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblwh_series`
--

DROP TABLE IF EXISTS `tblwh_series`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblwh_series` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` text DEFAULT NULL,
  `model_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`model_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblwh_series`
--

LOCK TABLES `tblwh_series` WRITE;
/*!40000 ALTER TABLE `tblwh_series` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblwh_series` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblwh_staff_warehouses`
--

DROP TABLE IF EXISTS `tblwh_staff_warehouses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblwh_staff_warehouses` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblwh_staff_warehouses`
--

LOCK TABLES `tblwh_staff_warehouses` WRITE;
/*!40000 ALTER TABLE `tblwh_staff_warehouses` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblwh_staff_warehouses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblwh_sub_group`
--

DROP TABLE IF EXISTS `tblwh_sub_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblwh_sub_group` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sub_group_code` varchar(100) DEFAULT NULL,
  `sub_group_name` text DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  `display` int(1) DEFAULT NULL COMMENT 'display 1: display (yes)  0: not displayed (no)',
  `note` text DEFAULT NULL,
  `group_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblwh_sub_group`
--

LOCK TABLES `tblwh_sub_group` WRITE;
/*!40000 ALTER TABLE `tblwh_sub_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblwh_sub_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblwork_shift`
--

DROP TABLE IF EXISTS `tblwork_shift`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblwork_shift` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shift_code` varchar(45) NOT NULL,
  `shift_name` varchar(200) NOT NULL,
  `shift_type` varchar(200) NOT NULL,
  `department` varchar(45) DEFAULT NULL,
  `position` varchar(45) DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  `staff` text DEFAULT NULL,
  `date_create` date DEFAULT NULL,
  `from_date` date DEFAULT NULL,
  `to_date` date DEFAULT NULL,
  `shifts_detail` text NOT NULL,
  `type_shiftwork` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblwork_shift`
--

LOCK TABLES `tblwork_shift` WRITE;
/*!40000 ALTER TABLE `tblwork_shift` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblwork_shift` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblwork_shift_detail`
--

DROP TABLE IF EXISTS `tblwork_shift_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblwork_shift_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `shift_id` int(11) DEFAULT NULL,
  `work_shift_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblwork_shift_detail`
--

LOCK TABLES `tblwork_shift_detail` WRITE;
/*!40000 ALTER TABLE `tblwork_shift_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblwork_shift_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblwork_shift_detail_day_name`
--

DROP TABLE IF EXISTS `tblwork_shift_detail_day_name`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblwork_shift_detail_day_name` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `day_name` varchar(45) DEFAULT NULL,
  `shift_id` int(11) DEFAULT NULL,
  `work_shift_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblwork_shift_detail_day_name`
--

LOCK TABLES `tblwork_shift_detail_day_name` WRITE;
/*!40000 ALTER TABLE `tblwork_shift_detail_day_name` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblwork_shift_detail_day_name` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblwork_shift_detail_number_day`
--

DROP TABLE IF EXISTS `tblwork_shift_detail_number_day`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblwork_shift_detail_number_day` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `number` int(11) DEFAULT NULL,
  `shift_id` int(11) DEFAULT NULL,
  `work_shift_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblwork_shift_detail_number_day`
--

LOCK TABLES `tblwork_shift_detail_number_day` WRITE;
/*!40000 ALTER TABLE `tblwork_shift_detail_number_day` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblwork_shift_detail_number_day` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-02  6:00:44
