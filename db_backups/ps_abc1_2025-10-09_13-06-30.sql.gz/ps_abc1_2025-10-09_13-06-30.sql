/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.5.27-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: ps_abc1
-- ------------------------------------------------------
-- Server version	10.5.27-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `abc1_tblacc_account_history`
--

DROP TABLE IF EXISTS `abc1_tblacc_account_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblacc_account_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account` int(11) NOT NULL,
  `debit` decimal(15,2) NOT NULL DEFAULT 0.00,
  `credit` decimal(15,2) NOT NULL DEFAULT 0.00,
  `description` text DEFAULT NULL,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(45) DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `customer` int(11) DEFAULT NULL,
  `reconcile` int(11) NOT NULL DEFAULT 0,
  `split` int(11) NOT NULL DEFAULT 0,
  `item` int(11) DEFAULT NULL,
  `paid` int(1) NOT NULL DEFAULT 0,
  `date` date DEFAULT NULL,
  `tax` int(11) DEFAULT NULL,
  `payslip_type` varchar(45) DEFAULT NULL,
  `vendor` int(11) DEFAULT NULL,
  `itemable_id` int(11) DEFAULT NULL,
  `cleared` int(11) NOT NULL DEFAULT 0,
  `sub_type` varchar(45) DEFAULT NULL,
  `bill_item` int(11) NOT NULL DEFAULT 0,
  `number` varchar(100) DEFAULT NULL,
  `issue` int(11) NOT NULL DEFAULT 0,
  `added_from_reconcile` int(11) NOT NULL DEFAULT 0,
  `bank_reconcile` int(11) NOT NULL DEFAULT 0,
  `currency_rate` decimal(15,6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblacc_account_history`
--

LOCK TABLES `abc1_tblacc_account_history` WRITE;
/*!40000 ALTER TABLE `abc1_tblacc_account_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblacc_account_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblacc_account_type_details`
--

DROP TABLE IF EXISTS `abc1_tblacc_account_type_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblacc_account_type_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_type_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `note` text DEFAULT NULL,
  `statement_of_cash_flows` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblacc_account_type_details`
--

LOCK TABLES `abc1_tblacc_account_type_details` WRITE;
/*!40000 ALTER TABLE `abc1_tblacc_account_type_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblacc_account_type_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblacc_accounts`
--

DROP TABLE IF EXISTS `abc1_tblacc_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblacc_accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `key_name` varchar(255) DEFAULT NULL,
  `number` varchar(45) DEFAULT NULL,
  `parent_account` int(11) DEFAULT NULL,
  `account_type_id` int(11) NOT NULL,
  `account_detail_type_id` int(11) NOT NULL,
  `balance` decimal(15,2) DEFAULT NULL,
  `balance_as_of` date DEFAULT NULL,
  `description` text DEFAULT NULL,
  `default_account` int(11) NOT NULL DEFAULT 0,
  `active` int(11) NOT NULL DEFAULT 1,
  `access_token` text DEFAULT NULL,
  `account_id` varchar(255) DEFAULT NULL,
  `plaid_status` tinyint(5) NOT NULL DEFAULT 0 COMMENT '1=>verified, 0=>not verified',
  `plaid_account_name` varchar(255) DEFAULT NULL,
  `bank_account` text DEFAULT NULL,
  `bank_routing` text DEFAULT NULL,
  `address_line_1` text DEFAULT NULL,
  `address_line_2` text DEFAULT NULL,
  `bank_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblacc_accounts`
--

LOCK TABLES `abc1_tblacc_accounts` WRITE;
/*!40000 ALTER TABLE `abc1_tblacc_accounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblacc_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblacc_bank_reconciles`
--

DROP TABLE IF EXISTS `abc1_tblacc_bank_reconciles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblacc_bank_reconciles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account` int(11) NOT NULL,
  `opening_balance` decimal(15,2) NOT NULL DEFAULT 0.00,
  `beginning_balance` decimal(15,2) NOT NULL,
  `ending_balance` decimal(15,2) NOT NULL,
  `ending_date` date NOT NULL,
  `finish` int(11) NOT NULL DEFAULT 0,
  `debits_for_period` decimal(15,2) NOT NULL,
  `credits_for_period` decimal(15,2) NOT NULL,
  `dateadded` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblacc_bank_reconciles`
--

LOCK TABLES `abc1_tblacc_bank_reconciles` WRITE;
/*!40000 ALTER TABLE `abc1_tblacc_bank_reconciles` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblacc_bank_reconciles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblacc_banking_rule_details`
--

DROP TABLE IF EXISTS `abc1_tblacc_banking_rule_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblacc_banking_rule_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rule_id` int(11) NOT NULL,
  `type` varchar(45) DEFAULT NULL,
  `subtype` varchar(45) DEFAULT NULL,
  `text` varchar(255) DEFAULT NULL,
  `subtype_amount` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblacc_banking_rule_details`
--

LOCK TABLES `abc1_tblacc_banking_rule_details` WRITE;
/*!40000 ALTER TABLE `abc1_tblacc_banking_rule_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblacc_banking_rule_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblacc_banking_rules`
--

DROP TABLE IF EXISTS `abc1_tblacc_banking_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblacc_banking_rules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `transaction` varchar(45) DEFAULT NULL,
  `following` varchar(45) DEFAULT NULL,
  `then` varchar(45) DEFAULT NULL,
  `payment_account` int(11) DEFAULT NULL,
  `deposit_to` int(11) DEFAULT NULL,
  `auto_add` int(11) NOT NULL DEFAULT 0,
  `mapping_type` varchar(25) DEFAULT NULL,
  `account` int(11) DEFAULT NULL,
  `split_percentage` text DEFAULT NULL,
  `split_amount` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblacc_banking_rules`
--

LOCK TABLES `abc1_tblacc_banking_rules` WRITE;
/*!40000 ALTER TABLE `abc1_tblacc_banking_rules` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblacc_banking_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblacc_bill_mappings`
--

DROP TABLE IF EXISTS `abc1_tblacc_bill_mappings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblacc_bill_mappings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bill_id` int(11) DEFAULT NULL,
  `type` varchar(25) DEFAULT NULL,
  `account` int(11) DEFAULT NULL,
  `amount` decimal(15,2) DEFAULT NULL,
  `item_id` int(11) NOT NULL DEFAULT 0,
  `qty` decimal(15,2) NOT NULL DEFAULT 0.00,
  `cost` decimal(15,2) NOT NULL DEFAULT 0.00,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblacc_bill_mappings`
--

LOCK TABLES `abc1_tblacc_bill_mappings` WRITE;
/*!40000 ALTER TABLE `abc1_tblacc_bill_mappings` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblacc_bill_mappings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblacc_budget_details`
--

DROP TABLE IF EXISTS `abc1_tblacc_budget_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblacc_budget_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `budget_id` int(11) NOT NULL,
  `month` int(11) NOT NULL,
  `year` int(11) NOT NULL,
  `account` int(11) DEFAULT NULL,
  `amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblacc_budget_details`
--

LOCK TABLES `abc1_tblacc_budget_details` WRITE;
/*!40000 ALTER TABLE `abc1_tblacc_budget_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblacc_budget_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblacc_budgets`
--

DROP TABLE IF EXISTS `abc1_tblacc_budgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblacc_budgets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `year` int(11) NOT NULL,
  `name` varchar(200) DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  `data_source` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblacc_budgets`
--

LOCK TABLES `abc1_tblacc_budgets` WRITE;
/*!40000 ALTER TABLE `abc1_tblacc_budgets` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblacc_budgets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblacc_check_details`
--

DROP TABLE IF EXISTS `abc1_tblacc_check_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblacc_check_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `check_id` int(11) DEFAULT NULL,
  `bill` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblacc_check_details`
--

LOCK TABLES `abc1_tblacc_check_details` WRITE;
/*!40000 ALTER TABLE `abc1_tblacc_check_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblacc_check_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblacc_checks`
--

DROP TABLE IF EXISTS `abc1_tblacc_checks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblacc_checks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(25) DEFAULT NULL,
  `amount` decimal(15,2) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `memo` varchar(255) DEFAULT NULL,
  `dateadded` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `bank_account` int(11) NOT NULL,
  `number` int(11) NOT NULL,
  `signed` int(11) NOT NULL DEFAULT 0,
  `include_company_name_address` int(11) NOT NULL DEFAULT 1,
  `include_routing_account_numbers` int(11) NOT NULL DEFAULT 1,
  `bill` int(11) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `zip` varchar(15) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `issue` int(11) DEFAULT NULL,
  `include_check_number` int(11) NOT NULL DEFAULT 1,
  `include_bank_name` int(11) NOT NULL DEFAULT 1,
  `bank_name` varchar(255) DEFAULT NULL,
  `address_line_1` text DEFAULT NULL,
  `address_line_2` text DEFAULT NULL,
  `vendor_city` varchar(100) DEFAULT NULL,
  `vendor_zip` varchar(15) DEFAULT NULL,
  `vendor_state` varchar(50) DEFAULT NULL,
  `vendor_address` text DEFAULT NULL,
  `reason_for_void` text DEFAULT NULL,
  `bill_items` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblacc_checks`
--

LOCK TABLES `abc1_tblacc_checks` WRITE;
/*!40000 ALTER TABLE `abc1_tblacc_checks` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblacc_checks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblacc_checks_printed`
--

DROP TABLE IF EXISTS `abc1_tblacc_checks_printed`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblacc_checks_printed` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `check_id` int(11) DEFAULT NULL,
  `bank_account` int(11) DEFAULT NULL,
  `first_check_number` int(11) DEFAULT NULL,
  `printed_at` datetime DEFAULT NULL,
  `printed_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblacc_checks_printed`
--

LOCK TABLES `abc1_tblacc_checks_printed` WRITE;
/*!40000 ALTER TABLE `abc1_tblacc_checks_printed` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblacc_checks_printed` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblacc_expense_category_mapping_details`
--

DROP TABLE IF EXISTS `abc1_tblacc_expense_category_mapping_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblacc_expense_category_mapping_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_mapping_id` int(11) NOT NULL,
  `payment_mode_id` int(11) NOT NULL,
  `payment_account` int(11) NOT NULL DEFAULT 0,
  `deposit_to` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblacc_expense_category_mapping_details`
--

LOCK TABLES `abc1_tblacc_expense_category_mapping_details` WRITE;
/*!40000 ALTER TABLE `abc1_tblacc_expense_category_mapping_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblacc_expense_category_mapping_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblacc_expense_category_mappings`
--

DROP TABLE IF EXISTS `abc1_tblacc_expense_category_mappings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblacc_expense_category_mappings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `payment_account` int(11) NOT NULL DEFAULT 0,
  `deposit_to` int(11) NOT NULL DEFAULT 0,
  `preferred_payment_method` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblacc_expense_category_mappings`
--

LOCK TABLES `abc1_tblacc_expense_category_mappings` WRITE;
/*!40000 ALTER TABLE `abc1_tblacc_expense_category_mappings` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblacc_expense_category_mappings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblacc_income_statement_modifications`
--

DROP TABLE IF EXISTS `abc1_tblacc_income_statement_modifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblacc_income_statement_modifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `account` int(11) DEFAULT NULL,
  `active` int(11) NOT NULL DEFAULT 1,
  `account_type` int(11) DEFAULT NULL,
  `options` text DEFAULT NULL,
  `dateadded` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `type` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblacc_income_statement_modifications`
--

LOCK TABLES `abc1_tblacc_income_statement_modifications` WRITE;
/*!40000 ALTER TABLE `abc1_tblacc_income_statement_modifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblacc_income_statement_modifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblacc_item_automatics`
--

DROP TABLE IF EXISTS `abc1_tblacc_item_automatics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblacc_item_automatics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL,
  `inventory_asset_account` int(11) NOT NULL DEFAULT 0,
  `income_account` int(11) NOT NULL DEFAULT 0,
  `expense_account` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblacc_item_automatics`
--

LOCK TABLES `abc1_tblacc_item_automatics` WRITE;
/*!40000 ALTER TABLE `abc1_tblacc_item_automatics` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblacc_item_automatics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblacc_journal_entries`
--

DROP TABLE IF EXISTS `abc1_tblacc_journal_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblacc_journal_entries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `number` varchar(45) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `journal_date` date DEFAULT NULL,
  `amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `reference` varchar(100) DEFAULT NULL,
  `recurring` int(11) NOT NULL DEFAULT 0,
  `recurring_type` varchar(10) DEFAULT NULL,
  `custom_recurring` tinyint(1) NOT NULL DEFAULT 0,
  `cycles` int(11) NOT NULL DEFAULT 0,
  `total_cycles` int(11) NOT NULL DEFAULT 0,
  `is_recurring_from` int(11) DEFAULT NULL,
  `last_recurring_date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblacc_journal_entries`
--

LOCK TABLES `abc1_tblacc_journal_entries` WRITE;
/*!40000 ALTER TABLE `abc1_tblacc_journal_entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblacc_journal_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblacc_matched_transactions`
--

DROP TABLE IF EXISTS `abc1_tblacc_matched_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblacc_matched_transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_history_id` int(11) DEFAULT NULL,
  `history_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(255) DEFAULT NULL,
  `amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `company` int(11) DEFAULT NULL,
  `reconcile` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblacc_matched_transactions`
--

LOCK TABLES `abc1_tblacc_matched_transactions` WRITE;
/*!40000 ALTER TABLE `abc1_tblacc_matched_transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblacc_matched_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblacc_pay_bill_details`
--

DROP TABLE IF EXISTS `abc1_tblacc_pay_bill_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblacc_pay_bill_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pay_bill` int(11) DEFAULT NULL,
  `bill_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblacc_pay_bill_details`
--

LOCK TABLES `abc1_tblacc_pay_bill_details` WRITE;
/*!40000 ALTER TABLE `abc1_tblacc_pay_bill_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblacc_pay_bill_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblacc_pay_bill_item_paid`
--

DROP TABLE IF EXISTS `abc1_tblacc_pay_bill_item_paid`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblacc_pay_bill_item_paid` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pay_bill_id` int(11) NOT NULL DEFAULT 0,
  `item_id` int(11) DEFAULT NULL,
  `item_name` varchar(255) DEFAULT NULL,
  `item_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `amount_paid` decimal(15,2) NOT NULL DEFAULT 0.00,
  `check_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblacc_pay_bill_item_paid`
--

LOCK TABLES `abc1_tblacc_pay_bill_item_paid` WRITE;
/*!40000 ALTER TABLE `abc1_tblacc_pay_bill_item_paid` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblacc_pay_bill_item_paid` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblacc_pay_bills`
--

DROP TABLE IF EXISTS `abc1_tblacc_pay_bills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblacc_pay_bills` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `expense` int(11) DEFAULT NULL,
  `amount` decimal(15,2) DEFAULT NULL,
  `reference_no` varchar(100) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `dateadded` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `company` int(11) DEFAULT NULL,
  `account_debit` int(11) DEFAULT NULL,
  `account_credit` int(11) DEFAULT NULL,
  `bill` int(11) NOT NULL DEFAULT 0,
  `vendor` int(11) NOT NULL DEFAULT 0,
  `pay_number` int(11) DEFAULT NULL,
  `payment_method` varchar(255) DEFAULT NULL,
  `bill_items` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblacc_pay_bills`
--

LOCK TABLES `abc1_tblacc_pay_bills` WRITE;
/*!40000 ALTER TABLE `abc1_tblacc_pay_bills` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblacc_pay_bills` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblacc_payment_mode_mappings`
--

DROP TABLE IF EXISTS `abc1_tblacc_payment_mode_mappings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblacc_payment_mode_mappings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `payment_mode_id` int(11) NOT NULL,
  `payment_account` int(11) NOT NULL DEFAULT 0,
  `deposit_to` int(11) NOT NULL DEFAULT 0,
  `expense_payment_account` int(11) NOT NULL DEFAULT 0,
  `expense_deposit_to` int(11) NOT NULL DEFAULT 0,
  `credit_note_refund_payment_account` int(11) NOT NULL DEFAULT 0,
  `credit_note_refund_deposit_to` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblacc_payment_mode_mappings`
--

LOCK TABLES `abc1_tblacc_payment_mode_mappings` WRITE;
/*!40000 ALTER TABLE `abc1_tblacc_payment_mode_mappings` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblacc_payment_mode_mappings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblacc_plaid_transaction_logs`
--

DROP TABLE IF EXISTS `abc1_tblacc_plaid_transaction_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblacc_plaid_transaction_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bank_id` int(11) DEFAULT NULL,
  `last_updated` date DEFAULT NULL,
  `transaction_count` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `addedFrom` int(11) DEFAULT NULL,
  `company` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblacc_plaid_transaction_logs`
--

LOCK TABLES `abc1_tblacc_plaid_transaction_logs` WRITE;
/*!40000 ALTER TABLE `abc1_tblacc_plaid_transaction_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblacc_plaid_transaction_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblacc_print_later`
--

DROP TABLE IF EXISTS `abc1_tblacc_print_later`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblacc_print_later` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(45) DEFAULT NULL,
  `account` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblacc_print_later`
--

LOCK TABLES `abc1_tblacc_print_later` WRITE;
/*!40000 ALTER TABLE `abc1_tblacc_print_later` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblacc_print_later` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblacc_reconciles`
--

DROP TABLE IF EXISTS `abc1_tblacc_reconciles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblacc_reconciles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account` int(11) NOT NULL,
  `beginning_balance` decimal(15,2) NOT NULL,
  `ending_balance` decimal(15,2) NOT NULL,
  `ending_date` date NOT NULL,
  `expense_date` date DEFAULT NULL,
  `service_charge` decimal(15,2) DEFAULT NULL,
  `expense_account` int(11) DEFAULT NULL,
  `income_date` date DEFAULT NULL,
  `interest_earned` decimal(15,2) DEFAULT NULL,
  `income_account` int(11) DEFAULT NULL,
  `finish` int(11) NOT NULL DEFAULT 0,
  `opening_balance` int(11) NOT NULL DEFAULT 0,
  `debits_for_period` decimal(15,2) DEFAULT NULL,
  `credits_for_period` decimal(15,2) DEFAULT NULL,
  `dateadded` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblacc_reconciles`
--

LOCK TABLES `abc1_tblacc_reconciles` WRITE;
/*!40000 ALTER TABLE `abc1_tblacc_reconciles` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblacc_reconciles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblacc_tax_mappings`
--

DROP TABLE IF EXISTS `abc1_tblacc_tax_mappings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblacc_tax_mappings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tax_id` int(11) NOT NULL,
  `payment_account` int(11) NOT NULL DEFAULT 0,
  `deposit_to` int(11) NOT NULL DEFAULT 0,
  `expense_payment_account` int(11) NOT NULL DEFAULT 0,
  `expense_deposit_to` int(11) NOT NULL DEFAULT 0,
  `purchase_payment_account` int(11) NOT NULL DEFAULT 0,
  `purchase_deposit_to` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblacc_tax_mappings`
--

LOCK TABLES `abc1_tblacc_tax_mappings` WRITE;
/*!40000 ALTER TABLE `abc1_tblacc_tax_mappings` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblacc_tax_mappings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblacc_transaction_bankings`
--

DROP TABLE IF EXISTS `abc1_tblacc_transaction_bankings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblacc_transaction_bankings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `withdrawals` decimal(15,2) NOT NULL DEFAULT 0.00,
  `deposits` decimal(15,2) NOT NULL DEFAULT 0.00,
  `payee` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `transaction_id` varchar(150) DEFAULT NULL,
  `bank_id` int(11) DEFAULT NULL,
  `status` tinyint(5) NOT NULL DEFAULT 0 COMMENT '1=>posted, 2=>pending',
  `matched` int(11) NOT NULL DEFAULT 0,
  `reconcile` int(11) NOT NULL DEFAULT 0,
  `adjusted` int(11) NOT NULL DEFAULT 0,
  `is_imported` int(11) NOT NULL DEFAULT 0,
  `banking_rule` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblacc_transaction_bankings`
--

LOCK TABLES `abc1_tblacc_transaction_bankings` WRITE;
/*!40000 ALTER TABLE `abc1_tblacc_transaction_bankings` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblacc_transaction_bankings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblacc_transfers`
--

DROP TABLE IF EXISTS `abc1_tblacc_transfers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblacc_transfers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transfer_funds_from` int(11) NOT NULL,
  `transfer_funds_to` int(11) NOT NULL,
  `transfer_amount` decimal(15,2) DEFAULT NULL,
  `date` varchar(45) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblacc_transfers`
--

LOCK TABLES `abc1_tblacc_transfers` WRITE;
/*!40000 ALTER TABLE `abc1_tblacc_transfers` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblacc_transfers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblaccount_planning`
--

DROP TABLE IF EXISTS `abc1_tblaccount_planning`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblaccount_planning` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) NOT NULL,
  `vision` varchar(255) DEFAULT NULL,
  `mission` varchar(255) DEFAULT NULL,
  `lead_generation` varchar(45) DEFAULT NULL,
  `current_service_know_pmax` varchar(45) DEFAULT NULL,
  `current_service_facebook` varchar(45) DEFAULT NULL,
  `current_service_sem` varchar(45) DEFAULT NULL,
  `objectives` varchar(255) DEFAULT NULL,
  `threat` varchar(255) DEFAULT NULL,
  `opportunity` varchar(255) DEFAULT NULL,
  `criteria_to_success` varchar(255) DEFAULT NULL,
  `constraints` varchar(255) DEFAULT NULL,
  `data_tree` longtext DEFAULT NULL,
  `latest_update` date DEFAULT NULL,
  `new_update` date DEFAULT NULL,
  `product` varchar(255) DEFAULT NULL,
  `sale_channel_online` varchar(255) DEFAULT NULL,
  `sale_channel_offline` varchar(255) DEFAULT NULL,
  `revenue_next_year` varchar(255) DEFAULT NULL,
  `wallet_share` varchar(255) DEFAULT NULL,
  `client_status` varchar(255) DEFAULT NULL,
  `bcg_model` varchar(255) DEFAULT NULL,
  `margin` varchar(255) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblaccount_planning`
--

LOCK TABLES `abc1_tblaccount_planning` WRITE;
/*!40000 ALTER TABLE `abc1_tblaccount_planning` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblaccount_planning` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblaccount_planning_current_service`
--

DROP TABLE IF EXISTS `abc1_tblaccount_planning_current_service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblaccount_planning_current_service` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_planning_id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `potential` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblaccount_planning_current_service`
--

LOCK TABLES `abc1_tblaccount_planning_current_service` WRITE;
/*!40000 ALTER TABLE `abc1_tblaccount_planning_current_service` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblaccount_planning_current_service` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblaccount_planning_financial`
--

DROP TABLE IF EXISTS `abc1_tblaccount_planning_financial`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblaccount_planning_financial` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_planning_id` int(11) NOT NULL,
  `year` varchar(45) DEFAULT NULL,
  `revenue` varchar(255) DEFAULT NULL,
  `sales_spent` varchar(255) DEFAULT NULL,
  `traffic` varchar(255) DEFAULT NULL,
  `loss` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblaccount_planning_financial`
--

LOCK TABLES `abc1_tblaccount_planning_financial` WRITE;
/*!40000 ALTER TABLE `abc1_tblaccount_planning_financial` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblaccount_planning_financial` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblaccount_planning_items`
--

DROP TABLE IF EXISTS `abc1_tblaccount_planning_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblaccount_planning_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_planning_id` int(11) NOT NULL,
  `objective_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `datecreated` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblaccount_planning_items`
--

LOCK TABLES `abc1_tblaccount_planning_items` WRITE;
/*!40000 ALTER TABLE `abc1_tblaccount_planning_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblaccount_planning_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblaccount_planning_marketing_activities`
--

DROP TABLE IF EXISTS `abc1_tblaccount_planning_marketing_activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblaccount_planning_marketing_activities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_planning_id` int(11) NOT NULL,
  `item` varchar(255) DEFAULT NULL,
  `reference` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblaccount_planning_marketing_activities`
--

LOCK TABLES `abc1_tblaccount_planning_marketing_activities` WRITE;
/*!40000 ALTER TABLE `abc1_tblaccount_planning_marketing_activities` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblaccount_planning_marketing_activities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblaccount_planning_objective`
--

DROP TABLE IF EXISTS `abc1_tblaccount_planning_objective`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblaccount_planning_objective` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_planning_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `datecreated` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblaccount_planning_objective`
--

LOCK TABLES `abc1_tblaccount_planning_objective` WRITE;
/*!40000 ALTER TABLE `abc1_tblaccount_planning_objective` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblaccount_planning_objective` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblaccount_planning_service_ability_offering`
--

DROP TABLE IF EXISTS `abc1_tblaccount_planning_service_ability_offering`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblaccount_planning_service_ability_offering` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_planning_id` int(11) NOT NULL,
  `service` varchar(255) DEFAULT NULL,
  `potential` varchar(255) DEFAULT NULL,
  `scale` varchar(255) DEFAULT NULL,
  `convert` varchar(255) DEFAULT NULL,
  `prioritization` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblaccount_planning_service_ability_offering`
--

LOCK TABLES `abc1_tblaccount_planning_service_ability_offering` WRITE;
/*!40000 ALTER TABLE `abc1_tblaccount_planning_service_ability_offering` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblaccount_planning_service_ability_offering` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblaccount_planning_task`
--

DROP TABLE IF EXISTS `abc1_tblaccount_planning_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblaccount_planning_task` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL,
  `account_planning_id` int(11) DEFAULT NULL,
  `action_needed` varchar(255) NOT NULL,
  `prioritization` varchar(255) DEFAULT NULL,
  `pic` varchar(255) DEFAULT NULL,
  `deadline` date DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `objective` varchar(255) DEFAULT NULL,
  `item` varchar(255) DEFAULT NULL,
  `convert_to_task` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblaccount_planning_task`
--

LOCK TABLES `abc1_tblaccount_planning_task` WRITE;
/*!40000 ALTER TABLE `abc1_tblaccount_planning_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblaccount_planning_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblaccount_planning_team`
--

DROP TABLE IF EXISTS `abc1_tblaccount_planning_team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblaccount_planning_team` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_planning_id` int(11) NOT NULL,
  `rel_id` varchar(45) NOT NULL,
  `rel_type` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblaccount_planning_team`
--

LOCK TABLES `abc1_tblaccount_planning_team` WRITE;
/*!40000 ALTER TABLE `abc1_tblaccount_planning_team` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblaccount_planning_team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblactivity_log`
--

DROP TABLE IF EXISTS `abc1_tblactivity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblactivity_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` longtext NOT NULL,
  `date` datetime NOT NULL,
  `staffid` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ehsan_staffid` (`staffid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblactivity_log`
--

LOCK TABLES `abc1_tblactivity_log` WRITE;
/*!40000 ALTER TABLE `abc1_tblactivity_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblactivity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblaffiliate_m_affiliates`
--

DROP TABLE IF EXISTS `abc1_tblaffiliate_m_affiliates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblaffiliate_m_affiliates` (
  `affiliate_id` int(11) NOT NULL AUTO_INCREMENT,
  `affiliate_slug` varchar(255) NOT NULL,
  `group_id` varchar(255) DEFAULT NULL,
  `contact_id` int(11) NOT NULL,
  `total_earnings` decimal(10,2) DEFAULT 0.00,
  `balance` decimal(10,2) DEFAULT 0.00,
  `status` varchar(255) DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`affiliate_id`),
  UNIQUE KEY `unique_ehsan_tbl_contact_id` (`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblaffiliate_m_affiliates`
--

LOCK TABLES `abc1_tblaffiliate_m_affiliates` WRITE;
/*!40000 ALTER TABLE `abc1_tblaffiliate_m_affiliates` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblaffiliate_m_affiliates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblaffiliate_m_commissions`
--

DROP TABLE IF EXISTS `abc1_tblaffiliate_m_commissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblaffiliate_m_commissions` (
  `commission_id` int(11) NOT NULL AUTO_INCREMENT,
  `referral_id` int(11) NOT NULL,
  `affiliate_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `payment_id` int(11) DEFAULT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `rule_info` varchar(255) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`commission_id`),
  KEY `fk_ehsan_tbl_commission_referral_id` (`referral_id`),
  KEY `fk_ehsan_tbl_commission_affiliate_id` (`affiliate_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblaffiliate_m_commissions`
--

LOCK TABLES `abc1_tblaffiliate_m_commissions` WRITE;
/*!40000 ALTER TABLE `abc1_tblaffiliate_m_commissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblaffiliate_m_commissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblaffiliate_m_payouts`
--

DROP TABLE IF EXISTS `abc1_tblaffiliate_m_payouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblaffiliate_m_payouts` (
  `payout_id` int(11) NOT NULL AUTO_INCREMENT,
  `affiliate_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `note_for_affiliate` text DEFAULT NULL,
  `note_for_admin` text DEFAULT NULL,
  `payout_method` varchar(255) NOT NULL,
  `status` varchar(255) DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`payout_id`),
  KEY `fk_ehsan_tbl_afm_payout_affiliate_id` (`affiliate_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblaffiliate_m_payouts`
--

LOCK TABLES `abc1_tblaffiliate_m_payouts` WRITE;
/*!40000 ALTER TABLE `abc1_tblaffiliate_m_payouts` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblaffiliate_m_payouts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblaffiliate_m_referrals`
--

DROP TABLE IF EXISTS `abc1_tblaffiliate_m_referrals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblaffiliate_m_referrals` (
  `referral_id` int(11) NOT NULL AUTO_INCREMENT,
  `affiliate_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `ua` text DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`referral_id`),
  UNIQUE KEY `unique_ehsan_tbl_client_id` (`client_id`),
  KEY `fk_ehsan_tbl_referral_affiliate_id` (`affiliate_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblaffiliate_m_referrals`
--

LOCK TABLES `abc1_tblaffiliate_m_referrals` WRITE;
/*!40000 ALTER TABLE `abc1_tblaffiliate_m_referrals` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblaffiliate_m_referrals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblaffiliate_m_tracking`
--

DROP TABLE IF EXISTS `abc1_tblaffiliate_m_tracking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblaffiliate_m_tracking` (
  `tracking_id` int(11) NOT NULL AUTO_INCREMENT,
  `affiliate_slug` varchar(255) NOT NULL,
  `rel_type` varchar(255) NOT NULL,
  `rel_id` int(11) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phonenumber` varchar(255) DEFAULT NULL,
  `metadata` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`tracking_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblaffiliate_m_tracking`
--

LOCK TABLES `abc1_tblaffiliate_m_tracking` WRITE;
/*!40000 ALTER TABLE `abc1_tblaffiliate_m_tracking` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblaffiliate_m_tracking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblannouncements`
--

DROP TABLE IF EXISTS `abc1_tblannouncements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblannouncements` (
  `announcementid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `message` mediumtext DEFAULT NULL,
  `showtousers` int(11) NOT NULL,
  `showtostaff` int(11) NOT NULL,
  `showname` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  `userid` varchar(100) NOT NULL,
  PRIMARY KEY (`announcementid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblannouncements`
--

LOCK TABLES `abc1_tblannouncements` WRITE;
/*!40000 ALTER TABLE `abc1_tblannouncements` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblannouncements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblappointly_appointment_types`
--

DROP TABLE IF EXISTS `abc1_tblappointly_appointment_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblappointly_appointment_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(191) NOT NULL,
  `color` varchar(191) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblappointly_appointment_types`
--

LOCK TABLES `abc1_tblappointly_appointment_types` WRITE;
/*!40000 ALTER TABLE `abc1_tblappointly_appointment_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblappointly_appointment_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblappointly_appointments`
--

DROP TABLE IF EXISTS `abc1_tblappointly_appointments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblappointly_appointments` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `google_event_id` varchar(191) DEFAULT NULL,
  `google_calendar_link` varchar(191) DEFAULT NULL,
  `google_meet_link` varchar(191) DEFAULT NULL,
  `google_added_by_id` int(11) DEFAULT NULL,
  `outlook_event_id` varchar(191) DEFAULT NULL,
  `outlook_calendar_link` varchar(255) DEFAULT NULL,
  `outlook_added_by_id` int(11) DEFAULT NULL,
  `subject` varchar(191) NOT NULL,
  `description` text DEFAULT NULL,
  `email` varchar(191) DEFAULT NULL,
  `name` varchar(191) DEFAULT NULL,
  `phone` varchar(191) DEFAULT NULL,
  `address` varchar(191) DEFAULT NULL,
  `notes` longtext DEFAULT NULL,
  `contact_id` int(11) DEFAULT NULL,
  `by_sms` tinyint(1) DEFAULT NULL,
  `by_email` tinyint(1) DEFAULT NULL,
  `hash` varchar(191) DEFAULT NULL,
  `notification_date` datetime DEFAULT NULL,
  `external_notification_date` datetime DEFAULT NULL,
  `date` date NOT NULL,
  `start_hour` varchar(191) NOT NULL,
  `approved` tinyint(1) NOT NULL DEFAULT 0,
  `created_by` int(11) DEFAULT NULL,
  `reminder_before` int(11) DEFAULT NULL,
  `reminder_before_type` varchar(10) DEFAULT NULL,
  `finished` tinyint(1) NOT NULL DEFAULT 0,
  `cancelled` tinyint(1) NOT NULL DEFAULT 0,
  `cancel_notes` text DEFAULT NULL,
  `source` varchar(191) DEFAULT NULL,
  `type_id` int(11) NOT NULL DEFAULT 0,
  `feedback` smallint(6) DEFAULT NULL,
  `feedback_comment` text DEFAULT NULL,
  `recurring` int(11) NOT NULL DEFAULT 0,
  `recurring_type` varchar(10) DEFAULT NULL,
  `repeat_every` int(11) DEFAULT NULL,
  `custom_recurring` tinyint(4) NOT NULL,
  `cycles` int(11) NOT NULL DEFAULT 0,
  `total_cycles` int(11) NOT NULL DEFAULT 0,
  `last_recurring_date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblappointly_appointments`
--

LOCK TABLES `abc1_tblappointly_appointments` WRITE;
/*!40000 ALTER TABLE `abc1_tblappointly_appointments` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblappointly_appointments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblappointly_attendees`
--

DROP TABLE IF EXISTS `abc1_tblappointly_attendees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblappointly_attendees` (
  `staff_id` int(11) NOT NULL,
  `appointment_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblappointly_attendees`
--

LOCK TABLES `abc1_tblappointly_attendees` WRITE;
/*!40000 ALTER TABLE `abc1_tblappointly_attendees` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblappointly_attendees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblappointly_callbacks`
--

DROP TABLE IF EXISTS `abc1_tblappointly_callbacks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblappointly_callbacks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `call_type` varchar(191) NOT NULL,
  `phone_number` varchar(191) NOT NULL,
  `timezone` varchar(191) NOT NULL,
  `firstname` varchar(191) NOT NULL,
  `lastname` varchar(191) NOT NULL,
  `status` varchar(191) NOT NULL DEFAULT '1',
  `message` text NOT NULL,
  `email` varchar(191) NOT NULL,
  `date_start` datetime NOT NULL,
  `date_end` datetime NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblappointly_callbacks`
--

LOCK TABLES `abc1_tblappointly_callbacks` WRITE;
/*!40000 ALTER TABLE `abc1_tblappointly_callbacks` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblappointly_callbacks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblappointly_callbacks_assignees`
--

DROP TABLE IF EXISTS `abc1_tblappointly_callbacks_assignees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblappointly_callbacks_assignees` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `callbackid` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblappointly_callbacks_assignees`
--

LOCK TABLES `abc1_tblappointly_callbacks_assignees` WRITE;
/*!40000 ALTER TABLE `abc1_tblappointly_callbacks_assignees` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblappointly_callbacks_assignees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblappointly_google`
--

DROP TABLE IF EXISTS `abc1_tblappointly_google`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblappointly_google` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `access_token` varchar(191) NOT NULL,
  `refresh_token` varchar(191) NOT NULL,
  `expires_in` varchar(191) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblappointly_google`
--

LOCK TABLES `abc1_tblappointly_google` WRITE;
/*!40000 ALTER TABLE `abc1_tblappointly_google` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblappointly_google` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblbom_scrap`
--

DROP TABLE IF EXISTS `abc1_tblbom_scrap`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblbom_scrap` (
  `ScrapID` int(11) NOT NULL,
  `product_id` int(255) NOT NULL,
  `item_type` int(11) NOT NULL,
  `unit_id` int(255) NOT NULL,
  `scrap_type` enum('reuse','waste') NOT NULL DEFAULT 'waste',
  `estimated_quantity` decimal(10,2) DEFAULT NULL,
  `scrap_location_id` int(11) DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `bill_of_material_id` int(11) NOT NULL,
  `routing_id` int(11) NOT NULL,
  `operation_id` int(11) NOT NULL,
  `bill_of_material_product_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblbom_scrap`
--

LOCK TABLES `abc1_tblbom_scrap` WRITE;
/*!40000 ALTER TABLE `abc1_tblbom_scrap` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblbom_scrap` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblbonus_discipline`
--

DROP TABLE IF EXISTS `abc1_tblbonus_discipline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblbonus_discipline` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `id_criteria` varchar(200) DEFAULT NULL,
  `type` int(3) NOT NULL,
  `apply_for` varchar(50) DEFAULT NULL,
  `from_time` datetime DEFAULT NULL,
  `lever_bonus` int(11) DEFAULT NULL,
  `approver` int(11) DEFAULT NULL,
  `url_file` longtext DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `id_admin` int(3) DEFAULT NULL,
  `status` int(3) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblbonus_discipline`
--

LOCK TABLES `abc1_tblbonus_discipline` WRITE;
/*!40000 ALTER TABLE `abc1_tblbonus_discipline` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblbonus_discipline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblbonus_discipline_detail`
--

DROP TABLE IF EXISTS `abc1_tblbonus_discipline_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblbonus_discipline_detail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_bonus_discipline` int(11) NOT NULL,
  `from_time` datetime DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `department_id` longtext DEFAULT NULL,
  `lever_bonus` int(11) DEFAULT NULL,
  `formality` varchar(50) DEFAULT NULL,
  `formality_value` varchar(100) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblbonus_discipline_detail`
--

LOCK TABLES `abc1_tblbonus_discipline_detail` WRITE;
/*!40000 ALTER TABLE `abc1_tblbonus_discipline_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblbonus_discipline_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblcd_care`
--

DROP TABLE IF EXISTS `abc1_tblcd_care`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblcd_care` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `candidate` int(11) NOT NULL,
  `care_time` datetime NOT NULL,
  `care_result` text NOT NULL,
  `description` text DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  `add_time` datetime DEFAULT NULL,
  `type` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblcd_care`
--

LOCK TABLES `abc1_tblcd_care` WRITE;
/*!40000 ALTER TABLE `abc1_tblcd_care` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblcd_care` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblcd_family_infor`
--

DROP TABLE IF EXISTS `abc1_tblcd_family_infor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblcd_family_infor` (
  `fi_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `candidate` int(11) NOT NULL,
  `relationship` varchar(100) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `fi_birthday` date DEFAULT NULL,
  `job` varchar(200) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `phone` int(15) DEFAULT NULL,
  PRIMARY KEY (`fi_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblcd_family_infor`
--

LOCK TABLES `abc1_tblcd_family_infor` WRITE;
/*!40000 ALTER TABLE `abc1_tblcd_family_infor` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblcd_family_infor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblcd_interview`
--

DROP TABLE IF EXISTS `abc1_tblcd_interview`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblcd_interview` (
  `in_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `candidate` int(11) NOT NULL,
  `interview` int(11) NOT NULL,
  `cd_from_hours` datetime DEFAULT NULL,
  `cd_to_hours` datetime DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`in_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblcd_interview`
--

LOCK TABLES `abc1_tblcd_interview` WRITE;
/*!40000 ALTER TABLE `abc1_tblcd_interview` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblcd_interview` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblcd_literacy`
--

DROP TABLE IF EXISTS `abc1_tblcd_literacy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblcd_literacy` (
  `li_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `candidate` int(11) NOT NULL,
  `literacy_from_date` date DEFAULT NULL,
  `literacy_to_date` date DEFAULT NULL,
  `diploma` varchar(200) DEFAULT NULL,
  `training_places` varchar(200) DEFAULT NULL,
  `specialized` varchar(200) DEFAULT NULL,
  `training_form` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`li_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblcd_literacy`
--

LOCK TABLES `abc1_tblcd_literacy` WRITE;
/*!40000 ALTER TABLE `abc1_tblcd_literacy` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblcd_literacy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblcd_skill`
--

DROP TABLE IF EXISTS `abc1_tblcd_skill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblcd_skill` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `candidate` int(11) NOT NULL,
  `skill_name` text DEFAULT NULL,
  `skill_description` text DEFAULT NULL,
  PRIMARY KEY (`id`,`candidate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblcd_skill`
--

LOCK TABLES `abc1_tblcd_skill` WRITE;
/*!40000 ALTER TABLE `abc1_tblcd_skill` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblcd_skill` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblcd_work_experience`
--

DROP TABLE IF EXISTS `abc1_tblcd_work_experience`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblcd_work_experience` (
  `we_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `candidate` int(11) NOT NULL,
  `from_date` date DEFAULT NULL,
  `to_date` date DEFAULT NULL,
  `company` varchar(200) DEFAULT NULL,
  `position` varchar(200) DEFAULT NULL,
  `contact_person` varchar(200) DEFAULT NULL,
  `salary` varchar(200) DEFAULT NULL,
  `reason_quitwork` varchar(200) DEFAULT NULL,
  `job_description` text DEFAULT NULL,
  PRIMARY KEY (`we_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblcd_work_experience`
--

LOCK TABLES `abc1_tblcd_work_experience` WRITE;
/*!40000 ALTER TABLE `abc1_tblcd_work_experience` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblcd_work_experience` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblcheck_in_out`
--

DROP TABLE IF EXISTS `abc1_tblcheck_in_out`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblcheck_in_out` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `type_check` int(11) DEFAULT NULL,
  `type` varchar(5) NOT NULL DEFAULT 'W',
  `route_point_id` int(11) DEFAULT NULL,
  `workplace_id` int(11) NOT NULL DEFAULT 0,
  `lat` decimal(10,6) DEFAULT NULL,
  `long` decimal(10,6) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `device_type` varchar(100) DEFAULT NULL,
  `device_fingerprint` varchar(255) DEFAULT NULL,
  `distance` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblcheck_in_out`
--

LOCK TABLES `abc1_tblcheck_in_out` WRITE;
/*!40000 ALTER TABLE `abc1_tblcheck_in_out` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblcheck_in_out` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblchecklist`
--

DROP TABLE IF EXISTS `abc1_tblchecklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblchecklist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `group_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblchecklist`
--

LOCK TABLES `abc1_tblchecklist` WRITE;
/*!40000 ALTER TABLE `abc1_tblchecklist` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblchecklist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblchecklist_allocation`
--

DROP TABLE IF EXISTS `abc1_tblchecklist_allocation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblchecklist_allocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `group_id` int(11) DEFAULT NULL,
  `staffid` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblchecklist_allocation`
--

LOCK TABLES `abc1_tblchecklist_allocation` WRITE;
/*!40000 ALTER TABLE `abc1_tblchecklist_allocation` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblchecklist_allocation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblcheckout_history`
--

DROP TABLE IF EXISTS `abc1_tblcheckout_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblcheckout_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `recorded_at` datetime NOT NULL,
  `accuracy_m` decimal(10,2) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `device_id` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblcheckout_history`
--

LOCK TABLES `abc1_tblcheckout_history` WRITE;
/*!40000 ALTER TABLE `abc1_tblcheckout_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblcheckout_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblclients`
--

DROP TABLE IF EXISTS `abc1_tblclients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblclients` (
  `userid` int(11) NOT NULL AUTO_INCREMENT,
  `company` varchar(191) DEFAULT NULL,
  `vat` varchar(50) DEFAULT NULL,
  `phonenumber` varchar(30) DEFAULT NULL,
  `country` int(11) NOT NULL DEFAULT 0,
  `city` varchar(100) DEFAULT NULL,
  `zip` varchar(15) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `address` varchar(191) DEFAULT NULL,
  `website` varchar(150) DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `active` int(11) NOT NULL DEFAULT 1,
  `leadid` int(11) DEFAULT NULL,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT 0,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT 0,
  `longitude` varchar(191) DEFAULT NULL,
  `latitude` varchar(191) DEFAULT NULL,
  `default_language` varchar(40) DEFAULT NULL,
  `default_currency` int(11) NOT NULL DEFAULT 0,
  `show_primary_contact` int(11) NOT NULL DEFAULT 0,
  `stripe_id` varchar(40) DEFAULT NULL,
  `registration_confirmed` int(11) NOT NULL DEFAULT 1,
  `addedfrom` int(11) NOT NULL DEFAULT 0,
  `balance` decimal(15,2) DEFAULT NULL,
  `balance_as_of` date DEFAULT NULL,
  `loy_point` decimal(10,0) DEFAULT 0,
  `sector` varchar(255) DEFAULT NULL,
  `industry` varchar(255) DEFAULT NULL,
  `continue_from_date` date DEFAULT NULL,
  PRIMARY KEY (`userid`),
  KEY `country` (`country`),
  KEY `leadid` (`leadid`),
  KEY `company` (`company`),
  KEY `active` (`active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblclients`
--

LOCK TABLES `abc1_tblclients` WRITE;
/*!40000 ALTER TABLE `abc1_tblclients` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblclients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblconsent_purposes`
--

DROP TABLE IF EXISTS `abc1_tblconsent_purposes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblconsent_purposes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `last_updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblconsent_purposes`
--

LOCK TABLES `abc1_tblconsent_purposes` WRITE;
/*!40000 ALTER TABLE `abc1_tblconsent_purposes` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblconsent_purposes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblconsents`
--

DROP TABLE IF EXISTS `abc1_tblconsents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblconsents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action` varchar(10) NOT NULL,
  `date` datetime NOT NULL,
  `ip` varchar(40) NOT NULL,
  `contact_id` int(11) NOT NULL DEFAULT 0,
  `lead_id` int(11) NOT NULL DEFAULT 0,
  `description` mediumtext DEFAULT NULL,
  `opt_in_purpose_description` mediumtext DEFAULT NULL,
  `purpose_id` int(11) NOT NULL,
  `staff_name` varchar(100) DEFAULT NULL,
  `candidate_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `purpose_id` (`purpose_id`),
  KEY `contact_id` (`contact_id`),
  KEY `lead_id` (`lead_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblconsents`
--

LOCK TABLES `abc1_tblconsents` WRITE;
/*!40000 ALTER TABLE `abc1_tblconsents` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblconsents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblcontact_permissions`
--

DROP TABLE IF EXISTS `abc1_tblcontact_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblcontact_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permission_id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblcontact_permissions`
--

LOCK TABLES `abc1_tblcontact_permissions` WRITE;
/*!40000 ALTER TABLE `abc1_tblcontact_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblcontact_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblcontacts`
--

DROP TABLE IF EXISTS `abc1_tblcontacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblcontacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `is_primary` int(11) NOT NULL DEFAULT 1,
  `firstname` varchar(191) NOT NULL,
  `lastname` varchar(191) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phonenumber` varchar(100) NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `new_pass_key` varchar(32) DEFAULT NULL,
  `new_pass_key_requested` datetime DEFAULT NULL,
  `email_verified_at` datetime DEFAULT NULL,
  `email_verification_key` varchar(32) DEFAULT NULL,
  `email_verification_sent_at` datetime DEFAULT NULL,
  `last_ip` varchar(40) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_password_change` datetime DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `profile_image` varchar(191) DEFAULT NULL,
  `direction` varchar(3) DEFAULT NULL,
  `invoice_emails` tinyint(1) NOT NULL DEFAULT 1,
  `estimate_emails` tinyint(1) NOT NULL DEFAULT 1,
  `credit_note_emails` tinyint(1) NOT NULL DEFAULT 1,
  `contract_emails` tinyint(1) NOT NULL DEFAULT 1,
  `task_emails` tinyint(1) NOT NULL DEFAULT 1,
  `project_emails` tinyint(1) NOT NULL DEFAULT 1,
  `ticket_emails` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `firstname` (`firstname`),
  KEY `lastname` (`lastname`),
  KEY `email` (`email`),
  KEY `is_primary` (`is_primary`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblcontacts`
--

LOCK TABLES `abc1_tblcontacts` WRITE;
/*!40000 ALTER TABLE `abc1_tblcontacts` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblcontacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblcontract_comments`
--

DROP TABLE IF EXISTS `abc1_tblcontract_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblcontract_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` longtext DEFAULT NULL,
  `contract_id` int(11) NOT NULL,
  `staffid` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblcontract_comments`
--

LOCK TABLES `abc1_tblcontract_comments` WRITE;
/*!40000 ALTER TABLE `abc1_tblcontract_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblcontract_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblcontract_renewals`
--

DROP TABLE IF EXISTS `abc1_tblcontract_renewals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblcontract_renewals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contractid` int(11) NOT NULL,
  `old_start_date` date NOT NULL,
  `new_start_date` date NOT NULL,
  `old_end_date` date DEFAULT NULL,
  `new_end_date` date DEFAULT NULL,
  `old_value` decimal(15,2) DEFAULT NULL,
  `new_value` decimal(15,2) DEFAULT NULL,
  `date_renewed` datetime NOT NULL,
  `renewed_by` varchar(100) NOT NULL,
  `renewed_by_staff_id` int(11) NOT NULL DEFAULT 0,
  `is_on_old_expiry_notified` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblcontract_renewals`
--

LOCK TABLES `abc1_tblcontract_renewals` WRITE;
/*!40000 ALTER TABLE `abc1_tblcontract_renewals` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblcontract_renewals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblcontracts`
--

DROP TABLE IF EXISTS `abc1_tblcontracts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblcontracts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` longtext DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `subject` varchar(191) DEFAULT NULL,
  `client` int(11) NOT NULL,
  `datestart` date DEFAULT NULL,
  `dateend` date DEFAULT NULL,
  `contract_type` int(11) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  `isexpirynotified` int(11) NOT NULL DEFAULT 0,
  `contract_value` decimal(15,2) DEFAULT NULL,
  `trash` tinyint(1) DEFAULT 0,
  `not_visible_to_client` tinyint(1) NOT NULL DEFAULT 0,
  `hash` varchar(32) DEFAULT NULL,
  `signed` tinyint(1) NOT NULL DEFAULT 0,
  `signature` varchar(40) DEFAULT NULL,
  `marked_as_signed` tinyint(1) NOT NULL DEFAULT 0,
  `acceptance_firstname` varchar(50) DEFAULT NULL,
  `acceptance_lastname` varchar(50) DEFAULT NULL,
  `acceptance_email` varchar(100) DEFAULT NULL,
  `acceptance_date` datetime DEFAULT NULL,
  `acceptance_ip` varchar(40) DEFAULT NULL,
  `short_link` varchar(100) DEFAULT NULL,
  `last_sent_at` datetime DEFAULT NULL,
  `contacts_sent_to` mediumtext DEFAULT NULL,
  `last_sign_reminder_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `client` (`client`),
  KEY `contract_type` (`contract_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblcontracts`
--

LOCK TABLES `abc1_tblcontracts` WRITE;
/*!40000 ALTER TABLE `abc1_tblcontracts` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblcontracts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblcontracts_types`
--

DROP TABLE IF EXISTS `abc1_tblcontracts_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblcontracts_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblcontracts_types`
--

LOCK TABLES `abc1_tblcontracts_types` WRITE;
/*!40000 ALTER TABLE `abc1_tblcontracts_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblcontracts_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblcountries`
--

DROP TABLE IF EXISTS `abc1_tblcountries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblcountries` (
  `country_id` int(11) NOT NULL AUTO_INCREMENT,
  `iso2` char(2) DEFAULT NULL,
  `short_name` varchar(80) NOT NULL DEFAULT '',
  `long_name` varchar(80) NOT NULL DEFAULT '',
  `iso3` char(3) DEFAULT NULL,
  `numcode` varchar(6) DEFAULT NULL,
  `un_member` varchar(12) DEFAULT NULL,
  `calling_code` varchar(8) DEFAULT NULL,
  `cctld` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`country_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblcountries`
--

LOCK TABLES `abc1_tblcountries` WRITE;
/*!40000 ALTER TABLE `abc1_tblcountries` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblcountries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblcreditnote_refunds`
--

DROP TABLE IF EXISTS `abc1_tblcreditnote_refunds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblcreditnote_refunds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `credit_note_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `refunded_on` date NOT NULL,
  `payment_mode` varchar(40) NOT NULL,
  `note` mediumtext DEFAULT NULL,
  `amount` decimal(15,2) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblcreditnote_refunds`
--

LOCK TABLES `abc1_tblcreditnote_refunds` WRITE;
/*!40000 ALTER TABLE `abc1_tblcreditnote_refunds` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblcreditnote_refunds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblcreditnotes`
--

DROP TABLE IF EXISTS `abc1_tblcreditnotes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblcreditnotes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clientid` int(11) NOT NULL,
  `deleted_customer_name` varchar(100) DEFAULT NULL,
  `number` int(11) NOT NULL,
  `prefix` varchar(50) DEFAULT NULL,
  `number_format` int(11) NOT NULL DEFAULT 1,
  `datecreated` datetime NOT NULL,
  `date` date NOT NULL,
  `adminnote` mediumtext DEFAULT NULL,
  `terms` mediumtext DEFAULT NULL,
  `clientnote` mediumtext DEFAULT NULL,
  `currency` int(11) NOT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `total_tax` decimal(15,2) NOT NULL DEFAULT 0.00,
  `total` decimal(15,2) NOT NULL,
  `adjustment` decimal(15,2) DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `project_id` int(11) NOT NULL DEFAULT 0,
  `discount_percent` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `discount_type` varchar(30) NOT NULL,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT NULL,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT NULL,
  `include_shipping` tinyint(1) NOT NULL,
  `show_shipping_on_credit_note` tinyint(1) NOT NULL DEFAULT 1,
  `show_quantity_as` int(11) NOT NULL DEFAULT 1,
  `reference_no` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `currency` (`currency`),
  KEY `clientid` (`clientid`),
  KEY `project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblcreditnotes`
--

LOCK TABLES `abc1_tblcreditnotes` WRITE;
/*!40000 ALTER TABLE `abc1_tblcreditnotes` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblcreditnotes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblcredits`
--

DROP TABLE IF EXISTS `abc1_tblcredits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblcredits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) NOT NULL,
  `credit_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `date_applied` datetime NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblcredits`
--

LOCK TABLES `abc1_tblcredits` WRITE;
/*!40000 ALTER TABLE `abc1_tblcredits` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblcredits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblcurrencies`
--

DROP TABLE IF EXISTS `abc1_tblcurrencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblcurrencies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `decimal_separator` varchar(5) DEFAULT NULL,
  `thousand_separator` varchar(5) DEFAULT NULL,
  `placement` varchar(10) DEFAULT NULL,
  `isdefault` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblcurrencies`
--

LOCK TABLES `abc1_tblcurrencies` WRITE;
/*!40000 ALTER TABLE `abc1_tblcurrencies` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblcurrencies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblcurrency_rate_logs`
--

DROP TABLE IF EXISTS `abc1_tblcurrency_rate_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblcurrency_rate_logs` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `from_currency_id` int(11) DEFAULT NULL,
  `from_currency_name` varchar(100) DEFAULT NULL,
  `from_currency_rate` decimal(15,6) NOT NULL DEFAULT 0.000000,
  `to_currency_id` int(11) DEFAULT NULL,
  `to_currency_name` varchar(100) DEFAULT NULL,
  `to_currency_rate` decimal(15,6) NOT NULL DEFAULT 0.000000,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblcurrency_rate_logs`
--

LOCK TABLES `abc1_tblcurrency_rate_logs` WRITE;
/*!40000 ALTER TABLE `abc1_tblcurrency_rate_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblcurrency_rate_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblcurrency_rates`
--

DROP TABLE IF EXISTS `abc1_tblcurrency_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblcurrency_rates` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `from_currency_id` int(11) DEFAULT NULL,
  `from_currency_name` varchar(100) DEFAULT NULL,
  `from_currency_rate` decimal(15,6) NOT NULL DEFAULT 0.000000,
  `to_currency_id` int(11) DEFAULT NULL,
  `to_currency_name` varchar(100) DEFAULT NULL,
  `to_currency_rate` decimal(15,6) NOT NULL DEFAULT 0.000000,
  `date_updated` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblcurrency_rates`
--

LOCK TABLES `abc1_tblcurrency_rates` WRITE;
/*!40000 ALTER TABLE `abc1_tblcurrency_rates` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblcurrency_rates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblcustomer_admins`
--

DROP TABLE IF EXISTS `abc1_tblcustomer_admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblcustomer_admins` (
  `staff_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `date_assigned` mediumtext NOT NULL,
  KEY `customer_id` (`customer_id`),
  KEY `ehsan_staff_id` (`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblcustomer_admins`
--

LOCK TABLES `abc1_tblcustomer_admins` WRITE;
/*!40000 ALTER TABLE `abc1_tblcustomer_admins` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblcustomer_admins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblcustomer_groups`
--

DROP TABLE IF EXISTS `abc1_tblcustomer_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblcustomer_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupid` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `groupid` (`groupid`),
  KEY `customer_id` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblcustomer_groups`
--

LOCK TABLES `abc1_tblcustomer_groups` WRITE;
/*!40000 ALTER TABLE `abc1_tblcustomer_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblcustomer_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblcustomers_groups`
--

DROP TABLE IF EXISTS `abc1_tblcustomers_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblcustomers_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `default_discount` decimal(5,2) DEFAULT NULL COMMENT 'Default discount to apply unless item overrides',
  `default_profit_margin` decimal(5,2) DEFAULT NULL COMMENT 'Used to auto-calculate selling price from cost',
  `override_allowed` tinyint(1) DEFAULT 1 COMMENT '1 = allow item-level override, 0 = enforce group defaults only',
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblcustomers_groups`
--

LOCK TABLES `abc1_tblcustomers_groups` WRITE;
/*!40000 ALTER TABLE `abc1_tblcustomers_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblcustomers_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblcustomfields`
--

DROP TABLE IF EXISTS `abc1_tblcustomfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblcustomfields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldto` varchar(30) DEFAULT NULL,
  `name` varchar(150) NOT NULL,
  `slug` varchar(150) NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT 0,
  `type` varchar(20) NOT NULL,
  `options` longtext DEFAULT NULL,
  `display_inline` tinyint(1) NOT NULL DEFAULT 0,
  `field_order` int(11) DEFAULT 0,
  `active` int(11) NOT NULL DEFAULT 1,
  `show_on_pdf` int(11) NOT NULL DEFAULT 0,
  `show_on_ticket_form` tinyint(1) NOT NULL DEFAULT 0,
  `only_admin` tinyint(1) NOT NULL DEFAULT 0,
  `show_on_table` tinyint(1) NOT NULL DEFAULT 0,
  `show_on_client_portal` int(11) NOT NULL DEFAULT 0,
  `disalow_client_to_edit` int(11) NOT NULL DEFAULT 0,
  `bs_column` int(11) NOT NULL DEFAULT 12,
  `default_value` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblcustomfields`
--

LOCK TABLES `abc1_tblcustomfields` WRITE;
/*!40000 ALTER TABLE `abc1_tblcustomfields` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblcustomfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblcustomfieldsvalues`
--

DROP TABLE IF EXISTS `abc1_tblcustomfieldsvalues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblcustomfieldsvalues` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `relid` int(11) NOT NULL,
  `fieldid` int(11) NOT NULL,
  `fieldto` varchar(15) NOT NULL,
  `value` mediumtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `relid` (`relid`),
  KEY `fieldto` (`fieldto`),
  KEY `fieldid` (`fieldid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblcustomfieldsvalues`
--

LOCK TABLES `abc1_tblcustomfieldsvalues` WRITE;
/*!40000 ALTER TABLE `abc1_tblcustomfieldsvalues` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblcustomfieldsvalues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblday_off`
--

DROP TABLE IF EXISTS `abc1_tblday_off`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblday_off` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `off_reason` varchar(255) NOT NULL,
  `off_type` varchar(100) NOT NULL,
  `break_date` date NOT NULL,
  `timekeeping` varchar(45) DEFAULT NULL,
  `department` varchar(45) DEFAULT NULL,
  `position` varchar(45) DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  `repeat_by_year` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblday_off`
--

LOCK TABLES `abc1_tblday_off` WRITE;
/*!40000 ALTER TABLE `abc1_tblday_off` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblday_off` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tbldepartments`
--

DROP TABLE IF EXISTS `abc1_tbldepartments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tbldepartments` (
  `departmentid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `imap_username` varchar(191) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `email_from_header` tinyint(1) NOT NULL DEFAULT 0,
  `host` varchar(150) DEFAULT NULL,
  `password` longtext DEFAULT NULL,
  `encryption` varchar(3) DEFAULT NULL,
  `folder` varchar(191) NOT NULL DEFAULT 'INBOX',
  `delete_after_import` int(11) NOT NULL DEFAULT 0,
  `calendar_id` longtext DEFAULT NULL,
  `hidefromclient` tinyint(1) NOT NULL DEFAULT 0,
  `manager_id` int(11) DEFAULT 0,
  `parent_id` int(11) DEFAULT 0,
  PRIMARY KEY (`departmentid`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tbldepartments`
--

LOCK TABLES `abc1_tbldepartments` WRITE;
/*!40000 ALTER TABLE `abc1_tbldepartments` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tbldepartments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tbldismissed_announcements`
--

DROP TABLE IF EXISTS `abc1_tbldismissed_announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tbldismissed_announcements` (
  `dismissedannouncementid` int(11) NOT NULL AUTO_INCREMENT,
  `announcementid` int(11) NOT NULL,
  `staff` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  PRIMARY KEY (`dismissedannouncementid`),
  KEY `announcementid` (`announcementid`),
  KEY `ehsan_staff` (`staff`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tbldismissed_announcements`
--

LOCK TABLES `abc1_tbldismissed_announcements` WRITE;
/*!40000 ALTER TABLE `abc1_tbldismissed_announcements` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tbldismissed_announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblemaillists`
--

DROP TABLE IF EXISTS `abc1_tblemaillists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblemaillists` (
  `listid` int(11) NOT NULL AUTO_INCREMENT,
  `name` mediumtext NOT NULL,
  `creator` varchar(100) NOT NULL,
  `datecreated` datetime NOT NULL,
  PRIMARY KEY (`listid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblemaillists`
--

LOCK TABLES `abc1_tblemaillists` WRITE;
/*!40000 ALTER TABLE `abc1_tblemaillists` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblemaillists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblemailtemplates`
--

DROP TABLE IF EXISTS `abc1_tblemailtemplates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblemailtemplates` (
  `emailtemplateid` int(11) NOT NULL AUTO_INCREMENT,
  `type` longtext NOT NULL,
  `slug` varchar(100) NOT NULL,
  `language` varchar(40) DEFAULT NULL,
  `name` longtext NOT NULL,
  `subject` longtext NOT NULL,
  `message` longtext NOT NULL,
  `fromname` longtext NOT NULL,
  `fromemail` varchar(100) DEFAULT NULL,
  `plaintext` int(11) NOT NULL DEFAULT 0,
  `active` tinyint(4) NOT NULL DEFAULT 0,
  `order` int(11) NOT NULL,
  PRIMARY KEY (`emailtemplateid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblemailtemplates`
--

LOCK TABLES `abc1_tblemailtemplates` WRITE;
/*!40000 ALTER TABLE `abc1_tblemailtemplates` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblemailtemplates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblestimate_request_forms`
--

DROP TABLE IF EXISTS `abc1_tblestimate_request_forms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblestimate_request_forms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `form_key` varchar(32) NOT NULL,
  `type` varchar(100) NOT NULL,
  `name` varchar(191) NOT NULL,
  `form_data` longtext DEFAULT NULL,
  `recaptcha` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL,
  `submit_btn_name` varchar(100) DEFAULT NULL,
  `submit_btn_bg_color` varchar(10) DEFAULT '#84c529',
  `submit_btn_text_color` varchar(10) DEFAULT '#ffffff',
  `success_submit_msg` mediumtext DEFAULT NULL,
  `submit_action` int(11) DEFAULT 0,
  `submit_redirect_url` longtext DEFAULT NULL,
  `language` varchar(100) DEFAULT NULL,
  `dateadded` datetime DEFAULT NULL,
  `notify_type` varchar(100) DEFAULT NULL,
  `notify_ids` longtext DEFAULT NULL,
  `responsible` int(11) DEFAULT NULL,
  `notify_request_submitted` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblestimate_request_forms`
--

LOCK TABLES `abc1_tblestimate_request_forms` WRITE;
/*!40000 ALTER TABLE `abc1_tblestimate_request_forms` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblestimate_request_forms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblestimate_request_status`
--

DROP TABLE IF EXISTS `abc1_tblestimate_request_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblestimate_request_status` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `statusorder` int(11) DEFAULT NULL,
  `color` varchar(10) DEFAULT NULL,
  `flag` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblestimate_request_status`
--

LOCK TABLES `abc1_tblestimate_request_status` WRITE;
/*!40000 ALTER TABLE `abc1_tblestimate_request_status` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblestimate_request_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblestimate_requests`
--

DROP TABLE IF EXISTS `abc1_tblestimate_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblestimate_requests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `submission` longtext NOT NULL,
  `last_status_change` datetime DEFAULT NULL,
  `date_estimated` datetime DEFAULT NULL,
  `from_form_id` int(11) DEFAULT NULL,
  `assigned` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `default_language` int(11) NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblestimate_requests`
--

LOCK TABLES `abc1_tblestimate_requests` WRITE;
/*!40000 ALTER TABLE `abc1_tblestimate_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblestimate_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblestimates`
--

DROP TABLE IF EXISTS `abc1_tblestimates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblestimates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sent` tinyint(1) NOT NULL DEFAULT 0,
  `datesend` datetime DEFAULT NULL,
  `clientid` int(11) NOT NULL,
  `deleted_customer_name` varchar(100) DEFAULT NULL,
  `project_id` int(11) NOT NULL DEFAULT 0,
  `number` int(11) NOT NULL,
  `prefix` varchar(50) DEFAULT NULL,
  `number_format` int(11) NOT NULL DEFAULT 0,
  `hash` varchar(32) DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `date` date NOT NULL,
  `expirydate` date DEFAULT NULL,
  `currency` int(11) NOT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `total_tax` decimal(15,2) NOT NULL DEFAULT 0.00,
  `total` decimal(15,2) NOT NULL,
  `adjustment` decimal(15,2) DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `clientnote` mediumtext DEFAULT NULL,
  `adminnote` mediumtext DEFAULT NULL,
  `discount_percent` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `discount_type` varchar(30) DEFAULT NULL,
  `invoiceid` int(11) DEFAULT NULL,
  `invoiced_date` datetime DEFAULT NULL,
  `terms` mediumtext DEFAULT NULL,
  `reference_no` varchar(100) DEFAULT NULL,
  `sale_agent` int(11) NOT NULL DEFAULT 0,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT NULL,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT NULL,
  `include_shipping` tinyint(1) NOT NULL,
  `show_shipping_on_estimate` tinyint(1) NOT NULL DEFAULT 1,
  `show_quantity_as` int(11) NOT NULL DEFAULT 1,
  `pipeline_order` int(11) DEFAULT 1,
  `is_expiry_notified` int(11) NOT NULL DEFAULT 0,
  `acceptance_firstname` varchar(50) DEFAULT NULL,
  `acceptance_lastname` varchar(50) DEFAULT NULL,
  `acceptance_email` varchar(100) DEFAULT NULL,
  `acceptance_date` datetime DEFAULT NULL,
  `acceptance_ip` varchar(40) DEFAULT NULL,
  `signature` varchar(40) DEFAULT NULL,
  `short_link` varchar(100) DEFAULT NULL,
  `production_assigned_to` int(11) DEFAULT NULL COMMENT 'Staff ID or user assigned to the production process',
  `production_type` varchar(100) DEFAULT NULL COMMENT 'Type of production process (e.g. in-house, subcontract, etc)',
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `currency` (`currency`),
  KEY `project_id` (`project_id`),
  KEY `sale_agent` (`sale_agent`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblestimates`
--

LOCK TABLES `abc1_tblestimates` WRITE;
/*!40000 ALTER TABLE `abc1_tblestimates` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblestimates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblevents`
--

DROP TABLE IF EXISTS `abc1_tblevents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblevents` (
  `eventid` int(11) NOT NULL AUTO_INCREMENT,
  `title` longtext NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `userid` int(11) NOT NULL,
  `start` datetime NOT NULL,
  `end` datetime DEFAULT NULL,
  `public` int(11) NOT NULL DEFAULT 0,
  `color` varchar(10) DEFAULT NULL,
  `isstartnotified` tinyint(1) NOT NULL DEFAULT 0,
  `reminder_before` int(11) NOT NULL DEFAULT 0,
  `reminder_before_type` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`eventid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblevents`
--

LOCK TABLES `abc1_tblevents` WRITE;
/*!40000 ALTER TABLE `abc1_tblevents` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblevents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblexpenses`
--

DROP TABLE IF EXISTS `abc1_tblexpenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblexpenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` int(11) NOT NULL,
  `currency` int(11) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `tax` int(11) DEFAULT NULL,
  `tax2` int(11) NOT NULL DEFAULT 0,
  `reference_no` varchar(100) DEFAULT NULL,
  `note` mediumtext DEFAULT NULL,
  `expense_name` varchar(191) DEFAULT NULL,
  `clientid` int(11) NOT NULL,
  `project_id` int(11) NOT NULL DEFAULT 0,
  `billable` int(11) DEFAULT 0,
  `invoiceid` int(11) DEFAULT NULL,
  `paymentmode` varchar(50) DEFAULT NULL,
  `date` date NOT NULL,
  `recurring_type` varchar(10) DEFAULT NULL,
  `repeat_every` int(11) DEFAULT NULL,
  `recurring` int(11) NOT NULL DEFAULT 0,
  `cycles` int(11) NOT NULL DEFAULT 0,
  `total_cycles` int(11) NOT NULL DEFAULT 0,
  `custom_recurring` int(11) NOT NULL DEFAULT 0,
  `last_recurring_date` date DEFAULT NULL,
  `create_invoice_billable` tinyint(1) DEFAULT NULL,
  `send_invoice_to_customer` tinyint(1) NOT NULL,
  `recurring_from` int(11) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  `addedfrom` int(11) NOT NULL,
  `vendor` int(11) DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `date_paid` date DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `is_bill` int(11) NOT NULL DEFAULT 0,
  `reason_for_void` text DEFAULT NULL,
  `voided` int(11) NOT NULL DEFAULT 0,
  `approved` int(11) NOT NULL DEFAULT 0,
  `from_fleet` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `project_id` (`project_id`),
  KEY `category` (`category`),
  KEY `currency` (`currency`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblexpenses`
--

LOCK TABLES `abc1_tblexpenses` WRITE;
/*!40000 ALTER TABLE `abc1_tblexpenses` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblexpenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblexpenses_categories`
--

DROP TABLE IF EXISTS `abc1_tblexpenses_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblexpenses_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblexpenses_categories`
--

LOCK TABLES `abc1_tblexpenses_categories` WRITE;
/*!40000 ALTER TABLE `abc1_tblexpenses_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblexpenses_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfe_activity_log`
--

DROP TABLE IF EXISTS `abc1_tblfe_activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfe_activity_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(45) NOT NULL,
  `staffid` int(11) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `note` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfe_activity_log`
--

LOCK TABLES `abc1_tblfe_activity_log` WRITE;
/*!40000 ALTER TABLE `abc1_tblfe_activity_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfe_activity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfe_approval_details`
--

DROP TABLE IF EXISTS `abc1_tblfe_approval_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfe_approval_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(45) NOT NULL,
  `staffid` varchar(45) DEFAULT NULL,
  `approve` varchar(45) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `approve_action` varchar(255) DEFAULT NULL,
  `reject_action` varchar(255) DEFAULT NULL,
  `approve_value` varchar(255) DEFAULT NULL,
  `reject_value` varchar(255) DEFAULT NULL,
  `staff_approve` int(11) DEFAULT NULL,
  `action` varchar(45) DEFAULT NULL,
  `sender` int(11) DEFAULT NULL,
  `date_send` datetime DEFAULT NULL,
  `notification_recipient` longtext DEFAULT NULL,
  `approval_deadline` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfe_approval_details`
--

LOCK TABLES `abc1_tblfe_approval_details` WRITE;
/*!40000 ALTER TABLE `abc1_tblfe_approval_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfe_approval_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfe_approval_setting`
--

DROP TABLE IF EXISTS `abc1_tblfe_approval_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfe_approval_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `related` varchar(255) NOT NULL,
  `setting` longtext NOT NULL,
  `choose_when_approving` int(11) NOT NULL DEFAULT 0,
  `notification_recipient` longtext DEFAULT NULL,
  `number_day_approval` int(11) DEFAULT NULL,
  `departments` text DEFAULT NULL,
  `job_positions` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfe_approval_setting`
--

LOCK TABLES `abc1_tblfe_approval_setting` WRITE;
/*!40000 ALTER TABLE `abc1_tblfe_approval_setting` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfe_approval_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfe_asset_maintenances`
--

DROP TABLE IF EXISTS `abc1_tblfe_asset_maintenances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfe_asset_maintenances` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `asset_id` int(11) DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `maintenance_type` varchar(30) DEFAULT NULL,
  `title` varchar(250) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `completion_date` date DEFAULT NULL,
  `cost` decimal(15,2) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  `warranty_improvement` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfe_asset_maintenances`
--

LOCK TABLES `abc1_tblfe_asset_maintenances` WRITE;
/*!40000 ALTER TABLE `abc1_tblfe_asset_maintenances` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfe_asset_maintenances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfe_asset_manufacturers`
--

DROP TABLE IF EXISTS `abc1_tblfe_asset_manufacturers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfe_asset_manufacturers` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `url` text DEFAULT NULL,
  `support_url` text DEFAULT NULL,
  `support_phone` varchar(50) DEFAULT NULL,
  `support_email` varchar(100) DEFAULT NULL,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  `creator_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfe_asset_manufacturers`
--

LOCK TABLES `abc1_tblfe_asset_manufacturers` WRITE;
/*!40000 ALTER TABLE `abc1_tblfe_asset_manufacturers` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfe_asset_manufacturers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfe_assets`
--

DROP TABLE IF EXISTS `abc1_tblfe_assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfe_assets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `assets_code` varchar(20) DEFAULT NULL,
  `assets_name` varchar(255) DEFAULT NULL,
  `series` varchar(200) DEFAULT NULL,
  `asset_group` int(11) DEFAULT NULL,
  `asset_location` int(11) DEFAULT NULL,
  `model_id` int(11) DEFAULT NULL,
  `date_buy` date DEFAULT NULL,
  `warranty_period` int(11) DEFAULT NULL,
  `unit_price` decimal(15,2) DEFAULT NULL,
  `depreciation` int(11) DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `order_number` varchar(150) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `requestable` int(11) DEFAULT 0,
  `qr_code` varchar(300) DEFAULT NULL,
  `type` varchar(50) NOT NULL DEFAULT 'asset',
  `status` int(11) NOT NULL DEFAULT 1,
  `checkin_out` int(11) NOT NULL DEFAULT 1,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  `quantity` int(11) DEFAULT NULL,
  `min_quantity` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `product_key` text DEFAULT NULL,
  `seats` varchar(50) DEFAULT NULL,
  `model_no` varchar(80) DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `manufacturer_id` int(11) DEFAULT NULL,
  `licensed_to_name` text DEFAULT NULL,
  `licensed_to_email` text DEFAULT NULL,
  `reassignable` int(11) NOT NULL DEFAULT 0,
  `termination_date` date DEFAULT NULL,
  `expiration_date` date DEFAULT NULL,
  `purchase_order_number` varchar(150) DEFAULT NULL,
  `maintained` int(11) NOT NULL DEFAULT 0,
  `item_no` varchar(80) DEFAULT NULL,
  `checkin_out_id` int(11) DEFAULT NULL,
  `active` int(11) NOT NULL DEFAULT 1,
  `selling_price` decimal(15,2) NOT NULL DEFAULT 0.00,
  `rental_price` decimal(15,2) NOT NULL DEFAULT 0.00,
  `for_rent` int(11) NOT NULL DEFAULT 0,
  `for_sell` int(11) NOT NULL DEFAULT 0,
  `renting_period` decimal(15,2) DEFAULT NULL,
  `renting_unit` varchar(10) DEFAULT NULL COMMENT 'hour day week month year',
  `warehouse_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfe_assets`
--

LOCK TABLES `abc1_tblfe_assets` WRITE;
/*!40000 ALTER TABLE `abc1_tblfe_assets` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfe_assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfe_assign_asset_predefined_kits`
--

DROP TABLE IF EXISTS `abc1_tblfe_assign_asset_predefined_kits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfe_assign_asset_predefined_kits` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) DEFAULT NULL,
  `assign_data` text DEFAULT '',
  `parent_id` int(11) DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfe_assign_asset_predefined_kits`
--

LOCK TABLES `abc1_tblfe_assign_asset_predefined_kits` WRITE;
/*!40000 ALTER TABLE `abc1_tblfe_assign_asset_predefined_kits` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfe_assign_asset_predefined_kits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfe_audit_detail_requests`
--

DROP TABLE IF EXISTS `abc1_tblfe_audit_detail_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfe_audit_detail_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `asset_id` int(11) DEFAULT NULL,
  `asset_name` varchar(300) DEFAULT NULL,
  `type` varchar(30) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `adjusted` int(11) DEFAULT NULL,
  `accept` int(11) NOT NULL DEFAULT 0,
  `audit_id` int(11) DEFAULT NULL,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  `maintenance` int(11) NOT NULL DEFAULT 0,
  `maintenance_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfe_audit_detail_requests`
--

LOCK TABLES `abc1_tblfe_audit_detail_requests` WRITE;
/*!40000 ALTER TABLE `abc1_tblfe_audit_detail_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfe_audit_detail_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfe_audit_requests`
--

DROP TABLE IF EXISTS `abc1_tblfe_audit_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfe_audit_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(300) DEFAULT NULL,
  `audit_date` datetime NOT NULL DEFAULT current_timestamp(),
  `auditor` int(11) DEFAULT NULL,
  `asset_location` int(11) DEFAULT NULL,
  `model_id` int(11) DEFAULT NULL,
  `asset_id` text DEFAULT NULL,
  `checkin_checkout_status` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `closed` int(11) NOT NULL DEFAULT 0,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  `from_order` int(11) DEFAULT NULL,
  `creator_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfe_audit_requests`
--

LOCK TABLES `abc1_tblfe_audit_requests` WRITE;
/*!40000 ALTER TABLE `abc1_tblfe_audit_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfe_audit_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfe_cart`
--

DROP TABLE IF EXISTS `abc1_tblfe_cart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfe_cart` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_contact` int(11) NOT NULL,
  `name` varchar(120) NOT NULL,
  `address` varchar(250) NOT NULL,
  `phone_number` varchar(20) NOT NULL,
  `voucher` varchar(100) NOT NULL,
  `status` int(11) DEFAULT 0,
  `complete` int(11) DEFAULT 0,
  `order_number` varchar(100) DEFAULT NULL,
  `channel_id` int(11) DEFAULT NULL,
  `channel` varchar(150) DEFAULT NULL,
  `first_name` varchar(60) DEFAULT NULL,
  `last_name` varchar(60) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `hash` varchar(32) DEFAULT NULL,
  `tax_id` text DEFAULT NULL,
  `tax_rate` text DEFAULT NULL,
  `tax_name` text DEFAULT NULL,
  `unit_id` int(11) DEFAULT NULL,
  `unit_name` varchar(255) DEFAULT NULL,
  `add_discount` decimal(15,2) DEFAULT 0.00,
  `company` varchar(150) DEFAULT NULL,
  `phonenumber` varchar(15) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL,
  `zip` varchar(50) DEFAULT NULL,
  `billing_street` varchar(150) DEFAULT NULL,
  `billing_city` varchar(50) DEFAULT NULL,
  `billing_state` varchar(50) DEFAULT NULL,
  `billing_country` varchar(50) DEFAULT NULL,
  `billing_zip` varchar(50) DEFAULT NULL,
  `shipping_street` varchar(150) DEFAULT NULL,
  `shipping_city` varchar(50) DEFAULT NULL,
  `shipping_state` varchar(50) DEFAULT NULL,
  `shipping_country` varchar(50) DEFAULT NULL,
  `shipping_zip` varchar(50) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `reason` varchar(250) DEFAULT NULL,
  `admin_action` int(11) DEFAULT 0,
  `discount` varchar(250) DEFAULT NULL,
  `discount_type` int(11) DEFAULT 0,
  `total` varchar(250) DEFAULT NULL,
  `sub_total` varchar(250) DEFAULT NULL,
  `discount_total` decimal(15,2) NOT NULL DEFAULT 0.00,
  `invoice` varchar(250) NOT NULL DEFAULT '',
  `number_invoice` varchar(250) NOT NULL DEFAULT '',
  `stock_export_number` varchar(250) NOT NULL DEFAULT '',
  `create_invoice` varchar(5) NOT NULL DEFAULT 'off',
  `stock_export` varchar(5) NOT NULL DEFAULT 'off',
  `customers_pay` decimal(15,2) NOT NULL DEFAULT 0.00,
  `amount_returned` decimal(15,2) NOT NULL DEFAULT 0.00,
  `tax` decimal(15,2) NOT NULL DEFAULT 0.00,
  `seller` int(11) DEFAULT NULL,
  `staff_note` text DEFAULT NULL,
  `payment_note` text DEFAULT NULL,
  `allowed_payment_modes` varchar(200) DEFAULT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `shipping` decimal(15,2) NOT NULL DEFAULT 0.00,
  `payment_method_title` varchar(250) DEFAULT NULL,
  `discount_type_str` text DEFAULT NULL,
  `discount_percent` decimal(15,2) DEFAULT NULL,
  `adjustment` decimal(15,2) DEFAULT NULL,
  `currency` int(11) DEFAULT NULL,
  `terms` text DEFAULT NULL,
  `shipping_tax` decimal(15,2) DEFAULT NULL,
  `enable` int(11) NOT NULL DEFAULT 1,
  `duedate` date DEFAULT NULL,
  `shipping_tax_json` varchar(150) DEFAULT NULL,
  `discount_voucher` varchar(150) DEFAULT NULL,
  `original_order_id` int(11) DEFAULT NULL,
  `return_reason` longtext DEFAULT NULL,
  `approve_status` int(11) NOT NULL DEFAULT 0,
  `process_invoice` varchar(5) NOT NULL DEFAULT 'off',
  `stock_import_number` int(11) NOT NULL DEFAULT 0,
  `fee_for_return_order` decimal(15,2) DEFAULT NULL,
  `estimate_id` int(11) DEFAULT NULL,
  `shipping_form` varchar(50) DEFAULT 'fixed',
  `shipping_value` decimal(15,2) DEFAULT 0.00,
  `type` varchar(30) NOT NULL DEFAULT 'order',
  `datecreator` datetime NOT NULL DEFAULT current_timestamp(),
  `return_reason_type` varchar(50) DEFAULT NULL,
  `return_type` varchar(30) DEFAULT NULL,
  `audit_id` int(11) DEFAULT NULL,
  `maintenance_id` int(11) DEFAULT NULL,
  `credit_note_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfe_cart`
--

LOCK TABLES `abc1_tblfe_cart` WRITE;
/*!40000 ALTER TABLE `abc1_tblfe_cart` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfe_cart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfe_cart_detailt`
--

DROP TABLE IF EXISTS `abc1_tblfe_cart_detailt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfe_cart_detailt` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `classify` varchar(30) DEFAULT NULL,
  `cart_id` int(11) NOT NULL,
  `product_name` varchar(150) DEFAULT NULL,
  `prices` decimal(15,2) DEFAULT NULL,
  `long_description` text DEFAULT NULL,
  `sku` text NOT NULL,
  `percent_discount` float NOT NULL,
  `prices_discount` decimal(15,2) NOT NULL,
  `tax` text DEFAULT NULL,
  `tax_id` text DEFAULT NULL,
  `tax_rate` text DEFAULT NULL,
  `tax_name` text DEFAULT NULL,
  `unit_id` int(11) DEFAULT NULL,
  `unit_name` varchar(255) DEFAULT NULL,
  `pickup_time` varchar(10) DEFAULT NULL,
  `dropoff_time` varchar(10) DEFAULT NULL,
  `rental_start_date` date DEFAULT NULL,
  `rental_end_date` date DEFAULT NULL,
  `number_date` int(11) DEFAULT NULL,
  `rental_value` decimal(15,2) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `renting_period` decimal(15,2) DEFAULT NULL,
  `renting_unit` varchar(10) DEFAULT NULL COMMENT 'hour day week month year',
  `maintenance_id` int(11) DEFAULT NULL,
  `estimate_id` int(11) DEFAULT NULL,
  `available_quantity` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfe_cart_detailt`
--

LOCK TABLES `abc1_tblfe_cart_detailt` WRITE;
/*!40000 ALTER TABLE `abc1_tblfe_cart_detailt` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfe_cart_detailt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfe_categories`
--

DROP TABLE IF EXISTS `abc1_tblfe_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfe_categories` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `category_name` varchar(200) NOT NULL,
  `type` varchar(30) DEFAULT NULL,
  `category_eula` text DEFAULT NULL,
  `primary_default_eula` bit(1) NOT NULL DEFAULT b'0',
  `confirm_acceptance` bit(1) NOT NULL DEFAULT b'0',
  `send_mail_to_user` bit(1) NOT NULL DEFAULT b'0',
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  `creator_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfe_categories`
--

LOCK TABLES `abc1_tblfe_categories` WRITE;
/*!40000 ALTER TABLE `abc1_tblfe_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfe_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfe_checkin_assets`
--

DROP TABLE IF EXISTS `abc1_tblfe_checkin_assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfe_checkin_assets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `model` varchar(200) DEFAULT NULL,
  `asset_name` varchar(200) DEFAULT NULL,
  `item_id` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `checkout_to` varchar(20) DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `asset_id` int(11) DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `checkin_date` date DEFAULT NULL,
  `expected_checkin_date` date DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  `check_status` int(11) NOT NULL DEFAULT 2,
  `requestable` int(11) NOT NULL DEFAULT 0,
  `request_status` int(11) NOT NULL DEFAULT 0,
  `request_title` varchar(300) DEFAULT NULL,
  `predefined_kit_id` int(11) DEFAULT NULL,
  `item_type` varchar(30) DEFAULT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `creator_id` int(11) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfe_checkin_assets`
--

LOCK TABLES `abc1_tblfe_checkin_assets` WRITE;
/*!40000 ALTER TABLE `abc1_tblfe_checkin_assets` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfe_checkin_assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfe_cron_log`
--

DROP TABLE IF EXISTS `abc1_tblfe_cron_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfe_cron_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  `cron_name` varchar(200) DEFAULT NULL,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfe_cron_log`
--

LOCK TABLES `abc1_tblfe_cron_log` WRITE;
/*!40000 ALTER TABLE `abc1_tblfe_cron_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfe_cron_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfe_custom_field_values`
--

DROP TABLE IF EXISTS `abc1_tblfe_custom_field_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfe_custom_field_values` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(300) DEFAULT NULL,
  `type` varchar(30) DEFAULT NULL,
  `option` text DEFAULT NULL,
  `required` int(11) NOT NULL DEFAULT 1,
  `value` text DEFAULT NULL,
  `fieldset_id` int(11) NOT NULL,
  `custom_field_id` int(11) NOT NULL,
  `asset_id` int(11) NOT NULL,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfe_custom_field_values`
--

LOCK TABLES `abc1_tblfe_custom_field_values` WRITE;
/*!40000 ALTER TABLE `abc1_tblfe_custom_field_values` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfe_custom_field_values` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfe_custom_fields`
--

DROP TABLE IF EXISTS `abc1_tblfe_custom_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfe_custom_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(300) DEFAULT NULL,
  `type` varchar(30) DEFAULT NULL,
  `option` text DEFAULT NULL,
  `required` int(11) NOT NULL DEFAULT 1,
  `default_value` text DEFAULT NULL,
  `fieldset_id` int(11) NOT NULL,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfe_custom_fields`
--

LOCK TABLES `abc1_tblfe_custom_fields` WRITE;
/*!40000 ALTER TABLE `abc1_tblfe_custom_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfe_custom_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfe_depreciation_items`
--

DROP TABLE IF EXISTS `abc1_tblfe_depreciation_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfe_depreciation_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL,
  `value` float DEFAULT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfe_depreciation_items`
--

LOCK TABLES `abc1_tblfe_depreciation_items` WRITE;
/*!40000 ALTER TABLE `abc1_tblfe_depreciation_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfe_depreciation_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfe_depreciations`
--

DROP TABLE IF EXISTS `abc1_tblfe_depreciations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfe_depreciations` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `term` double DEFAULT NULL,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  `creator_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfe_depreciations`
--

LOCK TABLES `abc1_tblfe_depreciations` WRITE;
/*!40000 ALTER TABLE `abc1_tblfe_depreciations` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfe_depreciations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfe_fieldsets`
--

DROP TABLE IF EXISTS `abc1_tblfe_fieldsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfe_fieldsets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(300) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  `creator_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfe_fieldsets`
--

LOCK TABLES `abc1_tblfe_fieldsets` WRITE;
/*!40000 ALTER TABLE `abc1_tblfe_fieldsets` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfe_fieldsets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfe_goods_delivery`
--

DROP TABLE IF EXISTS `abc1_tblfe_goods_delivery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfe_goods_delivery` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rel_type` int(11) DEFAULT NULL COMMENT 'type goods delivery',
  `rel_document` int(11) DEFAULT NULL COMMENT 'document id of goods delivery',
  `customer_code` text DEFAULT NULL,
  `customer_name` varchar(100) DEFAULT NULL,
  `to_` varchar(100) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL COMMENT 'the reason delivery',
  `staff_id` int(11) DEFAULT NULL COMMENT 'salesman',
  `date_c` date DEFAULT NULL,
  `date_add` date DEFAULT NULL,
  `goods_delivery_code` varchar(100) DEFAULT NULL COMMENT 'số chứng từ xuất kho',
  `approval` int(11) DEFAULT 0 COMMENT 'status approval ',
  `addedfrom` int(11) DEFAULT NULL,
  `total_money` varchar(200) DEFAULT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `total_discount` varchar(100) DEFAULT NULL,
  `after_discount` varchar(100) DEFAULT NULL,
  `invoice_id` varchar(100) DEFAULT NULL,
  `project` text DEFAULT NULL,
  `type` text DEFAULT NULL,
  `department` int(11) DEFAULT NULL,
  `requester` int(11) DEFAULT NULL,
  `invoice_no` text DEFAULT NULL,
  `pr_order_id` int(11) DEFAULT NULL,
  `type_of_delivery` varchar(100) DEFAULT 'total',
  `additional_discount` decimal(15,2) DEFAULT 0.00,
  `sub_total` decimal(15,2) DEFAULT 0.00,
  `delivery_status` varchar(100) DEFAULT 'ready_for_packing',
  `shipping_fee` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfe_goods_delivery`
--

LOCK TABLES `abc1_tblfe_goods_delivery` WRITE;
/*!40000 ALTER TABLE `abc1_tblfe_goods_delivery` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfe_goods_delivery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfe_goods_delivery_activity_log`
--

DROP TABLE IF EXISTS `abc1_tblfe_goods_delivery_activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfe_goods_delivery_activity_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(100) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `additional_data` text DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `staffid` int(11) DEFAULT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfe_goods_delivery_activity_log`
--

LOCK TABLES `abc1_tblfe_goods_delivery_activity_log` WRITE;
/*!40000 ALTER TABLE `abc1_tblfe_goods_delivery_activity_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfe_goods_delivery_activity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfe_goods_delivery_detail`
--

DROP TABLE IF EXISTS `abc1_tblfe_goods_delivery_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfe_goods_delivery_detail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `goods_delivery_id` int(11) NOT NULL,
  `commodity_code` varchar(100) DEFAULT NULL,
  `commodity_name` text DEFAULT NULL,
  `warehouse_id` text DEFAULT NULL,
  `unit_id` text DEFAULT NULL,
  `quantities` text DEFAULT NULL,
  `unit_price` varchar(100) DEFAULT NULL,
  `total_money` varchar(200) DEFAULT NULL,
  `discount` varchar(100) DEFAULT NULL,
  `discount_money` varchar(100) DEFAULT NULL,
  `available_quantity` varchar(100) DEFAULT NULL,
  `tax_id` varchar(100) DEFAULT NULL,
  `total_after_discount` varchar(100) DEFAULT NULL,
  `expiry_date` text DEFAULT NULL,
  `lot_number` text DEFAULT NULL,
  `guarantee_period` text DEFAULT NULL,
  `tax_rate` text DEFAULT NULL,
  `tax_name` text DEFAULT NULL,
  `sub_total` decimal(15,2) DEFAULT 0.00,
  `packing_qty` decimal(15,2) DEFAULT 0.00,
  `serial_number` varchar(255) DEFAULT NULL,
  `note` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfe_goods_delivery_detail`
--

LOCK TABLES `abc1_tblfe_goods_delivery_detail` WRITE;
/*!40000 ALTER TABLE `abc1_tblfe_goods_delivery_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfe_goods_delivery_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfe_goods_delivery_invoices_pr_orders`
--

DROP TABLE IF EXISTS `abc1_tblfe_goods_delivery_invoices_pr_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfe_goods_delivery_invoices_pr_orders` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) DEFAULT NULL COMMENT 'goods_delivery_id',
  `rel_type` int(11) DEFAULT NULL COMMENT 'invoice_id or purchase order id',
  `type` varchar(100) DEFAULT NULL COMMENT 'invoice,  purchase_orders',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfe_goods_delivery_invoices_pr_orders`
--

LOCK TABLES `abc1_tblfe_goods_delivery_invoices_pr_orders` WRITE;
/*!40000 ALTER TABLE `abc1_tblfe_goods_delivery_invoices_pr_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfe_goods_delivery_invoices_pr_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfe_goods_receipt`
--

DROP TABLE IF EXISTS `abc1_tblfe_goods_receipt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfe_goods_receipt` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `supplier_code` varchar(100) DEFAULT NULL,
  `supplier_name` text DEFAULT NULL,
  `deliver_name` text DEFAULT NULL,
  `buyer_id` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `pr_order_id` int(11) DEFAULT NULL COMMENT 'code puchase request agree',
  `date_c` date DEFAULT NULL,
  `date_add` date DEFAULT NULL,
  `goods_receipt_code` varchar(100) DEFAULT NULL,
  `total_tax_money` varchar(100) DEFAULT NULL,
  `total_goods_money` varchar(100) DEFAULT NULL,
  `value_of_inventory` varchar(100) DEFAULT NULL,
  `invoice_no` text DEFAULT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `total_money` varchar(100) DEFAULT NULL COMMENT 'total_money = total_tax_money +total_goods_money ',
  `approval` int(11) DEFAULT 0,
  `addedfrom` int(11) DEFAULT NULL,
  `from_order` int(11) DEFAULT NULL,
  `creator_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfe_goods_receipt`
--

LOCK TABLES `abc1_tblfe_goods_receipt` WRITE;
/*!40000 ALTER TABLE `abc1_tblfe_goods_receipt` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfe_goods_receipt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfe_goods_receipt_detail`
--

DROP TABLE IF EXISTS `abc1_tblfe_goods_receipt_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfe_goods_receipt_detail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `goods_receipt_id` int(11) NOT NULL,
  `commodity_code` varchar(100) DEFAULT NULL,
  `commodity_name` text DEFAULT NULL,
  `warehouse_id` text DEFAULT NULL,
  `unit_id` text DEFAULT NULL,
  `quantities` text DEFAULT NULL,
  `unit_price` varchar(100) DEFAULT NULL,
  `tax` varchar(100) DEFAULT NULL,
  `tax_money` varchar(100) DEFAULT NULL,
  `goods_money` varchar(100) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `tax_name` text DEFAULT NULL,
  `sub_total` decimal(15,2) DEFAULT 0.00,
  `tax_rate` text DEFAULT NULL,
  `serial_number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfe_goods_receipt_detail`
--

LOCK TABLES `abc1_tblfe_goods_receipt_detail` WRITE;
/*!40000 ALTER TABLE `abc1_tblfe_goods_receipt_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfe_goods_receipt_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfe_goods_transaction_detail`
--

DROP TABLE IF EXISTS `abc1_tblfe_goods_transaction_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfe_goods_transaction_detail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `goods_receipt_id` int(11) DEFAULT NULL COMMENT 'id_goods_receipt_id or goods_delivery_id',
  `goods_id` int(11) NOT NULL COMMENT ' is id commodity',
  `quantity` varchar(100) DEFAULT NULL,
  `date_add` datetime DEFAULT NULL,
  `commodity_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `note` text DEFAULT NULL,
  `status` int(2) DEFAULT NULL COMMENT '1:Goods receipt note 2:Goods delivery note',
  `old_quantity` varchar(100) DEFAULT NULL,
  `purchase_price` varchar(100) DEFAULT NULL,
  `price` varchar(100) DEFAULT NULL,
  `expiry_date` text DEFAULT NULL,
  `lot_number` text DEFAULT NULL,
  `from_stock_name` int(11) DEFAULT NULL,
  `to_stock_name` int(11) DEFAULT NULL,
  `serial_number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`,`commodity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfe_goods_transaction_detail`
--

LOCK TABLES `abc1_tblfe_goods_transaction_detail` WRITE;
/*!40000 ALTER TABLE `abc1_tblfe_goods_transaction_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfe_goods_transaction_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfe_goods_transaction_details`
--

DROP TABLE IF EXISTS `abc1_tblfe_goods_transaction_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfe_goods_transaction_details` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rel_type` varchar(100) DEFAULT NULL COMMENT 'goods_receipt or goods_delivery or loss_adjustment or internal_delivery',
  `rel_id` int(11) NOT NULL COMMENT ' goods_receipt_id or goods_delivery_id or loss_adjustment_id or internal_delivery_id',
  `rel_id_detail` int(11) NOT NULL COMMENT ' goods_receipt_id or goods_delivery_id or loss_adjustment_id or internal_delivery_id',
  `item_id` int(11) NOT NULL,
  `old_quantity` decimal(15,2) DEFAULT 0.00,
  `quantity` decimal(15,2) DEFAULT 0.00,
  `rate` decimal(15,2) DEFAULT 0.00,
  `expiry_date` date DEFAULT NULL,
  `lot_number` text DEFAULT NULL,
  `from_warehouse_id` int(11) DEFAULT NULL,
  `to_warehouse_id` int(11) DEFAULT NULL,
  `date_add` datetime DEFAULT NULL,
  `added_from_id` int(11) DEFAULT NULL,
  `added_from_type` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfe_goods_transaction_details`
--

LOCK TABLES `abc1_tblfe_goods_transaction_details` WRITE;
/*!40000 ALTER TABLE `abc1_tblfe_goods_transaction_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfe_goods_transaction_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfe_locations`
--

DROP TABLE IF EXISTS `abc1_tblfe_locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfe_locations` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `location_name` varchar(200) NOT NULL,
  `parent` int(11) DEFAULT NULL,
  `manager` int(11) DEFAULT NULL,
  `location_currency` varchar(50) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL,
  `zip` varchar(50) DEFAULT NULL,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfe_locations`
--

LOCK TABLES `abc1_tblfe_locations` WRITE;
/*!40000 ALTER TABLE `abc1_tblfe_locations` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfe_locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfe_log_assets`
--

DROP TABLE IF EXISTS `abc1_tblfe_log_assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfe_log_assets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_id` int(11) DEFAULT NULL,
  `action` varchar(200) DEFAULT NULL,
  `item_id` int(11) DEFAULT NULL,
  `target` varchar(200) DEFAULT NULL,
  `changed` varchar(200) DEFAULT NULL,
  `to` varchar(20) DEFAULT NULL,
  `to_id` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfe_log_assets`
--

LOCK TABLES `abc1_tblfe_log_assets` WRITE;
/*!40000 ALTER TABLE `abc1_tblfe_log_assets` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfe_log_assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfe_model_predefined_kits`
--

DROP TABLE IF EXISTS `abc1_tblfe_model_predefined_kits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfe_model_predefined_kits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `model_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfe_model_predefined_kits`
--

LOCK TABLES `abc1_tblfe_model_predefined_kits` WRITE;
/*!40000 ALTER TABLE `abc1_tblfe_model_predefined_kits` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfe_model_predefined_kits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfe_models`
--

DROP TABLE IF EXISTS `abc1_tblfe_models`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfe_models` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `model_name` varchar(200) NOT NULL,
  `manufacturer` int(11) DEFAULT NULL,
  `category` int(11) DEFAULT NULL,
  `model_no` varchar(200) DEFAULT NULL,
  `depreciation` int(11) DEFAULT NULL,
  `eol` int(11) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `custom_field` text DEFAULT NULL,
  `may_request` bit(1) NOT NULL DEFAULT b'0',
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  `fieldset_id` int(11) DEFAULT NULL,
  `creator_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfe_models`
--

LOCK TABLES `abc1_tblfe_models` WRITE;
/*!40000 ALTER TABLE `abc1_tblfe_models` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfe_models` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfe_omni_shipments`
--

DROP TABLE IF EXISTS `abc1_tblfe_omni_shipments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfe_omni_shipments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cart_id` int(11) DEFAULT NULL,
  `goods_delivery_id` int(11) DEFAULT NULL,
  `shipment_hash` varchar(32) DEFAULT NULL,
  `order_id` int(11) DEFAULT 0,
  `shipment_number` varchar(100) DEFAULT NULL,
  `planned_shipping_date` datetime DEFAULT NULL,
  `shipment_status` varchar(50) DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfe_omni_shipments`
--

LOCK TABLES `abc1_tblfe_omni_shipments` WRITE;
/*!40000 ALTER TABLE `abc1_tblfe_omni_shipments` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfe_omni_shipments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfe_packing_list_details`
--

DROP TABLE IF EXISTS `abc1_tblfe_packing_list_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfe_packing_list_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `packing_list_id` int(11) NOT NULL,
  `delivery_detail_id` int(11) DEFAULT NULL,
  `commodity_code` int(11) DEFAULT NULL,
  `commodity_name` text DEFAULT NULL,
  `quantity` decimal(15,2) DEFAULT 0.00,
  `unit_id` int(11) DEFAULT NULL,
  `unit_price` decimal(15,2) DEFAULT 0.00,
  `sub_total` decimal(15,2) DEFAULT 0.00,
  `tax_id` text DEFAULT NULL,
  `tax_rate` text DEFAULT NULL,
  `tax_name` text DEFAULT NULL,
  `total_amount` decimal(15,2) DEFAULT 0.00,
  `discount` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `total_after_discount` decimal(15,2) DEFAULT 0.00,
  `serial_number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfe_packing_list_details`
--

LOCK TABLES `abc1_tblfe_packing_list_details` WRITE;
/*!40000 ALTER TABLE `abc1_tblfe_packing_list_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfe_packing_list_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfe_packing_lists`
--

DROP TABLE IF EXISTS `abc1_tblfe_packing_lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfe_packing_lists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `delivery_note_id` int(11) DEFAULT NULL,
  `packing_list_number` varchar(100) DEFAULT NULL,
  `packing_list_name` varchar(200) DEFAULT NULL,
  `width` decimal(15,2) DEFAULT 0.00,
  `height` decimal(15,2) DEFAULT 0.00,
  `lenght` decimal(15,2) DEFAULT 0.00,
  `weight` decimal(15,2) DEFAULT 0.00,
  `volume` decimal(15,2) DEFAULT 0.00,
  `clientid` int(11) DEFAULT NULL,
  `subtotal` decimal(15,2) DEFAULT 0.00,
  `total_amount` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `additional_discount` decimal(15,2) DEFAULT 0.00,
  `total_after_discount` decimal(15,2) DEFAULT 0.00,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT NULL,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT NULL,
  `client_note` text DEFAULT NULL,
  `admin_note` text DEFAULT NULL,
  `approval` int(11) DEFAULT 0,
  `datecreated` datetime DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `type_of_packing_list` varchar(100) DEFAULT 'total',
  `delivery_status` varchar(100) DEFAULT 'wh_ready_to_deliver',
  `shipping_fee` decimal(15,2) DEFAULT 0.00,
  `sales_order_reference` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfe_packing_lists`
--

LOCK TABLES `abc1_tblfe_packing_lists` WRITE;
/*!40000 ALTER TABLE `abc1_tblfe_packing_lists` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfe_packing_lists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfe_refunds`
--

DROP TABLE IF EXISTS `abc1_tblfe_refunds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfe_refunds` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(11) DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `refunded_on` date DEFAULT NULL,
  `payment_mode` varchar(40) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `amount` decimal(15,2) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfe_refunds`
--

LOCK TABLES `abc1_tblfe_refunds` WRITE;
/*!40000 ALTER TABLE `abc1_tblfe_refunds` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfe_refunds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfe_seats`
--

DROP TABLE IF EXISTS `abc1_tblfe_seats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfe_seats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `seat_name` varchar(200) DEFAULT NULL,
  `to` varchar(20) DEFAULT NULL,
  `to_id` int(11) DEFAULT NULL,
  `license_id` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  `warehouse_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfe_seats`
--

LOCK TABLES `abc1_tblfe_seats` WRITE;
/*!40000 ALTER TABLE `abc1_tblfe_seats` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfe_seats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfe_sign_documents`
--

DROP TABLE IF EXISTS `abc1_tblfe_sign_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfe_sign_documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `checkin_out_id` text DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `check_to_staff` int(11) DEFAULT NULL,
  `reference` varchar(30) DEFAULT NULL,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfe_sign_documents`
--

LOCK TABLES `abc1_tblfe_sign_documents` WRITE;
/*!40000 ALTER TABLE `abc1_tblfe_sign_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfe_sign_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfe_signers`
--

DROP TABLE IF EXISTS `abc1_tblfe_signers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfe_signers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sign_document_id` int(11) DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `ip_address` varchar(100) DEFAULT NULL,
  `date_of_signing` datetime DEFAULT NULL,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  `firstname` varchar(50) DEFAULT NULL,
  `lastname` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfe_signers`
--

LOCK TABLES `abc1_tblfe_signers` WRITE;
/*!40000 ALTER TABLE `abc1_tblfe_signers` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfe_signers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfe_status_labels`
--

DROP TABLE IF EXISTS `abc1_tblfe_status_labels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfe_status_labels` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `status_type` varchar(30) NOT NULL,
  `chart_color` varchar(30) NOT NULL,
  `note` text DEFAULT NULL,
  `show_in_side_nav` bit(1) NOT NULL DEFAULT b'0',
  `default_label` bit(1) NOT NULL DEFAULT b'0',
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  `creator_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfe_status_labels`
--

LOCK TABLES `abc1_tblfe_status_labels` WRITE;
/*!40000 ALTER TABLE `abc1_tblfe_status_labels` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfe_status_labels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfe_suppliers`
--

DROP TABLE IF EXISTS `abc1_tblfe_suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfe_suppliers` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `supplier_name` varchar(200) NOT NULL,
  `address` text DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL,
  `zip` varchar(50) DEFAULT NULL,
  `contact_name` varchar(200) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `fax` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `url` text DEFAULT NULL,
  `note` text DEFAULT NULL,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  `creator_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfe_suppliers`
--

LOCK TABLES `abc1_tblfe_suppliers` WRITE;
/*!40000 ALTER TABLE `abc1_tblfe_suppliers` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfe_suppliers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfe_ticket_action_post_internal_notes`
--

DROP TABLE IF EXISTS `abc1_tblfe_ticket_action_post_internal_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfe_ticket_action_post_internal_notes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_id` int(11) DEFAULT NULL,
  `note_title` text DEFAULT NULL,
  `note_details` text DEFAULT NULL,
  `ticket_status` text DEFAULT NULL COMMENT 'select workflow progess Resolved Closed',
  `resolution` text DEFAULT NULL COMMENT 'Set Reply as Resolution if you want the message entered fix issue',
  `created_type` varchar(20) DEFAULT 'staff',
  `datecreated` datetime DEFAULT NULL,
  `dateupdated` datetime DEFAULT NULL,
  `staffid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfe_ticket_action_post_internal_notes`
--

LOCK TABLES `abc1_tblfe_ticket_action_post_internal_notes` WRITE;
/*!40000 ALTER TABLE `abc1_tblfe_ticket_action_post_internal_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfe_ticket_action_post_internal_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfe_ticket_timeline_logs`
--

DROP TABLE IF EXISTS `abc1_tblfe_ticket_timeline_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfe_ticket_timeline_logs` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(100) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `additional_data` text DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `staffid` int(11) DEFAULT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `from_date` datetime DEFAULT NULL,
  `to_date` datetime DEFAULT NULL,
  `duration` decimal(15,2) DEFAULT 0.00,
  `created_type` varchar(200) DEFAULT 'System',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfe_ticket_timeline_logs`
--

LOCK TABLES `abc1_tblfe_ticket_timeline_logs` WRITE;
/*!40000 ALTER TABLE `abc1_tblfe_ticket_timeline_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfe_ticket_timeline_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfe_tickets`
--

DROP TABLE IF EXISTS `abc1_tblfe_tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfe_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_id` int(11) DEFAULT NULL,
  `created_type` varchar(20) DEFAULT 'staff',
  `client_id` int(11) DEFAULT NULL,
  `cart_id` int(11) DEFAULT NULL,
  `asset_id` int(11) DEFAULT NULL,
  `ticket_source` text DEFAULT NULL,
  `assigned_id` int(11) DEFAULT NULL,
  `time_spent` decimal(15,2) DEFAULT NULL,
  `due_date` datetime DEFAULT NULL,
  `code` text DEFAULT NULL,
  `ticket_subject` text DEFAULT NULL,
  `issue_summary` text DEFAULT NULL,
  `priority_level` text DEFAULT NULL,
  `ticket_type` text DEFAULT NULL,
  `internal_note` text DEFAULT NULL,
  `last_message_time` datetime DEFAULT NULL,
  `last_response_time` datetime DEFAULT NULL,
  `first_reply_time` datetime DEFAULT NULL,
  `last_update_time` datetime DEFAULT NULL,
  `resolution` longtext DEFAULT NULL,
  `status` text DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `dateupdated` datetime DEFAULT NULL,
  `staffid` int(11) DEFAULT NULL,
  `model_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfe_tickets`
--

LOCK TABLES `abc1_tblfe_tickets` WRITE;
/*!40000 ALTER TABLE `abc1_tblfe_tickets` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfe_tickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfe_warehouse`
--

DROP TABLE IF EXISTS `abc1_tblfe_warehouse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfe_warehouse` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(100) DEFAULT NULL,
  `name` text DEFAULT NULL,
  `address` text DEFAULT NULL,
  `city` text DEFAULT NULL,
  `state` text DEFAULT NULL,
  `zip_code` text DEFAULT NULL,
  `country` text DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  `display` int(1) DEFAULT NULL COMMENT 'display 1: display (yes)  0: not displayed (no)',
  `note` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfe_warehouse`
--

LOCK TABLES `abc1_tblfe_warehouse` WRITE;
/*!40000 ALTER TABLE `abc1_tblfe_warehouse` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfe_warehouse` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfiles`
--

DROP TABLE IF EXISTS `abc1_tblfiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) NOT NULL,
  `file_name` varchar(191) NOT NULL,
  `filetype` varchar(40) DEFAULT NULL,
  `visible_to_customer` int(11) NOT NULL DEFAULT 0,
  `attachment_key` varchar(32) DEFAULT NULL,
  `external` varchar(40) DEFAULT NULL,
  `external_link` mediumtext DEFAULT NULL,
  `thumbnail_link` mediumtext DEFAULT NULL COMMENT 'For external usage',
  `staffid` int(11) NOT NULL,
  `contact_id` int(11) DEFAULT 0,
  `task_comment_id` int(11) NOT NULL DEFAULT 0,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfiles`
--

LOCK TABLES `abc1_tblfiles` WRITE;
/*!40000 ALTER TABLE `abc1_tblfiles` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfilter_defaults`
--

DROP TABLE IF EXISTS `abc1_tblfilter_defaults`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfilter_defaults` (
  `filter_id` int(10) unsigned NOT NULL,
  `staff_id` int(11) NOT NULL,
  `identifier` varchar(191) NOT NULL,
  `view` varchar(191) NOT NULL,
  KEY `filter_id` (`filter_id`),
  KEY `ehsan_staff_id` (`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfilter_defaults`
--

LOCK TABLES `abc1_tblfilter_defaults` WRITE;
/*!40000 ALTER TABLE `abc1_tblfilter_defaults` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfilter_defaults` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfilters`
--

DROP TABLE IF EXISTS `abc1_tblfilters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfilters` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `builder` mediumtext NOT NULL,
  `staff_id` int(10) unsigned NOT NULL,
  `identifier` varchar(191) NOT NULL,
  `is_shared` tinyint(3) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfilters`
--

LOCK TABLES `abc1_tblfilters` WRITE;
/*!40000 ALTER TABLE `abc1_tblfilters` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfilters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfleet_benefit_and_penalty`
--

DROP TABLE IF EXISTS `abc1_tblfleet_benefit_and_penalty`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfleet_benefit_and_penalty` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` text DEFAULT NULL,
  `criteria_id` int(11) DEFAULT NULL,
  `driver_id` int(11) DEFAULT NULL,
  `type` text DEFAULT NULL,
  `date` date DEFAULT NULL,
  `benefit_formality` text DEFAULT NULL,
  `reward` decimal(15,2) DEFAULT NULL,
  `penalty_formality` text DEFAULT NULL,
  `amount_of_damage` decimal(15,2) DEFAULT NULL,
  `amount_of_compensation` decimal(15,2) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfleet_benefit_and_penalty`
--

LOCK TABLES `abc1_tblfleet_benefit_and_penalty` WRITE;
/*!40000 ALTER TABLE `abc1_tblfleet_benefit_and_penalty` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfleet_benefit_and_penalty` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfleet_bookings`
--

DROP TABLE IF EXISTS `abc1_tblfleet_bookings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfleet_bookings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` text NOT NULL,
  `contactid` int(11) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  `approved` int(11) NOT NULL DEFAULT 0,
  `status` varchar(45) NOT NULL DEFAULT 'new',
  `delivery_date` date DEFAULT NULL,
  `phone` text NOT NULL,
  `receipt_address` text NOT NULL,
  `delivery_address` text NOT NULL,
  `note` text NOT NULL,
  `invoice_id` int(11) NOT NULL DEFAULT 0,
  `admin_note` text DEFAULT NULL,
  `number` text DEFAULT NULL,
  `amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `invoice_hash` text DEFAULT NULL,
  `rating` int(11) NOT NULL DEFAULT 0,
  `comments` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfleet_bookings`
--

LOCK TABLES `abc1_tblfleet_bookings` WRITE;
/*!40000 ALTER TABLE `abc1_tblfleet_bookings` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfleet_bookings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfleet_criterias`
--

DROP TABLE IF EXISTS `abc1_tblfleet_criterias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfleet_criterias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `description` text DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfleet_criterias`
--

LOCK TABLES `abc1_tblfleet_criterias` WRITE;
/*!40000 ALTER TABLE `abc1_tblfleet_criterias` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfleet_criterias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfleet_driver_documents`
--

DROP TABLE IF EXISTS `abc1_tblfleet_driver_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfleet_driver_documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `driver_id` int(11) NOT NULL DEFAULT 0,
  `subject` text NOT NULL,
  `description` text DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `type` varchar(45) NOT NULL DEFAULT 'driver',
  `vehicle_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfleet_driver_documents`
--

LOCK TABLES `abc1_tblfleet_driver_documents` WRITE;
/*!40000 ALTER TABLE `abc1_tblfleet_driver_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfleet_driver_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfleet_events`
--

DROP TABLE IF EXISTS `abc1_tblfleet_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfleet_events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` text NOT NULL,
  `vehicle_id` int(11) DEFAULT NULL,
  `driver_id` int(11) DEFAULT NULL,
  `event_type` text NOT NULL,
  `event_time` datetime NOT NULL,
  `description` text DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfleet_events`
--

LOCK TABLES `abc1_tblfleet_events` WRITE;
/*!40000 ALTER TABLE `abc1_tblfleet_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfleet_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfleet_fuel_history`
--

DROP TABLE IF EXISTS `abc1_tblfleet_fuel_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfleet_fuel_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vehicle_id` int(11) DEFAULT NULL,
  `vendor_id` int(11) DEFAULT NULL,
  `fuel_time` datetime NOT NULL,
  `odometer` int(11) DEFAULT NULL,
  `gallons` text DEFAULT NULL,
  `price` decimal(15,2) DEFAULT NULL,
  `fuel_type` text DEFAULT NULL,
  `reference` text DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfleet_fuel_history`
--

LOCK TABLES `abc1_tblfleet_fuel_history` WRITE;
/*!40000 ALTER TABLE `abc1_tblfleet_fuel_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfleet_fuel_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfleet_garages`
--

DROP TABLE IF EXISTS `abc1_tblfleet_garages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfleet_garages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `country` int(11) NOT NULL DEFAULT 0,
  `city` varchar(100) DEFAULT NULL,
  `zip` varchar(15) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfleet_garages`
--

LOCK TABLES `abc1_tblfleet_garages` WRITE;
/*!40000 ALTER TABLE `abc1_tblfleet_garages` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfleet_garages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfleet_inspection_forms`
--

DROP TABLE IF EXISTS `abc1_tblfleet_inspection_forms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfleet_inspection_forms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `color` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `slug` text DEFAULT NULL,
  `hash` text DEFAULT NULL,
  `recurring` int(11) NOT NULL DEFAULT 0,
  `recurring_type` varchar(10) DEFAULT NULL,
  `custom_recurring` tinyint(1) NOT NULL DEFAULT 0,
  `cycles` int(11) NOT NULL DEFAULT 0,
  `total_cycles` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfleet_inspection_forms`
--

LOCK TABLES `abc1_tblfleet_inspection_forms` WRITE;
/*!40000 ALTER TABLE `abc1_tblfleet_inspection_forms` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfleet_inspection_forms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfleet_inspection_question_box`
--

DROP TABLE IF EXISTS `abc1_tblfleet_inspection_question_box`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfleet_inspection_question_box` (
  `boxid` int(11) NOT NULL AUTO_INCREMENT,
  `boxtype` varchar(10) NOT NULL,
  `questionid` int(11) NOT NULL,
  PRIMARY KEY (`boxid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfleet_inspection_question_box`
--

LOCK TABLES `abc1_tblfleet_inspection_question_box` WRITE;
/*!40000 ALTER TABLE `abc1_tblfleet_inspection_question_box` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfleet_inspection_question_box` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfleet_inspection_question_box_description`
--

DROP TABLE IF EXISTS `abc1_tblfleet_inspection_question_box_description`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfleet_inspection_question_box_description` (
  `questionboxdescriptionid` int(11) NOT NULL AUTO_INCREMENT,
  `description` mediumtext NOT NULL,
  `boxid` mediumtext NOT NULL,
  `questionid` int(11) NOT NULL,
  `is_fail` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`questionboxdescriptionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfleet_inspection_question_box_description`
--

LOCK TABLES `abc1_tblfleet_inspection_question_box_description` WRITE;
/*!40000 ALTER TABLE `abc1_tblfleet_inspection_question_box_description` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfleet_inspection_question_box_description` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfleet_inspection_question_forms`
--

DROP TABLE IF EXISTS `abc1_tblfleet_inspection_question_forms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfleet_inspection_question_forms` (
  `questionid` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) DEFAULT NULL,
  `question` mediumtext NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT 0,
  `question_order` int(11) NOT NULL,
  PRIMARY KEY (`questionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfleet_inspection_question_forms`
--

LOCK TABLES `abc1_tblfleet_inspection_question_forms` WRITE;
/*!40000 ALTER TABLE `abc1_tblfleet_inspection_question_forms` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfleet_inspection_question_forms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfleet_inspection_results`
--

DROP TABLE IF EXISTS `abc1_tblfleet_inspection_results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfleet_inspection_results` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `inspection_id` int(11) DEFAULT NULL,
  `boxid` int(11) DEFAULT NULL,
  `boxdescriptionid` int(11) DEFAULT NULL,
  `questionid` int(11) DEFAULT NULL,
  `answer` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfleet_inspection_results`
--

LOCK TABLES `abc1_tblfleet_inspection_results` WRITE;
/*!40000 ALTER TABLE `abc1_tblfleet_inspection_results` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfleet_inspection_results` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfleet_inspections`
--

DROP TABLE IF EXISTS `abc1_tblfleet_inspections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfleet_inspections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vehicle_id` int(11) DEFAULT NULL,
  `inspection_form_id` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `recurring` int(11) NOT NULL DEFAULT 0,
  `recurring_type` varchar(10) DEFAULT NULL,
  `custom_recurring` tinyint(1) NOT NULL DEFAULT 0,
  `cycles` int(11) NOT NULL DEFAULT 0,
  `total_cycles` int(11) NOT NULL DEFAULT 0,
  `is_recurring_from` int(11) NOT NULL DEFAULT 0,
  `last_recurring_date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfleet_inspections`
--

LOCK TABLES `abc1_tblfleet_inspections` WRITE;
/*!40000 ALTER TABLE `abc1_tblfleet_inspections` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfleet_inspections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfleet_insurance_categories`
--

DROP TABLE IF EXISTS `abc1_tblfleet_insurance_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfleet_insurance_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `description` text DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfleet_insurance_categories`
--

LOCK TABLES `abc1_tblfleet_insurance_categories` WRITE;
/*!40000 ALTER TABLE `abc1_tblfleet_insurance_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfleet_insurance_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfleet_insurance_company`
--

DROP TABLE IF EXISTS `abc1_tblfleet_insurance_company`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfleet_insurance_company` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `description` text DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfleet_insurance_company`
--

LOCK TABLES `abc1_tblfleet_insurance_company` WRITE;
/*!40000 ALTER TABLE `abc1_tblfleet_insurance_company` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfleet_insurance_company` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfleet_insurance_status`
--

DROP TABLE IF EXISTS `abc1_tblfleet_insurance_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfleet_insurance_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `description` text DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfleet_insurance_status`
--

LOCK TABLES `abc1_tblfleet_insurance_status` WRITE;
/*!40000 ALTER TABLE `abc1_tblfleet_insurance_status` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfleet_insurance_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfleet_insurance_types`
--

DROP TABLE IF EXISTS `abc1_tblfleet_insurance_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfleet_insurance_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `description` text DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfleet_insurance_types`
--

LOCK TABLES `abc1_tblfleet_insurance_types` WRITE;
/*!40000 ALTER TABLE `abc1_tblfleet_insurance_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfleet_insurance_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfleet_insurances`
--

DROP TABLE IF EXISTS `abc1_tblfleet_insurances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfleet_insurances` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vehicle_id` int(11) DEFAULT NULL,
  `insurance_category_id` int(11) DEFAULT NULL,
  `insurance_type_id` int(11) DEFAULT NULL,
  `name` text DEFAULT NULL,
  `status` text DEFAULT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `description` text DEFAULT NULL,
  `amount` decimal(15,2) NOT NULL,
  `insurance_company_id` int(11) NOT NULL DEFAULT 0,
  `insurance_status_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfleet_insurances`
--

LOCK TABLES `abc1_tblfleet_insurances` WRITE;
/*!40000 ALTER TABLE `abc1_tblfleet_insurances` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfleet_insurances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfleet_logbooks`
--

DROP TABLE IF EXISTS `abc1_tblfleet_logbooks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfleet_logbooks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vehicle_id` int(11) DEFAULT NULL,
  `driver_id` int(11) DEFAULT NULL,
  `booking_id` int(11) DEFAULT NULL,
  `odometer` int(11) DEFAULT NULL,
  `status` varchar(45) NOT NULL DEFAULT 'new',
  `date` date DEFAULT NULL,
  `description` text DEFAULT NULL,
  `name` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfleet_logbooks`
--

LOCK TABLES `abc1_tblfleet_logbooks` WRITE;
/*!40000 ALTER TABLE `abc1_tblfleet_logbooks` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfleet_logbooks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfleet_maintenance_teams`
--

DROP TABLE IF EXISTS `abc1_tblfleet_maintenance_teams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfleet_maintenance_teams` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staffid` int(11) DEFAULT NULL,
  `garage_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfleet_maintenance_teams`
--

LOCK TABLES `abc1_tblfleet_maintenance_teams` WRITE;
/*!40000 ALTER TABLE `abc1_tblfleet_maintenance_teams` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfleet_maintenance_teams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfleet_maintenances`
--

DROP TABLE IF EXISTS `abc1_tblfleet_maintenances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfleet_maintenances` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vehicle_id` int(11) DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `maintenance_type` varchar(30) DEFAULT NULL,
  `title` varchar(250) DEFAULT NULL,
  `warranty_improvement` int(11) NOT NULL DEFAULT 0,
  `start_date` date DEFAULT NULL,
  `completion_date` date DEFAULT NULL,
  `cost` decimal(15,2) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  `garage_id` int(11) NOT NULL DEFAULT 0,
  `parts` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfleet_maintenances`
--

LOCK TABLES `abc1_tblfleet_maintenances` WRITE;
/*!40000 ALTER TABLE `abc1_tblfleet_maintenances` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfleet_maintenances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfleet_part_groups`
--

DROP TABLE IF EXISTS `abc1_tblfleet_part_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfleet_part_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `description` text DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfleet_part_groups`
--

LOCK TABLES `abc1_tblfleet_part_groups` WRITE;
/*!40000 ALTER TABLE `abc1_tblfleet_part_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfleet_part_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfleet_part_histories`
--

DROP TABLE IF EXISTS `abc1_tblfleet_part_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfleet_part_histories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `part_id` int(11) NOT NULL,
  `type` text NOT NULL,
  `vehicle_id` int(11) DEFAULT NULL,
  `driver_id` int(11) DEFAULT NULL,
  `start_time` text DEFAULT NULL,
  `end_time` text DEFAULT NULL,
  `start_by` int(11) DEFAULT NULL,
  `end_by` int(11) DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfleet_part_histories`
--

LOCK TABLES `abc1_tblfleet_part_histories` WRITE;
/*!40000 ALTER TABLE `abc1_tblfleet_part_histories` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfleet_part_histories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfleet_part_types`
--

DROP TABLE IF EXISTS `abc1_tblfleet_part_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfleet_part_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `description` text DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfleet_part_types`
--

LOCK TABLES `abc1_tblfleet_part_types` WRITE;
/*!40000 ALTER TABLE `abc1_tblfleet_part_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfleet_part_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfleet_parts`
--

DROP TABLE IF EXISTS `abc1_tblfleet_parts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfleet_parts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `part_type_id` int(11) DEFAULT NULL,
  `brand` text DEFAULT NULL,
  `model` text DEFAULT NULL,
  `serial_number` text DEFAULT NULL,
  `vehicle_id` int(11) NOT NULL DEFAULT 0,
  `driver_id` int(11) NOT NULL DEFAULT 0,
  `part_group_id` int(11) DEFAULT NULL,
  `status` text DEFAULT NULL,
  `purchase_vendor` int(11) DEFAULT NULL,
  `purchase_date` date DEFAULT NULL,
  `purchase_price` decimal(15,2) DEFAULT NULL,
  `warranty_expiration_date` date DEFAULT NULL,
  `purchase_comments` text DEFAULT NULL,
  `in_service_date` date DEFAULT NULL,
  `estimated_service_life_in_months` int(11) DEFAULT NULL,
  `estimated_resale_value` decimal(15,2) DEFAULT NULL,
  `out_of_service_date` date DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfleet_parts`
--

LOCK TABLES `abc1_tblfleet_parts` WRITE;
/*!40000 ALTER TABLE `abc1_tblfleet_parts` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfleet_parts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfleet_time_cards`
--

DROP TABLE IF EXISTS `abc1_tblfleet_time_cards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfleet_time_cards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `logbook_id` int(11) DEFAULT NULL,
  `driver_id` int(11) DEFAULT NULL,
  `start_time` text NOT NULL,
  `end_time` text NOT NULL,
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfleet_time_cards`
--

LOCK TABLES `abc1_tblfleet_time_cards` WRITE;
/*!40000 ALTER TABLE `abc1_tblfleet_time_cards` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfleet_time_cards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfleet_vehicle_assignments`
--

DROP TABLE IF EXISTS `abc1_tblfleet_vehicle_assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfleet_vehicle_assignments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `driver_id` int(11) NOT NULL,
  `vehicle_id` int(11) NOT NULL,
  `start_time` datetime DEFAULT NULL,
  `starting_odometer` float DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `ending_odometer` float DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfleet_vehicle_assignments`
--

LOCK TABLES `abc1_tblfleet_vehicle_assignments` WRITE;
/*!40000 ALTER TABLE `abc1_tblfleet_vehicle_assignments` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfleet_vehicle_assignments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfleet_vehicle_groups`
--

DROP TABLE IF EXISTS `abc1_tblfleet_vehicle_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfleet_vehicle_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `description` text DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfleet_vehicle_groups`
--

LOCK TABLES `abc1_tblfleet_vehicle_groups` WRITE;
/*!40000 ALTER TABLE `abc1_tblfleet_vehicle_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfleet_vehicle_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfleet_vehicle_histories`
--

DROP TABLE IF EXISTS `abc1_tblfleet_vehicle_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfleet_vehicle_histories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vehicle_id` int(11) NOT NULL,
  `type` text NOT NULL,
  `from_value` text DEFAULT NULL,
  `to_value` text DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfleet_vehicle_histories`
--

LOCK TABLES `abc1_tblfleet_vehicle_histories` WRITE;
/*!40000 ALTER TABLE `abc1_tblfleet_vehicle_histories` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfleet_vehicle_histories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfleet_vehicle_types`
--

DROP TABLE IF EXISTS `abc1_tblfleet_vehicle_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfleet_vehicle_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `description` text DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfleet_vehicle_types`
--

LOCK TABLES `abc1_tblfleet_vehicle_types` WRITE;
/*!40000 ALTER TABLE `abc1_tblfleet_vehicle_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfleet_vehicle_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfleet_vehicles`
--

DROP TABLE IF EXISTS `abc1_tblfleet_vehicles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfleet_vehicles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `vehicle_type_id` int(11) DEFAULT NULL,
  `vehicle_group_id` int(11) DEFAULT NULL,
  `status` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `model` text DEFAULT NULL,
  `year` text DEFAULT NULL,
  `width` text DEFAULT NULL,
  `height` text DEFAULT NULL,
  `length` text DEFAULT NULL,
  `interior_volume` text DEFAULT NULL,
  `passenger_volume` text DEFAULT NULL,
  `cargo_volume` text DEFAULT NULL,
  `ground_clearance` text DEFAULT NULL,
  `bed_length` text DEFAULT NULL,
  `curb_weight` text DEFAULT NULL,
  `gross_vehicle_weight_rating` text DEFAULT NULL,
  `towing_capacity` text DEFAULT NULL,
  `max_payload` text DEFAULT NULL,
  `epa_city` text DEFAULT NULL,
  `epa_highway` text DEFAULT NULL,
  `epa_combined` text DEFAULT NULL,
  `oil_capacity` text DEFAULT NULL,
  `in_service_date` date DEFAULT NULL,
  `in_service_odometer` int(11) DEFAULT NULL,
  `estimated_service_life_in_months` text DEFAULT NULL,
  `estimated_service_life_in_meter` text DEFAULT NULL,
  `estimated_resale_value` text DEFAULT NULL,
  `out_of_service_date` date DEFAULT NULL,
  `out_of_service_odometer` int(11) DEFAULT NULL,
  `vin` text DEFAULT NULL,
  `license_plate` text DEFAULT NULL,
  `make` text DEFAULT NULL,
  `trim` text DEFAULT NULL,
  `registration_state` text DEFAULT NULL,
  `ownership` text DEFAULT NULL,
  `color` text DEFAULT NULL,
  `body_type` text DEFAULT NULL,
  `body_subtype` text DEFAULT NULL,
  `msrp` text DEFAULT NULL,
  `purchase_vendor` int(11) DEFAULT NULL,
  `purchase_date` date DEFAULT NULL,
  `purchase_price` decimal(15,2) DEFAULT NULL,
  `odometer` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `expiration_date` date DEFAULT NULL,
  `max_meter_value` text DEFAULT NULL,
  `engine_summary` text DEFAULT NULL,
  `engine_brand` text DEFAULT NULL,
  `aspiration` text DEFAULT NULL,
  `block_type` text DEFAULT NULL,
  `bore` text DEFAULT NULL,
  `cam_type` text DEFAULT NULL,
  `compression` text DEFAULT NULL,
  `cylinders` text DEFAULT NULL,
  `displacement` text DEFAULT NULL,
  `fuel_induction` text DEFAULT NULL,
  `max_hp` text DEFAULT NULL,
  `max_torque` text DEFAULT NULL,
  `redline_rpm` text DEFAULT NULL,
  `stroke` text DEFAULT NULL,
  `valves` text DEFAULT NULL,
  `transmission_summary` text DEFAULT NULL,
  `transmission_brand` text DEFAULT NULL,
  `transmission_type` text DEFAULT NULL,
  `transmission_gears` text DEFAULT NULL,
  `drive_type` text DEFAULT NULL,
  `brake_system` text DEFAULT NULL,
  `front_track_width` text DEFAULT NULL,
  `rear_track_width` text DEFAULT NULL,
  `wheelbase` text DEFAULT NULL,
  `front_wheel_diameter` text DEFAULT NULL,
  `rear_wheel_diameter` text DEFAULT NULL,
  `rear_axle` text DEFAULT NULL,
  `front_tire_type` text DEFAULT NULL,
  `front_tire_psi` text DEFAULT NULL,
  `rear_tire_type` text DEFAULT NULL,
  `rear_tire_psi` text DEFAULT NULL,
  `fuel_type` text DEFAULT NULL,
  `fuel_quality` text DEFAULT NULL,
  `fuel_tank_1_capacity` text DEFAULT NULL,
  `fuel_tank_2_capacity` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfleet_vehicles`
--

LOCK TABLES `abc1_tblfleet_vehicles` WRITE;
/*!40000 ALTER TABLE `abc1_tblfleet_vehicles` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfleet_vehicles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfleet_work_order_details`
--

DROP TABLE IF EXISTS `abc1_tblfleet_work_order_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfleet_work_order_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `work_order_id` int(11) DEFAULT NULL,
  `part_id` int(11) DEFAULT NULL,
  `item_name` text DEFAULT NULL,
  `qty` int(11) DEFAULT NULL,
  `price` decimal(15,2) DEFAULT NULL,
  `total` decimal(15,2) DEFAULT NULL,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfleet_work_order_details`
--

LOCK TABLES `abc1_tblfleet_work_order_details` WRITE;
/*!40000 ALTER TABLE `abc1_tblfleet_work_order_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfleet_work_order_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfleet_work_orders`
--

DROP TABLE IF EXISTS `abc1_tblfleet_work_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfleet_work_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` text NOT NULL,
  `number` text DEFAULT NULL,
  `vehicle_id` int(11) DEFAULT NULL,
  `driver_id` int(11) DEFAULT NULL,
  `vendor_id` int(11) DEFAULT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `purchase_order_id` int(11) DEFAULT NULL,
  `status` varchar(45) NOT NULL DEFAULT 'open',
  `issue_date` date DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `complete_date` date DEFAULT NULL,
  `odometer_in` int(11) DEFAULT NULL,
  `odometer_out` int(11) DEFAULT NULL,
  `total` decimal(15,2) DEFAULT NULL,
  `work_requested` text DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `expense_id` int(11) NOT NULL DEFAULT 0,
  `parts` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfleet_work_orders`
--

LOCK TABLES `abc1_tblfleet_work_orders` WRITE;
/*!40000 ALTER TABLE `abc1_tblfleet_work_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfleet_work_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblflexcategories`
--

DROP TABLE IF EXISTS `abc1_tblflexcategories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblflexcategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` mediumtext NOT NULL,
  `slug` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblflexcategories`
--

LOCK TABLES `abc1_tblflexcategories` WRITE;
/*!40000 ALTER TABLE `abc1_tblflexcategories` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblflexcategories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblflexemaillists`
--

DROP TABLE IF EXISTS `abc1_tblflexemaillists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblflexemaillists` (
  `listid` int(11) NOT NULL AUTO_INCREMENT,
  `name` mediumtext NOT NULL,
  `creator` varchar(100) NOT NULL,
  `datecreated` datetime NOT NULL,
  PRIMARY KEY (`listid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblflexemaillists`
--

LOCK TABLES `abc1_tblflexemaillists` WRITE;
/*!40000 ALTER TABLE `abc1_tblflexemaillists` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblflexemaillists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblflexevents`
--

DROP TABLE IF EXISTS `abc1_tblflexevents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblflexevents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` mediumtext NOT NULL,
  `slug` mediumtext NOT NULL,
  `description` text DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `start_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `create_date` datetime NOT NULL,
  `auto_sync_attendees` tinyint(1) NOT NULL DEFAULT 0,
  `auto_add_to_calendar` tinyint(1) NOT NULL DEFAULT 0,
  `category_id` int(11) NOT NULL,
  `summary` mediumtext DEFAULT NULL,
  `type` mediumtext NOT NULL,
  `location` mediumtext DEFAULT NULL,
  `event_link` mediumtext DEFAULT NULL,
  `password` mediumtext DEFAULT NULL,
  `longitude` double(15,12) DEFAULT NULL,
  `latitude` double(15,12) DEFAULT NULL,
  `privacy` mediumtext NOT NULL,
  `created_by` int(11) NOT NULL,
  `tags` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ehsan_category_event_fk` (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblflexevents`
--

LOCK TABLES `abc1_tblflexevents` WRITE;
/*!40000 ALTER TABLE `abc1_tblflexevents` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblflexevents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblflexibackup`
--

DROP TABLE IF EXISTS `abc1_tblflexibackup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblflexibackup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `backup_name` varchar(255) NOT NULL,
  `backup_type` varchar(255) NOT NULL,
  `backup_data` varchar(255) NOT NULL,
  `datecreated` datetime NOT NULL,
  `uploaded_to_remote` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblflexibackup`
--

LOCK TABLES `abc1_tblflexibackup` WRITE;
/*!40000 ALTER TABLE `abc1_tblflexibackup` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblflexibackup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfleximages`
--

DROP TABLE IF EXISTS `abc1_tblfleximages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfleximages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event_id` int(11) NOT NULL,
  `file_name` mediumtext NOT NULL,
  `original_file_name` mediumtext NOT NULL,
  `filetype` mediumtext NOT NULL,
  `dateadded` datetime NOT NULL,
  `uploaded_by` int(11) NOT NULL,
  `subject` mediumtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ehsan_event_image_fk` (`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfleximages`
--

LOCK TABLES `abc1_tblfleximages` WRITE;
/*!40000 ALTER TABLE `abc1_tblfleximages` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfleximages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblflexinvitationsemailsendcron`
--

DROP TABLE IF EXISTS `abc1_tblflexinvitationsemailsendcron`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblflexinvitationsemailsendcron` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `eventid` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `emailid` int(11) DEFAULT NULL,
  `listid` varchar(11) DEFAULT NULL,
  `log_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblflexinvitationsemailsendcron`
--

LOCK TABLES `abc1_tblflexinvitationsemailsendcron` WRITE;
/*!40000 ALTER TABLE `abc1_tblflexinvitationsemailsendcron` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblflexinvitationsemailsendcron` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblflexinvitationsendlog`
--

DROP TABLE IF EXISTS `abc1_tblflexinvitationsendlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblflexinvitationsendlog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `eventid` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `iscronfinished` int(11) NOT NULL DEFAULT 0,
  `send_to_mail_lists` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblflexinvitationsendlog`
--

LOCK TABLES `abc1_tblflexinvitationsendlog` WRITE;
/*!40000 ALTER TABLE `abc1_tblflexinvitationsendlog` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblflexinvitationsendlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblflexlistemails`
--

DROP TABLE IF EXISTS `abc1_tblflexlistemails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblflexlistemails` (
  `emailid` int(11) NOT NULL AUTO_INCREMENT,
  `listid` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`emailid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblflexlistemails`
--

LOCK TABLES `abc1_tblflexlistemails` WRITE;
/*!40000 ALTER TABLE `abc1_tblflexlistemails` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblflexlistemails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblflexsocialchannels`
--

DROP TABLE IF EXISTS `abc1_tblflexsocialchannels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblflexsocialchannels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event_id` int(11) NOT NULL,
  `channel_id` mediumtext NOT NULL,
  `url` mediumtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ehsan_event_socialchannel_fk` (`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblflexsocialchannels`
--

LOCK TABLES `abc1_tblflexsocialchannels` WRITE;
/*!40000 ALTER TABLE `abc1_tblflexsocialchannels` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblflexsocialchannels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblflexspeakers`
--

DROP TABLE IF EXISTS `abc1_tblflexspeakers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblflexspeakers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event_id` int(11) NOT NULL,
  `name` mediumtext NOT NULL,
  `email` mediumtext NOT NULL,
  `image` mediumtext NOT NULL,
  `show` tinyint(1) DEFAULT 0,
  `bio` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ehsan_event_speaker_fk` (`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblflexspeakers`
--

LOCK TABLES `abc1_tblflexspeakers` WRITE;
/*!40000 ALTER TABLE `abc1_tblflexspeakers` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblflexspeakers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblflexticketorders`
--

DROP TABLE IF EXISTS `abc1_tblflexticketorders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblflexticketorders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `eventid` int(11) NOT NULL,
  `invoiceid` int(11) DEFAULT NULL,
  `attendee_name` varchar(100) NOT NULL,
  `attendee_email` varchar(100) NOT NULL,
  `attendee_mobile` varchar(100) DEFAULT NULL,
  `attendee_company` varchar(100) DEFAULT NULL,
  `total_amount` double(15,3) NOT NULL DEFAULT 0.000,
  `tickets_sent` tinyint(1) NOT NULL DEFAULT 0,
  `in_leads` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblflexticketorders`
--

LOCK TABLES `abc1_tblflexticketorders` WRITE;
/*!40000 ALTER TABLE `abc1_tblflexticketorders` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblflexticketorders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblflextickets`
--

DROP TABLE IF EXISTS `abc1_tblflextickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblflextickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event_id` int(11) NOT NULL,
  `name` mediumtext NOT NULL,
  `status` mediumtext NOT NULL,
  `quantity` int(11) NOT NULL,
  `paid` tinyint(1) DEFAULT 0,
  `currency` mediumtext DEFAULT NULL,
  `price` double(15,3) DEFAULT NULL,
  `min_buying_limit` int(11) DEFAULT NULL,
  `max_buying_limit` int(11) DEFAULT NULL,
  `sales_start_date` datetime DEFAULT NULL,
  `sales_end_date` datetime DEFAULT NULL,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ehsan_event_ticket_fk` (`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblflextickets`
--

LOCK TABLES `abc1_tblflextickets` WRITE;
/*!40000 ALTER TABLE `abc1_tblflextickets` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblflextickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblflexticketsales`
--

DROP TABLE IF EXISTS `abc1_tblflexticketsales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblflexticketsales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticketorderid` int(11) NOT NULL,
  `eventid` int(11) NOT NULL,
  `ticketid` int(11) NOT NULL,
  `reference_code` varchar(100) NOT NULL,
  `quantity` int(11) NOT NULL,
  `sub_total` double(15,3) DEFAULT NULL,
  `checked_in` int(10) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblflexticketsales`
--

LOCK TABLES `abc1_tblflexticketsales` WRITE;
/*!40000 ALTER TABLE `abc1_tblflexticketsales` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblflexticketsales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblflexvideos`
--

DROP TABLE IF EXISTS `abc1_tblflexvideos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblflexvideos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event_id` int(11) NOT NULL,
  `url` mediumtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ehsan_event_video_fk` (`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblflexvideos`
--

LOCK TABLES `abc1_tblflexvideos` WRITE;
/*!40000 ALTER TABLE `abc1_tblflexvideos` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblflexvideos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfmlcustomfields`
--

DROP TABLE IF EXISTS `abc1_tblfmlcustomfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfmlcustomfields` (
  `customfieldid` int(11) NOT NULL AUTO_INCREMENT,
  `listid` int(11) NOT NULL,
  `fieldname` varchar(150) NOT NULL,
  `fieldslug` varchar(100) NOT NULL,
  PRIMARY KEY (`customfieldid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfmlcustomfields`
--

LOCK TABLES `abc1_tblfmlcustomfields` WRITE;
/*!40000 ALTER TABLE `abc1_tblfmlcustomfields` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfmlcustomfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblfmlcustomfieldvalues`
--

DROP TABLE IF EXISTS `abc1_tblfmlcustomfieldvalues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblfmlcustomfieldvalues` (
  `customfieldvalueid` int(11) NOT NULL AUTO_INCREMENT,
  `listid` int(11) NOT NULL,
  `customfieldid` int(11) NOT NULL,
  `emailid` int(11) NOT NULL,
  `value` varchar(100) NOT NULL,
  PRIMARY KEY (`customfieldvalueid`),
  KEY `listid` (`listid`),
  KEY `customfieldid` (`customfieldid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblfmlcustomfieldvalues`
--

LOCK TABLES `abc1_tblfmlcustomfieldvalues` WRITE;
/*!40000 ALTER TABLE `abc1_tblfmlcustomfieldvalues` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblfmlcustomfieldvalues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblform_question_box`
--

DROP TABLE IF EXISTS `abc1_tblform_question_box`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblform_question_box` (
  `boxid` int(11) NOT NULL AUTO_INCREMENT,
  `boxtype` varchar(10) NOT NULL,
  `questionid` int(11) NOT NULL,
  PRIMARY KEY (`boxid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblform_question_box`
--

LOCK TABLES `abc1_tblform_question_box` WRITE;
/*!40000 ALTER TABLE `abc1_tblform_question_box` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblform_question_box` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblform_question_box_description`
--

DROP TABLE IF EXISTS `abc1_tblform_question_box_description`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblform_question_box_description` (
  `questionboxdescriptionid` int(11) NOT NULL AUTO_INCREMENT,
  `description` longtext NOT NULL,
  `boxid` longtext NOT NULL,
  `questionid` int(11) NOT NULL,
  PRIMARY KEY (`questionboxdescriptionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblform_question_box_description`
--

LOCK TABLES `abc1_tblform_question_box_description` WRITE;
/*!40000 ALTER TABLE `abc1_tblform_question_box_description` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblform_question_box_description` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblform_questions`
--

DROP TABLE IF EXISTS `abc1_tblform_questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblform_questions` (
  `questionid` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) DEFAULT NULL,
  `question` longtext NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT 0,
  `question_order` int(11) NOT NULL,
  PRIMARY KEY (`questionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblform_questions`
--

LOCK TABLES `abc1_tblform_questions` WRITE;
/*!40000 ALTER TABLE `abc1_tblform_questions` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblform_questions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblform_results`
--

DROP TABLE IF EXISTS `abc1_tblform_results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblform_results` (
  `resultid` int(11) NOT NULL AUTO_INCREMENT,
  `boxid` int(11) NOT NULL,
  `boxdescriptionid` int(11) DEFAULT NULL,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) DEFAULT NULL,
  `questionid` int(11) NOT NULL,
  `answer` mediumtext DEFAULT NULL,
  `resultsetid` int(11) NOT NULL,
  PRIMARY KEY (`resultid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblform_results`
--

LOCK TABLES `abc1_tblform_results` WRITE;
/*!40000 ALTER TABLE `abc1_tblform_results` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblform_results` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblgdpr_requests`
--

DROP TABLE IF EXISTS `abc1_tblgdpr_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblgdpr_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clientid` int(11) NOT NULL DEFAULT 0,
  `contact_id` int(11) NOT NULL DEFAULT 0,
  `lead_id` int(11) NOT NULL DEFAULT 0,
  `request_type` varchar(191) DEFAULT NULL,
  `status` varchar(40) DEFAULT NULL,
  `request_date` datetime NOT NULL,
  `request_from` varchar(150) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblgdpr_requests`
--

LOCK TABLES `abc1_tblgdpr_requests` WRITE;
/*!40000 ALTER TABLE `abc1_tblgdpr_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblgdpr_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblgoals`
--

DROP TABLE IF EXISTS `abc1_tblgoals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblgoals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(191) NOT NULL,
  `description` text NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `goal_type` int(11) NOT NULL,
  `contract_type` int(11) NOT NULL DEFAULT 0,
  `achievement` int(11) NOT NULL,
  `notify_when_fail` tinyint(1) NOT NULL DEFAULT 1,
  `notify_when_achieve` tinyint(1) NOT NULL DEFAULT 1,
  `notified` int(11) NOT NULL DEFAULT 0,
  `staff_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `staff_id` (`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblgoals`
--

LOCK TABLES `abc1_tblgoals` WRITE;
/*!40000 ALTER TABLE `abc1_tblgoals` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblgoals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblgoods_delivery`
--

DROP TABLE IF EXISTS `abc1_tblgoods_delivery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblgoods_delivery` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rel_type` int(11) DEFAULT NULL COMMENT 'type goods delivery',
  `rel_document` int(11) DEFAULT NULL COMMENT 'document id of goods delivery',
  `customer_code` text DEFAULT NULL,
  `customer_name` varchar(100) DEFAULT NULL,
  `to_` varchar(100) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL COMMENT 'the reason delivery',
  `staff_id` int(11) DEFAULT NULL COMMENT 'salesman',
  `date_c` date DEFAULT NULL,
  `date_add` date DEFAULT NULL,
  `goods_delivery_code` varchar(100) DEFAULT NULL COMMENT 'số chứng từ xuất kho',
  `warehouse_id` int(11) DEFAULT NULL,
  `total_money` varchar(200) DEFAULT NULL,
  `approval` int(11) DEFAULT 0 COMMENT 'status approval ',
  `addedfrom` int(11) DEFAULT NULL,
  `total_discount` varchar(100) DEFAULT NULL,
  `after_discount` varchar(100) DEFAULT NULL,
  `invoice_id` varchar(100) DEFAULT NULL,
  `project` text DEFAULT NULL,
  `type` text DEFAULT NULL,
  `department` int(11) DEFAULT NULL,
  `requester` int(11) DEFAULT NULL,
  `invoice_no` text DEFAULT NULL,
  `pr_order_id` int(11) DEFAULT NULL,
  `type_of_delivery` varchar(100) DEFAULT 'total',
  `additional_discount` decimal(15,2) DEFAULT 0.00,
  `sub_total` decimal(15,2) DEFAULT 0.00,
  `delivery_status` varchar(100) DEFAULT 'ready_for_packing',
  `shipping_fee` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblgoods_delivery`
--

LOCK TABLES `abc1_tblgoods_delivery` WRITE;
/*!40000 ALTER TABLE `abc1_tblgoods_delivery` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblgoods_delivery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblgoods_delivery_detail`
--

DROP TABLE IF EXISTS `abc1_tblgoods_delivery_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblgoods_delivery_detail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `goods_delivery_id` int(11) NOT NULL,
  `commodity_code` varchar(100) DEFAULT NULL,
  `commodity_name` text DEFAULT NULL,
  `warehouse_id` text DEFAULT NULL,
  `unit_id` text DEFAULT NULL,
  `quantities` text DEFAULT NULL,
  `unit_price` varchar(100) DEFAULT NULL,
  `total_money` varchar(200) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `discount` varchar(100) DEFAULT NULL,
  `discount_money` varchar(100) DEFAULT NULL,
  `available_quantity` varchar(100) DEFAULT NULL,
  `tax_id` varchar(100) DEFAULT NULL,
  `total_after_discount` varchar(100) DEFAULT NULL,
  `expiry_date` text DEFAULT NULL,
  `lot_number` text DEFAULT NULL,
  `guarantee_period` text DEFAULT NULL,
  `tax_rate` text DEFAULT NULL,
  `tax_name` text DEFAULT NULL,
  `sub_total` decimal(15,2) DEFAULT 0.00,
  `packing_qty` decimal(15,2) DEFAULT 0.00,
  `serial_number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblgoods_delivery_detail`
--

LOCK TABLES `abc1_tblgoods_delivery_detail` WRITE;
/*!40000 ALTER TABLE `abc1_tblgoods_delivery_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblgoods_delivery_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblgoods_delivery_invoices_pr_orders`
--

DROP TABLE IF EXISTS `abc1_tblgoods_delivery_invoices_pr_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblgoods_delivery_invoices_pr_orders` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) DEFAULT NULL COMMENT 'goods_delivery_id',
  `rel_type` int(11) DEFAULT NULL COMMENT 'invoice_id or purchase order id',
  `type` varchar(100) DEFAULT NULL COMMENT 'invoice,  purchase_orders',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblgoods_delivery_invoices_pr_orders`
--

LOCK TABLES `abc1_tblgoods_delivery_invoices_pr_orders` WRITE;
/*!40000 ALTER TABLE `abc1_tblgoods_delivery_invoices_pr_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblgoods_delivery_invoices_pr_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblgoods_receipt`
--

DROP TABLE IF EXISTS `abc1_tblgoods_receipt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblgoods_receipt` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `supplier_code` varchar(100) DEFAULT NULL,
  `supplier_name` text DEFAULT NULL,
  `deliver_name` text DEFAULT NULL,
  `buyer_id` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `pr_order_id` int(11) DEFAULT NULL COMMENT 'code puchase request agree',
  `date_c` date DEFAULT NULL,
  `date_add` date DEFAULT NULL,
  `goods_receipt_code` varchar(100) DEFAULT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `total_tax_money` varchar(100) DEFAULT NULL,
  `total_goods_money` varchar(100) DEFAULT NULL,
  `value_of_inventory` varchar(100) DEFAULT NULL,
  `total_money` varchar(100) DEFAULT NULL COMMENT 'total_money = total_tax_money +total_goods_money ',
  `addedfrom` int(11) DEFAULT NULL,
  `approval` int(11) DEFAULT 0,
  `project` text DEFAULT NULL,
  `type` text DEFAULT NULL,
  `department` int(11) DEFAULT NULL,
  `requester` int(11) DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `invoice_no` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblgoods_receipt`
--

LOCK TABLES `abc1_tblgoods_receipt` WRITE;
/*!40000 ALTER TABLE `abc1_tblgoods_receipt` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblgoods_receipt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblgoods_receipt_detail`
--

DROP TABLE IF EXISTS `abc1_tblgoods_receipt_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblgoods_receipt_detail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `goods_receipt_id` int(11) NOT NULL,
  `commodity_code` varchar(100) DEFAULT NULL,
  `commodity_name` text DEFAULT NULL,
  `warehouse_id` text DEFAULT NULL,
  `unit_id` text DEFAULT NULL,
  `quantities` text DEFAULT NULL,
  `unit_price` varchar(100) DEFAULT NULL,
  `tax` varchar(100) DEFAULT NULL,
  `tax_money` varchar(100) DEFAULT NULL,
  `goods_money` varchar(100) DEFAULT NULL,
  `date_manufacture` date DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `note` text DEFAULT NULL,
  `discount` varchar(100) DEFAULT NULL,
  `discount_money` varchar(100) DEFAULT NULL,
  `lot_number` varchar(100) DEFAULT NULL,
  `tax_rate` text DEFAULT NULL,
  `sub_total` decimal(15,2) DEFAULT 0.00,
  `tax_name` text DEFAULT NULL,
  `serial_number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblgoods_receipt_detail`
--

LOCK TABLES `abc1_tblgoods_receipt_detail` WRITE;
/*!40000 ALTER TABLE `abc1_tblgoods_receipt_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblgoods_receipt_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblgoods_transaction_detail`
--

DROP TABLE IF EXISTS `abc1_tblgoods_transaction_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblgoods_transaction_detail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `goods_receipt_id` int(11) DEFAULT NULL COMMENT 'id_goods_receipt_id or goods_delivery_id',
  `goods_id` int(11) NOT NULL COMMENT ' is id commodity',
  `old_quantity` varchar(100) DEFAULT NULL,
  `quantity` varchar(100) DEFAULT NULL,
  `date_add` datetime DEFAULT NULL,
  `commodity_id` int(11) NOT NULL,
  `warehouse_id` text NOT NULL,
  `note` text DEFAULT NULL,
  `status` int(2) DEFAULT NULL COMMENT '1:Goods receipt note 2:Goods delivery note',
  `purchase_price` varchar(100) DEFAULT NULL,
  `price` varchar(100) DEFAULT NULL,
  `expiry_date` text DEFAULT NULL,
  `lot_number` text DEFAULT NULL,
  `from_stock_name` int(11) DEFAULT NULL,
  `to_stock_name` int(11) DEFAULT NULL,
  `serial_number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`,`commodity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblgoods_transaction_detail`
--

LOCK TABLES `abc1_tblgoods_transaction_detail` WRITE;
/*!40000 ALTER TABLE `abc1_tblgoods_transaction_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblgoods_transaction_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblgroup_checklist`
--

DROP TABLE IF EXISTS `abc1_tblgroup_checklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblgroup_checklist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(100) NOT NULL,
  `meta` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblgroup_checklist`
--

LOCK TABLES `abc1_tblgroup_checklist` WRITE;
/*!40000 ALTER TABLE `abc1_tblgroup_checklist` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblgroup_checklist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblgroup_checklist_allocation`
--

DROP TABLE IF EXISTS `abc1_tblgroup_checklist_allocation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblgroup_checklist_allocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(100) NOT NULL,
  `meta` varchar(100) DEFAULT NULL,
  `staffid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblgroup_checklist_allocation`
--

LOCK TABLES `abc1_tblgroup_checklist_allocation` WRITE;
/*!40000 ALTER TABLE `abc1_tblgroup_checklist_allocation` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblgroup_checklist_allocation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhr_allocation_asset`
--

DROP TABLE IF EXISTS `abc1_tblhr_allocation_asset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhr_allocation_asset` (
  `allocation_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) unsigned NOT NULL,
  `asset_name` varchar(100) DEFAULT NULL,
  `assets_amount` int(11) unsigned NOT NULL,
  `status_allocation` int(11) unsigned DEFAULT 0 COMMENT '1: Allocated 0: Unallocated',
  PRIMARY KEY (`allocation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhr_allocation_asset`
--

LOCK TABLES `abc1_tblhr_allocation_asset` WRITE;
/*!40000 ALTER TABLE `abc1_tblhr_allocation_asset` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhr_allocation_asset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhr_allowance_type`
--

DROP TABLE IF EXISTS `abc1_tblhr_allowance_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhr_allowance_type` (
  `type_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type_name` varchar(200) NOT NULL,
  `allowance_val` decimal(15,2) NOT NULL,
  `taxable` tinyint(1) NOT NULL,
  PRIMARY KEY (`type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhr_allowance_type`
--

LOCK TABLES `abc1_tblhr_allowance_type` WRITE;
/*!40000 ALTER TABLE `abc1_tblhr_allowance_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhr_allowance_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhr_checklist_allocation`
--

DROP TABLE IF EXISTS `abc1_tblhr_checklist_allocation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhr_checklist_allocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `group_id` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhr_checklist_allocation`
--

LOCK TABLES `abc1_tblhr_checklist_allocation` WRITE;
/*!40000 ALTER TABLE `abc1_tblhr_checklist_allocation` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhr_checklist_allocation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhr_contract_template`
--

DROP TABLE IF EXISTS `abc1_tblhr_contract_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhr_contract_template` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text DEFAULT NULL,
  `job_position` longtext DEFAULT NULL,
  `content` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhr_contract_template`
--

LOCK TABLES `abc1_tblhr_contract_template` WRITE;
/*!40000 ALTER TABLE `abc1_tblhr_contract_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhr_contract_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhr_dependent_person`
--

DROP TABLE IF EXISTS `abc1_tblhr_dependent_person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhr_dependent_person` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staffid` int(11) unsigned DEFAULT NULL,
  `dependent_name` varchar(100) DEFAULT NULL,
  `relationship` varchar(100) DEFAULT NULL,
  `dependent_bir` date DEFAULT NULL,
  `start_month` date DEFAULT NULL,
  `end_month` date DEFAULT NULL,
  `dependent_iden` varchar(20) NOT NULL,
  `reason` longtext DEFAULT NULL,
  `status` int(11) unsigned DEFAULT 0,
  `status_comment` longtext DEFAULT NULL,
  PRIMARY KEY (`id`,`dependent_iden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhr_dependent_person`
--

LOCK TABLES `abc1_tblhr_dependent_person` WRITE;
/*!40000 ALTER TABLE `abc1_tblhr_dependent_person` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhr_dependent_person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhr_education`
--

DROP TABLE IF EXISTS `abc1_tblhr_education`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhr_education` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `programe_id` int(11) DEFAULT NULL,
  `training_programs_name` text NOT NULL,
  `training_places` text DEFAULT NULL,
  `training_time_from` datetime DEFAULT NULL,
  `training_time_to` datetime DEFAULT NULL,
  `date_create` datetime DEFAULT NULL,
  `training_result` varchar(150) DEFAULT NULL,
  `degree` varchar(150) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhr_education`
--

LOCK TABLES `abc1_tblhr_education` WRITE;
/*!40000 ALTER TABLE `abc1_tblhr_education` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhr_education` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhr_group_checklist_allocation`
--

DROP TABLE IF EXISTS `abc1_tblhr_group_checklist_allocation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhr_group_checklist_allocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(100) NOT NULL,
  `meta` varchar(100) DEFAULT NULL,
  `staffid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhr_group_checklist_allocation`
--

LOCK TABLES `abc1_tblhr_group_checklist_allocation` WRITE;
/*!40000 ALTER TABLE `abc1_tblhr_group_checklist_allocation` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhr_group_checklist_allocation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhr_job_p`
--

DROP TABLE IF EXISTS `abc1_tblhr_job_p`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhr_job_p` (
  `job_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `job_name` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`job_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhr_job_p`
--

LOCK TABLES `abc1_tblhr_job_p` WRITE;
/*!40000 ALTER TABLE `abc1_tblhr_job_p` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhr_job_p` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhr_job_position`
--

DROP TABLE IF EXISTS `abc1_tblhr_job_position`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhr_job_position` (
  `position_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `position_name` varchar(200) NOT NULL,
  `job_position_description` text DEFAULT NULL,
  `job_p_id` int(11) unsigned NOT NULL,
  `position_code` varchar(50) DEFAULT NULL,
  `department_id` text DEFAULT NULL,
  PRIMARY KEY (`position_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhr_job_position`
--

LOCK TABLES `abc1_tblhr_job_position` WRITE;
/*!40000 ALTER TABLE `abc1_tblhr_job_position` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhr_job_position` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhr_jp_interview_training`
--

DROP TABLE IF EXISTS `abc1_tblhr_jp_interview_training`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhr_jp_interview_training` (
  `training_process_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `job_position_id` longtext DEFAULT NULL,
  `training_name` varchar(100) DEFAULT NULL,
  `training_type` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `date_add` datetime DEFAULT NULL,
  `position_training_id` text DEFAULT NULL,
  `mint_point` int(11) DEFAULT NULL,
  `additional_training` varchar(100) DEFAULT '',
  `staff_id` text DEFAULT NULL,
  `time_to_start` date DEFAULT NULL,
  `time_to_end` date DEFAULT NULL,
  PRIMARY KEY (`training_process_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhr_jp_interview_training`
--

LOCK TABLES `abc1_tblhr_jp_interview_training` WRITE;
/*!40000 ALTER TABLE `abc1_tblhr_jp_interview_training` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhr_jp_interview_training` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhr_jp_salary_scale`
--

DROP TABLE IF EXISTS `abc1_tblhr_jp_salary_scale`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhr_jp_salary_scale` (
  `salary_scale_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `job_position_id` int(11) unsigned NOT NULL,
  `rel_type` varchar(100) DEFAULT NULL COMMENT 'salary:allowance:insurance',
  `rel_id` int(11) DEFAULT NULL,
  `value` text DEFAULT NULL,
  PRIMARY KEY (`salary_scale_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhr_jp_salary_scale`
--

LOCK TABLES `abc1_tblhr_jp_salary_scale` WRITE;
/*!40000 ALTER TABLE `abc1_tblhr_jp_salary_scale` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhr_jp_salary_scale` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhr_knowedge_base_article_feedback`
--

DROP TABLE IF EXISTS `abc1_tblhr_knowedge_base_article_feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhr_knowedge_base_article_feedback` (
  `articleanswerid` int(11) NOT NULL AUTO_INCREMENT,
  `articleid` int(11) NOT NULL,
  `answer` int(11) NOT NULL,
  `ip` varchar(40) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`articleanswerid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhr_knowedge_base_article_feedback`
--

LOCK TABLES `abc1_tblhr_knowedge_base_article_feedback` WRITE;
/*!40000 ALTER TABLE `abc1_tblhr_knowedge_base_article_feedback` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhr_knowedge_base_article_feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhr_knowledge_base`
--

DROP TABLE IF EXISTS `abc1_tblhr_knowledge_base`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhr_knowledge_base` (
  `articleid` int(11) NOT NULL AUTO_INCREMENT,
  `articlegroup` int(11) NOT NULL,
  `subject` mediumtext NOT NULL,
  `description` text NOT NULL,
  `slug` mediumtext NOT NULL,
  `active` tinyint(4) NOT NULL,
  `datecreated` datetime NOT NULL,
  `article_order` int(11) NOT NULL DEFAULT 0,
  `staff_article` int(11) NOT NULL DEFAULT 0,
  `question_answers` int(11) DEFAULT 0,
  `file_name` varchar(255) DEFAULT '',
  `curator` varchar(11) DEFAULT '',
  `benchmark` int(11) DEFAULT 0,
  `score` int(11) DEFAULT 0,
  PRIMARY KEY (`articleid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhr_knowledge_base`
--

LOCK TABLES `abc1_tblhr_knowledge_base` WRITE;
/*!40000 ALTER TABLE `abc1_tblhr_knowledge_base` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhr_knowledge_base` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhr_knowledge_base_groups`
--

DROP TABLE IF EXISTS `abc1_tblhr_knowledge_base_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhr_knowledge_base_groups` (
  `groupid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `group_slug` text DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `active` tinyint(4) NOT NULL,
  `color` varchar(10) DEFAULT '#28B8DA',
  `group_order` int(11) DEFAULT 0,
  PRIMARY KEY (`groupid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhr_knowledge_base_groups`
--

LOCK TABLES `abc1_tblhr_knowledge_base_groups` WRITE;
/*!40000 ALTER TABLE `abc1_tblhr_knowledge_base_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhr_knowledge_base_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhr_list_staff_quitting_work`
--

DROP TABLE IF EXISTS `abc1_tblhr_list_staff_quitting_work`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhr_list_staff_quitting_work` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staffid` int(11) DEFAULT NULL,
  `staff_name` text DEFAULT NULL,
  `department_name` text DEFAULT NULL,
  `role_name` text DEFAULT NULL,
  `email` text DEFAULT NULL,
  `dateoff` datetime DEFAULT NULL,
  `approval` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhr_list_staff_quitting_work`
--

LOCK TABLES `abc1_tblhr_list_staff_quitting_work` WRITE;
/*!40000 ALTER TABLE `abc1_tblhr_list_staff_quitting_work` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhr_list_staff_quitting_work` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhr_p_t_form_question_box`
--

DROP TABLE IF EXISTS `abc1_tblhr_p_t_form_question_box`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhr_p_t_form_question_box` (
  `boxid` int(11) NOT NULL AUTO_INCREMENT,
  `boxtype` varchar(10) NOT NULL,
  `questionid` int(11) NOT NULL,
  PRIMARY KEY (`boxid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhr_p_t_form_question_box`
--

LOCK TABLES `abc1_tblhr_p_t_form_question_box` WRITE;
/*!40000 ALTER TABLE `abc1_tblhr_p_t_form_question_box` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhr_p_t_form_question_box` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhr_p_t_form_question_box_description`
--

DROP TABLE IF EXISTS `abc1_tblhr_p_t_form_question_box_description`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhr_p_t_form_question_box_description` (
  `questionboxdescriptionid` int(11) NOT NULL AUTO_INCREMENT,
  `description` mediumtext NOT NULL,
  `boxid` mediumtext NOT NULL,
  `questionid` int(11) NOT NULL,
  `correct` int(11) DEFAULT 1 COMMENT '0: correct 1: incorrect',
  PRIMARY KEY (`questionboxdescriptionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhr_p_t_form_question_box_description`
--

LOCK TABLES `abc1_tblhr_p_t_form_question_box_description` WRITE;
/*!40000 ALTER TABLE `abc1_tblhr_p_t_form_question_box_description` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhr_p_t_form_question_box_description` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhr_p_t_form_results`
--

DROP TABLE IF EXISTS `abc1_tblhr_p_t_form_results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhr_p_t_form_results` (
  `resultid` int(11) NOT NULL AUTO_INCREMENT,
  `boxid` int(11) NOT NULL,
  `boxdescriptionid` int(11) DEFAULT NULL,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) DEFAULT NULL,
  `questionid` int(11) NOT NULL,
  `answer` text DEFAULT NULL,
  `resultsetid` int(11) NOT NULL,
  PRIMARY KEY (`resultid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhr_p_t_form_results`
--

LOCK TABLES `abc1_tblhr_p_t_form_results` WRITE;
/*!40000 ALTER TABLE `abc1_tblhr_p_t_form_results` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhr_p_t_form_results` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhr_p_t_surveyresultsets`
--

DROP TABLE IF EXISTS `abc1_tblhr_p_t_surveyresultsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhr_p_t_surveyresultsets` (
  `resultsetid` int(11) NOT NULL AUTO_INCREMENT,
  `trainingid` int(11) NOT NULL,
  `ip` varchar(40) NOT NULL,
  `useragent` varchar(150) NOT NULL,
  `date` datetime NOT NULL,
  `staff_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`resultsetid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhr_p_t_surveyresultsets`
--

LOCK TABLES `abc1_tblhr_p_t_surveyresultsets` WRITE;
/*!40000 ALTER TABLE `abc1_tblhr_p_t_surveyresultsets` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhr_p_t_surveyresultsets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhr_payroll_option`
--

DROP TABLE IF EXISTS `abc1_tblhr_payroll_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhr_payroll_option` (
  `option_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(200) NOT NULL,
  `option_val` longtext DEFAULT NULL,
  `auto` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`option_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhr_payroll_option`
--

LOCK TABLES `abc1_tblhr_payroll_option` WRITE;
/*!40000 ALTER TABLE `abc1_tblhr_payroll_option` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhr_payroll_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhr_position_training`
--

DROP TABLE IF EXISTS `abc1_tblhr_position_training`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhr_position_training` (
  `training_id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` mediumtext NOT NULL,
  `training_type` int(11) unsigned NOT NULL,
  `slug` mediumtext NOT NULL,
  `description` text DEFAULT NULL,
  `viewdescription` text DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `redirect_url` varchar(100) DEFAULT NULL,
  `send` tinyint(1) NOT NULL DEFAULT 0,
  `onlyforloggedin` int(11) DEFAULT 0,
  `fromname` varchar(100) DEFAULT NULL,
  `iprestrict` tinyint(1) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `hash` varchar(32) NOT NULL,
  `mint_point` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`training_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhr_position_training`
--

LOCK TABLES `abc1_tblhr_position_training` WRITE;
/*!40000 ALTER TABLE `abc1_tblhr_position_training` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhr_position_training` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhr_position_training_question_form`
--

DROP TABLE IF EXISTS `abc1_tblhr_position_training_question_form`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhr_position_training_question_form` (
  `questionid` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) DEFAULT NULL,
  `question` mediumtext NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT 0,
  `question_order` int(11) NOT NULL,
  `point` int(11) NOT NULL,
  PRIMARY KEY (`questionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhr_position_training_question_form`
--

LOCK TABLES `abc1_tblhr_position_training_question_form` WRITE;
/*!40000 ALTER TABLE `abc1_tblhr_position_training_question_form` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhr_position_training_question_form` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhr_procedure_retire`
--

DROP TABLE IF EXISTS `abc1_tblhr_procedure_retire`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhr_procedure_retire` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_name` text DEFAULT NULL,
  `option_name` text DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `people_handle_id` int(11) NOT NULL,
  `procedure_retire_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhr_procedure_retire`
--

LOCK TABLES `abc1_tblhr_procedure_retire` WRITE;
/*!40000 ALTER TABLE `abc1_tblhr_procedure_retire` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhr_procedure_retire` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhr_procedure_retire_manage`
--

DROP TABLE IF EXISTS `abc1_tblhr_procedure_retire_manage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhr_procedure_retire_manage` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name_procedure_retire` text NOT NULL,
  `department` varchar(250) NOT NULL,
  `datecreator` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhr_procedure_retire_manage`
--

LOCK TABLES `abc1_tblhr_procedure_retire_manage` WRITE;
/*!40000 ALTER TABLE `abc1_tblhr_procedure_retire_manage` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhr_procedure_retire_manage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhr_procedure_retire_of_staff`
--

DROP TABLE IF EXISTS `abc1_tblhr_procedure_retire_of_staff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhr_procedure_retire_of_staff` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) DEFAULT NULL,
  `option_name` text DEFAULT NULL,
  `status` int(11) DEFAULT 0,
  `staffid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhr_procedure_retire_of_staff`
--

LOCK TABLES `abc1_tblhr_procedure_retire_of_staff` WRITE;
/*!40000 ALTER TABLE `abc1_tblhr_procedure_retire_of_staff` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhr_procedure_retire_of_staff` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhr_procedure_retire_of_staff_by_id`
--

DROP TABLE IF EXISTS `abc1_tblhr_procedure_retire_of_staff_by_id`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhr_procedure_retire_of_staff_by_id` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_name` text DEFAULT NULL,
  `people_handle_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhr_procedure_retire_of_staff_by_id`
--

LOCK TABLES `abc1_tblhr_procedure_retire_of_staff_by_id` WRITE;
/*!40000 ALTER TABLE `abc1_tblhr_procedure_retire_of_staff_by_id` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhr_procedure_retire_of_staff_by_id` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhr_profile_option`
--

DROP TABLE IF EXISTS `abc1_tblhr_profile_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhr_profile_option` (
  `option_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(200) NOT NULL,
  `option_val` longtext DEFAULT NULL,
  `auto` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`option_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhr_profile_option`
--

LOCK TABLES `abc1_tblhr_profile_option` WRITE;
/*!40000 ALTER TABLE `abc1_tblhr_profile_option` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhr_profile_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhr_rec_transfer_records`
--

DROP TABLE IF EXISTS `abc1_tblhr_rec_transfer_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhr_rec_transfer_records` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `firstname` varchar(100) DEFAULT NULL,
  `lastname` varchar(100) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `gender` varchar(11) DEFAULT NULL,
  `staff_identifi` varchar(20) DEFAULT NULL,
  `creator` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhr_rec_transfer_records`
--

LOCK TABLES `abc1_tblhr_rec_transfer_records` WRITE;
/*!40000 ALTER TABLE `abc1_tblhr_rec_transfer_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhr_rec_transfer_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhr_salary_form`
--

DROP TABLE IF EXISTS `abc1_tblhr_salary_form`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhr_salary_form` (
  `form_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `form_name` varchar(200) NOT NULL,
  `salary_val` decimal(15,2) NOT NULL,
  `tax` tinyint(1) NOT NULL,
  PRIMARY KEY (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhr_salary_form`
--

LOCK TABLES `abc1_tblhr_salary_form` WRITE;
/*!40000 ALTER TABLE `abc1_tblhr_salary_form` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhr_salary_form` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhr_staff_contract`
--

DROP TABLE IF EXISTS `abc1_tblhr_staff_contract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhr_staff_contract` (
  `id_contract` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `contract_code` varchar(200) NOT NULL,
  `name_contract` int(11) NOT NULL,
  `staff` int(11) NOT NULL,
  `start_valid` date DEFAULT NULL,
  `end_valid` date DEFAULT NULL,
  `contract_status` varchar(100) DEFAULT NULL,
  `sign_day` date DEFAULT NULL,
  `staff_delegate` int(11) DEFAULT NULL,
  `hourly_or_month` longtext DEFAULT NULL,
  `content` longtext DEFAULT NULL,
  `hash` varchar(32) DEFAULT NULL,
  `signature` varchar(40) DEFAULT NULL,
  `signer` int(11) DEFAULT NULL,
  `staff_signature` varchar(40) DEFAULT NULL,
  `staff_sign_day` date DEFAULT NULL,
  PRIMARY KEY (`id_contract`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhr_staff_contract`
--

LOCK TABLES `abc1_tblhr_staff_contract` WRITE;
/*!40000 ALTER TABLE `abc1_tblhr_staff_contract` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhr_staff_contract` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhr_staff_contract_detail`
--

DROP TABLE IF EXISTS `abc1_tblhr_staff_contract_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhr_staff_contract_detail` (
  `contract_detail_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staff_contract_id` int(11) unsigned NOT NULL,
  `type` text DEFAULT NULL,
  `rel_type` text DEFAULT NULL,
  `rel_value` decimal(15,2) DEFAULT 0.00,
  `since_date` date DEFAULT NULL,
  `contract_note` text DEFAULT NULL,
  PRIMARY KEY (`contract_detail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhr_staff_contract_detail`
--

LOCK TABLES `abc1_tblhr_staff_contract_detail` WRITE;
/*!40000 ALTER TABLE `abc1_tblhr_staff_contract_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhr_staff_contract_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhr_staff_contract_type`
--

DROP TABLE IF EXISTS `abc1_tblhr_staff_contract_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhr_staff_contract_type` (
  `id_contracttype` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name_contracttype` varchar(200) NOT NULL,
  `description` longtext DEFAULT NULL,
  `duration` int(11) DEFAULT NULL,
  `unit` varchar(20) DEFAULT NULL,
  `insurance` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id_contracttype`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhr_staff_contract_type`
--

LOCK TABLES `abc1_tblhr_staff_contract_type` WRITE;
/*!40000 ALTER TABLE `abc1_tblhr_staff_contract_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhr_staff_contract_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhr_training_allocation`
--

DROP TABLE IF EXISTS `abc1_tblhr_training_allocation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhr_training_allocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `training_process_id` varchar(100) NOT NULL,
  `staffid` int(11) DEFAULT NULL,
  `training_type` int(11) DEFAULT NULL,
  `date_add` datetime DEFAULT NULL,
  `training_name` varchar(150) DEFAULT NULL,
  `jp_interview_training_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhr_training_allocation`
--

LOCK TABLES `abc1_tblhr_training_allocation` WRITE;
/*!40000 ALTER TABLE `abc1_tblhr_training_allocation` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhr_training_allocation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhr_type_of_trainings`
--

DROP TABLE IF EXISTS `abc1_tblhr_type_of_trainings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhr_type_of_trainings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhr_type_of_trainings`
--

LOCK TABLES `abc1_tblhr_type_of_trainings` WRITE;
/*!40000 ALTER TABLE `abc1_tblhr_type_of_trainings` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhr_type_of_trainings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhr_views_tracking`
--

DROP TABLE IF EXISTS `abc1_tblhr_views_tracking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhr_views_tracking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(40) NOT NULL,
  `date` datetime NOT NULL,
  `view_ip` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhr_views_tracking`
--

LOCK TABLES `abc1_tblhr_views_tracking` WRITE;
/*!40000 ALTER TABLE `abc1_tblhr_views_tracking` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhr_views_tracking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhr_workplace`
--

DROP TABLE IF EXISTS `abc1_tblhr_workplace`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhr_workplace` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `workplace_address` varchar(400) DEFAULT NULL,
  `latitude` double DEFAULT NULL,
  `longitude` double DEFAULT NULL,
  `default` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhr_workplace`
--

LOCK TABLES `abc1_tblhr_workplace` WRITE;
/*!40000 ALTER TABLE `abc1_tblhr_workplace` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhr_workplace` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhrp_bonus_kpi`
--

DROP TABLE IF EXISTS `abc1_tblhrp_bonus_kpi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhrp_bonus_kpi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `month_bonus_kpi` varchar(45) DEFAULT NULL,
  `staffid` int(11) DEFAULT NULL,
  `bonus_kpi` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhrp_bonus_kpi`
--

LOCK TABLES `abc1_tblhrp_bonus_kpi` WRITE;
/*!40000 ALTER TABLE `abc1_tblhrp_bonus_kpi` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhrp_bonus_kpi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhrp_commissions`
--

DROP TABLE IF EXISTS `abc1_tblhrp_commissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhrp_commissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `month` date NOT NULL,
  `commission_amount` decimal(15,2) DEFAULT NULL,
  `rel_type` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhrp_commissions`
--

LOCK TABLES `abc1_tblhrp_commissions` WRITE;
/*!40000 ALTER TABLE `abc1_tblhrp_commissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhrp_commissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhrp_company_contributions_list`
--

DROP TABLE IF EXISTS `abc1_tblhrp_company_contributions_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhrp_company_contributions_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(200) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `rate` decimal(15,2) DEFAULT NULL,
  `basis` varchar(200) DEFAULT NULL,
  `earn_inclusion` varchar(200) DEFAULT NULL,
  `earn_exclusion` varchar(200) DEFAULT NULL,
  `earnings_max` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhrp_company_contributions_list`
--

LOCK TABLES `abc1_tblhrp_company_contributions_list` WRITE;
/*!40000 ALTER TABLE `abc1_tblhrp_company_contributions_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhrp_company_contributions_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhrp_customize_staff_payslip_columns`
--

DROP TABLE IF EXISTS `abc1_tblhrp_customize_staff_payslip_columns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhrp_customize_staff_payslip_columns` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `column_name` text DEFAULT NULL,
  `order_number` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhrp_customize_staff_payslip_columns`
--

LOCK TABLES `abc1_tblhrp_customize_staff_payslip_columns` WRITE;
/*!40000 ALTER TABLE `abc1_tblhrp_customize_staff_payslip_columns` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhrp_customize_staff_payslip_columns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhrp_earnings_list`
--

DROP TABLE IF EXISTS `abc1_tblhrp_earnings_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhrp_earnings_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(200) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `short_name` varchar(200) DEFAULT NULL,
  `taxable` decimal(15,2) DEFAULT NULL,
  `basis_type` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhrp_earnings_list`
--

LOCK TABLES `abc1_tblhrp_earnings_list` WRITE;
/*!40000 ALTER TABLE `abc1_tblhrp_earnings_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhrp_earnings_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhrp_earnings_list_hr_records`
--

DROP TABLE IF EXISTS `abc1_tblhrp_earnings_list_hr_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhrp_earnings_list_hr_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(200) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `short_name` varchar(200) DEFAULT NULL,
  `taxable` decimal(15,2) DEFAULT NULL,
  `basis_type` varchar(200) DEFAULT NULL,
  `rel_type` varchar(200) DEFAULT NULL,
  `rel_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhrp_earnings_list_hr_records`
--

LOCK TABLES `abc1_tblhrp_earnings_list_hr_records` WRITE;
/*!40000 ALTER TABLE `abc1_tblhrp_earnings_list_hr_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhrp_earnings_list_hr_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhrp_employees_timeshee_leaves`
--

DROP TABLE IF EXISTS `abc1_tblhrp_employees_timeshee_leaves`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhrp_employees_timeshee_leaves` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `month` date NOT NULL,
  `day_1` text DEFAULT '',
  `day_2` text DEFAULT '',
  `day_3` text DEFAULT '',
  `day_4` text DEFAULT '',
  `day_5` text DEFAULT '',
  `day_6` text DEFAULT '',
  `day_7` text DEFAULT '',
  `day_8` text DEFAULT '',
  `day_9` text DEFAULT '',
  `day_10` text DEFAULT '',
  `day_11` text DEFAULT '',
  `day_12` text DEFAULT '',
  `day_13` text DEFAULT '',
  `day_14` text DEFAULT '',
  `day_15` text DEFAULT '',
  `day_16` text DEFAULT '',
  `day_17` text DEFAULT '',
  `day_18` text DEFAULT '',
  `day_19` text DEFAULT '',
  `day_20` text DEFAULT '',
  `day_21` text DEFAULT '',
  `day_22` text DEFAULT '',
  `day_23` text DEFAULT '',
  `day_24` text DEFAULT '',
  `day_25` text DEFAULT '',
  `day_26` text DEFAULT '',
  `day_27` text DEFAULT '',
  `day_28` text DEFAULT '',
  `day_29` text DEFAULT '',
  `day_30` text DEFAULT '',
  `day_31` text DEFAULT '',
  `paid_leave` decimal(15,2) DEFAULT NULL,
  `unpaid_leave` decimal(15,2) DEFAULT NULL,
  `rel_type` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhrp_employees_timeshee_leaves`
--

LOCK TABLES `abc1_tblhrp_employees_timeshee_leaves` WRITE;
/*!40000 ALTER TABLE `abc1_tblhrp_employees_timeshee_leaves` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhrp_employees_timeshee_leaves` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhrp_employees_timesheets`
--

DROP TABLE IF EXISTS `abc1_tblhrp_employees_timesheets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhrp_employees_timesheets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `month` date NOT NULL,
  `day_1` decimal(15,2) DEFAULT 0.00,
  `day_2` decimal(15,2) DEFAULT 0.00,
  `day_3` decimal(15,2) DEFAULT 0.00,
  `day_4` decimal(15,2) DEFAULT 0.00,
  `day_5` decimal(15,2) DEFAULT 0.00,
  `day_6` decimal(15,2) DEFAULT 0.00,
  `day_7` decimal(15,2) DEFAULT 0.00,
  `day_8` decimal(15,2) DEFAULT 0.00,
  `day_9` decimal(15,2) DEFAULT 0.00,
  `day_10` decimal(15,2) DEFAULT 0.00,
  `day_11` decimal(15,2) DEFAULT 0.00,
  `day_12` decimal(15,2) DEFAULT 0.00,
  `day_13` decimal(15,2) DEFAULT 0.00,
  `day_14` decimal(15,2) DEFAULT 0.00,
  `day_15` decimal(15,2) DEFAULT 0.00,
  `day_16` decimal(15,2) DEFAULT 0.00,
  `day_17` decimal(15,2) DEFAULT 0.00,
  `day_18` decimal(15,2) DEFAULT 0.00,
  `day_19` decimal(15,2) DEFAULT 0.00,
  `day_20` decimal(15,2) DEFAULT 0.00,
  `day_21` decimal(15,2) DEFAULT 0.00,
  `day_22` decimal(15,2) DEFAULT 0.00,
  `day_23` decimal(15,2) DEFAULT 0.00,
  `day_24` decimal(15,2) DEFAULT 0.00,
  `day_25` decimal(15,2) DEFAULT 0.00,
  `day_26` decimal(15,2) DEFAULT 0.00,
  `day_27` decimal(15,2) DEFAULT 0.00,
  `day_28` decimal(15,2) DEFAULT 0.00,
  `day_29` decimal(15,2) DEFAULT 0.00,
  `day_30` decimal(15,2) DEFAULT 0.00,
  `day_31` decimal(15,2) DEFAULT 0.00,
  `standard_workday` decimal(15,2) DEFAULT NULL,
  `actual_workday` decimal(15,2) DEFAULT NULL,
  `paid_leave` decimal(15,2) DEFAULT NULL,
  `unpaid_leave` decimal(15,2) DEFAULT NULL,
  `rel_type` varchar(100) DEFAULT NULL,
  `actual_workday_probation` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhrp_employees_timesheets`
--

LOCK TABLES `abc1_tblhrp_employees_timesheets` WRITE;
/*!40000 ALTER TABLE `abc1_tblhrp_employees_timesheets` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhrp_employees_timesheets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhrp_employees_value`
--

DROP TABLE IF EXISTS `abc1_tblhrp_employees_value`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhrp_employees_value` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `month` date NOT NULL,
  `job_title` varchar(200) DEFAULT NULL,
  `income_tax_number` varchar(200) DEFAULT NULL,
  `residential_address` text DEFAULT NULL,
  `income_rebate_code` varchar(200) DEFAULT NULL,
  `income_tax_rate` varchar(200) DEFAULT NULL,
  `probationary_contracts` longtext DEFAULT NULL,
  `primary_contracts` longtext DEFAULT NULL,
  `rel_type` varchar(100) DEFAULT NULL,
  `probationary_effective` date DEFAULT NULL,
  `probationary_expiration` date DEFAULT NULL,
  `primary_effective` date DEFAULT NULL,
  `primary_expiration` date DEFAULT NULL,
  `bank_name` varchar(500) DEFAULT NULL,
  `account_number` varchar(200) DEFAULT NULL,
  `epf_no` text DEFAULT NULL,
  `social_security_no` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhrp_employees_value`
--

LOCK TABLES `abc1_tblhrp_employees_value` WRITE;
/*!40000 ALTER TABLE `abc1_tblhrp_employees_value` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhrp_employees_value` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhrp_income_tax_rates`
--

DROP TABLE IF EXISTS `abc1_tblhrp_income_tax_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhrp_income_tax_rates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tax_bracket_value_from` decimal(15,2) DEFAULT NULL,
  `tax_bracket_value_to` decimal(15,2) DEFAULT NULL,
  `tax_rate` decimal(15,2) DEFAULT NULL,
  `equivalent_value` decimal(15,2) DEFAULT NULL,
  `effective_rate` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhrp_income_tax_rates`
--

LOCK TABLES `abc1_tblhrp_income_tax_rates` WRITE;
/*!40000 ALTER TABLE `abc1_tblhrp_income_tax_rates` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhrp_income_tax_rates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhrp_income_tax_rebates`
--

DROP TABLE IF EXISTS `abc1_tblhrp_income_tax_rebates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhrp_income_tax_rebates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(200) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `value` decimal(15,2) DEFAULT NULL,
  `total` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhrp_income_tax_rebates`
--

LOCK TABLES `abc1_tblhrp_income_tax_rebates` WRITE;
/*!40000 ALTER TABLE `abc1_tblhrp_income_tax_rebates` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhrp_income_tax_rebates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhrp_income_taxs`
--

DROP TABLE IF EXISTS `abc1_tblhrp_income_taxs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhrp_income_taxs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `month` date NOT NULL,
  `gross_amount` decimal(15,2) DEFAULT NULL,
  `total_deduction_amount` decimal(15,2) DEFAULT NULL,
  `income_tax` decimal(15,2) DEFAULT NULL,
  `payslip_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhrp_income_taxs`
--

LOCK TABLES `abc1_tblhrp_income_taxs` WRITE;
/*!40000 ALTER TABLE `abc1_tblhrp_income_taxs` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhrp_income_taxs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhrp_insurance_list`
--

DROP TABLE IF EXISTS `abc1_tblhrp_insurance_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhrp_insurance_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(200) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `rate` decimal(15,2) DEFAULT NULL,
  `basis` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhrp_insurance_list`
--

LOCK TABLES `abc1_tblhrp_insurance_list` WRITE;
/*!40000 ALTER TABLE `abc1_tblhrp_insurance_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhrp_insurance_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhrp_payroll_columns`
--

DROP TABLE IF EXISTS `abc1_tblhrp_payroll_columns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhrp_payroll_columns` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `column_key` text DEFAULT NULL,
  `taking_method` text DEFAULT NULL COMMENT 'get from system, caculator, constant... ',
  `function_name` text DEFAULT NULL COMMENT 'get value for method system',
  `value_related_to` text DEFAULT NULL COMMENT 'salary, allowance value...',
  `display_with_staff` varchar(10) DEFAULT 'true',
  `description` text DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `staff_id_created` int(11) NOT NULL,
  `order_display` int(11) DEFAULT NULL,
  `is_edit` varchar(100) DEFAULT 'yes',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhrp_payroll_columns`
--

LOCK TABLES `abc1_tblhrp_payroll_columns` WRITE;
/*!40000 ALTER TABLE `abc1_tblhrp_payroll_columns` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhrp_payroll_columns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhrp_payslip_details`
--

DROP TABLE IF EXISTS `abc1_tblhrp_payslip_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhrp_payslip_details` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `payslip_id` int(11) DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `month` date NOT NULL,
  `pay_slip_number` text DEFAULT NULL,
  `payment_run_date` date NOT NULL,
  `employee_number` text DEFAULT NULL,
  `employee_name` text DEFAULT NULL,
  `dept_name` text DEFAULT NULL,
  `standard_workday` decimal(15,2) DEFAULT 0.00,
  `actual_workday` decimal(15,2) DEFAULT 0.00,
  `paid_leave` decimal(15,2) DEFAULT 0.00,
  `unpaid_leave` decimal(15,2) DEFAULT 0.00,
  `gross_pay` decimal(15,2) DEFAULT 0.00,
  `income_tax_paye` decimal(15,2) DEFAULT 0.00,
  `total_deductions` decimal(15,2) DEFAULT 0.00,
  `net_pay` decimal(15,2) DEFAULT 0.00,
  `it_rebate_code` text DEFAULT NULL,
  `it_rebate_value` decimal(15,2) DEFAULT 0.00,
  `income_tax_code` text DEFAULT NULL,
  `commission_amount` decimal(15,2) DEFAULT 0.00,
  `bonus_kpi` decimal(15,2) DEFAULT 0.00,
  `total_cost` decimal(15,2) DEFAULT 0.00,
  `total_insurance` decimal(15,2) DEFAULT 0.00,
  `json_data` longtext DEFAULT NULL,
  `salary_of_the_probationary_contract` decimal(15,2) DEFAULT 0.00,
  `salary_of_the_formal_contract` decimal(15,2) DEFAULT 0.00,
  `taxable_salary` decimal(15,2) DEFAULT 0.00,
  `actual_workday_probation` decimal(15,2) DEFAULT 0.00,
  `total_hours_by_tasks` decimal(15,2) DEFAULT 0.00,
  `salary_from_tasks` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhrp_payslip_details`
--

LOCK TABLES `abc1_tblhrp_payslip_details` WRITE;
/*!40000 ALTER TABLE `abc1_tblhrp_payslip_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhrp_payslip_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhrp_payslip_pdf_templates`
--

DROP TABLE IF EXISTS `abc1_tblhrp_payslip_pdf_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhrp_payslip_pdf_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text DEFAULT NULL,
  `payslip_template_id` int(11) DEFAULT NULL,
  `content` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhrp_payslip_pdf_templates`
--

LOCK TABLES `abc1_tblhrp_payslip_pdf_templates` WRITE;
/*!40000 ALTER TABLE `abc1_tblhrp_payslip_pdf_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhrp_payslip_pdf_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhrp_payslip_templates`
--

DROP TABLE IF EXISTS `abc1_tblhrp_payslip_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhrp_payslip_templates` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `templates_name` varchar(100) NOT NULL,
  `payslip_columns` longtext DEFAULT NULL,
  `payslip_id_copy` int(11) unsigned NOT NULL,
  `department_id` longtext DEFAULT NULL,
  `role_employees` longtext DEFAULT NULL,
  `staff_employees` longtext DEFAULT NULL,
  `payslip_template_data` longtext DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `staff_id_created` int(11) NOT NULL,
  `cell_data` longtext DEFAULT NULL,
  `except_staff` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhrp_payslip_templates`
--

LOCK TABLES `abc1_tblhrp_payslip_templates` WRITE;
/*!40000 ALTER TABLE `abc1_tblhrp_payslip_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhrp_payslip_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhrp_payslips`
--

DROP TABLE IF EXISTS `abc1_tblhrp_payslips`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhrp_payslips` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `payslip_name` varchar(100) NOT NULL,
  `payslip_template_id` int(11) DEFAULT NULL,
  `payslip_month` date NOT NULL,
  `staff_id_created` int(11) NOT NULL,
  `date_created` datetime NOT NULL,
  `payslip_data` longtext DEFAULT NULL,
  `file_name` text DEFAULT NULL,
  `payslip_status` varchar(100) DEFAULT 'payslip_opening',
  `payslip_range` varchar(500) DEFAULT NULL,
  `pdf_template_id` int(11) DEFAULT NULL,
  `from_currency_id` int(11) DEFAULT 0,
  `from_currency_name` varchar(100) DEFAULT NULL,
  `from_currency_rate` decimal(15,6) NOT NULL DEFAULT 1.000000,
  `to_currency_id` int(11) DEFAULT 0,
  `to_currency_name` varchar(100) DEFAULT NULL,
  `to_currency_rate` decimal(15,6) NOT NULL DEFAULT 1.000000,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhrp_payslips`
--

LOCK TABLES `abc1_tblhrp_payslips` WRITE;
/*!40000 ALTER TABLE `abc1_tblhrp_payslips` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhrp_payslips` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhrp_salary_deductions`
--

DROP TABLE IF EXISTS `abc1_tblhrp_salary_deductions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhrp_salary_deductions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `month` date NOT NULL,
  `deduction_list` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhrp_salary_deductions`
--

LOCK TABLES `abc1_tblhrp_salary_deductions` WRITE;
/*!40000 ALTER TABLE `abc1_tblhrp_salary_deductions` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhrp_salary_deductions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhrp_salary_deductions_list`
--

DROP TABLE IF EXISTS `abc1_tblhrp_salary_deductions_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhrp_salary_deductions_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(200) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `rate` decimal(15,2) DEFAULT NULL,
  `basis` varchar(200) DEFAULT NULL,
  `earn_inclusion` varchar(200) DEFAULT NULL,
  `earn_exclusion` varchar(200) DEFAULT NULL,
  `earnings_max` decimal(15,2) DEFAULT NULL,
  `tax` decimal(15,2) DEFAULT NULL,
  `annual_tax_limit` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhrp_salary_deductions_list`
--

LOCK TABLES `abc1_tblhrp_salary_deductions_list` WRITE;
/*!40000 ALTER TABLE `abc1_tblhrp_salary_deductions_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhrp_salary_deductions_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblhrp_staff_insurances`
--

DROP TABLE IF EXISTS `abc1_tblhrp_staff_insurances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblhrp_staff_insurances` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `month` date NOT NULL,
  `insurance_list` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblhrp_staff_insurances`
--

LOCK TABLES `abc1_tblhrp_staff_insurances` WRITE;
/*!40000 ALTER TABLE `abc1_tblhrp_staff_insurances` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblhrp_staff_insurances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblinternal_delivery_note`
--

DROP TABLE IF EXISTS `abc1_tblinternal_delivery_note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblinternal_delivery_note` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `internal_delivery_name` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `date_c` date DEFAULT NULL,
  `date_add` date DEFAULT NULL,
  `internal_delivery_code` varchar(100) DEFAULT NULL,
  `approval` int(11) DEFAULT 0 COMMENT 'status approval ',
  `addedfrom` int(11) DEFAULT NULL,
  `total_amount` decimal(15,2) DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblinternal_delivery_note`
--

LOCK TABLES `abc1_tblinternal_delivery_note` WRITE;
/*!40000 ALTER TABLE `abc1_tblinternal_delivery_note` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblinternal_delivery_note` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblinternal_delivery_note_detail`
--

DROP TABLE IF EXISTS `abc1_tblinternal_delivery_note_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblinternal_delivery_note_detail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `internal_delivery_id` int(11) NOT NULL,
  `commodity_code` varchar(100) DEFAULT NULL,
  `from_stock_name` text DEFAULT NULL,
  `to_stock_name` text DEFAULT NULL,
  `unit_id` text DEFAULT NULL,
  `available_quantity` text DEFAULT NULL,
  `quantities` text DEFAULT NULL,
  `unit_price` varchar(100) DEFAULT NULL,
  `into_money` varchar(100) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `commodity_name` text DEFAULT NULL,
  `serial_number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblinternal_delivery_note_detail`
--

LOCK TABLES `abc1_tblinternal_delivery_note_detail` WRITE;
/*!40000 ALTER TABLE `abc1_tblinternal_delivery_note_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblinternal_delivery_note_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblinventory_commodity_min`
--

DROP TABLE IF EXISTS `abc1_tblinventory_commodity_min`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblinventory_commodity_min` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `commodity_id` int(11) NOT NULL,
  `commodity_code` varchar(100) DEFAULT NULL,
  `commodity_name` varchar(100) DEFAULT NULL,
  `inventory_number_min` varchar(100) DEFAULT NULL,
  `inventory_number_max` varchar(100) DEFAULT '0',
  PRIMARY KEY (`id`,`commodity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblinventory_commodity_min`
--

LOCK TABLES `abc1_tblinventory_commodity_min` WRITE;
/*!40000 ALTER TABLE `abc1_tblinventory_commodity_min` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblinventory_commodity_min` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblinventory_manage`
--

DROP TABLE IF EXISTS `abc1_tblinventory_manage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblinventory_manage` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `warehouse_id` int(11) NOT NULL,
  `commodity_id` int(11) NOT NULL,
  `inventory_number` varchar(100) DEFAULT NULL,
  `date_manufacture` date DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `lot_number` varchar(100) DEFAULT NULL,
  `purchase_price` decimal(15,2) DEFAULT 0.00,
  `lot_id` int(11) DEFAULT NULL,
  `rack_id` int(11) DEFAULT NULL,
  `shelf_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`,`commodity_id`,`warehouse_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblinventory_manage`
--

LOCK TABLES `abc1_tblinventory_manage` WRITE;
/*!40000 ALTER TABLE `abc1_tblinventory_manage` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblinventory_manage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblinvoicepaymentrecords`
--

DROP TABLE IF EXISTS `abc1_tblinvoicepaymentrecords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblinvoicepaymentrecords` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoiceid` int(11) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `paymentmode` varchar(40) DEFAULT NULL,
  `paymentmethod` varchar(191) DEFAULT NULL,
  `date` date NOT NULL,
  `daterecorded` datetime NOT NULL,
  `note` mediumtext DEFAULT NULL,
  `transactionid` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `invoiceid` (`invoiceid`),
  KEY `paymentmethod` (`paymentmethod`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblinvoicepaymentrecords`
--

LOCK TABLES `abc1_tblinvoicepaymentrecords` WRITE;
/*!40000 ALTER TABLE `abc1_tblinvoicepaymentrecords` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblinvoicepaymentrecords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblinvoices`
--

DROP TABLE IF EXISTS `abc1_tblinvoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblinvoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sent` tinyint(1) NOT NULL DEFAULT 0,
  `datesend` datetime DEFAULT NULL,
  `clientid` int(11) NOT NULL,
  `deleted_customer_name` varchar(100) DEFAULT NULL,
  `number` int(11) NOT NULL,
  `prefix` varchar(50) DEFAULT NULL,
  `number_format` int(11) NOT NULL DEFAULT 0,
  `datecreated` datetime NOT NULL,
  `date` date NOT NULL,
  `duedate` date DEFAULT NULL,
  `currency` int(11) NOT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `total_tax` decimal(15,2) NOT NULL DEFAULT 0.00,
  `total` decimal(15,2) NOT NULL,
  `adjustment` decimal(15,2) DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `hash` varchar(32) NOT NULL,
  `status` int(11) DEFAULT 1,
  `clientnote` mediumtext DEFAULT NULL,
  `adminnote` mediumtext DEFAULT NULL,
  `last_overdue_reminder` date DEFAULT NULL,
  `last_due_reminder` date DEFAULT NULL,
  `cancel_overdue_reminders` int(11) NOT NULL DEFAULT 0,
  `allowed_payment_modes` longtext DEFAULT NULL,
  `token` longtext DEFAULT NULL,
  `discount_percent` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `discount_type` varchar(30) NOT NULL,
  `recurring` int(11) NOT NULL DEFAULT 0,
  `recurring_type` varchar(10) DEFAULT NULL,
  `custom_recurring` tinyint(1) NOT NULL DEFAULT 0,
  `cycles` int(11) NOT NULL DEFAULT 0,
  `total_cycles` int(11) NOT NULL DEFAULT 0,
  `is_recurring_from` int(11) DEFAULT NULL,
  `last_recurring_date` date DEFAULT NULL,
  `terms` mediumtext DEFAULT NULL,
  `sale_agent` int(11) NOT NULL DEFAULT 0,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT NULL,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT NULL,
  `include_shipping` tinyint(1) NOT NULL,
  `show_shipping_on_invoice` tinyint(1) NOT NULL DEFAULT 1,
  `show_quantity_as` int(11) NOT NULL DEFAULT 1,
  `project_id` int(11) DEFAULT 0,
  `subscription_id` int(11) NOT NULL DEFAULT 0,
  `perfex_saas_packageid` int(11) DEFAULT NULL,
  `short_link` varchar(100) DEFAULT NULL,
  `from_fleet` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `currency` (`currency`),
  KEY `clientid` (`clientid`),
  KEY `project_id` (`project_id`),
  KEY `sale_agent` (`sale_agent`),
  KEY `total` (`total`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblinvoices`
--

LOCK TABLES `abc1_tblinvoices` WRITE;
/*!40000 ALTER TABLE `abc1_tblinvoices` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblinvoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblitem_group_discounts`
--

DROP TABLE IF EXISTS `abc1_tblitem_group_discounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblitem_group_discounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `discount` decimal(5,2) NOT NULL DEFAULT 0.00 COMMENT 'Custom discount % for this item and group',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_item_group` (`item_id`,`group_id`),
  KEY `group_id` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblitem_group_discounts`
--

LOCK TABLES `abc1_tblitem_group_discounts` WRITE;
/*!40000 ALTER TABLE `abc1_tblitem_group_discounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblitem_group_discounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblitem_tax`
--

DROP TABLE IF EXISTS `abc1_tblitem_tax`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblitem_tax` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemid` int(11) NOT NULL,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) NOT NULL,
  `taxrate` decimal(15,2) NOT NULL,
  `taxname` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `itemid` (`itemid`),
  KEY `rel_id` (`rel_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblitem_tax`
--

LOCK TABLES `abc1_tblitem_tax` WRITE;
/*!40000 ALTER TABLE `abc1_tblitem_tax` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblitem_tax` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblitemable`
--

DROP TABLE IF EXISTS `abc1_tblitemable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblitemable` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(15) NOT NULL,
  `description` longtext NOT NULL,
  `long_description` longtext DEFAULT NULL,
  `qty` decimal(15,2) NOT NULL,
  `rate` decimal(15,2) NOT NULL,
  `unit` varchar(40) DEFAULT NULL,
  `item_order` int(11) DEFAULT NULL,
  `wh_delivered_quantity` decimal(15,2) DEFAULT 0.00,
  `item_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`),
  KEY `qty` (`qty`),
  KEY `rate` (`rate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblitemable`
--

LOCK TABLES `abc1_tblitemable` WRITE;
/*!40000 ALTER TABLE `abc1_tblitemable` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblitemable` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblitems`
--

DROP TABLE IF EXISTS `abc1_tblitems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblitems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` longtext NOT NULL,
  `long_description` mediumtext DEFAULT NULL,
  `rate` decimal(15,2) NOT NULL,
  `tax` int(11) DEFAULT NULL,
  `tax2` int(11) DEFAULT NULL,
  `unit` varchar(40) DEFAULT NULL,
  `group_id` int(11) NOT NULL DEFAULT 0,
  `product_type` varchar(100) DEFAULT NULL,
  `description_internal_transfers` text DEFAULT NULL,
  `description_receipts` text DEFAULT NULL,
  `description_delivery_orders` text DEFAULT NULL,
  `customer_lead_time` decimal(15,2) DEFAULT 0.00,
  `replenish_on_order` varchar(100) DEFAULT NULL,
  `supplier_taxes_id` text DEFAULT NULL,
  `description_sale` text DEFAULT NULL,
  `invoice_policy` varchar(100) DEFAULT 'ordered_quantities',
  `purchase_unit_measure` int(11) DEFAULT NULL,
  `can_be_sold` varchar(100) DEFAULT 'can_be_sold',
  `can_be_purchased` varchar(100) DEFAULT 'can_be_purchased',
  `can_be_manufacturing` varchar(100) DEFAULT 'can_be_manufacturing',
  `manufacture` varchar(100) DEFAULT NULL,
  `manufacturing_lead_time` decimal(15,2) DEFAULT 0.00,
  `weight` decimal(15,2) DEFAULT 0.00,
  `volume` decimal(15,2) DEFAULT 0.00,
  `hs_code` varchar(200) DEFAULT NULL,
  `commodity_code` varchar(100) NOT NULL,
  `commodity_barcode` text DEFAULT NULL,
  `commodity_type` int(11) DEFAULT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `origin` varchar(100) DEFAULT NULL,
  `color_id` int(11) DEFAULT NULL,
  `style_id` int(11) DEFAULT NULL,
  `model_id` int(11) DEFAULT NULL,
  `size_id` int(11) DEFAULT NULL,
  `unit_id` int(11) DEFAULT NULL,
  `sku_code` varchar(200) DEFAULT NULL,
  `sku_name` varchar(200) DEFAULT NULL,
  `purchase_price` decimal(15,2) DEFAULT NULL,
  `sub_group` varchar(200) DEFAULT NULL,
  `commodity_name` varchar(200) NOT NULL,
  `color` text DEFAULT NULL,
  `guarantee` text DEFAULT NULL,
  `profif_ratio` text DEFAULT NULL,
  `active` int(11) DEFAULT 1,
  `long_descriptions` longtext DEFAULT NULL,
  `without_checking_warehouse` int(11) DEFAULT 0,
  `series_id` text DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `attributes` longtext DEFAULT NULL,
  `parent_attributes` longtext DEFAULT NULL,
  `can_be_inventory` varchar(100) DEFAULT 'can_be_inventory',
  `from_vendor_item` int(11) DEFAULT NULL,
  `thickness` decimal(10,3) DEFAULT NULL,
  `sort_name` varchar(100) DEFAULT NULL,
  `paperwork_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tax` (`tax`),
  KEY `tax2` (`tax2`),
  KEY `group_id` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblitems`
--

LOCK TABLES `abc1_tblitems` WRITE;
/*!40000 ALTER TABLE `abc1_tblitems` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblitems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblitems_groups`
--

DROP TABLE IF EXISTS `abc1_tblitems_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblitems_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `commodity_group_code` varchar(100) DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  `display` int(1) DEFAULT NULL,
  `note` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblitems_groups`
--

LOCK TABLES `abc1_tblitems_groups` WRITE;
/*!40000 ALTER TABLE `abc1_tblitems_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblitems_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblitems_of_vendor`
--

DROP TABLE IF EXISTS `abc1_tblitems_of_vendor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblitems_of_vendor` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `vendor_id` int(11) NOT NULL,
  `description` text NOT NULL,
  `long_description` text DEFAULT NULL,
  `rate` decimal(15,2) DEFAULT NULL,
  `tax` int(11) DEFAULT NULL,
  `tax2` int(11) DEFAULT NULL,
  `unit` varchar(40) DEFAULT NULL,
  `group_id` int(11) NOT NULL,
  `commodity_code` varchar(100) NOT NULL,
  `commodity_barcode` text DEFAULT NULL,
  `unit_id` int(11) DEFAULT NULL,
  `sku_code` varchar(200) DEFAULT NULL,
  `sku_name` varchar(200) DEFAULT NULL,
  `sub_group` varchar(200) DEFAULT NULL,
  `active` int(11) DEFAULT NULL,
  `parent` int(11) DEFAULT NULL,
  `attributes` longtext DEFAULT NULL,
  `parent_attributes` longtext DEFAULT NULL,
  `commodity_type` int(11) DEFAULT NULL,
  `origin` varchar(100) DEFAULT NULL,
  `commodity_name` varchar(200) NOT NULL,
  `series_id` text DEFAULT NULL,
  `long_descriptions` longtext DEFAULT NULL,
  `share_status` int(1) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblitems_of_vendor`
--

LOCK TABLES `abc1_tblitems_of_vendor` WRITE;
/*!40000 ALTER TABLE `abc1_tblitems_of_vendor` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblitems_of_vendor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tbljob_industry`
--

DROP TABLE IF EXISTS `abc1_tbljob_industry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tbljob_industry` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `industry_name` varchar(200) NOT NULL,
  `industry_description` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tbljob_industry`
--

LOCK TABLES `abc1_tbljob_industry` WRITE;
/*!40000 ALTER TABLE `abc1_tbljob_industry` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tbljob_industry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblknowedge_base_article_feedback`
--

DROP TABLE IF EXISTS `abc1_tblknowedge_base_article_feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblknowedge_base_article_feedback` (
  `articleanswerid` int(11) NOT NULL AUTO_INCREMENT,
  `articleid` int(11) NOT NULL,
  `answer` int(11) NOT NULL,
  `ip` varchar(40) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`articleanswerid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblknowedge_base_article_feedback`
--

LOCK TABLES `abc1_tblknowedge_base_article_feedback` WRITE;
/*!40000 ALTER TABLE `abc1_tblknowedge_base_article_feedback` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblknowedge_base_article_feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblknowledge_base`
--

DROP TABLE IF EXISTS `abc1_tblknowledge_base`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblknowledge_base` (
  `articleid` int(11) NOT NULL AUTO_INCREMENT,
  `articlegroup` int(11) NOT NULL,
  `subject` longtext NOT NULL,
  `description` mediumtext NOT NULL,
  `slug` longtext NOT NULL,
  `active` tinyint(4) NOT NULL,
  `datecreated` datetime NOT NULL,
  `article_order` int(11) NOT NULL DEFAULT 0,
  `staff_article` int(11) NOT NULL DEFAULT 0,
  `question_answers` int(11) DEFAULT 0,
  `file_name` varchar(255) DEFAULT '',
  `curator` varchar(11) DEFAULT '',
  `benchmark` int(11) DEFAULT 0,
  `score` int(11) DEFAULT 0,
  PRIMARY KEY (`articleid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblknowledge_base`
--

LOCK TABLES `abc1_tblknowledge_base` WRITE;
/*!40000 ALTER TABLE `abc1_tblknowledge_base` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblknowledge_base` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblknowledge_base_groups`
--

DROP TABLE IF EXISTS `abc1_tblknowledge_base_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblknowledge_base_groups` (
  `groupid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `group_slug` mediumtext DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `active` tinyint(4) NOT NULL,
  `color` varchar(10) DEFAULT '#28B8DA',
  `group_order` int(11) DEFAULT 0,
  PRIMARY KEY (`groupid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblknowledge_base_groups`
--

LOCK TABLES `abc1_tblknowledge_base_groups` WRITE;
/*!40000 ALTER TABLE `abc1_tblknowledge_base_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblknowledge_base_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tbllead_activity_log`
--

DROP TABLE IF EXISTS `abc1_tbllead_activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tbllead_activity_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `leadid` int(11) NOT NULL,
  `description` longtext NOT NULL,
  `additional_data` mediumtext DEFAULT NULL,
  `date` datetime NOT NULL,
  `staffid` int(11) NOT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `custom_activity` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tbllead_activity_log`
--

LOCK TABLES `abc1_tbllead_activity_log` WRITE;
/*!40000 ALTER TABLE `abc1_tbllead_activity_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tbllead_activity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tbllead_checkins`
--

DROP TABLE IF EXISTS `abc1_tbllead_checkins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tbllead_checkins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lead_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `type` enum('checkin','checkout') NOT NULL,
  `latitude` decimal(10,7) DEFAULT NULL,
  `longitude` decimal(10,7) DEFAULT NULL,
  `accuracy_m` decimal(8,2) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `lead_id` (`lead_id`),
  KEY `staff_id` (`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tbllead_checkins`
--

LOCK TABLES `abc1_tbllead_checkins` WRITE;
/*!40000 ALTER TABLE `abc1_tbllead_checkins` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tbllead_checkins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tbllead_integration_emails`
--

DROP TABLE IF EXISTS `abc1_tbllead_integration_emails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tbllead_integration_emails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` longtext DEFAULT NULL,
  `body` longtext DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  `leadid` int(11) NOT NULL,
  `emailid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tbllead_integration_emails`
--

LOCK TABLES `abc1_tbllead_integration_emails` WRITE;
/*!40000 ALTER TABLE `abc1_tbllead_integration_emails` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tbllead_integration_emails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblleads`
--

DROP TABLE IF EXISTS `abc1_tblleads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblleads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(65) DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `company` varchar(191) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `country` int(11) NOT NULL DEFAULT 0,
  `zip` varchar(15) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `assigned` int(11) NOT NULL DEFAULT 0,
  `dateadded` datetime NOT NULL,
  `from_form_id` int(11) NOT NULL DEFAULT 0,
  `status` int(11) NOT NULL,
  `source` int(11) NOT NULL,
  `lastcontact` datetime DEFAULT NULL,
  `dateassigned` date DEFAULT NULL,
  `last_status_change` datetime DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `website` varchar(150) DEFAULT NULL,
  `leadorder` int(11) DEFAULT 1,
  `phonenumber` varchar(50) DEFAULT NULL,
  `date_converted` datetime DEFAULT NULL,
  `lost` tinyint(1) NOT NULL DEFAULT 0,
  `junk` int(11) NOT NULL DEFAULT 0,
  `last_lead_status` int(11) NOT NULL DEFAULT 0,
  `is_imported_from_email_integration` tinyint(1) NOT NULL DEFAULT 0,
  `email_integration_uid` varchar(30) DEFAULT NULL,
  `is_public` tinyint(1) NOT NULL DEFAULT 0,
  `default_language` varchar(40) DEFAULT NULL,
  `client_id` int(11) NOT NULL DEFAULT 0,
  `lead_value` decimal(15,2) DEFAULT NULL,
  `vat` varchar(50) DEFAULT NULL,
  `from_ma_form_id` int(11) NOT NULL DEFAULT 0,
  `ma_point` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `company` (`company`),
  KEY `email` (`email`),
  KEY `assigned` (`assigned`),
  KEY `status` (`status`),
  KEY `source` (`source`),
  KEY `lastcontact` (`lastcontact`),
  KEY `dateadded` (`dateadded`),
  KEY `leadorder` (`leadorder`),
  KEY `from_form_id` (`from_form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblleads`
--

LOCK TABLES `abc1_tblleads` WRITE;
/*!40000 ALTER TABLE `abc1_tblleads` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblleads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblleads_email_integration`
--

DROP TABLE IF EXISTS `abc1_tblleads_email_integration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblleads_email_integration` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'the ID always must be 1',
  `active` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `imap_server` varchar(100) NOT NULL,
  `password` longtext NOT NULL,
  `check_every` int(11) NOT NULL DEFAULT 5,
  `responsible` int(11) NOT NULL,
  `lead_source` int(11) NOT NULL,
  `lead_status` int(11) NOT NULL,
  `encryption` varchar(3) DEFAULT NULL,
  `folder` varchar(100) NOT NULL,
  `last_run` varchar(50) DEFAULT NULL,
  `notify_lead_imported` tinyint(1) NOT NULL DEFAULT 1,
  `notify_lead_contact_more_times` tinyint(1) NOT NULL DEFAULT 1,
  `notify_type` varchar(20) DEFAULT NULL,
  `notify_ids` longtext DEFAULT NULL,
  `mark_public` int(11) NOT NULL DEFAULT 0,
  `only_loop_on_unseen_emails` tinyint(1) NOT NULL DEFAULT 1,
  `delete_after_import` int(11) NOT NULL DEFAULT 0,
  `create_task_if_customer` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblleads_email_integration`
--

LOCK TABLES `abc1_tblleads_email_integration` WRITE;
/*!40000 ALTER TABLE `abc1_tblleads_email_integration` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblleads_email_integration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblleads_sources`
--

DROP TABLE IF EXISTS `abc1_tblleads_sources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblleads_sources` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblleads_sources`
--

LOCK TABLES `abc1_tblleads_sources` WRITE;
/*!40000 ALTER TABLE `abc1_tblleads_sources` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblleads_sources` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblleads_status`
--

DROP TABLE IF EXISTS `abc1_tblleads_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblleads_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `statusorder` int(11) DEFAULT NULL,
  `color` varchar(10) DEFAULT '#28B8DA',
  `isdefault` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblleads_status`
--

LOCK TABLES `abc1_tblleads_status` WRITE;
/*!40000 ALTER TABLE `abc1_tblleads_status` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblleads_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblleave_of_the_year`
--

DROP TABLE IF EXISTS `abc1_tblleave_of_the_year`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblleave_of_the_year` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `value` double DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblleave_of_the_year`
--

LOCK TABLES `abc1_tblleave_of_the_year` WRITE;
/*!40000 ALTER TABLE `abc1_tblleave_of_the_year` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblleave_of_the_year` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tbllist_widget`
--

DROP TABLE IF EXISTS `abc1_tbllist_widget`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tbllist_widget` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `add_from` int(11) NOT NULL,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(45) DEFAULT NULL,
  `layout` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tbllist_widget`
--

LOCK TABLES `abc1_tbllist_widget` WRITE;
/*!40000 ALTER TABLE `abc1_tbllist_widget` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tbllist_widget` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tbllistemails`
--

DROP TABLE IF EXISTS `abc1_tbllistemails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tbllistemails` (
  `emailid` int(11) NOT NULL AUTO_INCREMENT,
  `listid` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`emailid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tbllistemails`
--

LOCK TABLES `abc1_tbllistemails` WRITE;
/*!40000 ALTER TABLE `abc1_tbllistemails` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tbllistemails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblloy_card`
--

DROP TABLE IF EXISTS `abc1_tblloy_card`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblloy_card` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `add_from` int(11) NOT NULL,
  `date_create` date DEFAULT NULL,
  `subject_card` int(2) DEFAULT 0,
  `client_name` int(2) DEFAULT 0,
  `membership` int(2) DEFAULT 0,
  `company_name` int(2) DEFAULT 0,
  `member_since` int(2) DEFAULT 0,
  `custom_field` int(2) DEFAULT 0,
  `custom_field_content` varchar(200) DEFAULT NULL,
  `text_color` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblloy_card`
--

LOCK TABLES `abc1_tblloy_card` WRITE;
/*!40000 ALTER TABLE `abc1_tblloy_card` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblloy_card` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblloy_mbs_program`
--

DROP TABLE IF EXISTS `abc1_tblloy_mbs_program`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblloy_mbs_program` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `program_name` varchar(200) NOT NULL,
  `add_from` int(11) NOT NULL,
  `date_create` date DEFAULT NULL,
  `voucher_code` text NOT NULL,
  `discount` varchar(30) DEFAULT NULL,
  `discount_percent` int(5) DEFAULT NULL,
  `loyalty_point_from` decimal(15,0) DEFAULT NULL,
  `loyalty_point_to` decimal(15,0) DEFAULT NULL,
  `membership` text NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `note` text DEFAULT NULL,
  `voucher_value` decimal(15,2) DEFAULT 0.00,
  `formal` int(1) DEFAULT 1,
  `minium_purchase` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblloy_mbs_program`
--

LOCK TABLES `abc1_tblloy_mbs_program` WRITE;
/*!40000 ALTER TABLE `abc1_tblloy_mbs_program` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblloy_mbs_program` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblloy_mbs_rule`
--

DROP TABLE IF EXISTS `abc1_tblloy_mbs_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblloy_mbs_rule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `add_from` int(11) NOT NULL,
  `date_create` date DEFAULT NULL,
  `client_group` int(11) DEFAULT NULL,
  `client` text NOT NULL,
  `loyalty_point_from` decimal(15,0) DEFAULT NULL,
  `loyalty_point_to` decimal(15,0) DEFAULT NULL,
  `card` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblloy_mbs_rule`
--

LOCK TABLES `abc1_tblloy_mbs_rule` WRITE;
/*!40000 ALTER TABLE `abc1_tblloy_mbs_rule` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblloy_mbs_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblloy_program_detail`
--

DROP TABLE IF EXISTS `abc1_tblloy_program_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblloy_program_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mbs_program` int(11) NOT NULL,
  `rel_type` varchar(30) NOT NULL,
  `rel_id` text NOT NULL,
  `percent` int(5) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblloy_program_detail`
--

LOCK TABLES `abc1_tblloy_program_detail` WRITE;
/*!40000 ALTER TABLE `abc1_tblloy_program_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblloy_program_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblloy_redeem_log`
--

DROP TABLE IF EXISTS `abc1_tblloy_redeem_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblloy_redeem_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client` int(11) NOT NULL,
  `cart` int(11) DEFAULT NULL,
  `invoice` int(11) DEFAULT NULL,
  `time` datetime DEFAULT NULL,
  `old_point` decimal(10,0) DEFAULT NULL,
  `new_point` decimal(10,0) DEFAULT NULL,
  `redeep_from` decimal(10,0) DEFAULT NULL,
  `redeep_to` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblloy_redeem_log`
--

LOCK TABLES `abc1_tblloy_redeem_log` WRITE;
/*!40000 ALTER TABLE `abc1_tblloy_redeem_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblloy_redeem_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblloy_redemp_detail`
--

DROP TABLE IF EXISTS `abc1_tblloy_redemp_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblloy_redemp_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `loy_rule` int(11) NOT NULL,
  `rule_name` varchar(200) NOT NULL,
  `point_from` decimal(15,0) DEFAULT NULL,
  `point_to` decimal(15,0) DEFAULT NULL,
  `point_weight` decimal(15,2) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblloy_redemp_detail`
--

LOCK TABLES `abc1_tblloy_redemp_detail` WRITE;
/*!40000 ALTER TABLE `abc1_tblloy_redemp_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblloy_redemp_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblloy_rule`
--

DROP TABLE IF EXISTS `abc1_tblloy_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblloy_rule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(200) NOT NULL,
  `add_from` int(11) NOT NULL,
  `date_create` date DEFAULT NULL,
  `enable` int(2) DEFAULT 0,
  `redeemp_type` varchar(15) DEFAULT NULL,
  `min_poin_to_redeem` decimal(15,0) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `rule_base` varchar(30) DEFAULT NULL,
  `minium_purchase` decimal(15,0) DEFAULT NULL,
  `poin_awarded` decimal(15,0) DEFAULT NULL,
  `purchase_value` decimal(15,0) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `redeem_portal` int(1) DEFAULT 0,
  `redeem_pos` int(1) DEFAULT 0,
  `client_group` int(11) DEFAULT 0,
  `client` text NOT NULL,
  `max_amount_received` int(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblloy_rule`
--

LOCK TABLES `abc1_tblloy_rule` WRITE;
/*!40000 ALTER TABLE `abc1_tblloy_rule` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblloy_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblloy_rule_detail`
--

DROP TABLE IF EXISTS `abc1_tblloy_rule_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblloy_rule_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `loy_rule` int(11) NOT NULL,
  `rel_type` varchar(30) NOT NULL,
  `rel_id` text NOT NULL,
  `loyalty_point` decimal(15,0) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblloy_rule_detail`
--

LOCK TABLES `abc1_tblloy_rule_detail` WRITE;
/*!40000 ALTER TABLE `abc1_tblloy_rule_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblloy_rule_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblloy_transation`
--

DROP TABLE IF EXISTS `abc1_tblloy_transation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblloy_transation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference` varchar(30) NOT NULL,
  `invoice` int(11) DEFAULT NULL,
  `client` int(11) NOT NULL,
  `add_from` int(11) DEFAULT NULL,
  `date_create` datetime DEFAULT NULL,
  `loyalty_point` decimal(15,0) DEFAULT NULL,
  `type` varchar(30) DEFAULT NULL,
  `note` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblloy_transation`
--

LOCK TABLES `abc1_tblloy_transation` WRITE;
/*!40000 ALTER TABLE `abc1_tblloy_transation` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblloy_transation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblmail_queue`
--

DROP TABLE IF EXISTS `abc1_tblmail_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblmail_queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `engine` varchar(40) DEFAULT NULL,
  `email` varchar(191) NOT NULL,
  `cc` mediumtext DEFAULT NULL,
  `bcc` mediumtext DEFAULT NULL,
  `message` longtext NOT NULL,
  `alt_message` longtext DEFAULT NULL,
  `status` enum('pending','sending','sent','failed') DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `headers` mediumtext DEFAULT NULL,
  `attachments` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblmail_queue`
--

LOCK TABLES `abc1_tblmail_queue` WRITE;
/*!40000 ALTER TABLE `abc1_tblmail_queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblmail_queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblmailflow_email_templates`
--

DROP TABLE IF EXISTS `abc1_tblmailflow_email_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblmailflow_email_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_name` text DEFAULT NULL,
  `template_subject` text DEFAULT NULL,
  `template_content` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblmailflow_email_templates`
--

LOCK TABLES `abc1_tblmailflow_email_templates` WRITE;
/*!40000 ALTER TABLE `abc1_tblmailflow_email_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblmailflow_email_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblmailflow_newsletter_history`
--

DROP TABLE IF EXISTS `abc1_tblmailflow_newsletter_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblmailflow_newsletter_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sent_by` text DEFAULT NULL,
  `email_subject` text DEFAULT NULL,
  `email_content` text DEFAULT NULL,
  `total_emails_to_send` text DEFAULT NULL,
  `email_list` text DEFAULT NULL,
  `emails_sent` text DEFAULT NULL,
  `emails_failed` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblmailflow_newsletter_history`
--

LOCK TABLES `abc1_tblmailflow_newsletter_history` WRITE;
/*!40000 ALTER TABLE `abc1_tblmailflow_newsletter_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblmailflow_newsletter_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblmailflow_unsubscribed_emails`
--

DROP TABLE IF EXISTS `abc1_tblmailflow_unsubscribed_emails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblmailflow_unsubscribed_emails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblmailflow_unsubscribed_emails`
--

LOCK TABLES `abc1_tblmailflow_unsubscribed_emails` WRITE;
/*!40000 ALTER TABLE `abc1_tblmailflow_unsubscribed_emails` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblmailflow_unsubscribed_emails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblmaillistscustomfields`
--

DROP TABLE IF EXISTS `abc1_tblmaillistscustomfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblmaillistscustomfields` (
  `customfieldid` int(11) NOT NULL AUTO_INCREMENT,
  `listid` int(11) NOT NULL,
  `fieldname` varchar(150) NOT NULL,
  `fieldslug` varchar(100) NOT NULL,
  PRIMARY KEY (`customfieldid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblmaillistscustomfields`
--

LOCK TABLES `abc1_tblmaillistscustomfields` WRITE;
/*!40000 ALTER TABLE `abc1_tblmaillistscustomfields` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblmaillistscustomfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblmaillistscustomfieldvalues`
--

DROP TABLE IF EXISTS `abc1_tblmaillistscustomfieldvalues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblmaillistscustomfieldvalues` (
  `customfieldvalueid` int(11) NOT NULL AUTO_INCREMENT,
  `listid` int(11) NOT NULL,
  `customfieldid` int(11) NOT NULL,
  `emailid` int(11) NOT NULL,
  `value` varchar(100) NOT NULL,
  PRIMARY KEY (`customfieldvalueid`),
  KEY `listid` (`listid`),
  KEY `customfieldid` (`customfieldid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblmaillistscustomfieldvalues`
--

LOCK TABLES `abc1_tblmaillistscustomfieldvalues` WRITE;
/*!40000 ALTER TABLE `abc1_tblmaillistscustomfieldvalues` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblmaillistscustomfieldvalues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblmanage_leave`
--

DROP TABLE IF EXISTS `abc1_tblmanage_leave`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblmanage_leave` (
  `leave_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_staff` int(11) NOT NULL,
  `leave_date` int(11) DEFAULT NULL,
  `leave_year` int(11) DEFAULT NULL,
  `accumulated_leave` int(11) DEFAULT NULL,
  `seniority_leave` int(11) DEFAULT NULL,
  `borrow_leave` int(11) DEFAULT NULL,
  `actual_leave` int(11) DEFAULT NULL,
  `expected_leave` int(11) DEFAULT NULL,
  PRIMARY KEY (`leave_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblmanage_leave`
--

LOCK TABLES `abc1_tblmanage_leave` WRITE;
/*!40000 ALTER TABLE `abc1_tblmanage_leave` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblmanage_leave` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblmfa_history_login`
--

DROP TABLE IF EXISTS `abc1_tblmfa_history_login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblmfa_history_login` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staff` int(11) NOT NULL,
  `type` varchar(100) NOT NULL,
  `status` varchar(50) NOT NULL,
  `mess` text DEFAULT NULL,
  `time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblmfa_history_login`
--

LOCK TABLES `abc1_tblmfa_history_login` WRITE;
/*!40000 ALTER TABLE `abc1_tblmfa_history_login` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblmfa_history_login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblmfa_options`
--

DROP TABLE IF EXISTS `abc1_tblmfa_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblmfa_options` (
  `option_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(200) NOT NULL,
  `option_val` longtext DEFAULT NULL,
  `auto` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`option_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblmfa_options`
--

LOCK TABLES `abc1_tblmfa_options` WRITE;
/*!40000 ALTER TABLE `abc1_tblmfa_options` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblmfa_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblmfa_security_code`
--

DROP TABLE IF EXISTS `abc1_tblmfa_security_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblmfa_security_code` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staff` int(11) NOT NULL,
  `code` text NOT NULL,
  `created_at` datetime NOT NULL,
  `type` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblmfa_security_code`
--

LOCK TABLES `abc1_tblmfa_security_code` WRITE;
/*!40000 ALTER TABLE `abc1_tblmfa_security_code` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblmfa_security_code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblmfa_send_code_logs`
--

DROP TABLE IF EXISTS `abc1_tblmfa_send_code_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblmfa_send_code_logs` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staff` int(11) NOT NULL,
  `type` varchar(100) NOT NULL,
  `status` varchar(50) NOT NULL,
  `mess` text DEFAULT NULL,
  `time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblmfa_send_code_logs`
--

LOCK TABLES `abc1_tblmfa_send_code_logs` WRITE;
/*!40000 ALTER TABLE `abc1_tblmfa_send_code_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblmfa_send_code_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblmigrations`
--

DROP TABLE IF EXISTS `abc1_tblmigrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblmigrations` (
  `version` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblmigrations`
--

LOCK TABLES `abc1_tblmigrations` WRITE;
/*!40000 ALTER TABLE `abc1_tblmigrations` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblmigrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblmilestones`
--

DROP TABLE IF EXISTS `abc1_tblmilestones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblmilestones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `description_visible_to_customer` tinyint(1) DEFAULT 0,
  `start_date` date DEFAULT NULL,
  `due_date` date NOT NULL,
  `project_id` int(11) NOT NULL,
  `color` varchar(10) DEFAULT NULL,
  `milestone_order` int(11) NOT NULL DEFAULT 0,
  `datecreated` date NOT NULL,
  `hide_from_customer` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblmilestones`
--

LOCK TABLES `abc1_tblmilestones` WRITE;
/*!40000 ALTER TABLE `abc1_tblmilestones` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblmilestones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblmo_scrap`
--

DROP TABLE IF EXISTS `abc1_tblmo_scrap`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblmo_scrap` (
  `ScrapID` int(11) NOT NULL,
  `manufacturing_order_id` int(11) NOT NULL,
  `work_order_id` int(11) DEFAULT NULL,
  `product_id` int(255) NOT NULL,
  `item_type` int(11) NOT NULL,
  `unit_id` int(255) NOT NULL,
  `scrap_type` enum('reuse','waste') NOT NULL DEFAULT 'waste',
  `scrap_source` enum('bom','routing','work_order','manual') NOT NULL DEFAULT 'manual',
  `expected_scrap_percentage` decimal(5,2) DEFAULT NULL,
  `estimated_quantity` decimal(10,2) DEFAULT NULL,
  `actual_quantity` decimal(10,2) NOT NULL,
  `scrap_value` decimal(10,2) DEFAULT NULL,
  `cost_allocation` decimal(10,2) DEFAULT NULL,
  `oee_impact` decimal(5,2) DEFAULT NULL,
  `scrap_status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `scrap_location_id` int(11) DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `bill_of_material_id` int(11) NOT NULL,
  `routing_id` int(11) NOT NULL,
  `operation_id` int(11) NOT NULL,
  `bill_of_material_product_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblmo_scrap`
--

LOCK TABLES `abc1_tblmo_scrap` WRITE;
/*!40000 ALTER TABLE `abc1_tblmo_scrap` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblmo_scrap` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblmodules`
--

DROP TABLE IF EXISTS `abc1_tblmodules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblmodules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module_name` varchar(55) NOT NULL,
  `installed_version` varchar(11) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblmodules`
--

LOCK TABLES `abc1_tblmodules` WRITE;
/*!40000 ALTER TABLE `abc1_tblmodules` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblmodules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblmrp_bill_of_material_details`
--

DROP TABLE IF EXISTS `abc1_tblmrp_bill_of_material_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblmrp_bill_of_material_details` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `bill_of_material_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL COMMENT 'Only Product variant do not get parent Product',
  `product_qty` decimal(15,2) DEFAULT 0.00,
  `unit_id` int(11) DEFAULT NULL,
  `apply_on_variants` text DEFAULT NULL,
  `operation_id` int(11) DEFAULT NULL,
  `display_order` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblmrp_bill_of_material_details`
--

LOCK TABLES `abc1_tblmrp_bill_of_material_details` WRITE;
/*!40000 ALTER TABLE `abc1_tblmrp_bill_of_material_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblmrp_bill_of_material_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblmrp_bill_of_materials`
--

DROP TABLE IF EXISTS `abc1_tblmrp_bill_of_materials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblmrp_bill_of_materials` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `bom_code` varchar(100) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `product_variant_id` int(11) DEFAULT NULL,
  `product_qty` decimal(15,2) DEFAULT 0.00,
  `unit_id` int(11) DEFAULT NULL,
  `routing_id` int(11) DEFAULT NULL,
  `bom_type` varchar(100) DEFAULT NULL,
  `ready_to_produce` varchar(200) DEFAULT NULL,
  `consumption` varchar(200) DEFAULT NULL,
  `labour_charges` decimal(10,2) DEFAULT NULL,
  `machinery_charges` decimal(10,2) DEFAULT NULL,
  `electricity_charges` decimal(10,2) DEFAULT NULL,
  `other_charges` decimal(10,2) DEFAULT NULL,
  `labour_charges_description` text DEFAULT NULL,
  `machinery_charges_description` text DEFAULT NULL,
  `electricity_charges_description` text DEFAULT NULL,
  `other_charges_description` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblmrp_bill_of_materials`
--

LOCK TABLES `abc1_tblmrp_bill_of_materials` WRITE;
/*!40000 ALTER TABLE `abc1_tblmrp_bill_of_materials` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblmrp_bill_of_materials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblmrp_bom_changes_logs`
--

DROP TABLE IF EXISTS `abc1_tblmrp_bom_changes_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblmrp_bom_changes_logs` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `manufacturing_order_id` int(11) DEFAULT NULL,
  `parent_product_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `unit_id` int(11) DEFAULT 0,
  `change_type` text DEFAULT NULL,
  `change_quantity` decimal(15,2) DEFAULT 0.00,
  `created_at` datetime DEFAULT NULL,
  `staff_id` int(11) DEFAULT 0,
  `description` text DEFAULT NULL,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` text DEFAULT NULL COMMENT 'receipt_note, delivery_note',
  `check_availability` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblmrp_bom_changes_logs`
--

LOCK TABLES `abc1_tblmrp_bom_changes_logs` WRITE;
/*!40000 ALTER TABLE `abc1_tblmrp_bom_changes_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblmrp_bom_changes_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblmrp_manufacturing_order_details`
--

DROP TABLE IF EXISTS `abc1_tblmrp_manufacturing_order_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblmrp_manufacturing_order_details` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `manufacturing_order_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `unit_id` int(11) DEFAULT NULL,
  `qty_to_consume` decimal(15,2) DEFAULT 0.00,
  `qty_reserved` decimal(15,2) DEFAULT 0.00,
  `qty_done` decimal(15,2) DEFAULT 0.00,
  `check_inventory_qty` varchar(10) DEFAULT NULL,
  `warehouse_id` text DEFAULT NULL,
  `lot_number` text DEFAULT NULL,
  `expiry_date` text DEFAULT NULL,
  `available_quantity` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblmrp_manufacturing_order_details`
--

LOCK TABLES `abc1_tblmrp_manufacturing_order_details` WRITE;
/*!40000 ALTER TABLE `abc1_tblmrp_manufacturing_order_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblmrp_manufacturing_order_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblmrp_manufacturing_orders`
--

DROP TABLE IF EXISTS `abc1_tblmrp_manufacturing_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblmrp_manufacturing_orders` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `manufacturing_order_code` varchar(100) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL COMMENT 'Only Product variant do not get parent Product',
  `product_qty` decimal(15,2) DEFAULT 0.00,
  `unit_id` int(11) DEFAULT NULL,
  `bom_id` int(11) DEFAULT NULL,
  `routing_id` int(11) DEFAULT NULL,
  `date_deadline` datetime DEFAULT NULL,
  `date_plan_from` datetime DEFAULT NULL,
  `date_planned_start` datetime DEFAULT NULL,
  `date_planned_finished` datetime DEFAULT NULL,
  `status` varchar(100) DEFAULT 'draft',
  `material_availability_status` varchar(100) DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `components_warehouse_id` text DEFAULT NULL,
  `finished_products_warehouse_id` text DEFAULT NULL,
  `purchase_request_id` int(11) DEFAULT NULL,
  `contact_id` int(11) DEFAULT NULL,
  `labour_charges` decimal(10,2) DEFAULT NULL,
  `machinery_charges` decimal(10,2) DEFAULT NULL,
  `electricity_charges` decimal(10,2) DEFAULT NULL,
  `other_charges` decimal(10,2) DEFAULT NULL,
  `labour_charges_description` text DEFAULT NULL,
  `machinery_charges_description` text DEFAULT NULL,
  `electricity_charges_description` text DEFAULT NULL,
  `other_charges_description` text DEFAULT NULL,
  `expected_labour_charges` decimal(10,2) DEFAULT NULL,
  `expected_machinery_charges` decimal(10,2) DEFAULT NULL,
  `expected_electricity_charges` decimal(10,2) DEFAULT NULL,
  `expected_other_charges` decimal(10,2) DEFAULT NULL,
  `estimate_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblmrp_manufacturing_orders`
--

LOCK TABLES `abc1_tblmrp_manufacturing_orders` WRITE;
/*!40000 ALTER TABLE `abc1_tblmrp_manufacturing_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblmrp_manufacturing_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblmrp_option`
--

DROP TABLE IF EXISTS `abc1_tblmrp_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblmrp_option` (
  `option_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(200) NOT NULL,
  `option_val` longtext DEFAULT NULL,
  `auto` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`option_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblmrp_option`
--

LOCK TABLES `abc1_tblmrp_option` WRITE;
/*!40000 ALTER TABLE `abc1_tblmrp_option` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblmrp_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblmrp_routing_details`
--

DROP TABLE IF EXISTS `abc1_tblmrp_routing_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblmrp_routing_details` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `routing_id` int(11) NOT NULL,
  `operation` varchar(200) DEFAULT NULL,
  `work_center_id` int(11) DEFAULT NULL,
  `duration_computation` varchar(200) DEFAULT NULL,
  `based_on` decimal(15,2) DEFAULT 0.00,
  `default_duration` decimal(15,2) DEFAULT 0.00,
  `start_next_operation` varchar(200) DEFAULT NULL,
  `quantity_process` decimal(15,2) DEFAULT 0.00,
  `description` text DEFAULT NULL,
  `display_order` decimal(15,2) DEFAULT 0.00,
  `staff_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblmrp_routing_details`
--

LOCK TABLES `abc1_tblmrp_routing_details` WRITE;
/*!40000 ALTER TABLE `abc1_tblmrp_routing_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblmrp_routing_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblmrp_routings`
--

DROP TABLE IF EXISTS `abc1_tblmrp_routings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblmrp_routings` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `routing_code` varchar(200) DEFAULT NULL,
  `routing_name` varchar(200) DEFAULT NULL,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblmrp_routings`
--

LOCK TABLES `abc1_tblmrp_routings` WRITE;
/*!40000 ALTER TABLE `abc1_tblmrp_routings` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblmrp_routings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblmrp_scrap`
--

DROP TABLE IF EXISTS `abc1_tblmrp_scrap`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblmrp_scrap` (
  `ScrapID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `manufacturing_order_id` int(11) NOT NULL,
  `product_id` int(255) NOT NULL,
  `unit_id` int(255) NOT NULL,
  `scrap_type` enum('component','finished_good') NOT NULL,
  `estimated_quantity` decimal(10,2) DEFAULT NULL,
  `actual_quantity` decimal(10,2) NOT NULL,
  `cost_allocation` decimal(10,2) DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`ScrapID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblmrp_scrap`
--

LOCK TABLES `abc1_tblmrp_scrap` WRITE;
/*!40000 ALTER TABLE `abc1_tblmrp_scrap` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblmrp_scrap` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblmrp_unit_measure_categories`
--

DROP TABLE IF EXISTS `abc1_tblmrp_unit_measure_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblmrp_unit_measure_categories` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `category_name` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblmrp_unit_measure_categories`
--

LOCK TABLES `abc1_tblmrp_unit_measure_categories` WRITE;
/*!40000 ALTER TABLE `abc1_tblmrp_unit_measure_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblmrp_unit_measure_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblmrp_work_centers`
--

DROP TABLE IF EXISTS `abc1_tblmrp_work_centers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblmrp_work_centers` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `work_center_name` varchar(200) DEFAULT NULL,
  `work_center_code` varchar(200) DEFAULT NULL,
  `working_hours` varchar(200) DEFAULT NULL,
  `time_efficiency` decimal(15,2) DEFAULT 0.00,
  `capacity` decimal(15,2) DEFAULT 0.00,
  `oee_target` decimal(15,2) DEFAULT 0.00,
  `time_start` decimal(15,2) DEFAULT 0.00,
  `time_stop` decimal(15,2) DEFAULT 0.00,
  `costs_hour` decimal(15,2) DEFAULT 0.00,
  `description` text DEFAULT NULL,
  `is_subcontract` tinyint(1) DEFAULT 0,
  `subcontractor_id` int(11) DEFAULT NULL,
  `vendor_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblmrp_work_centers`
--

LOCK TABLES `abc1_tblmrp_work_centers` WRITE;
/*!40000 ALTER TABLE `abc1_tblmrp_work_centers` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblmrp_work_centers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblmrp_work_order_details`
--

DROP TABLE IF EXISTS `abc1_tblmrp_work_order_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblmrp_work_order_details` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `work_order_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `to_consume` decimal(15,2) DEFAULT 0.00,
  `reserved` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblmrp_work_order_details`
--

LOCK TABLES `abc1_tblmrp_work_order_details` WRITE;
/*!40000 ALTER TABLE `abc1_tblmrp_work_order_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblmrp_work_order_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblmrp_work_order_time_trackings`
--

DROP TABLE IF EXISTS `abc1_tblmrp_work_order_time_trackings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblmrp_work_order_time_trackings` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `work_order_id` int(11) NOT NULL,
  `from_date` datetime DEFAULT NULL,
  `to_date` datetime DEFAULT NULL,
  `duration` decimal(15,2) DEFAULT 0.00,
  `staff_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblmrp_work_order_time_trackings`
--

LOCK TABLES `abc1_tblmrp_work_order_time_trackings` WRITE;
/*!40000 ALTER TABLE `abc1_tblmrp_work_order_time_trackings` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblmrp_work_order_time_trackings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblmrp_work_orders`
--

DROP TABLE IF EXISTS `abc1_tblmrp_work_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblmrp_work_orders` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `manufacturing_order_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `qty_produced` decimal(15,2) DEFAULT 0.00,
  `qty_production` decimal(15,2) DEFAULT 0.00,
  `qty_producing` decimal(15,2) DEFAULT 0.00,
  `unit_id` int(11) DEFAULT NULL,
  `routing_detail_id` int(11) DEFAULT NULL,
  `operation_name` text DEFAULT NULL,
  `work_center_id` int(11) DEFAULT NULL,
  `date_planned_start` datetime DEFAULT NULL,
  `date_planned_finished` datetime DEFAULT NULL,
  `date_start` datetime DEFAULT NULL,
  `date_finished` datetime DEFAULT NULL,
  `duration_expected` decimal(15,2) DEFAULT 0.00,
  `real_duration` decimal(15,2) DEFAULT 0.00,
  `status` varchar(100) DEFAULT NULL,
  `is_subcontract` tinyint(1) DEFAULT 0,
  `subcontractor_id` int(11) DEFAULT NULL,
  `subcontractor_name` varchar(255) DEFAULT NULL,
  `expected_delivery_date` date DEFAULT NULL,
  `subcontract_notes` text DEFAULT NULL,
  `subcontract_status` varchar(50) DEFAULT 'pending',
  `contact_id` int(11) DEFAULT NULL,
  `labour_charges` decimal(10,2) DEFAULT NULL,
  `machinery_charges` decimal(10,2) DEFAULT NULL,
  `electricity_charges` decimal(10,2) DEFAULT NULL,
  `other_charges` decimal(10,2) DEFAULT NULL,
  `labour_charges_description` text DEFAULT NULL,
  `machinery_charges_description` text DEFAULT NULL,
  `electricity_charges_description` text DEFAULT NULL,
  `other_charges_description` text DEFAULT NULL,
  `expected_labour_charges` decimal(10,2) DEFAULT NULL,
  `expected_machinery_charges` decimal(10,2) DEFAULT NULL,
  `expected_electricity_charges` decimal(10,2) DEFAULT NULL,
  `expected_other_charges` decimal(10,2) DEFAULT NULL,
  `estimate_id` int(11) DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblmrp_work_orders`
--

LOCK TABLES `abc1_tblmrp_work_orders` WRITE;
/*!40000 ALTER TABLE `abc1_tblmrp_work_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblmrp_work_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblmrp_working_hour_time_off`
--

DROP TABLE IF EXISTS `abc1_tblmrp_working_hour_time_off`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblmrp_working_hour_time_off` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `working_hour_id` int(11) NOT NULL,
  `reason` varchar(200) DEFAULT NULL,
  `starting_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblmrp_working_hour_time_off`
--

LOCK TABLES `abc1_tblmrp_working_hour_time_off` WRITE;
/*!40000 ALTER TABLE `abc1_tblmrp_working_hour_time_off` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblmrp_working_hour_time_off` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblmrp_working_hour_times`
--

DROP TABLE IF EXISTS `abc1_tblmrp_working_hour_times`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblmrp_working_hour_times` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `working_hour_id` int(11) NOT NULL,
  `working_hour_name` varchar(200) DEFAULT NULL,
  `day_of_week` varchar(100) DEFAULT NULL,
  `day_period` varchar(100) DEFAULT NULL,
  `work_from` time DEFAULT NULL,
  `work_to` time DEFAULT NULL,
  `starting_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblmrp_working_hour_times`
--

LOCK TABLES `abc1_tblmrp_working_hour_times` WRITE;
/*!40000 ALTER TABLE `abc1_tblmrp_working_hour_times` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblmrp_working_hour_times` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblmrp_working_hours`
--

DROP TABLE IF EXISTS `abc1_tblmrp_working_hours`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblmrp_working_hours` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `working_hour_name` varchar(200) DEFAULT NULL,
  `hours_per_day` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblmrp_working_hours`
--

LOCK TABLES `abc1_tblmrp_working_hours` WRITE;
/*!40000 ALTER TABLE `abc1_tblmrp_working_hours` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblmrp_working_hours` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblnaming_attr_pref`
--

DROP TABLE IF EXISTS `abc1_tblnaming_attr_pref`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblnaming_attr_pref` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_subgroup_pairs` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`group_subgroup_pairs`)),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblnaming_attr_pref`
--

LOCK TABLES `abc1_tblnaming_attr_pref` WRITE;
/*!40000 ALTER TABLE `abc1_tblnaming_attr_pref` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblnaming_attr_pref` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblnaming_attr_store`
--

DROP TABLE IF EXISTS `abc1_tblnaming_attr_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblnaming_attr_store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pref_id` int(11) NOT NULL,
  `attr_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `separator` varchar(10) DEFAULT ' - ',
  `display_order` int(11) DEFAULT 0,
  `use_attr` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `pref_id` (`pref_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblnaming_attr_store`
--

LOCK TABLES `abc1_tblnaming_attr_store` WRITE;
/*!40000 ALTER TABLE `abc1_tblnaming_attr_store` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblnaming_attr_store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblnewsfeed_comment_likes`
--

DROP TABLE IF EXISTS `abc1_tblnewsfeed_comment_likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblnewsfeed_comment_likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `postid` int(11) NOT NULL,
  `commentid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `dateliked` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblnewsfeed_comment_likes`
--

LOCK TABLES `abc1_tblnewsfeed_comment_likes` WRITE;
/*!40000 ALTER TABLE `abc1_tblnewsfeed_comment_likes` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblnewsfeed_comment_likes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblnewsfeed_post_comments`
--

DROP TABLE IF EXISTS `abc1_tblnewsfeed_post_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblnewsfeed_post_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` mediumtext DEFAULT NULL,
  `userid` int(11) NOT NULL,
  `postid` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblnewsfeed_post_comments`
--

LOCK TABLES `abc1_tblnewsfeed_post_comments` WRITE;
/*!40000 ALTER TABLE `abc1_tblnewsfeed_post_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblnewsfeed_post_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblnewsfeed_post_likes`
--

DROP TABLE IF EXISTS `abc1_tblnewsfeed_post_likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblnewsfeed_post_likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `postid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `dateliked` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblnewsfeed_post_likes`
--

LOCK TABLES `abc1_tblnewsfeed_post_likes` WRITE;
/*!40000 ALTER TABLE `abc1_tblnewsfeed_post_likes` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblnewsfeed_post_likes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblnewsfeed_posts`
--

DROP TABLE IF EXISTS `abc1_tblnewsfeed_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblnewsfeed_posts` (
  `postid` int(11) NOT NULL AUTO_INCREMENT,
  `creator` int(11) NOT NULL,
  `datecreated` datetime NOT NULL,
  `visibility` varchar(100) NOT NULL,
  `content` mediumtext NOT NULL,
  `pinned` int(11) NOT NULL,
  `datepinned` datetime DEFAULT NULL,
  PRIMARY KEY (`postid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblnewsfeed_posts`
--

LOCK TABLES `abc1_tblnewsfeed_posts` WRITE;
/*!40000 ALTER TABLE `abc1_tblnewsfeed_posts` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblnewsfeed_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblnotes`
--

DROP TABLE IF EXISTS `abc1_tblnotes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblnotes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `date_contacted` datetime DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblnotes`
--

LOCK TABLES `abc1_tblnotes` WRITE;
/*!40000 ALTER TABLE `abc1_tblnotes` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblnotes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblnotifications`
--

DROP TABLE IF EXISTS `abc1_tblnotifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblnotifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `isread` int(11) NOT NULL DEFAULT 0,
  `isread_inline` tinyint(1) NOT NULL DEFAULT 0,
  `date` datetime NOT NULL,
  `description` mediumtext NOT NULL,
  `fromuserid` int(11) NOT NULL,
  `fromclientid` int(11) NOT NULL DEFAULT 0,
  `from_fullname` varchar(100) NOT NULL,
  `touserid` int(11) NOT NULL,
  `fromcompany` int(11) DEFAULT NULL,
  `link` longtext DEFAULT NULL,
  `additional_data` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblnotifications`
--

LOCK TABLES `abc1_tblnotifications` WRITE;
/*!40000 ALTER TABLE `abc1_tblnotifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblnotifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tbloptions`
--

DROP TABLE IF EXISTS `abc1_tbloptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tbloptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `value` longtext NOT NULL,
  `autoload` tinyint(1) NOT NULL DEFAULT 1,
  `annual_turnover` decimal(15,2) DEFAULT 0.00 COMMENT 'Yearly turnover (?) as declared by admin or fetched from GSTR-3B',
  `einvoice_enabled` tinyint(1) DEFAULT 0 COMMENT 'True/False – whether E-Invoicing is enabled for this company',
  `einvoice_enforced` tinyint(1) DEFAULT 0 COMMENT 'True if system decides it must be enabled (auto based on turnover)',
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tbloptions`
--

LOCK TABLES `abc1_tbloptions` WRITE;
/*!40000 ALTER TABLE `abc1_tbloptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tbloptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblp_t_form_question_box_description`
--

DROP TABLE IF EXISTS `abc1_tblp_t_form_question_box_description`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblp_t_form_question_box_description` (
  `questionboxdescriptionid` int(11) NOT NULL AUTO_INCREMENT,
  `description` mediumtext NOT NULL,
  `boxid` mediumtext NOT NULL,
  `questionid` int(11) NOT NULL,
  `correct` int(11) DEFAULT 1 COMMENT '0: correct 1: incorrect',
  PRIMARY KEY (`questionboxdescriptionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblp_t_form_question_box_description`
--

LOCK TABLES `abc1_tblp_t_form_question_box_description` WRITE;
/*!40000 ALTER TABLE `abc1_tblp_t_form_question_box_description` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblp_t_form_question_box_description` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblpaperwork`
--

DROP TABLE IF EXISTS `abc1_tblpaperwork`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblpaperwork` (
  `paperwork_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `paperwork_code` varchar(100) DEFAULT NULL,
  `paperwork_name` varchar(100) DEFAULT NULL,
  `paperwork_hex` text DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  `display` tinyint(1) DEFAULT 1 COMMENT '1: display (yes), 0: not displayed (no)',
  `note` text DEFAULT NULL,
  PRIMARY KEY (`paperwork_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblpaperwork`
--

LOCK TABLES `abc1_tblpaperwork` WRITE;
/*!40000 ALTER TABLE `abc1_tblpaperwork` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblpaperwork` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblpayment_attempts`
--

DROP TABLE IF EXISTS `abc1_tblpayment_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblpayment_attempts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference` varchar(100) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `amount` double NOT NULL,
  `fee` double NOT NULL,
  `payment_gateway` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblpayment_attempts`
--

LOCK TABLES `abc1_tblpayment_attempts` WRITE;
/*!40000 ALTER TABLE `abc1_tblpayment_attempts` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblpayment_attempts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblpayment_modes`
--

DROP TABLE IF EXISTS `abc1_tblpayment_modes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblpayment_modes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `show_on_pdf` int(11) NOT NULL DEFAULT 0,
  `invoices_only` int(11) NOT NULL DEFAULT 0,
  `expenses_only` int(11) NOT NULL DEFAULT 0,
  `selected_by_default` int(11) NOT NULL DEFAULT 1,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblpayment_modes`
--

LOCK TABLES `abc1_tblpayment_modes` WRITE;
/*!40000 ALTER TABLE `abc1_tblpayment_modes` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblpayment_modes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblpinned_projects`
--

DROP TABLE IF EXISTS `abc1_tblpinned_projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblpinned_projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblpinned_projects`
--

LOCK TABLES `abc1_tblpinned_projects` WRITE;
/*!40000 ALTER TABLE `abc1_tblpinned_projects` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblpinned_projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblposition_training_question_form`
--

DROP TABLE IF EXISTS `abc1_tblposition_training_question_form`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblposition_training_question_form` (
  `questionid` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) DEFAULT NULL,
  `question` mediumtext NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT 0,
  `question_order` int(11) NOT NULL,
  `point` int(11) NOT NULL,
  PRIMARY KEY (`questionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblposition_training_question_form`
--

LOCK TABLES `abc1_tblposition_training_question_form` WRITE;
/*!40000 ALTER TABLE `abc1_tblposition_training_question_form` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblposition_training_question_form` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblproject_activity`
--

DROP TABLE IF EXISTS `abc1_tblproject_activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblproject_activity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL DEFAULT 0,
  `contact_id` int(11) NOT NULL DEFAULT 0,
  `fullname` varchar(100) DEFAULT NULL,
  `visible_to_customer` int(11) NOT NULL DEFAULT 0,
  `description_key` varchar(191) NOT NULL COMMENT 'Language file key',
  `additional_data` mediumtext DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblproject_activity`
--

LOCK TABLES `abc1_tblproject_activity` WRITE;
/*!40000 ALTER TABLE `abc1_tblproject_activity` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblproject_activity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblproject_files`
--

DROP TABLE IF EXISTS `abc1_tblproject_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblproject_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file_name` varchar(191) NOT NULL,
  `original_file_name` longtext DEFAULT NULL,
  `subject` varchar(191) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `filetype` varchar(50) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  `last_activity` datetime DEFAULT NULL,
  `project_id` int(11) NOT NULL,
  `visible_to_customer` tinyint(1) DEFAULT 0,
  `staffid` int(11) NOT NULL,
  `contact_id` int(11) NOT NULL DEFAULT 0,
  `external` varchar(40) DEFAULT NULL,
  `external_link` mediumtext DEFAULT NULL,
  `thumbnail_link` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblproject_files`
--

LOCK TABLES `abc1_tblproject_files` WRITE;
/*!40000 ALTER TABLE `abc1_tblproject_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblproject_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblproject_members`
--

DROP TABLE IF EXISTS `abc1_tblproject_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblproject_members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`),
  KEY `ehsan_staff_id` (`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblproject_members`
--

LOCK TABLES `abc1_tblproject_members` WRITE;
/*!40000 ALTER TABLE `abc1_tblproject_members` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblproject_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblproject_notes`
--

DROP TABLE IF EXISTS `abc1_tblproject_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblproject_notes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `content` mediumtext NOT NULL,
  `staff_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblproject_notes`
--

LOCK TABLES `abc1_tblproject_notes` WRITE;
/*!40000 ALTER TABLE `abc1_tblproject_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblproject_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblproject_settings`
--

DROP TABLE IF EXISTS `abc1_tblproject_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblproject_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `value` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblproject_settings`
--

LOCK TABLES `abc1_tblproject_settings` WRITE;
/*!40000 ALTER TABLE `abc1_tblproject_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblproject_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblprojectdiscussioncomments`
--

DROP TABLE IF EXISTS `abc1_tblprojectdiscussioncomments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblprojectdiscussioncomments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `discussion_id` int(11) NOT NULL,
  `discussion_type` varchar(10) NOT NULL,
  `parent` int(11) DEFAULT NULL,
  `created` datetime NOT NULL,
  `modified` datetime DEFAULT NULL,
  `content` mediumtext NOT NULL,
  `staff_id` int(11) NOT NULL,
  `contact_id` int(11) DEFAULT 0,
  `fullname` varchar(191) DEFAULT NULL,
  `file_name` varchar(191) DEFAULT NULL,
  `file_mime_type` varchar(70) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblprojectdiscussioncomments`
--

LOCK TABLES `abc1_tblprojectdiscussioncomments` WRITE;
/*!40000 ALTER TABLE `abc1_tblprojectdiscussioncomments` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblprojectdiscussioncomments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblprojectdiscussions`
--

DROP TABLE IF EXISTS `abc1_tblprojectdiscussions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblprojectdiscussions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `subject` varchar(191) NOT NULL,
  `description` mediumtext NOT NULL,
  `show_to_customer` tinyint(1) NOT NULL DEFAULT 0,
  `datecreated` datetime NOT NULL,
  `last_activity` datetime DEFAULT NULL,
  `staff_id` int(11) NOT NULL DEFAULT 0,
  `contact_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblprojectdiscussions`
--

LOCK TABLES `abc1_tblprojectdiscussions` WRITE;
/*!40000 ALTER TABLE `abc1_tblprojectdiscussions` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblprojectdiscussions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblprojects`
--

DROP TABLE IF EXISTS `abc1_tblprojects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblprojects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `clientid` int(11) NOT NULL,
  `billing_type` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `deadline` date DEFAULT NULL,
  `project_created` date NOT NULL,
  `date_finished` datetime DEFAULT NULL,
  `progress` int(11) DEFAULT 0,
  `progress_from_tasks` int(11) NOT NULL DEFAULT 1,
  `project_cost` decimal(15,2) DEFAULT NULL,
  `project_rate_per_hour` decimal(15,2) DEFAULT NULL,
  `estimated_hours` decimal(15,2) DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `contact_notification` int(11) DEFAULT 1,
  `notify_contacts` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblprojects`
--

LOCK TABLES `abc1_tblprojects` WRITE;
/*!40000 ALTER TABLE `abc1_tblprojects` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblprojects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblproposal_comments`
--

DROP TABLE IF EXISTS `abc1_tblproposal_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblproposal_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` longtext DEFAULT NULL,
  `proposalid` int(11) NOT NULL,
  `staffid` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblproposal_comments`
--

LOCK TABLES `abc1_tblproposal_comments` WRITE;
/*!40000 ALTER TABLE `abc1_tblproposal_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblproposal_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblproposals`
--

DROP TABLE IF EXISTS `abc1_tblproposals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblproposals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(191) DEFAULT NULL,
  `content` longtext DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `datecreated` datetime NOT NULL,
  `total` decimal(15,2) DEFAULT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `total_tax` decimal(15,2) NOT NULL DEFAULT 0.00,
  `adjustment` decimal(15,2) DEFAULT NULL,
  `discount_percent` decimal(15,2) NOT NULL,
  `discount_total` decimal(15,2) NOT NULL,
  `discount_type` varchar(30) DEFAULT NULL,
  `show_quantity_as` int(11) NOT NULL DEFAULT 1,
  `currency` int(11) NOT NULL,
  `open_till` date DEFAULT NULL,
  `date` date NOT NULL,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(40) DEFAULT NULL,
  `assigned` int(11) DEFAULT NULL,
  `hash` varchar(32) NOT NULL,
  `proposal_to` varchar(191) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  `country` int(11) NOT NULL DEFAULT 0,
  `zip` varchar(50) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `allow_comments` tinyint(1) NOT NULL DEFAULT 1,
  `status` int(11) NOT NULL,
  `estimate_id` int(11) DEFAULT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `date_converted` datetime DEFAULT NULL,
  `pipeline_order` int(11) DEFAULT 1,
  `is_expiry_notified` int(11) NOT NULL DEFAULT 0,
  `acceptance_firstname` varchar(50) DEFAULT NULL,
  `acceptance_lastname` varchar(50) DEFAULT NULL,
  `acceptance_email` varchar(100) DEFAULT NULL,
  `acceptance_date` datetime DEFAULT NULL,
  `acceptance_ip` varchar(40) DEFAULT NULL,
  `signature` varchar(40) DEFAULT NULL,
  `short_link` varchar(100) DEFAULT NULL,
  `processing` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblproposals`
--

LOCK TABLES `abc1_tblproposals` WRITE;
/*!40000 ALTER TABLE `abc1_tblproposals` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblproposals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblpur_activity_log`
--

DROP TABLE IF EXISTS `abc1_tblpur_activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblpur_activity_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(45) NOT NULL,
  `staffid` int(11) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `note` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblpur_activity_log`
--

LOCK TABLES `abc1_tblpur_activity_log` WRITE;
/*!40000 ALTER TABLE `abc1_tblpur_activity_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblpur_activity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblpur_approval_details`
--

DROP TABLE IF EXISTS `abc1_tblpur_approval_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblpur_approval_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(45) NOT NULL,
  `staffid` varchar(45) DEFAULT NULL,
  `approve` varchar(45) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `approve_action` varchar(255) DEFAULT NULL,
  `reject_action` varchar(255) DEFAULT NULL,
  `approve_value` varchar(255) DEFAULT NULL,
  `reject_value` varchar(255) DEFAULT NULL,
  `staff_approve` int(11) DEFAULT NULL,
  `action` varchar(45) DEFAULT NULL,
  `sender` int(11) DEFAULT NULL,
  `date_send` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblpur_approval_details`
--

LOCK TABLES `abc1_tblpur_approval_details` WRITE;
/*!40000 ALTER TABLE `abc1_tblpur_approval_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblpur_approval_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblpur_approval_setting`
--

DROP TABLE IF EXISTS `abc1_tblpur_approval_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblpur_approval_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `related` varchar(255) NOT NULL,
  `setting` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblpur_approval_setting`
--

LOCK TABLES `abc1_tblpur_approval_setting` WRITE;
/*!40000 ALTER TABLE `abc1_tblpur_approval_setting` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblpur_approval_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblpur_comments`
--

DROP TABLE IF EXISTS `abc1_tblpur_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblpur_comments` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `content` mediumtext DEFAULT NULL,
  `rel_type` varchar(50) NOT NULL,
  `rel_id` int(11) DEFAULT NULL,
  `staffid` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblpur_comments`
--

LOCK TABLES `abc1_tblpur_comments` WRITE;
/*!40000 ALTER TABLE `abc1_tblpur_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblpur_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblpur_contacts`
--

DROP TABLE IF EXISTS `abc1_tblpur_contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblpur_contacts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `is_primary` int(11) NOT NULL DEFAULT 1,
  `firstname` varchar(191) NOT NULL,
  `lastname` varchar(191) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phonenumber` varchar(100) NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `new_pass_key` varchar(32) DEFAULT NULL,
  `new_pass_key_requested` datetime DEFAULT NULL,
  `email_verified_at` datetime DEFAULT NULL,
  `email_verification_key` varchar(32) DEFAULT NULL,
  `email_verification_sent_at` datetime DEFAULT NULL,
  `last_ip` varchar(40) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_password_change` datetime DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `profile_image` varchar(191) DEFAULT NULL,
  `direction` varchar(3) DEFAULT NULL,
  `invoice_emails` tinyint(1) NOT NULL DEFAULT 1,
  `estimate_emails` tinyint(1) NOT NULL DEFAULT 1,
  `credit_note_emails` tinyint(1) NOT NULL DEFAULT 1,
  `contract_emails` tinyint(1) NOT NULL DEFAULT 1,
  `task_emails` tinyint(1) NOT NULL DEFAULT 1,
  `project_emails` tinyint(1) NOT NULL DEFAULT 1,
  `ticket_emails` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblpur_contacts`
--

LOCK TABLES `abc1_tblpur_contacts` WRITE;
/*!40000 ALTER TABLE `abc1_tblpur_contacts` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblpur_contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblpur_contracts`
--

DROP TABLE IF EXISTS `abc1_tblpur_contracts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblpur_contracts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `contract_number` varchar(200) NOT NULL,
  `contract_name` varchar(200) NOT NULL,
  `content` longtext DEFAULT NULL,
  `vendor` int(11) NOT NULL,
  `pur_order` int(11) NOT NULL,
  `contract_value` decimal(15,2) DEFAULT NULL,
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `buyer` int(11) DEFAULT NULL,
  `time_payment` date DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  `signed` int(32) NOT NULL DEFAULT 0,
  `note` longtext DEFAULT NULL,
  `signer` int(11) DEFAULT NULL,
  `signed_date` date DEFAULT NULL,
  `signed_status` varchar(50) DEFAULT NULL,
  `service_category` text DEFAULT NULL,
  `project` int(11) DEFAULT NULL,
  `payment_terms` text DEFAULT NULL,
  `payment_amount` decimal(15,2) DEFAULT NULL,
  `payment_cycle` varchar(50) DEFAULT NULL,
  `department` int(11) DEFAULT NULL,
  `signature` text DEFAULT NULL,
  `marked_as_signed` tinyint(1) DEFAULT 0,
  `acceptance_firstname` text DEFAULT NULL,
  `acceptance_lastname` text DEFAULT NULL,
  `acceptance_email` text DEFAULT NULL,
  `acceptance_date` datetime DEFAULT NULL,
  `acceptance_ip` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblpur_contracts`
--

LOCK TABLES `abc1_tblpur_contracts` WRITE;
/*!40000 ALTER TABLE `abc1_tblpur_contracts` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblpur_contracts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblpur_debit_notes`
--

DROP TABLE IF EXISTS `abc1_tblpur_debit_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblpur_debit_notes` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `vendorid` int(11) DEFAULT NULL,
  `deleted_vendor_name` varchar(100) DEFAULT NULL,
  `number` int(11) DEFAULT NULL,
  `prefix` varchar(50) DEFAULT NULL,
  `number_format` int(11) DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `date` date DEFAULT NULL,
  `adminnote` text DEFAULT NULL,
  `terms` text DEFAULT NULL,
  `vendornote` text DEFAULT NULL,
  `currency` int(11) DEFAULT NULL,
  `subtotal` decimal(15,2) DEFAULT NULL,
  `total_tax` decimal(15,2) DEFAULT NULL,
  `total` decimal(15,2) DEFAULT NULL,
  `adjustment` decimal(15,2) DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `discount_percent` decimal(15,2) DEFAULT NULL,
  `discount_total` decimal(15,2) DEFAULT NULL,
  `discount_type` varchar(30) DEFAULT NULL,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT NULL,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT NULL,
  `include_shipping` tinyint(1) DEFAULT NULL,
  `show_shipping_on_debit_note` tinyint(1) DEFAULT NULL,
  `show_quantity_as` int(11) DEFAULT NULL,
  `reference_no` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblpur_debit_notes`
--

LOCK TABLES `abc1_tblpur_debit_notes` WRITE;
/*!40000 ALTER TABLE `abc1_tblpur_debit_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblpur_debit_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblpur_debits`
--

DROP TABLE IF EXISTS `abc1_tblpur_debits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblpur_debits` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) DEFAULT NULL,
  `debit_id` int(11) DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `date_applied` datetime DEFAULT NULL,
  `date` date DEFAULT NULL,
  `amount` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblpur_debits`
--

LOCK TABLES `abc1_tblpur_debits` WRITE;
/*!40000 ALTER TABLE `abc1_tblpur_debits` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblpur_debits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblpur_debits_refunds`
--

DROP TABLE IF EXISTS `abc1_tblpur_debits_refunds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblpur_debits_refunds` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `debit_note_id` int(11) DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `refunded_on` date DEFAULT NULL,
  `payment_mode` varchar(40) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `amount` decimal(15,2) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblpur_debits_refunds`
--

LOCK TABLES `abc1_tblpur_debits_refunds` WRITE;
/*!40000 ALTER TABLE `abc1_tblpur_debits_refunds` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblpur_debits_refunds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblpur_estimate_detail`
--

DROP TABLE IF EXISTS `abc1_tblpur_estimate_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblpur_estimate_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pur_estimate` int(11) NOT NULL,
  `item_code` varchar(100) NOT NULL,
  `unit_id` int(11) DEFAULT NULL,
  `unit_price` decimal(15,2) DEFAULT NULL,
  `quantity` decimal(15,2) NOT NULL,
  `into_money` decimal(15,2) DEFAULT NULL,
  `tax` text DEFAULT NULL,
  `total` decimal(15,2) DEFAULT NULL,
  `total_money` decimal(15,2) DEFAULT NULL,
  `discount_money` decimal(15,2) DEFAULT NULL,
  `discount_%` decimal(15,2) DEFAULT NULL,
  `tax_value` decimal(15,2) DEFAULT NULL,
  `tax_rate` text DEFAULT NULL,
  `tax_name` text DEFAULT NULL,
  `item_name` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblpur_estimate_detail`
--

LOCK TABLES `abc1_tblpur_estimate_detail` WRITE;
/*!40000 ALTER TABLE `abc1_tblpur_estimate_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblpur_estimate_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblpur_estimates`
--

DROP TABLE IF EXISTS `abc1_tblpur_estimates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblpur_estimates` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sent` tinyint(1) NOT NULL DEFAULT 0,
  `datesend` datetime DEFAULT NULL,
  `vendor` int(11) NOT NULL,
  `deleted_vendor_name` varchar(100) DEFAULT NULL,
  `pur_request` int(11) DEFAULT NULL,
  `number` int(11) NOT NULL,
  `prefix` varchar(50) DEFAULT NULL,
  `number_format` int(11) NOT NULL DEFAULT 0,
  `hash` varchar(32) DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `date` date NOT NULL,
  `expirydate` date DEFAULT NULL,
  `currency` int(11) NOT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `total_tax` decimal(15,2) NOT NULL,
  `total` decimal(15,2) NOT NULL,
  `adjustment` decimal(15,2) DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `vendornote` text DEFAULT NULL,
  `adminnote` text DEFAULT NULL,
  `discount_percent` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `discount_type` varchar(30) DEFAULT NULL,
  `invoiceid` int(11) DEFAULT NULL,
  `invoiced_date` datetime DEFAULT NULL,
  `terms` text DEFAULT NULL,
  `reference_no` varchar(100) DEFAULT NULL,
  `buyer` int(11) NOT NULL DEFAULT 0,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT NULL,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT NULL,
  `include_shipping` tinyint(1) NOT NULL,
  `show_shipping_on_estimate` tinyint(1) NOT NULL DEFAULT 1,
  `show_quantity_as` int(11) NOT NULL DEFAULT 1,
  `pipeline_order` int(11) NOT NULL DEFAULT 0,
  `is_expiry_notified` int(11) NOT NULL DEFAULT 0,
  `acceptance_firstname` varchar(50) DEFAULT NULL,
  `acceptance_lastname` varchar(50) DEFAULT NULL,
  `acceptance_email` varchar(100) DEFAULT NULL,
  `acceptance_date` datetime DEFAULT NULL,
  `acceptance_ip` varchar(40) DEFAULT NULL,
  `signature` varchar(40) DEFAULT NULL,
  `make_a_contract` text DEFAULT NULL,
  `currency_rate` decimal(15,6) DEFAULT NULL,
  `from_currency` varchar(20) DEFAULT NULL,
  `to_currency` varchar(20) DEFAULT NULL,
  `shipping_fee` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblpur_estimates`
--

LOCK TABLES `abc1_tblpur_estimates` WRITE;
/*!40000 ALTER TABLE `abc1_tblpur_estimates` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblpur_estimates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblpur_invoice_details`
--

DROP TABLE IF EXISTS `abc1_tblpur_invoice_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblpur_invoice_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pur_invoice` int(11) NOT NULL,
  `item_code` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `unit_id` int(11) DEFAULT NULL,
  `unit_price` decimal(15,2) DEFAULT NULL,
  `quantity` decimal(15,2) DEFAULT NULL,
  `into_money` decimal(15,2) DEFAULT NULL,
  `tax` text DEFAULT NULL,
  `total` decimal(15,2) DEFAULT NULL,
  `discount_percent` decimal(15,2) DEFAULT NULL,
  `discount_money` decimal(15,2) DEFAULT NULL,
  `total_money` decimal(15,2) DEFAULT NULL,
  `tax_value` decimal(15,2) DEFAULT NULL,
  `tax_rate` text DEFAULT NULL,
  `tax_name` text DEFAULT NULL,
  `item_name` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblpur_invoice_details`
--

LOCK TABLES `abc1_tblpur_invoice_details` WRITE;
/*!40000 ALTER TABLE `abc1_tblpur_invoice_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblpur_invoice_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblpur_invoice_payment`
--

DROP TABLE IF EXISTS `abc1_tblpur_invoice_payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblpur_invoice_payment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pur_invoice` int(11) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `paymentmode` longtext DEFAULT NULL,
  `date` date NOT NULL,
  `daterecorded` datetime NOT NULL,
  `note` text NOT NULL,
  `transactionid` mediumtext DEFAULT NULL,
  `approval_status` int(2) DEFAULT NULL,
  `requester` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblpur_invoice_payment`
--

LOCK TABLES `abc1_tblpur_invoice_payment` WRITE;
/*!40000 ALTER TABLE `abc1_tblpur_invoice_payment` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblpur_invoice_payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblpur_invoices`
--

DROP TABLE IF EXISTS `abc1_tblpur_invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblpur_invoices` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `number` int(11) NOT NULL,
  `invoice_number` text DEFAULT NULL,
  `invoice_date` date DEFAULT NULL,
  `subtotal` decimal(15,2) DEFAULT NULL,
  `tax_rate` int(11) DEFAULT NULL,
  `tax` decimal(15,2) DEFAULT NULL,
  `total` decimal(15,2) DEFAULT NULL,
  `contract` int(11) DEFAULT NULL,
  `vendor` int(11) DEFAULT NULL,
  `transactionid` mediumtext DEFAULT NULL,
  `transaction_date` date DEFAULT NULL,
  `payment_request_status` varchar(30) DEFAULT NULL,
  `payment_status` varchar(30) DEFAULT NULL,
  `vendor_note` text DEFAULT NULL,
  `adminnote` text DEFAULT NULL,
  `terms` text DEFAULT NULL,
  `add_from` int(11) DEFAULT NULL,
  `date_add` date DEFAULT NULL,
  `pur_order` int(11) DEFAULT NULL,
  `recurring` int(11) DEFAULT NULL,
  `recurring_type` varchar(10) DEFAULT NULL,
  `cycles` int(11) DEFAULT 0,
  `total_cycles` int(11) DEFAULT 0,
  `last_recurring_date` date DEFAULT NULL,
  `is_recurring_from` int(11) DEFAULT NULL,
  `duedate` date DEFAULT NULL,
  `add_from_type` varchar(20) DEFAULT NULL,
  `currency` int(11) DEFAULT 0,
  `discount_total` decimal(15,2) DEFAULT NULL,
  `discount_percent` decimal(15,2) DEFAULT NULL,
  `currency_rate` decimal(15,6) DEFAULT NULL,
  `from_currency` varchar(20) DEFAULT NULL,
  `to_currency` varchar(20) DEFAULT NULL,
  `shipping_fee` decimal(15,2) DEFAULT NULL,
  `vendor_invoice_number` text DEFAULT NULL,
  `discount_type` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblpur_invoices`
--

LOCK TABLES `abc1_tblpur_invoices` WRITE;
/*!40000 ALTER TABLE `abc1_tblpur_invoices` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblpur_invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblpur_order_detail`
--

DROP TABLE IF EXISTS `abc1_tblpur_order_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblpur_order_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pur_order` int(11) NOT NULL,
  `item_code` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `unit_id` int(11) DEFAULT NULL,
  `unit_price` decimal(15,2) DEFAULT NULL,
  `quantity` decimal(15,2) NOT NULL,
  `into_money` decimal(15,2) DEFAULT NULL,
  `tax` text DEFAULT NULL,
  `total` decimal(15,2) DEFAULT NULL,
  `discount_%` decimal(15,2) DEFAULT NULL,
  `discount_money` decimal(15,2) DEFAULT NULL,
  `total_money` decimal(15,2) DEFAULT NULL,
  `tax_value` decimal(15,2) DEFAULT NULL,
  `tax_rate` text DEFAULT NULL,
  `tax_name` text DEFAULT NULL,
  `item_name` text DEFAULT NULL,
  `wh_quantity_received` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblpur_order_detail`
--

LOCK TABLES `abc1_tblpur_order_detail` WRITE;
/*!40000 ALTER TABLE `abc1_tblpur_order_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblpur_order_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblpur_order_payment`
--

DROP TABLE IF EXISTS `abc1_tblpur_order_payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblpur_order_payment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pur_order` int(11) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `paymentmode` longtext DEFAULT NULL,
  `date` date NOT NULL,
  `daterecorded` datetime NOT NULL,
  `note` text NOT NULL,
  `transactionid` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblpur_order_payment`
--

LOCK TABLES `abc1_tblpur_order_payment` WRITE;
/*!40000 ALTER TABLE `abc1_tblpur_order_payment` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblpur_order_payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblpur_orders`
--

DROP TABLE IF EXISTS `abc1_tblpur_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblpur_orders` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pur_order_name` varchar(100) NOT NULL,
  `vendor` int(11) NOT NULL,
  `estimate` int(11) NOT NULL,
  `pur_order_number` varchar(30) NOT NULL,
  `order_date` date NOT NULL,
  `status` int(32) NOT NULL DEFAULT 1,
  `approve_status` int(32) NOT NULL DEFAULT 1,
  `datecreated` datetime NOT NULL,
  `days_owed` int(11) NOT NULL,
  `delivery_date` date DEFAULT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `total_tax` decimal(15,2) NOT NULL,
  `total` decimal(15,2) NOT NULL,
  `addedfrom` int(11) NOT NULL,
  `vendornote` text DEFAULT NULL,
  `terms` text DEFAULT NULL,
  `discount_percent` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `discount_type` varchar(30) DEFAULT NULL,
  `buyer` int(11) NOT NULL DEFAULT 0,
  `status_goods` int(11) NOT NULL DEFAULT 0,
  `number` int(11) DEFAULT NULL,
  `expense_convert` int(11) DEFAULT 0,
  `hash` varchar(32) DEFAULT NULL,
  `clients` text DEFAULT NULL,
  `delivery_status` int(2) DEFAULT 0,
  `type` text DEFAULT NULL,
  `project` int(11) DEFAULT NULL,
  `pur_request` int(11) DEFAULT NULL,
  `department` int(11) DEFAULT NULL,
  `tax_order_rate` decimal(15,2) DEFAULT NULL,
  `tax_order_amount` decimal(15,2) DEFAULT NULL,
  `sale_invoice` int(11) DEFAULT NULL,
  `currency` int(11) DEFAULT 0,
  `order_status` varchar(30) DEFAULT NULL,
  `shipping_note` text DEFAULT NULL,
  `currency_rate` decimal(15,6) DEFAULT NULL,
  `from_currency` varchar(20) DEFAULT NULL,
  `to_currency` varchar(20) DEFAULT NULL,
  `shipping_fee` decimal(15,2) DEFAULT NULL,
  `shipping_address` text DEFAULT NULL,
  `shipping_city` text DEFAULT NULL,
  `shipping_state` text DEFAULT NULL,
  `shipping_zip` text DEFAULT NULL,
  `shipping_country` int(11) DEFAULT NULL,
  `shipping_country_text` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblpur_orders`
--

LOCK TABLES `abc1_tblpur_orders` WRITE;
/*!40000 ALTER TABLE `abc1_tblpur_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblpur_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblpur_request`
--

DROP TABLE IF EXISTS `abc1_tblpur_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblpur_request` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pur_rq_code` varchar(45) NOT NULL,
  `pur_rq_name` varchar(100) NOT NULL,
  `rq_description` text DEFAULT NULL,
  `requester` int(11) NOT NULL,
  `department` int(11) DEFAULT NULL,
  `request_date` datetime NOT NULL,
  `status` int(11) DEFAULT NULL,
  `status_goods` int(11) NOT NULL DEFAULT 0,
  `hash` varchar(32) DEFAULT NULL,
  `type` text DEFAULT NULL,
  `project` int(11) DEFAULT NULL,
  `number` int(11) DEFAULT NULL,
  `from_items` int(2) DEFAULT 1,
  `subtotal` decimal(15,2) DEFAULT NULL,
  `total_tax` decimal(15,2) DEFAULT NULL,
  `total` decimal(15,2) DEFAULT NULL,
  `sale_invoice` int(11) DEFAULT NULL,
  `compare_note` text DEFAULT NULL,
  `send_to_vendors` text DEFAULT NULL,
  `currency` int(11) DEFAULT 0,
  `currency_rate` decimal(15,6) DEFAULT NULL,
  `from_currency` varchar(20) DEFAULT NULL,
  `to_currency` varchar(20) DEFAULT NULL,
  `sale_estimate` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblpur_request`
--

LOCK TABLES `abc1_tblpur_request` WRITE;
/*!40000 ALTER TABLE `abc1_tblpur_request` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblpur_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblpur_request_detail`
--

DROP TABLE IF EXISTS `abc1_tblpur_request_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblpur_request_detail` (
  `prd_id` int(11) NOT NULL AUTO_INCREMENT,
  `pur_request` int(11) NOT NULL,
  `item_code` varchar(100) NOT NULL,
  `unit_id` int(11) DEFAULT NULL,
  `unit_price` decimal(15,2) DEFAULT NULL,
  `quantity` decimal(15,2) NOT NULL,
  `into_money` decimal(15,2) DEFAULT NULL,
  `inventory_quantity` int(11) DEFAULT 0,
  `item_text` text DEFAULT NULL,
  `tax` text DEFAULT NULL,
  `tax_rate` text DEFAULT NULL,
  `tax_value` decimal(15,2) DEFAULT NULL,
  `total` decimal(15,2) DEFAULT NULL,
  `tax_name` text DEFAULT NULL,
  PRIMARY KEY (`prd_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblpur_request_detail`
--

LOCK TABLES `abc1_tblpur_request_detail` WRITE;
/*!40000 ALTER TABLE `abc1_tblpur_request_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblpur_request_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblpur_unit`
--

DROP TABLE IF EXISTS `abc1_tblpur_unit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblpur_unit` (
  `unit_id` int(11) NOT NULL AUTO_INCREMENT,
  `unit_name` varchar(100) NOT NULL,
  PRIMARY KEY (`unit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblpur_unit`
--

LOCK TABLES `abc1_tblpur_unit` WRITE;
/*!40000 ALTER TABLE `abc1_tblpur_unit` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblpur_unit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblpur_vendor`
--

DROP TABLE IF EXISTS `abc1_tblpur_vendor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblpur_vendor` (
  `userid` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `company` varchar(200) DEFAULT NULL,
  `vat` varchar(200) DEFAULT NULL,
  `phonenumber` varchar(30) DEFAULT NULL,
  `country` int(11) NOT NULL DEFAULT 0,
  `city` varchar(100) DEFAULT NULL,
  `zip` varchar(15) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `website` varchar(150) DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `active` int(11) NOT NULL DEFAULT 1,
  `leadid` int(11) DEFAULT NULL,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT 0,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT 0,
  `longitude` varchar(191) DEFAULT NULL,
  `latitude` varchar(191) DEFAULT NULL,
  `default_language` varchar(40) DEFAULT NULL,
  `default_currency` int(11) NOT NULL DEFAULT 0,
  `show_primary_contact` int(11) NOT NULL DEFAULT 0,
  `stripe_id` varchar(40) DEFAULT NULL,
  `registration_confirmed` int(11) NOT NULL DEFAULT 1,
  `addedfrom` int(11) NOT NULL DEFAULT 0,
  `category` text DEFAULT NULL,
  `bank_detail` text DEFAULT NULL,
  `payment_terms` text DEFAULT NULL,
  `vendor_code` varchar(100) DEFAULT NULL,
  `return_within_day` int(11) DEFAULT NULL,
  `return_order_fee` decimal(15,2) DEFAULT NULL,
  `return_policies` text DEFAULT NULL,
  `balance` decimal(15,2) DEFAULT NULL,
  `balance_as_of` date DEFAULT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblpur_vendor`
--

LOCK TABLES `abc1_tblpur_vendor` WRITE;
/*!40000 ALTER TABLE `abc1_tblpur_vendor` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblpur_vendor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblpur_vendor_admin`
--

DROP TABLE IF EXISTS `abc1_tblpur_vendor_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblpur_vendor_admin` (
  `staff_id` int(11) NOT NULL,
  `vendor_id` int(11) NOT NULL,
  `date_assigned` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblpur_vendor_admin`
--

LOCK TABLES `abc1_tblpur_vendor_admin` WRITE;
/*!40000 ALTER TABLE `abc1_tblpur_vendor_admin` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblpur_vendor_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblpur_vendor_cate`
--

DROP TABLE IF EXISTS `abc1_tblpur_vendor_cate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblpur_vendor_cate` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblpur_vendor_cate`
--

LOCK TABLES `abc1_tblpur_vendor_cate` WRITE;
/*!40000 ALTER TABLE `abc1_tblpur_vendor_cate` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblpur_vendor_cate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblpur_vendor_items`
--

DROP TABLE IF EXISTS `abc1_tblpur_vendor_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblpur_vendor_items` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `vendor` int(11) NOT NULL,
  `group_items` int(11) DEFAULT NULL,
  `items` int(11) NOT NULL,
  `add_from` int(11) DEFAULT NULL,
  `datecreate` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblpur_vendor_items`
--

LOCK TABLES `abc1_tblpur_vendor_items` WRITE;
/*!40000 ALTER TABLE `abc1_tblpur_vendor_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblpur_vendor_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblpurchase_option`
--

DROP TABLE IF EXISTS `abc1_tblpurchase_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblpurchase_option` (
  `option_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(200) NOT NULL,
  `option_val` longtext DEFAULT NULL,
  `auto` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`option_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblpurchase_option`
--

LOCK TABLES `abc1_tblpurchase_option` WRITE;
/*!40000 ALTER TABLE `abc1_tblpurchase_option` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblpurchase_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblrec_activity_log`
--

DROP TABLE IF EXISTS `abc1_tblrec_activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblrec_activity_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(100) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `additional_data` text DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `staffid` int(11) DEFAULT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblrec_activity_log`
--

LOCK TABLES `abc1_tblrec_activity_log` WRITE;
/*!40000 ALTER TABLE `abc1_tblrec_activity_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblrec_activity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblrec_applied_jobs`
--

DROP TABLE IF EXISTS `abc1_tblrec_applied_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblrec_applied_jobs` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `candidate_id` int(11) DEFAULT NULL,
  `campaign_id` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `status` text DEFAULT NULL,
  `activate` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblrec_applied_jobs`
--

LOCK TABLES `abc1_tblrec_applied_jobs` WRITE;
/*!40000 ALTER TABLE `abc1_tblrec_applied_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblrec_applied_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblrec_campaign`
--

DROP TABLE IF EXISTS `abc1_tblrec_campaign`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblrec_campaign` (
  `cp_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `campaign_code` varchar(200) NOT NULL,
  `campaign_name` varchar(200) NOT NULL,
  `cp_proposal` text DEFAULT NULL,
  `cp_position` int(11) NOT NULL,
  `cp_department` int(11) DEFAULT NULL,
  `cp_amount_recruiment` int(11) DEFAULT NULL,
  `cp_form_work` varchar(45) DEFAULT NULL,
  `cp_workplace` varchar(255) DEFAULT NULL,
  `cp_salary_from` decimal(15,0) DEFAULT NULL,
  `cp_salary_to` decimal(15,0) DEFAULT NULL,
  `cp_from_date` date DEFAULT NULL,
  `cp_to_date` date NOT NULL,
  `cp_reason_recruitment` text DEFAULT NULL,
  `cp_job_description` text DEFAULT NULL,
  `cp_manager` text DEFAULT NULL,
  `cp_follower` text DEFAULT NULL,
  `cp_ages_from` int(11) DEFAULT NULL,
  `cp_ages_to` int(11) DEFAULT NULL,
  `cp_gender` varchar(10) DEFAULT NULL,
  `cp_height` float DEFAULT NULL,
  `cp_weight` float DEFAULT NULL,
  `cp_literacy` varchar(200) DEFAULT NULL,
  `cp_experience` varchar(200) DEFAULT NULL,
  `cp_add_from` int(11) NOT NULL,
  `cp_date_add` date NOT NULL,
  `cp_status` int(11) NOT NULL,
  `display_salary` int(15) DEFAULT NULL,
  `rec_channel_form_id` int(15) DEFAULT NULL,
  `company_id` int(15) DEFAULT NULL,
  `job_meta_title` text DEFAULT NULL,
  `job_meta_description` text DEFAULT NULL,
  PRIMARY KEY (`cp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblrec_campaign`
--

LOCK TABLES `abc1_tblrec_campaign` WRITE;
/*!40000 ALTER TABLE `abc1_tblrec_campaign` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblrec_campaign` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblrec_campaign_form_web`
--

DROP TABLE IF EXISTS `abc1_tblrec_campaign_form_web`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblrec_campaign_form_web` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rec_campaign_id` int(11) NOT NULL,
  `form_type` int(11) DEFAULT NULL,
  `lead_source` varchar(10) DEFAULT NULL,
  `lead_status` varchar(10) DEFAULT NULL,
  `notify_ids_staff` text DEFAULT NULL,
  `notify_ids_roles` text DEFAULT NULL,
  `form_key` varchar(32) DEFAULT NULL,
  `notify_lead_imported` int(11) DEFAULT 1,
  `notify_type` varchar(20) DEFAULT NULL,
  `notify_ids` mediumtext DEFAULT NULL,
  `responsible` int(11) DEFAULT 0,
  `r_form_name` varchar(191) DEFAULT NULL,
  `form_data` mediumtext DEFAULT NULL,
  `recaptcha` int(11) DEFAULT 0,
  `submit_btn_name` varchar(40) DEFAULT NULL,
  `success_submit_msg` text DEFAULT NULL,
  `language` varchar(40) DEFAULT NULL,
  `allow_duplicate` int(11) DEFAULT 1,
  `mark_public` int(11) DEFAULT 0,
  `track_duplicate_field` varchar(20) DEFAULT NULL,
  `track_duplicate_field_and` varchar(20) DEFAULT NULL,
  `create_task_on_duplicate` int(11) DEFAULT 0,
  PRIMARY KEY (`id`,`rec_campaign_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblrec_campaign_form_web`
--

LOCK TABLES `abc1_tblrec_campaign_form_web` WRITE;
/*!40000 ALTER TABLE `abc1_tblrec_campaign_form_web` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblrec_campaign_form_web` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblrec_candidate`
--

DROP TABLE IF EXISTS `abc1_tblrec_candidate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblrec_candidate` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rec_campaign` int(11) DEFAULT NULL,
  `candidate_code` varchar(200) NOT NULL,
  `candidate_name` varchar(200) NOT NULL,
  `birthday` date DEFAULT NULL,
  `gender` varchar(11) DEFAULT NULL,
  `birthplace` text DEFAULT NULL,
  `home_town` text DEFAULT NULL,
  `identification` varchar(45) DEFAULT NULL,
  `days_for_identity` date DEFAULT NULL,
  `place_of_issue` varchar(255) DEFAULT NULL,
  `marital_status` varchar(11) DEFAULT NULL,
  `nationality` varchar(100) DEFAULT NULL,
  `nation` varchar(100) NOT NULL,
  `religion` varchar(100) DEFAULT NULL,
  `height` float DEFAULT NULL,
  `weight` float DEFAULT NULL,
  `introduce_yourself` text DEFAULT NULL,
  `phonenumber` text DEFAULT NULL,
  `email` text DEFAULT NULL,
  `skype` text DEFAULT NULL,
  `facebook` text DEFAULT NULL,
  `resident` text DEFAULT NULL,
  `current_accommodation` text DEFAULT NULL,
  `status` int(11) NOT NULL,
  `rate` int(11) DEFAULT NULL,
  `desired_salary` decimal(15,0) DEFAULT NULL,
  `date_add` date DEFAULT NULL,
  `recruitment_channel` int(11) DEFAULT NULL,
  `skill` text DEFAULT NULL,
  `interests` text DEFAULT NULL,
  `linkedin` text DEFAULT NULL,
  `alternate_contact_number` varchar(15) DEFAULT NULL,
  `last_name` varchar(200) DEFAULT NULL,
  `year_experience` varchar(200) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `new_pass_key` varchar(32) DEFAULT NULL,
  `new_pass_key_requested` datetime DEFAULT NULL,
  `email_verified_at` datetime DEFAULT NULL,
  `email_verification_key` varchar(32) DEFAULT NULL,
  `email_verification_sent_at` datetime DEFAULT NULL,
  `last_ip` varchar(40) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_password_change` datetime DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblrec_candidate`
--

LOCK TABLES `abc1_tblrec_candidate` WRITE;
/*!40000 ALTER TABLE `abc1_tblrec_candidate` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblrec_candidate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblrec_cd_evaluation`
--

DROP TABLE IF EXISTS `abc1_tblrec_cd_evaluation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblrec_cd_evaluation` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `criteria` int(11) NOT NULL,
  `rate_score` int(11) NOT NULL,
  `assessor` int(11) NOT NULL,
  `evaluation_date` datetime NOT NULL,
  `percent` int(11) NOT NULL,
  `candidate` int(11) NOT NULL,
  `feedback` text NOT NULL,
  `group_criteria` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblrec_cd_evaluation`
--

LOCK TABLES `abc1_tblrec_cd_evaluation` WRITE;
/*!40000 ALTER TABLE `abc1_tblrec_cd_evaluation` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblrec_cd_evaluation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblrec_company`
--

DROP TABLE IF EXISTS `abc1_tblrec_company`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblrec_company` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `company_name` varchar(200) NOT NULL,
  `company_description` text DEFAULT NULL,
  `company_address` varchar(200) DEFAULT NULL,
  `company_industry` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblrec_company`
--

LOCK TABLES `abc1_tblrec_company` WRITE;
/*!40000 ALTER TABLE `abc1_tblrec_company` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblrec_company` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblrec_criteria`
--

DROP TABLE IF EXISTS `abc1_tblrec_criteria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblrec_criteria` (
  `criteria_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `criteria_type` varchar(45) NOT NULL,
  `criteria_title` varchar(200) NOT NULL,
  `group_criteria` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  `add_date` date DEFAULT NULL,
  `score_des1` text DEFAULT NULL,
  `score_des2` text DEFAULT NULL,
  `score_des3` text DEFAULT NULL,
  `score_des4` text DEFAULT NULL,
  `score_des5` text DEFAULT NULL,
  PRIMARY KEY (`criteria_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblrec_criteria`
--

LOCK TABLES `abc1_tblrec_criteria` WRITE;
/*!40000 ALTER TABLE `abc1_tblrec_criteria` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblrec_criteria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblrec_evaluation_form`
--

DROP TABLE IF EXISTS `abc1_tblrec_evaluation_form`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblrec_evaluation_form` (
  `form_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `form_name` varchar(200) NOT NULL,
  `position` int(11) DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  `add_date` date DEFAULT NULL,
  PRIMARY KEY (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblrec_evaluation_form`
--

LOCK TABLES `abc1_tblrec_evaluation_form` WRITE;
/*!40000 ALTER TABLE `abc1_tblrec_evaluation_form` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblrec_evaluation_form` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblrec_interview`
--

DROP TABLE IF EXISTS `abc1_tblrec_interview`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblrec_interview` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `campaign` int(11) NOT NULL,
  `is_name` varchar(100) NOT NULL,
  `interview_day` varchar(200) NOT NULL,
  `from_time` text NOT NULL,
  `to_time` text NOT NULL,
  `from_hours` datetime DEFAULT NULL,
  `to_hours` datetime DEFAULT NULL,
  `interviewer` text NOT NULL,
  `added_from` int(11) NOT NULL,
  `added_date` date NOT NULL,
  `position` int(15) DEFAULT NULL,
  `send_notify` int(1) DEFAULT 0,
  `interview_location` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblrec_interview`
--

LOCK TABLES `abc1_tblrec_interview` WRITE;
/*!40000 ALTER TABLE `abc1_tblrec_interview` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblrec_interview` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblrec_job_position`
--

DROP TABLE IF EXISTS `abc1_tblrec_job_position`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblrec_job_position` (
  `position_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `position_name` varchar(200) NOT NULL,
  `position_description` text DEFAULT NULL,
  `industry_id` int(15) DEFAULT NULL,
  `company_id` int(15) DEFAULT NULL,
  `job_skill` text DEFAULT NULL,
  PRIMARY KEY (`position_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblrec_job_position`
--

LOCK TABLES `abc1_tblrec_job_position` WRITE;
/*!40000 ALTER TABLE `abc1_tblrec_job_position` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblrec_job_position` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblrec_list_criteria`
--

DROP TABLE IF EXISTS `abc1_tblrec_list_criteria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblrec_list_criteria` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `evaluation_form` int(11) NOT NULL,
  `group_criteria` int(11) NOT NULL,
  `evaluation_criteria` int(11) NOT NULL,
  `percent` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblrec_list_criteria`
--

LOCK TABLES `abc1_tblrec_list_criteria` WRITE;
/*!40000 ALTER TABLE `abc1_tblrec_list_criteria` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblrec_list_criteria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblrec_notifications`
--

DROP TABLE IF EXISTS `abc1_tblrec_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblrec_notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `isread` int(11) NOT NULL DEFAULT 0,
  `isread_inline` tinyint(1) NOT NULL DEFAULT 0,
  `date` datetime NOT NULL,
  `description` text NOT NULL,
  `fromuserid` int(11) NOT NULL,
  `fromclientid` int(11) NOT NULL DEFAULT 0,
  `from_fullname` varchar(100) NOT NULL,
  `touserid` int(11) NOT NULL,
  `fromcompany` int(11) DEFAULT NULL,
  `link` mediumtext DEFAULT NULL,
  `additional_data` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblrec_notifications`
--

LOCK TABLES `abc1_tblrec_notifications` WRITE;
/*!40000 ALTER TABLE `abc1_tblrec_notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblrec_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblrec_proposal`
--

DROP TABLE IF EXISTS `abc1_tblrec_proposal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblrec_proposal` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `proposal_name` varchar(200) NOT NULL,
  `position` int(11) NOT NULL,
  `department` int(11) DEFAULT NULL,
  `amount_recruiment` int(11) DEFAULT NULL,
  `form_work` varchar(45) DEFAULT NULL,
  `workplace` varchar(255) DEFAULT NULL,
  `salary_from` decimal(15,0) DEFAULT NULL,
  `salary_to` decimal(15,0) DEFAULT NULL,
  `from_date` date DEFAULT NULL,
  `to_date` date NOT NULL,
  `reason_recruitment` text DEFAULT NULL,
  `job_description` text DEFAULT NULL,
  `approver` int(11) NOT NULL,
  `ages_from` int(11) DEFAULT NULL,
  `ages_to` int(11) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `height` float DEFAULT NULL,
  `weight` float DEFAULT NULL,
  `literacy` varchar(200) DEFAULT NULL,
  `experience` varchar(200) DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  `date_add` date NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblrec_proposal`
--

LOCK TABLES `abc1_tblrec_proposal` WRITE;
/*!40000 ALTER TABLE `abc1_tblrec_proposal` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblrec_proposal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblrec_set_transfer_record`
--

DROP TABLE IF EXISTS `abc1_tblrec_set_transfer_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblrec_set_transfer_record` (
  `set_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `send_to` varchar(45) NOT NULL,
  `email_to` text DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  `add_date` date NOT NULL,
  `subject` text NOT NULL,
  `content` text DEFAULT NULL,
  `order` int(11) NOT NULL,
  PRIMARY KEY (`set_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblrec_set_transfer_record`
--

LOCK TABLES `abc1_tblrec_set_transfer_record` WRITE;
/*!40000 ALTER TABLE `abc1_tblrec_set_transfer_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblrec_set_transfer_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblrec_skill`
--

DROP TABLE IF EXISTS `abc1_tblrec_skill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblrec_skill` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `skill_name` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblrec_skill`
--

LOCK TABLES `abc1_tblrec_skill` WRITE;
/*!40000 ALTER TABLE `abc1_tblrec_skill` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblrec_skill` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblrec_transfer_records`
--

DROP TABLE IF EXISTS `abc1_tblrec_transfer_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblrec_transfer_records` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `firstname` varchar(100) DEFAULT NULL,
  `lastname` varchar(100) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `gender` varchar(11) DEFAULT NULL,
  `staff_identifi` varchar(20) DEFAULT NULL,
  `creator` int(11) DEFAULT NULL,
  `datecreator` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblrec_transfer_records`
--

LOCK TABLES `abc1_tblrec_transfer_records` WRITE;
/*!40000 ALTER TABLE `abc1_tblrec_transfer_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblrec_transfer_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblrecords_meta`
--

DROP TABLE IF EXISTS `abc1_tblrecords_meta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblrecords_meta` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) DEFAULT NULL,
  `meta` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblrecords_meta`
--

LOCK TABLES `abc1_tblrecords_meta` WRITE;
/*!40000 ALTER TABLE `abc1_tblrecords_meta` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblrecords_meta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblrelated_items`
--

DROP TABLE IF EXISTS `abc1_tblrelated_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblrelated_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(30) NOT NULL,
  `item_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblrelated_items`
--

LOCK TABLES `abc1_tblrelated_items` WRITE;
/*!40000 ALTER TABLE `abc1_tblrelated_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblrelated_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblreminders`
--

DROP TABLE IF EXISTS `abc1_tblreminders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblreminders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` mediumtext DEFAULT NULL,
  `date` datetime NOT NULL,
  `isnotified` int(11) NOT NULL DEFAULT 0,
  `rel_id` int(11) NOT NULL,
  `staff` int(11) NOT NULL,
  `rel_type` varchar(40) NOT NULL,
  `notify_by_email` int(11) NOT NULL DEFAULT 1,
  `creator` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`),
  KEY `ehsan_staff` (`staff`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblreminders`
--

LOCK TABLES `abc1_tblreminders` WRITE;
/*!40000 ALTER TABLE `abc1_tblreminders` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblreminders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblroles`
--

DROP TABLE IF EXISTS `abc1_tblroles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblroles` (
  `roleid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `permissions` longtext DEFAULT NULL,
  `enable_gg_auth` int(1) DEFAULT 0,
  PRIMARY KEY (`roleid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblroles`
--

LOCK TABLES `abc1_tblroles` WRITE;
/*!40000 ALTER TABLE `abc1_tblroles` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblroles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblsales_activity`
--

DROP TABLE IF EXISTS `abc1_tblsales_activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblsales_activity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_type` varchar(20) DEFAULT NULL,
  `rel_id` int(11) NOT NULL,
  `description` mediumtext NOT NULL,
  `additional_data` mediumtext DEFAULT NULL,
  `staffid` varchar(11) DEFAULT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblsales_activity`
--

LOCK TABLES `abc1_tblsales_activity` WRITE;
/*!40000 ALTER TABLE `abc1_tblsales_activity` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblsales_activity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblscheduled_emails`
--

DROP TABLE IF EXISTS `abc1_tblscheduled_emails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblscheduled_emails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(15) NOT NULL,
  `scheduled_at` datetime NOT NULL,
  `contacts` varchar(197) NOT NULL,
  `cc` mediumtext DEFAULT NULL,
  `attach_pdf` tinyint(1) NOT NULL DEFAULT 1,
  `template` varchar(197) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblscheduled_emails`
--

LOCK TABLES `abc1_tblscheduled_emails` WRITE;
/*!40000 ALTER TABLE `abc1_tblscheduled_emails` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblscheduled_emails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblservices`
--

DROP TABLE IF EXISTS `abc1_tblservices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblservices` (
  `serviceid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`serviceid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblservices`
--

LOCK TABLES `abc1_tblservices` WRITE;
/*!40000 ALTER TABLE `abc1_tblservices` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblservices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblsessions`
--

DROP TABLE IF EXISTS `abc1_tblsessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblsessions` (
  `id` varchar(128) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT 0,
  `data` blob NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ci_sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblsessions`
--

LOCK TABLES `abc1_tblsessions` WRITE;
/*!40000 ALTER TABLE `abc1_tblsessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblsessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblsetting_asset_allocation`
--

DROP TABLE IF EXISTS `abc1_tblsetting_asset_allocation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblsetting_asset_allocation` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) DEFAULT NULL,
  `meta` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblsetting_asset_allocation`
--

LOCK TABLES `abc1_tblsetting_asset_allocation` WRITE;
/*!40000 ALTER TABLE `abc1_tblsetting_asset_allocation` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblsetting_asset_allocation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblsetting_training`
--

DROP TABLE IF EXISTS `abc1_tblsetting_training`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblsetting_training` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `training_type` int(11) NOT NULL,
  `position_training` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblsetting_training`
--

LOCK TABLES `abc1_tblsetting_training` WRITE;
/*!40000 ALTER TABLE `abc1_tblsetting_training` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblsetting_training` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblsetting_transfer_records`
--

DROP TABLE IF EXISTS `abc1_tblsetting_transfer_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblsetting_transfer_records` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) DEFAULT NULL,
  `meta` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblsetting_transfer_records`
--

LOCK TABLES `abc1_tblsetting_transfer_records` WRITE;
/*!40000 ALTER TABLE `abc1_tblsetting_transfer_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblsetting_transfer_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblshared_customer_files`
--

DROP TABLE IF EXISTS `abc1_tblshared_customer_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblshared_customer_files` (
  `file_id` int(11) NOT NULL,
  `contact_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblshared_customer_files`
--

LOCK TABLES `abc1_tblshared_customer_files` WRITE;
/*!40000 ALTER TABLE `abc1_tblshared_customer_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblshared_customer_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblshift_type`
--

DROP TABLE IF EXISTS `abc1_tblshift_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblshift_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shift_type_name` varchar(150) DEFAULT NULL,
  `color` varchar(50) DEFAULT NULL,
  `time_start` date DEFAULT NULL,
  `time_end` date DEFAULT NULL,
  `time_start_work` varchar(50) DEFAULT NULL,
  `time_end_work` varchar(50) DEFAULT NULL,
  `start_lunch_break_time` varchar(50) DEFAULT NULL,
  `end_lunch_break_time` varchar(50) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblshift_type`
--

LOCK TABLES `abc1_tblshift_type` WRITE;
/*!40000 ALTER TABLE `abc1_tblshift_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblshift_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblsi_custom_status`
--

DROP TABLE IF EXISTS `abc1_tblsi_custom_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblsi_custom_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '',
  `order` int(11) NOT NULL DEFAULT 0,
  `color` varchar(7) NOT NULL DEFAULT '#757575',
  `filter_default` int(11) NOT NULL DEFAULT 0,
  `relto` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblsi_custom_status`
--

LOCK TABLES `abc1_tblsi_custom_status` WRITE;
/*!40000 ALTER TABLE `abc1_tblsi_custom_status` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblsi_custom_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblsi_custom_status_default`
--

DROP TABLE IF EXISTS `abc1_tblsi_custom_status_default`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblsi_custom_status_default` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status_id` int(11) NOT NULL DEFAULT 0,
  `name` varchar(50) NOT NULL DEFAULT '',
  `order` int(11) NOT NULL DEFAULT 0,
  `color` varchar(7) NOT NULL DEFAULT '#757575',
  `filter_default` int(11) NOT NULL DEFAULT 0,
  `active` int(11) NOT NULL DEFAULT 1,
  `relto` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblsi_custom_status_default`
--

LOCK TABLES `abc1_tblsi_custom_status_default` WRITE;
/*!40000 ALTER TABLE `abc1_tblsi_custom_status_default` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblsi_custom_status_default` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblsi_lead_followup_schedule`
--

DROP TABLE IF EXISTS `abc1_tblsi_lead_followup_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblsi_lead_followup_schedule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `source` int(11) NOT NULL DEFAULT 0,
  `filter_by` varchar(25) NOT NULL,
  `content` text NOT NULL,
  `dlt_template_id_key` varchar(100) NOT NULL DEFAULT '',
  `dlt_template_id_value` varchar(100) NOT NULL DEFAULT '',
  `staff_id` int(11) NOT NULL DEFAULT 0,
  `schedule_days` int(11) NOT NULL DEFAULT 1,
  `schedule_hour` int(11) NOT NULL DEFAULT 12,
  `last_executed` datetime DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `staff_id` (`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblsi_lead_followup_schedule`
--

LOCK TABLES `abc1_tblsi_lead_followup_schedule` WRITE;
/*!40000 ALTER TABLE `abc1_tblsi_lead_followup_schedule` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblsi_lead_followup_schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblsi_lead_followup_schedule_rel`
--

DROP TABLE IF EXISTS `abc1_tblsi_lead_followup_schedule_rel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblsi_lead_followup_schedule_rel` (
  `schedule_id` int(11) NOT NULL DEFAULT 0,
  `rel_id` int(11) NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  KEY `schedule_id` (`schedule_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblsi_lead_followup_schedule_rel`
--

LOCK TABLES `abc1_tblsi_lead_followup_schedule_rel` WRITE;
/*!40000 ALTER TABLE `abc1_tblsi_lead_followup_schedule_rel` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblsi_lead_followup_schedule_rel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblspam_filters`
--

DROP TABLE IF EXISTS `abc1_tblspam_filters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblspam_filters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(40) NOT NULL,
  `rel_type` varchar(10) NOT NULL,
  `value` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblspam_filters`
--

LOCK TABLES `abc1_tblspam_filters` WRITE;
/*!40000 ALTER TABLE `abc1_tblspam_filters` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblspam_filters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblstaff`
--

DROP TABLE IF EXISTS `abc1_tblstaff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblstaff` (
  `staffid` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `facebook` longtext DEFAULT NULL,
  `linkedin` longtext DEFAULT NULL,
  `phonenumber` varchar(30) DEFAULT NULL,
  `skype` varchar(50) DEFAULT NULL,
  `password` varchar(250) NOT NULL,
  `datecreated` datetime NOT NULL,
  `profile_image` varchar(191) DEFAULT NULL,
  `last_ip` varchar(40) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_activity` datetime DEFAULT NULL,
  `last_password_change` datetime DEFAULT NULL,
  `new_pass_key` varchar(32) DEFAULT NULL,
  `new_pass_key_requested` datetime DEFAULT NULL,
  `admin` int(11) NOT NULL DEFAULT 0,
  `role` int(11) DEFAULT NULL,
  `active` int(11) NOT NULL DEFAULT 1,
  `default_language` varchar(40) DEFAULT NULL,
  `direction` varchar(3) DEFAULT NULL,
  `media_path_slug` varchar(191) DEFAULT NULL,
  `is_not_staff` int(11) NOT NULL DEFAULT 0,
  `hourly_rate` decimal(15,2) NOT NULL DEFAULT 0.00,
  `two_factor_auth_enabled` tinyint(1) DEFAULT 0,
  `two_factor_auth_code` varchar(100) DEFAULT NULL,
  `two_factor_auth_code_requested` datetime DEFAULT NULL,
  `email_signature` mediumtext DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `birthplace` varchar(200) DEFAULT NULL,
  `sex` varchar(15) DEFAULT NULL,
  `marital_status` varchar(25) DEFAULT NULL,
  `nation` varchar(25) DEFAULT NULL,
  `religion` varchar(50) DEFAULT NULL,
  `identification` varchar(100) DEFAULT NULL,
  `days_for_identity` date DEFAULT NULL,
  `home_town` varchar(200) DEFAULT NULL,
  `resident` varchar(200) DEFAULT NULL,
  `current_address` varchar(200) DEFAULT NULL,
  `literacy` varchar(50) DEFAULT NULL,
  `orther_infor` text DEFAULT NULL,
  `job_position` int(11) DEFAULT NULL,
  `workplace` int(11) DEFAULT NULL,
  `place_of_issue` varchar(50) DEFAULT NULL,
  `account_number` varchar(50) DEFAULT NULL,
  `name_account` varchar(50) DEFAULT NULL,
  `issue_bank` varchar(200) DEFAULT NULL,
  `records_received` longtext DEFAULT NULL,
  `Personal_tax_code` varchar(50) DEFAULT NULL,
  `google_auth_secret` mediumtext DEFAULT NULL,
  `team_manage` int(11) DEFAULT 0,
  `staff_identifi` varchar(200) DEFAULT NULL,
  `status_work` varchar(100) DEFAULT NULL,
  `date_update` date DEFAULT NULL,
  `epf_no` text DEFAULT NULL,
  `social_security_no` text DEFAULT NULL,
  `mail_password` varchar(250) DEFAULT NULL,
  `mail_signature` varchar(250) DEFAULT NULL,
  `last_email_check` varchar(50) DEFAULT NULL,
  `token` varchar(255) DEFAULT NULL,
  `date_of_joining` date DEFAULT NULL,
  `pan_no` varchar(20) DEFAULT NULL,
  `uan_no` varchar(20) DEFAULT NULL,
  `mother_name` varchar(100) DEFAULT NULL,
  `father_name` varchar(100) DEFAULT NULL,
  `ho_wo_name` varchar(100) DEFAULT NULL,
  `ifsc_code` varchar(20) DEFAULT NULL,
  `account_type` varchar(50) DEFAULT NULL,
  `disability_type` varchar(100) DEFAULT NULL,
  `adhar_no` varchar(20) DEFAULT NULL,
  `esi_insurance_no` varchar(20) DEFAULT NULL,
  `esi_enable` tinyint(1) DEFAULT 0,
  `epf_enable` tinyint(1) DEFAULT 0,
  `enable_contribute_to_employee_pension_scheme` tinyint(1) DEFAULT 0,
  `contribute_eps_on_actual_pf_wages` tinyint(1) DEFAULT 0,
  `mfa_google_ath_enable` tinyint(1) DEFAULT 0,
  `mfa_whatsapp_enable` tinyint(1) DEFAULT 0,
  `mfa_sms_enable` tinyint(1) DEFAULT 0,
  `whatsapp_number` text DEFAULT '',
  `gg_auth_secret_key` text DEFAULT '',
  `fleet_is_driver` int(11) DEFAULT 0,
  `is_director_or_has_substantial_interest` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`staffid`),
  KEY `firstname` (`firstname`),
  KEY `lastname` (`lastname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblstaff`
--

LOCK TABLES `abc1_tblstaff` WRITE;
/*!40000 ALTER TABLE `abc1_tblstaff` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblstaff` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblstaff_departments`
--

DROP TABLE IF EXISTS `abc1_tblstaff_departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblstaff_departments` (
  `staffdepartmentid` int(11) NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `departmentid` int(11) NOT NULL,
  PRIMARY KEY (`staffdepartmentid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblstaff_departments`
--

LOCK TABLES `abc1_tblstaff_departments` WRITE;
/*!40000 ALTER TABLE `abc1_tblstaff_departments` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblstaff_departments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblstaff_permissions`
--

DROP TABLE IF EXISTS `abc1_tblstaff_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblstaff_permissions` (
  `staff_id` int(11) NOT NULL,
  `feature` varchar(40) NOT NULL,
  `capability` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblstaff_permissions`
--

LOCK TABLES `abc1_tblstaff_permissions` WRITE;
/*!40000 ALTER TABLE `abc1_tblstaff_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblstaff_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblstandard_workload`
--

DROP TABLE IF EXISTS `abc1_tblstandard_workload`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblstandard_workload` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `monday` varchar(45) DEFAULT NULL,
  `tuesday` varchar(45) DEFAULT NULL,
  `wednesday` varchar(45) DEFAULT NULL,
  `thursday` varchar(45) DEFAULT NULL,
  `friday` varchar(45) DEFAULT NULL,
  `saturday` varchar(45) DEFAULT NULL,
  `sunday` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblstandard_workload`
--

LOCK TABLES `abc1_tblstandard_workload` WRITE;
/*!40000 ALTER TABLE `abc1_tblstandard_workload` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblstandard_workload` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblstock_take`
--

DROP TABLE IF EXISTS `abc1_tblstock_take`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblstock_take` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `description` text DEFAULT NULL COMMENT 'the reason stock take',
  `warehouse_id` int(11) DEFAULT NULL,
  `date_stock_take` date DEFAULT NULL,
  `stock_take_code` varchar(100) DEFAULT NULL COMMENT 'số kiểm kê kho',
  `date_add` date DEFAULT NULL,
  `hour_add` date DEFAULT NULL,
  `staff_id` varchar(100) DEFAULT NULL,
  `approval` int(11) DEFAULT 0 COMMENT 'status approval ',
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblstock_take`
--

LOCK TABLES `abc1_tblstock_take` WRITE;
/*!40000 ALTER TABLE `abc1_tblstock_take` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblstock_take` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblstock_take_detail`
--

DROP TABLE IF EXISTS `abc1_tblstock_take_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblstock_take_detail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `stock_take_id` int(11) NOT NULL,
  `commodity_code` varchar(100) DEFAULT NULL,
  `commodity_name` text DEFAULT NULL,
  `unit_id` text DEFAULT NULL,
  `unit_price` varchar(100) DEFAULT NULL,
  `quantity_stock_take` varchar(100) DEFAULT NULL,
  `quantity_accounting_book` varchar(100) DEFAULT NULL,
  `quantity_change` varchar(100) DEFAULT NULL,
  `handling` text DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `approval` int(11) DEFAULT 0 COMMENT 'status approval ',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblstock_take_detail`
--

LOCK TABLES `abc1_tblstock_take_detail` WRITE;
/*!40000 ALTER TABLE `abc1_tblstock_take_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblstock_take_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblsubscriptions`
--

DROP TABLE IF EXISTS `abc1_tblsubscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblsubscriptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `description_in_item` tinyint(1) NOT NULL DEFAULT 0,
  `clientid` int(11) NOT NULL,
  `date` date DEFAULT NULL,
  `terms` mediumtext DEFAULT NULL,
  `currency` int(11) NOT NULL,
  `tax_id` int(11) NOT NULL DEFAULT 0,
  `stripe_tax_id` varchar(50) DEFAULT NULL,
  `tax_id_2` int(11) NOT NULL DEFAULT 0,
  `stripe_tax_id_2` varchar(50) DEFAULT NULL,
  `stripe_plan_id` mediumtext DEFAULT NULL,
  `stripe_subscription_id` mediumtext NOT NULL,
  `next_billing_cycle` bigint(20) DEFAULT NULL,
  `ends_at` bigint(20) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `project_id` int(11) NOT NULL DEFAULT 0,
  `hash` varchar(32) NOT NULL,
  `created` datetime NOT NULL,
  `created_from` int(11) NOT NULL,
  `date_subscribed` datetime DEFAULT NULL,
  `in_test_environment` int(11) DEFAULT NULL,
  `last_sent_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `currency` (`currency`),
  KEY `tax_id` (`tax_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblsubscriptions`
--

LOCK TABLES `abc1_tblsubscriptions` WRITE;
/*!40000 ALTER TABLE `abc1_tblsubscriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblsubscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblsurveyresultsets`
--

DROP TABLE IF EXISTS `abc1_tblsurveyresultsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblsurveyresultsets` (
  `resultsetid` int(11) NOT NULL AUTO_INCREMENT,
  `surveyid` int(11) NOT NULL,
  `ip` varchar(40) NOT NULL,
  `useragent` varchar(150) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`resultsetid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblsurveyresultsets`
--

LOCK TABLES `abc1_tblsurveyresultsets` WRITE;
/*!40000 ALTER TABLE `abc1_tblsurveyresultsets` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblsurveyresultsets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblsurveys`
--

DROP TABLE IF EXISTS `abc1_tblsurveys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblsurveys` (
  `surveyid` int(11) NOT NULL AUTO_INCREMENT,
  `subject` mediumtext NOT NULL,
  `slug` mediumtext NOT NULL,
  `description` text NOT NULL,
  `viewdescription` text DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `redirect_url` varchar(100) DEFAULT NULL,
  `send` tinyint(1) NOT NULL DEFAULT 0,
  `onlyforloggedin` int(11) DEFAULT 0,
  `fromname` varchar(100) DEFAULT NULL,
  `iprestrict` tinyint(1) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `hash` varchar(32) NOT NULL,
  PRIMARY KEY (`surveyid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblsurveys`
--

LOCK TABLES `abc1_tblsurveys` WRITE;
/*!40000 ALTER TABLE `abc1_tblsurveys` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblsurveys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblsurveysemailsendcron`
--

DROP TABLE IF EXISTS `abc1_tblsurveysemailsendcron`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblsurveysemailsendcron` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `surveyid` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `emailid` int(11) DEFAULT NULL,
  `listid` varchar(11) DEFAULT NULL,
  `log_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblsurveysemailsendcron`
--

LOCK TABLES `abc1_tblsurveysemailsendcron` WRITE;
/*!40000 ALTER TABLE `abc1_tblsurveysemailsendcron` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblsurveysemailsendcron` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblsurveysendlog`
--

DROP TABLE IF EXISTS `abc1_tblsurveysendlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblsurveysendlog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `surveyid` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `iscronfinished` int(11) NOT NULL DEFAULT 0,
  `send_to_mail_lists` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblsurveysendlog`
--

LOCK TABLES `abc1_tblsurveysendlog` WRITE;
/*!40000 ALTER TABLE `abc1_tblsurveysendlog` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblsurveysendlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tbltaggables`
--

DROP TABLE IF EXISTS `abc1_tbltaggables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tbltaggables` (
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) NOT NULL,
  `tag_id` int(11) NOT NULL,
  `tag_order` int(11) NOT NULL DEFAULT 0,
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`),
  KEY `tag_id` (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tbltaggables`
--

LOCK TABLES `abc1_tbltaggables` WRITE;
/*!40000 ALTER TABLE `abc1_tbltaggables` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tbltaggables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tbltags`
--

DROP TABLE IF EXISTS `abc1_tbltags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tbltags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tbltags`
--

LOCK TABLES `abc1_tbltags` WRITE;
/*!40000 ALTER TABLE `abc1_tbltags` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tbltags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tbltask_assigned`
--

DROP TABLE IF EXISTS `abc1_tbltask_assigned`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tbltask_assigned` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `taskid` int(11) NOT NULL,
  `assigned_from` int(11) NOT NULL DEFAULT 0,
  `is_assigned_from_contact` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `taskid` (`taskid`),
  KEY `ehsan_staffid` (`staffid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tbltask_assigned`
--

LOCK TABLES `abc1_tbltask_assigned` WRITE;
/*!40000 ALTER TABLE `abc1_tbltask_assigned` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tbltask_assigned` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tbltask_checklist_items`
--

DROP TABLE IF EXISTS `abc1_tbltask_checklist_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tbltask_checklist_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `taskid` int(11) NOT NULL,
  `description` mediumtext NOT NULL,
  `finished` int(11) NOT NULL DEFAULT 0,
  `dateadded` datetime NOT NULL,
  `addedfrom` int(11) NOT NULL,
  `finished_from` int(11) DEFAULT 0,
  `list_order` int(11) NOT NULL DEFAULT 0,
  `assigned` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `taskid` (`taskid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tbltask_checklist_items`
--

LOCK TABLES `abc1_tbltask_checklist_items` WRITE;
/*!40000 ALTER TABLE `abc1_tbltask_checklist_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tbltask_checklist_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tbltask_comments`
--

DROP TABLE IF EXISTS `abc1_tbltask_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tbltask_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` mediumtext NOT NULL,
  `taskid` int(11) NOT NULL,
  `staffid` int(11) NOT NULL,
  `contact_id` int(11) NOT NULL DEFAULT 0,
  `file_id` int(11) NOT NULL DEFAULT 0,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `file_id` (`file_id`),
  KEY `taskid` (`taskid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tbltask_comments`
--

LOCK TABLES `abc1_tbltask_comments` WRITE;
/*!40000 ALTER TABLE `abc1_tbltask_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tbltask_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tbltask_followers`
--

DROP TABLE IF EXISTS `abc1_tbltask_followers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tbltask_followers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `taskid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tbltask_followers`
--

LOCK TABLES `abc1_tbltask_followers` WRITE;
/*!40000 ALTER TABLE `abc1_tbltask_followers` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tbltask_followers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tbltasks`
--

DROP TABLE IF EXISTS `abc1_tbltasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tbltasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  `startdate` date NOT NULL,
  `duedate` date DEFAULT NULL,
  `datefinished` datetime DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `is_added_from_contact` tinyint(1) NOT NULL DEFAULT 0,
  `status` int(11) NOT NULL DEFAULT 0,
  `recurring_type` varchar(10) DEFAULT NULL,
  `repeat_every` int(11) DEFAULT NULL,
  `recurring` int(11) NOT NULL DEFAULT 0,
  `is_recurring_from` int(11) DEFAULT NULL,
  `cycles` int(11) NOT NULL DEFAULT 0,
  `total_cycles` int(11) NOT NULL DEFAULT 0,
  `custom_recurring` tinyint(1) NOT NULL DEFAULT 0,
  `last_recurring_date` date DEFAULT NULL,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(30) DEFAULT NULL,
  `is_public` tinyint(1) NOT NULL DEFAULT 0,
  `billable` tinyint(1) NOT NULL DEFAULT 0,
  `billed` tinyint(1) NOT NULL DEFAULT 0,
  `invoice_id` int(11) NOT NULL DEFAULT 0,
  `hourly_rate` decimal(15,2) NOT NULL DEFAULT 0.00,
  `milestone` int(11) DEFAULT 0,
  `kanban_order` int(11) DEFAULT 1,
  `milestone_order` int(11) NOT NULL DEFAULT 0,
  `visible_to_client` tinyint(1) NOT NULL DEFAULT 0,
  `deadline_notified` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`),
  KEY `milestone` (`milestone`),
  KEY `kanban_order` (`kanban_order`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tbltasks`
--

LOCK TABLES `abc1_tbltasks` WRITE;
/*!40000 ALTER TABLE `abc1_tbltasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tbltasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tbltasks_checklist_templates`
--

DROP TABLE IF EXISTS `abc1_tbltasks_checklist_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tbltasks_checklist_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tbltasks_checklist_templates`
--

LOCK TABLES `abc1_tbltasks_checklist_templates` WRITE;
/*!40000 ALTER TABLE `abc1_tbltasks_checklist_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tbltasks_checklist_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tbltaskstimers`
--

DROP TABLE IF EXISTS `abc1_tbltaskstimers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tbltaskstimers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) NOT NULL,
  `start_time` varchar(64) NOT NULL,
  `end_time` varchar(64) DEFAULT NULL,
  `staff_id` int(11) NOT NULL,
  `hourly_rate` decimal(15,2) NOT NULL DEFAULT 0.00,
  `note` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `task_id` (`task_id`),
  KEY `ehsan_staff_id` (`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tbltaskstimers`
--

LOCK TABLES `abc1_tbltaskstimers` WRITE;
/*!40000 ALTER TABLE `abc1_tbltaskstimers` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tbltaskstimers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tbltaxes`
--

DROP TABLE IF EXISTS `abc1_tbltaxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tbltaxes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `taxrate` decimal(15,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tbltaxes`
--

LOCK TABLES `abc1_tbltaxes` WRITE;
/*!40000 ALTER TABLE `abc1_tbltaxes` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tbltaxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tbltemplates`
--

DROP TABLE IF EXISTS `abc1_tbltemplates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tbltemplates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `type` varchar(100) NOT NULL,
  `addedfrom` int(11) NOT NULL,
  `content` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tbltemplates`
--

LOCK TABLES `abc1_tbltemplates` WRITE;
/*!40000 ALTER TABLE `abc1_tbltemplates` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tbltemplates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblticket_attachments`
--

DROP TABLE IF EXISTS `abc1_tblticket_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblticket_attachments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticketid` int(11) NOT NULL,
  `replyid` int(11) DEFAULT NULL,
  `file_name` varchar(191) NOT NULL,
  `filetype` varchar(50) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblticket_attachments`
--

LOCK TABLES `abc1_tblticket_attachments` WRITE;
/*!40000 ALTER TABLE `abc1_tblticket_attachments` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblticket_attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblticket_replies`
--

DROP TABLE IF EXISTS `abc1_tblticket_replies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblticket_replies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticketid` int(11) NOT NULL,
  `userid` int(11) DEFAULT NULL,
  `contactid` int(11) NOT NULL DEFAULT 0,
  `name` mediumtext DEFAULT NULL,
  `email` mediumtext DEFAULT NULL,
  `date` datetime NOT NULL,
  `message` mediumtext DEFAULT NULL,
  `attachment` int(11) DEFAULT NULL,
  `admin` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblticket_replies`
--

LOCK TABLES `abc1_tblticket_replies` WRITE;
/*!40000 ALTER TABLE `abc1_tblticket_replies` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblticket_replies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tbltickets`
--

DROP TABLE IF EXISTS `abc1_tbltickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tbltickets` (
  `ticketid` int(11) NOT NULL AUTO_INCREMENT,
  `adminreplying` int(11) NOT NULL DEFAULT 0,
  `userid` int(11) NOT NULL,
  `contactid` int(11) NOT NULL DEFAULT 0,
  `merged_ticket_id` int(11) DEFAULT NULL,
  `email` mediumtext DEFAULT NULL,
  `name` mediumtext DEFAULT NULL,
  `department` int(11) NOT NULL,
  `priority` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `service` int(11) DEFAULT NULL,
  `ticketkey` varchar(32) NOT NULL,
  `subject` varchar(191) NOT NULL,
  `message` mediumtext DEFAULT NULL,
  `admin` int(11) DEFAULT NULL,
  `date` datetime NOT NULL,
  `project_id` int(11) NOT NULL DEFAULT 0,
  `lastreply` datetime DEFAULT NULL,
  `clientread` int(11) NOT NULL DEFAULT 0,
  `adminread` int(11) NOT NULL DEFAULT 0,
  `assigned` int(11) NOT NULL DEFAULT 0,
  `staff_id_replying` int(11) DEFAULT NULL,
  `cc` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`ticketid`),
  KEY `service` (`service`),
  KEY `department` (`department`),
  KEY `status` (`status`),
  KEY `userid` (`userid`),
  KEY `priority` (`priority`),
  KEY `project_id` (`project_id`),
  KEY `contactid` (`contactid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tbltickets`
--

LOCK TABLES `abc1_tbltickets` WRITE;
/*!40000 ALTER TABLE `abc1_tbltickets` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tbltickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tbltickets_pipe_log`
--

DROP TABLE IF EXISTS `abc1_tbltickets_pipe_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tbltickets_pipe_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `email_to` varchar(100) NOT NULL,
  `name` varchar(191) NOT NULL,
  `subject` varchar(191) NOT NULL,
  `message` longtext NOT NULL,
  `email` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tbltickets_pipe_log`
--

LOCK TABLES `abc1_tbltickets_pipe_log` WRITE;
/*!40000 ALTER TABLE `abc1_tbltickets_pipe_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tbltickets_pipe_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tbltickets_predefined_replies`
--

DROP TABLE IF EXISTS `abc1_tbltickets_predefined_replies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tbltickets_predefined_replies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `message` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tbltickets_predefined_replies`
--

LOCK TABLES `abc1_tbltickets_predefined_replies` WRITE;
/*!40000 ALTER TABLE `abc1_tbltickets_predefined_replies` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tbltickets_predefined_replies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tbltickets_priorities`
--

DROP TABLE IF EXISTS `abc1_tbltickets_priorities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tbltickets_priorities` (
  `priorityid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`priorityid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tbltickets_priorities`
--

LOCK TABLES `abc1_tbltickets_priorities` WRITE;
/*!40000 ALTER TABLE `abc1_tbltickets_priorities` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tbltickets_priorities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tbltickets_status`
--

DROP TABLE IF EXISTS `abc1_tbltickets_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tbltickets_status` (
  `ticketstatusid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `isdefault` int(11) NOT NULL DEFAULT 0,
  `statuscolor` varchar(7) DEFAULT NULL,
  `statusorder` int(11) DEFAULT NULL,
  PRIMARY KEY (`ticketstatusid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tbltickets_status`
--

LOCK TABLES `abc1_tbltickets_status` WRITE;
/*!40000 ALTER TABLE `abc1_tbltickets_status` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tbltickets_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tbltimesheets_additional_timesheet`
--

DROP TABLE IF EXISTS `abc1_tbltimesheets_additional_timesheet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tbltimesheets_additional_timesheet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `additional_day` varchar(45) NOT NULL,
  `status` varchar(45) NOT NULL,
  `timekeeping_type` varchar(50) DEFAULT NULL,
  `timekeeping_value` varchar(45) NOT NULL,
  `approver` int(11) NOT NULL,
  `creator` int(11) NOT NULL,
  `old_timekeeping` varchar(50) DEFAULT NULL,
  `time_in` varchar(45) DEFAULT NULL,
  `time_out` varchar(45) DEFAULT NULL,
  `overtime_setting` int(11) DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `staff_id` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tbltimesheets_additional_timesheet`
--

LOCK TABLES `abc1_tbltimesheets_additional_timesheet` WRITE;
/*!40000 ALTER TABLE `abc1_tbltimesheets_additional_timesheet` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tbltimesheets_additional_timesheet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tbltimesheets_approval_details`
--

DROP TABLE IF EXISTS `abc1_tbltimesheets_approval_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tbltimesheets_approval_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(45) NOT NULL,
  `staffid` varchar(45) DEFAULT NULL,
  `approve` varchar(45) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `approve_action` varchar(255) DEFAULT NULL,
  `reject_action` varchar(255) DEFAULT NULL,
  `approve_value` varchar(255) DEFAULT NULL,
  `reject_value` varchar(255) DEFAULT NULL,
  `staff_approve` int(11) DEFAULT NULL,
  `action` varchar(45) DEFAULT NULL,
  `sender` int(11) DEFAULT NULL,
  `date_send` datetime DEFAULT NULL,
  `notification_recipient` longtext DEFAULT NULL,
  `approval_deadline` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tbltimesheets_approval_details`
--

LOCK TABLES `abc1_tbltimesheets_approval_details` WRITE;
/*!40000 ALTER TABLE `abc1_tbltimesheets_approval_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tbltimesheets_approval_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tbltimesheets_approval_setting`
--

DROP TABLE IF EXISTS `abc1_tbltimesheets_approval_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tbltimesheets_approval_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `related` varchar(255) NOT NULL,
  `setting` longtext NOT NULL,
  `choose_when_approving` int(11) NOT NULL DEFAULT 0,
  `notification_recipient` longtext DEFAULT NULL,
  `number_day_approval` int(11) DEFAULT NULL,
  `departments` text DEFAULT NULL,
  `job_positions` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tbltimesheets_approval_setting`
--

LOCK TABLES `abc1_tbltimesheets_approval_setting` WRITE;
/*!40000 ALTER TABLE `abc1_tbltimesheets_approval_setting` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tbltimesheets_approval_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tbltimesheets_day_off`
--

DROP TABLE IF EXISTS `abc1_tbltimesheets_day_off`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tbltimesheets_day_off` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `year` varchar(45) DEFAULT NULL,
  `total` varchar(45) DEFAULT NULL,
  `remain` varchar(45) DEFAULT NULL,
  `accumulated` varchar(45) DEFAULT NULL,
  `days_off` float DEFAULT 0,
  `type_of_leave` varchar(200) NOT NULL DEFAULT '8',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tbltimesheets_day_off`
--

LOCK TABLES `abc1_tbltimesheets_day_off` WRITE;
/*!40000 ALTER TABLE `abc1_tbltimesheets_day_off` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tbltimesheets_day_off` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tbltimesheets_go_bussiness_advance_payment`
--

DROP TABLE IF EXISTS `abc1_tbltimesheets_go_bussiness_advance_payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tbltimesheets_go_bussiness_advance_payment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `requisition_leave` int(11) NOT NULL,
  `used_to` varchar(200) DEFAULT NULL,
  `amoun_of_money` varchar(200) DEFAULT NULL,
  `request_date` date DEFAULT NULL,
  `advance_payment_reason` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tbltimesheets_go_bussiness_advance_payment`
--

LOCK TABLES `abc1_tbltimesheets_go_bussiness_advance_payment` WRITE;
/*!40000 ALTER TABLE `abc1_tbltimesheets_go_bussiness_advance_payment` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tbltimesheets_go_bussiness_advance_payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tbltimesheets_latch_timesheet`
--

DROP TABLE IF EXISTS `abc1_tbltimesheets_latch_timesheet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tbltimesheets_latch_timesheet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `month_latch` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tbltimesheets_latch_timesheet`
--

LOCK TABLES `abc1_tbltimesheets_latch_timesheet` WRITE;
/*!40000 ALTER TABLE `abc1_tbltimesheets_latch_timesheet` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tbltimesheets_latch_timesheet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tbltimesheets_leave`
--

DROP TABLE IF EXISTS `abc1_tbltimesheets_leave`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tbltimesheets_leave` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `date_work` date NOT NULL,
  `value` text DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tbltimesheets_leave`
--

LOCK TABLES `abc1_tbltimesheets_leave` WRITE;
/*!40000 ALTER TABLE `abc1_tbltimesheets_leave` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tbltimesheets_leave` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tbltimesheets_log_send_notify`
--

DROP TABLE IF EXISTS `abc1_tbltimesheets_log_send_notify`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tbltimesheets_log_send_notify` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sent` int(11) NOT NULL DEFAULT 0,
  `staffid` int(11) NOT NULL DEFAULT 0,
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  `type` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tbltimesheets_log_send_notify`
--

LOCK TABLES `abc1_tbltimesheets_log_send_notify` WRITE;
/*!40000 ALTER TABLE `abc1_tbltimesheets_log_send_notify` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tbltimesheets_log_send_notify` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tbltimesheets_option`
--

DROP TABLE IF EXISTS `abc1_tbltimesheets_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tbltimesheets_option` (
  `option_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(200) NOT NULL,
  `option_val` longtext DEFAULT NULL,
  `auto` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`option_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tbltimesheets_option`
--

LOCK TABLES `abc1_tbltimesheets_option` WRITE;
/*!40000 ALTER TABLE `abc1_tbltimesheets_option` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tbltimesheets_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tbltimesheets_requisition_leave`
--

DROP TABLE IF EXISTS `abc1_tbltimesheets_requisition_leave`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tbltimesheets_requisition_leave` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `subject` varchar(100) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `received_date` date DEFAULT NULL,
  `amount_received` text DEFAULT NULL,
  `approver_id` int(11) NOT NULL,
  `followers_id` int(11) DEFAULT NULL,
  `rel_type` int(11) NOT NULL COMMENT '1:Leave 2:Late_early 3:Go_out 4:Go_on_bussiness',
  `status` int(11) DEFAULT 0 COMMENT '0:Create 1:Approver 2:Reject',
  `place_of_business` longtext DEFAULT NULL,
  `type_of_leave` int(11) DEFAULT 0,
  `according_to_the_plan` int(11) DEFAULT 0,
  `handover_recipients` longtext DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `number_of_days` float DEFAULT NULL,
  `number_of_leaving_day` varchar(45) DEFAULT NULL,
  `type_of_leave_text` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`,`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tbltimesheets_requisition_leave`
--

LOCK TABLES `abc1_tbltimesheets_requisition_leave` WRITE;
/*!40000 ALTER TABLE `abc1_tbltimesheets_requisition_leave` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tbltimesheets_requisition_leave` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tbltimesheets_route`
--

DROP TABLE IF EXISTS `abc1_tbltimesheets_route`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tbltimesheets_route` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `route_point_id` int(11) NOT NULL,
  `date_work` date NOT NULL,
  `order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tbltimesheets_route`
--

LOCK TABLES `abc1_tbltimesheets_route` WRITE;
/*!40000 ALTER TABLE `abc1_tbltimesheets_route` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tbltimesheets_route` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tbltimesheets_route_point`
--

DROP TABLE IF EXISTS `abc1_tbltimesheets_route_point`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tbltimesheets_route_point` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `route_point_address` varchar(400) DEFAULT NULL,
  `latitude` varchar(30) DEFAULT NULL,
  `longitude` varchar(30) DEFAULT NULL,
  `distance` double DEFAULT NULL,
  `related_to` int(11) NOT NULL,
  `related_id` int(11) NOT NULL,
  `default` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tbltimesheets_route_point`
--

LOCK TABLES `abc1_tbltimesheets_route_point` WRITE;
/*!40000 ALTER TABLE `abc1_tbltimesheets_route_point` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tbltimesheets_route_point` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tbltimesheets_shift_sc`
--

DROP TABLE IF EXISTS `abc1_tbltimesheets_shift_sc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tbltimesheets_shift_sc` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shift_symbol` varchar(45) NOT NULL,
  `time_start_work` varchar(45) NOT NULL,
  `time_end_work` varchar(45) NOT NULL,
  `start_lunch_break_time` varchar(45) NOT NULL,
  `end_lunch_break_time` varchar(45) NOT NULL,
  `late_latency_allowed` varchar(45) NOT NULL,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tbltimesheets_shift_sc`
--

LOCK TABLES `abc1_tbltimesheets_shift_sc` WRITE;
/*!40000 ALTER TABLE `abc1_tbltimesheets_shift_sc` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tbltimesheets_shift_sc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tbltimesheets_shiftwork_sc`
--

DROP TABLE IF EXISTS `abc1_tbltimesheets_shiftwork_sc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tbltimesheets_shiftwork_sc` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `date_work` date NOT NULL,
  `shift` int(11) NOT NULL,
  `datecreated` datetime DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tbltimesheets_shiftwork_sc`
--

LOCK TABLES `abc1_tbltimesheets_shiftwork_sc` WRITE;
/*!40000 ALTER TABLE `abc1_tbltimesheets_shiftwork_sc` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tbltimesheets_shiftwork_sc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tbltimesheets_timekeeper_data`
--

DROP TABLE IF EXISTS `abc1_tbltimesheets_timekeeper_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tbltimesheets_timekeeper_data` (
  `staff_identifi` varchar(25) NOT NULL,
  `time` datetime NOT NULL,
  `type` varchar(45) NOT NULL,
  PRIMARY KEY (`staff_identifi`,`time`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tbltimesheets_timekeeper_data`
--

LOCK TABLES `abc1_tbltimesheets_timekeeper_data` WRITE;
/*!40000 ALTER TABLE `abc1_tbltimesheets_timekeeper_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tbltimesheets_timekeeper_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tbltimesheets_timesheet`
--

DROP TABLE IF EXISTS `abc1_tbltimesheets_timesheet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tbltimesheets_timesheet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `date_work` date NOT NULL,
  `value` text DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  `overtime_setting` int(11) DEFAULT NULL,
  `relate_id` int(11) DEFAULT NULL,
  `relate_type` varchar(25) DEFAULT NULL,
  `latch` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tbltimesheets_timesheet`
--

LOCK TABLES `abc1_tbltimesheets_timesheet` WRITE;
/*!40000 ALTER TABLE `abc1_tbltimesheets_timesheet` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tbltimesheets_timesheet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tbltimesheets_type_of_leave`
--

DROP TABLE IF EXISTS `abc1_tbltimesheets_type_of_leave`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tbltimesheets_type_of_leave` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type_name` varchar(200) DEFAULT NULL,
  `slug` varchar(200) DEFAULT NULL,
  `symbol` varchar(5) DEFAULT NULL,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tbltimesheets_type_of_leave`
--

LOCK TABLES `abc1_tbltimesheets_type_of_leave` WRITE;
/*!40000 ALTER TABLE `abc1_tbltimesheets_type_of_leave` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tbltimesheets_type_of_leave` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tbltimesheets_valid_ip`
--

DROP TABLE IF EXISTS `abc1_tbltimesheets_valid_ip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tbltimesheets_valid_ip` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ip` varchar(30) DEFAULT NULL,
  `enable` int(11) NOT NULL DEFAULT 1,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tbltimesheets_valid_ip`
--

LOCK TABLES `abc1_tbltimesheets_valid_ip` WRITE;
/*!40000 ALTER TABLE `abc1_tbltimesheets_valid_ip` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tbltimesheets_valid_ip` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tbltimesheets_workplace`
--

DROP TABLE IF EXISTS `abc1_tbltimesheets_workplace`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tbltimesheets_workplace` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `workplace_address` varchar(400) DEFAULT NULL,
  `latitude` varchar(30) DEFAULT NULL,
  `longitude` varchar(30) DEFAULT NULL,
  `distance` double DEFAULT NULL,
  `default` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tbltimesheets_workplace`
--

LOCK TABLES `abc1_tbltimesheets_workplace` WRITE;
/*!40000 ALTER TABLE `abc1_tbltimesheets_workplace` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tbltimesheets_workplace` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tbltimesheets_workplace_assign`
--

DROP TABLE IF EXISTS `abc1_tbltimesheets_workplace_assign`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tbltimesheets_workplace_assign` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `workplace_id` int(11) NOT NULL,
  `datecreator` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tbltimesheets_workplace_assign`
--

LOCK TABLES `abc1_tbltimesheets_workplace_assign` WRITE;
/*!40000 ALTER TABLE `abc1_tbltimesheets_workplace_assign` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tbltimesheets_workplace_assign` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tbltodos`
--

DROP TABLE IF EXISTS `abc1_tbltodos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tbltodos` (
  `todoid` int(11) NOT NULL AUTO_INCREMENT,
  `description` mediumtext NOT NULL,
  `staffid` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  `finished` tinyint(1) NOT NULL,
  `datefinished` datetime DEFAULT NULL,
  `item_order` int(11) DEFAULT NULL,
  PRIMARY KEY (`todoid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tbltodos`
--

LOCK TABLES `abc1_tbltodos` WRITE;
/*!40000 ALTER TABLE `abc1_tbltodos` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tbltodos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tbltracked_mails`
--

DROP TABLE IF EXISTS `abc1_tbltracked_mails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tbltracked_mails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` varchar(32) NOT NULL,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(40) NOT NULL,
  `date` datetime NOT NULL,
  `email` varchar(100) NOT NULL,
  `opened` tinyint(1) NOT NULL DEFAULT 0,
  `date_opened` datetime DEFAULT NULL,
  `subject` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tbltracked_mails`
--

LOCK TABLES `abc1_tbltracked_mails` WRITE;
/*!40000 ALTER TABLE `abc1_tbltracked_mails` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tbltracked_mails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tbltraining_allocation`
--

DROP TABLE IF EXISTS `abc1_tbltraining_allocation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tbltraining_allocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `training_process_id` varchar(100) NOT NULL,
  `staffid` int(11) DEFAULT NULL,
  `training_type` int(11) DEFAULT NULL,
  `date_add` datetime DEFAULT NULL,
  `training_name` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tbltraining_allocation`
--

LOCK TABLES `abc1_tbltraining_allocation` WRITE;
/*!40000 ALTER TABLE `abc1_tbltraining_allocation` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tbltraining_allocation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tbltransfer_records_reception`
--

DROP TABLE IF EXISTS `abc1_tbltransfer_records_reception`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tbltransfer_records_reception` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) DEFAULT NULL,
  `meta` varchar(50) DEFAULT NULL,
  `staffid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tbltransfer_records_reception`
--

LOCK TABLES `abc1_tbltransfer_records_reception` WRITE;
/*!40000 ALTER TABLE `abc1_tbltransfer_records_reception` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tbltransfer_records_reception` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tbltwocheckout_log`
--

DROP TABLE IF EXISTS `abc1_tbltwocheckout_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tbltwocheckout_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference` varchar(64) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `amount` varchar(25) NOT NULL,
  `created_at` datetime NOT NULL,
  `attempt_reference` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `invoice_id` (`invoice_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tbltwocheckout_log`
--

LOCK TABLES `abc1_tbltwocheckout_log` WRITE;
/*!40000 ALTER TABLE `abc1_tbltwocheckout_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tbltwocheckout_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tbluser_auto_login`
--

DROP TABLE IF EXISTS `abc1_tbluser_auto_login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tbluser_auto_login` (
  `key_id` char(32) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_agent` varchar(150) NOT NULL,
  `last_ip` varchar(40) NOT NULL,
  `last_login` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `staff` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tbluser_auto_login`
--

LOCK TABLES `abc1_tbluser_auto_login` WRITE;
/*!40000 ALTER TABLE `abc1_tbluser_auto_login` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tbluser_auto_login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tbluser_meta`
--

DROP TABLE IF EXISTS `abc1_tbluser_meta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tbluser_meta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `staff_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `client_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `contact_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(191) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  `candidate_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`umeta_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tbluser_meta`
--

LOCK TABLES `abc1_tbluser_meta` WRITE;
/*!40000 ALTER TABLE `abc1_tbluser_meta` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tbluser_meta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblvault`
--

DROP TABLE IF EXISTS `abc1_tblvault`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblvault` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `server_address` varchar(191) NOT NULL,
  `port` int(11) DEFAULT NULL,
  `username` varchar(191) NOT NULL,
  `password` mediumtext NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `creator` int(11) NOT NULL,
  `creator_name` varchar(100) DEFAULT NULL,
  `visibility` tinyint(1) NOT NULL DEFAULT 1,
  `share_in_projects` tinyint(1) NOT NULL DEFAULT 0,
  `last_updated` datetime DEFAULT NULL,
  `last_updated_from` varchar(100) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblvault`
--

LOCK TABLES `abc1_tblvault` WRITE;
/*!40000 ALTER TABLE `abc1_tblvault` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblvault` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblviews_tracking`
--

DROP TABLE IF EXISTS `abc1_tblviews_tracking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblviews_tracking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(40) NOT NULL,
  `date` datetime NOT NULL,
  `view_ip` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblviews_tracking`
--

LOCK TABLES `abc1_tblviews_tracking` WRITE;
/*!40000 ALTER TABLE `abc1_tblviews_tracking` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblviews_tracking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblware_body_type`
--

DROP TABLE IF EXISTS `abc1_tblware_body_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblware_body_type` (
  `body_type_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `body_code` varchar(100) DEFAULT NULL,
  `body_name` text DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  `display` int(1) DEFAULT NULL COMMENT 'display 1: display (yes)  0: not displayed (no)',
  `note` text DEFAULT NULL,
  PRIMARY KEY (`body_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblware_body_type`
--

LOCK TABLES `abc1_tblware_body_type` WRITE;
/*!40000 ALTER TABLE `abc1_tblware_body_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblware_body_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblware_color`
--

DROP TABLE IF EXISTS `abc1_tblware_color`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblware_color` (
  `color_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `color_code` varchar(100) DEFAULT NULL,
  `color_name` varchar(100) DEFAULT NULL,
  `color_hex` text DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  `display` int(1) DEFAULT NULL COMMENT 'display 1: display (yes)  0: not displayed (no)',
  `note` text DEFAULT NULL,
  PRIMARY KEY (`color_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblware_color`
--

LOCK TABLES `abc1_tblware_color` WRITE;
/*!40000 ALTER TABLE `abc1_tblware_color` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblware_color` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblware_commodity_type`
--

DROP TABLE IF EXISTS `abc1_tblware_commodity_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblware_commodity_type` (
  `commodity_type_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `commondity_code` varchar(100) DEFAULT NULL,
  `commondity_name` text DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  `display` int(1) DEFAULT NULL COMMENT 'display 1: display (yes)  0: not displayed (no)',
  `note` text DEFAULT NULL,
  PRIMARY KEY (`commodity_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblware_commodity_type`
--

LOCK TABLES `abc1_tblware_commodity_type` WRITE;
/*!40000 ALTER TABLE `abc1_tblware_commodity_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblware_commodity_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblware_size_type`
--

DROP TABLE IF EXISTS `abc1_tblware_size_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblware_size_type` (
  `size_type_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `size_code` varchar(100) DEFAULT NULL,
  `size_name` text DEFAULT NULL,
  `size_symbol` text DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  `display` int(1) DEFAULT NULL COMMENT 'display 1: display (yes)  0: not displayed (no)',
  `note` text DEFAULT NULL,
  `width` decimal(10,2) DEFAULT NULL,
  `length` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`size_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblware_size_type`
--

LOCK TABLES `abc1_tblware_size_type` WRITE;
/*!40000 ALTER TABLE `abc1_tblware_size_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblware_size_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblware_style_type`
--

DROP TABLE IF EXISTS `abc1_tblware_style_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblware_style_type` (
  `style_type_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `style_code` varchar(100) DEFAULT NULL,
  `style_barcode` text DEFAULT NULL,
  `style_name` text DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  `display` int(1) DEFAULT NULL COMMENT 'display 1: display (yes)  0: not displayed (no)',
  `note` text DEFAULT NULL,
  PRIMARY KEY (`style_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblware_style_type`
--

LOCK TABLES `abc1_tblware_style_type` WRITE;
/*!40000 ALTER TABLE `abc1_tblware_style_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblware_style_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblware_unit_type`
--

DROP TABLE IF EXISTS `abc1_tblware_unit_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblware_unit_type` (
  `unit_type_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `unit_code` varchar(100) DEFAULT NULL,
  `unit_name` text DEFAULT NULL,
  `unit_symbol` text DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  `display` int(1) DEFAULT NULL COMMENT 'display 1: display (yes)  0: not displayed (no)',
  `note` text DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `unit_measure_type` varchar(100) DEFAULT 'reference',
  `bigger_ratio` decimal(15,5) DEFAULT 0.00000,
  `smaller_ratio` decimal(15,5) DEFAULT 0.00000,
  `rounding` decimal(15,5) DEFAULT 0.00000,
  PRIMARY KEY (`unit_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblware_unit_type`
--

LOCK TABLES `abc1_tblware_unit_type` WRITE;
/*!40000 ALTER TABLE `abc1_tblware_unit_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblware_unit_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblwarehouse`
--

DROP TABLE IF EXISTS `abc1_tblwarehouse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblwarehouse` (
  `warehouse_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `warehouse_code` varchar(100) DEFAULT NULL,
  `warehouse_name` text DEFAULT NULL,
  `warehouse_address` text DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  `display` int(1) DEFAULT NULL COMMENT 'display 1: display (yes)  0: not displayed (no)',
  `note` text DEFAULT NULL,
  `city` text DEFAULT NULL,
  `state` text DEFAULT NULL,
  `zip_code` text DEFAULT NULL,
  `country` text DEFAULT NULL,
  `hide_warehouse_when_out_of_stock` int(11) DEFAULT 0 COMMENT ' 1: yes  0: no',
  PRIMARY KEY (`warehouse_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblwarehouse`
--

LOCK TABLES `abc1_tblwarehouse` WRITE;
/*!40000 ALTER TABLE `abc1_tblwarehouse` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblwarehouse` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblweb_to_lead`
--

DROP TABLE IF EXISTS `abc1_tblweb_to_lead`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblweb_to_lead` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `form_key` varchar(32) NOT NULL,
  `lead_source` int(11) NOT NULL,
  `lead_status` int(11) NOT NULL,
  `notify_lead_imported` int(11) NOT NULL DEFAULT 1,
  `notify_type` varchar(20) DEFAULT NULL,
  `notify_ids` longtext DEFAULT NULL,
  `responsible` int(11) NOT NULL DEFAULT 0,
  `name` varchar(191) NOT NULL,
  `form_data` longtext DEFAULT NULL,
  `recaptcha` int(11) NOT NULL DEFAULT 0,
  `submit_btn_name` varchar(40) DEFAULT NULL,
  `submit_btn_text_color` varchar(10) DEFAULT '#ffffff',
  `submit_btn_bg_color` varchar(10) DEFAULT '#84c529',
  `success_submit_msg` mediumtext DEFAULT NULL,
  `submit_action` int(11) DEFAULT 0,
  `lead_name_prefix` varchar(255) DEFAULT NULL,
  `submit_redirect_url` longtext DEFAULT NULL,
  `language` varchar(40) DEFAULT NULL,
  `allow_duplicate` int(11) NOT NULL DEFAULT 1,
  `mark_public` int(11) NOT NULL DEFAULT 0,
  `track_duplicate_field` varchar(20) DEFAULT NULL,
  `track_duplicate_field_and` varchar(20) DEFAULT NULL,
  `create_task_on_duplicate` int(11) NOT NULL DEFAULT 0,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblweb_to_lead`
--

LOCK TABLES `abc1_tblweb_to_lead` WRITE;
/*!40000 ALTER TABLE `abc1_tblweb_to_lead` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblweb_to_lead` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblweb_to_recruitment`
--

DROP TABLE IF EXISTS `abc1_tblweb_to_recruitment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblweb_to_recruitment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `campaign_code` varchar(200) DEFAULT NULL,
  `campaign_name` varchar(200) DEFAULT NULL,
  `cp_proposal` text DEFAULT NULL,
  `cp_position` int(11) DEFAULT NULL,
  `cp_department` int(11) DEFAULT NULL,
  `cp_amount_recruiment` int(11) DEFAULT NULL,
  `cp_form_work` varchar(45) DEFAULT NULL,
  `cp_workplace` varchar(255) DEFAULT NULL,
  `cp_salary_from` decimal(15,0) DEFAULT NULL,
  `cp_salary_to` decimal(15,0) DEFAULT NULL,
  `cp_from_date` date DEFAULT NULL,
  `cp_to_date` date DEFAULT NULL,
  `cp_reason_recruitment` text DEFAULT NULL,
  `cp_job_description` text DEFAULT NULL,
  `cp_manager` text DEFAULT NULL,
  `cp_follower` text DEFAULT NULL,
  `cp_ages_from` int(11) DEFAULT NULL,
  `cp_ages_to` int(11) DEFAULT NULL,
  `cp_gender` varchar(10) DEFAULT NULL,
  `cp_height` float DEFAULT NULL,
  `cp_weight` float DEFAULT NULL,
  `cp_literacy` varchar(200) DEFAULT NULL,
  `cp_experience` varchar(200) DEFAULT NULL,
  `cp_add_from` int(11) DEFAULT NULL,
  `cp_date_add` date DEFAULT NULL,
  `cp_status` int(11) DEFAULT NULL,
  `nation` varchar(15) DEFAULT NULL,
  `nationality` varchar(15) DEFAULT NULL,
  `religion` varchar(15) DEFAULT NULL,
  `marital_status` varchar(15) DEFAULT NULL,
  `birthplace` varchar(200) DEFAULT NULL,
  `home_town` varchar(200) DEFAULT NULL,
  `resident` varchar(200) DEFAULT NULL,
  `current_accommodation` varchar(200) DEFAULT NULL,
  `cp_desired_salary` varchar(10) DEFAULT NULL,
  `specialized` varchar(100) DEFAULT NULL,
  `training_form` varchar(50) DEFAULT NULL,
  `training_places` varchar(50) DEFAULT NULL,
  `lead_source` varchar(10) DEFAULT NULL,
  `lead_status` varchar(10) DEFAULT NULL,
  `notify_ids_staff` text DEFAULT NULL,
  `notify_ids_roles` text DEFAULT NULL,
  `form_key` varchar(32) DEFAULT NULL,
  `notify_lead_imported` int(11) DEFAULT 1,
  `notify_type` varchar(20) DEFAULT NULL,
  `notify_ids` mediumtext DEFAULT NULL,
  `responsible` int(11) DEFAULT 0,
  `name` varchar(191) DEFAULT NULL,
  `form_data` mediumtext DEFAULT NULL,
  `recaptcha` int(11) DEFAULT 0,
  `submit_btn_name` varchar(40) DEFAULT NULL,
  `success_submit_msg` text DEFAULT NULL,
  `language` varchar(40) DEFAULT NULL,
  `allow_duplicate` int(11) DEFAULT 1,
  `mark_public` int(11) DEFAULT 0,
  `track_duplicate_field` varchar(20) DEFAULT NULL,
  `track_duplicate_field_and` varchar(20) DEFAULT NULL,
  `create_task_on_duplicate` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblweb_to_recruitment`
--

LOCK TABLES `abc1_tblweb_to_recruitment` WRITE;
/*!40000 ALTER TABLE `abc1_tblweb_to_recruitment` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblweb_to_recruitment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblwh_activity_log`
--

DROP TABLE IF EXISTS `abc1_tblwh_activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblwh_activity_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(45) NOT NULL,
  `staffid` int(11) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `note` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblwh_activity_log`
--

LOCK TABLES `abc1_tblwh_activity_log` WRITE;
/*!40000 ALTER TABLE `abc1_tblwh_activity_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblwh_activity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblwh_approval_details`
--

DROP TABLE IF EXISTS `abc1_tblwh_approval_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblwh_approval_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(45) NOT NULL,
  `staffid` varchar(45) DEFAULT NULL,
  `approve` varchar(45) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `approve_action` varchar(255) DEFAULT NULL,
  `reject_action` varchar(255) DEFAULT NULL,
  `approve_value` varchar(255) DEFAULT NULL,
  `reject_value` varchar(255) DEFAULT NULL,
  `staff_approve` int(11) DEFAULT NULL,
  `action` varchar(45) DEFAULT NULL,
  `sender` int(11) DEFAULT NULL,
  `date_send` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblwh_approval_details`
--

LOCK TABLES `abc1_tblwh_approval_details` WRITE;
/*!40000 ALTER TABLE `abc1_tblwh_approval_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblwh_approval_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblwh_approval_setting`
--

DROP TABLE IF EXISTS `abc1_tblwh_approval_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblwh_approval_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `related` varchar(255) NOT NULL,
  `setting` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblwh_approval_setting`
--

LOCK TABLES `abc1_tblwh_approval_setting` WRITE;
/*!40000 ALTER TABLE `abc1_tblwh_approval_setting` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblwh_approval_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblwh_brand`
--

DROP TABLE IF EXISTS `abc1_tblwh_brand`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblwh_brand` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblwh_brand`
--

LOCK TABLES `abc1_tblwh_brand` WRITE;
/*!40000 ALTER TABLE `abc1_tblwh_brand` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblwh_brand` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblwh_custom_fields`
--

DROP TABLE IF EXISTS `abc1_tblwh_custom_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblwh_custom_fields` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `custom_fields_id` int(11) DEFAULT NULL,
  `warehouse_id` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblwh_custom_fields`
--

LOCK TABLES `abc1_tblwh_custom_fields` WRITE;
/*!40000 ALTER TABLE `abc1_tblwh_custom_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblwh_custom_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblwh_goods_delivery_activity_log`
--

DROP TABLE IF EXISTS `abc1_tblwh_goods_delivery_activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblwh_goods_delivery_activity_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(100) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `additional_data` text DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `staffid` int(11) DEFAULT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblwh_goods_delivery_activity_log`
--

LOCK TABLES `abc1_tblwh_goods_delivery_activity_log` WRITE;
/*!40000 ALTER TABLE `abc1_tblwh_goods_delivery_activity_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblwh_goods_delivery_activity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblwh_inventory_serial_numbers`
--

DROP TABLE IF EXISTS `abc1_tblwh_inventory_serial_numbers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblwh_inventory_serial_numbers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `commodity_id` int(11) NOT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `inventory_manage_id` int(11) DEFAULT NULL,
  `serial_number` varchar(255) DEFAULT NULL,
  `is_used` varchar(20) DEFAULT 'no',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblwh_inventory_serial_numbers`
--

LOCK TABLES `abc1_tblwh_inventory_serial_numbers` WRITE;
/*!40000 ALTER TABLE `abc1_tblwh_inventory_serial_numbers` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblwh_inventory_serial_numbers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblwh_loss_adjustment`
--

DROP TABLE IF EXISTS `abc1_tblwh_loss_adjustment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblwh_loss_adjustment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(15) DEFAULT NULL,
  `addfrom` int(11) DEFAULT NULL,
  `reason` longtext DEFAULT NULL,
  `time` datetime DEFAULT NULL,
  `date_create` date NOT NULL,
  `status` int(11) NOT NULL,
  `warehouses` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblwh_loss_adjustment`
--

LOCK TABLES `abc1_tblwh_loss_adjustment` WRITE;
/*!40000 ALTER TABLE `abc1_tblwh_loss_adjustment` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblwh_loss_adjustment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblwh_loss_adjustment_detail`
--

DROP TABLE IF EXISTS `abc1_tblwh_loss_adjustment_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblwh_loss_adjustment_detail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `items` int(11) DEFAULT NULL,
  `unit` int(11) DEFAULT NULL,
  `current_number` int(15) DEFAULT NULL,
  `updates_number` int(15) DEFAULT NULL,
  `loss_adjustment` int(11) DEFAULT NULL,
  `expiry_date` text DEFAULT NULL,
  `lot_number` text DEFAULT NULL,
  `commodity_name` text DEFAULT NULL,
  `serial_number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblwh_loss_adjustment_detail`
--

LOCK TABLES `abc1_tblwh_loss_adjustment_detail` WRITE;
/*!40000 ALTER TABLE `abc1_tblwh_loss_adjustment_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblwh_loss_adjustment_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblwh_model`
--

DROP TABLE IF EXISTS `abc1_tblwh_model`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblwh_model` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` text DEFAULT NULL,
  `brand_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`brand_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblwh_model`
--

LOCK TABLES `abc1_tblwh_model` WRITE;
/*!40000 ALTER TABLE `abc1_tblwh_model` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblwh_model` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblwh_omni_shipments`
--

DROP TABLE IF EXISTS `abc1_tblwh_omni_shipments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblwh_omni_shipments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cart_id` int(11) DEFAULT NULL,
  `shipment_number` varchar(100) DEFAULT NULL,
  `planned_shipping_date` datetime DEFAULT NULL,
  `shipment_status` varchar(50) DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `goods_delivery_id` int(11) DEFAULT NULL,
  `shipment_hash` varchar(32) DEFAULT NULL,
  `order_id` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblwh_omni_shipments`
--

LOCK TABLES `abc1_tblwh_omni_shipments` WRITE;
/*!40000 ALTER TABLE `abc1_tblwh_omni_shipments` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblwh_omni_shipments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblwh_order_return_details`
--

DROP TABLE IF EXISTS `abc1_tblwh_order_return_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblwh_order_return_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_return_id` int(11) NOT NULL,
  `rel_type_detail_id` int(11) DEFAULT NULL,
  `commodity_code` int(11) DEFAULT NULL,
  `commodity_name` text DEFAULT NULL,
  `quantity` decimal(15,2) DEFAULT 0.00,
  `unit_id` int(11) DEFAULT NULL,
  `unit_price` decimal(15,2) DEFAULT 0.00,
  `sub_total` decimal(15,2) DEFAULT 0.00,
  `tax_id` text DEFAULT NULL,
  `tax_rate` text DEFAULT NULL,
  `tax_name` text DEFAULT NULL,
  `total_amount` decimal(15,2) DEFAULT 0.00,
  `discount` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `total_after_discount` decimal(15,2) DEFAULT 0.00,
  `reason_return` varchar(200) DEFAULT NULL,
  `purchase_price` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblwh_order_return_details`
--

LOCK TABLES `abc1_tblwh_order_return_details` WRITE;
/*!40000 ALTER TABLE `abc1_tblwh_order_return_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblwh_order_return_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblwh_order_returns`
--

DROP TABLE IF EXISTS `abc1_tblwh_order_returns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblwh_order_returns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(50) NOT NULL COMMENT 'manual, sales_return_order, purchasing_return_order',
  `return_type` varchar(50) DEFAULT NULL COMMENT 'manual, partially, fully',
  `company_id` int(11) DEFAULT NULL,
  `company_name` varchar(500) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phonenumber` varchar(20) DEFAULT NULL,
  `order_number` varchar(500) DEFAULT NULL,
  `order_date` datetime DEFAULT NULL,
  `number_of_item` decimal(15,2) DEFAULT 0.00,
  `order_total` decimal(15,2) DEFAULT 0.00,
  `order_return_number` varchar(200) DEFAULT NULL,
  `order_return_name` varchar(500) DEFAULT NULL,
  `fee_return_order` decimal(15,2) DEFAULT 0.00,
  `refund_loyaty_point` int(11) DEFAULT 0,
  `subtotal` decimal(15,2) DEFAULT 0.00,
  `total_amount` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `additional_discount` decimal(15,2) DEFAULT 0.00,
  `adjustment_amount` decimal(15,2) DEFAULT 0.00,
  `total_after_discount` decimal(15,2) DEFAULT 0.00,
  `return_policies_information` text DEFAULT NULL,
  `admin_note` text DEFAULT NULL,
  `approval` int(11) DEFAULT 0,
  `datecreated` datetime DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `currency` int(11) DEFAULT NULL,
  `receipt_delivery_id` int(1) DEFAULT 0,
  `return_reason` longtext DEFAULT NULL,
  `status` varchar(30) DEFAULT 'draft',
  `discount_type` text DEFAULT NULL,
  `receipt_delivery_type` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblwh_order_returns`
--

LOCK TABLES `abc1_tblwh_order_returns` WRITE;
/*!40000 ALTER TABLE `abc1_tblwh_order_returns` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblwh_order_returns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblwh_order_returns_refunds`
--

DROP TABLE IF EXISTS `abc1_tblwh_order_returns_refunds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblwh_order_returns_refunds` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `order_return_id` int(11) DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `refunded_on` date DEFAULT NULL,
  `payment_mode` varchar(40) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `amount` decimal(15,2) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblwh_order_returns_refunds`
--

LOCK TABLES `abc1_tblwh_order_returns_refunds` WRITE;
/*!40000 ALTER TABLE `abc1_tblwh_order_returns_refunds` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblwh_order_returns_refunds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblwh_packing_list_details`
--

DROP TABLE IF EXISTS `abc1_tblwh_packing_list_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblwh_packing_list_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `packing_list_id` int(11) NOT NULL,
  `delivery_detail_id` int(11) DEFAULT NULL,
  `commodity_code` int(11) DEFAULT NULL,
  `commodity_name` text DEFAULT NULL,
  `quantity` decimal(15,2) DEFAULT 0.00,
  `unit_id` int(11) DEFAULT NULL,
  `unit_price` decimal(15,2) DEFAULT 0.00,
  `sub_total` decimal(15,2) DEFAULT 0.00,
  `tax_id` text DEFAULT NULL,
  `tax_rate` text DEFAULT NULL,
  `tax_name` text DEFAULT NULL,
  `total_amount` decimal(15,2) DEFAULT 0.00,
  `discount` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `total_after_discount` decimal(15,2) DEFAULT 0.00,
  `serial_number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblwh_packing_list_details`
--

LOCK TABLES `abc1_tblwh_packing_list_details` WRITE;
/*!40000 ALTER TABLE `abc1_tblwh_packing_list_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblwh_packing_list_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblwh_packing_lists`
--

DROP TABLE IF EXISTS `abc1_tblwh_packing_lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblwh_packing_lists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `delivery_note_id` int(11) DEFAULT NULL,
  `packing_list_number` varchar(100) DEFAULT NULL,
  `packing_list_name` varchar(200) DEFAULT NULL,
  `width` decimal(15,2) DEFAULT 0.00,
  `height` decimal(15,2) DEFAULT 0.00,
  `lenght` decimal(15,2) DEFAULT 0.00,
  `weight` decimal(15,2) DEFAULT 0.00,
  `volume` decimal(15,2) DEFAULT 0.00,
  `clientid` int(11) DEFAULT NULL,
  `subtotal` decimal(15,2) DEFAULT 0.00,
  `total_amount` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `additional_discount` decimal(15,2) DEFAULT 0.00,
  `total_after_discount` decimal(15,2) DEFAULT 0.00,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT NULL,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT NULL,
  `client_note` text DEFAULT NULL,
  `admin_note` text DEFAULT NULL,
  `approval` int(11) DEFAULT 0,
  `datecreated` datetime DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `type_of_packing_list` varchar(100) DEFAULT 'total',
  `delivery_status` varchar(100) DEFAULT 'wh_ready_to_deliver',
  `shipping_fee` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblwh_packing_lists`
--

LOCK TABLES `abc1_tblwh_packing_lists` WRITE;
/*!40000 ALTER TABLE `abc1_tblwh_packing_lists` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblwh_packing_lists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblwh_series`
--

DROP TABLE IF EXISTS `abc1_tblwh_series`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblwh_series` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` text DEFAULT NULL,
  `model_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`model_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblwh_series`
--

LOCK TABLES `abc1_tblwh_series` WRITE;
/*!40000 ALTER TABLE `abc1_tblwh_series` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblwh_series` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblwh_staff_warehouses`
--

DROP TABLE IF EXISTS `abc1_tblwh_staff_warehouses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblwh_staff_warehouses` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblwh_staff_warehouses`
--

LOCK TABLES `abc1_tblwh_staff_warehouses` WRITE;
/*!40000 ALTER TABLE `abc1_tblwh_staff_warehouses` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblwh_staff_warehouses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblwh_sub_group`
--

DROP TABLE IF EXISTS `abc1_tblwh_sub_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblwh_sub_group` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sub_group_code` varchar(100) DEFAULT NULL,
  `sub_group_name` text DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  `display` int(1) DEFAULT NULL COMMENT 'display 1: display (yes)  0: not displayed (no)',
  `note` text DEFAULT NULL,
  `group_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblwh_sub_group`
--

LOCK TABLES `abc1_tblwh_sub_group` WRITE;
/*!40000 ALTER TABLE `abc1_tblwh_sub_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblwh_sub_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblwhatsapp_api_debug_log`
--

DROP TABLE IF EXISTS `abc1_tblwhatsapp_api_debug_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblwhatsapp_api_debug_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `api_endpoint` varchar(255) DEFAULT NULL,
  `phone_number_id` varchar(255) DEFAULT NULL,
  `access_token` text DEFAULT NULL,
  `business_account_id` varchar(255) DEFAULT NULL,
  `response_code` varchar(4) NOT NULL,
  `response_data` text NOT NULL,
  `send_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`send_json`)),
  `message_category` varchar(50) NOT NULL,
  `category_params` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`category_params`)),
  `merge_field_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`merge_field_data`)),
  `recorded_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblwhatsapp_api_debug_log`
--

LOCK TABLES `abc1_tblwhatsapp_api_debug_log` WRITE;
/*!40000 ALTER TABLE `abc1_tblwhatsapp_api_debug_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblwhatsapp_api_debug_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblwhatsapp_templates`
--

DROP TABLE IF EXISTS `abc1_tblwhatsapp_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblwhatsapp_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_id` bigint(20) unsigned NOT NULL COMMENT 'id from api',
  `template_name` varchar(255) NOT NULL,
  `language` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  `category` varchar(100) NOT NULL,
  `header_data_format` varchar(10) NOT NULL,
  `header_data_text` text DEFAULT NULL,
  `header_params_count` int(11) NOT NULL,
  `body_data` text NOT NULL,
  `body_params_count` int(11) NOT NULL,
  `footer_data` text DEFAULT NULL,
  `footer_params_count` int(11) NOT NULL,
  `buttons_data` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `template_id` (`template_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblwhatsapp_templates`
--

LOCK TABLES `abc1_tblwhatsapp_templates` WRITE;
/*!40000 ALTER TABLE `abc1_tblwhatsapp_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblwhatsapp_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblwhatsapp_templates_mapping`
--

DROP TABLE IF EXISTS `abc1_tblwhatsapp_templates_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblwhatsapp_templates_mapping` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_id` int(11) NOT NULL,
  `category` varchar(100) NOT NULL,
  `send_to` varchar(50) NOT NULL,
  `header_params` varchar(255) NOT NULL,
  `body_params` varchar(255) NOT NULL,
  `footer_params` varchar(255) NOT NULL,
  `active` tinyint(4) NOT NULL DEFAULT 1,
  `debug_mode` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblwhatsapp_templates_mapping`
--

LOCK TABLES `abc1_tblwhatsapp_templates_mapping` WRITE;
/*!40000 ALTER TABLE `abc1_tblwhatsapp_templates_mapping` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblwhatsapp_templates_mapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblwork_shift`
--

DROP TABLE IF EXISTS `abc1_tblwork_shift`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblwork_shift` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shift_code` varchar(45) NOT NULL,
  `shift_name` varchar(200) NOT NULL,
  `shift_type` varchar(200) NOT NULL,
  `department` varchar(45) DEFAULT NULL,
  `position` varchar(45) DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  `staff` text DEFAULT NULL,
  `date_create` date DEFAULT NULL,
  `from_date` date DEFAULT NULL,
  `to_date` date DEFAULT NULL,
  `shifts_detail` text NOT NULL,
  `type_shiftwork` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblwork_shift`
--

LOCK TABLES `abc1_tblwork_shift` WRITE;
/*!40000 ALTER TABLE `abc1_tblwork_shift` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblwork_shift` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblwork_shift_detail`
--

DROP TABLE IF EXISTS `abc1_tblwork_shift_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblwork_shift_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `shift_id` int(11) DEFAULT NULL,
  `work_shift_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblwork_shift_detail`
--

LOCK TABLES `abc1_tblwork_shift_detail` WRITE;
/*!40000 ALTER TABLE `abc1_tblwork_shift_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblwork_shift_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblwork_shift_detail_day_name`
--

DROP TABLE IF EXISTS `abc1_tblwork_shift_detail_day_name`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblwork_shift_detail_day_name` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `day_name` varchar(45) DEFAULT NULL,
  `shift_id` int(11) DEFAULT NULL,
  `work_shift_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblwork_shift_detail_day_name`
--

LOCK TABLES `abc1_tblwork_shift_detail_day_name` WRITE;
/*!40000 ALTER TABLE `abc1_tblwork_shift_detail_day_name` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblwork_shift_detail_day_name` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblwork_shift_detail_number_day`
--

DROP TABLE IF EXISTS `abc1_tblwork_shift_detail_number_day`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblwork_shift_detail_number_day` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `number` int(11) DEFAULT NULL,
  `shift_id` int(11) DEFAULT NULL,
  `work_shift_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblwork_shift_detail_number_day`
--

LOCK TABLES `abc1_tblwork_shift_detail_number_day` WRITE;
/*!40000 ALTER TABLE `abc1_tblwork_shift_detail_number_day` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblwork_shift_detail_number_day` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblworkload_dayoff`
--

DROP TABLE IF EXISTS `abc1_tblworkload_dayoff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblworkload_dayoff` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reason` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `addedfrom` int(11) NOT NULL,
  `datecreated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblworkload_dayoff`
--

LOCK TABLES `abc1_tblworkload_dayoff` WRITE;
/*!40000 ALTER TABLE `abc1_tblworkload_dayoff` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblworkload_dayoff` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblwr_lot`
--

DROP TABLE IF EXISTS `abc1_tblwr_lot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblwr_lot` (
  `lot_id` int(11) NOT NULL AUTO_INCREMENT,
  `warehouse_id` int(11) NOT NULL,
  `lot_name` varchar(100) NOT NULL,
  PRIMARY KEY (`lot_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblwr_lot`
--

LOCK TABLES `abc1_tblwr_lot` WRITE;
/*!40000 ALTER TABLE `abc1_tblwr_lot` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblwr_lot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblwr_rack`
--

DROP TABLE IF EXISTS `abc1_tblwr_rack`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblwr_rack` (
  `rack_id` int(11) NOT NULL AUTO_INCREMENT,
  `warehouse_id` int(11) NOT NULL,
  `rack_name` varchar(100) NOT NULL,
  PRIMARY KEY (`rack_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblwr_rack`
--

LOCK TABLES `abc1_tblwr_rack` WRITE;
/*!40000 ALTER TABLE `abc1_tblwr_rack` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblwr_rack` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abc1_tblwr_shelf`
--

DROP TABLE IF EXISTS `abc1_tblwr_shelf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abc1_tblwr_shelf` (
  `shelf_id` int(11) NOT NULL AUTO_INCREMENT,
  `rack_id` int(11) NOT NULL,
  `shelf_name` varchar(100) NOT NULL,
  PRIMARY KEY (`shelf_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abc1_tblwr_shelf`
--

LOCK TABLES `abc1_tblwr_shelf` WRITE;
/*!40000 ALTER TABLE `abc1_tblwr_shelf` DISABLE KEYS */;
/*!40000 ALTER TABLE `abc1_tblwr_shelf` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-09 13:06:33
