/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.5.27-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: ps_maxlife
-- ------------------------------------------------------
-- Server version	10.5.27-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `maxlife_tblacc_account_history`
--

DROP TABLE IF EXISTS `maxlife_tblacc_account_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblacc_account_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account` int(11) NOT NULL,
  `debit` decimal(15,2) NOT NULL DEFAULT 0.00,
  `credit` decimal(15,2) NOT NULL DEFAULT 0.00,
  `description` text DEFAULT NULL,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(45) DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `customer` int(11) DEFAULT NULL,
  `reconcile` int(11) NOT NULL DEFAULT 0,
  `split` int(11) NOT NULL DEFAULT 0,
  `item` int(11) DEFAULT NULL,
  `paid` int(1) NOT NULL DEFAULT 0,
  `date` date DEFAULT NULL,
  `tax` int(11) DEFAULT NULL,
  `payslip_type` varchar(45) DEFAULT NULL,
  `vendor` int(11) DEFAULT NULL,
  `itemable_id` int(11) DEFAULT NULL,
  `cleared` int(11) NOT NULL DEFAULT 0,
  `sub_type` varchar(45) DEFAULT NULL,
  `bill_item` int(11) NOT NULL DEFAULT 0,
  `number` varchar(100) DEFAULT NULL,
  `issue` int(11) NOT NULL DEFAULT 0,
  `added_from_reconcile` int(11) NOT NULL DEFAULT 0,
  `bank_reconcile` int(11) NOT NULL DEFAULT 0,
  `currency_rate` decimal(15,6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblacc_account_history`
--

LOCK TABLES `maxlife_tblacc_account_history` WRITE;
/*!40000 ALTER TABLE `maxlife_tblacc_account_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblacc_account_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblacc_account_type_details`
--

DROP TABLE IF EXISTS `maxlife_tblacc_account_type_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblacc_account_type_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_type_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `note` text DEFAULT NULL,
  `statement_of_cash_flows` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=200 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblacc_account_type_details`
--

LOCK TABLES `maxlife_tblacc_account_type_details` WRITE;
/*!40000 ALTER TABLE `maxlife_tblacc_account_type_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblacc_account_type_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblacc_accounts`
--

DROP TABLE IF EXISTS `maxlife_tblacc_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblacc_accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `key_name` varchar(255) DEFAULT NULL,
  `number` varchar(45) DEFAULT NULL,
  `parent_account` int(11) DEFAULT NULL,
  `account_type_id` int(11) NOT NULL,
  `account_detail_type_id` int(11) NOT NULL,
  `balance` decimal(15,2) DEFAULT NULL,
  `balance_as_of` date DEFAULT NULL,
  `description` text DEFAULT NULL,
  `default_account` int(11) NOT NULL DEFAULT 0,
  `active` int(11) NOT NULL DEFAULT 1,
  `access_token` text DEFAULT NULL,
  `account_id` varchar(255) DEFAULT NULL,
  `plaid_status` tinyint(5) NOT NULL DEFAULT 0 COMMENT '1=>verified, 0=>not verified',
  `plaid_account_name` varchar(255) DEFAULT NULL,
  `bank_account` text DEFAULT NULL,
  `bank_routing` text DEFAULT NULL,
  `address_line_1` text DEFAULT NULL,
  `address_line_2` text DEFAULT NULL,
  `bank_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblacc_accounts`
--

LOCK TABLES `maxlife_tblacc_accounts` WRITE;
/*!40000 ALTER TABLE `maxlife_tblacc_accounts` DISABLE KEYS */;
INSERT INTO `maxlife_tblacc_accounts` VALUES (1,'','acc_opening_balance_equity',NULL,NULL,10,71,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `maxlife_tblacc_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblacc_bank_reconciles`
--

DROP TABLE IF EXISTS `maxlife_tblacc_bank_reconciles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblacc_bank_reconciles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account` int(11) NOT NULL,
  `opening_balance` decimal(15,2) NOT NULL DEFAULT 0.00,
  `beginning_balance` decimal(15,2) NOT NULL,
  `ending_balance` decimal(15,2) NOT NULL,
  `ending_date` date NOT NULL,
  `finish` int(11) NOT NULL DEFAULT 0,
  `debits_for_period` decimal(15,2) NOT NULL,
  `credits_for_period` decimal(15,2) NOT NULL,
  `dateadded` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblacc_bank_reconciles`
--

LOCK TABLES `maxlife_tblacc_bank_reconciles` WRITE;
/*!40000 ALTER TABLE `maxlife_tblacc_bank_reconciles` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblacc_bank_reconciles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblacc_banking_rule_details`
--

DROP TABLE IF EXISTS `maxlife_tblacc_banking_rule_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblacc_banking_rule_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rule_id` int(11) NOT NULL,
  `type` varchar(45) DEFAULT NULL,
  `subtype` varchar(45) DEFAULT NULL,
  `text` varchar(255) DEFAULT NULL,
  `subtype_amount` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblacc_banking_rule_details`
--

LOCK TABLES `maxlife_tblacc_banking_rule_details` WRITE;
/*!40000 ALTER TABLE `maxlife_tblacc_banking_rule_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblacc_banking_rule_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblacc_banking_rules`
--

DROP TABLE IF EXISTS `maxlife_tblacc_banking_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblacc_banking_rules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `transaction` varchar(45) DEFAULT NULL,
  `following` varchar(45) DEFAULT NULL,
  `then` varchar(45) DEFAULT NULL,
  `payment_account` int(11) DEFAULT NULL,
  `deposit_to` int(11) DEFAULT NULL,
  `auto_add` int(11) NOT NULL DEFAULT 0,
  `mapping_type` varchar(25) DEFAULT NULL,
  `account` int(11) DEFAULT NULL,
  `split_percentage` text DEFAULT NULL,
  `split_amount` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblacc_banking_rules`
--

LOCK TABLES `maxlife_tblacc_banking_rules` WRITE;
/*!40000 ALTER TABLE `maxlife_tblacc_banking_rules` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblacc_banking_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblacc_bill_mappings`
--

DROP TABLE IF EXISTS `maxlife_tblacc_bill_mappings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblacc_bill_mappings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bill_id` int(11) DEFAULT NULL,
  `type` varchar(25) DEFAULT NULL,
  `account` int(11) DEFAULT NULL,
  `amount` decimal(15,2) DEFAULT NULL,
  `item_id` int(11) NOT NULL DEFAULT 0,
  `qty` decimal(15,2) NOT NULL DEFAULT 0.00,
  `cost` decimal(15,2) NOT NULL DEFAULT 0.00,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblacc_bill_mappings`
--

LOCK TABLES `maxlife_tblacc_bill_mappings` WRITE;
/*!40000 ALTER TABLE `maxlife_tblacc_bill_mappings` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblacc_bill_mappings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblacc_budget_details`
--

DROP TABLE IF EXISTS `maxlife_tblacc_budget_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblacc_budget_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `budget_id` int(11) NOT NULL,
  `month` int(11) NOT NULL,
  `year` int(11) NOT NULL,
  `account` int(11) DEFAULT NULL,
  `amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblacc_budget_details`
--

LOCK TABLES `maxlife_tblacc_budget_details` WRITE;
/*!40000 ALTER TABLE `maxlife_tblacc_budget_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblacc_budget_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblacc_budgets`
--

DROP TABLE IF EXISTS `maxlife_tblacc_budgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblacc_budgets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `year` int(11) NOT NULL,
  `name` varchar(200) DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  `data_source` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblacc_budgets`
--

LOCK TABLES `maxlife_tblacc_budgets` WRITE;
/*!40000 ALTER TABLE `maxlife_tblacc_budgets` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblacc_budgets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblacc_check_details`
--

DROP TABLE IF EXISTS `maxlife_tblacc_check_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblacc_check_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `check_id` int(11) DEFAULT NULL,
  `bill` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblacc_check_details`
--

LOCK TABLES `maxlife_tblacc_check_details` WRITE;
/*!40000 ALTER TABLE `maxlife_tblacc_check_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblacc_check_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblacc_checks`
--

DROP TABLE IF EXISTS `maxlife_tblacc_checks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblacc_checks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(25) DEFAULT NULL,
  `amount` decimal(15,2) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `memo` varchar(255) DEFAULT NULL,
  `dateadded` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `bank_account` int(11) NOT NULL,
  `number` int(11) NOT NULL,
  `signed` int(11) NOT NULL DEFAULT 0,
  `include_company_name_address` int(11) NOT NULL DEFAULT 1,
  `include_routing_account_numbers` int(11) NOT NULL DEFAULT 1,
  `bill` int(11) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `zip` varchar(15) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `issue` int(11) DEFAULT NULL,
  `include_check_number` int(11) NOT NULL DEFAULT 1,
  `include_bank_name` int(11) NOT NULL DEFAULT 1,
  `bank_name` varchar(255) DEFAULT NULL,
  `address_line_1` text DEFAULT NULL,
  `address_line_2` text DEFAULT NULL,
  `vendor_city` varchar(100) DEFAULT NULL,
  `vendor_zip` varchar(15) DEFAULT NULL,
  `vendor_state` varchar(50) DEFAULT NULL,
  `vendor_address` text DEFAULT NULL,
  `reason_for_void` text DEFAULT NULL,
  `bill_items` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblacc_checks`
--

LOCK TABLES `maxlife_tblacc_checks` WRITE;
/*!40000 ALTER TABLE `maxlife_tblacc_checks` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblacc_checks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblacc_checks_printed`
--

DROP TABLE IF EXISTS `maxlife_tblacc_checks_printed`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblacc_checks_printed` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `check_id` int(11) DEFAULT NULL,
  `bank_account` int(11) DEFAULT NULL,
  `first_check_number` int(11) DEFAULT NULL,
  `printed_at` datetime DEFAULT NULL,
  `printed_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblacc_checks_printed`
--

LOCK TABLES `maxlife_tblacc_checks_printed` WRITE;
/*!40000 ALTER TABLE `maxlife_tblacc_checks_printed` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblacc_checks_printed` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblacc_expense_category_mapping_details`
--

DROP TABLE IF EXISTS `maxlife_tblacc_expense_category_mapping_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblacc_expense_category_mapping_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_mapping_id` int(11) NOT NULL,
  `payment_mode_id` int(11) NOT NULL,
  `payment_account` int(11) NOT NULL DEFAULT 0,
  `deposit_to` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblacc_expense_category_mapping_details`
--

LOCK TABLES `maxlife_tblacc_expense_category_mapping_details` WRITE;
/*!40000 ALTER TABLE `maxlife_tblacc_expense_category_mapping_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblacc_expense_category_mapping_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblacc_expense_category_mappings`
--

DROP TABLE IF EXISTS `maxlife_tblacc_expense_category_mappings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblacc_expense_category_mappings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `payment_account` int(11) NOT NULL DEFAULT 0,
  `deposit_to` int(11) NOT NULL DEFAULT 0,
  `preferred_payment_method` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblacc_expense_category_mappings`
--

LOCK TABLES `maxlife_tblacc_expense_category_mappings` WRITE;
/*!40000 ALTER TABLE `maxlife_tblacc_expense_category_mappings` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblacc_expense_category_mappings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblacc_income_statement_modifications`
--

DROP TABLE IF EXISTS `maxlife_tblacc_income_statement_modifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblacc_income_statement_modifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `account` int(11) DEFAULT NULL,
  `active` int(11) NOT NULL DEFAULT 1,
  `account_type` int(11) DEFAULT NULL,
  `options` text DEFAULT NULL,
  `dateadded` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `type` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblacc_income_statement_modifications`
--

LOCK TABLES `maxlife_tblacc_income_statement_modifications` WRITE;
/*!40000 ALTER TABLE `maxlife_tblacc_income_statement_modifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblacc_income_statement_modifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblacc_item_automatics`
--

DROP TABLE IF EXISTS `maxlife_tblacc_item_automatics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblacc_item_automatics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL,
  `inventory_asset_account` int(11) NOT NULL DEFAULT 0,
  `income_account` int(11) NOT NULL DEFAULT 0,
  `expense_account` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblacc_item_automatics`
--

LOCK TABLES `maxlife_tblacc_item_automatics` WRITE;
/*!40000 ALTER TABLE `maxlife_tblacc_item_automatics` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblacc_item_automatics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblacc_journal_entries`
--

DROP TABLE IF EXISTS `maxlife_tblacc_journal_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblacc_journal_entries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `number` varchar(45) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `journal_date` date DEFAULT NULL,
  `amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `reference` varchar(100) DEFAULT NULL,
  `recurring` int(11) NOT NULL DEFAULT 0,
  `recurring_type` varchar(10) DEFAULT NULL,
  `custom_recurring` tinyint(1) NOT NULL DEFAULT 0,
  `cycles` int(11) NOT NULL DEFAULT 0,
  `total_cycles` int(11) NOT NULL DEFAULT 0,
  `is_recurring_from` int(11) DEFAULT NULL,
  `last_recurring_date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblacc_journal_entries`
--

LOCK TABLES `maxlife_tblacc_journal_entries` WRITE;
/*!40000 ALTER TABLE `maxlife_tblacc_journal_entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblacc_journal_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblacc_matched_transactions`
--

DROP TABLE IF EXISTS `maxlife_tblacc_matched_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblacc_matched_transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_history_id` int(11) DEFAULT NULL,
  `history_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(255) DEFAULT NULL,
  `amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `company` int(11) DEFAULT NULL,
  `reconcile` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblacc_matched_transactions`
--

LOCK TABLES `maxlife_tblacc_matched_transactions` WRITE;
/*!40000 ALTER TABLE `maxlife_tblacc_matched_transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblacc_matched_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblacc_pay_bill_details`
--

DROP TABLE IF EXISTS `maxlife_tblacc_pay_bill_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblacc_pay_bill_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pay_bill` int(11) DEFAULT NULL,
  `bill_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblacc_pay_bill_details`
--

LOCK TABLES `maxlife_tblacc_pay_bill_details` WRITE;
/*!40000 ALTER TABLE `maxlife_tblacc_pay_bill_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblacc_pay_bill_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblacc_pay_bill_item_paid`
--

DROP TABLE IF EXISTS `maxlife_tblacc_pay_bill_item_paid`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblacc_pay_bill_item_paid` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pay_bill_id` int(11) NOT NULL DEFAULT 0,
  `item_id` int(11) DEFAULT NULL,
  `item_name` varchar(255) DEFAULT NULL,
  `item_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `amount_paid` decimal(15,2) NOT NULL DEFAULT 0.00,
  `check_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblacc_pay_bill_item_paid`
--

LOCK TABLES `maxlife_tblacc_pay_bill_item_paid` WRITE;
/*!40000 ALTER TABLE `maxlife_tblacc_pay_bill_item_paid` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblacc_pay_bill_item_paid` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblacc_pay_bills`
--

DROP TABLE IF EXISTS `maxlife_tblacc_pay_bills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblacc_pay_bills` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `expense` int(11) DEFAULT NULL,
  `amount` decimal(15,2) DEFAULT NULL,
  `reference_no` varchar(100) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `dateadded` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `company` int(11) DEFAULT NULL,
  `account_debit` int(11) DEFAULT NULL,
  `account_credit` int(11) DEFAULT NULL,
  `bill` int(11) NOT NULL DEFAULT 0,
  `vendor` int(11) NOT NULL DEFAULT 0,
  `pay_number` int(11) DEFAULT NULL,
  `payment_method` varchar(255) DEFAULT NULL,
  `bill_items` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblacc_pay_bills`
--

LOCK TABLES `maxlife_tblacc_pay_bills` WRITE;
/*!40000 ALTER TABLE `maxlife_tblacc_pay_bills` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblacc_pay_bills` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblacc_payment_mode_mappings`
--

DROP TABLE IF EXISTS `maxlife_tblacc_payment_mode_mappings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblacc_payment_mode_mappings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `payment_mode_id` int(11) NOT NULL,
  `payment_account` int(11) NOT NULL DEFAULT 0,
  `deposit_to` int(11) NOT NULL DEFAULT 0,
  `expense_payment_account` int(11) NOT NULL DEFAULT 0,
  `expense_deposit_to` int(11) NOT NULL DEFAULT 0,
  `credit_note_refund_payment_account` int(11) NOT NULL DEFAULT 0,
  `credit_note_refund_deposit_to` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblacc_payment_mode_mappings`
--

LOCK TABLES `maxlife_tblacc_payment_mode_mappings` WRITE;
/*!40000 ALTER TABLE `maxlife_tblacc_payment_mode_mappings` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblacc_payment_mode_mappings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblacc_plaid_transaction_logs`
--

DROP TABLE IF EXISTS `maxlife_tblacc_plaid_transaction_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblacc_plaid_transaction_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bank_id` int(11) DEFAULT NULL,
  `last_updated` date DEFAULT NULL,
  `transaction_count` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `addedFrom` int(11) DEFAULT NULL,
  `company` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblacc_plaid_transaction_logs`
--

LOCK TABLES `maxlife_tblacc_plaid_transaction_logs` WRITE;
/*!40000 ALTER TABLE `maxlife_tblacc_plaid_transaction_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblacc_plaid_transaction_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblacc_print_later`
--

DROP TABLE IF EXISTS `maxlife_tblacc_print_later`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblacc_print_later` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(45) DEFAULT NULL,
  `account` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblacc_print_later`
--

LOCK TABLES `maxlife_tblacc_print_later` WRITE;
/*!40000 ALTER TABLE `maxlife_tblacc_print_later` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblacc_print_later` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblacc_reconciles`
--

DROP TABLE IF EXISTS `maxlife_tblacc_reconciles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblacc_reconciles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account` int(11) NOT NULL,
  `beginning_balance` decimal(15,2) NOT NULL,
  `ending_balance` decimal(15,2) NOT NULL,
  `ending_date` date NOT NULL,
  `expense_date` date DEFAULT NULL,
  `service_charge` decimal(15,2) DEFAULT NULL,
  `expense_account` int(11) DEFAULT NULL,
  `income_date` date DEFAULT NULL,
  `interest_earned` decimal(15,2) DEFAULT NULL,
  `income_account` int(11) DEFAULT NULL,
  `finish` int(11) NOT NULL DEFAULT 0,
  `opening_balance` int(11) NOT NULL DEFAULT 0,
  `debits_for_period` decimal(15,2) DEFAULT NULL,
  `credits_for_period` decimal(15,2) DEFAULT NULL,
  `dateadded` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblacc_reconciles`
--

LOCK TABLES `maxlife_tblacc_reconciles` WRITE;
/*!40000 ALTER TABLE `maxlife_tblacc_reconciles` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblacc_reconciles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblacc_tax_mappings`
--

DROP TABLE IF EXISTS `maxlife_tblacc_tax_mappings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblacc_tax_mappings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tax_id` int(11) NOT NULL,
  `payment_account` int(11) NOT NULL DEFAULT 0,
  `deposit_to` int(11) NOT NULL DEFAULT 0,
  `expense_payment_account` int(11) NOT NULL DEFAULT 0,
  `expense_deposit_to` int(11) NOT NULL DEFAULT 0,
  `purchase_payment_account` int(11) NOT NULL DEFAULT 0,
  `purchase_deposit_to` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblacc_tax_mappings`
--

LOCK TABLES `maxlife_tblacc_tax_mappings` WRITE;
/*!40000 ALTER TABLE `maxlife_tblacc_tax_mappings` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblacc_tax_mappings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblacc_transaction_bankings`
--

DROP TABLE IF EXISTS `maxlife_tblacc_transaction_bankings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblacc_transaction_bankings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `withdrawals` decimal(15,2) NOT NULL DEFAULT 0.00,
  `deposits` decimal(15,2) NOT NULL DEFAULT 0.00,
  `payee` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `transaction_id` varchar(150) DEFAULT NULL,
  `bank_id` int(11) DEFAULT NULL,
  `status` tinyint(5) NOT NULL DEFAULT 0 COMMENT '1=>posted, 2=>pending',
  `matched` int(11) NOT NULL DEFAULT 0,
  `reconcile` int(11) NOT NULL DEFAULT 0,
  `adjusted` int(11) NOT NULL DEFAULT 0,
  `is_imported` int(11) NOT NULL DEFAULT 0,
  `banking_rule` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblacc_transaction_bankings`
--

LOCK TABLES `maxlife_tblacc_transaction_bankings` WRITE;
/*!40000 ALTER TABLE `maxlife_tblacc_transaction_bankings` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblacc_transaction_bankings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblacc_transfers`
--

DROP TABLE IF EXISTS `maxlife_tblacc_transfers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblacc_transfers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transfer_funds_from` int(11) NOT NULL,
  `transfer_funds_to` int(11) NOT NULL,
  `transfer_amount` decimal(15,2) DEFAULT NULL,
  `date` varchar(45) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblacc_transfers`
--

LOCK TABLES `maxlife_tblacc_transfers` WRITE;
/*!40000 ALTER TABLE `maxlife_tblacc_transfers` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblacc_transfers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblaccount_planning`
--

DROP TABLE IF EXISTS `maxlife_tblaccount_planning`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblaccount_planning` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) NOT NULL,
  `vision` varchar(255) DEFAULT NULL,
  `mission` varchar(255) DEFAULT NULL,
  `lead_generation` varchar(45) DEFAULT NULL,
  `current_service_know_pmax` varchar(45) DEFAULT NULL,
  `current_service_facebook` varchar(45) DEFAULT NULL,
  `current_service_sem` varchar(45) DEFAULT NULL,
  `objectives` varchar(255) DEFAULT NULL,
  `threat` varchar(255) DEFAULT NULL,
  `opportunity` varchar(255) DEFAULT NULL,
  `criteria_to_success` varchar(255) DEFAULT NULL,
  `constraints` varchar(255) DEFAULT NULL,
  `data_tree` longtext DEFAULT NULL,
  `latest_update` date DEFAULT NULL,
  `new_update` date DEFAULT NULL,
  `product` varchar(255) DEFAULT NULL,
  `sale_channel_online` varchar(255) DEFAULT NULL,
  `sale_channel_offline` varchar(255) DEFAULT NULL,
  `revenue_next_year` varchar(255) DEFAULT NULL,
  `wallet_share` varchar(255) DEFAULT NULL,
  `client_status` varchar(255) DEFAULT NULL,
  `bcg_model` varchar(255) DEFAULT NULL,
  `margin` varchar(255) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblaccount_planning`
--

LOCK TABLES `maxlife_tblaccount_planning` WRITE;
/*!40000 ALTER TABLE `maxlife_tblaccount_planning` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblaccount_planning` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblaccount_planning_current_service`
--

DROP TABLE IF EXISTS `maxlife_tblaccount_planning_current_service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblaccount_planning_current_service` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_planning_id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `potential` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblaccount_planning_current_service`
--

LOCK TABLES `maxlife_tblaccount_planning_current_service` WRITE;
/*!40000 ALTER TABLE `maxlife_tblaccount_planning_current_service` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblaccount_planning_current_service` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblaccount_planning_financial`
--

DROP TABLE IF EXISTS `maxlife_tblaccount_planning_financial`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblaccount_planning_financial` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_planning_id` int(11) NOT NULL,
  `year` varchar(45) DEFAULT NULL,
  `revenue` varchar(255) DEFAULT NULL,
  `sales_spent` varchar(255) DEFAULT NULL,
  `traffic` varchar(255) DEFAULT NULL,
  `loss` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblaccount_planning_financial`
--

LOCK TABLES `maxlife_tblaccount_planning_financial` WRITE;
/*!40000 ALTER TABLE `maxlife_tblaccount_planning_financial` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblaccount_planning_financial` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblaccount_planning_items`
--

DROP TABLE IF EXISTS `maxlife_tblaccount_planning_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblaccount_planning_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_planning_id` int(11) NOT NULL,
  `objective_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `datecreated` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblaccount_planning_items`
--

LOCK TABLES `maxlife_tblaccount_planning_items` WRITE;
/*!40000 ALTER TABLE `maxlife_tblaccount_planning_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblaccount_planning_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblaccount_planning_marketing_activities`
--

DROP TABLE IF EXISTS `maxlife_tblaccount_planning_marketing_activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblaccount_planning_marketing_activities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_planning_id` int(11) NOT NULL,
  `item` varchar(255) DEFAULT NULL,
  `reference` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblaccount_planning_marketing_activities`
--

LOCK TABLES `maxlife_tblaccount_planning_marketing_activities` WRITE;
/*!40000 ALTER TABLE `maxlife_tblaccount_planning_marketing_activities` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblaccount_planning_marketing_activities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblaccount_planning_objective`
--

DROP TABLE IF EXISTS `maxlife_tblaccount_planning_objective`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblaccount_planning_objective` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_planning_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `datecreated` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblaccount_planning_objective`
--

LOCK TABLES `maxlife_tblaccount_planning_objective` WRITE;
/*!40000 ALTER TABLE `maxlife_tblaccount_planning_objective` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblaccount_planning_objective` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblaccount_planning_service_ability_offering`
--

DROP TABLE IF EXISTS `maxlife_tblaccount_planning_service_ability_offering`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblaccount_planning_service_ability_offering` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_planning_id` int(11) NOT NULL,
  `service` varchar(255) DEFAULT NULL,
  `potential` varchar(255) DEFAULT NULL,
  `scale` varchar(255) DEFAULT NULL,
  `convert` varchar(255) DEFAULT NULL,
  `prioritization` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblaccount_planning_service_ability_offering`
--

LOCK TABLES `maxlife_tblaccount_planning_service_ability_offering` WRITE;
/*!40000 ALTER TABLE `maxlife_tblaccount_planning_service_ability_offering` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblaccount_planning_service_ability_offering` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblaccount_planning_task`
--

DROP TABLE IF EXISTS `maxlife_tblaccount_planning_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblaccount_planning_task` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL,
  `account_planning_id` int(11) DEFAULT NULL,
  `action_needed` varchar(255) NOT NULL,
  `prioritization` varchar(255) DEFAULT NULL,
  `pic` varchar(255) DEFAULT NULL,
  `deadline` date DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `objective` varchar(255) DEFAULT NULL,
  `item` varchar(255) DEFAULT NULL,
  `convert_to_task` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblaccount_planning_task`
--

LOCK TABLES `maxlife_tblaccount_planning_task` WRITE;
/*!40000 ALTER TABLE `maxlife_tblaccount_planning_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblaccount_planning_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblaccount_planning_team`
--

DROP TABLE IF EXISTS `maxlife_tblaccount_planning_team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblaccount_planning_team` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_planning_id` int(11) NOT NULL,
  `rel_id` varchar(45) NOT NULL,
  `rel_type` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblaccount_planning_team`
--

LOCK TABLES `maxlife_tblaccount_planning_team` WRITE;
/*!40000 ALTER TABLE `maxlife_tblaccount_planning_team` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblaccount_planning_team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblactivity_log`
--

DROP TABLE IF EXISTS `maxlife_tblactivity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblactivity_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` longtext NOT NULL,
  `date` datetime NOT NULL,
  `staffid` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `maxlife_staffid` (`staffid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblactivity_log`
--

LOCK TABLES `maxlife_tblactivity_log` WRITE;
/*!40000 ALTER TABLE `maxlife_tblactivity_log` DISABLE KEYS */;
INSERT INTO `maxlife_tblactivity_log` VALUES (1,'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 106.219.231.124]','2025-07-13 18:59:54','Ayesha Ayesha'),(2,'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 106.219.231.124]','2025-07-13 18:59:57','Ayesha Ayesha');
/*!40000 ALTER TABLE `maxlife_tblactivity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblaffiliate_m_affiliates`
--

DROP TABLE IF EXISTS `maxlife_tblaffiliate_m_affiliates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblaffiliate_m_affiliates` (
  `affiliate_id` int(11) NOT NULL AUTO_INCREMENT,
  `affiliate_slug` varchar(255) NOT NULL,
  `group_id` varchar(255) DEFAULT NULL,
  `contact_id` int(11) NOT NULL,
  `total_earnings` decimal(10,2) DEFAULT 0.00,
  `balance` decimal(10,2) DEFAULT 0.00,
  `status` varchar(255) DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`affiliate_id`),
  UNIQUE KEY `unique_maxlife_tbl_contact_id` (`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblaffiliate_m_affiliates`
--

LOCK TABLES `maxlife_tblaffiliate_m_affiliates` WRITE;
/*!40000 ALTER TABLE `maxlife_tblaffiliate_m_affiliates` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblaffiliate_m_affiliates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblaffiliate_m_commissions`
--

DROP TABLE IF EXISTS `maxlife_tblaffiliate_m_commissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblaffiliate_m_commissions` (
  `commission_id` int(11) NOT NULL AUTO_INCREMENT,
  `referral_id` int(11) NOT NULL,
  `affiliate_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `payment_id` int(11) DEFAULT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `rule_info` varchar(255) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`commission_id`),
  KEY `fk_maxlife_tbl_commission_referral_id` (`referral_id`),
  KEY `fk_maxlife_tbl_commission_affiliate_id` (`affiliate_id`),
  CONSTRAINT `fk_maxlife_tbl_commission_affiliate_id` FOREIGN KEY (`affiliate_id`) REFERENCES `maxlife_tblaffiliate_m_affiliates` (`affiliate_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_maxlife_tbl_commission_referral_id` FOREIGN KEY (`referral_id`) REFERENCES `maxlife_tblaffiliate_m_referrals` (`referral_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblaffiliate_m_commissions`
--

LOCK TABLES `maxlife_tblaffiliate_m_commissions` WRITE;
/*!40000 ALTER TABLE `maxlife_tblaffiliate_m_commissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblaffiliate_m_commissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblaffiliate_m_payouts`
--

DROP TABLE IF EXISTS `maxlife_tblaffiliate_m_payouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblaffiliate_m_payouts` (
  `payout_id` int(11) NOT NULL AUTO_INCREMENT,
  `affiliate_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `note_for_affiliate` text DEFAULT NULL,
  `note_for_admin` text DEFAULT NULL,
  `payout_method` varchar(255) NOT NULL,
  `status` varchar(255) DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`payout_id`),
  KEY `fk_maxlife_tbl_afm_payout_affiliate_id` (`affiliate_id`),
  CONSTRAINT `fk_maxlife_tbl_afm_payout_affiliate_id` FOREIGN KEY (`affiliate_id`) REFERENCES `maxlife_tblaffiliate_m_affiliates` (`affiliate_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblaffiliate_m_payouts`
--

LOCK TABLES `maxlife_tblaffiliate_m_payouts` WRITE;
/*!40000 ALTER TABLE `maxlife_tblaffiliate_m_payouts` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblaffiliate_m_payouts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblaffiliate_m_referrals`
--

DROP TABLE IF EXISTS `maxlife_tblaffiliate_m_referrals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblaffiliate_m_referrals` (
  `referral_id` int(11) NOT NULL AUTO_INCREMENT,
  `affiliate_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `ua` text DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`referral_id`),
  UNIQUE KEY `unique_maxlife_tbl_client_id` (`client_id`),
  KEY `fk_maxlife_tbl_referral_affiliate_id` (`affiliate_id`),
  CONSTRAINT `fk_maxlife_tbl_referral_affiliate_id` FOREIGN KEY (`affiliate_id`) REFERENCES `maxlife_tblaffiliate_m_affiliates` (`affiliate_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblaffiliate_m_referrals`
--

LOCK TABLES `maxlife_tblaffiliate_m_referrals` WRITE;
/*!40000 ALTER TABLE `maxlife_tblaffiliate_m_referrals` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblaffiliate_m_referrals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblaffiliate_m_tracking`
--

DROP TABLE IF EXISTS `maxlife_tblaffiliate_m_tracking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblaffiliate_m_tracking` (
  `tracking_id` int(11) NOT NULL AUTO_INCREMENT,
  `affiliate_slug` varchar(255) NOT NULL,
  `rel_type` varchar(255) NOT NULL,
  `rel_id` int(11) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phonenumber` varchar(255) DEFAULT NULL,
  `metadata` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`tracking_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblaffiliate_m_tracking`
--

LOCK TABLES `maxlife_tblaffiliate_m_tracking` WRITE;
/*!40000 ALTER TABLE `maxlife_tblaffiliate_m_tracking` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblaffiliate_m_tracking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblannouncements`
--

DROP TABLE IF EXISTS `maxlife_tblannouncements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblannouncements` (
  `announcementid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `message` mediumtext DEFAULT NULL,
  `showtousers` int(11) NOT NULL,
  `showtostaff` int(11) NOT NULL,
  `showname` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  `userid` varchar(100) NOT NULL,
  PRIMARY KEY (`announcementid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblannouncements`
--

LOCK TABLES `maxlife_tblannouncements` WRITE;
/*!40000 ALTER TABLE `maxlife_tblannouncements` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblannouncements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblappointly_appointment_types`
--

DROP TABLE IF EXISTS `maxlife_tblappointly_appointment_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblappointly_appointment_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(191) NOT NULL,
  `color` varchar(191) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblappointly_appointment_types`
--

LOCK TABLES `maxlife_tblappointly_appointment_types` WRITE;
/*!40000 ALTER TABLE `maxlife_tblappointly_appointment_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblappointly_appointment_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblappointly_appointments`
--

DROP TABLE IF EXISTS `maxlife_tblappointly_appointments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblappointly_appointments` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `google_event_id` varchar(191) DEFAULT NULL,
  `google_calendar_link` varchar(191) DEFAULT NULL,
  `google_meet_link` varchar(191) DEFAULT NULL,
  `google_added_by_id` int(11) DEFAULT NULL,
  `outlook_event_id` varchar(191) DEFAULT NULL,
  `outlook_calendar_link` varchar(255) DEFAULT NULL,
  `outlook_added_by_id` int(11) DEFAULT NULL,
  `subject` varchar(191) NOT NULL,
  `description` text DEFAULT NULL,
  `email` varchar(191) DEFAULT NULL,
  `name` varchar(191) DEFAULT NULL,
  `phone` varchar(191) DEFAULT NULL,
  `address` varchar(191) DEFAULT NULL,
  `notes` longtext DEFAULT NULL,
  `contact_id` int(11) DEFAULT NULL,
  `by_sms` tinyint(1) DEFAULT NULL,
  `by_email` tinyint(1) DEFAULT NULL,
  `hash` varchar(191) DEFAULT NULL,
  `notification_date` datetime DEFAULT NULL,
  `external_notification_date` datetime DEFAULT NULL,
  `date` date NOT NULL,
  `start_hour` varchar(191) NOT NULL,
  `approved` tinyint(1) NOT NULL DEFAULT 0,
  `created_by` int(11) DEFAULT NULL,
  `reminder_before` int(11) DEFAULT NULL,
  `reminder_before_type` varchar(10) DEFAULT NULL,
  `finished` tinyint(1) NOT NULL DEFAULT 0,
  `cancelled` tinyint(1) NOT NULL DEFAULT 0,
  `cancel_notes` text DEFAULT NULL,
  `source` varchar(191) DEFAULT NULL,
  `type_id` int(11) NOT NULL DEFAULT 0,
  `feedback` smallint(6) DEFAULT NULL,
  `feedback_comment` text DEFAULT NULL,
  `recurring` int(11) NOT NULL DEFAULT 0,
  `recurring_type` varchar(10) DEFAULT NULL,
  `repeat_every` int(11) DEFAULT NULL,
  `custom_recurring` tinyint(4) NOT NULL,
  `cycles` int(11) NOT NULL DEFAULT 0,
  `total_cycles` int(11) NOT NULL DEFAULT 0,
  `last_recurring_date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblappointly_appointments`
--

LOCK TABLES `maxlife_tblappointly_appointments` WRITE;
/*!40000 ALTER TABLE `maxlife_tblappointly_appointments` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblappointly_appointments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblappointly_attendees`
--

DROP TABLE IF EXISTS `maxlife_tblappointly_attendees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblappointly_attendees` (
  `staff_id` int(11) NOT NULL,
  `appointment_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblappointly_attendees`
--

LOCK TABLES `maxlife_tblappointly_attendees` WRITE;
/*!40000 ALTER TABLE `maxlife_tblappointly_attendees` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblappointly_attendees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblappointly_callbacks`
--

DROP TABLE IF EXISTS `maxlife_tblappointly_callbacks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblappointly_callbacks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `call_type` varchar(191) NOT NULL,
  `phone_number` varchar(191) NOT NULL,
  `timezone` varchar(191) NOT NULL,
  `firstname` varchar(191) NOT NULL,
  `lastname` varchar(191) NOT NULL,
  `status` varchar(191) NOT NULL DEFAULT '1',
  `message` text NOT NULL,
  `email` varchar(191) NOT NULL,
  `date_start` datetime NOT NULL,
  `date_end` datetime NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblappointly_callbacks`
--

LOCK TABLES `maxlife_tblappointly_callbacks` WRITE;
/*!40000 ALTER TABLE `maxlife_tblappointly_callbacks` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblappointly_callbacks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblappointly_callbacks_assignees`
--

DROP TABLE IF EXISTS `maxlife_tblappointly_callbacks_assignees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblappointly_callbacks_assignees` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `callbackid` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblappointly_callbacks_assignees`
--

LOCK TABLES `maxlife_tblappointly_callbacks_assignees` WRITE;
/*!40000 ALTER TABLE `maxlife_tblappointly_callbacks_assignees` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblappointly_callbacks_assignees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblappointly_google`
--

DROP TABLE IF EXISTS `maxlife_tblappointly_google`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblappointly_google` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `access_token` varchar(191) NOT NULL,
  `refresh_token` varchar(191) NOT NULL,
  `expires_in` varchar(191) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblappointly_google`
--

LOCK TABLES `maxlife_tblappointly_google` WRITE;
/*!40000 ALTER TABLE `maxlife_tblappointly_google` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblappointly_google` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblcart`
--

DROP TABLE IF EXISTS `maxlife_tblcart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblcart` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_contact` int(11) NOT NULL,
  `name` varchar(120) NOT NULL,
  `address` varchar(250) NOT NULL,
  `phone_number` varchar(20) NOT NULL,
  `voucher` varchar(100) NOT NULL,
  `status` int(11) DEFAULT 0,
  `complete` int(11) DEFAULT 0,
  `datecreator` datetime NOT NULL DEFAULT current_timestamp(),
  `order_number` varchar(100) DEFAULT NULL,
  `channel_id` int(11) DEFAULT NULL,
  `channel` varchar(150) DEFAULT NULL,
  `first_name` varchar(60) DEFAULT NULL,
  `last_name` varchar(60) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `company` varchar(150) DEFAULT NULL,
  `phonenumber` varchar(15) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL,
  `zip` varchar(50) DEFAULT NULL,
  `billing_street` varchar(150) DEFAULT NULL,
  `billing_city` varchar(50) DEFAULT NULL,
  `billing_state` varchar(50) DEFAULT NULL,
  `billing_country` varchar(50) DEFAULT NULL,
  `billing_zip` varchar(50) DEFAULT NULL,
  `shipping_street` varchar(150) DEFAULT NULL,
  `shipping_city` varchar(50) DEFAULT NULL,
  `shipping_state` varchar(50) DEFAULT NULL,
  `shipping_country` varchar(50) DEFAULT NULL,
  `shipping_zip` varchar(50) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `reason` varchar(250) DEFAULT NULL,
  `admin_action` int(11) DEFAULT 0,
  `discount` varchar(250) DEFAULT NULL,
  `discount_type` int(11) DEFAULT 0,
  `total` varchar(250) DEFAULT NULL,
  `sub_total` varchar(250) DEFAULT NULL,
  `discount_total` varchar(250) NOT NULL DEFAULT '',
  `invoice` varchar(250) NOT NULL DEFAULT '',
  `number_invoice` varchar(250) NOT NULL DEFAULT '',
  `stock_export_number` varchar(250) NOT NULL DEFAULT '',
  `create_invoice` varchar(5) NOT NULL DEFAULT 'off',
  `stock_export` varchar(5) NOT NULL DEFAULT 'off',
  `customers_pay` decimal(15,2) NOT NULL DEFAULT 0.00,
  `amount_returned` decimal(15,2) NOT NULL DEFAULT 0.00,
  `tax` decimal(15,2) NOT NULL DEFAULT 0.00,
  `seller` int(11) DEFAULT NULL,
  `staff_note` text DEFAULT NULL,
  `payment_note` text DEFAULT NULL,
  `allowed_payment_modes` varchar(200) DEFAULT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `shipping` decimal(15,2) NOT NULL DEFAULT 0.00,
  `payment_method_title` varchar(250) DEFAULT NULL,
  `discount_type_str` text DEFAULT NULL,
  `discount_percent` decimal(15,2) DEFAULT NULL,
  `adjustment` decimal(15,2) DEFAULT NULL,
  `currency` int(11) DEFAULT NULL,
  `terms` text DEFAULT NULL,
  `shipping_tax` decimal(15,2) DEFAULT NULL,
  `enable` int(11) NOT NULL DEFAULT 1,
  `duedate` date DEFAULT NULL,
  `shipping_tax_json` varchar(150) DEFAULT NULL,
  `discount_voucher` varchar(150) DEFAULT NULL,
  `original_order_id` int(11) DEFAULT NULL,
  `return_reason` longtext DEFAULT NULL,
  `approve_status` int(11) NOT NULL DEFAULT 0,
  `process_invoice` varchar(5) NOT NULL DEFAULT 'off',
  `stock_import_number` int(11) NOT NULL DEFAULT 0,
  `fee_for_return_order` decimal(15,2) DEFAULT NULL,
  `hash` varchar(32) DEFAULT NULL,
  `estimate_id` int(11) DEFAULT NULL,
  `add_discount` decimal(15,2) DEFAULT 0.00,
  `shipping_form` varchar(50) DEFAULT 'fixed',
  `shipping_value` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblcart`
--

LOCK TABLES `maxlife_tblcart` WRITE;
/*!40000 ALTER TABLE `maxlife_tblcart` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblcart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblcart_detailt`
--

DROP TABLE IF EXISTS `maxlife_tblcart_detailt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblcart_detailt` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `quantity` float NOT NULL,
  `classify` varchar(30) DEFAULT NULL,
  `cart_id` int(11) NOT NULL,
  `product_name` varchar(150) DEFAULT NULL,
  `prices` decimal(15,2) DEFAULT NULL,
  `long_description` text DEFAULT NULL,
  `sku` text NOT NULL,
  `percent_discount` decimal(15,0) NOT NULL,
  `prices_discount` decimal(15,2) NOT NULL,
  `tax` text DEFAULT NULL,
  `tax_id` text DEFAULT NULL,
  `tax_rate` text DEFAULT NULL,
  `tax_name` text DEFAULT NULL,
  `unit_id` int(11) DEFAULT NULL,
  `unit_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblcart_detailt`
--

LOCK TABLES `maxlife_tblcart_detailt` WRITE;
/*!40000 ALTER TABLE `maxlife_tblcart_detailt` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblcart_detailt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblcheck_in_out`
--

DROP TABLE IF EXISTS `maxlife_tblcheck_in_out`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblcheck_in_out` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `type_check` int(11) DEFAULT NULL,
  `type` varchar(5) NOT NULL DEFAULT 'W',
  `route_point_id` int(11) DEFAULT NULL,
  `workplace_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblcheck_in_out`
--

LOCK TABLES `maxlife_tblcheck_in_out` WRITE;
/*!40000 ALTER TABLE `maxlife_tblcheck_in_out` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblcheck_in_out` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblclients`
--

DROP TABLE IF EXISTS `maxlife_tblclients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblclients` (
  `userid` int(11) NOT NULL AUTO_INCREMENT,
  `company` varchar(191) DEFAULT NULL,
  `vat` varchar(50) DEFAULT NULL,
  `phonenumber` varchar(30) DEFAULT NULL,
  `country` int(11) NOT NULL DEFAULT 0,
  `city` varchar(100) DEFAULT NULL,
  `zip` varchar(15) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `address` varchar(191) DEFAULT NULL,
  `website` varchar(150) DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `active` int(11) NOT NULL DEFAULT 1,
  `leadid` int(11) DEFAULT NULL,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT 0,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT 0,
  `longitude` varchar(191) DEFAULT NULL,
  `latitude` varchar(191) DEFAULT NULL,
  `default_language` varchar(40) DEFAULT NULL,
  `default_currency` int(11) NOT NULL DEFAULT 0,
  `show_primary_contact` int(11) NOT NULL DEFAULT 0,
  `stripe_id` varchar(40) DEFAULT NULL,
  `registration_confirmed` int(11) NOT NULL DEFAULT 1,
  `addedfrom` int(11) NOT NULL DEFAULT 0,
  `balance` decimal(15,2) DEFAULT NULL,
  `balance_as_of` date DEFAULT NULL,
  `loy_point` decimal(10,0) DEFAULT 0,
  `sector` varchar(255) DEFAULT NULL,
  `industry` varchar(255) DEFAULT NULL,
  `continue_from_date` date DEFAULT NULL,
  `woo_customer_id` int(11) DEFAULT 0,
  `woo_channel_id` int(11) DEFAULT 0,
  PRIMARY KEY (`userid`),
  KEY `country` (`country`),
  KEY `leadid` (`leadid`),
  KEY `company` (`company`),
  KEY `active` (`active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblclients`
--

LOCK TABLES `maxlife_tblclients` WRITE;
/*!40000 ALTER TABLE `maxlife_tblclients` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblclients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblconsent_purposes`
--

DROP TABLE IF EXISTS `maxlife_tblconsent_purposes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblconsent_purposes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `last_updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblconsent_purposes`
--

LOCK TABLES `maxlife_tblconsent_purposes` WRITE;
/*!40000 ALTER TABLE `maxlife_tblconsent_purposes` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblconsent_purposes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblconsents`
--

DROP TABLE IF EXISTS `maxlife_tblconsents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblconsents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action` varchar(10) NOT NULL,
  `date` datetime NOT NULL,
  `ip` varchar(40) NOT NULL,
  `contact_id` int(11) NOT NULL DEFAULT 0,
  `lead_id` int(11) NOT NULL DEFAULT 0,
  `description` mediumtext DEFAULT NULL,
  `opt_in_purpose_description` mediumtext DEFAULT NULL,
  `purpose_id` int(11) NOT NULL,
  `staff_name` varchar(100) DEFAULT NULL,
  `candidate_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `purpose_id` (`purpose_id`),
  KEY `contact_id` (`contact_id`),
  KEY `lead_id` (`lead_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblconsents`
--

LOCK TABLES `maxlife_tblconsents` WRITE;
/*!40000 ALTER TABLE `maxlife_tblconsents` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblconsents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblcontact_permissions`
--

DROP TABLE IF EXISTS `maxlife_tblcontact_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblcontact_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permission_id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblcontact_permissions`
--

LOCK TABLES `maxlife_tblcontact_permissions` WRITE;
/*!40000 ALTER TABLE `maxlife_tblcontact_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblcontact_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblcontacts`
--

DROP TABLE IF EXISTS `maxlife_tblcontacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblcontacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `is_primary` int(11) NOT NULL DEFAULT 1,
  `firstname` varchar(191) NOT NULL,
  `lastname` varchar(191) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phonenumber` varchar(100) NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `new_pass_key` varchar(32) DEFAULT NULL,
  `new_pass_key_requested` datetime DEFAULT NULL,
  `email_verified_at` datetime DEFAULT NULL,
  `email_verification_key` varchar(32) DEFAULT NULL,
  `email_verification_sent_at` datetime DEFAULT NULL,
  `last_ip` varchar(40) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_password_change` datetime DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `profile_image` varchar(191) DEFAULT NULL,
  `direction` varchar(3) DEFAULT NULL,
  `invoice_emails` tinyint(1) NOT NULL DEFAULT 1,
  `estimate_emails` tinyint(1) NOT NULL DEFAULT 1,
  `credit_note_emails` tinyint(1) NOT NULL DEFAULT 1,
  `contract_emails` tinyint(1) NOT NULL DEFAULT 1,
  `task_emails` tinyint(1) NOT NULL DEFAULT 1,
  `project_emails` tinyint(1) NOT NULL DEFAULT 1,
  `ticket_emails` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `firstname` (`firstname`),
  KEY `lastname` (`lastname`),
  KEY `email` (`email`),
  KEY `is_primary` (`is_primary`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblcontacts`
--

LOCK TABLES `maxlife_tblcontacts` WRITE;
/*!40000 ALTER TABLE `maxlife_tblcontacts` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblcontacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblcontract_comments`
--

DROP TABLE IF EXISTS `maxlife_tblcontract_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblcontract_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` longtext DEFAULT NULL,
  `contract_id` int(11) NOT NULL,
  `staffid` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblcontract_comments`
--

LOCK TABLES `maxlife_tblcontract_comments` WRITE;
/*!40000 ALTER TABLE `maxlife_tblcontract_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblcontract_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblcontract_renewals`
--

DROP TABLE IF EXISTS `maxlife_tblcontract_renewals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblcontract_renewals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contractid` int(11) NOT NULL,
  `old_start_date` date NOT NULL,
  `new_start_date` date NOT NULL,
  `old_end_date` date DEFAULT NULL,
  `new_end_date` date DEFAULT NULL,
  `old_value` decimal(15,2) DEFAULT NULL,
  `new_value` decimal(15,2) DEFAULT NULL,
  `date_renewed` datetime NOT NULL,
  `renewed_by` varchar(100) NOT NULL,
  `renewed_by_staff_id` int(11) NOT NULL DEFAULT 0,
  `is_on_old_expiry_notified` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblcontract_renewals`
--

LOCK TABLES `maxlife_tblcontract_renewals` WRITE;
/*!40000 ALTER TABLE `maxlife_tblcontract_renewals` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblcontract_renewals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblcontracts`
--

DROP TABLE IF EXISTS `maxlife_tblcontracts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblcontracts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` longtext DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `subject` varchar(191) DEFAULT NULL,
  `client` int(11) NOT NULL,
  `datestart` date DEFAULT NULL,
  `dateend` date DEFAULT NULL,
  `contract_type` int(11) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  `isexpirynotified` int(11) NOT NULL DEFAULT 0,
  `contract_value` decimal(15,2) DEFAULT NULL,
  `trash` tinyint(1) DEFAULT 0,
  `not_visible_to_client` tinyint(1) NOT NULL DEFAULT 0,
  `hash` varchar(32) DEFAULT NULL,
  `signed` tinyint(1) NOT NULL DEFAULT 0,
  `signature` varchar(40) DEFAULT NULL,
  `marked_as_signed` tinyint(1) NOT NULL DEFAULT 0,
  `acceptance_firstname` varchar(50) DEFAULT NULL,
  `acceptance_lastname` varchar(50) DEFAULT NULL,
  `acceptance_email` varchar(100) DEFAULT NULL,
  `acceptance_date` datetime DEFAULT NULL,
  `acceptance_ip` varchar(40) DEFAULT NULL,
  `short_link` varchar(100) DEFAULT NULL,
  `last_sent_at` datetime DEFAULT NULL,
  `contacts_sent_to` mediumtext DEFAULT NULL,
  `last_sign_reminder_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `client` (`client`),
  KEY `contract_type` (`contract_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblcontracts`
--

LOCK TABLES `maxlife_tblcontracts` WRITE;
/*!40000 ALTER TABLE `maxlife_tblcontracts` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblcontracts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblcontracts_types`
--

DROP TABLE IF EXISTS `maxlife_tblcontracts_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblcontracts_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblcontracts_types`
--

LOCK TABLES `maxlife_tblcontracts_types` WRITE;
/*!40000 ALTER TABLE `maxlife_tblcontracts_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblcontracts_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblcountries`
--

DROP TABLE IF EXISTS `maxlife_tblcountries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblcountries` (
  `country_id` int(11) NOT NULL AUTO_INCREMENT,
  `iso2` char(2) DEFAULT NULL,
  `short_name` varchar(80) NOT NULL DEFAULT '',
  `long_name` varchar(80) NOT NULL DEFAULT '',
  `iso3` char(3) DEFAULT NULL,
  `numcode` varchar(6) DEFAULT NULL,
  `un_member` varchar(12) DEFAULT NULL,
  `calling_code` varchar(8) DEFAULT NULL,
  `cctld` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`country_id`)
) ENGINE=InnoDB AUTO_INCREMENT=251 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblcountries`
--

LOCK TABLES `maxlife_tblcountries` WRITE;
/*!40000 ALTER TABLE `maxlife_tblcountries` DISABLE KEYS */;
INSERT INTO `maxlife_tblcountries` VALUES (1,'AF','Afghanistan','Islamic Republic of Afghanistan','AFG','004','yes','93','.af'),(2,'AX','Aland Islands','&Aring;land Islands','ALA','248','no','358','.ax'),(3,'AL','Albania','Republic of Albania','ALB','008','yes','355','.al'),(4,'DZ','Algeria','People\'s Democratic Republic of Algeria','DZA','012','yes','213','.dz'),(5,'AS','American Samoa','American Samoa','ASM','016','no','1+684','.as'),(6,'AD','Andorra','Principality of Andorra','AND','020','yes','376','.ad'),(7,'AO','Angola','Republic of Angola','AGO','024','yes','244','.ao'),(8,'AI','Anguilla','Anguilla','AIA','660','no','1+264','.ai'),(9,'AQ','Antarctica','Antarctica','ATA','010','no','672','.aq'),(10,'AG','Antigua and Barbuda','Antigua and Barbuda','ATG','028','yes','1+268','.ag'),(11,'AR','Argentina','Argentine Republic','ARG','032','yes','54','.ar'),(12,'AM','Armenia','Republic of Armenia','ARM','051','yes','374','.am'),(13,'AW','Aruba','Aruba','ABW','533','no','297','.aw'),(14,'AU','Australia','Commonwealth of Australia','AUS','036','yes','61','.au'),(15,'AT','Austria','Republic of Austria','AUT','040','yes','43','.at'),(16,'AZ','Azerbaijan','Republic of Azerbaijan','AZE','031','yes','994','.az'),(17,'BS','Bahamas','Commonwealth of The Bahamas','BHS','044','yes','1+242','.bs'),(18,'BH','Bahrain','Kingdom of Bahrain','BHR','048','yes','973','.bh'),(19,'BD','Bangladesh','People\'s Republic of Bangladesh','BGD','050','yes','880','.bd'),(20,'BB','Barbados','Barbados','BRB','052','yes','1+246','.bb'),(21,'BY','Belarus','Republic of Belarus','BLR','112','yes','375','.by'),(22,'BE','Belgium','Kingdom of Belgium','BEL','056','yes','32','.be'),(23,'BZ','Belize','Belize','BLZ','084','yes','501','.bz'),(24,'BJ','Benin','Republic of Benin','BEN','204','yes','229','.bj'),(25,'BM','Bermuda','Bermuda Islands','BMU','060','no','1+441','.bm'),(26,'BT','Bhutan','Kingdom of Bhutan','BTN','064','yes','975','.bt'),(27,'BO','Bolivia','Plurinational State of Bolivia','BOL','068','yes','591','.bo'),(28,'BQ','Bonaire, Sint Eustatius and Saba','Bonaire, Sint Eustatius and Saba','BES','535','no','599','.bq'),(29,'BA','Bosnia and Herzegovina','Bosnia and Herzegovina','BIH','070','yes','387','.ba'),(30,'BW','Botswana','Republic of Botswana','BWA','072','yes','267','.bw'),(31,'BV','Bouvet Island','Bouvet Island','BVT','074','no','NONE','.bv'),(32,'BR','Brazil','Federative Republic of Brazil','BRA','076','yes','55','.br'),(33,'IO','British Indian Ocean Territory','British Indian Ocean Territory','IOT','086','no','246','.io'),(34,'BN','Brunei','Brunei Darussalam','BRN','096','yes','673','.bn'),(35,'BG','Bulgaria','Republic of Bulgaria','BGR','100','yes','359','.bg'),(36,'BF','Burkina Faso','Burkina Faso','BFA','854','yes','226','.bf'),(37,'BI','Burundi','Republic of Burundi','BDI','108','yes','257','.bi'),(38,'KH','Cambodia','Kingdom of Cambodia','KHM','116','yes','855','.kh'),(39,'CM','Cameroon','Republic of Cameroon','CMR','120','yes','237','.cm'),(40,'CA','Canada','Canada','CAN','124','yes','1','.ca'),(41,'CV','Cape Verde','Republic of Cape Verde','CPV','132','yes','238','.cv'),(42,'KY','Cayman Islands','The Cayman Islands','CYM','136','no','1+345','.ky'),(43,'CF','Central African Republic','Central African Republic','CAF','140','yes','236','.cf'),(44,'TD','Chad','Republic of Chad','TCD','148','yes','235','.td'),(45,'CL','Chile','Republic of Chile','CHL','152','yes','56','.cl'),(46,'CN','China','People\'s Republic of China','CHN','156','yes','86','.cn'),(47,'CX','Christmas Island','Christmas Island','CXR','162','no','61','.cx'),(48,'CC','Cocos (Keeling) Islands','Cocos (Keeling) Islands','CCK','166','no','61','.cc'),(49,'CO','Colombia','Republic of Colombia','COL','170','yes','57','.co'),(50,'KM','Comoros','Union of the Comoros','COM','174','yes','269','.km'),(51,'CG','Congo','Republic of the Congo','COG','178','yes','242','.cg'),(52,'CK','Cook Islands','Cook Islands','COK','184','some','682','.ck'),(53,'CR','Costa Rica','Republic of Costa Rica','CRI','188','yes','506','.cr'),(54,'CI','Cote d\'ivoire (Ivory Coast)','Republic of C&ocirc;te D\'Ivoire (Ivory Coast)','CIV','384','yes','225','.ci'),(55,'HR','Croatia','Republic of Croatia','HRV','191','yes','385','.hr'),(56,'CU','Cuba','Republic of Cuba','CUB','192','yes','53','.cu'),(57,'CW','Curacao','Cura&ccedil;ao','CUW','531','no','599','.cw'),(58,'CY','Cyprus','Republic of Cyprus','CYP','196','yes','357','.cy'),(59,'CZ','Czech Republic','Czech Republic','CZE','203','yes','420','.cz'),(60,'CD','Democratic Republic of the Congo','Democratic Republic of the Congo','COD','180','yes','243','.cd'),(61,'DK','Denmark','Kingdom of Denmark','DNK','208','yes','45','.dk'),(62,'DJ','Djibouti','Republic of Djibouti','DJI','262','yes','253','.dj'),(63,'DM','Dominica','Commonwealth of Dominica','DMA','212','yes','1+767','.dm'),(64,'DO','Dominican Republic','Dominican Republic','DOM','214','yes','1+809, 8','.do'),(65,'EC','Ecuador','Republic of Ecuador','ECU','218','yes','593','.ec'),(66,'EG','Egypt','Arab Republic of Egypt','EGY','818','yes','20','.eg'),(67,'SV','El Salvador','Republic of El Salvador','SLV','222','yes','503','.sv'),(68,'GQ','Equatorial Guinea','Republic of Equatorial Guinea','GNQ','226','yes','240','.gq'),(69,'ER','Eritrea','State of Eritrea','ERI','232','yes','291','.er'),(70,'EE','Estonia','Republic of Estonia','EST','233','yes','372','.ee'),(71,'ET','Ethiopia','Federal Democratic Republic of Ethiopia','ETH','231','yes','251','.et'),(72,'FK','Falkland Islands (Malvinas)','The Falkland Islands (Malvinas)','FLK','238','no','500','.fk'),(73,'FO','Faroe Islands','The Faroe Islands','FRO','234','no','298','.fo'),(74,'FJ','Fiji','Republic of Fiji','FJI','242','yes','679','.fj'),(75,'FI','Finland','Republic of Finland','FIN','246','yes','358','.fi'),(76,'FR','France','French Republic','FRA','250','yes','33','.fr'),(77,'GF','French Guiana','French Guiana','GUF','254','no','594','.gf'),(78,'PF','French Polynesia','French Polynesia','PYF','258','no','689','.pf'),(79,'TF','French Southern Territories','French Southern Territories','ATF','260','no',NULL,'.tf'),(80,'GA','Gabon','Gabonese Republic','GAB','266','yes','241','.ga'),(81,'GM','Gambia','Republic of The Gambia','GMB','270','yes','220','.gm'),(82,'GE','Georgia','Georgia','GEO','268','yes','995','.ge'),(83,'DE','Germany','Federal Republic of Germany','DEU','276','yes','49','.de'),(84,'GH','Ghana','Republic of Ghana','GHA','288','yes','233','.gh'),(85,'GI','Gibraltar','Gibraltar','GIB','292','no','350','.gi'),(86,'GR','Greece','Hellenic Republic','GRC','300','yes','30','.gr'),(87,'GL','Greenland','Greenland','GRL','304','no','299','.gl'),(88,'GD','Grenada','Grenada','GRD','308','yes','1+473','.gd'),(89,'GP','Guadaloupe','Guadeloupe','GLP','312','no','590','.gp'),(90,'GU','Guam','Guam','GUM','316','no','1+671','.gu'),(91,'GT','Guatemala','Republic of Guatemala','GTM','320','yes','502','.gt'),(92,'GG','Guernsey','Guernsey','GGY','831','no','44','.gg'),(93,'GN','Guinea','Republic of Guinea','GIN','324','yes','224','.gn'),(94,'GW','Guinea-Bissau','Republic of Guinea-Bissau','GNB','624','yes','245','.gw'),(95,'GY','Guyana','Co-operative Republic of Guyana','GUY','328','yes','592','.gy'),(96,'HT','Haiti','Republic of Haiti','HTI','332','yes','509','.ht'),(97,'HM','Heard Island and McDonald Islands','Heard Island and McDonald Islands','HMD','334','no','NONE','.hm'),(98,'HN','Honduras','Republic of Honduras','HND','340','yes','504','.hn'),(99,'HK','Hong Kong','Hong Kong','HKG','344','no','852','.hk'),(100,'HU','Hungary','Hungary','HUN','348','yes','36','.hu'),(101,'IS','Iceland','Republic of Iceland','ISL','352','yes','354','.is'),(102,'IN','India','Republic of India','IND','356','yes','91','.in'),(103,'ID','Indonesia','Republic of Indonesia','IDN','360','yes','62','.id'),(104,'IR','Iran','Islamic Republic of Iran','IRN','364','yes','98','.ir'),(105,'IQ','Iraq','Republic of Iraq','IRQ','368','yes','964','.iq'),(106,'IE','Ireland','Ireland','IRL','372','yes','353','.ie'),(107,'IM','Isle of Man','Isle of Man','IMN','833','no','44','.im'),(108,'IL','Israel','State of Israel','ISR','376','yes','972','.il'),(109,'IT','Italy','Italian Republic','ITA','380','yes','39','.jm'),(110,'JM','Jamaica','Jamaica','JAM','388','yes','1+876','.jm'),(111,'JP','Japan','Japan','JPN','392','yes','81','.jp'),(112,'JE','Jersey','The Bailiwick of Jersey','JEY','832','no','44','.je'),(113,'JO','Jordan','Hashemite Kingdom of Jordan','JOR','400','yes','962','.jo'),(114,'KZ','Kazakhstan','Republic of Kazakhstan','KAZ','398','yes','7','.kz'),(115,'KE','Kenya','Republic of Kenya','KEN','404','yes','254','.ke'),(116,'KI','Kiribati','Republic of Kiribati','KIR','296','yes','686','.ki'),(117,'XK','Kosovo','Republic of Kosovo','---','---','some','381',''),(118,'KW','Kuwait','State of Kuwait','KWT','414','yes','965','.kw'),(119,'KG','Kyrgyzstan','Kyrgyz Republic','KGZ','417','yes','996','.kg'),(120,'LA','Laos','Lao People\'s Democratic Republic','LAO','418','yes','856','.la'),(121,'LV','Latvia','Republic of Latvia','LVA','428','yes','371','.lv'),(122,'LB','Lebanon','Republic of Lebanon','LBN','422','yes','961','.lb'),(123,'LS','Lesotho','Kingdom of Lesotho','LSO','426','yes','266','.ls'),(124,'LR','Liberia','Republic of Liberia','LBR','430','yes','231','.lr'),(125,'LY','Libya','Libya','LBY','434','yes','218','.ly'),(126,'LI','Liechtenstein','Principality of Liechtenstein','LIE','438','yes','423','.li'),(127,'LT','Lithuania','Republic of Lithuania','LTU','440','yes','370','.lt'),(128,'LU','Luxembourg','Grand Duchy of Luxembourg','LUX','442','yes','352','.lu'),(129,'MO','Macao','The Macao Special Administrative Region','MAC','446','no','853','.mo'),(130,'MK','North Macedonia','Republic of North Macedonia','MKD','807','yes','389','.mk'),(131,'MG','Madagascar','Republic of Madagascar','MDG','450','yes','261','.mg'),(132,'MW','Malawi','Republic of Malawi','MWI','454','yes','265','.mw'),(133,'MY','Malaysia','Malaysia','MYS','458','yes','60','.my'),(134,'MV','Maldives','Republic of Maldives','MDV','462','yes','960','.mv'),(135,'ML','Mali','Republic of Mali','MLI','466','yes','223','.ml'),(136,'MT','Malta','Republic of Malta','MLT','470','yes','356','.mt'),(137,'MH','Marshall Islands','Republic of the Marshall Islands','MHL','584','yes','692','.mh'),(138,'MQ','Martinique','Martinique','MTQ','474','no','596','.mq'),(139,'MR','Mauritania','Islamic Republic of Mauritania','MRT','478','yes','222','.mr'),(140,'MU','Mauritius','Republic of Mauritius','MUS','480','yes','230','.mu'),(141,'YT','Mayotte','Mayotte','MYT','175','no','262','.yt'),(142,'MX','Mexico','United Mexican States','MEX','484','yes','52','.mx'),(143,'FM','Micronesia','Federated States of Micronesia','FSM','583','yes','691','.fm'),(144,'MD','Moldava','Republic of Moldova','MDA','498','yes','373','.md'),(145,'MC','Monaco','Principality of Monaco','MCO','492','yes','377','.mc'),(146,'MN','Mongolia','Mongolia','MNG','496','yes','976','.mn'),(147,'ME','Montenegro','Montenegro','MNE','499','yes','382','.me'),(148,'MS','Montserrat','Montserrat','MSR','500','no','1+664','.ms'),(149,'MA','Morocco','Kingdom of Morocco','MAR','504','yes','212','.ma'),(150,'MZ','Mozambique','Republic of Mozambique','MOZ','508','yes','258','.mz'),(151,'MM','Myanmar (Burma)','Republic of the Union of Myanmar','MMR','104','yes','95','.mm'),(152,'NA','Namibia','Republic of Namibia','NAM','516','yes','264','.na'),(153,'NR','Nauru','Republic of Nauru','NRU','520','yes','674','.nr'),(154,'NP','Nepal','Federal Democratic Republic of Nepal','NPL','524','yes','977','.np'),(155,'NL','Netherlands','Kingdom of the Netherlands','NLD','528','yes','31','.nl'),(156,'NC','New Caledonia','New Caledonia','NCL','540','no','687','.nc'),(157,'NZ','New Zealand','New Zealand','NZL','554','yes','64','.nz'),(158,'NI','Nicaragua','Republic of Nicaragua','NIC','558','yes','505','.ni'),(159,'NE','Niger','Republic of Niger','NER','562','yes','227','.ne'),(160,'NG','Nigeria','Federal Republic of Nigeria','NGA','566','yes','234','.ng'),(161,'NU','Niue','Niue','NIU','570','some','683','.nu'),(162,'NF','Norfolk Island','Norfolk Island','NFK','574','no','672','.nf'),(163,'KP','North Korea','Democratic People\'s Republic of Korea','PRK','408','yes','850','.kp'),(164,'MP','Northern Mariana Islands','Northern Mariana Islands','MNP','580','no','1+670','.mp'),(165,'NO','Norway','Kingdom of Norway','NOR','578','yes','47','.no'),(166,'OM','Oman','Sultanate of Oman','OMN','512','yes','968','.om'),(167,'PK','Pakistan','Islamic Republic of Pakistan','PAK','586','yes','92','.pk'),(168,'PW','Palau','Republic of Palau','PLW','585','yes','680','.pw'),(169,'PS','Palestine','State of Palestine (or Occupied Palestinian Territory)','PSE','275','some','970','.ps'),(170,'PA','Panama','Republic of Panama','PAN','591','yes','507','.pa'),(171,'PG','Papua New Guinea','Independent State of Papua New Guinea','PNG','598','yes','675','.pg'),(172,'PY','Paraguay','Republic of Paraguay','PRY','600','yes','595','.py'),(173,'PE','Peru','Republic of Peru','PER','604','yes','51','.pe'),(174,'PH','Philippines','Republic of the Philippines','PHL','608','yes','63','.ph'),(175,'PN','Pitcairn','Pitcairn','PCN','612','no','NONE','.pn'),(176,'PL','Poland','Republic of Poland','POL','616','yes','48','.pl'),(177,'PT','Portugal','Portuguese Republic','PRT','620','yes','351','.pt'),(178,'PR','Puerto Rico','Commonwealth of Puerto Rico','PRI','630','no','1+939','.pr'),(179,'QA','Qatar','State of Qatar','QAT','634','yes','974','.qa'),(180,'RE','Reunion','R&eacute;union','REU','638','no','262','.re'),(181,'RO','Romania','Romania','ROU','642','yes','40','.ro'),(182,'RU','Russia','Russian Federation','RUS','643','yes','7','.ru'),(183,'RW','Rwanda','Republic of Rwanda','RWA','646','yes','250','.rw'),(184,'BL','Saint Barthelemy','Saint Barth&eacute;lemy','BLM','652','no','590','.bl'),(185,'SH','Saint Helena','Saint Helena, Ascension and Tristan da Cunha','SHN','654','no','290','.sh'),(186,'KN','Saint Kitts and Nevis','Federation of Saint Christopher and Nevis','KNA','659','yes','1+869','.kn'),(187,'LC','Saint Lucia','Saint Lucia','LCA','662','yes','1+758','.lc'),(188,'MF','Saint Martin','Saint Martin','MAF','663','no','590','.mf'),(189,'PM','Saint Pierre and Miquelon','Saint Pierre and Miquelon','SPM','666','no','508','.pm'),(190,'VC','Saint Vincent and the Grenadines','Saint Vincent and the Grenadines','VCT','670','yes','1+784','.vc'),(191,'WS','Samoa','Independent State of Samoa','WSM','882','yes','685','.ws'),(192,'SM','San Marino','Republic of San Marino','SMR','674','yes','378','.sm'),(193,'ST','Sao Tome and Principe','Democratic Republic of S&atilde;o Tom&eacute; and Pr&iacute;ncipe','STP','678','yes','239','.st'),(194,'SA','Saudi Arabia','Kingdom of Saudi Arabia','SAU','682','yes','966','.sa'),(195,'SN','Senegal','Republic of Senegal','SEN','686','yes','221','.sn'),(196,'RS','Serbia','Republic of Serbia','SRB','688','yes','381','.rs'),(197,'SC','Seychelles','Republic of Seychelles','SYC','690','yes','248','.sc'),(198,'SL','Sierra Leone','Republic of Sierra Leone','SLE','694','yes','232','.sl'),(199,'SG','Singapore','Republic of Singapore','SGP','702','yes','65','.sg'),(200,'SX','Sint Maarten','Sint Maarten','SXM','534','no','1+721','.sx'),(201,'SK','Slovakia','Slovak Republic','SVK','703','yes','421','.sk'),(202,'SI','Slovenia','Republic of Slovenia','SVN','705','yes','386','.si'),(203,'SB','Solomon Islands','Solomon Islands','SLB','090','yes','677','.sb'),(204,'SO','Somalia','Somali Republic','SOM','706','yes','252','.so'),(205,'ZA','South Africa','Republic of South Africa','ZAF','710','yes','27','.za'),(206,'GS','South Georgia and the South Sandwich Islands','South Georgia and the South Sandwich Islands','SGS','239','no','500','.gs'),(207,'KR','South Korea','Republic of Korea','KOR','410','yes','82','.kr'),(208,'SS','South Sudan','Republic of South Sudan','SSD','728','yes','211','.ss'),(209,'ES','Spain','Kingdom of Spain','ESP','724','yes','34','.es'),(210,'LK','Sri Lanka','Democratic Socialist Republic of Sri Lanka','LKA','144','yes','94','.lk'),(211,'SD','Sudan','Republic of the Sudan','SDN','729','yes','249','.sd'),(212,'SR','Suriname','Republic of Suriname','SUR','740','yes','597','.sr'),(213,'SJ','Svalbard and Jan Mayen','Svalbard and Jan Mayen','SJM','744','no','47','.sj'),(214,'SZ','Swaziland','Kingdom of Swaziland','SWZ','748','yes','268','.sz'),(215,'SE','Sweden','Kingdom of Sweden','SWE','752','yes','46','.se'),(216,'CH','Switzerland','Swiss Confederation','CHE','756','yes','41','.ch'),(217,'SY','Syria','Syrian Arab Republic','SYR','760','yes','963','.sy'),(218,'TW','Taiwan','Republic of China (Taiwan)','TWN','158','former','886','.tw'),(219,'TJ','Tajikistan','Republic of Tajikistan','TJK','762','yes','992','.tj'),(220,'TZ','Tanzania','United Republic of Tanzania','TZA','834','yes','255','.tz'),(221,'TH','Thailand','Kingdom of Thailand','THA','764','yes','66','.th'),(222,'TL','Timor-Leste (East Timor)','Democratic Republic of Timor-Leste','TLS','626','yes','670','.tl'),(223,'TG','Togo','Togolese Republic','TGO','768','yes','228','.tg'),(224,'TK','Tokelau','Tokelau','TKL','772','no','690','.tk'),(225,'TO','Tonga','Kingdom of Tonga','TON','776','yes','676','.to'),(226,'TT','Trinidad and Tobago','Republic of Trinidad and Tobago','TTO','780','yes','1+868','.tt'),(227,'TN','Tunisia','Republic of Tunisia','TUN','788','yes','216','.tn'),(228,'TR','Turkey','Republic of Turkey','TUR','792','yes','90','.tr'),(229,'TM','Turkmenistan','Turkmenistan','TKM','795','yes','993','.tm'),(230,'TC','Turks and Caicos Islands','Turks and Caicos Islands','TCA','796','no','1+649','.tc'),(231,'TV','Tuvalu','Tuvalu','TUV','798','yes','688','.tv'),(232,'UG','Uganda','Republic of Uganda','UGA','800','yes','256','.ug'),(233,'UA','Ukraine','Ukraine','UKR','804','yes','380','.ua'),(234,'AE','United Arab Emirates','United Arab Emirates','ARE','784','yes','971','.ae'),(235,'GB','United Kingdom','United Kingdom of Great Britain and Nothern Ireland','GBR','826','yes','44','.uk'),(236,'US','United States','United States of America','USA','840','yes','1','.us'),(237,'UM','United States Minor Outlying Islands','United States Minor Outlying Islands','UMI','581','no','NONE','NONE'),(238,'UY','Uruguay','Eastern Republic of Uruguay','URY','858','yes','598','.uy'),(239,'UZ','Uzbekistan','Republic of Uzbekistan','UZB','860','yes','998','.uz'),(240,'VU','Vanuatu','Republic of Vanuatu','VUT','548','yes','678','.vu'),(241,'VA','Vatican City','State of the Vatican City','VAT','336','no','39','.va'),(242,'VE','Venezuela','Bolivarian Republic of Venezuela','VEN','862','yes','58','.ve'),(243,'VN','Vietnam','Socialist Republic of Vietnam','VNM','704','yes','84','.vn'),(244,'VG','Virgin Islands, British','British Virgin Islands','VGB','092','no','1+284','.vg'),(245,'VI','Virgin Islands, US','Virgin Islands of the United States','VIR','850','no','1+340','.vi'),(246,'WF','Wallis and Futuna','Wallis and Futuna','WLF','876','no','681','.wf'),(247,'EH','Western Sahara','Western Sahara','ESH','732','no','212','.eh'),(248,'YE','Yemen','Republic of Yemen','YEM','887','yes','967','.ye'),(249,'ZM','Zambia','Republic of Zambia','ZMB','894','yes','260','.zm'),(250,'ZW','Zimbabwe','Republic of Zimbabwe','ZWE','716','yes','263','.zw');
/*!40000 ALTER TABLE `maxlife_tblcountries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblcreditnote_refunds`
--

DROP TABLE IF EXISTS `maxlife_tblcreditnote_refunds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblcreditnote_refunds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `credit_note_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `refunded_on` date NOT NULL,
  `payment_mode` varchar(40) NOT NULL,
  `note` mediumtext DEFAULT NULL,
  `amount` decimal(15,2) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblcreditnote_refunds`
--

LOCK TABLES `maxlife_tblcreditnote_refunds` WRITE;
/*!40000 ALTER TABLE `maxlife_tblcreditnote_refunds` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblcreditnote_refunds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblcreditnotes`
--

DROP TABLE IF EXISTS `maxlife_tblcreditnotes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblcreditnotes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clientid` int(11) NOT NULL,
  `deleted_customer_name` varchar(100) DEFAULT NULL,
  `number` int(11) NOT NULL,
  `prefix` varchar(50) DEFAULT NULL,
  `number_format` int(11) NOT NULL DEFAULT 1,
  `datecreated` datetime NOT NULL,
  `date` date NOT NULL,
  `adminnote` mediumtext DEFAULT NULL,
  `terms` mediumtext DEFAULT NULL,
  `clientnote` mediumtext DEFAULT NULL,
  `currency` int(11) NOT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `total_tax` decimal(15,2) NOT NULL DEFAULT 0.00,
  `total` decimal(15,2) NOT NULL,
  `adjustment` decimal(15,2) DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `project_id` int(11) NOT NULL DEFAULT 0,
  `discount_percent` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `discount_type` varchar(30) NOT NULL,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT NULL,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT NULL,
  `include_shipping` tinyint(1) NOT NULL,
  `show_shipping_on_credit_note` tinyint(1) NOT NULL DEFAULT 1,
  `show_quantity_as` int(11) NOT NULL DEFAULT 1,
  `reference_no` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `currency` (`currency`),
  KEY `clientid` (`clientid`),
  KEY `project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblcreditnotes`
--

LOCK TABLES `maxlife_tblcreditnotes` WRITE;
/*!40000 ALTER TABLE `maxlife_tblcreditnotes` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblcreditnotes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblcredits`
--

DROP TABLE IF EXISTS `maxlife_tblcredits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblcredits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) NOT NULL,
  `credit_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `date_applied` datetime NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblcredits`
--

LOCK TABLES `maxlife_tblcredits` WRITE;
/*!40000 ALTER TABLE `maxlife_tblcredits` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblcredits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblcurrencies`
--

DROP TABLE IF EXISTS `maxlife_tblcurrencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblcurrencies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `decimal_separator` varchar(5) DEFAULT NULL,
  `thousand_separator` varchar(5) DEFAULT NULL,
  `placement` varchar(10) DEFAULT NULL,
  `isdefault` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblcurrencies`
--

LOCK TABLES `maxlife_tblcurrencies` WRITE;
/*!40000 ALTER TABLE `maxlife_tblcurrencies` DISABLE KEYS */;
INSERT INTO `maxlife_tblcurrencies` VALUES (1,'$','USD','.',',','before',0),(3,'?','INR','.',',','before',1);
/*!40000 ALTER TABLE `maxlife_tblcurrencies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblcurrency_rate_logs`
--

DROP TABLE IF EXISTS `maxlife_tblcurrency_rate_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblcurrency_rate_logs` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `from_currency_id` int(11) DEFAULT NULL,
  `from_currency_name` varchar(100) DEFAULT NULL,
  `from_currency_rate` decimal(15,6) NOT NULL DEFAULT 0.000000,
  `to_currency_id` int(11) DEFAULT NULL,
  `to_currency_name` varchar(100) DEFAULT NULL,
  `to_currency_rate` decimal(15,6) NOT NULL DEFAULT 0.000000,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblcurrency_rate_logs`
--

LOCK TABLES `maxlife_tblcurrency_rate_logs` WRITE;
/*!40000 ALTER TABLE `maxlife_tblcurrency_rate_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblcurrency_rate_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblcurrency_rates`
--

DROP TABLE IF EXISTS `maxlife_tblcurrency_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblcurrency_rates` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `from_currency_id` int(11) DEFAULT NULL,
  `from_currency_name` varchar(100) DEFAULT NULL,
  `from_currency_rate` decimal(15,6) NOT NULL DEFAULT 0.000000,
  `to_currency_id` int(11) DEFAULT NULL,
  `to_currency_name` varchar(100) DEFAULT NULL,
  `to_currency_rate` decimal(15,6) NOT NULL DEFAULT 0.000000,
  `date_updated` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblcurrency_rates`
--

LOCK TABLES `maxlife_tblcurrency_rates` WRITE;
/*!40000 ALTER TABLE `maxlife_tblcurrency_rates` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblcurrency_rates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblcustomer_admins`
--

DROP TABLE IF EXISTS `maxlife_tblcustomer_admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblcustomer_admins` (
  `staff_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `date_assigned` mediumtext NOT NULL,
  KEY `customer_id` (`customer_id`),
  KEY `maxlife_staff_id` (`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblcustomer_admins`
--

LOCK TABLES `maxlife_tblcustomer_admins` WRITE;
/*!40000 ALTER TABLE `maxlife_tblcustomer_admins` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblcustomer_admins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblcustomer_groups`
--

DROP TABLE IF EXISTS `maxlife_tblcustomer_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblcustomer_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupid` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `groupid` (`groupid`),
  KEY `customer_id` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblcustomer_groups`
--

LOCK TABLES `maxlife_tblcustomer_groups` WRITE;
/*!40000 ALTER TABLE `maxlife_tblcustomer_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblcustomer_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblcustomers_groups`
--

DROP TABLE IF EXISTS `maxlife_tblcustomers_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblcustomers_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblcustomers_groups`
--

LOCK TABLES `maxlife_tblcustomers_groups` WRITE;
/*!40000 ALTER TABLE `maxlife_tblcustomers_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblcustomers_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblcustomfields`
--

DROP TABLE IF EXISTS `maxlife_tblcustomfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblcustomfields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldto` varchar(30) DEFAULT NULL,
  `name` varchar(150) NOT NULL,
  `slug` varchar(150) NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT 0,
  `type` varchar(20) NOT NULL,
  `options` longtext DEFAULT NULL,
  `display_inline` tinyint(1) NOT NULL DEFAULT 0,
  `field_order` int(11) DEFAULT 0,
  `active` int(11) NOT NULL DEFAULT 1,
  `show_on_pdf` int(11) NOT NULL DEFAULT 0,
  `show_on_ticket_form` tinyint(1) NOT NULL DEFAULT 0,
  `only_admin` tinyint(1) NOT NULL DEFAULT 0,
  `show_on_table` tinyint(1) NOT NULL DEFAULT 0,
  `show_on_client_portal` int(11) NOT NULL DEFAULT 0,
  `disalow_client_to_edit` int(11) NOT NULL DEFAULT 0,
  `bs_column` int(11) NOT NULL DEFAULT 12,
  `default_value` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblcustomfields`
--

LOCK TABLES `maxlife_tblcustomfields` WRITE;
/*!40000 ALTER TABLE `maxlife_tblcustomfields` DISABLE KEYS */;
INSERT INTO `maxlife_tblcustomfields` VALUES (1,'tasks','Estimate hour','tasks_estimate_hour',0,'number','',0,0,1,0,0,0,0,0,0,12,NULL);
/*!40000 ALTER TABLE `maxlife_tblcustomfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblcustomfieldsvalues`
--

DROP TABLE IF EXISTS `maxlife_tblcustomfieldsvalues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblcustomfieldsvalues` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `relid` int(11) NOT NULL,
  `fieldid` int(11) NOT NULL,
  `fieldto` varchar(15) NOT NULL,
  `value` mediumtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `relid` (`relid`),
  KEY `fieldto` (`fieldto`),
  KEY `fieldid` (`fieldid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblcustomfieldsvalues`
--

LOCK TABLES `maxlife_tblcustomfieldsvalues` WRITE;
/*!40000 ALTER TABLE `maxlife_tblcustomfieldsvalues` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblcustomfieldsvalues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblday_off`
--

DROP TABLE IF EXISTS `maxlife_tblday_off`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblday_off` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `off_reason` varchar(255) NOT NULL,
  `off_type` varchar(100) NOT NULL,
  `break_date` date NOT NULL,
  `timekeeping` varchar(45) DEFAULT NULL,
  `department` varchar(45) DEFAULT NULL,
  `position` varchar(45) DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  `repeat_by_year` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblday_off`
--

LOCK TABLES `maxlife_tblday_off` WRITE;
/*!40000 ALTER TABLE `maxlife_tblday_off` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblday_off` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tbldepartments`
--

DROP TABLE IF EXISTS `maxlife_tbldepartments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tbldepartments` (
  `departmentid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `imap_username` varchar(191) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `email_from_header` tinyint(1) NOT NULL DEFAULT 0,
  `host` varchar(150) DEFAULT NULL,
  `password` longtext DEFAULT NULL,
  `encryption` varchar(3) DEFAULT NULL,
  `folder` varchar(191) NOT NULL DEFAULT 'INBOX',
  `delete_after_import` int(11) NOT NULL DEFAULT 0,
  `calendar_id` longtext DEFAULT NULL,
  `hidefromclient` tinyint(1) NOT NULL DEFAULT 0,
  `manager_id` int(11) DEFAULT 0,
  `parent_id` int(11) DEFAULT 0,
  PRIMARY KEY (`departmentid`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tbldepartments`
--

LOCK TABLES `maxlife_tbldepartments` WRITE;
/*!40000 ALTER TABLE `maxlife_tbldepartments` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tbldepartments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tbldismissed_announcements`
--

DROP TABLE IF EXISTS `maxlife_tbldismissed_announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tbldismissed_announcements` (
  `dismissedannouncementid` int(11) NOT NULL AUTO_INCREMENT,
  `announcementid` int(11) NOT NULL,
  `staff` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  PRIMARY KEY (`dismissedannouncementid`),
  KEY `announcementid` (`announcementid`),
  KEY `maxlife_staff` (`staff`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tbldismissed_announcements`
--

LOCK TABLES `maxlife_tbldismissed_announcements` WRITE;
/*!40000 ALTER TABLE `maxlife_tbldismissed_announcements` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tbldismissed_announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblemaillists`
--

DROP TABLE IF EXISTS `maxlife_tblemaillists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblemaillists` (
  `listid` int(11) NOT NULL AUTO_INCREMENT,
  `name` mediumtext NOT NULL,
  `creator` varchar(100) NOT NULL,
  `datecreated` datetime NOT NULL,
  PRIMARY KEY (`listid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblemaillists`
--

LOCK TABLES `maxlife_tblemaillists` WRITE;
/*!40000 ALTER TABLE `maxlife_tblemaillists` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblemaillists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblemailtemplates`
--

DROP TABLE IF EXISTS `maxlife_tblemailtemplates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblemailtemplates` (
  `emailtemplateid` int(11) NOT NULL AUTO_INCREMENT,
  `type` longtext NOT NULL,
  `slug` varchar(100) NOT NULL,
  `language` varchar(40) DEFAULT NULL,
  `name` longtext NOT NULL,
  `subject` longtext NOT NULL,
  `message` longtext NOT NULL,
  `fromname` longtext NOT NULL,
  `fromemail` varchar(100) DEFAULT NULL,
  `plaintext` int(11) NOT NULL DEFAULT 0,
  `active` tinyint(4) NOT NULL DEFAULT 0,
  `order` int(11) NOT NULL,
  PRIMARY KEY (`emailtemplateid`)
) ENGINE=InnoDB AUTO_INCREMENT=136 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblemailtemplates`
--

LOCK TABLES `maxlife_tblemailtemplates` WRITE;
/*!40000 ALTER TABLE `maxlife_tblemailtemplates` DISABLE KEYS */;
INSERT INTO `maxlife_tblemailtemplates` VALUES (1,'client','new-client-created','english','New Contact Added/Registered (Welcome Email)','Welcome aboard','Dear {contact_firstname} {contact_lastname}<br /><br />Thank you for registering on the <strong>{companyname}</strong> CRM System.<br /><br />We just wanted to say welcome.<br /><br />Please contact us if you need any help.<br /><br />Click here to view your profile: <a href=\"{crm_url}\">{crm_url}</a><br /><br />Kind Regards, <br />{email_signature}<br /><br />(This is an automated email, so please don\'t reply to this email address)','{companyname} | CRM','',0,1,0),(2,'invoice','invoice-send-to-client','english','Send Invoice to Customer','Invoice with number {invoice_number} created','<span style=\"font-size: 12pt;\">Dear {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">We have prepared the following invoice for you: <strong># {invoice_number}</strong></span><br /><br /><span style=\"font-size: 12pt;\"><strong>Invoice status</strong>: {invoice_status}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the invoice on the following link: <a href=\"{invoice_link}\">{invoice_number}</a></span><br /><br /><span style=\"font-size: 12pt;\">Please contact us for more information.</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(3,'ticket','new-ticket-opened-admin','english','New Ticket Opened (Opened by Staff, Sent to Customer)','New Support Ticket Opened','<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">New support ticket has been opened.</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject:</strong> {ticket_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Department:</strong> {ticket_department}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority:</strong> {ticket_priority}<br /></span><br /><span style=\"font-size: 12pt;\"><strong>Ticket message:</strong></span><br /><span style=\"font-size: 12pt;\">{ticket_message}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_public_url}\">#{ticket_id}</a><br /><br />Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(4,'ticket','ticket-reply','english','Ticket Reply (Sent to Customer)','New Ticket Reply','<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">You have a new ticket reply to ticket <a href=\"{ticket_public_url}\">#{ticket_id}</a></span><br /><br /><span style=\"font-size: 12pt;\"><strong>Ticket Subject:</strong> {ticket_subject}<br /></span><br /><span style=\"font-size: 12pt;\"><strong>Ticket message:</strong></span><br /><span style=\"font-size: 12pt;\">{ticket_message}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_public_url}\">#{ticket_id}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(5,'ticket','ticket-autoresponse','english','New Ticket Opened - Autoresponse','New Support Ticket Opened','<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">Thank you for contacting our support team. A support ticket has now been opened for your request. You will be notified when a response is made by email.</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject:</strong> {ticket_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Department</strong>: {ticket_department}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority:</strong> {ticket_priority}</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Ticket message:</strong></span><br /><span style=\"font-size: 12pt;\">{ticket_message}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_public_url}\">#{ticket_id}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(6,'invoice','invoice-payment-recorded','english','Invoice Payment Recorded (Sent to Customer)','Invoice Payment Recorded','<span style=\"font-size: 12pt;\">Hello {contact_firstname}&nbsp;{contact_lastname}<br /><br /></span>Thank you for the payment. Find the payment details below:<br /><br />-------------------------------------------------<br /><br />Amount:&nbsp;<strong>{payment_total}<br /></strong>Date:&nbsp;<strong>{payment_date}</strong><br />Invoice number:&nbsp;<span style=\"font-size: 12pt;\"><strong># {invoice_number}<br /><br /></strong></span>-------------------------------------------------<br /><br />You can always view the invoice for this payment at the following link:&nbsp;<a href=\"{invoice_link}\"><span style=\"font-size: 12pt;\">{invoice_number}</span></a><br /><br />We are looking forward working with you.<br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(7,'invoice','invoice-overdue-notice','english','Invoice Overdue Notice','Invoice Overdue Notice - {invoice_number}','<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">This is an overdue notice for invoice <strong># {invoice_number}</strong></span><br /><br /><span style=\"font-size: 12pt;\">This invoice was due: {invoice_duedate}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the invoice on the following link: <a href=\"{invoice_link}\">{invoice_number}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(8,'invoice','invoice-already-send','english','Invoice Already Sent to Customer','Invoice # {invoice_number} ','<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">At your request, here is the invoice with number <strong># {invoice_number}</strong></span><br /><br /><span style=\"font-size: 12pt;\">You can view the invoice on the following link: <a href=\"{invoice_link}\">{invoice_number}</a></span><br /><br /><span style=\"font-size: 12pt;\">Please contact us for more information.</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(9,'ticket','new-ticket-created-staff','english','New Ticket Created (Opened by Customer, Sent to Staff Members)','New Ticket Created','<p><span style=\"font-size: 12pt;\">A new support ticket has been opened.</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject</strong>: {ticket_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Department</strong>: {ticket_department}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority</strong>: {ticket_priority}<br /></span><br /><span style=\"font-size: 12pt;\"><strong>Ticket message:</strong></span><br /><span style=\"font-size: 12pt;\">{ticket_message}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_url}\">#{ticket_id}</a></span><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span></p>','{companyname} | CRM','',0,1,0),(10,'estimate','estimate-send-to-client','english','Send Estimate to Customer','Estimate # {estimate_number} created','<span style=\"font-size: 12pt;\">Dear {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">Please find the attached estimate <strong># {estimate_number}</strong></span><br /><br /><span style=\"font-size: 12pt;\"><strong>Estimate status:</strong> {estimate_status}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the estimate on the following link: <a href=\"{estimate_link}\">{estimate_number}</a></span><br /><br /><span style=\"font-size: 12pt;\">We look forward to your communication.</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}<br /></span>','{companyname} | CRM','',0,1,0),(11,'ticket','ticket-reply-to-admin','english','Ticket Reply (Sent to Staff)','New Support Ticket Reply','<span style=\"font-size: 12pt;\">A new support ticket reply from {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject</strong>: {ticket_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Department</strong>: {ticket_department}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority</strong>: {ticket_priority}</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Ticket message:</strong></span><br /><span style=\"font-size: 12pt;\">{ticket_message}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_url}\">#{ticket_id}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(12,'estimate','estimate-already-send','english','Estimate Already Sent to Customer','Estimate # {estimate_number} ','<span style=\"font-size: 12pt;\">Dear {contact_firstname} {contact_lastname}</span><br /> <br /><span style=\"font-size: 12pt;\">Thank you for your estimate request.</span><br /> <br /><span style=\"font-size: 12pt;\">You can view the estimate on the following link: <a href=\"{estimate_link}\">{estimate_number}</a></span><br /> <br /><span style=\"font-size: 12pt;\">Please contact us for more information.</span><br /> <br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(13,'contract','contract-expiration','english','Contract Expiration Reminder (Sent to Customer Contacts)','Contract Expiration Reminder','<span style=\"font-size: 12pt;\">Dear {client_company}</span><br /><br /><span style=\"font-size: 12pt;\">This is a reminder that the following contract will expire soon:</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject:</strong> {contract_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Description:</strong> {contract_description}</span><br /><span style=\"font-size: 12pt;\"><strong>Date Start:</strong> {contract_datestart}</span><br /><span style=\"font-size: 12pt;\"><strong>Date End:</strong> {contract_dateend}</span><br /><br /><span style=\"font-size: 12pt;\">Please contact us for more information.</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(14,'tasks','task-assigned','english','New Task Assigned (Sent to Staff)','New Task Assigned to You - {task_name}','<span style=\"font-size: 12pt;\">Dear {staff_firstname}</span><br /><br /><span style=\"font-size: 12pt;\">You have been assigned to a new task:</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Name:</strong> {task_name}<br /></span><strong>Start Date:</strong> {task_startdate}<br /><span style=\"font-size: 12pt;\"><strong>Due date:</strong> {task_duedate}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority:</strong> {task_priority}<br /><br /></span><span style=\"font-size: 12pt;\"><span>You can view the task on the following link</span>: <a href=\"{task_link}\">{task_name}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(15,'tasks','task-added-as-follower','english','Staff Member Added as Follower on Task (Sent to Staff)','You are added as follower on task - {task_name}','<span style=\"font-size: 12pt;\">Hi {staff_firstname}<br /></span><br /><span style=\"font-size: 12pt;\">You have been added as follower on the following task:</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Name:</strong> {task_name}</span><br /><span style=\"font-size: 12pt;\"><strong>Start date:</strong> {task_startdate}</span><br /><br /><span>You can view the task on the following link</span><span>: </span><a href=\"{task_link}\">{task_name}</a><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(16,'tasks','task-commented','english','New Comment on Task (Sent to Staff)','New Comment on Task - {task_name}','Dear {staff_firstname}<br /><br />A comment has been made on the following task:<br /><br /><strong>Name:</strong> {task_name}<br /><strong>Comment:</strong> {task_comment}<br /><br />You can view the task on the following link: <a href=\"{task_link}\">{task_name}</a><br /><br />Kind Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),(17,'tasks','task-added-attachment','english','New Attachment(s) on Task (Sent to Staff)','New Attachment on Task - {task_name}','Hi {staff_firstname}<br /><br /><strong>{task_user_take_action}</strong> added an attachment on the following task:<br /><br /><strong>Name:</strong> {task_name}<br /><br />You can view the task on the following link: <a href=\"{task_link}\">{task_name}</a><br /><br />Kind Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),(18,'estimate','estimate-declined-to-staff','english','Estimate Declined (Sent to Staff)','Customer Declined Estimate','<span style=\"font-size: 12pt;\">Hi</span><br /> <br /><span style=\"font-size: 12pt;\">Customer ({client_company}) declined estimate with number <strong># {estimate_number}</strong></span><br /> <br /><span style=\"font-size: 12pt;\">You can view the estimate on the following link: <a href=\"{estimate_link}\">{estimate_number}</a></span><br /> <br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(19,'estimate','estimate-accepted-to-staff','english','Estimate Accepted (Sent to Staff)','Customer Accepted Estimate','<span style=\"font-size: 12pt;\">Hi</span><br /> <br /><span style=\"font-size: 12pt;\">Customer ({client_company}) accepted estimate with number <strong># {estimate_number}</strong></span><br /> <br /><span style=\"font-size: 12pt;\">You can view the estimate on the following link: <a href=\"{estimate_link}\">{estimate_number}</a></span><br /> <br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(20,'proposals','proposal-client-accepted','english','Customer Action - Accepted (Sent to Staff)','Customer Accepted Proposal','<div>Hi<br /> <br />Client <strong>{proposal_proposal_to}</strong> accepted the following proposal:<br /> <br /><strong>Number:</strong> {proposal_number}<br /><strong>Subject</strong>: {proposal_subject}<br /><strong>Total</strong>: {proposal_total}<br /> <br />View the proposal on the following link: <a href=\"{proposal_link}\">{proposal_number}</a><br /> <br />Kind Regards,<br />{email_signature}</div>\r\n<div>&nbsp;</div>\r\n<div>&nbsp;</div>\r\n<div>&nbsp;</div>','{companyname} | CRM','',0,1,0),(21,'proposals','proposal-send-to-customer','english','Send Proposal to Customer','Proposal With Number {proposal_number} Created','Dear {proposal_proposal_to}<br /><br />Please find our attached proposal.<br /><br />This proposal is valid until: {proposal_open_till}<br />You can view the proposal on the following link: <a href=\"{proposal_link}\">{proposal_number}</a><br /><br />Please don\'t hesitate to comment online if you have any questions.<br /><br />We look forward to your communication.<br /><br />Kind Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),(22,'proposals','proposal-client-declined','english','Customer Action - Declined (Sent to Staff)','Client Declined Proposal','Hi<br /> <br />Customer <strong>{proposal_proposal_to}</strong> declined the proposal <strong>{proposal_subject}</strong><br /> <br />View the proposal on the following link <a href=\"{proposal_link}\">{proposal_number}</a>&nbsp;or from the admin area.<br /> <br />Kind Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),(23,'proposals','proposal-client-thank-you','english','Thank You Email (Sent to Customer After Accept)','Thank for you accepting proposal','Dear {proposal_proposal_to}<br /> <br />Thank for for accepting the proposal.<br /> <br />We look forward to doing business with you.<br /> <br />We will contact you as soon as possible<br /> <br />Kind Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),(24,'proposals','proposal-comment-to-client','english','New Comment Â (Sent to Customer/Lead)','New Proposal Comment','Dear {proposal_proposal_to}<br /> <br />A new comment has been made on the following proposal: <strong>{proposal_number}</strong><br /> <br />You can view and reply to the comment on the following link: <a href=\"{proposal_link}\">{proposal_number}</a><br /> <br />Kind Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),(25,'proposals','proposal-comment-to-admin','english','New Comment (Sent to Staff) ','New Proposal Comment','Hi<br /> <br />A new comment has been made to the proposal <strong>{proposal_subject}</strong><br /> <br />You can view and reply to the comment on the following link: <a href=\"{proposal_link}\">{proposal_number}</a>&nbsp;or from the admin area.<br /> <br />{email_signature}','{companyname} | CRM','',0,1,0),(26,'estimate','estimate-thank-you-to-customer','english','Thank You Email (Sent to Customer After Accept)','Thank for you accepting estimate','<span style=\"font-size: 12pt;\">Dear {contact_firstname} {contact_lastname}</span><br /> <br /><span style=\"font-size: 12pt;\">Thank for for accepting the estimate.</span><br /> <br /><span style=\"font-size: 12pt;\">We look forward to doing business with you.</span><br /> <br /><span style=\"font-size: 12pt;\">We will contact you as soon as possible.</span><br /> <br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(27,'tasks','task-deadline-notification','english','Task Deadline Reminder - Sent to Assigned Members','Task Deadline Reminder','Hi {staff_firstname}&nbsp;{staff_lastname}<br /><br />This is an automated email from {companyname}.<br /><br />The task <strong>{task_name}</strong> deadline is on <strong>{task_duedate}</strong>. <br />This task is still not finished.<br /><br />You can view the task on the following link: <a href=\"{task_link}\">{task_name}</a><br /><br />Kind Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),(28,'contract','send-contract','english','Send Contract to Customer','Contract - {contract_subject}','<p><span style=\"font-size: 12pt;\">Hi&nbsp;{contact_firstname}&nbsp;{contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">Please find the <a href=\"{contract_link}\">{contract_subject}</a> attached.<br /><br />Description: {contract_description}<br /><br /></span><span style=\"font-size: 12pt;\">Looking forward to hear from you.</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span></p>','{companyname} | CRM','',0,1,0),(29,'invoice','invoice-payment-recorded-to-staff','english','Invoice Payment Recorded (Sent to Staff)','New Invoice Payment','<span style=\"font-size: 12pt;\">Hi</span><br /><br /><span style=\"font-size: 12pt;\">Customer recorded payment for invoice <strong># {invoice_number}</strong></span><br /> <br /><span style=\"font-size: 12pt;\">You can view the invoice on the following link: <a href=\"{invoice_link}\">{invoice_number}</a></span><br /> <br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(30,'ticket','auto-close-ticket','english','Auto Close Ticket','Ticket Auto Closed','<p><span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">Ticket {ticket_subject} has been auto close due to inactivity.</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Ticket #</strong>: <a href=\"{ticket_public_url}\">{ticket_id}</a></span><br /><span style=\"font-size: 12pt;\"><strong>Department</strong>: {ticket_department}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority:</strong> {ticket_priority}</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span></p>','{companyname} | CRM','',0,1,0),(31,'project','new-project-discussion-created-to-staff','english','New Project Discussion (Sent to Project Members)','New Project Discussion Created - {project_name}','<p>Hi {staff_firstname}<br /><br />New project discussion created from <strong>{discussion_creator}</strong><br /><br /><strong>Subject:</strong> {discussion_subject}<br /><strong>Description:</strong> {discussion_description}<br /><br />You can view the discussion on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a><br /><br />Kind Regards,<br />{email_signature}</p>','{companyname} | CRM','',0,1,0),(32,'project','new-project-discussion-created-to-customer','english','New Project Discussion (Sent to Customer Contacts)','New Project Discussion Created - {project_name}','<p>Hello {contact_firstname} {contact_lastname}<br /><br />New project discussion created from <strong>{discussion_creator}</strong><br /><br /><strong>Subject:</strong> {discussion_subject}<br /><strong>Description:</strong> {discussion_description}<br /><br />You can view the discussion on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a><br /><br />Kind Regards,<br />{email_signature}</p>','{companyname} | CRM','',0,1,0),(33,'project','new-project-file-uploaded-to-customer','english','New Project File(s) Uploaded (Sent to Customer Contacts)','New Project File(s) Uploaded - {project_name}','<p>Hello {contact_firstname} {contact_lastname}<br /><br />New project file is uploaded on <strong>{project_name}</strong> from <strong>{file_creator}</strong><br /><br />You can view the project on the following link: <a href=\"{project_link}\">{project_name}</a><br /><br />To view the file in our CRM you can click on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a><br /><br />Kind Regards,<br />{email_signature}</p>','{companyname} | CRM','',0,1,0),(34,'project','new-project-file-uploaded-to-staff','english','New Project File(s) Uploaded (Sent to Project Members)','New Project File(s) Uploaded - {project_name}','<p>Hello&nbsp;{staff_firstname}</p>\r\n<p>New project&nbsp;file is uploaded on&nbsp;<strong>{project_name}</strong> from&nbsp;<strong>{file_creator}</strong></p>\r\n<p>You can view the project on the following link: <a href=\"{project_link}\">{project_name}<br /></a><br />To view&nbsp;the file you can click on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a></p>\r\n<p>Kind Regards,<br />{email_signature}</p>','{companyname} | CRM','',0,1,0),(35,'project','new-project-discussion-comment-to-customer','english','New Discussion Comment  (Sent to Customer Contacts)','New Discussion Comment','<p><span style=\"font-size: 12pt;\">Hello {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">New discussion comment has been made on <strong>{discussion_subject}</strong> from <strong>{comment_creator}</strong></span><br /><br /><span style=\"font-size: 12pt;\"><strong>Discussion subject:</strong> {discussion_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Comment</strong>: {discussion_comment}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the discussion on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span></p>','{companyname} | CRM','',0,1,0),(36,'project','new-project-discussion-comment-to-staff','english','New Discussion Comment (Sent to Project Members)','New Discussion Comment','<p>Hi {staff_firstname}<br /><br />New discussion comment has been made on <strong>{discussion_subject}</strong> from <strong>{comment_creator}</strong><br /><br /><strong>Discussion subject:</strong> {discussion_subject}<br /><strong>Comment:</strong> {discussion_comment}<br /><br />You can view the discussion on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a><br /><br />Kind Regards,<br />{email_signature}</p>','{companyname} | CRM','',0,1,0),(37,'project','staff-added-as-project-member','english','Staff Added as Project Member','New project assigned to you','<p>Hi {staff_firstname}<br /><br />New project has been assigned to you.<br /><br />You can view the project on the following link <a href=\"{project_link}\">{project_name}</a><br /><br />{email_signature}</p>','{companyname} | CRM','',0,1,0),(38,'estimate','estimate-expiry-reminder','english','Estimate Expiration Reminder','Estimate Expiration Reminder','<p><span style=\"font-size: 12pt;\">Hello {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">The estimate with <strong># {estimate_number}</strong> will expire on <strong>{estimate_expirydate}</strong></span><br /><br /><span style=\"font-size: 12pt;\">You can view the estimate on the following link: <a href=\"{estimate_link}\">{estimate_number}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span></p>','{companyname} | CRM','',0,1,0),(39,'proposals','proposal-expiry-reminder','english','Proposal Expiration Reminder','Proposal Expiration Reminder','<p>Hello {proposal_proposal_to}<br /><br />The proposal {proposal_number}&nbsp;will expire on <strong>{proposal_open_till}</strong><br /><br />You can view the proposal on the following link: <a href=\"{proposal_link}\">{proposal_number}</a><br /><br />Kind Regards,<br />{email_signature}</p>','{companyname} | CRM','',0,1,0),(40,'staff','new-staff-created','english','New Staff Created (Welcome Email)','You are added as staff member','Hi {staff_firstname}<br /><br />You are added as member on our CRM.<br /><br />Please use the following logic credentials:<br /><br /><strong>Email:</strong> {staff_email}<br /><strong>Password:</strong> {password}<br /><br />Click <a href=\"{admin_url}\">here </a>to login in the dashboard.<br /><br />Best Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),(41,'client','contact-forgot-password','english','Forgot Password','Create New Password','<h2>Create a new password</h2>\r\nForgot your password?<br /> To create a new password, just follow this link:<br /> <br /><a href=\"{reset_password_url}\">Reset Password</a><br /> <br /> You received this email, because it was requested by a {companyname}&nbsp;user. This is part of the procedure to create a new password on the system. If you DID NOT request a new password then please ignore this email and your password will remain the same. <br /><br /> {email_signature}','{companyname} | CRM','',0,1,0),(42,'client','contact-password-reseted','english','Password Reset - Confirmation','Your password has been changed','<strong><span style=\"font-size: 14pt;\">You have changed your password.</span><br /></strong><br /> Please, keep it in your records so you don\'t forget it.<br /> <br /> Your email address for login is: {contact_email}<br /><br />If this wasnt you, please contact us.<br /><br />{email_signature}','{companyname} | CRM','',0,1,0),(43,'client','contact-set-password','english','Set New Password','Set new password on {companyname} ','<h2><span style=\"font-size: 14pt;\">Setup your new password on {companyname}</span></h2>\r\nPlease use the following link to set up your new password:<br /><br /><a href=\"{set_password_url}\">Set new password</a><br /><br />Keep it in your records so you don\'t forget it.<br /><br />Please set your new password in <strong>48 hours</strong>. After that, you won\'t be able to set your password because this link will expire.<br /><br />You can login at: <a href=\"{crm_url}\">{crm_url}</a><br />Your email address for login: {contact_email}<br /><br />{email_signature}','{companyname} | CRM','',0,1,0),(44,'staff','staff-forgot-password','english','Forgot Password','Create New Password','<h2><span style=\"font-size: 14pt;\">Create a new password</span></h2>\r\nForgot your password?<br /> To create a new password, just follow this link:<br /> <br /><a href=\"{reset_password_url}\">Reset Password</a><br /> <br /> You received this email, because it was requested by a <strong>{companyname}</strong>&nbsp;user. This is part of the procedure to create a new password on the system. If you DID NOT request a new password then please ignore this email and your password will remain the same. <br /><br /> {email_signature}','{companyname} | CRM','',0,1,0),(45,'staff','staff-password-reseted','english','Password Reset - Confirmation','Your password has been changed','<span style=\"font-size: 14pt;\"><strong>You have changed your password.<br /></strong></span><br /> Please, keep it in your records so you don\'t forget it.<br /> <br /> Your email address for login is: {staff_email}<br /><br /> If this wasnt you, please contact us.<br /><br />{email_signature}','{companyname} | CRM','',0,1,0),(46,'project','assigned-to-project','english','New Project Created (Sent to Customer Contacts)','New Project Created','<p>Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}</p>\r\n<p>New project is assigned to your company.<br /><br /><strong>Project Name:</strong>&nbsp;{project_name}<br /><strong>Project Start Date:</strong>&nbsp;{project_start_date}</p>\r\n<p>You can view the project on the following link:&nbsp;<a href=\"{project_link}\">{project_name}</a></p>\r\n<p>We are looking forward hearing from you.<br /><br />Kind Regards,<br />{email_signature}</p>','{companyname} | CRM','',0,1,0),(47,'tasks','task-added-attachment-to-contacts','english','New Attachment(s) on Task (Sent to Customer Contacts)','New Attachment on Task - {task_name}','<span>Hi {contact_firstname} {contact_lastname}</span><br /><br /><strong>{task_user_take_action}</strong><span> added an attachment on the following task:</span><br /><br /><strong>Name:</strong><span> {task_name}</span><br /><br /><span>You can view the task on the following link: </span><a href=\"{task_link}\">{task_name}</a><br /><br /><span>Kind Regards,</span><br /><span>{email_signature}</span>','{companyname} | CRM','',0,1,0),(48,'tasks','task-commented-to-contacts','english','New Comment on Task (Sent to Customer Contacts)','New Comment on Task - {task_name}','<span>Dear {contact_firstname} {contact_lastname}</span><br /><br /><span>A comment has been made on the following task:</span><br /><br /><strong>Name:</strong><span> {task_name}</span><br /><strong>Comment:</strong><span> {task_comment}</span><br /><br /><span>You can view the task on the following link: </span><a href=\"{task_link}\">{task_name}</a><br /><br /><span>Kind Regards,</span><br /><span>{email_signature}</span>','{companyname} | CRM','',0,1,0),(49,'leads','new-lead-assigned','english','New Lead Assigned to Staff Member','New lead assigned to you','<p>Hello {lead_assigned}<br /><br />New lead is assigned to you.<br /><br /><strong>Lead Name:</strong>&nbsp;{lead_name}<br /><strong>Lead Email:</strong>&nbsp;{lead_email}<br /><br />You can view the lead on the following link: <a href=\"{lead_link}\">{lead_name}</a><br /><br />Kind Regards,<br />{email_signature}</p>','{companyname} | CRM','',0,1,0),(50,'client','client-statement','english','Statement - Account Summary','Account Statement from {statement_from} to {statement_to}','Dear {contact_firstname} {contact_lastname}, <br /><br />Its been a great experience working with you.<br /><br />Attached with this email is a list of all transactions for the period between {statement_from} to {statement_to}<br /><br />For your information your account balance due is total:&nbsp;{statement_balance_due}<br /><br />Please contact us if you need more information.<br /> <br />Kind Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),(51,'ticket','ticket-assigned-to-admin','english','New Ticket Assigned (Sent to Staff)','New support ticket has been assigned to you','<p><span style=\"font-size: 12pt;\">Hi</span></p>\r\n<p><span style=\"font-size: 12pt;\">A new support ticket&nbsp;has been assigned to you.</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject</strong>: {ticket_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Department</strong>: {ticket_department}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority</strong>: {ticket_priority}</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Ticket message:</strong></span><br /><span style=\"font-size: 12pt;\">{ticket_message}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_url}\">#{ticket_id}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span></p>','{companyname} | CRM','',0,1,0),(52,'client','new-client-registered-to-admin','english','New Customer Registration (Sent to admins)','New Customer Registration','Hello.<br /><br />New customer registration on your customer portal:<br /><br /><strong>Firstname:</strong>&nbsp;{contact_firstname}<br /><strong>Lastname:</strong>&nbsp;{contact_lastname}<br /><strong>Company:</strong>&nbsp;{client_company}<br /><strong>Email:</strong>&nbsp;{contact_email}<br /><br />Best Regards','{companyname} | CRM','',0,1,0),(53,'leads','new-web-to-lead-form-submitted','english','Web to lead form submitted - Sent to lead','{lead_name} - We Received Your Request','Hello {lead_name}.<br /><br /><strong>Your request has been received.</strong><br /><br />This email is to let you know that we received your request and we will get back to you as soon as possible with more information.<br /><br />Best Regards,<br />{email_signature}','{companyname} | CRM','',0,0,0),(54,'staff','two-factor-authentication','english','Two Factor Authentication','Confirm Your Login','<p>Hi {staff_firstname}</p>\r\n<p style=\"text-align: left;\">You received this email because you have enabled two factor authentication in your account.<br />Use the following code to confirm your login:</p>\r\n<p style=\"text-align: left;\"><span style=\"font-size: 18pt;\"><strong>{two_factor_auth_code}<br /><br /></strong><span style=\"font-size: 12pt;\">{email_signature}</span><strong><br /><br /><br /><br /></strong></span></p>','{companyname} | CRM','',0,1,0),(55,'project','project-finished-to-customer','english','Project Marked as Finished (Sent to Customer Contacts)','Project Marked as Finished','<p>Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}</p>\r\n<p>You are receiving this email because project&nbsp;<strong>{project_name}</strong> has been marked as finished. This project is assigned under your company and we just wanted to keep you up to date.<br /><br />You can view the project on the following link:&nbsp;<a href=\"{project_link}\">{project_name}</a></p>\r\n<p>If you have any questions don\'t hesitate to contact us.<br /><br />Kind Regards,<br />{email_signature}</p>','{companyname} | CRM','',0,1,0),(56,'credit_note','credit-note-send-to-client','english','Send Credit Note To Email','Credit Note With Number #{credit_note_number} Created','Dear&nbsp;{contact_firstname}&nbsp;{contact_lastname}<br /><br />We have attached the credit note with number <strong>#{credit_note_number} </strong>for your reference.<br /><br /><strong>Date:</strong>&nbsp;{credit_note_date}<br /><strong>Total Amount:</strong>&nbsp;{credit_note_total}<br /><br /><span style=\"font-size: 12pt;\">Please contact us for more information.</span><br /> <br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(57,'tasks','task-status-change-to-staff','english','Task Status Changed (Sent to Staff)','Task Status Changed','<span style=\"font-size: 12pt;\">Hi {staff_firstname}</span><br /><br /><span style=\"font-size: 12pt;\"><strong>{task_user_take_action}</strong> marked task as <strong>{task_status}</strong></span><br /><br /><span style=\"font-size: 12pt;\"><strong>Name:</strong> {task_name}</span><br /><span style=\"font-size: 12pt;\"><strong>Due date:</strong> {task_duedate}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the task on the following link: <a href=\"{task_link}\">{task_name}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(58,'tasks','task-status-change-to-contacts','english','Task Status Changed (Sent to Customer Contacts)','Task Status Changed','<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\"><strong>{task_user_take_action}</strong> marked task as <strong>{task_status}</strong></span><br /><br /><span style=\"font-size: 12pt;\"><strong>Name:</strong> {task_name}</span><br /><span style=\"font-size: 12pt;\"><strong>Due date:</strong> {task_duedate}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the task on the following link: <a href=\"{task_link}\">{task_name}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(59,'staff','reminder-email-staff','english','Staff Reminder Email','You Have a New Reminder!','<p>Hello&nbsp;{staff_firstname}<br /><br /><strong>You have a new reminder&nbsp;linked to&nbsp;{staff_reminder_relation_name}!<br /><br />Reminder description:</strong><br />{staff_reminder_description}<br /><br />Click <a href=\"{staff_reminder_relation_link}\">here</a> to view&nbsp;<a href=\"{staff_reminder_relation_link}\">{staff_reminder_relation_name}</a><br /><br />Best Regards<br /><br /></p>','{companyname} | CRM','',0,1,0),(60,'contract','contract-comment-to-client','english','New Comment Â (Sent to Customer Contacts)','New Contract Comment','Dear {contact_firstname} {contact_lastname}<br /> <br />A new comment has been made on the following contract: <strong>{contract_subject}</strong><br /> <br />You can view and reply to the comment on the following link: <a href=\"{contract_link}\">{contract_subject}</a><br /> <br />Kind Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),(61,'contract','contract-comment-to-admin','english','New Comment (Sent to Staff) ','New Contract Comment','Hi {staff_firstname}<br /><br />A new comment has been made to the contract&nbsp;<strong>{contract_subject}</strong><br /><br />You can view and reply to the comment on the following link: <a href=\"{contract_link}\">{contract_subject}</a>&nbsp;or from the admin area.<br /><br />{email_signature}','{companyname} | CRM','',0,1,0),(62,'subscriptions','send-subscription','english','Send Subscription to Customer','Subscription Created','Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}<br /><br />We have prepared the subscription&nbsp;<strong>{subscription_name}</strong> for your company.<br /><br />Click <a href=\"{subscription_link}\">here</a> to review the subscription and subscribe.<br /><br />Best Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),(63,'subscriptions','subscription-payment-failed','english','Subscription Payment Failed','Your most recent invoice payment failed','Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}<br /><br br=\"\" />Unfortunately, your most recent invoice payment for&nbsp;<strong>{subscription_name}</strong> was declined.<br /><br />This could be due to a change in your card number, your card expiring,<br />cancellation of your credit card, or the card issuer not recognizing the<br />payment and therefore taking action to prevent it.<br /><br />Please update your payment information as soon as possible by logging in here:<br /><a href=\"{crm_url}/login\">{crm_url}/login</a><br /><br />Best Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),(64,'subscriptions','subscription-canceled','english','Subscription Canceled (Sent to customer primary contact)','Your subscription has been canceled','Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}<br /><br />Your subscription&nbsp;<strong>{subscription_name} </strong>has been canceled, if you have any questions don\'t hesitate to contact us.<br /><br />It was a pleasure doing business with you.<br /><br />Best Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),(65,'subscriptions','subscription-payment-succeeded','english','Subscription Payment Succeeded (Sent to customer primary contact)','Subscription  Payment Receipt - {subscription_name}','Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}<br /><br />This email is to let you know that we received your payment for subscription&nbsp;<strong>{subscription_name}&nbsp;</strong>of&nbsp;<strong><span>{payment_total}<br /><br /></span></strong>The invoice associated with it is now with status&nbsp;<strong>{invoice_status}<br /></strong><br />Thank you for your confidence.<br /><br />Best Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),(66,'contract','contract-expiration-to-staff','english','Contract Expiration Reminder (Sent to Staff)','Contract Expiration Reminder','Hi {staff_firstname}<br /><br /><span style=\"font-size: 12pt;\">This is a reminder that the following contract will expire soon:</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject:</strong> {contract_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Description:</strong> {contract_description}</span><br /><span style=\"font-size: 12pt;\"><strong>Date Start:</strong> {contract_datestart}</span><br /><span style=\"font-size: 12pt;\"><strong>Date End:</strong> {contract_dateend}</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(67,'gdpr','gdpr-removal-request','english','Removal Request From Contact (Sent to administrators)','Data Removal Request Received','Hello&nbsp;{staff_firstname}&nbsp;{staff_lastname}<br /><br />Data removal has been requested by&nbsp;{contact_firstname} {contact_lastname}<br /><br />You can review this request and take proper actions directly from the admin area.','{companyname} | CRM','',0,1,0),(68,'gdpr','gdpr-removal-request-lead','english','Removal Request From Lead (Sent to administrators)','Data Removal Request Received','Hello&nbsp;{staff_firstname}&nbsp;{staff_lastname}<br /><br />Data removal has been requested by {lead_name}<br /><br />You can review this request and take proper actions directly from the admin area.<br /><br />To view the lead inside the admin area click here:&nbsp;<a href=\"{lead_link}\">{lead_link}</a>','{companyname} | CRM','',0,1,0),(69,'client','client-registration-confirmed','english','Customer Registration Confirmed','Your registration is confirmed','<p>Dear {contact_firstname} {contact_lastname}<br /><br />We just wanted to let you know that your registration at&nbsp;{companyname} is successfully confirmed and your account is now active.<br /><br />You can login at&nbsp;<a href=\"{crm_url}\">{crm_url}</a> with the email and password you provided during registration.<br /><br />Please contact us if you need any help.<br /><br />Kind Regards, <br />{email_signature}</p>\r\n<p><br />(This is an automated email, so please don\'t reply to this email address)</p>','{companyname} | CRM','',0,1,0),(70,'contract','contract-signed-to-staff','english','Contract Signed (Sent to Staff)','Customer Signed a Contract','Hi {staff_firstname}<br /><br />A contract with subject&nbsp;<strong>{contract_subject} </strong>has been successfully signed by the customer.<br /><br />You can view the contract at the following link: <a href=\"{contract_link}\">{contract_subject}</a>&nbsp;or from the admin area.<br /><br />{email_signature}','{companyname} | CRM','',0,1,0),(71,'subscriptions','customer-subscribed-to-staff','english','Customer Subscribed to a Subscription (Sent to administrators and subscription creator)','Customer Subscribed to a Subscription','The customer <strong>{client_company}</strong> subscribed to a subscription with name&nbsp;<strong>{subscription_name}</strong><br /><br /><strong>ID</strong>:&nbsp;{subscription_id}<br /><strong>Subscription name</strong>:&nbsp;{subscription_name}<br /><strong>Subscription description</strong>:&nbsp;{subscription_description}<br /><br />You can view the subscription by clicking <a href=\"{subscription_link}\">here</a><br />\r\n<div style=\"text-align: center;\"><span style=\"font-size: 10pt;\">&nbsp;</span></div>\r\nBest Regards,<br />{email_signature}<br /><br /><span style=\"font-size: 10pt;\"><span style=\"color: #999999;\">You are receiving this email because you are either administrator or you are creator of the subscription.</span></span>','{companyname} | CRM','',0,1,0),(72,'client','contact-verification-email','english','Email Verification (Sent to Contact After Registration)','Verify Email Address','<p>Hello&nbsp;{contact_firstname}<br /><br />Please click the button below to verify your email address.<br /><br /><a href=\"{email_verification_url}\">Verify Email Address</a><br /><br />If you did not create an account, no further action is required</p>\r\n<p><br />{email_signature}</p>','{companyname} | CRM','',0,1,0),(73,'client','new-customer-profile-file-uploaded-to-staff','english','New Customer Profile File(s) Uploaded (Sent to Staff)','Customer Uploaded New File(s) in Profile','Hi!<br /><br />New file(s) is uploaded into the customer ({client_company}) profile by&nbsp;{contact_firstname}<br /><br />You can check the uploaded files into the admin area by clicking <a href=\"{customer_profile_files_admin_link}\">here</a> or at the following link:&nbsp;{customer_profile_files_admin_link}<br /><br />{email_signature}','{companyname} | CRM','',0,1,0),(74,'staff','event-notification-to-staff','english','Event Notification (Calendar)','Upcoming Event - {event_title}','Hi {staff_firstname}! <br /><br />This is a reminder for event <a href=\\\"{event_link}\\\">{event_title}</a> scheduled at {event_start_date}. <br /><br />Regards.','','',0,1,0),(75,'subscriptions','subscription-payment-requires-action','english','Credit Card Authorization Required - SCA','Important: Confirm your subscription {subscription_name} payment','<p>Hello {contact_firstname}</p>\r\n<p><strong>Your bank sometimes requires an additional step to make sure an online transaction was authorized.</strong><br /><br />Because of European regulation to protect consumers, many online payments now require two-factor authentication. Your bank ultimately decides when authentication is required to confirm a payment, but you may notice this step when you start paying for a service or when the cost changes.<br /><br />In order to pay the subscription <strong>{subscription_name}</strong>, you will need to&nbsp;confirm your payment by clicking on the follow link: <strong><a href=\"{subscription_authorize_payment_link}\">{subscription_authorize_payment_link}</a></strong><br /><br />To view the subscription, please click at the following link: <a href=\"{subscription_link}\"><span>{subscription_link}</span></a><br />or you can login in our dedicated area here: <a href=\"{crm_url}/login\">{crm_url}/login</a> in case you want to update your credit card or view the subscriptions you are subscribed.<br /><br />Best Regards,<br />{email_signature}</p>','{companyname} | CRM','',0,1,0),(76,'invoice','invoice-due-notice','english','Invoice Due Notice','Your {invoice_number} will be due soon','<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}<br /><br /></span>You invoice <span style=\"font-size: 12pt;\"><strong># {invoice_number} </strong>will be due on <strong>{invoice_duedate}</strong></span><br /><br /><span style=\"font-size: 12pt;\">You can view the invoice on the following link: <a href=\"{invoice_link}\">{invoice_number}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(77,'estimate_request','estimate-request-submitted-to-staff','english','Estimate Request Submitted (Sent to Staff)','New Estimate Request Submitted','<span> Hello,&nbsp;</span><br /><br />{estimate_request_email} submitted an estimate request via the {estimate_request_form_name} form.<br /><br />You can view the request at the following link: <a href=\"{estimate_request_link}\">{estimate_request_link}</a><br /><br />==<br /><br />{estimate_request_submitted_data}<br /><br />Kind Regards,<br /><span>{email_signature}</span>','{companyname} | CRM','',0,1,0),(78,'estimate_request','estimate-request-assigned','english','Estimate Request Assigned (Sent to Staff)','New Estimate Request Assigned','<span> Hello {estimate_request_assigned},&nbsp;</span><br /><br />Estimate request #{estimate_request_id} has been assigned to you.<br /><br />You can view the request at the following link: <a href=\"{estimate_request_link}\">{estimate_request_link}</a><br /><br />Kind Regards,<br /><span>{email_signature}</span>','{companyname} | CRM','',0,1,0),(79,'estimate_request','estimate-request-received-to-user','english','Estimate Request Received (Sent to User)','Estimate Request Received','Hello,<br /><br /><strong>Your request has been received.</strong><br /><br />This email is to let you know that we received your request and we will get back to you as soon as possible with more information.<br /><br />Best Regards,<br />{email_signature}','{companyname} | CRM','',0,0,0),(80,'notifications','non-billed-tasks-reminder','english','Non-billed tasks reminder (sent to selected staff members)','Action required: Completed tasks are not billed','Hello {staff_firstname}<br><br>The following tasks are marked as complete but not yet billed:<br><br>{unbilled_tasks_list}<br><br>Kind Regards,<br><br>{email_signature}','{companyname} | CRM','',0,1,0),(81,'invoice','invoices-batch-payments','english','Invoices Payments Recorded in Batch (Sent to Customer)','We have received your payments','Hello {contact_firstname} {contact_lastname}<br><br>Thank you for the payments. Please find the payments details below:<br><br>{batch_payments_list}<br><br>We are looking forward working with you.<br><br>Kind Regards,<br><br>{email_signature}','{companyname} | CRM','',0,1,0),(82,'contract','contract-sign-reminder','english','Contract Sign Reminder (Sent to Customer)','Contract Sign Reminder','<p>Hello {contact_firstname} {contact_lastname}<br /><br />This is a reminder to review and sign the contract:<a href=\"{contract_link}\">{contract_subject}</a></p><p>You can view and sign by visiting: <a href=\"{contract_link}\">{contract_subject}</a></p><p><br />We are looking forward working with you.<br /><br />Kind Regards,<br /><br />{email_signature}</p>','{companyname} | CRM','',0,1,0),(83,'timesheets_attendance_mgt','attendance_notice','english','Attendance notice','Timesheets - Attendance notice','{staff_name} {type_check} at {date_time}','{companyname} | CRM',NULL,0,1,0),(84,'timesheets_attendance_mgt','send_request_approval','english','Send request approval','Timesheets - Send request approval to approver','Hi {approver}! <br>-{staff_name} has created an apply for leave and requires your approval. Please go to this link for details and approval: {link}','{companyname} | CRM',NULL,0,1,0),(85,'timesheets_attendance_mgt','remind_user_check_in','english','Remind user check in','Timesheets - Remind user check in','Remind you to check in today to record the start time of the shift {date_time}','{companyname} | CRM',NULL,0,1,0),(86,'timesheets_attendance_mgt','new_leave_application_send_to_notification_recipient','english','New application (Send to notification recipient)','Timesheets - New application - Send to notification recipient','{staff_name} created a new application {link} at {date_time}','{companyname} | CRM',NULL,0,1,0),(87,'client','affiliate_management_payout_updated','english','Affiliate Payout Request Update','An update regarding your payout request','Dear {contact_firstname},<br/><br/>\n    We hope this message finds you well.\n    <br/>\n    We wanted to inform you about the latest status of your payout request, identified by reference number <b>#{payout_id}</b>. \n    <br/><br/>\n    Amount: {payout_amount}<br/>\n    Status: {payout_status}<br/>\n    Note: {payout_note_for_affiliate}<br/>\n    Created: {payout_created_at}<br/>\n    <br/><br/>\n    If you have any questions or need further clarification, please do not hesitate to reach out. We are here to assist you in any way possible.<br/><br/>\n    \n    Best regards,<br/>\n    {email_signature}','{companyname} | CRM',NULL,0,1,0),(88,'client','affiliate_management_signup_through_affiliate_link','english','Successful Signup through Affiliate Link','Congratulations on a successful signup!','Dear {contact_firstname},<br/><br/>\n    We are delighted to inform you that someone has successfully signed up using your affiliate link.\n    <br/><br/>\n    Company/Contact: {referral_name}<br/>\n    Date: {referral_created_at}<br/>\n    <br/><br/>\n    While this signup may not have resulted in an immediate transaction, your efforts are highly valued. We appreciate your contribution to our community and anticipate further success in the future.\n    <br/><br/>\n    If you have any questions or need additional information, please feel free to reach out.\n    <br/><br/>\n    Best regards,<br/>\n    {email_signature}','{companyname} | CRM',NULL,0,1,0),(89,'client','affiliate_management_successful_referral_commission','english','Successful Referral Commission Notification','A referral commission received!','Dear {contact_firstname},<br/><br/>\n    We are thrilled to inform you that your referral has resulted in a successful transaction, earning you a commission.\n    <br/><br/>\n    Company/Contact: {referral_name}<br/>\n    Transaction Amount: {payment_amount}<br/>\n    Commission Earned: {commission_amount}<br/>\n    New Balance: {affiliate_balance}<br/>\n    Date: {commission_created_at}<br/>\n    <br/><br/>\n    We appreciate your efforts and look forward to more successful collaborations. Should you have any questions or require further information, feel free to reach out.\n    <br/><br/>\n    Best regards,<br/>\n    {email_signature}','{companyname} | CRM',NULL,0,1,0),(90,'staff','affiliate_management_new_payout_request_for_admin','english','Affiliate Payout Request','You have new affiliate payout request','Dear Admin,<br/><br/>\n    I wanted to inform you about a new payout request, identified by reference number <b>#{payout_id}</b>. \n    <br/><br/>\n    Affiliate: {affiliate_name}<br/>\n    Amount: {payout_amount}<br/>\n    Status: {payout_status}<br/>\n    Note: {payout_note_for_admin}<br/>\n    Created: {payout_created_at}<br/>\n    <br/><br/>    \n    Best regards,<br/>\n    {email_signature}','{companyname} | CRM',NULL,0,1,0),(91,'staff','affiliate_management_payout_updated_for_admin','english','Affiliate Payout Request Updated','You marked payout: #{payout_id} as {payout_status}','Dear Admin,<br/><br/>\n    I wanted to update you about the recent update to a payout request, identified by reference number <b>#{payout_id}</b>. \n    <br/><br/>\n    Affiliate: {affiliate_name}<br/>\n    Amount: {payout_amount}<br/>\n    Status: {payout_status}<br/><br/>\n    Admin Note: {payout_note_for_admin}<br/>\n    Note: {payout_note_for_affiliate}<br/>\n    Created: {payout_created_at}<br/>\n    <br/><br/>    \n    Best regards,<br/>\n    {email_signature}','{companyname} | CRM',NULL,0,1,0),(92,'staff','affiliate_management_new_affiliate_signup_for_admin','english','New Affiliate Signup','A new affiliate signup','Dear Admin,<br/><br/>\n    I wanted to inform you about a new affiliate signup, identified by reference number <b>#{affiliate_slug}</b>. \n    <br/><br/>\n    Affiliate: {affiliate_name}<br/>\n    Status: {affiliate_status}<br/>\n    Created: {affiliate_created_at}<br/>\n    <br/><br/>    \n    Best regards,<br/>\n    {email_signature}','{companyname} | CRM',NULL,0,1,0),(93,'client','affiliate_management_referral_commission_reversal','english','Referral Commission Reversal Notification','A referral commission was reversed!','Dear {contact_firstname},<br/><br/>\n    We regret to inform you that the commission previously awarded for your referral has been reversed due to reversal or removal of the rewarded payment.\n    <br/><br/>\n    Company/Contact: {referral_name}<br/>\n    Comission ID: {commission_id}<br/>\n    Amount Reversed: {commission_amount}<br/>\n    New Balance: {affiliate_balance}<br/>\n    Date of commission: {commission_created_at}<br/>\n    <br/><br/>\n    We appreciate your efforts and look forward to more successful collaborations. Should you have any questions or require further information, feel free to reach out.\n    <br/><br/>\n    Best regards,<br/>\n    {email_signature}','{companyname} | CRM',NULL,0,1,0),(94,'inventory_warning','inventory-warning-to-staff','english','Inventory warning (Sent to staff)','Inventory warning','Hi {staff_name}! <br /><br />This is a inventory warning<br />{<span 12pt=\"\">notification_content</span>}. <br /><br />Regards.','{companyname} | CRM',NULL,0,1,0),(103,'purchase_order','purchase-order-to-contact','english','Purchase Order (Sent to contact)','Purchase Order','<span style=\\\"font-size: 12pt;\\\"> Hello !. </span><br /><br /><span style=\\\"font-size: 12pt;\\\"> We would like to share with you a link of Purchase Order information with the number {po_number} </span><br /><br /><span style=\\\"font-size: 12pt;\\\"><br />Please click on the link to view information: {public_link}\r\n  </span><br /><br />','{companyname} | CRM',NULL,0,1,0),(104,'purchase_order','purchase-request-to-contact','english','Purchase Request (Sent to contact)','Purchase Request','<span style=\\\"font-size: 12pt;\\\"> Hello !. </span><br /><br /><span style=\\\"font-size: 12pt;\\\"> We would like to share with you a link of Purchase Request information with the number {pr_number} </span><br /><br /><span style=\\\"font-size: 12pt;\\\"><br />Please click on the link to view information: {public_link}<br/ >{additional_content}\r\n  </span><br /><br />','{companyname} | CRM',NULL,0,1,0),(105,'purchase_order','purchase-quotation-to-contact','english','Purchase Quotation (Sent to contact)','Purchase Quotation','<span style=\\\"font-size: 12pt;\\\"> Hello !. </span><br /><br /><span style=\\\"font-size: 12pt;\\\"> We would like to share with you a link of Purchase Quotation information with the number {pq_number} </span><br /><br /><span style=\\\"font-size: 12pt;\\\"><br />Please click on the link to view information: {quotation_link}<br/ >{additional_content}\r\n  </span><br /><br />','{companyname} | CRM',NULL,0,1,0),(106,'purchase_order','debit-note-to-contact','english','Debit Note (Sent to contact)','Debit Note','<span style=\\\"font-size: 12pt;\\\"> Hello !. </span><br /><br /><span style=\\\"font-size: 12pt;\\\"> We would like to share with you a link of Debit Note information with the number {dn_number} </span><br /><br /><span style=\\\"font-size: 12pt;\\\"><br />{additional_content}\r\n  </span><br /><br />','{companyname} | CRM',NULL,0,1,0),(107,'purchase_order','purchase-statement-to-contact','english','Purchase Statement (Sent to contact)','Purchase Statement','<span style=\\\"font-size: 12pt;\\\"> Dear {contact_firstname} {contact_lastname} !. </span><br /><br /><span style=\\\"font-size: 12pt;\\\">Its been a great experience working with you. </span><br /><br /><span style=\\\"font-size: 12pt;\\\"><br />Attached with this email is a list of all transactions for the period between {statement_from} to {statement_to}<br/ ><br/ >For your information your account balance due is total: {statement_balance_due}<br /><br/ > Please contact us if you need more information.<br/ > <br />{additional_content}\r\n  </span><br /><br />','{companyname} | CRM',NULL,0,1,0),(108,'purchase_order','vendor-registration-confirmed','english','Vendor Registration Confirmed','Your registration is confirmed','<p>Dear {contact_firstname} {contact_lastname}<br /><br />We just wanted to let you know that your registration at&nbsp;{companyname} is successfully confirmed and your account is now active.<br /><br />You can login at&nbsp;<a href=\"{vendor_portal_url}\">{vendor_portal_url}</a> with the email and password you provided during registration.<br /><br />Please contact us if you need any help.<br /><br />Kind Regards, <br />{email_signature}</p>\r\n <p><br />(This is an automated email, so please dont reply to this email address)</p>','{companyname} | CRM',NULL,0,1,0),(109,'purchase_order','purchase-contract-to-contact','english','Purchase Contract (Sent to contact)','Purchase Contract','<span style=\\\"font-size: 12pt;\\\"> Hello !. </span><br /><br /><span style=\\\"font-size: 12pt;\\\"> We would like to share with you a link of Purchase Contract information with the number {contract_number} </span><br /><br /><span style=\\\"font-size: 12pt;\\\"><br />Please click on the link to view information: {contract_link}\r\n  </span><br /><br />','{companyname} | CRM',NULL,0,1,0),(110,'purchase_order','new-contact-created','english','New Contact Added/Registered (Welcome Email)','New Contact Added/Registered (Welcome Email)','<span style=\\\"font-size: 12pt;\\\"> Dear {contact_firstname} {contact_lastname}! </span><br /><br /><span style=\\\"font-size: 12pt;\\\"> Welcome to our system </span><br /><br /><span style=\\\"font-size: 12pt;\\\"><br />Click here to login: {vendor_portal_link}</span><br /></span><br />','{companyname} | CRM',NULL,0,1,0),(111,'purchase_order','purchase-request-approval','english','Request approval','Request approval','<span style=\\\"font-size: 12pt;\\\"> Hello {staff_name}! </span><br /><br /><span style=\\\"font-size: 12pt;\\\"> You receive an approval request: {link} from {from_staff_name}</span>','{companyname} | CRM',NULL,0,1,0),(112,'purchase_order','purchase-send-approved','english','Email send approved','Email send approved','<span style=\\\"font-size: 12pt;\\\"> Hello {staff_name}! </span><br /><br /><span style=\\\"font-size: 12pt;\\\">{type} has been approved by {by_staff_name} </span><br /><span style=\\\"font-size: 12pt;\\\"><br />Click here to view detail: {link} </span><br /></span><br />','{companyname} | CRM',NULL,0,1,0),(113,'purchase_order','purchase-send-rejected','english','Email send rejected','Email send rejected','<span style=\\\"font-size: 12pt;\\\"> Hello {staff_name}! </span><br /><br /><span style=\\\"font-size: 12pt;\\\"> {type} has been declined by {by_staff_name} </span><br /><span style=\\\"font-size: 12pt;\\\"><br />Click here to view detail: {link}  </span><br /></span><br />','{companyname} | CRM',NULL,0,1,0),(114,'change_candidate_status','change-candidate-status-to-candidate','english','Change Candidate Status (Sent to Candidate)','Changed Candidate Status','<br />Hi {candidate_name} {last_name}<br /><br />I would like to inform you that your candidate profile status changed to {candidate_status}<br /><br />I will contact you again as soon as I have any news.<br /><br />Kind Regards,<br />{email_signature}.','{companyname} | CRM',NULL,0,1,0),(115,'change_candidate_job_applied_status','change-candidate-job-applied-status-to-candidate','english','Change Candidate Job Applied Status (Sent to Candidate)','Changed Candidate Job Applied Status','<br />Hi {candidate_name} {last_name}<br /><br />I would like to inform you that your Job Applied status changed to {job_applied_status}<br /><br />I will contact you again as soon as I have any news.<br /><br />Kind Regards,<br />{email_signature}.','{companyname} | CRM',NULL,0,1,0),(116,'change_candidate_interview_schedule_status','change-candidate-interview-schedule-status-to-candidate','english','Change Candidate Interview Schedule Status (Sent to Candidate)','Changed Candidate Interview Schedule Status','<br />Hi {candidate_name} {last_name}<br /><br />I would like to inform you that your Interview Schedule status changed to {interview_schedule_status}<br /><br />I will contact you again as soon as I have any news.<br /><br />Kind Regards,<br />{email_signature}.','{companyname} | CRM',NULL,0,1,0),(117,'new_candidate_have_applied','new-candidate-have-applied','english','New candidate have applied (Sent to Responsible)','New candidate have applied','<p><span style=\"font-size: 12pt;\">New Candidate have been applied.</span><br /><br /><span style=\"font-size: 12pt;\">You can view the Candidate profile on the following link: <a href=\"{candidate_link}\">#{candidate_link}</a><br /><br />Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span></p>','{companyname} | CRM',NULL,0,1,0),(118,'staff','flexibackup-new-backup-to-staff','english','Flexi Backup Notification','New Backup Available  - {backup_name}','Hi there! <br /><br /> Please find attached a copy of your {backup_type} created on {backup_date}.  <br /><br /> Regards.','{companyname} | CRM',NULL,0,1,0),(119,'appointly','appointment-cron-reminder-to-staff','english','Appointment reminder (Sent to Staff and Attendees)','You have an upcoming appointment!','<span style=\\\"font-size: 12pt;\\\"> Hello {staff_firstname} {staff_lastname} </span><br /><br /><span style=\\\"font-size: 12pt;\\\"> You have an upcoming appointment that is need to be held date {appointment_date} and location {appointment_location}</span><br /><br /><span style=\\\"font-size: 12pt;\\\"><strong>Additional info for your appointment:</strong></span><br /><span style=\\\"font-size: 12pt;\\\"><strong>Appointment Subject:</strong> {appointment_subject}</span><br /><span style=\\\"font-size: 12pt;\\\"><strong>Appointment Description:</strong> {appointment_description}</span><br /><span style=\\\"font-size: 12pt;\\\"><strong>Appointment scheduled date to start:</strong> {appointment_date}</span><br /><span style=\\\"font-size: 12pt;\\\"><strong>You can view this appointment at the following link:</strong> <a href=\"{appointment_admin_url}\">Your appointment URL</a></span><br /><span style=\\\"font-size: 12pt;\\\"><br />Kind Regards</span><br /><br /><span style=\\\"font-size: 12pt;\\\">{email_signature}</span>','{companyname} | CRM',NULL,0,1,0),(120,'appointly','appointment-recurring-to-staff','english','Appointment recurring (Sent to Staff and Attendees)','Recurring appointment was re-created!','<span style=\\\"font-size: 12pt;\\\"> Hello {staff_firstname} {staff_lastname} </span><br /><br /><span style=\\\"font-size: 12pt;\\\"> Your recurring appointment was recreated with date {appointment_date} and location {appointment_location}</span><br /><br /><span style=\\\"font-size: 12pt;\\\"><strong> Additional info for your appointment:</strong></span><br /><span style=\\\"font-size: 12pt;\\\"><strong>Appointment Subject:</strong> {appointment_subject}</span><br /><span style=\\\"font-size: 12pt;\\\"><strong>Appointment Description:</strong> {appointment_description}</span><br /><span style=\\\"font-size: 12pt;\\\"><strong>Appointment scheduled date to start:</strong> {appointment_date}</span><br /><span style=\\\"font-size: 12pt;\\\"><strong>You can view this appointment at the following link:</strong> <a href=\"{appointment_admin_url}\">Your appointment URL</a></span><br /><span style=\\\"font-size: 12pt;\\\"><br />Kind Regards</span><br /><br /><span style=\\\"font-size: 12pt;\\\">{email_signature}</span>','{companyname} | CRM',NULL,0,1,0),(121,'appointly','appointment-cancelled-to-staff','english','Appointment cancelled (Sent to Staff and Attendees)','Appointment has been cancelled!','<span style=\\\"font-size: 12pt;\\\"> Hello {staff_firstname} {staff_lastname}. </span><br /><br /><span style=\\\"font-size: 12pt;\\\"> The appointment that needed to be held on date {appointment_date} and location {appointment_location} with contact {appointment_client_name} is cancelled.</span><br /><br /><span style=\\\"font-size: 12pt;\\\"><br />Kind Regards</span><br /><br /><span style=\\\"font-size: 12pt;\\\">{email_signature}</span>','{companyname} | CRM',NULL,0,1,0),(122,'appointly','appointment-cancelled-to-contact','english','Appointment cancelled (Sent to Contact)','Your appointment has been cancelled!','<span style=\\\"font-size: 12pt;\\\"> Hello {appointment_client_name}. </span><br /><br /><span style=\\\"font-size: 12pt;\\\"> The appointment that needed to be held on date {appointment_date} and location {appointment_location} is now cancelled.</span><br /><br /><span style=\\\"font-size:12pt;\\\"><br />Kind Regards</span><br /><br /><span style=\\\"font-size: 12pt;\\\">{email_signature}</span>','{companyname} | CRM',NULL,0,1,0),(123,'appointly','appointment-cron-reminder-to-contact','english','Appointment reminder (Sent to Contact)','You have an upcoming appointment!','<span style=\\\"font-size: 12pt;\\\"> Hello {appointment_client_name}. </span><br /><br /><span style=\\\"font-size: 12pt;\\\"> You have an upcoming appointment that is need to be held date {appointment_date} and location {appointment_location}.</span><br /><br /><span style=\\\"font-size: 12pt;\\\"><strong>Additional info for your appointment</strong></span><br /><span style=\\\"font-size: 12pt;\\\"><strong>Appointment Subject:</strong> {appointment_subject}</span><br /><span style=\\\"font-size: 12pt;\\\"><strong>Appointment Description:</strong> {appointment_description}</span><br /><span style=\\\"font-size: 12pt;\\\"><strong>Appointment scheduled date to start:</strong> {appointment_date}</span><br /><span style=\\\"font-size: 12pt;\\\"><strong>You can view this appointment at the following link:</strong> <a href=\"{appointment_public_url}\">Your appointment URL</a></span><br /><span style=\\\"font-size: 12pt;\\\"><br />Kind Regards</span><br /><br /><span style=\\\"font-size: 12pt;\\\">{email_signature}</span>','{companyname} | CRM',NULL,0,1,0),(124,'appointly','appointment-recurring-to-contacts','english','Appointment recurring (Sent to Contact)','Recurring appointment was re-created!','<span style=\\\"font-size: 12pt;\\\"> Hello {appointment_client_name}. </span><br /><br /><span style=\\\"font-size: 12pt;\\\"> Your recurring appointment was recreated with date {appointment_date} and location {appointment_location}.</span><br /><br /><span style=\\\"font-size: 12pt;\\\"><strong>Additional info for your appointment</strong></span><br /><span style=\\\"font-size: 12pt;\\\"><strong>Appointment Subject:</strong> {appointment_subject}</span><br /><span style=\\\"font-size: 12pt;\\\"><strong>Appointment Description:</strong> {appointment_description}</span><br /><span style=\\\"font-size: 12pt;\\\"><strong>Appointment scheduled date to start:</strong> {appointment_date}</span><br /><span style=\\\"font-size: 12pt;\\\"><strong>You can view this appointment at the following link:</strong> <a href=\"{appointment_public_url}\">Your appointment URL</a></span><br /><span style=\\\"font-size: 12pt;\\\"><br />Kind Regards</span><br /><br /><span style=\\\"font-size: 12pt;\\\">{email_signature}</span>','{companyname} | CRM',NULL,0,1,0),(125,'appointly','appointment-approved-to-staff','english','Appointment approved (Sent to Staff and Atendees)','You are added as a appointment attendee!','<span style=\\\"font-size: 12pt;\\\"> Hello {staff_firstname} {staff_lastname}.</span><br /><br /><span style=\\\"font-size: 12pt;\\\"> You are added as a appointment attendee.</span><br /><br /><span style=\\\"font-size: 12pt;\\\"><strong>Appointment Subject:</strong> {appointment_subject}</span><br /><span style=\\\"font-size: 12pt;\\\"><strong>Appointment Description:</strong> {appointment_description}</span><br /><span style=\\\"font-size: 12pt;\\\"><strong>Appointment scheduled date to start:</strong> {appointment_date}</span><br /><span style=\\\"font-size: 12pt;\\\"><strong>You can view this appointment at the following link:</strong> <a href=\"{appointment_admin_url}\">Your appointment URL</a></span><br /><span style=\\\"font-size: 12pt;\\\"><br />Kind Regards</span><br /><br /><span style=\\\"font-size: 12pt;\\\">{email_signature}</span>','{companyname} | CRM',NULL,0,1,0),(126,'appointly','appointment-approved-to-contact','english','Appointment approved (Sent to Contact)','Your appointment has been approved!','<span style=\\\"font-size: 12pt;\\\"> Hello {appointment_client_name}.</span><br /><br /><span style=\\\"font-size: 12pt;\\\"> You appointment has been approved!</span><br /><br /><span style=\\\"font-size: 12pt;\\\"><strong>Appointment Subject:</strong> {appointment_subject}</span><br /><span style=\\\"font-size: 12pt;\\\"><strong>Appointment Description:</strong> {appointment_description}</span><br /><span style=\\\"font-size: 12pt;\\\"><strong>Appointment scheduled date to start:</strong> {appointment_date}</span><br /><span style=\\\"font-size: 12pt;\\\"><strong>You can keep track of your appointment at the following link:</strong> <a href=\"{appointment_public_url}\">Your appointment URL</a></span><br /><span style=\\\"font-size: 12pt;\\\"><br/>If you have any questions Please contact us for more information.</span><br /><br /><span style=\\\"font-size: 12pt;\\\"><br />Kind Regards</span><br /><br /><span style=\\\"font-size: 12pt;\\\">{email_signature}</span>','{companyname} | CRM',NULL,0,1,0),(127,'appointly','appointment-submitted-to-staff','english','New appointment request (Sent to Responsible Person)','New appointment request via external form!','<span 12pt=\"\"><span 12pt=\"\">Hello {staff_firstname} {staff_lastname}<br /><br />New appointment request submitted via external form</span>.<br /><br /><span 12pt=\"\"><strong>Appointment Subject:</strong> {appointment_subject}</span><br /><br /><span 12pt=\"\"><strong>Appointment Description:</strong> {appointment_description}</span><br /><br /><span 12pt=\"\"><strong>Appointment requested scheduled start date:</strong> {appointment_date}</span><br /><br /><span 12pt=\"\"><strong>You can view this appointment request at the following link:</strong> <a href=\"{appointment_admin_url}\">{appointment_admin_url}</a></span><br /><br /><br />{companyname}<br />{crm_url}<br /><span 12pt=\"\"></span></span>','{companyname} | CRM',NULL,0,1,0),(128,'appointly','callback-assigned-to-staff','english','Assigned to callback (Sent to Staff)','You have been assigned to handle a new callback!','<span 12pt=\"\"><span 12pt=\"\">Hello {staff_firstname} {staff_lastname}<br /><br />An admin assigned a callback to you, you can view this callback request at the following link:</strong> <a href=\"{admin_url}/appointly/callbacks\">{admin_url}/appointly/callbacks</a></span><br /><br /><br />{companyname}<br />{crm_url}<br /><span 12pt=\"\"></span></span>','{companyname} | CRM',NULL,0,1,0),(129,'appointly','newcallback-requested-to-staff','english','New callback request (Sent to Callbacks Responsible Person)','You have a new callback request!','<span 12pt=\"\"><span 12pt=\"\">Hello {staff_firstname} {staff_lastname}<br /><br />A new callback request has just been submitted, fast navigate to callbacks to view latest callback submitted:</strong> <a href=\"{admin_url}/appointly/callbacks\">{admin_url}/appointly/callbacks</a></span><br /><br /><br />{companyname}<br />{crm_url}<br /><span 12pt=\"\"></span></span>','{companyname} | CRM',NULL,0,1,0),(130,'appointly','appointly-appointment-request-feedback','english','Request Appointment Feedback (Sent to Client)','Feedback request for appointment!','<span 12pt=\"\"><span 12pt=\"\">Hello {appointment_client_name} <br /><br />A new feedback request has just been submitted, please leave your comments and thoughts about this past appointment, fast navigate to the appointment to add a feedback:</strong> <a href=\"{appointment_public_url}\">{appointment_public_url}</a></span><br /><br /><br />{companyname}<br />{crm_url}<br /><span 12pt=\"\"></span></span>','{companyname} | CRM',NULL,0,1,0),(131,'appointly','appointly-appointment-feedback-received','english','New Feedback Received (Sent to Responsible Person)','New appointment feedback rating received!','<span 12pt=\"\"><span 12pt=\"\">Hello {staff_firstname} {staff_lastname} <br /><br />A new feedback rating has been received from client {appointment_client_name}. View the new feedback rating submitted at the following link:</strong> <a href=\"{appointment_admin_url}\">{appointment_admin_url}</a></span><br /><br /><br />{companyname}<br />{crm_url}<br /><span 12pt=\"\"></span></span>','{companyname} | CRM',NULL,0,1,0),(132,'appointly','appointly-appointment-feedback-updated','english','Feedback Updated (Sent to Responsible Person)','Appointment feedback rating updated!','<span 12pt=\"\"><span 12pt=\"\">Hello {staff_firstname} {staff_lastname} <br /><br />An existing feedback was just updated from client {appointment_client_name}. View the new rating submitted at the following link:</strong> <a href=\"{appointment_admin_url}\">{appointment_admin_url}</a></span><br /><br /><br />{companyname}<br />{crm_url}<br /><span 12pt=\"\"></span></span>','{companyname} | CRM',NULL,0,1,0),(133,'omni_sales','purchase-receipt','english','Purchase receipt (Sent to customer)','Purchase receipt','Hi {staff_name}! <br /><br />Thank you for shopping in our store.<br />\r\n    We send a receipt of your purchase below.<br />{<span 12pt=\"\">notification_content</span>}. <br /><br />Kind Regards.<br/>Very pleased to serve you!','{companyname} | CRM',NULL,0,1,0),(134,'omni_sales','pre-orders-notify','english','Pre-orders notify (Sent to seller)','Pre-orders notify','Hi {seller_name}! <br /><br />You have a new order from {buyer_name}, the order is created at {create_at}. View order details: {link}.<br />','{companyname} | CRM',NULL,0,1,0),(135,'omni_sales','pre-orders-handover','english','Pre-orders handover','Pre-orders handover','Hi {to_name}! <br /><br />{from_name} has handed over an order to you. View order details: {link}.<br />','{companyname} | CRM',NULL,0,1,0);
/*!40000 ALTER TABLE `maxlife_tblemailtemplates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblestimate_request_forms`
--

DROP TABLE IF EXISTS `maxlife_tblestimate_request_forms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblestimate_request_forms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `form_key` varchar(32) NOT NULL,
  `type` varchar(100) NOT NULL,
  `name` varchar(191) NOT NULL,
  `form_data` longtext DEFAULT NULL,
  `recaptcha` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL,
  `submit_btn_name` varchar(100) DEFAULT NULL,
  `submit_btn_bg_color` varchar(10) DEFAULT '#84c529',
  `submit_btn_text_color` varchar(10) DEFAULT '#ffffff',
  `success_submit_msg` mediumtext DEFAULT NULL,
  `submit_action` int(11) DEFAULT 0,
  `submit_redirect_url` longtext DEFAULT NULL,
  `language` varchar(100) DEFAULT NULL,
  `dateadded` datetime DEFAULT NULL,
  `notify_type` varchar(100) DEFAULT NULL,
  `notify_ids` longtext DEFAULT NULL,
  `responsible` int(11) DEFAULT NULL,
  `notify_request_submitted` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblestimate_request_forms`
--

LOCK TABLES `maxlife_tblestimate_request_forms` WRITE;
/*!40000 ALTER TABLE `maxlife_tblestimate_request_forms` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblestimate_request_forms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblestimate_request_status`
--

DROP TABLE IF EXISTS `maxlife_tblestimate_request_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblestimate_request_status` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `statusorder` int(11) DEFAULT NULL,
  `color` varchar(10) DEFAULT NULL,
  `flag` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblestimate_request_status`
--

LOCK TABLES `maxlife_tblestimate_request_status` WRITE;
/*!40000 ALTER TABLE `maxlife_tblestimate_request_status` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblestimate_request_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblestimate_requests`
--

DROP TABLE IF EXISTS `maxlife_tblestimate_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblestimate_requests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `submission` longtext NOT NULL,
  `last_status_change` datetime DEFAULT NULL,
  `date_estimated` datetime DEFAULT NULL,
  `from_form_id` int(11) DEFAULT NULL,
  `assigned` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `default_language` int(11) NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblestimate_requests`
--

LOCK TABLES `maxlife_tblestimate_requests` WRITE;
/*!40000 ALTER TABLE `maxlife_tblestimate_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblestimate_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblestimates`
--

DROP TABLE IF EXISTS `maxlife_tblestimates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblestimates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sent` tinyint(1) NOT NULL DEFAULT 0,
  `datesend` datetime DEFAULT NULL,
  `clientid` int(11) NOT NULL,
  `deleted_customer_name` varchar(100) DEFAULT NULL,
  `project_id` int(11) NOT NULL DEFAULT 0,
  `number` int(11) NOT NULL,
  `prefix` varchar(50) DEFAULT NULL,
  `number_format` int(11) NOT NULL DEFAULT 0,
  `hash` varchar(32) DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `date` date NOT NULL,
  `expirydate` date DEFAULT NULL,
  `currency` int(11) NOT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `total_tax` decimal(15,2) NOT NULL DEFAULT 0.00,
  `total` decimal(15,2) NOT NULL,
  `adjustment` decimal(15,2) DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `clientnote` mediumtext DEFAULT NULL,
  `adminnote` mediumtext DEFAULT NULL,
  `discount_percent` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `discount_type` varchar(30) DEFAULT NULL,
  `invoiceid` int(11) DEFAULT NULL,
  `invoiced_date` datetime DEFAULT NULL,
  `terms` mediumtext DEFAULT NULL,
  `reference_no` varchar(100) DEFAULT NULL,
  `sale_agent` int(11) NOT NULL DEFAULT 0,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT NULL,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT NULL,
  `include_shipping` tinyint(1) NOT NULL,
  `show_shipping_on_estimate` tinyint(1) NOT NULL DEFAULT 1,
  `show_quantity_as` int(11) NOT NULL DEFAULT 1,
  `pipeline_order` int(11) DEFAULT 1,
  `is_expiry_notified` int(11) NOT NULL DEFAULT 0,
  `acceptance_firstname` varchar(50) DEFAULT NULL,
  `acceptance_lastname` varchar(50) DEFAULT NULL,
  `acceptance_email` varchar(100) DEFAULT NULL,
  `acceptance_date` datetime DEFAULT NULL,
  `acceptance_ip` varchar(40) DEFAULT NULL,
  `signature` varchar(40) DEFAULT NULL,
  `short_link` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `currency` (`currency`),
  KEY `project_id` (`project_id`),
  KEY `sale_agent` (`sale_agent`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblestimates`
--

LOCK TABLES `maxlife_tblestimates` WRITE;
/*!40000 ALTER TABLE `maxlife_tblestimates` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblestimates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblevents`
--

DROP TABLE IF EXISTS `maxlife_tblevents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblevents` (
  `eventid` int(11) NOT NULL AUTO_INCREMENT,
  `title` longtext NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `userid` int(11) NOT NULL,
  `start` datetime NOT NULL,
  `end` datetime DEFAULT NULL,
  `public` int(11) NOT NULL DEFAULT 0,
  `color` varchar(10) DEFAULT NULL,
  `isstartnotified` tinyint(1) NOT NULL DEFAULT 0,
  `reminder_before` int(11) NOT NULL DEFAULT 0,
  `reminder_before_type` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`eventid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblevents`
--

LOCK TABLES `maxlife_tblevents` WRITE;
/*!40000 ALTER TABLE `maxlife_tblevents` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblevents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblexpenses`
--

DROP TABLE IF EXISTS `maxlife_tblexpenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblexpenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` int(11) NOT NULL,
  `currency` int(11) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `tax` int(11) DEFAULT NULL,
  `tax2` int(11) NOT NULL DEFAULT 0,
  `reference_no` varchar(100) DEFAULT NULL,
  `note` mediumtext DEFAULT NULL,
  `expense_name` varchar(191) DEFAULT NULL,
  `clientid` int(11) NOT NULL,
  `project_id` int(11) NOT NULL DEFAULT 0,
  `billable` int(11) DEFAULT 0,
  `invoiceid` int(11) DEFAULT NULL,
  `paymentmode` varchar(50) DEFAULT NULL,
  `date` date NOT NULL,
  `recurring_type` varchar(10) DEFAULT NULL,
  `repeat_every` int(11) DEFAULT NULL,
  `recurring` int(11) NOT NULL DEFAULT 0,
  `cycles` int(11) NOT NULL DEFAULT 0,
  `total_cycles` int(11) NOT NULL DEFAULT 0,
  `custom_recurring` int(11) NOT NULL DEFAULT 0,
  `last_recurring_date` date DEFAULT NULL,
  `create_invoice_billable` tinyint(1) DEFAULT NULL,
  `send_invoice_to_customer` tinyint(1) NOT NULL,
  `recurring_from` int(11) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  `addedfrom` int(11) NOT NULL,
  `vendor` int(11) DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `date_paid` date DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `is_bill` int(11) NOT NULL DEFAULT 0,
  `reason_for_void` text DEFAULT NULL,
  `voided` int(11) NOT NULL DEFAULT 0,
  `approved` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `project_id` (`project_id`),
  KEY `category` (`category`),
  KEY `currency` (`currency`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblexpenses`
--

LOCK TABLES `maxlife_tblexpenses` WRITE;
/*!40000 ALTER TABLE `maxlife_tblexpenses` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblexpenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblexpenses_categories`
--

DROP TABLE IF EXISTS `maxlife_tblexpenses_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblexpenses_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblexpenses_categories`
--

LOCK TABLES `maxlife_tblexpenses_categories` WRITE;
/*!40000 ALTER TABLE `maxlife_tblexpenses_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblexpenses_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblfe_activity_log`
--

DROP TABLE IF EXISTS `maxlife_tblfe_activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblfe_activity_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(45) NOT NULL,
  `staffid` int(11) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `note` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblfe_activity_log`
--

LOCK TABLES `maxlife_tblfe_activity_log` WRITE;
/*!40000 ALTER TABLE `maxlife_tblfe_activity_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblfe_activity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblfe_approval_details`
--

DROP TABLE IF EXISTS `maxlife_tblfe_approval_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblfe_approval_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(45) NOT NULL,
  `staffid` varchar(45) DEFAULT NULL,
  `approve` varchar(45) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `approve_action` varchar(255) DEFAULT NULL,
  `reject_action` varchar(255) DEFAULT NULL,
  `approve_value` varchar(255) DEFAULT NULL,
  `reject_value` varchar(255) DEFAULT NULL,
  `staff_approve` int(11) DEFAULT NULL,
  `action` varchar(45) DEFAULT NULL,
  `sender` int(11) DEFAULT NULL,
  `date_send` datetime DEFAULT NULL,
  `notification_recipient` longtext DEFAULT NULL,
  `approval_deadline` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblfe_approval_details`
--

LOCK TABLES `maxlife_tblfe_approval_details` WRITE;
/*!40000 ALTER TABLE `maxlife_tblfe_approval_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblfe_approval_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblfe_approval_setting`
--

DROP TABLE IF EXISTS `maxlife_tblfe_approval_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblfe_approval_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `related` varchar(255) NOT NULL,
  `setting` longtext NOT NULL,
  `choose_when_approving` int(11) NOT NULL DEFAULT 0,
  `notification_recipient` longtext DEFAULT NULL,
  `number_day_approval` int(11) DEFAULT NULL,
  `departments` text DEFAULT NULL,
  `job_positions` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblfe_approval_setting`
--

LOCK TABLES `maxlife_tblfe_approval_setting` WRITE;
/*!40000 ALTER TABLE `maxlife_tblfe_approval_setting` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblfe_approval_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblfe_asset_maintenances`
--

DROP TABLE IF EXISTS `maxlife_tblfe_asset_maintenances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblfe_asset_maintenances` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `asset_id` int(11) DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `maintenance_type` varchar(30) DEFAULT NULL,
  `title` varchar(250) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `completion_date` date DEFAULT NULL,
  `cost` decimal(15,2) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  `warranty_improvement` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblfe_asset_maintenances`
--

LOCK TABLES `maxlife_tblfe_asset_maintenances` WRITE;
/*!40000 ALTER TABLE `maxlife_tblfe_asset_maintenances` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblfe_asset_maintenances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblfe_asset_manufacturers`
--

DROP TABLE IF EXISTS `maxlife_tblfe_asset_manufacturers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblfe_asset_manufacturers` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `url` text DEFAULT NULL,
  `support_url` text DEFAULT NULL,
  `support_phone` varchar(50) DEFAULT NULL,
  `support_email` varchar(100) DEFAULT NULL,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  `creator_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblfe_asset_manufacturers`
--

LOCK TABLES `maxlife_tblfe_asset_manufacturers` WRITE;
/*!40000 ALTER TABLE `maxlife_tblfe_asset_manufacturers` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblfe_asset_manufacturers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblfe_assets`
--

DROP TABLE IF EXISTS `maxlife_tblfe_assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblfe_assets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `assets_code` varchar(20) DEFAULT NULL,
  `assets_name` varchar(255) DEFAULT NULL,
  `series` varchar(200) DEFAULT NULL,
  `asset_group` int(11) DEFAULT NULL,
  `asset_location` int(11) DEFAULT NULL,
  `model_id` int(11) DEFAULT NULL,
  `date_buy` date DEFAULT NULL,
  `warranty_period` int(11) DEFAULT NULL,
  `unit_price` decimal(15,2) DEFAULT NULL,
  `depreciation` int(11) DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `order_number` varchar(150) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `requestable` int(11) DEFAULT 0,
  `qr_code` varchar(300) DEFAULT NULL,
  `type` varchar(50) NOT NULL DEFAULT 'asset',
  `status` int(11) NOT NULL DEFAULT 1,
  `checkin_out` int(11) NOT NULL DEFAULT 1,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  `quantity` int(11) DEFAULT NULL,
  `min_quantity` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `product_key` text DEFAULT NULL,
  `seats` varchar(50) DEFAULT NULL,
  `model_no` varchar(80) DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `manufacturer_id` int(11) DEFAULT NULL,
  `licensed_to_name` text DEFAULT NULL,
  `licensed_to_email` text DEFAULT NULL,
  `reassignable` int(11) NOT NULL DEFAULT 0,
  `termination_date` date DEFAULT NULL,
  `expiration_date` date DEFAULT NULL,
  `purchase_order_number` varchar(150) DEFAULT NULL,
  `maintained` int(11) NOT NULL DEFAULT 0,
  `item_no` varchar(80) DEFAULT NULL,
  `checkin_out_id` int(11) DEFAULT NULL,
  `active` int(11) NOT NULL DEFAULT 1,
  `selling_price` decimal(15,2) NOT NULL DEFAULT 0.00,
  `rental_price` decimal(15,2) NOT NULL DEFAULT 0.00,
  `for_rent` int(11) NOT NULL DEFAULT 0,
  `for_sell` int(11) NOT NULL DEFAULT 0,
  `renting_period` decimal(15,2) DEFAULT NULL,
  `renting_unit` varchar(10) DEFAULT NULL COMMENT 'hour day week month year',
  `warehouse_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblfe_assets`
--

LOCK TABLES `maxlife_tblfe_assets` WRITE;
/*!40000 ALTER TABLE `maxlife_tblfe_assets` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblfe_assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblfe_assign_asset_predefined_kits`
--

DROP TABLE IF EXISTS `maxlife_tblfe_assign_asset_predefined_kits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblfe_assign_asset_predefined_kits` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) DEFAULT NULL,
  `assign_data` text DEFAULT '',
  `parent_id` int(11) DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblfe_assign_asset_predefined_kits`
--

LOCK TABLES `maxlife_tblfe_assign_asset_predefined_kits` WRITE;
/*!40000 ALTER TABLE `maxlife_tblfe_assign_asset_predefined_kits` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblfe_assign_asset_predefined_kits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblfe_audit_detail_requests`
--

DROP TABLE IF EXISTS `maxlife_tblfe_audit_detail_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblfe_audit_detail_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `asset_id` int(11) DEFAULT NULL,
  `asset_name` varchar(300) DEFAULT NULL,
  `type` varchar(30) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `adjusted` int(11) DEFAULT NULL,
  `accept` int(11) NOT NULL DEFAULT 0,
  `audit_id` int(11) DEFAULT NULL,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  `maintenance` int(11) NOT NULL DEFAULT 0,
  `maintenance_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblfe_audit_detail_requests`
--

LOCK TABLES `maxlife_tblfe_audit_detail_requests` WRITE;
/*!40000 ALTER TABLE `maxlife_tblfe_audit_detail_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblfe_audit_detail_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblfe_audit_requests`
--

DROP TABLE IF EXISTS `maxlife_tblfe_audit_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblfe_audit_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(300) DEFAULT NULL,
  `audit_date` datetime NOT NULL DEFAULT current_timestamp(),
  `auditor` int(11) DEFAULT NULL,
  `asset_location` int(11) DEFAULT NULL,
  `model_id` int(11) DEFAULT NULL,
  `asset_id` text DEFAULT NULL,
  `checkin_checkout_status` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `closed` int(11) NOT NULL DEFAULT 0,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  `from_order` int(11) DEFAULT NULL,
  `creator_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblfe_audit_requests`
--

LOCK TABLES `maxlife_tblfe_audit_requests` WRITE;
/*!40000 ALTER TABLE `maxlife_tblfe_audit_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblfe_audit_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblfe_cart`
--

DROP TABLE IF EXISTS `maxlife_tblfe_cart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblfe_cart` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_contact` int(11) NOT NULL,
  `name` varchar(120) NOT NULL,
  `address` varchar(250) NOT NULL,
  `phone_number` varchar(20) NOT NULL,
  `voucher` varchar(100) NOT NULL,
  `status` int(11) DEFAULT 0,
  `complete` int(11) DEFAULT 0,
  `order_number` varchar(100) DEFAULT NULL,
  `channel_id` int(11) DEFAULT NULL,
  `channel` varchar(150) DEFAULT NULL,
  `first_name` varchar(60) DEFAULT NULL,
  `last_name` varchar(60) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `hash` varchar(32) DEFAULT NULL,
  `tax_id` text DEFAULT NULL,
  `tax_rate` text DEFAULT NULL,
  `tax_name` text DEFAULT NULL,
  `unit_id` int(11) DEFAULT NULL,
  `unit_name` varchar(255) DEFAULT NULL,
  `add_discount` decimal(15,2) DEFAULT 0.00,
  `company` varchar(150) DEFAULT NULL,
  `phonenumber` varchar(15) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL,
  `zip` varchar(50) DEFAULT NULL,
  `billing_street` varchar(150) DEFAULT NULL,
  `billing_city` varchar(50) DEFAULT NULL,
  `billing_state` varchar(50) DEFAULT NULL,
  `billing_country` varchar(50) DEFAULT NULL,
  `billing_zip` varchar(50) DEFAULT NULL,
  `shipping_street` varchar(150) DEFAULT NULL,
  `shipping_city` varchar(50) DEFAULT NULL,
  `shipping_state` varchar(50) DEFAULT NULL,
  `shipping_country` varchar(50) DEFAULT NULL,
  `shipping_zip` varchar(50) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `reason` varchar(250) DEFAULT NULL,
  `admin_action` int(11) DEFAULT 0,
  `discount` varchar(250) DEFAULT NULL,
  `discount_type` int(11) DEFAULT 0,
  `total` varchar(250) DEFAULT NULL,
  `sub_total` varchar(250) DEFAULT NULL,
  `discount_total` decimal(15,2) NOT NULL DEFAULT 0.00,
  `invoice` varchar(250) NOT NULL DEFAULT '',
  `number_invoice` varchar(250) NOT NULL DEFAULT '',
  `stock_export_number` varchar(250) NOT NULL DEFAULT '',
  `create_invoice` varchar(5) NOT NULL DEFAULT 'off',
  `stock_export` varchar(5) NOT NULL DEFAULT 'off',
  `customers_pay` decimal(15,2) NOT NULL DEFAULT 0.00,
  `amount_returned` decimal(15,2) NOT NULL DEFAULT 0.00,
  `tax` decimal(15,2) NOT NULL DEFAULT 0.00,
  `seller` int(11) DEFAULT NULL,
  `staff_note` text DEFAULT NULL,
  `payment_note` text DEFAULT NULL,
  `allowed_payment_modes` varchar(200) DEFAULT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `shipping` decimal(15,2) NOT NULL DEFAULT 0.00,
  `payment_method_title` varchar(250) DEFAULT NULL,
  `discount_type_str` text DEFAULT NULL,
  `discount_percent` decimal(15,2) DEFAULT NULL,
  `adjustment` decimal(15,2) DEFAULT NULL,
  `currency` int(11) DEFAULT NULL,
  `terms` text DEFAULT NULL,
  `shipping_tax` decimal(15,2) DEFAULT NULL,
  `enable` int(11) NOT NULL DEFAULT 1,
  `duedate` date DEFAULT NULL,
  `shipping_tax_json` varchar(150) DEFAULT NULL,
  `discount_voucher` varchar(150) DEFAULT NULL,
  `original_order_id` int(11) DEFAULT NULL,
  `return_reason` longtext DEFAULT NULL,
  `approve_status` int(11) NOT NULL DEFAULT 0,
  `process_invoice` varchar(5) NOT NULL DEFAULT 'off',
  `stock_import_number` int(11) NOT NULL DEFAULT 0,
  `fee_for_return_order` decimal(15,2) DEFAULT NULL,
  `estimate_id` int(11) DEFAULT NULL,
  `shipping_form` varchar(50) DEFAULT 'fixed',
  `shipping_value` decimal(15,2) DEFAULT 0.00,
  `type` varchar(30) NOT NULL DEFAULT 'order',
  `datecreator` datetime NOT NULL DEFAULT current_timestamp(),
  `return_reason_type` varchar(50) DEFAULT NULL,
  `return_type` varchar(30) DEFAULT NULL,
  `audit_id` int(11) DEFAULT NULL,
  `maintenance_id` int(11) DEFAULT NULL,
  `credit_note_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblfe_cart`
--

LOCK TABLES `maxlife_tblfe_cart` WRITE;
/*!40000 ALTER TABLE `maxlife_tblfe_cart` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblfe_cart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblfe_cart_detailt`
--

DROP TABLE IF EXISTS `maxlife_tblfe_cart_detailt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblfe_cart_detailt` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `classify` varchar(30) DEFAULT NULL,
  `cart_id` int(11) NOT NULL,
  `product_name` varchar(150) DEFAULT NULL,
  `prices` decimal(15,2) DEFAULT NULL,
  `long_description` text DEFAULT NULL,
  `sku` text NOT NULL,
  `percent_discount` float NOT NULL,
  `prices_discount` decimal(15,2) NOT NULL,
  `tax` text DEFAULT NULL,
  `tax_id` text DEFAULT NULL,
  `tax_rate` text DEFAULT NULL,
  `tax_name` text DEFAULT NULL,
  `unit_id` int(11) DEFAULT NULL,
  `unit_name` varchar(255) DEFAULT NULL,
  `pickup_time` varchar(10) DEFAULT NULL,
  `dropoff_time` varchar(10) DEFAULT NULL,
  `rental_start_date` date DEFAULT NULL,
  `rental_end_date` date DEFAULT NULL,
  `number_date` int(11) DEFAULT NULL,
  `rental_value` decimal(15,2) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `renting_period` decimal(15,2) DEFAULT NULL,
  `renting_unit` varchar(10) DEFAULT NULL COMMENT 'hour day week month year',
  `maintenance_id` int(11) DEFAULT NULL,
  `estimate_id` int(11) DEFAULT NULL,
  `available_quantity` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblfe_cart_detailt`
--

LOCK TABLES `maxlife_tblfe_cart_detailt` WRITE;
/*!40000 ALTER TABLE `maxlife_tblfe_cart_detailt` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblfe_cart_detailt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblfe_categories`
--

DROP TABLE IF EXISTS `maxlife_tblfe_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblfe_categories` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `category_name` varchar(200) NOT NULL,
  `type` varchar(30) DEFAULT NULL,
  `category_eula` text DEFAULT NULL,
  `primary_default_eula` bit(1) NOT NULL DEFAULT b'0',
  `confirm_acceptance` bit(1) NOT NULL DEFAULT b'0',
  `send_mail_to_user` bit(1) NOT NULL DEFAULT b'0',
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  `creator_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblfe_categories`
--

LOCK TABLES `maxlife_tblfe_categories` WRITE;
/*!40000 ALTER TABLE `maxlife_tblfe_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblfe_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblfe_checkin_assets`
--

DROP TABLE IF EXISTS `maxlife_tblfe_checkin_assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblfe_checkin_assets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `model` varchar(200) DEFAULT NULL,
  `asset_name` varchar(200) DEFAULT NULL,
  `item_id` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `checkout_to` varchar(20) DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `asset_id` int(11) DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `checkin_date` date DEFAULT NULL,
  `expected_checkin_date` date DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  `check_status` int(11) NOT NULL DEFAULT 2,
  `requestable` int(11) NOT NULL DEFAULT 0,
  `request_status` int(11) NOT NULL DEFAULT 0,
  `request_title` varchar(300) DEFAULT NULL,
  `predefined_kit_id` int(11) DEFAULT NULL,
  `item_type` varchar(30) DEFAULT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `creator_id` int(11) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblfe_checkin_assets`
--

LOCK TABLES `maxlife_tblfe_checkin_assets` WRITE;
/*!40000 ALTER TABLE `maxlife_tblfe_checkin_assets` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblfe_checkin_assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblfe_cron_log`
--

DROP TABLE IF EXISTS `maxlife_tblfe_cron_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblfe_cron_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  `cron_name` varchar(200) DEFAULT NULL,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblfe_cron_log`
--

LOCK TABLES `maxlife_tblfe_cron_log` WRITE;
/*!40000 ALTER TABLE `maxlife_tblfe_cron_log` DISABLE KEYS */;
INSERT INTO `maxlife_tblfe_cron_log` VALUES (1,'2025-07-13 00:00:00','auto_depreciation',0,'');
/*!40000 ALTER TABLE `maxlife_tblfe_cron_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblfe_custom_field_values`
--

DROP TABLE IF EXISTS `maxlife_tblfe_custom_field_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblfe_custom_field_values` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(300) DEFAULT NULL,
  `type` varchar(30) DEFAULT NULL,
  `option` text DEFAULT NULL,
  `required` int(11) NOT NULL DEFAULT 1,
  `value` text DEFAULT NULL,
  `fieldset_id` int(11) NOT NULL,
  `custom_field_id` int(11) NOT NULL,
  `asset_id` int(11) NOT NULL,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblfe_custom_field_values`
--

LOCK TABLES `maxlife_tblfe_custom_field_values` WRITE;
/*!40000 ALTER TABLE `maxlife_tblfe_custom_field_values` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblfe_custom_field_values` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblfe_custom_fields`
--

DROP TABLE IF EXISTS `maxlife_tblfe_custom_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblfe_custom_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(300) DEFAULT NULL,
  `type` varchar(30) DEFAULT NULL,
  `option` text DEFAULT NULL,
  `required` int(11) NOT NULL DEFAULT 1,
  `default_value` text DEFAULT NULL,
  `fieldset_id` int(11) NOT NULL,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblfe_custom_fields`
--

LOCK TABLES `maxlife_tblfe_custom_fields` WRITE;
/*!40000 ALTER TABLE `maxlife_tblfe_custom_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblfe_custom_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblfe_depreciation_items`
--

DROP TABLE IF EXISTS `maxlife_tblfe_depreciation_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblfe_depreciation_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL,
  `value` float DEFAULT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblfe_depreciation_items`
--

LOCK TABLES `maxlife_tblfe_depreciation_items` WRITE;
/*!40000 ALTER TABLE `maxlife_tblfe_depreciation_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblfe_depreciation_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblfe_depreciations`
--

DROP TABLE IF EXISTS `maxlife_tblfe_depreciations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblfe_depreciations` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `term` double DEFAULT NULL,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  `creator_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblfe_depreciations`
--

LOCK TABLES `maxlife_tblfe_depreciations` WRITE;
/*!40000 ALTER TABLE `maxlife_tblfe_depreciations` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblfe_depreciations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblfe_fieldsets`
--

DROP TABLE IF EXISTS `maxlife_tblfe_fieldsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblfe_fieldsets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(300) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  `creator_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblfe_fieldsets`
--

LOCK TABLES `maxlife_tblfe_fieldsets` WRITE;
/*!40000 ALTER TABLE `maxlife_tblfe_fieldsets` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblfe_fieldsets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblfe_goods_delivery`
--

DROP TABLE IF EXISTS `maxlife_tblfe_goods_delivery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblfe_goods_delivery` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rel_type` int(11) DEFAULT NULL COMMENT 'type goods delivery',
  `rel_document` int(11) DEFAULT NULL COMMENT 'document id of goods delivery',
  `customer_code` text DEFAULT NULL,
  `customer_name` varchar(100) DEFAULT NULL,
  `to_` varchar(100) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL COMMENT 'the reason delivery',
  `staff_id` int(11) DEFAULT NULL COMMENT 'salesman',
  `date_c` date DEFAULT NULL,
  `date_add` date DEFAULT NULL,
  `goods_delivery_code` varchar(100) DEFAULT NULL COMMENT 'số chứng từ xuất kho',
  `approval` int(11) DEFAULT 0 COMMENT 'status approval ',
  `addedfrom` int(11) DEFAULT NULL,
  `total_money` varchar(200) DEFAULT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `total_discount` varchar(100) DEFAULT NULL,
  `after_discount` varchar(100) DEFAULT NULL,
  `invoice_id` varchar(100) DEFAULT NULL,
  `project` text DEFAULT NULL,
  `type` text DEFAULT NULL,
  `department` int(11) DEFAULT NULL,
  `requester` int(11) DEFAULT NULL,
  `invoice_no` text DEFAULT NULL,
  `pr_order_id` int(11) DEFAULT NULL,
  `type_of_delivery` varchar(100) DEFAULT 'total',
  `additional_discount` decimal(15,2) DEFAULT 0.00,
  `sub_total` decimal(15,2) DEFAULT 0.00,
  `delivery_status` varchar(100) DEFAULT 'ready_for_packing',
  `shipping_fee` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblfe_goods_delivery`
--

LOCK TABLES `maxlife_tblfe_goods_delivery` WRITE;
/*!40000 ALTER TABLE `maxlife_tblfe_goods_delivery` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblfe_goods_delivery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblfe_goods_delivery_activity_log`
--

DROP TABLE IF EXISTS `maxlife_tblfe_goods_delivery_activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblfe_goods_delivery_activity_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(100) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `additional_data` text DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `staffid` int(11) DEFAULT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblfe_goods_delivery_activity_log`
--

LOCK TABLES `maxlife_tblfe_goods_delivery_activity_log` WRITE;
/*!40000 ALTER TABLE `maxlife_tblfe_goods_delivery_activity_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblfe_goods_delivery_activity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblfe_goods_delivery_detail`
--

DROP TABLE IF EXISTS `maxlife_tblfe_goods_delivery_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblfe_goods_delivery_detail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `goods_delivery_id` int(11) NOT NULL,
  `commodity_code` varchar(100) DEFAULT NULL,
  `commodity_name` text DEFAULT NULL,
  `warehouse_id` text DEFAULT NULL,
  `unit_id` text DEFAULT NULL,
  `quantities` text DEFAULT NULL,
  `unit_price` varchar(100) DEFAULT NULL,
  `total_money` varchar(200) DEFAULT NULL,
  `discount` varchar(100) DEFAULT NULL,
  `discount_money` varchar(100) DEFAULT NULL,
  `available_quantity` varchar(100) DEFAULT NULL,
  `tax_id` varchar(100) DEFAULT NULL,
  `total_after_discount` varchar(100) DEFAULT NULL,
  `expiry_date` text DEFAULT NULL,
  `lot_number` text DEFAULT NULL,
  `guarantee_period` text DEFAULT NULL,
  `tax_rate` text DEFAULT NULL,
  `tax_name` text DEFAULT NULL,
  `sub_total` decimal(15,2) DEFAULT 0.00,
  `packing_qty` decimal(15,2) DEFAULT 0.00,
  `serial_number` varchar(255) DEFAULT NULL,
  `note` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblfe_goods_delivery_detail`
--

LOCK TABLES `maxlife_tblfe_goods_delivery_detail` WRITE;
/*!40000 ALTER TABLE `maxlife_tblfe_goods_delivery_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblfe_goods_delivery_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblfe_goods_delivery_invoices_pr_orders`
--

DROP TABLE IF EXISTS `maxlife_tblfe_goods_delivery_invoices_pr_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblfe_goods_delivery_invoices_pr_orders` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) DEFAULT NULL COMMENT 'goods_delivery_id',
  `rel_type` int(11) DEFAULT NULL COMMENT 'invoice_id or purchase order id',
  `type` varchar(100) DEFAULT NULL COMMENT 'invoice,  purchase_orders',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblfe_goods_delivery_invoices_pr_orders`
--

LOCK TABLES `maxlife_tblfe_goods_delivery_invoices_pr_orders` WRITE;
/*!40000 ALTER TABLE `maxlife_tblfe_goods_delivery_invoices_pr_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblfe_goods_delivery_invoices_pr_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblfe_goods_receipt`
--

DROP TABLE IF EXISTS `maxlife_tblfe_goods_receipt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblfe_goods_receipt` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `supplier_code` varchar(100) DEFAULT NULL,
  `supplier_name` text DEFAULT NULL,
  `deliver_name` text DEFAULT NULL,
  `buyer_id` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `pr_order_id` int(11) DEFAULT NULL COMMENT 'code puchase request agree',
  `date_c` date DEFAULT NULL,
  `date_add` date DEFAULT NULL,
  `goods_receipt_code` varchar(100) DEFAULT NULL,
  `total_tax_money` varchar(100) DEFAULT NULL,
  `total_goods_money` varchar(100) DEFAULT NULL,
  `value_of_inventory` varchar(100) DEFAULT NULL,
  `invoice_no` text DEFAULT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `total_money` varchar(100) DEFAULT NULL COMMENT 'total_money = total_tax_money +total_goods_money ',
  `approval` int(11) DEFAULT 0,
  `addedfrom` int(11) DEFAULT NULL,
  `from_order` int(11) DEFAULT NULL,
  `creator_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblfe_goods_receipt`
--

LOCK TABLES `maxlife_tblfe_goods_receipt` WRITE;
/*!40000 ALTER TABLE `maxlife_tblfe_goods_receipt` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblfe_goods_receipt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblfe_goods_receipt_detail`
--

DROP TABLE IF EXISTS `maxlife_tblfe_goods_receipt_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblfe_goods_receipt_detail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `goods_receipt_id` int(11) NOT NULL,
  `commodity_code` varchar(100) DEFAULT NULL,
  `commodity_name` text DEFAULT NULL,
  `warehouse_id` text DEFAULT NULL,
  `unit_id` text DEFAULT NULL,
  `quantities` text DEFAULT NULL,
  `unit_price` varchar(100) DEFAULT NULL,
  `tax` varchar(100) DEFAULT NULL,
  `tax_money` varchar(100) DEFAULT NULL,
  `goods_money` varchar(100) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `tax_name` text DEFAULT NULL,
  `sub_total` decimal(15,2) DEFAULT 0.00,
  `tax_rate` text DEFAULT NULL,
  `serial_number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblfe_goods_receipt_detail`
--

LOCK TABLES `maxlife_tblfe_goods_receipt_detail` WRITE;
/*!40000 ALTER TABLE `maxlife_tblfe_goods_receipt_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblfe_goods_receipt_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblfe_goods_transaction_detail`
--

DROP TABLE IF EXISTS `maxlife_tblfe_goods_transaction_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblfe_goods_transaction_detail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `goods_receipt_id` int(11) DEFAULT NULL COMMENT 'id_goods_receipt_id or goods_delivery_id',
  `goods_id` int(11) NOT NULL COMMENT ' is id commodity',
  `quantity` varchar(100) DEFAULT NULL,
  `date_add` datetime DEFAULT NULL,
  `commodity_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `note` text DEFAULT NULL,
  `status` int(2) DEFAULT NULL COMMENT '1:Goods receipt note 2:Goods delivery note',
  `old_quantity` varchar(100) DEFAULT NULL,
  `purchase_price` varchar(100) DEFAULT NULL,
  `price` varchar(100) DEFAULT NULL,
  `expiry_date` text DEFAULT NULL,
  `lot_number` text DEFAULT NULL,
  `from_stock_name` int(11) DEFAULT NULL,
  `to_stock_name` int(11) DEFAULT NULL,
  `serial_number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`,`commodity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblfe_goods_transaction_detail`
--

LOCK TABLES `maxlife_tblfe_goods_transaction_detail` WRITE;
/*!40000 ALTER TABLE `maxlife_tblfe_goods_transaction_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblfe_goods_transaction_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblfe_goods_transaction_details`
--

DROP TABLE IF EXISTS `maxlife_tblfe_goods_transaction_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblfe_goods_transaction_details` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rel_type` varchar(100) DEFAULT NULL COMMENT 'goods_receipt or goods_delivery or loss_adjustment or internal_delivery',
  `rel_id` int(11) NOT NULL COMMENT ' goods_receipt_id or goods_delivery_id or loss_adjustment_id or internal_delivery_id',
  `rel_id_detail` int(11) NOT NULL COMMENT ' goods_receipt_id or goods_delivery_id or loss_adjustment_id or internal_delivery_id',
  `item_id` int(11) NOT NULL,
  `old_quantity` decimal(15,2) DEFAULT 0.00,
  `quantity` decimal(15,2) DEFAULT 0.00,
  `rate` decimal(15,2) DEFAULT 0.00,
  `expiry_date` date DEFAULT NULL,
  `lot_number` text DEFAULT NULL,
  `from_warehouse_id` int(11) DEFAULT NULL,
  `to_warehouse_id` int(11) DEFAULT NULL,
  `date_add` datetime DEFAULT NULL,
  `added_from_id` int(11) DEFAULT NULL,
  `added_from_type` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblfe_goods_transaction_details`
--

LOCK TABLES `maxlife_tblfe_goods_transaction_details` WRITE;
/*!40000 ALTER TABLE `maxlife_tblfe_goods_transaction_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblfe_goods_transaction_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblfe_locations`
--

DROP TABLE IF EXISTS `maxlife_tblfe_locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblfe_locations` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `location_name` varchar(200) NOT NULL,
  `parent` int(11) DEFAULT NULL,
  `manager` int(11) DEFAULT NULL,
  `location_currency` varchar(50) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL,
  `zip` varchar(50) DEFAULT NULL,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblfe_locations`
--

LOCK TABLES `maxlife_tblfe_locations` WRITE;
/*!40000 ALTER TABLE `maxlife_tblfe_locations` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblfe_locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblfe_log_assets`
--

DROP TABLE IF EXISTS `maxlife_tblfe_log_assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblfe_log_assets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_id` int(11) DEFAULT NULL,
  `action` varchar(200) DEFAULT NULL,
  `item_id` int(11) DEFAULT NULL,
  `target` varchar(200) DEFAULT NULL,
  `changed` varchar(200) DEFAULT NULL,
  `to` varchar(20) DEFAULT NULL,
  `to_id` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblfe_log_assets`
--

LOCK TABLES `maxlife_tblfe_log_assets` WRITE;
/*!40000 ALTER TABLE `maxlife_tblfe_log_assets` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblfe_log_assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblfe_model_predefined_kits`
--

DROP TABLE IF EXISTS `maxlife_tblfe_model_predefined_kits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblfe_model_predefined_kits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `model_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblfe_model_predefined_kits`
--

LOCK TABLES `maxlife_tblfe_model_predefined_kits` WRITE;
/*!40000 ALTER TABLE `maxlife_tblfe_model_predefined_kits` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblfe_model_predefined_kits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblfe_models`
--

DROP TABLE IF EXISTS `maxlife_tblfe_models`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblfe_models` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `model_name` varchar(200) NOT NULL,
  `manufacturer` int(11) DEFAULT NULL,
  `category` int(11) DEFAULT NULL,
  `model_no` varchar(200) DEFAULT NULL,
  `depreciation` int(11) DEFAULT NULL,
  `eol` int(11) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `custom_field` text DEFAULT NULL,
  `may_request` bit(1) NOT NULL DEFAULT b'0',
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  `fieldset_id` int(11) DEFAULT NULL,
  `creator_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblfe_models`
--

LOCK TABLES `maxlife_tblfe_models` WRITE;
/*!40000 ALTER TABLE `maxlife_tblfe_models` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblfe_models` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblfe_omni_shipments`
--

DROP TABLE IF EXISTS `maxlife_tblfe_omni_shipments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblfe_omni_shipments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cart_id` int(11) DEFAULT NULL,
  `goods_delivery_id` int(11) DEFAULT NULL,
  `shipment_hash` varchar(32) DEFAULT NULL,
  `order_id` int(11) DEFAULT 0,
  `shipment_number` varchar(100) DEFAULT NULL,
  `planned_shipping_date` datetime DEFAULT NULL,
  `shipment_status` varchar(50) DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblfe_omni_shipments`
--

LOCK TABLES `maxlife_tblfe_omni_shipments` WRITE;
/*!40000 ALTER TABLE `maxlife_tblfe_omni_shipments` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblfe_omni_shipments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblfe_packing_list_details`
--

DROP TABLE IF EXISTS `maxlife_tblfe_packing_list_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblfe_packing_list_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `packing_list_id` int(11) NOT NULL,
  `delivery_detail_id` int(11) DEFAULT NULL,
  `commodity_code` int(11) DEFAULT NULL,
  `commodity_name` text DEFAULT NULL,
  `quantity` decimal(15,2) DEFAULT 0.00,
  `unit_id` int(11) DEFAULT NULL,
  `unit_price` decimal(15,2) DEFAULT 0.00,
  `sub_total` decimal(15,2) DEFAULT 0.00,
  `tax_id` text DEFAULT NULL,
  `tax_rate` text DEFAULT NULL,
  `tax_name` text DEFAULT NULL,
  `total_amount` decimal(15,2) DEFAULT 0.00,
  `discount` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `total_after_discount` decimal(15,2) DEFAULT 0.00,
  `serial_number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblfe_packing_list_details`
--

LOCK TABLES `maxlife_tblfe_packing_list_details` WRITE;
/*!40000 ALTER TABLE `maxlife_tblfe_packing_list_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblfe_packing_list_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblfe_packing_lists`
--

DROP TABLE IF EXISTS `maxlife_tblfe_packing_lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblfe_packing_lists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `delivery_note_id` int(11) DEFAULT NULL,
  `packing_list_number` varchar(100) DEFAULT NULL,
  `packing_list_name` varchar(200) DEFAULT NULL,
  `width` decimal(15,2) DEFAULT 0.00,
  `height` decimal(15,2) DEFAULT 0.00,
  `lenght` decimal(15,2) DEFAULT 0.00,
  `weight` decimal(15,2) DEFAULT 0.00,
  `volume` decimal(15,2) DEFAULT 0.00,
  `clientid` int(11) DEFAULT NULL,
  `subtotal` decimal(15,2) DEFAULT 0.00,
  `total_amount` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `additional_discount` decimal(15,2) DEFAULT 0.00,
  `total_after_discount` decimal(15,2) DEFAULT 0.00,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT NULL,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT NULL,
  `client_note` text DEFAULT NULL,
  `admin_note` text DEFAULT NULL,
  `approval` int(11) DEFAULT 0,
  `datecreated` datetime DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `type_of_packing_list` varchar(100) DEFAULT 'total',
  `delivery_status` varchar(100) DEFAULT 'wh_ready_to_deliver',
  `shipping_fee` decimal(15,2) DEFAULT 0.00,
  `sales_order_reference` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblfe_packing_lists`
--

LOCK TABLES `maxlife_tblfe_packing_lists` WRITE;
/*!40000 ALTER TABLE `maxlife_tblfe_packing_lists` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblfe_packing_lists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblfe_refunds`
--

DROP TABLE IF EXISTS `maxlife_tblfe_refunds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblfe_refunds` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(11) DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `refunded_on` date DEFAULT NULL,
  `payment_mode` varchar(40) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `amount` decimal(15,2) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblfe_refunds`
--

LOCK TABLES `maxlife_tblfe_refunds` WRITE;
/*!40000 ALTER TABLE `maxlife_tblfe_refunds` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblfe_refunds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblfe_seats`
--

DROP TABLE IF EXISTS `maxlife_tblfe_seats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblfe_seats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `seat_name` varchar(200) DEFAULT NULL,
  `to` varchar(20) DEFAULT NULL,
  `to_id` int(11) DEFAULT NULL,
  `license_id` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  `warehouse_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblfe_seats`
--

LOCK TABLES `maxlife_tblfe_seats` WRITE;
/*!40000 ALTER TABLE `maxlife_tblfe_seats` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblfe_seats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblfe_sign_documents`
--

DROP TABLE IF EXISTS `maxlife_tblfe_sign_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblfe_sign_documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `checkin_out_id` text DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `check_to_staff` int(11) DEFAULT NULL,
  `reference` varchar(30) DEFAULT NULL,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblfe_sign_documents`
--

LOCK TABLES `maxlife_tblfe_sign_documents` WRITE;
/*!40000 ALTER TABLE `maxlife_tblfe_sign_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblfe_sign_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblfe_signers`
--

DROP TABLE IF EXISTS `maxlife_tblfe_signers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblfe_signers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sign_document_id` int(11) DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `ip_address` varchar(100) DEFAULT NULL,
  `date_of_signing` datetime DEFAULT NULL,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  `firstname` varchar(50) DEFAULT NULL,
  `lastname` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblfe_signers`
--

LOCK TABLES `maxlife_tblfe_signers` WRITE;
/*!40000 ALTER TABLE `maxlife_tblfe_signers` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblfe_signers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblfe_status_labels`
--

DROP TABLE IF EXISTS `maxlife_tblfe_status_labels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblfe_status_labels` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `status_type` varchar(30) NOT NULL,
  `chart_color` varchar(30) NOT NULL,
  `note` text DEFAULT NULL,
  `show_in_side_nav` bit(1) NOT NULL DEFAULT b'0',
  `default_label` bit(1) NOT NULL DEFAULT b'0',
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  `creator_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblfe_status_labels`
--

LOCK TABLES `maxlife_tblfe_status_labels` WRITE;
/*!40000 ALTER TABLE `maxlife_tblfe_status_labels` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblfe_status_labels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblfe_suppliers`
--

DROP TABLE IF EXISTS `maxlife_tblfe_suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblfe_suppliers` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `supplier_name` varchar(200) NOT NULL,
  `address` text DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL,
  `zip` varchar(50) DEFAULT NULL,
  `contact_name` varchar(200) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `fax` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `url` text DEFAULT NULL,
  `note` text DEFAULT NULL,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  `creator_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblfe_suppliers`
--

LOCK TABLES `maxlife_tblfe_suppliers` WRITE;
/*!40000 ALTER TABLE `maxlife_tblfe_suppliers` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblfe_suppliers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblfe_ticket_action_post_internal_notes`
--

DROP TABLE IF EXISTS `maxlife_tblfe_ticket_action_post_internal_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblfe_ticket_action_post_internal_notes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_id` int(11) DEFAULT NULL,
  `note_title` text DEFAULT NULL,
  `note_details` text DEFAULT NULL,
  `ticket_status` text DEFAULT NULL COMMENT 'select workflow progess Resolved Closed',
  `resolution` text DEFAULT NULL COMMENT 'Set Reply as Resolution if you want the message entered fix issue',
  `created_type` varchar(20) DEFAULT 'staff',
  `datecreated` datetime DEFAULT NULL,
  `dateupdated` datetime DEFAULT NULL,
  `staffid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblfe_ticket_action_post_internal_notes`
--

LOCK TABLES `maxlife_tblfe_ticket_action_post_internal_notes` WRITE;
/*!40000 ALTER TABLE `maxlife_tblfe_ticket_action_post_internal_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblfe_ticket_action_post_internal_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblfe_ticket_timeline_logs`
--

DROP TABLE IF EXISTS `maxlife_tblfe_ticket_timeline_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblfe_ticket_timeline_logs` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(100) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `additional_data` text DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `staffid` int(11) DEFAULT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `from_date` datetime DEFAULT NULL,
  `to_date` datetime DEFAULT NULL,
  `duration` decimal(15,2) DEFAULT 0.00,
  `created_type` varchar(200) DEFAULT 'System',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblfe_ticket_timeline_logs`
--

LOCK TABLES `maxlife_tblfe_ticket_timeline_logs` WRITE;
/*!40000 ALTER TABLE `maxlife_tblfe_ticket_timeline_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblfe_ticket_timeline_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblfe_tickets`
--

DROP TABLE IF EXISTS `maxlife_tblfe_tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblfe_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_id` int(11) DEFAULT NULL,
  `created_type` varchar(20) DEFAULT 'staff',
  `client_id` int(11) DEFAULT NULL,
  `cart_id` int(11) DEFAULT NULL,
  `asset_id` int(11) DEFAULT NULL,
  `ticket_source` text DEFAULT NULL,
  `assigned_id` int(11) DEFAULT NULL,
  `time_spent` decimal(15,2) DEFAULT NULL,
  `due_date` datetime DEFAULT NULL,
  `code` text DEFAULT NULL,
  `ticket_subject` text DEFAULT NULL,
  `issue_summary` text DEFAULT NULL,
  `priority_level` text DEFAULT NULL,
  `ticket_type` text DEFAULT NULL,
  `internal_note` text DEFAULT NULL,
  `last_message_time` datetime DEFAULT NULL,
  `last_response_time` datetime DEFAULT NULL,
  `first_reply_time` datetime DEFAULT NULL,
  `last_update_time` datetime DEFAULT NULL,
  `resolution` longtext DEFAULT NULL,
  `status` text DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `dateupdated` datetime DEFAULT NULL,
  `staffid` int(11) DEFAULT NULL,
  `model_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblfe_tickets`
--

LOCK TABLES `maxlife_tblfe_tickets` WRITE;
/*!40000 ALTER TABLE `maxlife_tblfe_tickets` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblfe_tickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblfe_warehouse`
--

DROP TABLE IF EXISTS `maxlife_tblfe_warehouse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblfe_warehouse` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(100) DEFAULT NULL,
  `name` text DEFAULT NULL,
  `address` text DEFAULT NULL,
  `city` text DEFAULT NULL,
  `state` text DEFAULT NULL,
  `zip_code` text DEFAULT NULL,
  `country` text DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  `display` int(1) DEFAULT NULL COMMENT 'display 1: display (yes)  0: not displayed (no)',
  `note` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblfe_warehouse`
--

LOCK TABLES `maxlife_tblfe_warehouse` WRITE;
/*!40000 ALTER TABLE `maxlife_tblfe_warehouse` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblfe_warehouse` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblfiles`
--

DROP TABLE IF EXISTS `maxlife_tblfiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblfiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) NOT NULL,
  `file_name` varchar(191) NOT NULL,
  `filetype` varchar(40) DEFAULT NULL,
  `visible_to_customer` int(11) NOT NULL DEFAULT 0,
  `attachment_key` varchar(32) DEFAULT NULL,
  `external` varchar(40) DEFAULT NULL,
  `external_link` mediumtext DEFAULT NULL,
  `thumbnail_link` mediumtext DEFAULT NULL COMMENT 'For external usage',
  `staffid` int(11) NOT NULL,
  `contact_id` int(11) DEFAULT 0,
  `task_comment_id` int(11) NOT NULL DEFAULT 0,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblfiles`
--

LOCK TABLES `maxlife_tblfiles` WRITE;
/*!40000 ALTER TABLE `maxlife_tblfiles` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblfiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblfilter_defaults`
--

DROP TABLE IF EXISTS `maxlife_tblfilter_defaults`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblfilter_defaults` (
  `filter_id` int(10) unsigned NOT NULL,
  `staff_id` int(11) NOT NULL,
  `identifier` varchar(191) NOT NULL,
  `view` varchar(191) NOT NULL,
  KEY `filter_id` (`filter_id`),
  KEY `maxlife_staff_id` (`staff_id`),
  CONSTRAINT `maxlife_tblfilter_defaults_ibfk_1` FOREIGN KEY (`filter_id`) REFERENCES `maxlife_tblfilters` (`id`) ON DELETE CASCADE,
  CONSTRAINT `maxlife_tblfilter_defaults_ibfk_2` FOREIGN KEY (`staff_id`) REFERENCES `maxlife_tblstaff` (`staffid`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblfilter_defaults`
--

LOCK TABLES `maxlife_tblfilter_defaults` WRITE;
/*!40000 ALTER TABLE `maxlife_tblfilter_defaults` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblfilter_defaults` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblfilters`
--

DROP TABLE IF EXISTS `maxlife_tblfilters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblfilters` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `builder` mediumtext NOT NULL,
  `staff_id` int(10) unsigned NOT NULL,
  `identifier` varchar(191) NOT NULL,
  `is_shared` tinyint(3) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblfilters`
--

LOCK TABLES `maxlife_tblfilters` WRITE;
/*!40000 ALTER TABLE `maxlife_tblfilters` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblfilters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblform_question_box`
--

DROP TABLE IF EXISTS `maxlife_tblform_question_box`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblform_question_box` (
  `boxid` int(11) NOT NULL AUTO_INCREMENT,
  `boxtype` varchar(10) NOT NULL,
  `questionid` int(11) NOT NULL,
  PRIMARY KEY (`boxid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblform_question_box`
--

LOCK TABLES `maxlife_tblform_question_box` WRITE;
/*!40000 ALTER TABLE `maxlife_tblform_question_box` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblform_question_box` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblform_question_box_description`
--

DROP TABLE IF EXISTS `maxlife_tblform_question_box_description`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblform_question_box_description` (
  `questionboxdescriptionid` int(11) NOT NULL AUTO_INCREMENT,
  `description` longtext NOT NULL,
  `boxid` longtext NOT NULL,
  `questionid` int(11) NOT NULL,
  PRIMARY KEY (`questionboxdescriptionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblform_question_box_description`
--

LOCK TABLES `maxlife_tblform_question_box_description` WRITE;
/*!40000 ALTER TABLE `maxlife_tblform_question_box_description` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblform_question_box_description` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblform_questions`
--

DROP TABLE IF EXISTS `maxlife_tblform_questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblform_questions` (
  `questionid` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) DEFAULT NULL,
  `question` longtext NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT 0,
  `question_order` int(11) NOT NULL,
  PRIMARY KEY (`questionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblform_questions`
--

LOCK TABLES `maxlife_tblform_questions` WRITE;
/*!40000 ALTER TABLE `maxlife_tblform_questions` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblform_questions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblform_results`
--

DROP TABLE IF EXISTS `maxlife_tblform_results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblform_results` (
  `resultid` int(11) NOT NULL AUTO_INCREMENT,
  `boxid` int(11) NOT NULL,
  `boxdescriptionid` int(11) DEFAULT NULL,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) DEFAULT NULL,
  `questionid` int(11) NOT NULL,
  `answer` mediumtext DEFAULT NULL,
  `resultsetid` int(11) NOT NULL,
  PRIMARY KEY (`resultid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblform_results`
--

LOCK TABLES `maxlife_tblform_results` WRITE;
/*!40000 ALTER TABLE `maxlife_tblform_results` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblform_results` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblgdpr_requests`
--

DROP TABLE IF EXISTS `maxlife_tblgdpr_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblgdpr_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clientid` int(11) NOT NULL DEFAULT 0,
  `contact_id` int(11) NOT NULL DEFAULT 0,
  `lead_id` int(11) NOT NULL DEFAULT 0,
  `request_type` varchar(191) DEFAULT NULL,
  `status` varchar(40) DEFAULT NULL,
  `request_date` datetime NOT NULL,
  `request_from` varchar(150) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblgdpr_requests`
--

LOCK TABLES `maxlife_tblgdpr_requests` WRITE;
/*!40000 ALTER TABLE `maxlife_tblgdpr_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblgdpr_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblgoals`
--

DROP TABLE IF EXISTS `maxlife_tblgoals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblgoals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(191) NOT NULL,
  `description` text NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `goal_type` int(11) NOT NULL,
  `contract_type` int(11) NOT NULL DEFAULT 0,
  `achievement` int(11) NOT NULL,
  `notify_when_fail` tinyint(1) NOT NULL DEFAULT 1,
  `notify_when_achieve` tinyint(1) NOT NULL DEFAULT 1,
  `notified` int(11) NOT NULL DEFAULT 0,
  `staff_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `staff_id` (`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblgoals`
--

LOCK TABLES `maxlife_tblgoals` WRITE;
/*!40000 ALTER TABLE `maxlife_tblgoals` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblgoals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblinvoicepaymentrecords`
--

DROP TABLE IF EXISTS `maxlife_tblinvoicepaymentrecords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblinvoicepaymentrecords` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoiceid` int(11) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `paymentmode` varchar(40) DEFAULT NULL,
  `paymentmethod` varchar(191) DEFAULT NULL,
  `date` date NOT NULL,
  `daterecorded` datetime NOT NULL,
  `note` mediumtext DEFAULT NULL,
  `transactionid` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `invoiceid` (`invoiceid`),
  KEY `paymentmethod` (`paymentmethod`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblinvoicepaymentrecords`
--

LOCK TABLES `maxlife_tblinvoicepaymentrecords` WRITE;
/*!40000 ALTER TABLE `maxlife_tblinvoicepaymentrecords` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblinvoicepaymentrecords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblinvoices`
--

DROP TABLE IF EXISTS `maxlife_tblinvoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblinvoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sent` tinyint(1) NOT NULL DEFAULT 0,
  `datesend` datetime DEFAULT NULL,
  `clientid` int(11) NOT NULL,
  `deleted_customer_name` varchar(100) DEFAULT NULL,
  `number` int(11) NOT NULL,
  `prefix` varchar(50) DEFAULT NULL,
  `number_format` int(11) NOT NULL DEFAULT 0,
  `datecreated` datetime NOT NULL,
  `date` date NOT NULL,
  `duedate` date DEFAULT NULL,
  `currency` int(11) NOT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `total_tax` decimal(15,2) NOT NULL DEFAULT 0.00,
  `total` decimal(15,2) NOT NULL,
  `adjustment` decimal(15,2) DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `hash` varchar(32) NOT NULL,
  `status` int(11) DEFAULT 1,
  `clientnote` mediumtext DEFAULT NULL,
  `adminnote` mediumtext DEFAULT NULL,
  `last_overdue_reminder` date DEFAULT NULL,
  `last_due_reminder` date DEFAULT NULL,
  `cancel_overdue_reminders` int(11) NOT NULL DEFAULT 0,
  `allowed_payment_modes` longtext DEFAULT NULL,
  `token` longtext DEFAULT NULL,
  `discount_percent` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `discount_type` varchar(30) NOT NULL,
  `recurring` int(11) NOT NULL DEFAULT 0,
  `recurring_type` varchar(10) DEFAULT NULL,
  `custom_recurring` tinyint(1) NOT NULL DEFAULT 0,
  `cycles` int(11) NOT NULL DEFAULT 0,
  `total_cycles` int(11) NOT NULL DEFAULT 0,
  `is_recurring_from` int(11) DEFAULT NULL,
  `last_recurring_date` date DEFAULT NULL,
  `terms` mediumtext DEFAULT NULL,
  `sale_agent` int(11) NOT NULL DEFAULT 0,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT NULL,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT NULL,
  `include_shipping` tinyint(1) NOT NULL,
  `show_shipping_on_invoice` tinyint(1) NOT NULL DEFAULT 1,
  `show_quantity_as` int(11) NOT NULL DEFAULT 1,
  `project_id` int(11) DEFAULT 0,
  `subscription_id` int(11) NOT NULL DEFAULT 0,
  `perfex_saas_packageid` int(11) DEFAULT NULL,
  `short_link` varchar(100) DEFAULT NULL,
  `shipping_fee` decimal(15,2) DEFAULT 0.00,
  `woo_order_number` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `currency` (`currency`),
  KEY `clientid` (`clientid`),
  KEY `project_id` (`project_id`),
  KEY `sale_agent` (`sale_agent`),
  KEY `total` (`total`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblinvoices`
--

LOCK TABLES `maxlife_tblinvoices` WRITE;
/*!40000 ALTER TABLE `maxlife_tblinvoices` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblinvoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblitem_tax`
--

DROP TABLE IF EXISTS `maxlife_tblitem_tax`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblitem_tax` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemid` int(11) NOT NULL,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) NOT NULL,
  `taxrate` decimal(15,2) NOT NULL,
  `taxname` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `itemid` (`itemid`),
  KEY `rel_id` (`rel_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblitem_tax`
--

LOCK TABLES `maxlife_tblitem_tax` WRITE;
/*!40000 ALTER TABLE `maxlife_tblitem_tax` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblitem_tax` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblitemable`
--

DROP TABLE IF EXISTS `maxlife_tblitemable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblitemable` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(15) NOT NULL,
  `description` longtext NOT NULL,
  `long_description` longtext DEFAULT NULL,
  `qty` decimal(15,2) NOT NULL,
  `rate` decimal(15,2) NOT NULL,
  `unit` varchar(40) DEFAULT NULL,
  `item_order` int(11) DEFAULT NULL,
  `wh_delivered_quantity` decimal(15,2) DEFAULT 0.00,
  `item_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`),
  KEY `qty` (`qty`),
  KEY `rate` (`rate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblitemable`
--

LOCK TABLES `maxlife_tblitemable` WRITE;
/*!40000 ALTER TABLE `maxlife_tblitemable` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblitemable` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblitems`
--

DROP TABLE IF EXISTS `maxlife_tblitems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblitems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` longtext NOT NULL,
  `long_description` mediumtext DEFAULT NULL,
  `rate` decimal(15,2) NOT NULL,
  `tax` int(11) DEFAULT NULL,
  `tax2` int(11) DEFAULT NULL,
  `unit` varchar(40) DEFAULT NULL,
  `group_id` int(11) NOT NULL DEFAULT 0,
  `product_type` varchar(100) DEFAULT NULL,
  `description_internal_transfers` text DEFAULT NULL,
  `description_receipts` text DEFAULT NULL,
  `description_delivery_orders` text DEFAULT NULL,
  `customer_lead_time` decimal(15,2) DEFAULT 0.00,
  `replenish_on_order` varchar(100) DEFAULT NULL,
  `supplier_taxes_id` text DEFAULT NULL,
  `description_sale` text DEFAULT NULL,
  `invoice_policy` varchar(100) DEFAULT 'ordered_quantities',
  `purchase_unit_measure` int(11) DEFAULT NULL,
  `can_be_sold` varchar(100) DEFAULT 'can_be_sold',
  `can_be_purchased` varchar(100) DEFAULT 'can_be_purchased',
  `can_be_manufacturing` varchar(100) DEFAULT 'can_be_manufacturing',
  `manufacture` varchar(100) DEFAULT NULL,
  `manufacturing_lead_time` decimal(15,2) DEFAULT 0.00,
  `weight` decimal(15,2) DEFAULT 0.00,
  `volume` decimal(15,2) DEFAULT 0.00,
  `hs_code` varchar(200) DEFAULT NULL,
  `commodity_code` varchar(100) NOT NULL,
  `commodity_barcode` text DEFAULT NULL,
  `commodity_type` int(11) DEFAULT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `origin` varchar(100) DEFAULT NULL,
  `color_id` int(11) DEFAULT NULL,
  `style_id` int(11) DEFAULT NULL,
  `model_id` int(11) DEFAULT NULL,
  `size_id` int(11) DEFAULT NULL,
  `unit_id` int(11) DEFAULT NULL,
  `sku_code` varchar(200) DEFAULT NULL,
  `sku_name` varchar(200) DEFAULT NULL,
  `purchase_price` decimal(15,2) DEFAULT NULL,
  `sub_group` varchar(200) DEFAULT NULL,
  `commodity_name` varchar(200) NOT NULL,
  `color` text DEFAULT NULL,
  `guarantee` text DEFAULT NULL,
  `profif_ratio` text DEFAULT NULL,
  `active` int(11) DEFAULT 1,
  `long_descriptions` longtext DEFAULT NULL,
  `without_checking_warehouse` int(11) DEFAULT 0,
  `series_id` text DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `attributes` longtext DEFAULT NULL,
  `parent_attributes` longtext DEFAULT NULL,
  `can_be_inventory` varchar(100) DEFAULT 'can_be_inventory',
  `from_vendor_item` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tax` (`tax`),
  KEY `tax2` (`tax2`),
  KEY `group_id` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblitems`
--

LOCK TABLES `maxlife_tblitems` WRITE;
/*!40000 ALTER TABLE `maxlife_tblitems` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblitems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblitems_groups`
--

DROP TABLE IF EXISTS `maxlife_tblitems_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblitems_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `commodity_group_code` varchar(100) DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  `display` int(1) DEFAULT NULL,
  `note` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblitems_groups`
--

LOCK TABLES `maxlife_tblitems_groups` WRITE;
/*!40000 ALTER TABLE `maxlife_tblitems_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblitems_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblitems_of_vendor`
--

DROP TABLE IF EXISTS `maxlife_tblitems_of_vendor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblitems_of_vendor` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `vendor_id` int(11) NOT NULL,
  `description` text NOT NULL,
  `long_description` text DEFAULT NULL,
  `rate` decimal(15,2) DEFAULT NULL,
  `tax` int(11) DEFAULT NULL,
  `tax2` int(11) DEFAULT NULL,
  `unit` varchar(40) DEFAULT NULL,
  `group_id` int(11) NOT NULL,
  `commodity_code` varchar(100) NOT NULL,
  `commodity_barcode` text DEFAULT NULL,
  `unit_id` int(11) DEFAULT NULL,
  `sku_code` varchar(200) DEFAULT NULL,
  `sku_name` varchar(200) DEFAULT NULL,
  `sub_group` varchar(200) DEFAULT NULL,
  `active` int(11) DEFAULT NULL,
  `parent` int(11) DEFAULT NULL,
  `attributes` longtext DEFAULT NULL,
  `parent_attributes` longtext DEFAULT NULL,
  `commodity_type` int(11) DEFAULT NULL,
  `origin` varchar(100) DEFAULT NULL,
  `commodity_name` varchar(200) NOT NULL,
  `series_id` text DEFAULT NULL,
  `long_descriptions` longtext DEFAULT NULL,
  `share_status` int(1) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblitems_of_vendor`
--

LOCK TABLES `maxlife_tblitems_of_vendor` WRITE;
/*!40000 ALTER TABLE `maxlife_tblitems_of_vendor` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblitems_of_vendor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblknowedge_base_article_feedback`
--

DROP TABLE IF EXISTS `maxlife_tblknowedge_base_article_feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblknowedge_base_article_feedback` (
  `articleanswerid` int(11) NOT NULL AUTO_INCREMENT,
  `articleid` int(11) NOT NULL,
  `answer` int(11) NOT NULL,
  `ip` varchar(40) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`articleanswerid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblknowedge_base_article_feedback`
--

LOCK TABLES `maxlife_tblknowedge_base_article_feedback` WRITE;
/*!40000 ALTER TABLE `maxlife_tblknowedge_base_article_feedback` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblknowedge_base_article_feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblknowledge_base`
--

DROP TABLE IF EXISTS `maxlife_tblknowledge_base`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblknowledge_base` (
  `articleid` int(11) NOT NULL AUTO_INCREMENT,
  `articlegroup` int(11) NOT NULL,
  `subject` longtext NOT NULL,
  `description` mediumtext NOT NULL,
  `slug` longtext NOT NULL,
  `active` tinyint(4) NOT NULL,
  `datecreated` datetime NOT NULL,
  `article_order` int(11) NOT NULL DEFAULT 0,
  `staff_article` int(11) NOT NULL DEFAULT 0,
  `question_answers` int(11) DEFAULT 0,
  `file_name` varchar(255) DEFAULT '',
  `curator` varchar(11) DEFAULT '',
  `benchmark` int(11) DEFAULT 0,
  `score` int(11) DEFAULT 0,
  PRIMARY KEY (`articleid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblknowledge_base`
--

LOCK TABLES `maxlife_tblknowledge_base` WRITE;
/*!40000 ALTER TABLE `maxlife_tblknowledge_base` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblknowledge_base` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblknowledge_base_groups`
--

DROP TABLE IF EXISTS `maxlife_tblknowledge_base_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblknowledge_base_groups` (
  `groupid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `group_slug` mediumtext DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `active` tinyint(4) NOT NULL,
  `color` varchar(10) DEFAULT '#28B8DA',
  `group_order` int(11) DEFAULT 0,
  PRIMARY KEY (`groupid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblknowledge_base_groups`
--

LOCK TABLES `maxlife_tblknowledge_base_groups` WRITE;
/*!40000 ALTER TABLE `maxlife_tblknowledge_base_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblknowledge_base_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tbllead_activity_log`
--

DROP TABLE IF EXISTS `maxlife_tbllead_activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tbllead_activity_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `leadid` int(11) NOT NULL,
  `description` longtext NOT NULL,
  `additional_data` mediumtext DEFAULT NULL,
  `date` datetime NOT NULL,
  `staffid` int(11) NOT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `custom_activity` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tbllead_activity_log`
--

LOCK TABLES `maxlife_tbllead_activity_log` WRITE;
/*!40000 ALTER TABLE `maxlife_tbllead_activity_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tbllead_activity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tbllead_integration_emails`
--

DROP TABLE IF EXISTS `maxlife_tbllead_integration_emails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tbllead_integration_emails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` longtext DEFAULT NULL,
  `body` longtext DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  `leadid` int(11) NOT NULL,
  `emailid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tbllead_integration_emails`
--

LOCK TABLES `maxlife_tbllead_integration_emails` WRITE;
/*!40000 ALTER TABLE `maxlife_tbllead_integration_emails` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tbllead_integration_emails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblleads`
--

DROP TABLE IF EXISTS `maxlife_tblleads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblleads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(65) DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `company` varchar(191) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `country` int(11) NOT NULL DEFAULT 0,
  `zip` varchar(15) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `assigned` int(11) NOT NULL DEFAULT 0,
  `dateadded` datetime NOT NULL,
  `from_form_id` int(11) NOT NULL DEFAULT 0,
  `status` int(11) NOT NULL,
  `source` int(11) NOT NULL,
  `lastcontact` datetime DEFAULT NULL,
  `dateassigned` date DEFAULT NULL,
  `last_status_change` datetime DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `website` varchar(150) DEFAULT NULL,
  `leadorder` int(11) DEFAULT 1,
  `phonenumber` varchar(50) DEFAULT NULL,
  `date_converted` datetime DEFAULT NULL,
  `lost` tinyint(1) NOT NULL DEFAULT 0,
  `junk` int(11) NOT NULL DEFAULT 0,
  `last_lead_status` int(11) NOT NULL DEFAULT 0,
  `is_imported_from_email_integration` tinyint(1) NOT NULL DEFAULT 0,
  `email_integration_uid` varchar(30) DEFAULT NULL,
  `is_public` tinyint(1) NOT NULL DEFAULT 0,
  `default_language` varchar(40) DEFAULT NULL,
  `client_id` int(11) NOT NULL DEFAULT 0,
  `lead_value` decimal(15,2) DEFAULT NULL,
  `vat` varchar(50) DEFAULT NULL,
  `from_ma_form_id` int(11) NOT NULL DEFAULT 0,
  `ma_point` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `company` (`company`),
  KEY `email` (`email`),
  KEY `assigned` (`assigned`),
  KEY `status` (`status`),
  KEY `source` (`source`),
  KEY `lastcontact` (`lastcontact`),
  KEY `dateadded` (`dateadded`),
  KEY `leadorder` (`leadorder`),
  KEY `from_form_id` (`from_form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblleads`
--

LOCK TABLES `maxlife_tblleads` WRITE;
/*!40000 ALTER TABLE `maxlife_tblleads` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblleads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblleads_email_integration`
--

DROP TABLE IF EXISTS `maxlife_tblleads_email_integration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblleads_email_integration` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'the ID always must be 1',
  `active` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `imap_server` varchar(100) NOT NULL,
  `password` longtext NOT NULL,
  `check_every` int(11) NOT NULL DEFAULT 5,
  `responsible` int(11) NOT NULL,
  `lead_source` int(11) NOT NULL,
  `lead_status` int(11) NOT NULL,
  `encryption` varchar(3) DEFAULT NULL,
  `folder` varchar(100) NOT NULL,
  `last_run` varchar(50) DEFAULT NULL,
  `notify_lead_imported` tinyint(1) NOT NULL DEFAULT 1,
  `notify_lead_contact_more_times` tinyint(1) NOT NULL DEFAULT 1,
  `notify_type` varchar(20) DEFAULT NULL,
  `notify_ids` longtext DEFAULT NULL,
  `mark_public` int(11) NOT NULL DEFAULT 0,
  `only_loop_on_unseen_emails` tinyint(1) NOT NULL DEFAULT 1,
  `delete_after_import` int(11) NOT NULL DEFAULT 0,
  `create_task_if_customer` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblleads_email_integration`
--

LOCK TABLES `maxlife_tblleads_email_integration` WRITE;
/*!40000 ALTER TABLE `maxlife_tblleads_email_integration` DISABLE KEYS */;
INSERT INTO `maxlife_tblleads_email_integration` VALUES (1,0,'','','',10,0,0,0,'tls','INBOX','',1,1,'assigned','',0,1,0,1);
/*!40000 ALTER TABLE `maxlife_tblleads_email_integration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblleads_sources`
--

DROP TABLE IF EXISTS `maxlife_tblleads_sources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblleads_sources` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblleads_sources`
--

LOCK TABLES `maxlife_tblleads_sources` WRITE;
/*!40000 ALTER TABLE `maxlife_tblleads_sources` DISABLE KEYS */;
INSERT INTO `maxlife_tblleads_sources` VALUES (3,'Events'),(2,'Facebook'),(1,'Google');
/*!40000 ALTER TABLE `maxlife_tblleads_sources` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblleads_status`
--

DROP TABLE IF EXISTS `maxlife_tblleads_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblleads_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `statusorder` int(11) DEFAULT NULL,
  `color` varchar(10) DEFAULT '#28B8DA',
  `isdefault` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblleads_status`
--

LOCK TABLES `maxlife_tblleads_status` WRITE;
/*!40000 ALTER TABLE `maxlife_tblleads_status` DISABLE KEYS */;
INSERT INTO `maxlife_tblleads_status` VALUES (1,'Customer',1000,'#7cb342',1),(2,'New Lead',2,'#28B8DA',0);
/*!40000 ALTER TABLE `maxlife_tblleads_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblleave_of_the_year`
--

DROP TABLE IF EXISTS `maxlife_tblleave_of_the_year`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblleave_of_the_year` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `value` double DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblleave_of_the_year`
--

LOCK TABLES `maxlife_tblleave_of_the_year` WRITE;
/*!40000 ALTER TABLE `maxlife_tblleave_of_the_year` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblleave_of_the_year` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tbllist_widget`
--

DROP TABLE IF EXISTS `maxlife_tbllist_widget`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tbllist_widget` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `add_from` int(11) NOT NULL,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(45) DEFAULT NULL,
  `layout` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tbllist_widget`
--

LOCK TABLES `maxlife_tbllist_widget` WRITE;
/*!40000 ALTER TABLE `maxlife_tbllist_widget` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tbllist_widget` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tbllistemails`
--

DROP TABLE IF EXISTS `maxlife_tbllistemails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tbllistemails` (
  `emailid` int(11) NOT NULL AUTO_INCREMENT,
  `listid` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`emailid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tbllistemails`
--

LOCK TABLES `maxlife_tbllistemails` WRITE;
/*!40000 ALTER TABLE `maxlife_tbllistemails` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tbllistemails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblloy_card`
--

DROP TABLE IF EXISTS `maxlife_tblloy_card`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblloy_card` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `add_from` int(11) NOT NULL,
  `date_create` date DEFAULT NULL,
  `subject_card` int(2) DEFAULT 0,
  `client_name` int(2) DEFAULT 0,
  `membership` int(2) DEFAULT 0,
  `company_name` int(2) DEFAULT 0,
  `member_since` int(2) DEFAULT 0,
  `custom_field` int(2) DEFAULT 0,
  `custom_field_content` varchar(200) DEFAULT NULL,
  `text_color` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblloy_card`
--

LOCK TABLES `maxlife_tblloy_card` WRITE;
/*!40000 ALTER TABLE `maxlife_tblloy_card` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblloy_card` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblloy_mbs_program`
--

DROP TABLE IF EXISTS `maxlife_tblloy_mbs_program`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblloy_mbs_program` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `program_name` varchar(200) NOT NULL,
  `add_from` int(11) NOT NULL,
  `date_create` date DEFAULT NULL,
  `voucher_code` text NOT NULL,
  `discount` varchar(30) DEFAULT NULL,
  `discount_percent` int(5) DEFAULT NULL,
  `loyalty_point_from` decimal(15,0) DEFAULT NULL,
  `loyalty_point_to` decimal(15,0) DEFAULT NULL,
  `membership` text NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `note` text DEFAULT NULL,
  `voucher_value` decimal(15,2) DEFAULT 0.00,
  `formal` int(1) DEFAULT 1,
  `minium_purchase` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblloy_mbs_program`
--

LOCK TABLES `maxlife_tblloy_mbs_program` WRITE;
/*!40000 ALTER TABLE `maxlife_tblloy_mbs_program` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblloy_mbs_program` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblloy_mbs_rule`
--

DROP TABLE IF EXISTS `maxlife_tblloy_mbs_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblloy_mbs_rule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `add_from` int(11) NOT NULL,
  `date_create` date DEFAULT NULL,
  `client_group` int(11) DEFAULT NULL,
  `client` text NOT NULL,
  `loyalty_point_from` decimal(15,0) DEFAULT NULL,
  `loyalty_point_to` decimal(15,0) DEFAULT NULL,
  `card` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblloy_mbs_rule`
--

LOCK TABLES `maxlife_tblloy_mbs_rule` WRITE;
/*!40000 ALTER TABLE `maxlife_tblloy_mbs_rule` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblloy_mbs_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblloy_program_detail`
--

DROP TABLE IF EXISTS `maxlife_tblloy_program_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblloy_program_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mbs_program` int(11) NOT NULL,
  `rel_type` varchar(30) NOT NULL,
  `rel_id` text NOT NULL,
  `percent` int(5) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblloy_program_detail`
--

LOCK TABLES `maxlife_tblloy_program_detail` WRITE;
/*!40000 ALTER TABLE `maxlife_tblloy_program_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblloy_program_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblloy_redeem_log`
--

DROP TABLE IF EXISTS `maxlife_tblloy_redeem_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblloy_redeem_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client` int(11) NOT NULL,
  `cart` int(11) DEFAULT NULL,
  `invoice` int(11) DEFAULT NULL,
  `time` datetime DEFAULT NULL,
  `old_point` decimal(10,0) DEFAULT NULL,
  `new_point` decimal(10,0) DEFAULT NULL,
  `redeep_from` decimal(10,0) DEFAULT NULL,
  `redeep_to` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblloy_redeem_log`
--

LOCK TABLES `maxlife_tblloy_redeem_log` WRITE;
/*!40000 ALTER TABLE `maxlife_tblloy_redeem_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblloy_redeem_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblloy_redemp_detail`
--

DROP TABLE IF EXISTS `maxlife_tblloy_redemp_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblloy_redemp_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `loy_rule` int(11) NOT NULL,
  `rule_name` varchar(200) NOT NULL,
  `point_from` decimal(15,0) DEFAULT NULL,
  `point_to` decimal(15,0) DEFAULT NULL,
  `point_weight` decimal(15,2) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblloy_redemp_detail`
--

LOCK TABLES `maxlife_tblloy_redemp_detail` WRITE;
/*!40000 ALTER TABLE `maxlife_tblloy_redemp_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblloy_redemp_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblloy_rule`
--

DROP TABLE IF EXISTS `maxlife_tblloy_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblloy_rule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(200) NOT NULL,
  `add_from` int(11) NOT NULL,
  `date_create` date DEFAULT NULL,
  `enable` int(2) DEFAULT 0,
  `redeemp_type` varchar(15) DEFAULT NULL,
  `min_poin_to_redeem` decimal(15,0) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `rule_base` varchar(30) DEFAULT NULL,
  `minium_purchase` decimal(15,0) DEFAULT NULL,
  `poin_awarded` decimal(15,0) DEFAULT NULL,
  `purchase_value` decimal(15,0) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `redeem_portal` int(1) DEFAULT 0,
  `redeem_pos` int(1) DEFAULT 0,
  `client_group` int(11) DEFAULT 0,
  `client` text NOT NULL,
  `max_amount_received` int(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblloy_rule`
--

LOCK TABLES `maxlife_tblloy_rule` WRITE;
/*!40000 ALTER TABLE `maxlife_tblloy_rule` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblloy_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblloy_rule_detail`
--

DROP TABLE IF EXISTS `maxlife_tblloy_rule_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblloy_rule_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `loy_rule` int(11) NOT NULL,
  `rel_type` varchar(30) NOT NULL,
  `rel_id` text NOT NULL,
  `loyalty_point` decimal(15,0) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblloy_rule_detail`
--

LOCK TABLES `maxlife_tblloy_rule_detail` WRITE;
/*!40000 ALTER TABLE `maxlife_tblloy_rule_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblloy_rule_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblloy_transation`
--

DROP TABLE IF EXISTS `maxlife_tblloy_transation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblloy_transation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference` varchar(30) NOT NULL,
  `invoice` int(11) DEFAULT NULL,
  `client` int(11) NOT NULL,
  `add_from` int(11) DEFAULT NULL,
  `date_create` datetime DEFAULT NULL,
  `loyalty_point` decimal(15,0) DEFAULT NULL,
  `type` varchar(30) DEFAULT NULL,
  `note` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblloy_transation`
--

LOCK TABLES `maxlife_tblloy_transation` WRITE;
/*!40000 ALTER TABLE `maxlife_tblloy_transation` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblloy_transation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblma_asset_download_logs`
--

DROP TABLE IF EXISTS `maxlife_tblma_asset_download_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblma_asset_download_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `asset_id` int(11) NOT NULL,
  `ip` text DEFAULT NULL,
  `browser_name` text DEFAULT NULL,
  `http_user_agent` text DEFAULT NULL,
  `time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblma_asset_download_logs`
--

LOCK TABLES `maxlife_tblma_asset_download_logs` WRITE;
/*!40000 ALTER TABLE `maxlife_tblma_asset_download_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblma_asset_download_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblma_assets`
--

DROP TABLE IF EXISTS `maxlife_tblma_assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblma_assets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `language` varchar(40) DEFAULT NULL,
  `category` int(11) NOT NULL DEFAULT 0,
  `published` int(11) NOT NULL DEFAULT 1,
  `description` text DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  `color` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblma_assets`
--

LOCK TABLES `maxlife_tblma_assets` WRITE;
/*!40000 ALTER TABLE `maxlife_tblma_assets` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblma_assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblma_campaign_flows`
--

DROP TABLE IF EXISTS `maxlife_tblma_campaign_flows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblma_campaign_flows` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `campaign_id` int(11) NOT NULL,
  `node_id` int(11) NOT NULL,
  `lead_id` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  `output` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblma_campaign_flows`
--

LOCK TABLES `maxlife_tblma_campaign_flows` WRITE;
/*!40000 ALTER TABLE `maxlife_tblma_campaign_flows` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblma_campaign_flows` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblma_campaign_lead_exceptions`
--

DROP TABLE IF EXISTS `maxlife_tblma_campaign_lead_exceptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblma_campaign_lead_exceptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lead_id` int(11) NOT NULL,
  `campaign_id` int(11) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblma_campaign_lead_exceptions`
--

LOCK TABLES `maxlife_tblma_campaign_lead_exceptions` WRITE;
/*!40000 ALTER TABLE `maxlife_tblma_campaign_lead_exceptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblma_campaign_lead_exceptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblma_campaigns`
--

DROP TABLE IF EXISTS `maxlife_tblma_campaigns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblma_campaigns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `color` text DEFAULT NULL,
  `category` int(11) NOT NULL DEFAULT 0,
  `published` int(11) NOT NULL DEFAULT 1,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `workflow` longtext DEFAULT NULL,
  `description` text DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblma_campaigns`
--

LOCK TABLES `maxlife_tblma_campaigns` WRITE;
/*!40000 ALTER TABLE `maxlife_tblma_campaigns` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblma_campaigns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblma_categories`
--

DROP TABLE IF EXISTS `maxlife_tblma_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblma_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `type` text DEFAULT NULL,
  `published` int(11) NOT NULL DEFAULT 1,
  `description` text DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  `color` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblma_categories`
--

LOCK TABLES `maxlife_tblma_categories` WRITE;
/*!40000 ALTER TABLE `maxlife_tblma_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblma_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblma_email_click_logs`
--

DROP TABLE IF EXISTS `maxlife_tblma_email_click_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblma_email_click_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lead_id` int(11) NOT NULL,
  `campaign_id` int(11) DEFAULT NULL,
  `email_id` int(11) DEFAULT NULL,
  `url` text DEFAULT NULL,
  `time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblma_email_click_logs`
--

LOCK TABLES `maxlife_tblma_email_click_logs` WRITE;
/*!40000 ALTER TABLE `maxlife_tblma_email_click_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblma_email_click_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblma_email_logs`
--

DROP TABLE IF EXISTS `maxlife_tblma_email_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblma_email_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lead_id` int(11) NOT NULL,
  `campaign_id` int(11) DEFAULT NULL,
  `email_template_id` int(11) DEFAULT NULL,
  `delivery` int(11) NOT NULL DEFAULT 0,
  `open` int(11) NOT NULL DEFAULT 0,
  `click` int(11) NOT NULL DEFAULT 0,
  `dateadded` datetime NOT NULL,
  `delivery_time` datetime DEFAULT NULL,
  `open_time` datetime DEFAULT NULL,
  `click_time` datetime DEFAULT NULL,
  `email_id` int(11) DEFAULT NULL,
  `failed` int(11) NOT NULL DEFAULT 0,
  `failed_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblma_email_logs`
--

LOCK TABLES `maxlife_tblma_email_logs` WRITE;
/*!40000 ALTER TABLE `maxlife_tblma_email_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblma_email_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblma_email_templates`
--

DROP TABLE IF EXISTS `maxlife_tblma_email_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblma_email_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `color` text NOT NULL,
  `category` int(11) NOT NULL DEFAULT 0,
  `published` int(11) NOT NULL DEFAULT 1,
  `language` text DEFAULT NULL,
  `data_html` longtext DEFAULT NULL,
  `data_design` longtext DEFAULT NULL,
  `description` text DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblma_email_templates`
--

LOCK TABLES `maxlife_tblma_email_templates` WRITE;
/*!40000 ALTER TABLE `maxlife_tblma_email_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblma_email_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblma_emails`
--

DROP TABLE IF EXISTS `maxlife_tblma_emails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblma_emails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `type` text NOT NULL,
  `category` int(11) NOT NULL DEFAULT 0,
  `segment` int(11) NOT NULL DEFAULT 0,
  `published` int(11) NOT NULL DEFAULT 1,
  `language` varchar(40) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  `color` text DEFAULT NULL,
  `subject` text DEFAULT NULL,
  `email_template` int(11) DEFAULT NULL,
  `from_name` text DEFAULT NULL,
  `from_address` text DEFAULT NULL,
  `reply_to_address` text DEFAULT NULL,
  `bcc_address` text DEFAULT NULL,
  `attachment` text DEFAULT NULL,
  `data_design` longtext DEFAULT NULL,
  `data_html` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblma_emails`
--

LOCK TABLES `maxlife_tblma_emails` WRITE;
/*!40000 ALTER TABLE `maxlife_tblma_emails` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblma_emails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblma_forms`
--

DROP TABLE IF EXISTS `maxlife_tblma_forms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblma_forms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `form_key` varchar(32) NOT NULL,
  `lead_source` int(11) NOT NULL,
  `lead_status` int(11) NOT NULL,
  `notify_lead_imported` int(11) NOT NULL,
  `notify_type` varchar(20) DEFAULT NULL,
  `notify_ids` mediumtext DEFAULT NULL,
  `responsible` int(11) NOT NULL DEFAULT 0,
  `name` varchar(191) NOT NULL,
  `form_data` mediumtext DEFAULT NULL,
  `recaptcha` int(11) NOT NULL DEFAULT 0,
  `submit_btn_name` varchar(40) DEFAULT NULL,
  `success_submit_msg` text DEFAULT NULL,
  `language` varchar(40) DEFAULT NULL,
  `allow_duplicate` int(11) NOT NULL DEFAULT 1,
  `mark_public` int(11) NOT NULL DEFAULT 0,
  `track_duplicate_field` varchar(20) DEFAULT NULL,
  `track_duplicate_field_and` varchar(20) DEFAULT NULL,
  `create_task_on_duplicate` int(11) NOT NULL DEFAULT 0,
  `dateadded` datetime NOT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `category` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblma_forms`
--

LOCK TABLES `maxlife_tblma_forms` WRITE;
/*!40000 ALTER TABLE `maxlife_tblma_forms` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblma_forms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblma_lead_segments`
--

DROP TABLE IF EXISTS `maxlife_tblma_lead_segments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblma_lead_segments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `segment_id` int(11) NOT NULL,
  `lead_id` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  `deleted` int(11) NOT NULL DEFAULT 0,
  `date_delete` datetime DEFAULT NULL,
  `campaign_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblma_lead_segments`
--

LOCK TABLES `maxlife_tblma_lead_segments` WRITE;
/*!40000 ALTER TABLE `maxlife_tblma_lead_segments` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblma_lead_segments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblma_lead_stages`
--

DROP TABLE IF EXISTS `maxlife_tblma_lead_stages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblma_lead_stages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stage_id` int(11) NOT NULL,
  `lead_id` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  `deleted` int(11) NOT NULL DEFAULT 0,
  `date_delete` datetime DEFAULT NULL,
  `campaign_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblma_lead_stages`
--

LOCK TABLES `maxlife_tblma_lead_stages` WRITE;
/*!40000 ALTER TABLE `maxlife_tblma_lead_stages` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblma_lead_stages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblma_marketing_messages`
--

DROP TABLE IF EXISTS `maxlife_tblma_marketing_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblma_marketing_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `type` text NOT NULL,
  `category` int(11) NOT NULL DEFAULT 0,
  `published` int(11) NOT NULL DEFAULT 1,
  `email_template` int(11) NOT NULL DEFAULT 0,
  `web_notification_description` text DEFAULT NULL,
  `web_notification_link` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblma_marketing_messages`
--

LOCK TABLES `maxlife_tblma_marketing_messages` WRITE;
/*!40000 ALTER TABLE `maxlife_tblma_marketing_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblma_marketing_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblma_point_action_logs`
--

DROP TABLE IF EXISTS `maxlife_tblma_point_action_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblma_point_action_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lead_id` int(11) NOT NULL,
  `campaign_id` int(11) DEFAULT NULL,
  `point_action_id` int(11) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  `point` float DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblma_point_action_logs`
--

LOCK TABLES `maxlife_tblma_point_action_logs` WRITE;
/*!40000 ALTER TABLE `maxlife_tblma_point_action_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblma_point_action_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblma_point_actions`
--

DROP TABLE IF EXISTS `maxlife_tblma_point_actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblma_point_actions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `change_points` float NOT NULL,
  `action` text DEFAULT NULL,
  `category` int(11) NOT NULL DEFAULT 0,
  `published` int(11) NOT NULL DEFAULT 1,
  `description` text DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblma_point_actions`
--

LOCK TABLES `maxlife_tblma_point_actions` WRITE;
/*!40000 ALTER TABLE `maxlife_tblma_point_actions` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblma_point_actions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblma_point_triggers`
--

DROP TABLE IF EXISTS `maxlife_tblma_point_triggers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblma_point_triggers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `minimum_number_of_points` float NOT NULL,
  `contact_color` text DEFAULT NULL,
  `category` int(11) NOT NULL DEFAULT 0,
  `published` int(11) NOT NULL DEFAULT 1,
  `description` text DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblma_point_triggers`
--

LOCK TABLES `maxlife_tblma_point_triggers` WRITE;
/*!40000 ALTER TABLE `maxlife_tblma_point_triggers` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblma_point_triggers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblma_segment_filters`
--

DROP TABLE IF EXISTS `maxlife_tblma_segment_filters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblma_segment_filters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `segment_id` int(255) DEFAULT NULL,
  `type` text DEFAULT NULL,
  `sub_type_1` text DEFAULT NULL,
  `sub_type_2` text DEFAULT NULL,
  `value` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblma_segment_filters`
--

LOCK TABLES `maxlife_tblma_segment_filters` WRITE;
/*!40000 ALTER TABLE `maxlife_tblma_segment_filters` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblma_segment_filters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblma_segments`
--

DROP TABLE IF EXISTS `maxlife_tblma_segments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblma_segments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `category` int(255) DEFAULT NULL,
  `public_segment` int(255) NOT NULL DEFAULT 1,
  `published` int(11) NOT NULL DEFAULT 1,
  `description` text DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  `color` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblma_segments`
--

LOCK TABLES `maxlife_tblma_segments` WRITE;
/*!40000 ALTER TABLE `maxlife_tblma_segments` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblma_segments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblma_sms`
--

DROP TABLE IF EXISTS `maxlife_tblma_sms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblma_sms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `category` int(11) NOT NULL DEFAULT 0,
  `sms_template` int(11) NOT NULL DEFAULT 0,
  `color` text DEFAULT NULL,
  `published` int(11) NOT NULL DEFAULT 1,
  `language` varchar(40) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblma_sms`
--

LOCK TABLES `maxlife_tblma_sms` WRITE;
/*!40000 ALTER TABLE `maxlife_tblma_sms` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblma_sms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblma_sms_logs`
--

DROP TABLE IF EXISTS `maxlife_tblma_sms_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblma_sms_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lead_id` int(11) NOT NULL,
  `campaign_id` int(11) DEFAULT NULL,
  `text_message_id` int(11) DEFAULT NULL,
  `delivery` int(11) NOT NULL DEFAULT 0,
  `delivery_time` datetime NOT NULL,
  `dateadded` datetime NOT NULL,
  `sms_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblma_sms_logs`
--

LOCK TABLES `maxlife_tblma_sms_logs` WRITE;
/*!40000 ALTER TABLE `maxlife_tblma_sms_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblma_sms_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblma_stages`
--

DROP TABLE IF EXISTS `maxlife_tblma_stages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblma_stages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `weight` text DEFAULT NULL,
  `category` int(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  `color` text DEFAULT NULL,
  `published` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblma_stages`
--

LOCK TABLES `maxlife_tblma_stages` WRITE;
/*!40000 ALTER TABLE `maxlife_tblma_stages` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblma_stages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblma_text_messages`
--

DROP TABLE IF EXISTS `maxlife_tblma_text_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblma_text_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `category` int(11) NOT NULL DEFAULT 0,
  `published` int(11) NOT NULL DEFAULT 1,
  `language` varchar(40) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblma_text_messages`
--

LOCK TABLES `maxlife_tblma_text_messages` WRITE;
/*!40000 ALTER TABLE `maxlife_tblma_text_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblma_text_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblmail_queue`
--

DROP TABLE IF EXISTS `maxlife_tblmail_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblmail_queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `engine` varchar(40) DEFAULT NULL,
  `email` varchar(191) NOT NULL,
  `cc` mediumtext DEFAULT NULL,
  `bcc` mediumtext DEFAULT NULL,
  `message` longtext NOT NULL,
  `alt_message` longtext DEFAULT NULL,
  `status` enum('pending','sending','sent','failed') DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `headers` mediumtext DEFAULT NULL,
  `attachments` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblmail_queue`
--

LOCK TABLES `maxlife_tblmail_queue` WRITE;
/*!40000 ALTER TABLE `maxlife_tblmail_queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblmail_queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblmailflow_email_templates`
--

DROP TABLE IF EXISTS `maxlife_tblmailflow_email_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblmailflow_email_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_name` text DEFAULT NULL,
  `template_subject` text DEFAULT NULL,
  `template_content` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblmailflow_email_templates`
--

LOCK TABLES `maxlife_tblmailflow_email_templates` WRITE;
/*!40000 ALTER TABLE `maxlife_tblmailflow_email_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblmailflow_email_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblmailflow_newsletter_history`
--

DROP TABLE IF EXISTS `maxlife_tblmailflow_newsletter_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblmailflow_newsletter_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sent_by` text DEFAULT NULL,
  `email_subject` text DEFAULT NULL,
  `email_content` text DEFAULT NULL,
  `total_emails_to_send` text DEFAULT NULL,
  `email_list` text DEFAULT NULL,
  `emails_sent` text DEFAULT NULL,
  `emails_failed` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblmailflow_newsletter_history`
--

LOCK TABLES `maxlife_tblmailflow_newsletter_history` WRITE;
/*!40000 ALTER TABLE `maxlife_tblmailflow_newsletter_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblmailflow_newsletter_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblmailflow_unsubscribed_emails`
--

DROP TABLE IF EXISTS `maxlife_tblmailflow_unsubscribed_emails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblmailflow_unsubscribed_emails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblmailflow_unsubscribed_emails`
--

LOCK TABLES `maxlife_tblmailflow_unsubscribed_emails` WRITE;
/*!40000 ALTER TABLE `maxlife_tblmailflow_unsubscribed_emails` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblmailflow_unsubscribed_emails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblmaillistscustomfields`
--

DROP TABLE IF EXISTS `maxlife_tblmaillistscustomfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblmaillistscustomfields` (
  `customfieldid` int(11) NOT NULL AUTO_INCREMENT,
  `listid` int(11) NOT NULL,
  `fieldname` varchar(150) NOT NULL,
  `fieldslug` varchar(100) NOT NULL,
  PRIMARY KEY (`customfieldid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblmaillistscustomfields`
--

LOCK TABLES `maxlife_tblmaillistscustomfields` WRITE;
/*!40000 ALTER TABLE `maxlife_tblmaillistscustomfields` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblmaillistscustomfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblmaillistscustomfieldvalues`
--

DROP TABLE IF EXISTS `maxlife_tblmaillistscustomfieldvalues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblmaillistscustomfieldvalues` (
  `customfieldvalueid` int(11) NOT NULL AUTO_INCREMENT,
  `listid` int(11) NOT NULL,
  `customfieldid` int(11) NOT NULL,
  `emailid` int(11) NOT NULL,
  `value` varchar(100) NOT NULL,
  PRIMARY KEY (`customfieldvalueid`),
  KEY `listid` (`listid`),
  KEY `customfieldid` (`customfieldid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblmaillistscustomfieldvalues`
--

LOCK TABLES `maxlife_tblmaillistscustomfieldvalues` WRITE;
/*!40000 ALTER TABLE `maxlife_tblmaillistscustomfieldvalues` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblmaillistscustomfieldvalues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblmanage_leave`
--

DROP TABLE IF EXISTS `maxlife_tblmanage_leave`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblmanage_leave` (
  `leave_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_staff` int(11) NOT NULL,
  `leave_date` int(11) DEFAULT NULL,
  `leave_year` int(11) DEFAULT NULL,
  `accumulated_leave` int(11) DEFAULT NULL,
  `seniority_leave` int(11) DEFAULT NULL,
  `borrow_leave` int(11) DEFAULT NULL,
  `actual_leave` int(11) DEFAULT NULL,
  `expected_leave` int(11) DEFAULT NULL,
  PRIMARY KEY (`leave_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblmanage_leave`
--

LOCK TABLES `maxlife_tblmanage_leave` WRITE;
/*!40000 ALTER TABLE `maxlife_tblmanage_leave` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblmanage_leave` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblmfa_history_login`
--

DROP TABLE IF EXISTS `maxlife_tblmfa_history_login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblmfa_history_login` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staff` int(11) NOT NULL,
  `type` varchar(100) NOT NULL,
  `status` varchar(50) NOT NULL,
  `mess` text DEFAULT NULL,
  `time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblmfa_history_login`
--

LOCK TABLES `maxlife_tblmfa_history_login` WRITE;
/*!40000 ALTER TABLE `maxlife_tblmfa_history_login` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblmfa_history_login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblmfa_options`
--

DROP TABLE IF EXISTS `maxlife_tblmfa_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblmfa_options` (
  `option_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(200) NOT NULL,
  `option_val` longtext DEFAULT NULL,
  `auto` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`option_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblmfa_options`
--

LOCK TABLES `maxlife_tblmfa_options` WRITE;
/*!40000 ALTER TABLE `maxlife_tblmfa_options` DISABLE KEYS */;
INSERT INTO `maxlife_tblmfa_options` VALUES (1,'enable_mfa','0',1),(2,'enable_google_authenticator','0',1),(3,'enable_whatsapp','0',1),(4,'google_authenticator_secret_key','',1),(5,'enable_sms','0',1),(6,'twilio_account_sid','',1),(7,'twilio_auth_token','',1),(8,'twilio_phone_number','',1),(9,'twilio_phone_number_for_sms','',1),(10,'delete_history_after_months','6',1),(11,'whatsapp_message_template','Your login code for {{1}} is {{2}}',1),(12,'enable_gg_auth_for_users_have_not_role','0',1);
/*!40000 ALTER TABLE `maxlife_tblmfa_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblmfa_security_code`
--

DROP TABLE IF EXISTS `maxlife_tblmfa_security_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblmfa_security_code` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staff` int(11) NOT NULL,
  `code` text NOT NULL,
  `created_at` datetime NOT NULL,
  `type` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblmfa_security_code`
--

LOCK TABLES `maxlife_tblmfa_security_code` WRITE;
/*!40000 ALTER TABLE `maxlife_tblmfa_security_code` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblmfa_security_code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblmfa_send_code_logs`
--

DROP TABLE IF EXISTS `maxlife_tblmfa_send_code_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblmfa_send_code_logs` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staff` int(11) NOT NULL,
  `type` varchar(100) NOT NULL,
  `status` varchar(50) NOT NULL,
  `mess` text DEFAULT NULL,
  `time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblmfa_send_code_logs`
--

LOCK TABLES `maxlife_tblmfa_send_code_logs` WRITE;
/*!40000 ALTER TABLE `maxlife_tblmfa_send_code_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblmfa_send_code_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblmigrations`
--

DROP TABLE IF EXISTS `maxlife_tblmigrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblmigrations` (
  `version` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblmigrations`
--

LOCK TABLES `maxlife_tblmigrations` WRITE;
/*!40000 ALTER TABLE `maxlife_tblmigrations` DISABLE KEYS */;
INSERT INTO `maxlife_tblmigrations` VALUES (310),(310);
/*!40000 ALTER TABLE `maxlife_tblmigrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblmilestones`
--

DROP TABLE IF EXISTS `maxlife_tblmilestones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblmilestones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `description_visible_to_customer` tinyint(1) DEFAULT 0,
  `start_date` date DEFAULT NULL,
  `due_date` date NOT NULL,
  `project_id` int(11) NOT NULL,
  `color` varchar(10) DEFAULT NULL,
  `milestone_order` int(11) NOT NULL DEFAULT 0,
  `datecreated` date NOT NULL,
  `hide_from_customer` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblmilestones`
--

LOCK TABLES `maxlife_tblmilestones` WRITE;
/*!40000 ALTER TABLE `maxlife_tblmilestones` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblmilestones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblmodules`
--

DROP TABLE IF EXISTS `maxlife_tblmodules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblmodules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module_name` varchar(55) NOT NULL,
  `installed_version` varchar(11) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblmodules`
--

LOCK TABLES `maxlife_tblmodules` WRITE;
/*!40000 ALTER TABLE `maxlife_tblmodules` DISABLE KEYS */;
INSERT INTO `maxlife_tblmodules` VALUES (1,'account_planning','1.0.0',1),(2,'accounting','1.3.4',1),(3,'affiliate_management','1.0.6',1),(4,'appointly','1.1.9',1),(5,'aws_integration','1.0.0',0),(6,'exports','1.0.0',1),(7,'loyalty','1.0.0',1),(8,'backup','2.3.0',1),(9,'facebook_leads_integration','1.0.0',0),(10,'fixed_equipment','1.0.9',1),(11,'goals','2.3.0',1),(12,'si_lead_followup','1.0.1',1),(13,'mailbox','2.0.1',0),(14,'mailflow','1.1.0',1),(15,'si_custom_status','1.0.5',1),(16,'ma','1.0.0',1),(17,'menu_setup','2.3.0',1),(18,'mfa','1.0.1',1),(19,'omni_sales','1.2.0',1),(20,'project_roadmap','1.0.0',1),(21,'purchase','1.5.0',1),(22,'resource_workload','1.0.7',1),(23,'surveys','2.3.0',1),(24,'theme_style','2.3.0',1),(25,'timesheets','1.1.9',1),(26,'user_mention','1.0.2',1),(27,'webhooks','1.1.0',0);
/*!40000 ALTER TABLE `maxlife_tblmodules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblnewsfeed_comment_likes`
--

DROP TABLE IF EXISTS `maxlife_tblnewsfeed_comment_likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblnewsfeed_comment_likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `postid` int(11) NOT NULL,
  `commentid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `dateliked` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblnewsfeed_comment_likes`
--

LOCK TABLES `maxlife_tblnewsfeed_comment_likes` WRITE;
/*!40000 ALTER TABLE `maxlife_tblnewsfeed_comment_likes` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblnewsfeed_comment_likes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblnewsfeed_post_comments`
--

DROP TABLE IF EXISTS `maxlife_tblnewsfeed_post_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblnewsfeed_post_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` mediumtext DEFAULT NULL,
  `userid` int(11) NOT NULL,
  `postid` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblnewsfeed_post_comments`
--

LOCK TABLES `maxlife_tblnewsfeed_post_comments` WRITE;
/*!40000 ALTER TABLE `maxlife_tblnewsfeed_post_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblnewsfeed_post_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblnewsfeed_post_likes`
--

DROP TABLE IF EXISTS `maxlife_tblnewsfeed_post_likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblnewsfeed_post_likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `postid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `dateliked` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblnewsfeed_post_likes`
--

LOCK TABLES `maxlife_tblnewsfeed_post_likes` WRITE;
/*!40000 ALTER TABLE `maxlife_tblnewsfeed_post_likes` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblnewsfeed_post_likes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblnewsfeed_posts`
--

DROP TABLE IF EXISTS `maxlife_tblnewsfeed_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblnewsfeed_posts` (
  `postid` int(11) NOT NULL AUTO_INCREMENT,
  `creator` int(11) NOT NULL,
  `datecreated` datetime NOT NULL,
  `visibility` varchar(100) NOT NULL,
  `content` mediumtext NOT NULL,
  `pinned` int(11) NOT NULL,
  `datepinned` datetime DEFAULT NULL,
  PRIMARY KEY (`postid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblnewsfeed_posts`
--

LOCK TABLES `maxlife_tblnewsfeed_posts` WRITE;
/*!40000 ALTER TABLE `maxlife_tblnewsfeed_posts` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblnewsfeed_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblnotes`
--

DROP TABLE IF EXISTS `maxlife_tblnotes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblnotes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `date_contacted` datetime DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblnotes`
--

LOCK TABLES `maxlife_tblnotes` WRITE;
/*!40000 ALTER TABLE `maxlife_tblnotes` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblnotes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblnotifications`
--

DROP TABLE IF EXISTS `maxlife_tblnotifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblnotifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `isread` int(11) NOT NULL DEFAULT 0,
  `isread_inline` tinyint(1) NOT NULL DEFAULT 0,
  `date` datetime NOT NULL,
  `description` mediumtext NOT NULL,
  `fromuserid` int(11) NOT NULL,
  `fromclientid` int(11) NOT NULL DEFAULT 0,
  `from_fullname` varchar(100) NOT NULL,
  `touserid` int(11) NOT NULL,
  `fromcompany` int(11) DEFAULT NULL,
  `link` longtext DEFAULT NULL,
  `additional_data` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblnotifications`
--

LOCK TABLES `maxlife_tblnotifications` WRITE;
/*!40000 ALTER TABLE `maxlife_tblnotifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblnotifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblomni_cart_payment`
--

DROP TABLE IF EXISTS `maxlife_tblomni_cart_payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblomni_cart_payment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `cart_id` int(11) NOT NULL,
  `payment_id` varchar(30) NOT NULL,
  `payment_name` varchar(100) DEFAULT NULL,
  `customer_pay` decimal(15,2) NOT NULL DEFAULT 0.00,
  `datecreator` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblomni_cart_payment`
--

LOCK TABLES `maxlife_tblomni_cart_payment` WRITE;
/*!40000 ALTER TABLE `maxlife_tblomni_cart_payment` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblomni_cart_payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblomni_create_customer_report`
--

DROP TABLE IF EXISTS `maxlife_tblomni_create_customer_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblomni_create_customer_report` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `m_date_report` text DEFAULT NULL,
  `m_total_diesel` double DEFAULT NULL,
  `m_total_pertrol` double DEFAULT NULL,
  `m_total_other` double DEFAULT NULL,
  `m_total_by_cash` double DEFAULT NULL,
  `m_total_by_mpesa` double DEFAULT NULL,
  `m_total_by_card` double DEFAULT NULL,
  `m_total_by_invoice` double DEFAULT NULL,
  `m_total_amount` double DEFAULT NULL,
  `m_total_quantity` double DEFAULT NULL,
  `date_time_transaction` datetime DEFAULT NULL,
  `list_customer_report_id` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblomni_create_customer_report`
--

LOCK TABLES `maxlife_tblomni_create_customer_report` WRITE;
/*!40000 ALTER TABLE `maxlife_tblomni_create_customer_report` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblomni_create_customer_report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblomni_create_customer_report_detail`
--

DROP TABLE IF EXISTS `maxlife_tblomni_create_customer_report_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblomni_create_customer_report_detail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `create_customer_report_id` int(11) NOT NULL,
  `date_add` datetime DEFAULT NULL,
  `attendant_name` text DEFAULT NULL,
  `shift_type` varchar(100) DEFAULT NULL,
  `date_report` text DEFAULT NULL,
  `total_diesel` double DEFAULT NULL,
  `total_pertrol` double DEFAULT NULL,
  `total_other_product` double DEFAULT NULL,
  `total_by_cash` double DEFAULT NULL,
  `total_by_mpesa` double DEFAULT NULL,
  `total_by_card` double DEFAULT NULL,
  `total_by_invoice` double DEFAULT NULL,
  `total_sales` double DEFAULT NULL,
  `list_customer_report_id` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblomni_create_customer_report_detail`
--

LOCK TABLES `maxlife_tblomni_create_customer_report_detail` WRITE;
/*!40000 ALTER TABLE `maxlife_tblomni_create_customer_report_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblomni_create_customer_report_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblomni_customer_report`
--

DROP TABLE IF EXISTS `maxlife_tblomni_customer_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblomni_customer_report` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ser_no` varchar(100) DEFAULT NULL,
  `authorized_by` text DEFAULT NULL,
  `date` date DEFAULT NULL,
  `time` varchar(100) DEFAULT NULL,
  `transaction_id` varchar(100) DEFAULT NULL,
  `receipt` varchar(100) DEFAULT NULL,
  `pay_mode` text DEFAULT NULL,
  `nozzle` text DEFAULT NULL,
  `product` text DEFAULT NULL,
  `quantity` double DEFAULT NULL,
  `total_sale` double DEFAULT NULL,
  `ref_slip_no` text DEFAULT NULL,
  `date_add` datetime DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `customer_id` varchar(100) DEFAULT NULL,
  `payment_id` int(11) DEFAULT NULL,
  `shift_type` varchar(100) DEFAULT NULL,
  `date_time_transaction` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblomni_customer_report`
--

LOCK TABLES `maxlife_tblomni_customer_report` WRITE;
/*!40000 ALTER TABLE `maxlife_tblomni_customer_report` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblomni_customer_report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblomni_log_discount`
--

DROP TABLE IF EXISTS `maxlife_tblomni_log_discount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblomni_log_discount` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name_discount` varchar(250) NOT NULL,
  `client` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_quality` int(11) NOT NULL,
  `total_product` int(11) NOT NULL,
  `date_apply` datetime NOT NULL DEFAULT current_timestamp(),
  `voucher_coupon` varchar(250) DEFAULT NULL,
  `order_number` varchar(100) DEFAULT NULL,
  `total_order` varchar(100) DEFAULT NULL,
  `discount` varchar(100) DEFAULT NULL,
  `tax` varchar(100) DEFAULT NULL,
  `total_after` varchar(100) DEFAULT NULL,
  `channel_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblomni_log_discount`
--

LOCK TABLES `maxlife_tblomni_log_discount` WRITE;
/*!40000 ALTER TABLE `maxlife_tblomni_log_discount` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblomni_log_discount` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblomni_log_sync_woo`
--

DROP TABLE IF EXISTS `maxlife_tblomni_log_sync_woo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblomni_log_sync_woo` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `regular_price` int(11) NOT NULL,
  `sale_price` int(11) NOT NULL,
  `date_on_sale_from` date DEFAULT NULL,
  `date_on_sale_to` date DEFAULT NULL,
  `short_description` text DEFAULT NULL,
  `stock_quantity` int(11) DEFAULT NULL,
  `sku` text NOT NULL,
  `type` varchar(225) NOT NULL,
  `date_sync` datetime NOT NULL DEFAULT current_timestamp(),
  `stock_quantity_history` int(11) NOT NULL DEFAULT 0,
  `order_id` int(11) NOT NULL,
  `chanel` varchar(250) NOT NULL DEFAULT '',
  `company` varchar(250) NOT NULL DEFAULT '',
  `description` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblomni_log_sync_woo`
--

LOCK TABLES `maxlife_tblomni_log_sync_woo` WRITE;
/*!40000 ALTER TABLE `maxlife_tblomni_log_sync_woo` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblomni_log_sync_woo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblomni_master_channel_woocommere`
--

DROP TABLE IF EXISTS `maxlife_tblomni_master_channel_woocommere`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblomni_master_channel_woocommere` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name_channel` text NOT NULL,
  `consumer_key` text NOT NULL,
  `consumer_secret` text NOT NULL,
  `url` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblomni_master_channel_woocommere`
--

LOCK TABLES `maxlife_tblomni_master_channel_woocommere` WRITE;
/*!40000 ALTER TABLE `maxlife_tblomni_master_channel_woocommere` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblomni_master_channel_woocommere` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblomni_pre_order_product_setting`
--

DROP TABLE IF EXISTS `maxlife_tblomni_pre_order_product_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblomni_pre_order_product_setting` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `channel_id` int(11) NOT NULL,
  `customer_group` text DEFAULT NULL,
  `customer` text DEFAULT NULL,
  `group_product_id` int(11) DEFAULT NULL,
  `datecreator` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblomni_pre_order_product_setting`
--

LOCK TABLES `maxlife_tblomni_pre_order_product_setting` WRITE;
/*!40000 ALTER TABLE `maxlife_tblomni_pre_order_product_setting` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblomni_pre_order_product_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblomni_refunds`
--

DROP TABLE IF EXISTS `maxlife_tblomni_refunds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblomni_refunds` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(11) DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `refunded_on` date DEFAULT NULL,
  `payment_mode` varchar(40) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `amount` decimal(15,2) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblomni_refunds`
--

LOCK TABLES `maxlife_tblomni_refunds` WRITE;
/*!40000 ALTER TABLE `maxlife_tblomni_refunds` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblomni_refunds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblomni_setting_woo_store`
--

DROP TABLE IF EXISTS `maxlife_tblomni_setting_woo_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblomni_setting_woo_store` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `store` int(11) NOT NULL,
  `sync_omni_sales_products` int(11) NOT NULL DEFAULT 0,
  `time1` int(11) NOT NULL DEFAULT 50,
  `sync_omni_sales_inventorys` int(11) NOT NULL DEFAULT 0,
  `time2` int(11) NOT NULL DEFAULT 50,
  `price_crm_woo` int(11) NOT NULL DEFAULT 0,
  `time3` int(11) NOT NULL DEFAULT 50,
  `sync_omni_sales_description` int(11) NOT NULL DEFAULT 0,
  `time4` int(11) NOT NULL DEFAULT 50,
  `sync_omni_sales_images` int(11) NOT NULL DEFAULT 0,
  `time5` int(11) NOT NULL DEFAULT 50,
  `sync_omni_sales_orders` int(11) NOT NULL DEFAULT 0,
  `time6` int(11) NOT NULL DEFAULT 50,
  `product_info_enable_disable` int(11) NOT NULL DEFAULT 0,
  `time7` int(11) NOT NULL DEFAULT 50,
  `product_info_image_enable_disable` int(11) NOT NULL DEFAULT 0,
  `time8` int(11) NOT NULL DEFAULT 50,
  `datecreator` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblomni_setting_woo_store`
--

LOCK TABLES `maxlife_tblomni_setting_woo_store` WRITE;
/*!40000 ALTER TABLE `maxlife_tblomni_setting_woo_store` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblomni_setting_woo_store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblomni_shift`
--

DROP TABLE IF EXISTS `maxlife_tblomni_shift`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblomni_shift` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `shift_code` varchar(150) DEFAULT NULL,
  `granted_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `incurred_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `closing_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `status` int(11) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `order_value` decimal(15,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblomni_shift`
--

LOCK TABLES `maxlife_tblomni_shift` WRITE;
/*!40000 ALTER TABLE `maxlife_tblomni_shift` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblomni_shift` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblomni_shift_history`
--

DROP TABLE IF EXISTS `maxlife_tblomni_shift_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblomni_shift_history` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `shift_id` int(11) NOT NULL,
  `action` varchar(150) DEFAULT NULL,
  `granted_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `current_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `customer_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `balance_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `staff_id` int(11) DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `order_value` decimal(15,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblomni_shift_history`
--

LOCK TABLES `maxlife_tblomni_shift_history` WRITE;
/*!40000 ALTER TABLE `maxlife_tblomni_shift_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblomni_shift_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblomni_trade_discount`
--

DROP TABLE IF EXISTS `maxlife_tblomni_trade_discount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblomni_trade_discount` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name_trade_discount` varchar(250) NOT NULL,
  `start_time` date NOT NULL,
  `end_time` date NOT NULL,
  `group_clients` text NOT NULL,
  `clients` text NOT NULL,
  `group_items` text NOT NULL,
  `items` text NOT NULL,
  `formal` int(11) NOT NULL,
  `discount` int(11) NOT NULL,
  `voucher` text DEFAULT NULL,
  `channel` int(11) NOT NULL DEFAULT 0,
  `store` varchar(11) NOT NULL DEFAULT '',
  `minimum_order_value` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblomni_trade_discount`
--

LOCK TABLES `maxlife_tblomni_trade_discount` WRITE;
/*!40000 ALTER TABLE `maxlife_tblomni_trade_discount` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblomni_trade_discount` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tbloptions`
--

DROP TABLE IF EXISTS `maxlife_tbloptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tbloptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `value` longtext NOT NULL,
  `autoload` tinyint(1) NOT NULL DEFAULT 1,
  `annual_turnover` decimal(15,2) DEFAULT 0.00 COMMENT 'Yearly turnover (?) as declared by admin or fetched from GSTR-3B',
  `einvoice_enabled` tinyint(1) DEFAULT 0 COMMENT 'True/False – whether E-Invoicing is enabled for this company',
  `einvoice_enforced` tinyint(1) DEFAULT 0 COMMENT 'True if system decides it must be enabled (auto based on turnover)',
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=919 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tbloptions`
--

LOCK TABLES `maxlife_tbloptions` WRITE;
/*!40000 ALTER TABLE `maxlife_tbloptions` DISABLE KEYS */;
INSERT INTO `maxlife_tbloptions` VALUES (1,'dateformat','Y-m-d|%Y-%m-%d',1,0.00,0,0),(2,'companyname','max life insurance',1,0.00,0,0),(3,'services','1',1,0.00,0,0),(4,'maximum_allowed_ticket_attachments','4',1,0.00,0,0),(5,'ticket_attachments_file_extensions','.jpg,.png,.pdf,.doc,.zip,.rar',1,0.00,0,0),(6,'staff_access_only_assigned_departments','1',1,0.00,0,0),(7,'use_knowledge_base','1',1,0.00,0,0),(8,'smtp_email','noreply@techdotbit.com',1,0.00,0,0),(10,'company_info_format','{company_name}<br />\r\n      {address}<br />\r\n      {city} {state}<br />\r\n      {country_code} {zip_code}<br />\r\n      {vat_number_with_label}',0,0.00,0,0),(11,'smtp_port','587',1,0.00,0,0),(12,'smtp_host','smtp.hostinger.com',1,0.00,0,0),(13,'smtp_email_charset','utf-8',1,0.00,0,0),(14,'default_timezone','Asia/Kolkata',1,0.00,0,0),(15,'clients_default_theme','perfex',1,0.00,0,0),(17,'tables_pagination_limit','25',1,0.00,0,0),(19,'allow_registration','1',1,0.00,0,0),(20,'knowledge_base_without_registration','1',1,0.00,0,0),(21,'email_signature','<br><br>\r\n--<br>\r\n<b>DOT ONE ERP System</b><br>\r\nAutomated Notification Service<br>\r\n? no-reply@techdotbit.in<br>\r\n? <a href=\"https://www.techdotbit.in\" target=\"_blank\">www.techdotbit.in</a><br>\r\n<small><i>Please do not reply to this email. For assistance, contact support@techdotbit.com</i></small>',1,0.00,0,0),(22,'default_staff_role','1',1,0.00,0,0),(23,'newsfeed_maximum_files_upload','10',1,0.00,0,0),(24,'contract_expiration_before','4',1,0.00,0,0),(25,'invoice_prefix','INV-',1,0.00,0,0),(26,'decimal_separator','.',1,0.00,0,0),(27,'thousand_separator',',',1,0.00,0,0),(34,'view_invoice_only_logged_in','1',1,0.00,0,0),(35,'invoice_number_format','1',1,0.00,0,0),(36,'next_invoice_number','1',0,0.00,0,0),(37,'active_language','english',1,0.00,0,0),(38,'invoice_number_decrement_on_delete','1',1,0.00,0,0),(39,'automatically_send_invoice_overdue_reminder_after','1',1,0.00,0,0),(40,'automatically_resend_invoice_overdue_reminder_after','3',1,0.00,0,0),(41,'expenses_auto_operations_hour','21',1,0.00,0,0),(42,'delete_only_on_last_invoice','1',1,0.00,0,0),(43,'delete_only_on_last_estimate','1',1,0.00,0,0),(44,'create_invoice_from_recurring_only_on_paid_invoices','0',1,0.00,0,0),(45,'allow_payment_amount_to_be_modified','0',1,0.00,0,0),(46,'rtl_support_client','0',1,0.00,0,0),(47,'limit_top_search_bar_results_to','10',1,0.00,0,0),(48,'estimate_prefix','EST-',1,0.00,0,0),(49,'next_estimate_number','1',0,0.00,0,0),(50,'estimate_number_decrement_on_delete','1',1,0.00,0,0),(51,'estimate_number_format','1',1,0.00,0,0),(52,'estimate_auto_convert_to_invoice_on_client_accept','1',1,0.00,0,0),(53,'exclude_estimate_from_client_area_with_draft_status','1',1,0.00,0,0),(54,'rtl_support_admin','0',1,0.00,0,0),(55,'last_cron_run','1752413395',1,0.00,0,0),(56,'show_sale_agent_on_estimates','1',1,0.00,0,0),(57,'show_sale_agent_on_invoices','1',1,0.00,0,0),(58,'predefined_terms_invoice','',1,0.00,0,0),(59,'predefined_terms_estimate','',1,0.00,0,0),(60,'default_task_priority','2',1,0.00,0,0),(62,'show_expense_reminders_on_calendar','1',1,0.00,0,0),(63,'only_show_contact_tickets','1',1,0.00,0,0),(64,'predefined_clientnote_invoice','',1,0.00,0,0),(65,'predefined_clientnote_estimate','',1,0.00,0,0),(66,'custom_pdf_logo_image_url','',1,0.00,0,0),(68,'invoice_due_after','30',1,0.00,0,0),(70,'google_calendar_main_calendar','',1,0.00,0,0),(71,'default_tax','a:0:{}',1,0.00,0,0),(72,'show_invoices_on_calendar','1',1,0.00,0,0),(73,'show_estimates_on_calendar','1',1,0.00,0,0),(74,'show_contracts_on_calendar','1',1,0.00,0,0),(75,'show_tasks_on_calendar','1',1,0.00,0,0),(76,'show_customer_reminders_on_calendar','1',1,0.00,0,0),(77,'output_client_pdfs_from_admin_area_in_client_language','0',1,0.00,0,0),(78,'show_lead_reminders_on_calendar','1',1,0.00,0,0),(79,'send_estimate_expiry_reminder_before','4',1,0.00,0,0),(80,'leads_default_source','',1,0.00,0,0),(81,'leads_default_status','',1,0.00,0,0),(82,'proposal_expiry_reminder_enabled','1',1,0.00,0,0),(83,'send_proposal_expiry_reminder_before','4',1,0.00,0,0),(84,'default_contact_permissions','a:8:{i:0;s:1:\"1\";i:1;s:1:\"2\";i:2;s:1:\"3\";i:3;s:1:\"4\";i:4;s:1:\"5\";i:5;s:1:\"6\";i:6;s:6:\"311301\";i:7;s:6:\"311302\";}',1,0.00,0,0),(85,'pdf_logo_width','150',1,0.00,0,0),(86,'access_tickets_to_none_staff_members','0',1,0.00,0,0),(87,'customer_default_country','102',1,0.00,0,0),(88,'view_estimate_only_logged_in','0',1,0.00,0,0),(89,'show_status_on_pdf_ei','1',1,0.00,0,0),(90,'email_piping_only_replies','0',1,0.00,0,0),(91,'email_piping_only_registered','0',1,0.00,0,0),(92,'default_view_calendar','dayGridMonth',1,0.00,0,0),(93,'email_piping_default_priority','2',1,0.00,0,0),(94,'total_to_words_lowercase','0',1,0.00,0,0),(95,'show_tax_per_item','1',1,0.00,0,0),(96,'total_to_words_enabled','0',1,0.00,0,0),(97,'receive_notification_on_new_ticket','1',0,0.00,0,0),(98,'autoclose_tickets_after','0',1,0.00,0,0),(99,'media_max_file_size_upload','10',1,0.00,0,0),(100,'client_staff_add_edit_delete_task_comments_first_hour','0',1,0.00,0,0),(101,'show_projects_on_calendar','1',1,0.00,0,0),(102,'leads_kanban_limit','50',1,0.00,0,0),(103,'tasks_reminder_notification_before','2',1,0.00,0,0),(104,'pdf_font','freesans',1,0.00,0,0),(105,'pdf_table_heading_color','#323a45',1,0.00,0,0),(106,'pdf_table_heading_text_color','#ffffff',1,0.00,0,0),(107,'pdf_font_size','10',1,0.00,0,0),(108,'default_leads_kanban_sort','leadorder',1,0.00,0,0),(109,'default_leads_kanban_sort_type','asc',1,0.00,0,0),(110,'allowed_files','.png,.jpg,.pdf,.doc,.docx,.xls,.xlsx,.zip,.rar,.txt',1,0.00,0,0),(111,'show_all_tasks_for_project_member','1',1,0.00,0,0),(112,'email_protocol','smtp',1,0.00,0,0),(113,'calendar_first_day','0',1,0.00,0,0),(115,'show_help_on_setup_menu','1',1,0.00,0,0),(116,'show_proposals_on_calendar','1',1,0.00,0,0),(117,'smtp_encryption','ssl',1,0.00,0,0),(119,'smtp_username','noreply@techdotbit.com',1,0.00,0,0),(120,'auto_stop_tasks_timers_on_new_timer','1',1,0.00,0,0),(121,'notification_when_customer_pay_invoice','1',1,0.00,0,0),(122,'calendar_invoice_color','#FF6F00',1,0.00,0,0),(123,'calendar_estimate_color','#FF6F00',1,0.00,0,0),(124,'calendar_proposal_color','#84c529',1,0.00,0,0),(125,'new_task_auto_assign_current_member','1',1,0.00,0,0),(126,'calendar_reminder_color','#03A9F4',1,0.00,0,0),(127,'calendar_contract_color','#B72974',1,0.00,0,0),(128,'calendar_project_color','#B72974',1,0.00,0,0),(129,'update_info_message','',1,0.00,0,0),(130,'show_estimate_reminders_on_calendar','1',1,0.00,0,0),(131,'show_invoice_reminders_on_calendar','1',1,0.00,0,0),(132,'show_proposal_reminders_on_calendar','1',1,0.00,0,0),(133,'proposal_due_after','7',1,0.00,0,0),(134,'allow_customer_to_change_ticket_status','0',1,0.00,0,0),(135,'lead_lock_after_convert_to_customer','0',1,0.00,0,0),(136,'default_proposals_pipeline_sort','pipeline_order',1,0.00,0,0),(137,'default_proposals_pipeline_sort_type','asc',1,0.00,0,0),(138,'default_estimates_pipeline_sort','pipeline_order',1,0.00,0,0),(139,'default_estimates_pipeline_sort_type','asc',1,0.00,0,0),(140,'use_recaptcha_customers_area','0',1,0.00,0,0),(141,'remove_decimals_on_zero','0',1,0.00,0,0),(142,'remove_tax_name_from_item_table','0',1,0.00,0,0),(143,'pdf_format_invoice','A4-PORTRAIT',1,0.00,0,0),(144,'pdf_format_estimate','A4-PORTRAIT',1,0.00,0,0),(145,'pdf_format_proposal','A4-PORTRAIT',1,0.00,0,0),(146,'pdf_format_payment','A4-PORTRAIT',1,0.00,0,0),(147,'pdf_format_contract','A4-PORTRAIT',1,0.00,0,0),(148,'swap_pdf_info','0',1,0.00,0,0),(149,'exclude_invoice_from_client_area_with_draft_status','1',1,0.00,0,0),(150,'cron_has_run_from_cli','1',1,0.00,0,0),(151,'hide_cron_is_required_message','0',0,0.00,0,0),(152,'auto_assign_customer_admin_after_lead_convert','1',1,0.00,0,0),(153,'show_transactions_on_invoice_pdf','1',1,0.00,0,0),(154,'show_pay_link_to_invoice_pdf','1',1,0.00,0,0),(155,'tasks_kanban_limit','50',1,0.00,0,0),(157,'estimates_pipeline_limit','50',1,0.00,0,0),(158,'proposals_pipeline_limit','50',1,0.00,0,0),(159,'proposal_number_prefix','PRO-',1,0.00,0,0),(160,'number_padding_prefixes','6',1,0.00,0,0),(161,'show_page_number_on_pdf','0',1,0.00,0,0),(162,'calendar_events_limit','4',1,0.00,0,0),(163,'show_setup_menu_item_only_on_hover','0',1,0.00,0,0),(164,'company_requires_vat_number_field','1',1,0.00,0,0),(165,'company_is_required','1',1,0.00,0,0),(166,'allow_contact_to_delete_files','0',1,0.00,0,0),(168,'di','1750847029',1,0.00,0,0),(169,'invoice_auto_operations_hour','21',1,0.00,0,0),(170,'use_minified_files','1',1,0.00,0,0),(171,'only_own_files_contacts','0',1,0.00,0,0),(172,'allow_primary_contact_to_view_edit_billing_and_shipping','0',1,0.00,0,0),(173,'estimate_due_after','7',1,0.00,0,0),(174,'staff_members_open_tickets_to_all_contacts','1',1,0.00,0,0),(175,'time_format','24',1,0.00,0,0),(176,'delete_activity_log_older_then','1',1,0.00,0,0),(177,'disable_language','0',1,0.00,0,0),(179,'email_header','<!doctype html>\r\n      <html>\r\n      <head>\r\n      <meta name=\"viewport\" content=\"width=device-width\" />\r\n      <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />\r\n      <style>\r\n      body {\r\n        background-color: #f6f6f6;\r\n        font-family: sans-serif;\r\n        -webkit-font-smoothing: antialiased;\r\n        font-size: 14px;\r\n        line-height: 1.4;\r\n        margin: 0;\r\n        padding: 0;\r\n        -ms-text-size-adjust: 100%;\r\n        -webkit-text-size-adjust: 100%;\r\n      }\r\n      table {\r\n        border-collapse: separate;\r\n        mso-table-lspace: 0pt;\r\n        mso-table-rspace: 0pt;\r\n        width: 100%;\r\n      }\r\n      table td {\r\n        font-family: sans-serif;\r\n        font-size: 14px;\r\n        vertical-align: top;\r\n      }\r\n      /* -------------------------------------\r\n      BODY & CONTAINER\r\n      ------------------------------------- */\r\n      .body {\r\n        background-color: #f6f6f6;\r\n        width: 100%;\r\n      }\r\n      /* Set a max-width, and make it display as block so it will automatically stretch to that width, but will also shrink down on a phone or something */\r\n      \r\n      .container {\r\n        display: block;\r\n        margin: 0 auto !important;\r\n        /* makes it centered */\r\n        max-width: 680px;\r\n        padding: 10px;\r\n        width: 680px;\r\n      }\r\n      /* This should also be a block element, so that it will fill 100% of the .container */\r\n      \r\n      .content {\r\n        box-sizing: border-box;\r\n        display: block;\r\n        margin: 0 auto;\r\n        max-width: 680px;\r\n        padding: 10px;\r\n      }\r\n      /* -------------------------------------\r\n      HEADER, FOOTER, MAIN\r\n      ------------------------------------- */\r\n      \r\n      .main {\r\n        background: #fff;\r\n        border-radius: 3px;\r\n        width: 100%;\r\n      }\r\n      .wrapper {\r\n        box-sizing: border-box;\r\n        padding: 20px;\r\n      }\r\n      .footer {\r\n        clear: both;\r\n        padding-top: 10px;\r\n        text-align: center;\r\n        width: 100%;\r\n      }\r\n      .footer td,\r\n      .footer p,\r\n      .footer span,\r\n      .footer a {\r\n        color: #999999;\r\n        font-size: 12px;\r\n        text-align: center;\r\n      }\r\n      hr {\r\n        border: 0;\r\n        border-bottom: 1px solid #f6f6f6;\r\n        margin: 20px 0;\r\n      }\r\n      /* -------------------------------------\r\n      RESPONSIVE AND MOBILE FRIENDLY STYLES\r\n      ------------------------------------- */\r\n      \r\n      @media only screen and (max-width: 620px) {\r\n        table[class=body] .content {\r\n          padding: 0 !important;\r\n        }\r\n        table[class=body] .container {\r\n          padding: 0 !important;\r\n          width: 100% !important;\r\n        }\r\n        table[class=body] .main {\r\n          border-left-width: 0 !important;\r\n          border-radius: 0 !important;\r\n          border-right-width: 0 !important;\r\n        }\r\n      }\r\n      </style>\r\n      </head>\r\n      <body class=\"\">\r\n      <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" class=\"body\">\r\n      <tr>\r\n      <td>&nbsp;</td>\r\n      <td class=\"container\">\r\n      <div class=\"content\">\r\n      <!-- START CENTERED WHITE CONTAINER -->\r\n      <table class=\"main\">\r\n      <!-- START MAIN CONTENT AREA -->\r\n      <tr>\r\n      <td class=\"wrapper\">\r\n      <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\r\n      <tr>\r\n      <td>',1,0.00,0,0),(180,'show_pdf_signature_invoice','1',0,0.00,0,0),(181,'show_pdf_signature_estimate','1',0,0.00,0,0),(182,'signature_image','',0,0.00,0,0),(183,'email_footer','</td>\r\n      </tr>\r\n      </table>\r\n      </td>\r\n      </tr>\r\n      <!-- END MAIN CONTENT AREA -->\r\n      </table>\r\n      <!-- START FOOTER -->\r\n      <div class=\"footer\">\r\n      <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\r\n      <tr>\r\n      <td class=\"content-block\">\r\n      <span>{companyname}</span>\r\n      </td>\r\n      </tr>\r\n      </table>\r\n      </div>\r\n      <!-- END FOOTER -->\r\n      <!-- END CENTERED WHITE CONTAINER -->\r\n      </div>\r\n      </td>\r\n      <td>&nbsp;</td>\r\n      </tr>\r\n      </table>\r\n      </body>\r\n      </html>',1,0.00,0,0),(184,'exclude_proposal_from_client_area_with_draft_status','1',1,0.00,0,0),(188,'pusher_realtime_notifications','0',1,0.00,0,0),(189,'pdf_format_statement','A4-PORTRAIT',1,0.00,0,0),(190,'pusher_cluster','',1,0.00,0,0),(191,'show_table_export_button','to_all',1,0.00,0,0),(192,'allow_staff_view_proposals_assigned','1',1,0.00,0,0),(193,'show_cloudflare_notice','1',0,0.00,0,0),(194,'task_modal_class','modal-lg',1,0.00,0,0),(195,'lead_modal_class','modal-lg',1,0.00,0,0),(196,'show_timesheets_overview_all_members_notice_admins','0',1,0.00,0,0),(197,'desktop_notifications','0',1,0.00,0,0),(198,'hide_notified_reminders_from_calendar','1',0,0.00,0,0),(199,'customer_info_format','{company_name}<br />\r\n      {street}<br />\r\n      {city} {state}<br />\r\n      {country_code} {zip_code}<br />\r\n      {vat_number_with_label}',0,0.00,0,0),(200,'timer_started_change_status_in_progress','1',0,0.00,0,0),(201,'default_ticket_reply_status','3',1,0.00,0,0),(202,'default_task_status','auto',1,0.00,0,0),(203,'email_queue_skip_with_attachments','1',1,0.00,0,0),(204,'email_queue_enabled','0',1,0.00,0,0),(205,'last_email_queue_retry','1752413395',1,0.00,0,0),(206,'auto_dismiss_desktop_notifications_after','0',1,0.00,0,0),(207,'proposal_info_format','{proposal_to}<br />\r\n      {address}<br />\r\n      {city} {state}<br />\r\n      {country_code} {zip_code}<br />\r\n      {phone}<br />\r\n      {email}',0,0.00,0,0),(208,'ticket_replies_order','asc',1,0.00,0,0),(209,'new_recurring_invoice_action','generate_and_send',0,0.00,0,0),(210,'bcc_emails','',0,0.00,0,0),(211,'email_templates_language_checks','',0,0.00,0,0),(212,'proposal_accept_identity_confirmation','1',0,0.00,0,0),(213,'estimate_accept_identity_confirmation','1',0,0.00,0,0),(214,'new_task_auto_follower_current_member','0',1,0.00,0,0),(215,'task_biillable_checked_on_creation','1',1,0.00,0,0),(216,'predefined_clientnote_credit_note','',1,0.00,0,0),(217,'predefined_terms_credit_note','',1,0.00,0,0),(218,'next_credit_note_number','1',1,0.00,0,0),(219,'credit_note_prefix','CN-',1,0.00,0,0),(220,'credit_note_number_decrement_on_delete','1',1,0.00,0,0),(221,'pdf_format_credit_note','A4-PORTRAIT',1,0.00,0,0),(222,'show_pdf_signature_credit_note','1',0,0.00,0,0),(223,'show_credit_note_reminders_on_calendar','1',1,0.00,0,0),(224,'show_amount_due_on_invoice','1',1,0.00,0,0),(225,'show_total_paid_on_invoice','1',1,0.00,0,0),(226,'show_credits_applied_on_invoice','1',1,0.00,0,0),(227,'staff_members_create_inline_lead_status','1',1,0.00,0,0),(228,'staff_members_create_inline_customer_groups','1',1,0.00,0,0),(229,'staff_members_create_inline_ticket_services','1',1,0.00,0,0),(230,'staff_members_save_tickets_predefined_replies','1',1,0.00,0,0),(231,'staff_members_create_inline_contract_types','1',1,0.00,0,0),(232,'staff_members_create_inline_expense_categories','1',1,0.00,0,0),(233,'show_project_on_credit_note','1',1,0.00,0,0),(234,'proposals_auto_operations_hour','21',1,0.00,0,0),(235,'estimates_auto_operations_hour','21',1,0.00,0,0),(236,'contracts_auto_operations_hour','21',1,0.00,0,0),(237,'credit_note_number_format','1',1,0.00,0,0),(238,'allow_non_admin_members_to_import_leads','0',1,0.00,0,0),(239,'e_sign_legal_text','By clicking on \"Sign\", I consent to be legally bound by this electronic representation of my signature.',1,0.00,0,0),(240,'show_pdf_signature_contract','1',1,0.00,0,0),(241,'view_contract_only_logged_in','0',1,0.00,0,0),(242,'show_subscriptions_in_customers_area','1',1,0.00,0,0),(243,'calendar_only_assigned_tasks','0',1,0.00,0,0),(244,'after_subscription_payment_captured','send_invoice_and_receipt',1,0.00,0,0),(245,'mail_engine','phpmailer',1,0.00,0,0),(246,'gdpr_enable_terms_and_conditions','0',1,0.00,0,0),(247,'privacy_policy','',1,0.00,0,0),(248,'terms_and_conditions','',1,0.00,0,0),(249,'gdpr_enable_terms_and_conditions_lead_form','0',1,0.00,0,0),(250,'gdpr_enable_terms_and_conditions_ticket_form','0',1,0.00,0,0),(251,'gdpr_contact_enable_right_to_be_forgotten','0',1,0.00,0,0),(252,'show_gdpr_in_customers_menu','1',1,0.00,0,0),(253,'show_gdpr_link_in_footer','1',1,0.00,0,0),(254,'enable_gdpr','0',1,0.00,0,0),(255,'gdpr_on_forgotten_remove_invoices_credit_notes','0',1,0.00,0,0),(256,'gdpr_on_forgotten_remove_estimates','0',1,0.00,0,0),(257,'gdpr_enable_consent_for_contacts','0',1,0.00,0,0),(258,'gdpr_consent_public_page_top_block','',1,0.00,0,0),(259,'gdpr_page_top_information_block','',1,0.00,0,0),(260,'gdpr_enable_lead_public_form','0',1,0.00,0,0),(261,'gdpr_show_lead_custom_fields_on_public_form','0',1,0.00,0,0),(262,'gdpr_lead_attachments_on_public_form','0',1,0.00,0,0),(263,'gdpr_enable_consent_for_leads','0',1,0.00,0,0),(264,'gdpr_lead_enable_right_to_be_forgotten','0',1,0.00,0,0),(265,'allow_staff_view_invoices_assigned','1',1,0.00,0,0),(266,'gdpr_data_portability_leads','0',1,0.00,0,0),(267,'gdpr_lead_data_portability_allowed','',1,0.00,0,0),(268,'gdpr_contact_data_portability_allowed','',1,0.00,0,0),(269,'gdpr_data_portability_contacts','0',1,0.00,0,0),(270,'allow_staff_view_estimates_assigned','1',1,0.00,0,0),(271,'gdpr_after_lead_converted_delete','0',1,0.00,0,0),(272,'gdpr_show_terms_and_conditions_in_footer','0',1,0.00,0,0),(273,'save_last_order_for_tables','0',1,0.00,0,0),(275,'customers_register_require_confirmation','0',1,0.00,0,0),(276,'allow_non_admin_staff_to_delete_ticket_attachments','0',1,0.00,0,0),(277,'receive_notification_on_new_ticket_replies','1',0,0.00,0,0),(279,'enable_google_picker','1',1,0.00,0,0),(280,'show_ticket_reminders_on_calendar','1',1,0.00,0,0),(281,'ticket_import_reply_only','0',1,0.00,0,0),(282,'visible_customer_profile_tabs','a:19:{s:7:\"profile\";b:0;s:8:\"contacts\";b:0;s:5:\"notes\";b:1;s:9:\"statement\";b:1;s:8:\"invoices\";b:1;s:8:\"payments\";b:1;s:9:\"proposals\";b:1;s:12:\"credit_notes\";b:1;s:9:\"estimates\";b:1;s:13:\"subscriptions\";b:1;s:8:\"expenses\";b:1;s:9:\"contracts\";b:1;s:8:\"projects\";b:1;s:5:\"tasks\";b:1;s:7:\"tickets\";b:1;s:11:\"attachments\";b:1;s:5:\"vault\";b:1;s:9:\"reminders\";b:1;s:3:\"map\";b:1;}',0,0.00,0,0),(283,'show_project_on_invoice','0',1,0.00,0,0),(284,'show_project_on_estimate','1',1,0.00,0,0),(285,'staff_members_create_inline_lead_source','1',1,0.00,0,0),(286,'lead_unique_validation','[\"email\"]',1,0.00,0,0),(287,'last_upgrade_copy_data','',1,0.00,0,0),(288,'custom_js_admin_scripts','',1,0.00,0,0),(289,'custom_js_customer_scripts','0',1,0.00,0,0),(294,'show_php_version_notice','1',0,0.00,0,0),(295,'recaptcha_ignore_ips','',1,0.00,0,0),(296,'show_task_reminders_on_calendar','1',1,0.00,0,0),(297,'customer_settings','true',1,0.00,0,0),(298,'tasks_reminder_notification_hour','21',1,0.00,0,0),(299,'allow_primary_contact_to_manage_other_contacts','0',1,0.00,0,0),(300,'items_table_amounts_exclude_currency_symbol','1',1,0.00,0,0),(301,'round_off_task_timer_option','0',1,0.00,0,0),(302,'round_off_task_timer_time','5',1,0.00,0,0),(304,'enable_support_menu_badges','0',1,0.00,0,0),(305,'attach_invoice_to_payment_receipt_email','0',1,0.00,0,0),(306,'invoice_due_notice_before','2',1,0.00,0,0),(307,'invoice_due_notice_resend_after','0',1,0.00,0,0),(308,'_leads_settings','true',1,0.00,0,0),(309,'show_estimate_request_in_customers_area','0',1,0.00,0,0),(310,'gdpr_enable_terms_and_conditions_estimate_request_form','0',1,0.00,0,0),(312,'automatically_stop_task_timer_after_hours','8',1,0.00,0,0),(313,'automatically_assign_ticket_to_first_staff_responding','0',1,0.00,0,0),(314,'reminder_for_completed_but_not_billed_tasks','0',1,0.00,0,0),(315,'staff_notify_completed_but_not_billed_tasks','',1,0.00,0,0),(316,'reminder_for_completed_but_not_billed_tasks_days','',1,0.00,0,0),(317,'tasks_reminder_notification_last_notified_day','',1,0.00,0,0),(318,'staff_related_ticket_notification_to_assignee_only','0',1,0.00,0,0),(319,'show_pdf_signature_proposal','1',1,0.00,0,0),(320,'enable_honeypot_spam_validation','1',1,0.00,0,0),(328,'automatically_set_logged_in_staff_sales_agent','1',1,0.00,0,0),(329,'contract_sign_reminder_every_days','0',1,0.00,0,0),(330,'last_updated_date','',1,0.00,0,0),(331,'v310_incompatible_tables','[]',1,0.00,0,0),(332,'upgraded_from_version','',0,0.00,0,0),(334,'sms_clickatell_active','0',1,0.00,0,0),(335,'sms_clickatell_initialized','1',1,0.00,0,0),(337,'sms_msg91_api_type','api',1,0.00,0,0),(339,'sms_msg91_active','0',1,0.00,0,0),(340,'sms_msg91_initialized','1',1,0.00,0,0),(341,'sms_twilio_account_sid','',1,0.00,0,0),(343,'sms_twilio_phone_number','',1,0.00,0,0),(345,'sms_twilio_active','0',1,0.00,0,0),(346,'sms_twilio_initialized','1',1,0.00,0,0),(347,'cr_date_cronjob_currency_rates','2025-07-13',1,0.00,0,0),(348,'cr_automatically_get_currency_rate','1',1,0.00,0,0),(349,'cr_global_amount_expiration','0',1,0.00,0,0),(350,'hr_profile_hide_menu','1',1,0.00,0,0),(351,'account_planning_enabled','1',1,0.00,0,0),(353,'mailbox_last_verification','1750867445',1,0.00,0,0),(355,'mailbox_enabled','1',1,0.00,0,0),(356,'mailbox_imap_server','',1,0.00,0,0),(357,'mailbox_encryption','',1,0.00,0,0),(358,'mailbox_folder_scan','Inbox',1,0.00,0,0),(359,'mailbox_check_every','3',1,0.00,0,0),(360,'mailbox_only_loop_on_unseen_emails','1',1,0.00,0,0),(361,'acc_first_month_of_financial_year','January',1,0.00,0,0),(362,'acc_first_month_of_tax_year','same_as_financial_year',1,0.00,0,0),(363,'acc_accounting_method','accrual',1,0.00,0,0),(364,'acc_close_the_books','0',1,0.00,0,0),(365,'acc_allow_changes_after_viewing','allow_changes_after_viewing_a_warning',1,0.00,0,0),(368,'acc_enable_account_numbers','0',1,0.00,0,0),(369,'acc_show_account_numbers','0',1,0.00,0,0),(370,'acc_closing_date','',1,0.00,0,0),(371,'acc_add_default_account','1',1,0.00,0,0),(372,'acc_add_default_account_new','0',1,0.00,0,0),(373,'acc_invoice_automatic_conversion','1',1,0.00,0,0),(374,'acc_payment_automatic_conversion','1',1,0.00,0,0),(375,'acc_credit_note_automatic_conversion','1',1,0.00,0,0),(376,'acc_credit_note_refund_automatic_conversion','1',1,0.00,0,0),(377,'acc_expense_automatic_conversion','1',1,0.00,0,0),(378,'acc_tax_automatic_conversion','1',1,0.00,0,0),(379,'acc_invoice_payment_account','66',1,0.00,0,0),(380,'acc_invoice_deposit_to','1',1,0.00,0,0),(381,'acc_payment_payment_account','1',1,0.00,0,0),(382,'acc_payment_deposit_to','13',1,0.00,0,0),(383,'acc_credit_note_payment_account','1',1,0.00,0,0),(384,'acc_credit_note_deposit_to','13',1,0.00,0,0),(385,'acc_credit_note_refund_payment_account','1',1,0.00,0,0),(386,'acc_credit_note_refund_deposit_to','13',1,0.00,0,0),(387,'acc_expense_payment_account','13',1,0.00,0,0),(388,'acc_expense_deposit_to','80',1,0.00,0,0),(389,'acc_tax_payment_account','29',1,0.00,0,0),(390,'acc_tax_deposit_to','1',1,0.00,0,0),(391,'acc_expense_tax_payment_account','13',1,0.00,0,0),(392,'acc_expense_tax_deposit_to','29',1,0.00,0,0),(393,'acc_active_payment_mode_mapping','1',1,0.00,0,0),(394,'acc_active_expense_category_mapping','1',1,0.00,0,0),(395,'acc_payment_expense_automatic_conversion','1',1,0.00,0,0),(396,'acc_payment_sale_automatic_conversion','1',1,0.00,0,0),(397,'acc_expense_payment_payment_account','1',1,0.00,0,0),(398,'acc_expense_payment_deposit_to','1',1,0.00,0,0),(399,'acc_pl_total_insurance_automatic_conversion','1',1,0.00,0,0),(400,'acc_pl_total_insurance_payment_account','13',1,0.00,0,0),(401,'acc_pl_total_insurance_deposit_to','32',1,0.00,0,0),(402,'acc_pl_tax_paye_automatic_conversion','1',1,0.00,0,0),(403,'acc_pl_tax_paye_payment_account','13',1,0.00,0,0),(404,'acc_pl_tax_paye_deposit_to','28',1,0.00,0,0),(405,'acc_pl_net_pay_automatic_conversion','1',1,0.00,0,0),(406,'acc_pl_net_pay_payment_account','13',1,0.00,0,0),(407,'acc_pl_net_pay_deposit_to','56',1,0.00,0,0),(408,'acc_wh_stock_import_automatic_conversion','1',1,0.00,0,0),(409,'acc_wh_stock_import_payment_account','87',1,0.00,0,0),(410,'acc_wh_stock_import_deposit_to','37',1,0.00,0,0),(411,'acc_wh_stock_export_automatic_conversion','1',1,0.00,0,0),(412,'acc_wh_stock_export_payment_account','37',1,0.00,0,0),(413,'acc_wh_stock_export_deposit_to','1',1,0.00,0,0),(414,'acc_wh_loss_adjustment_automatic_conversion','1',1,0.00,0,0),(415,'acc_wh_decrease_payment_account','37',1,0.00,0,0),(416,'acc_wh_decrease_deposit_to','1',1,0.00,0,0),(417,'acc_wh_increase_payment_account','87',1,0.00,0,0),(418,'acc_wh_increase_deposit_to','37',1,0.00,0,0),(419,'acc_wh_opening_stock_automatic_conversion','1',1,0.00,0,0),(420,'acc_wh_opening_stock_payment_account','88',1,0.00,0,0),(421,'acc_wh_opening_stock_deposit_to','37',1,0.00,0,0),(422,'acc_pur_order_automatic_conversion','1',1,0.00,0,0),(423,'acc_pur_order_payment_account','13',1,0.00,0,0),(424,'acc_pur_order_deposit_to','80',1,0.00,0,0),(425,'acc_pur_payment_automatic_conversion','1',1,0.00,0,0),(426,'acc_pur_payment_payment_account','16',1,0.00,0,0),(427,'acc_pur_payment_deposit_to','37',1,0.00,0,0),(428,'acc_mrp_manufacturing_order_automatic_conversion','1',1,0.00,0,0),(429,'acc_mrp_material_cost_payment_account','13',1,0.00,0,0),(430,'acc_mrp_material_cost_deposit_to','45',1,0.00,0,0),(431,'acc_mrp_labour_cost_payment_account','13',1,0.00,0,0),(432,'acc_mrp_labour_cost_deposit_to','18',1,0.00,0,0),(433,'acc_pur_order_return_automatic_conversion','1',1,0.00,0,0),(434,'acc_pur_order_return_payment_account','80',1,0.00,0,0),(435,'acc_pur_order_return_deposit_to','13',1,0.00,0,0),(436,'acc_pur_refund_automatic_conversion','1',1,0.00,0,0),(437,'acc_pur_refund_payment_account','37',1,0.00,0,0),(438,'acc_pur_refund_deposit_to','16',1,0.00,0,0),(439,'acc_pur_invoice_automatic_conversion','1',1,0.00,0,0),(440,'acc_pur_invoice_payment_account','13',1,0.00,0,0),(441,'acc_pur_invoice_deposit_to','80',1,0.00,0,0),(442,'acc_omni_sales_order_return_automatic_conversion','1',1,0.00,0,0),(443,'acc_omni_sales_order_return_payment_account','1',1,0.00,0,0),(444,'acc_omni_sales_order_return_deposit_to','66',1,0.00,0,0),(445,'acc_omni_sales_refund_automatic_conversion','1',1,0.00,0,0),(446,'acc_omni_sales_refund_payment_account','13',1,0.00,0,0),(447,'acc_omni_sales_refund_deposit_to','1',1,0.00,0,0),(448,'acc_routing_number_icon_a','a',1,0.00,0,0),(449,'acc_routing_number_icon_b','a',1,0.00,0,0),(450,'acc_bank_account_icon_a','a',1,0.00,0,0),(451,'acc_bank_account_icon_b','a',1,0.00,0,0),(452,'acc_current_check_no_icon_a','a',1,0.00,0,0),(453,'acc_current_check_no_icon_b','a',1,0.00,0,0),(454,'acc_check_type','type_1',1,0.00,0,0),(455,'acc_fe_asset_automatic_conversion','1',1,0.00,0,0),(456,'acc_fe_asset_payment_account','13',1,0.00,0,0),(457,'acc_fe_asset_deposit_to','1',1,0.00,0,0),(458,'acc_fe_license_automatic_conversion','1',1,0.00,0,0),(459,'acc_fe_license_payment_account','13',1,0.00,0,0),(460,'acc_fe_license_deposit_to','1',1,0.00,0,0),(461,'acc_fe_consumable_automatic_conversion','1',1,0.00,0,0),(462,'acc_fe_consumable_payment_account','13',1,0.00,0,0),(463,'acc_fe_consumable_deposit_to','1',1,0.00,0,0),(464,'acc_fe_component_automatic_conversion','1',1,0.00,0,0),(465,'acc_fe_component_payment_account','13',1,0.00,0,0),(466,'acc_fe_component_deposit_to','1',1,0.00,0,0),(467,'acc_fe_maintenance_automatic_conversion','1',1,0.00,0,0),(468,'acc_fe_maintenance_payment_account','13',1,0.00,0,0),(469,'acc_fe_maintenance_deposit_to','1',1,0.00,0,0),(470,'acc_fe_depreciation_automatic_conversion','1',1,0.00,0,0),(471,'acc_fe_depreciation_payment_account','13',1,0.00,0,0),(472,'acc_fe_depreciation_deposit_to','1',1,0.00,0,0),(473,'acc_wh_stock_export_profit_payment_account','66',1,0.00,0,0),(474,'acc_wh_stock_export_profit_deposit_to','1',1,0.00,0,0),(475,'update_bank_account_v124','1',1,0.00,0,0),(476,'update_income_statement_modifications_v125','1',1,0.00,0,0),(477,'acc_enable_income_statement_modifications','0',1,0.00,0,0),(478,'acc_invoice_discount_payment_account','1',1,0.00,0,0),(479,'acc_invoice_discount_deposit_to','19',1,0.00,0,0),(480,'acc_pur_tax_automatic_conversion','1',1,0.00,0,0),(481,'acc_pur_tax_payment_account','13',1,0.00,0,0),(482,'acc_pur_tax_deposit_to','29',1,0.00,0,0),(483,'acc_wh_stock_import_return_automatic_conversion','0',1,0.00,0,0),(484,'acc_wh_stock_import_return_payment_account','1',1,0.00,0,0),(485,'acc_wh_stock_import_return_deposit_to','37',1,0.00,0,0),(486,'acc_wh_stock_export_profit_automatic_conversion','1',1,0.00,0,0),(487,'affiliate_management_auto_approve_signup','1',1,0.00,0,0),(488,'affiliate_management_save_referral_client_info','1',1,0.00,0,0),(489,'affiliate_management_groups','{\"general\":{\"name\":\"General\",\"settings\":{\"affiliate_management_commission_enabled\":\"1\",\"affiliate_management_commission_rule\":\"first-invoice-payment\",\"affiliate_management_commission_type\":\"percent\",\"affiliate_management_commission_amount\":\"15\",\"affiliate_management_commission_cap\":\"-1\",\"affiliate_management_payout_min\":\"50\",\"affiliate_management_payout_methods\":\"bank, paypal\"}}}',1,0.00,0,0),(490,'affiliate_management_join_page_content','\n                    <div class=\"jumbotron text-center\">\n                        <h1>Welcome to Our Affiliate Program!</h1>\n                        <p>Join us and start earning today.</p>\n                        <a href=\"{SIGNUP_LINK}\" class=\"btn btn-primary btn-lg\">Join Now</a>\n                    </div>\n                    <div id=\"referral\" class=\"row\">\n                        <div class=\"col-md-6\">\n                            <h2>Referral Program</h2>\n                            <p>Join our referral program and start earning rewards!</p>\n                            <p>Earn {COMMISSION_AMOUNT} on every referral\'s first payment.</p>\n                            <p>Minimum payout is {MIN_PAYOUT}.</p>\n                        </div>\n                        <div class=\"col-md-6\">\n                            <h2>How It Works</h2>\n                            <p>1. Register for the affiliate program.</p>\n                            <p>2. Share your referral link with friends and colleagues.</p>\n                            <p>3. When someone signs up using your link and makes their first payment, you earn {COMMISSION_AMOUNT}.</p>\n                            <p>4. Once your earnings reach {MIN_PAYOUT}, you can request a payout.</p>\n                        </div>\n                    </div>\n                ',1,0.00,0,0),(491,'affiliate_management_affiliate_model','first-click',1,0.00,0,0),(492,'affiliate_management_enable_referral_removal','0',1,0.00,0,0),(493,'loyalty_setting','1',1,0.00,0,0),(494,'warehouse_selling_price_rule_profif_ratio','0',1,0.00,0,0),(495,'profit_rate_by_purchase_price_sale','0',1,0.00,0,0),(496,'warehouse_the_fractional_part','0',1,0.00,0,0),(497,'warehouse_integer_part','0',1,0.00,0,0),(498,'auto_create_goods_received','0',1,0.00,0,0),(499,'auto_create_goods_delivery','0',1,0.00,0,0),(500,'goods_receipt_warehouse','0',1,0.00,0,0),(501,'barcode_with_sku_code','0',1,0.00,0,0),(502,'revert_goods_receipt_goods_delivery','0',1,0.00,0,0),(503,'cancelled_invoice_reverse_inventory_delivery_voucher','0',1,0.00,0,0),(504,'uncancelled_invoice_create_inventory_delivery_voucher','0',1,0.00,0,0),(505,'inventory_auto_operations_hour','0',1,0.00,0,0),(506,'automatically_send_items_expired_before','0',1,0.00,0,0),(507,'inventorys_cronjob_active','0',1,0.00,0,0),(508,'inventory_cronjob_notification_recipients','',1,0.00,0,0),(509,'inventory_received_number_prefix','NK',1,0.00,0,0),(510,'next_inventory_received_mumber','2',1,0.00,0,0),(511,'inventory_delivery_number_prefix','XK',1,0.00,0,0),(512,'next_inventory_delivery_mumber','1',1,0.00,0,0),(513,'internal_delivery_number_prefix','ID',1,0.00,0,0),(514,'next_internal_delivery_mumber','1',1,0.00,0,0),(515,'item_sku_prefix','',1,0.00,0,0),(516,'goods_receipt_required_po','0',1,0.00,0,0),(517,'goods_delivery_required_po','0',1,0.00,0,0),(518,'goods_delivery_pdf_display','0',1,0.00,0,0),(519,'display_product_name_when_print_barcode','0',1,0.00,0,0),(520,'show_item_cf_on_pdf','0',1,0.00,0,0),(521,'goods_delivery_pdf_display_outstanding','0',1,0.00,0,0),(522,'goods_delivery_pdf_display_warehouse_lotnumber_bottom_infor','0',1,0.00,0,0),(523,'packing_list_number_prefix','PL',1,0.00,0,0),(524,'next_packing_list_number','1',1,0.00,0,0),(525,'wh_return_request_within_x_day','30',1,0.00,0,0),(526,'wh_fee_for_return_order','0',1,0.00,0,0),(527,'wh_return_policies_information','',1,0.00,0,0),(528,'wh_refund_loyaty_point','1',1,0.00,0,0),(529,'order_return_number_prefix','ReReturn',1,0.00,0,0),(530,'next_order_return_number','1',1,0.00,0,0),(531,'e_order_return_number_prefix','DEReturn',1,0.00,0,0),(532,'e_next_order_return_number','1',1,0.00,0,0),(533,'warehouse_receive_return_order ','0',1,0.00,0,0),(534,'wh_display_shipment_on_client_portal','1',1,0.00,0,0),(535,'wh_on_total_items','200',1,0.00,0,0),(536,'wh_products_by_serial','1',1,0.00,0,0),(537,'wh_shortened_form_pdf','0',1,0.00,0,0),(538,'wh_show_price_when_print_barcode','1',1,0.00,0,0),(539,'notify_customer_when_change_delivery_status','1',1,0.00,0,0),(540,'wh_hide_shipping_fee','0',1,0.00,0,0),(541,'lot_number_prefix','LOT',1,0.00,0,0),(542,'next_lot_number','1',1,0.00,0,0),(543,'auto_generate_lotnumber','0',1,0.00,0,0),(544,'custom_name_for_meter','m',1,0.00,0,0),(545,'custom_name_for_kg','kg',1,0.00,0,0),(546,'custom_name_for_m3','m3',1,0.00,0,0),(547,'packing_list_pdf_display_rate','1',1,0.00,0,0),(548,'packing_list_pdf_display_tax','1',1,0.00,0,0),(549,'packing_list_pdf_display_subtotal','1',1,0.00,0,0),(550,'packing_list_pdf_display_discount_percent','1',1,0.00,0,0),(551,'packing_list_pdf_display_discount_amount','1',1,0.00,0,0),(552,'packing_list_pdf_display_totalpayment','1',1,0.00,0,0),(553,'packing_list_pdf_display_summary','1',1,0.00,0,0),(554,'standard_workload','8',1,0.00,0,0),(555,'aside_menu_active','{\"dashboard\":{\"id\":\"dashboard\",\"icon\":\"\",\"disabled\":\"false\",\"position\":1},\"leads\":{\"id\":\"leads\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"10\"},\"customers\":{\"id\":\"customers\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"15\"},\"recruitment\":{\"id\":\"recruitment\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"20\",\"children\":{\"recruitment_dashboard\":{\"disabled\":\"false\",\"id\":\"recruitment_dashboard\",\"icon\":\"\",\"position\":\"5\"},\"recruitment-proposal\":{\"disabled\":\"false\",\"id\":\"recruitment-proposal\",\"icon\":\"\",\"position\":\"10\"},\"recruitment-campaign\":{\"disabled\":\"false\",\"id\":\"recruitment-campaign\",\"icon\":\"\",\"position\":\"15\"},\"candidate-profile\":{\"disabled\":\"false\",\"id\":\"candidate-profile\",\"icon\":\"\",\"position\":\"20\"},\"interview-schedule\":{\"disabled\":\"false\",\"id\":\"interview-schedule\",\"icon\":\"\",\"position\":\"25\"},\"recruitment-channel\":{\"disabled\":\"false\",\"id\":\"recruitment-channel\",\"icon\":\"\",\"position\":\"30\"},\"recruitment-portal\":{\"disabled\":\"false\",\"id\":\"recruitment-portal\",\"icon\":\"\",\"position\":\"35\"},\"rec_settings\":{\"disabled\":\"false\",\"id\":\"rec_settings\",\"icon\":\"\",\"position\":\"40\"}}},\"hr_profile\":{\"id\":\"hr_profile\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"25\",\"children\":{\"hr_profile_dashboard\":{\"disabled\":\"false\",\"id\":\"hr_profile_dashboard\",\"icon\":\"\",\"position\":\"5\"},\"hr_profile_job_position_manage\":{\"disabled\":\"false\",\"id\":\"hr_profile_job_position_manage\",\"icon\":\"\",\"position\":\"10\"},\"hr_profile_organizational_chart\":{\"disabled\":\"false\",\"id\":\"hr_profile_organizational_chart\",\"icon\":\"\",\"position\":\"15\"},\"hr_profile_reception_of_staff\":{\"disabled\":\"false\",\"id\":\"hr_profile_reception_of_staff\",\"icon\":\"\",\"position\":\"20\"},\"hr_profile_hr_records\":{\"disabled\":\"false\",\"id\":\"hr_profile_hr_records\",\"icon\":\"\",\"position\":\"25\"},\"hr_profile_training\":{\"disabled\":\"false\",\"id\":\"hr_profile_training\",\"icon\":\"\",\"position\":\"30\"},\"hr_profile_contract\":{\"disabled\":\"false\",\"id\":\"hr_profile_contract\",\"icon\":\"\",\"position\":\"35\"},\"hr_profile_dependent_person\":{\"disabled\":\"false\",\"id\":\"hr_profile_dependent_person\",\"icon\":\"\",\"position\":\"40\"},\"hr_profile_quitting_works\":{\"disabled\":\"false\",\"id\":\"hr_profile_quitting_works\",\"icon\":\"\",\"position\":\"45\"},\"hr_profile_q_a\":{\"disabled\":\"false\",\"id\":\"hr_profile_q_a\",\"icon\":\"\",\"position\":\"50\"},\"hr_profile_reports\":{\"disabled\":\"false\",\"id\":\"hr_profile_reports\",\"icon\":\"\",\"position\":\"55\"},\"hr_profile_setting\":{\"disabled\":\"false\",\"id\":\"hr_profile_setting\",\"icon\":\"\",\"position\":\"60\"}}},\"hr_payroll\":{\"id\":\"hr_payroll\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"30\",\"children\":{\"hr_manage_employees\":{\"disabled\":\"false\",\"id\":\"hr_manage_employees\",\"icon\":\"\",\"position\":\"5\"},\"hr_manage_attendance\":{\"disabled\":\"false\",\"id\":\"hr_manage_attendance\",\"icon\":\"\",\"position\":\"10\"},\"hr_manage_commissions\":{\"disabled\":\"false\",\"id\":\"hr_manage_commissions\",\"icon\":\"\",\"position\":\"15\"},\"hr_manage_deductions\":{\"disabled\":\"false\",\"id\":\"hr_manage_deductions\",\"icon\":\"\",\"position\":\"20\"},\"hr_manage_reimbursements\":{\"disabled\":\"false\",\"id\":\"hr_manage_reimbursements\",\"icon\":\"\",\"position\":\"25\"},\"hr_bonus_kpi\":{\"disabled\":\"false\",\"id\":\"hr_bonus_kpi\",\"icon\":\"\",\"position\":\"30\"},\"hrp_insurrance\":{\"disabled\":\"false\",\"id\":\"hrp_insurrance\",\"icon\":\"\",\"position\":\"35\"},\"hr_pay_slips\":{\"disabled\":\"false\",\"id\":\"hr_pay_slips\",\"icon\":\"\",\"position\":\"40\"},\"hrp_payslip_template\":{\"disabled\":\"false\",\"id\":\"hrp_payslip_template\",\"icon\":\"\",\"position\":\"45\"},\"hrp_income_tax\":{\"disabled\":\"false\",\"id\":\"hrp_income_tax\",\"icon\":\"\",\"position\":\"50\"},\"hr_payroll_reports\":{\"disabled\":\"false\",\"id\":\"hr_payroll_reports\",\"icon\":\"\",\"position\":\"55\"},\"hrp_settings\":{\"disabled\":\"false\",\"id\":\"hrp_settings\",\"icon\":\"\",\"position\":\"60\"}}},\"accounting\":{\"id\":\"accounting\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"35\",\"children\":{\"accounting\":{\"disabled\":\"false\",\"id\":\"accounting\",\"icon\":\"\",\"position\":\"5\"},\"accounting_dashboard\":{\"disabled\":\"false\",\"id\":\"accounting_dashboard\",\"icon\":\"\",\"position\":\"15\"},\"accounting_banking\":{\"disabled\":\"false\",\"id\":\"accounting_banking\",\"icon\":\"\",\"position\":\"25\"},\"accounting_transaction\":{\"disabled\":\"false\",\"id\":\"accounting_transaction\",\"icon\":\"\",\"position\":\"30\"},\"accounting_registers\":{\"disabled\":\"false\",\"id\":\"accounting_registers\",\"icon\":\"\",\"position\":\"35\"},\"accounting_bills\":{\"disabled\":\"false\",\"id\":\"accounting_bills\",\"icon\":\"\",\"position\":\"40\"},\"accounting_checks\":{\"disabled\":\"false\",\"id\":\"accounting_checks\",\"icon\":\"\",\"position\":\"45\"},\"accounting_journal_entry\":{\"disabled\":\"false\",\"id\":\"accounting_journal_entry\",\"icon\":\"\",\"position\":\"50\"},\"accounting_transfer\":{\"disabled\":\"false\",\"id\":\"accounting_transfer\",\"icon\":\"\",\"position\":\"55\"},\"accounting_chart_of_accounts\":{\"disabled\":\"false\",\"id\":\"accounting_chart_of_accounts\",\"icon\":\"\",\"position\":\"60\"},\"accounting_reconcile\":{\"disabled\":\"false\",\"id\":\"accounting_reconcile\",\"icon\":\"\",\"position\":\"65\"},\"accounting_budget\":{\"disabled\":\"false\",\"id\":\"accounting_budget\",\"icon\":\"\",\"position\":\"70\"},\"accounting_report\":{\"disabled\":\"false\",\"id\":\"accounting_report\",\"icon\":\"\",\"position\":\"75\"},\"accounting_setting\":{\"disabled\":\"false\",\"id\":\"accounting_setting\",\"icon\":\"\",\"position\":\"80\"}}},\"projects\":{\"id\":\"projects\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"40\"},\"tasks\":{\"id\":\"tasks\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"45\"},\"purchase\":{\"id\":\"purchase\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"50\",\"children\":{\"purchase-items\":{\"disabled\":\"false\",\"id\":\"purchase-items\",\"icon\":\"\",\"position\":\"5\"},\"vendors\":{\"disabled\":\"false\",\"id\":\"vendors\",\"icon\":\"\",\"position\":\"10\"},\"vendors-items\":{\"disabled\":\"false\",\"id\":\"vendors-items\",\"icon\":\"\",\"position\":\"15\"},\"purchase-request\":{\"disabled\":\"false\",\"id\":\"purchase-request\",\"icon\":\"\",\"position\":\"20\"},\"purchase-quotation\":{\"disabled\":\"false\",\"id\":\"purchase-quotation\",\"icon\":\"\",\"position\":\"25\"},\"purchase-order\":{\"disabled\":\"false\",\"id\":\"purchase-order\",\"icon\":\"\",\"position\":\"30\"},\"return-order\":{\"disabled\":\"false\",\"id\":\"return-order\",\"icon\":\"\",\"position\":\"35\"},\"purchase-contract\":{\"disabled\":\"false\",\"id\":\"purchase-contract\",\"icon\":\"\",\"position\":\"40\"},\"purchase-debit-note\":{\"disabled\":\"false\",\"id\":\"purchase-debit-note\",\"icon\":\"\",\"position\":\"45\"},\"purchase-invoices\":{\"disabled\":\"false\",\"id\":\"purchase-invoices\",\"icon\":\"\",\"position\":\"50\"},\"purchase_reports\":{\"disabled\":\"false\",\"id\":\"purchase_reports\",\"icon\":\"\",\"position\":\"55\"},\"purchase-settings\":{\"disabled\":\"false\",\"id\":\"purchase-settings\",\"icon\":\"\",\"position\":\"60\"}}},\"manufacturing\":{\"id\":\"manufacturing\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"55\",\"children\":{\"manufacturing_dashboard\":{\"disabled\":\"false\",\"id\":\"manufacturing_dashboard\",\"icon\":\"\",\"position\":\"5\"},\"manufacturing_product_management\":{\"disabled\":\"false\",\"id\":\"manufacturing_product_management\",\"icon\":\"\",\"position\":\"10\"},\"manufacturing_reception_of_staff\":{\"disabled\":\"false\",\"id\":\"manufacturing_reception_of_staff\",\"icon\":\"\",\"position\":\"15\"},\"manufacturing_hr_records\":{\"disabled\":\"false\",\"id\":\"manufacturing_hr_records\",\"icon\":\"\",\"position\":\"20\"},\"manufacturing_training\":{\"disabled\":\"false\",\"id\":\"manufacturing_training\",\"icon\":\"\",\"position\":\"25\"},\"manufacturing_q_a\":{\"disabled\":\"false\",\"id\":\"manufacturing_q_a\",\"icon\":\"\",\"position\":\"30\"},\"manufacturing_contract\":{\"disabled\":\"false\",\"id\":\"manufacturing_contract\",\"icon\":\"\",\"position\":\"35\"},\"manufacturing_sub_contract\":{\"disabled\":\"false\",\"id\":\"manufacturing_sub_contract\",\"icon\":\"\",\"position\":\"40\"},\"manufacturing_dependent_person\":{\"disabled\":\"false\",\"id\":\"manufacturing_dependent_person\",\"icon\":\"\",\"position\":\"45\"},\"manufacturing_setting\":{\"disabled\":\"false\",\"id\":\"manufacturing_setting\",\"icon\":\"\",\"position\":\"50\"}}},\"warehouse\":{\"id\":\"warehouse\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"60\",\"children\":{\"wa_commodity_list\":{\"disabled\":\"false\",\"id\":\"wa_commodity_list\",\"icon\":\"\",\"position\":\"5\"},\"wa_manage_goods_receipt\":{\"disabled\":\"false\",\"id\":\"wa_manage_goods_receipt\",\"icon\":\"\",\"position\":\"10\"},\"wa_manage_goods_delivery\":{\"disabled\":\"false\",\"id\":\"wa_manage_goods_delivery\",\"icon\":\"\",\"position\":\"15\"},\"wa_manage_packing_list\":{\"disabled\":\"false\",\"id\":\"wa_manage_packing_list\",\"icon\":\"\",\"position\":\"20\"},\"wa_manage_internal_delivery\":{\"disabled\":\"false\",\"id\":\"wa_manage_internal_delivery\",\"icon\":\"\",\"position\":\"25\"},\"wa_manage_loss_adjustment\":{\"disabled\":\"false\",\"id\":\"wa_manage_loss_adjustment\",\"icon\":\"\",\"position\":\"30\"},\"wa_manage_order_return\":{\"disabled\":\"false\",\"id\":\"wa_manage_order_return\",\"icon\":\"\",\"position\":\"35\"},\"wa_manage_warehouse\":{\"disabled\":\"false\",\"id\":\"wa_manage_warehouse\",\"icon\":\"\",\"position\":\"40\"},\"wa_warehouse_history\":{\"disabled\":\"false\",\"id\":\"wa_warehouse_history\",\"icon\":\"\",\"position\":\"45\"},\"wa_report\":{\"disabled\":\"false\",\"id\":\"wa_report\",\"icon\":\"\",\"position\":\"50\"},\"ware_settings\":{\"disabled\":\"false\",\"id\":\"ware_settings\",\"icon\":\"\",\"position\":\"55\"}}},\"mailbox\":{\"id\":\"mailbox\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"65\"},\"mailflow\":{\"id\":\"mailflow\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"70\",\"children\":{\"mailflow-view\":{\"disabled\":\"false\",\"id\":\"mailflow-view\",\"icon\":\"\",\"position\":\"5\"},\"mailflow-view-history\":{\"disabled\":\"false\",\"id\":\"mailflow-view-history\",\"icon\":\"\",\"position\":\"10\"},\"mailflow-templates\":{\"disabled\":\"false\",\"id\":\"mailflow-templates\",\"icon\":\"\",\"position\":\"15\"},\"mailflow-unsub-emails\":{\"disabled\":\"false\",\"id\":\"mailflow-unsub-emails\",\"icon\":\"\",\"position\":\"20\"}}},\"sales\":{\"id\":\"sales\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"75\",\"children\":{\"proposals\":{\"disabled\":\"false\",\"id\":\"proposals\",\"icon\":\"\",\"position\":\"5\"},\"estimates\":{\"disabled\":\"false\",\"id\":\"estimates\",\"icon\":\"\",\"position\":\"10\"},\"invoices\":{\"disabled\":\"false\",\"id\":\"invoices\",\"icon\":\"\",\"position\":\"15\"},\"payments\":{\"disabled\":\"false\",\"id\":\"payments\",\"icon\":\"\",\"position\":\"20\"},\"credit_notes\":{\"disabled\":\"false\",\"id\":\"credit_notes\",\"icon\":\"\",\"position\":\"25\"},\"items\":{\"disabled\":\"false\",\"id\":\"items\",\"icon\":\"\",\"position\":\"30\"}}},\"subscriptions\":{\"id\":\"subscriptions\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"80\"},\"expenses\":{\"id\":\"expenses\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"85\"},\"contracts\":{\"id\":\"contracts\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"90\"},\"account- planning\":{\"id\":\"account- planning\",\"disabled\":\"false\",\"position\":\"95\",\"icon\":false},\"ma\":{\"id\":\"ma\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"100\",\"children\":{\"ma-dashboard\":{\"disabled\":\"false\",\"id\":\"ma-dashboard\",\"icon\":\"\",\"position\":\"5\"},\"ma-segments\":{\"disabled\":\"false\",\"id\":\"ma-segments\",\"icon\":\"\",\"position\":\"10\"},\"ma-components\":{\"disabled\":\"false\",\"id\":\"ma-components\",\"icon\":\"\",\"position\":\"15\"},\"ma-campaigns\":{\"disabled\":\"false\",\"id\":\"ma-campaigns\",\"icon\":\"\",\"position\":\"20\"},\"ma-channels\":{\"disabled\":\"false\",\"id\":\"ma-channels\",\"icon\":\"\",\"position\":\"25\"},\"ma-points\":{\"disabled\":\"false\",\"id\":\"ma-points\",\"icon\":\"\",\"position\":\"30\"},\"ma-stages\":{\"disabled\":\"false\",\"id\":\"ma-stages\",\"icon\":\"\",\"position\":\"35\"},\"ma-reports\":{\"disabled\":\"false\",\"id\":\"ma-reports\",\"icon\":\"\",\"position\":\"40\"},\"ma-settings\":{\"disabled\":\"false\",\"id\":\"ma-settings\",\"icon\":\"\",\"position\":\"45\"}}},\"timesheets\":{\"id\":\"timesheets\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"105\",\"children\":{\"timesheets_timekeeping\":{\"disabled\":\"false\",\"id\":\"timesheets_timekeeping\",\"icon\":\"\",\"position\":\"5\"},\"timesheets_timekeeping_mnrh\":{\"disabled\":\"false\",\"id\":\"timesheets_timekeeping_mnrh\",\"icon\":\"\",\"position\":\"10\"},\"timesheets_route_management\":{\"disabled\":\"false\",\"id\":\"timesheets_route_management\",\"icon\":\"\",\"position\":\"15\"},\"timesheets_table_shiftwork\":{\"disabled\":\"false\",\"id\":\"timesheets_table_shiftwork\",\"icon\":\"\",\"position\":\"20\"},\"timesheets_shift_management\":{\"disabled\":\"false\",\"id\":\"timesheets_shift_management\",\"icon\":\"\",\"position\":\"25\"},\"timesheets_shift_type\":{\"disabled\":\"false\",\"id\":\"timesheets_shift_type\",\"icon\":\"\",\"position\":\"30\"},\"timesheets_workplace_mgt\":{\"disabled\":\"false\",\"id\":\"timesheets_workplace_mgt\",\"icon\":\"\",\"position\":\"35\"},\"timesheets-report\":{\"disabled\":\"false\",\"id\":\"timesheets-report\",\"icon\":\"\",\"position\":\"40\"},\"timesheets_setting\":{\"disabled\":\"false\",\"id\":\"timesheets_setting\",\"icon\":\"\",\"position\":\"45\"}}},\"support\":{\"id\":\"support\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"110\"},\"estimate_request\":{\"id\":\"estimate_request\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"115\"},\"knowledge-base\":{\"id\":\"knowledge-base\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"120\"},\"utilities\":{\"id\":\"utilities\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"125\",\"children\":{\"media\":{\"disabled\":\"false\",\"id\":\"media\",\"icon\":\"\",\"position\":\"5\"},\"bulk-pdf-exporter\":{\"disabled\":\"false\",\"id\":\"bulk-pdf-exporter\",\"icon\":\"\",\"position\":\"10\"},\"calendar\":{\"disabled\":\"false\",\"id\":\"calendar\",\"icon\":\"\",\"position\":\"15\"},\"announcements\":{\"disabled\":\"false\",\"id\":\"announcements\",\"icon\":\"\",\"position\":\"20\"},\"goals-tracking\":{\"disabled\":\"false\",\"id\":\"goals-tracking\",\"icon\":\"\",\"position\":\"25\"},\"activity-log\":{\"disabled\":\"false\",\"id\":\"activity-log\",\"icon\":\"\",\"position\":\"30\"},\"ticket-pipe-log\":{\"disabled\":\"false\",\"id\":\"ticket-pipe-log\",\"icon\":\"\",\"position\":\"35\"},\"flexibackup\":{\"disabled\":\"false\",\"id\":\"flexibackup\",\"icon\":\"\",\"position\":\"40\"}}},\"reports\":{\"id\":\"reports\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"130\",\"children\":{\"sales-reports\":{\"disabled\":\"false\",\"id\":\"sales-reports\",\"icon\":\"\",\"position\":\"5\"},\"expenses-reports\":{\"disabled\":\"false\",\"id\":\"expenses-reports\",\"icon\":\"\",\"position\":\"10\"},\"expenses-vs-income-reports\":{\"disabled\":\"false\",\"id\":\"expenses-vs-income-reports\",\"icon\":\"\",\"position\":\"15\"},\"leads-reports\":{\"disabled\":\"false\",\"id\":\"leads-reports\",\"icon\":\"\",\"position\":\"20\"},\"timesheets-reports\":{\"disabled\":\"false\",\"id\":\"timesheets-reports\",\"icon\":\"\",\"position\":\"25\"},\"knowledge-base-reports\":{\"disabled\":\"false\",\"id\":\"knowledge-base-reports\",\"icon\":\"\",\"position\":\"30\"}}}}',1,0.00,0,0),(556,'setup_menu_active','[]',1,0.00,0,0),(585,'paymentmethod_affiliate_management_gateway_active','0',1,0.00,0,0),(586,'paymentmethod_affiliate_management_gateway_label','Affiliate Earnings',1,0.00,0,0),(587,'paymentmethod_affiliate_management_gateway_currencies','USD',0,0.00,0,0),(588,'paymentmethod_affiliate_management_gateway_default_selected','1',1,0.00,0,0),(589,'paymentmethod_affiliate_management_gateway_initialized','1',1,0.00,0,0),(590,'paymentmethod_authorize_acceptjs_active','0',1,0.00,0,0),(591,'paymentmethod_authorize_acceptjs_label','Authorize.net Accept.js',1,0.00,0,0),(595,'paymentmethod_authorize_acceptjs_description_dashboard','Payment for Invoice {invoice_number}',0,0.00,0,0),(596,'paymentmethod_authorize_acceptjs_currencies','USD',0,0.00,0,0),(597,'paymentmethod_authorize_acceptjs_test_mode_enabled','0',0,0.00,0,0),(598,'paymentmethod_authorize_acceptjs_default_selected','1',1,0.00,0,0),(599,'paymentmethod_authorize_acceptjs_initialized','1',1,0.00,0,0),(600,'paymentmethod_instamojo_active','0',1,0.00,0,0),(601,'paymentmethod_instamojo_label','Instamojo',1,0.00,0,0),(602,'paymentmethod_instamojo_fee_fixed','0',0,0.00,0,0),(603,'paymentmethod_instamojo_fee_percent','0',0,0.00,0,0),(606,'paymentmethod_instamojo_description_dashboard','Payment for Invoice {invoice_number}',0,0.00,0,0),(607,'paymentmethod_instamojo_currencies','INR',0,0.00,0,0),(608,'paymentmethod_instamojo_test_mode_enabled','1',0,0.00,0,0),(609,'paymentmethod_instamojo_default_selected','1',1,0.00,0,0),(610,'paymentmethod_instamojo_initialized','1',1,0.00,0,0),(611,'paymentmethod_mollie_active','0',1,0.00,0,0),(612,'paymentmethod_mollie_label','Mollie',1,0.00,0,0),(614,'paymentmethod_mollie_description_dashboard','Payment for Invoice {invoice_number}',0,0.00,0,0),(615,'paymentmethod_mollie_currencies','EUR',0,0.00,0,0),(616,'paymentmethod_mollie_test_mode_enabled','1',0,0.00,0,0),(617,'paymentmethod_mollie_default_selected','1',1,0.00,0,0),(618,'paymentmethod_mollie_initialized','1',1,0.00,0,0),(619,'paymentmethod_paypal_braintree_active','0',1,0.00,0,0),(620,'paymentmethod_paypal_braintree_label','Braintree',1,0.00,0,0),(624,'paymentmethod_paypal_braintree_currencies','USD',0,0.00,0,0),(625,'paymentmethod_paypal_braintree_paypal_enabled','1',0,0.00,0,0),(626,'paymentmethod_paypal_braintree_test_mode_enabled','1',0,0.00,0,0),(627,'paymentmethod_paypal_braintree_default_selected','1',1,0.00,0,0),(628,'paymentmethod_paypal_braintree_initialized','1',1,0.00,0,0),(629,'paymentmethod_paypal_checkout_active','0',1,0.00,0,0),(630,'paymentmethod_paypal_checkout_label','Paypal Smart Checkout',1,0.00,0,0),(631,'paymentmethod_paypal_checkout_fee_fixed','0',0,0.00,0,0),(632,'paymentmethod_paypal_checkout_fee_percent','0',0,0.00,0,0),(635,'paymentmethod_paypal_checkout_payment_description','Payment for Invoice {invoice_number}',0,0.00,0,0),(636,'paymentmethod_paypal_checkout_currencies','USD,CAD,EUR',0,0.00,0,0),(637,'paymentmethod_paypal_checkout_test_mode_enabled','1',0,0.00,0,0),(638,'paymentmethod_paypal_checkout_default_selected','1',1,0.00,0,0),(639,'paymentmethod_paypal_checkout_initialized','1',1,0.00,0,0),(640,'paymentmethod_paypal_active','0',1,0.00,0,0),(641,'paymentmethod_paypal_label','Paypal',1,0.00,0,0),(642,'paymentmethod_paypal_fee_fixed','0',0,0.00,0,0),(643,'paymentmethod_paypal_fee_percent','0',0,0.00,0,0),(644,'paymentmethod_paypal_username','',0,0.00,0,0),(646,'paymentmethod_paypal_signature','',0,0.00,0,0),(647,'paymentmethod_paypal_description_dashboard','Payment for Invoice {invoice_number}',0,0.00,0,0),(648,'paymentmethod_paypal_currencies','EUR,USD',0,0.00,0,0),(649,'paymentmethod_paypal_test_mode_enabled','1',0,0.00,0,0),(650,'paymentmethod_paypal_default_selected','1',1,0.00,0,0),(651,'paymentmethod_paypal_initialized','1',1,0.00,0,0),(652,'paymentmethod_payu_money_active','0',1,0.00,0,0),(653,'paymentmethod_payu_money_label','PayU Money',1,0.00,0,0),(654,'paymentmethod_payu_money_fee_fixed','0',0,0.00,0,0),(655,'paymentmethod_payu_money_fee_percent','0',0,0.00,0,0),(657,'paymentmethod_payu_money_salt','',0,0.00,0,0),(658,'paymentmethod_payu_money_description_dashboard','Payment for Invoice {invoice_number}',0,0.00,0,0),(659,'paymentmethod_payu_money_currencies','INR',0,0.00,0,0),(660,'paymentmethod_payu_money_test_mode_enabled','1',0,0.00,0,0),(661,'paymentmethod_payu_money_default_selected','1',1,0.00,0,0),(662,'paymentmethod_payu_money_initialized','1',1,0.00,0,0),(663,'paymentmethod_stripe_active','1',1,0.00,0,0),(664,'paymentmethod_stripe_label','Stripe Checkout',1,0.00,0,0),(665,'paymentmethod_stripe_fee_fixed','0',0,0.00,0,0),(666,'paymentmethod_stripe_fee_percent','0',0,0.00,0,0),(669,'paymentmethod_stripe_description_dashboard','Payment for Invoice {invoice_number}',0,0.00,0,0),(670,'paymentmethod_stripe_currencies','USD,CAD',0,0.00,0,0),(671,'paymentmethod_stripe_allow_primary_contact_to_update_credit_card','1',0,0.00,0,0),(672,'paymentmethod_stripe_default_selected','1',1,0.00,0,0),(673,'paymentmethod_stripe_initialized','1',1,0.00,0,0),(674,'paymentmethod_stripe_ideal_active','0',1,0.00,0,0),(675,'paymentmethod_stripe_ideal_label','Stripe iDEAL',1,0.00,0,0),(678,'paymentmethod_stripe_ideal_description_dashboard','Payment for Invoice {invoice_number}',0,0.00,0,0),(679,'paymentmethod_stripe_ideal_statement_descriptor','Payment for Invoice {invoice_number}',0,0.00,0,0),(680,'paymentmethod_stripe_ideal_currencies','EUR',0,0.00,0,0),(681,'paymentmethod_stripe_ideal_default_selected','1',1,0.00,0,0),(682,'paymentmethod_stripe_ideal_initialized','1',1,0.00,0,0),(683,'paymentmethod_two_checkout_active','0',1,0.00,0,0),(684,'paymentmethod_two_checkout_label','2Checkout',1,0.00,0,0),(685,'paymentmethod_two_checkout_fee_fixed','0',0,0.00,0,0),(686,'paymentmethod_two_checkout_fee_percent','0',0,0.00,0,0),(687,'paymentmethod_two_checkout_merchant_code','',0,0.00,0,0),(689,'paymentmethod_two_checkout_description','Payment for Invoice {invoice_number}',0,0.00,0,0),(690,'paymentmethod_two_checkout_currencies','USD, EUR, GBP',0,0.00,0,0),(691,'paymentmethod_two_checkout_test_mode_enabled','1',0,0.00,0,0),(692,'paymentmethod_two_checkout_default_selected','1',1,0.00,0,0),(693,'paymentmethod_two_checkout_initialized','1',1,0.00,0,0),(736,'sms_trigger_invoice_overdue_notice','',0,0.00,0,0),(737,'sms_trigger_invoice_due_notice','',0,0.00,0,0),(738,'sms_trigger_invoice_payment_recorded','',0,0.00,0,0),(739,'sms_trigger_estimate_expiration_reminder','',0,0.00,0,0),(740,'sms_trigger_proposal_expiration_reminder','',0,0.00,0,0),(741,'sms_trigger_proposal_new_comment_to_customer','',0,0.00,0,0),(742,'sms_trigger_proposal_new_comment_to_staff','',0,0.00,0,0),(743,'sms_trigger_contract_new_comment_to_customer','',0,0.00,0,0),(744,'sms_trigger_contract_new_comment_to_staff','',0,0.00,0,0),(745,'sms_trigger_contract_expiration_reminder','',0,0.00,0,0),(746,'sms_trigger_contract_sign_reminder_to_customer','',0,0.00,0,0),(747,'sms_trigger_staff_reminder','',0,0.00,0,0),(748,'perfex_office_theme_customers','1',1,0.00,0,0),(752,'required_register_fields','[\"contact_firstname\",\"contact_lastname\"]',1,0.00,0,0),(756,'pur_invoice_auto_operations_hour','21',1,0.00,0,0),(757,'next_debit_note_number','1',1,0.00,0,0),(758,'debit_note_number_format','1',1,0.00,0,0),(759,'debit_note_prefix','DN-',1,0.00,0,0),(760,'show_purchase_tax_column','1',1,0.00,0,0),(761,'po_only_prefix_and_number','0',1,0.00,0,0),(762,'pur_return_request_within_x_day','30',1,0.00,0,0),(763,'pur_fee_for_return_order','0',1,0.00,0,0),(764,'pur_return_policies_information','',1,0.00,0,0),(765,'pur_order_return_number_prefix','OReturn',1,0.00,0,0),(766,'next_pur_order_return_number','1',1,0.00,0,0),(767,'send_email_welcome_for_new_contact','1',1,0.00,0,0),(768,'reset_purchase_order_number_every_month','1',1,0.00,0,0),(769,'pur_company_address','',1,0.00,0,0),(770,'pur_company_city','',1,0.00,0,0),(771,'pur_company_state','',1,0.00,0,0),(772,'pur_company_zipcode','',1,0.00,0,0),(773,'pur_company_country_code','',1,0.00,0,0),(774,'allow_vendors_to_register','1',1,0.00,0,0),(775,'pur_company_country_text','',1,0.00,0,0),(776,'whatsapp_api_verification_id','38690826',1,0.00,0,0),(777,'whatsapp_api_last_verification','999999999',1,0.00,0,0),(778,'whatsapp_api_verified','1',1,0.00,0,0),(779,'whatsapp_api_heartbeat','1',1,0.00,0,0),(780,'whatsapp_api_enabled','1',1,0.00,0,0),(781,'recruitment_create_campaign_with_plan ','1',1,0.00,0,0),(782,'display_quantity_to_be_recruited','1',1,0.00,0,0),(783,'candidate_code_prefix','ID',1,0.00,0,0),(784,'candidate_code_number','1',1,0.00,0,0),(785,'send_email_welcome_for_new_candidate','1',1,0.00,0,0),(786,'flexibackup_files_backup_schedule','1',1,0.00,0,0),(787,'flexibackup_database_backup_schedule','1',1,0.00,0,0),(788,'flexibackup_remote_storage','',1,0.00,0,0),(789,'last_flexi_backup_file','',1,0.00,0,0),(790,'last_flexi_backup_database','',1,0.00,0,0),(791,'paymentmethod_razorpay_active','1',1,0.00,0,0),(792,'paymentmethod_razorpay_label','Razorpay',1,0.00,0,0),(793,'paymentmethod_razorpay_key_id','rzp_live_HI0V07stWalvUa',0,0.00,0,0),(794,'paymentmethod_razorpay_key_secret','a47c2140b2a4df8aa3a442d35af770c4d785e019650f49d8c66bae44850594e3b08118198a17d37714082727d27cfa11330653dea32ef9e0a937380752e6b94dBGCxpf++61fQn/fsjYXvgN7HaninjzUIZC6UAooL0+RV3RP+gOfX6yji7P1z6oQn',0,0.00,0,0),(795,'paymentmethod_razorpay_description_dashboard','Payment for Invoice {invoice_number}',0,0.00,0,0),(796,'paymentmethod_razorpay_currencies','INR',0,0.00,0,0),(797,'paymentmethod_razorpay_default_selected','1',1,0.00,0,0),(798,'paymentmethod_razorpay_initialized','1',1,0.00,0,0),(799,'ma_insert_email_template_default','1',1,0.00,0,0),(800,'si_lead_followup_activated','0',1,0.00,0,0),(801,'si_lead_followup_activation_code','',1,0.00,0,0),(802,'sms_trigger_si_lead_followup_custom_sms','',1,0.00,0,0),(803,'si_lead_followup_trigger_schedule_sms_last_run','2025-07-13 18:59:55',1,0.00,0,0),(804,'si_lead_followup_clear_schedule_sms_log_after_days','30',1,0.00,0,0),(805,'si_custom_status_edit_default_status_tasks','0',1,0.00,0,0),(806,'si_custom_status_edit_default_status_projects','0',1,0.00,0,0),(807,'auto_backup_enabled','0',1,0.00,0,0),(808,'auto_backup_every','7',1,0.00,0,0),(809,'last_auto_backup','',1,0.00,0,0),(810,'delete_backups_older_then','0',1,0.00,0,0),(811,'auto_backup_hour','6',1,0.00,0,0),(812,'survey_send_emails_per_cron_run','100',1,0.00,0,0),(813,'last_survey_send_cron','',1,0.00,0,0),(814,'perfex_saas_installation_secured','true',0,0.00,0,0),(815,'acc_close_book_password','',1,0.00,0,0),(816,'acc_close_book_passwordr','',1,0.00,0,0),(817,'appointly_responsible_person','',1,0.00,0,0),(818,'callbacks_responsible_person','',1,0.00,0,0),(819,'appointly_show_clients_schedule_button','0',1,0.00,0,0),(820,'appointly_tab_on_clients_page','0',1,0.00,0,0),(821,'appointly_also_delete_in_google_calendar','1',1,0.00,0,0),(822,'appointments_show_past_times','1',1,0.00,0,0),(823,'appointments_disable_weekends','1',1,0.00,0,0),(824,'appointly_client_meeting_approved_default','0',1,0.00,0,0),(825,'appointly_google_client_secret','',1,0.00,0,0),(826,'appointly_outlook_client_id','',1,0.00,0,0),(827,'appointly_available_hours','[\"08:00\",\"08:30\",\"09:00\",\"09:30\",\"10:00\",\"10:30\",\"11:00\",\"11:30\",\"12:00\",\"12:30\",\"13:00\",\"13:30\",\"14:00\",\"14:30\",\"15:00\",\"15:30\",\"16:00\",\"16:30\",\"17:00\"]',1,0.00,0,0),(828,'appointly_default_feedbacks','[\"0\",\"1\",\"2\",\"3\",\"4\",\"5\",\"6\"]',1,0.00,0,0),(829,'appointly_busy_times_enabled','1',1,0.00,0,0),(830,'callbacks_mode_enabled','1',1,0.00,0,0),(831,'appointly_appointments_recaptcha','0',1,0.00,0,0),(832,'fe_googlemap_api_key','',1,0.00,0,0),(833,'fe_show_public_page','1',1,0.00,0,0),(834,'fe_inventory_receiving_prefix','IR',1,0.00,0,0),(835,'fe_next_inventory_receiving_mumber','1',1,0.00,0,0),(836,'fe_inventory_delivery_prefix','ID',1,0.00,0,0),(837,'fe_next_inventory_delivery_mumber','1',1,0.00,0,0),(838,'fe_packing_list_prefix','PL',1,0.00,0,0),(839,'fe_next_packing_list_number','1',1,0.00,0,0),(840,'fe_next_serial_number','1',1,0.00,0,0),(841,'fe_serial_number_format','1',1,0.00,0,0),(842,'fe_show_customer_asset','0',1,0.00,0,0),(843,'fe_issue_prefix','ISSUE',1,0.00,0,0),(844,'fe_next_issue_number','1',1,0.00,0,0),(845,'fe_issue_number_format','1',1,0.00,0,0),(846,'staff_sync_orders','',1,0.00,0,0),(847,'minute_sync_orders','',1,0.00,0,0),(848,'time_cron_woo','',1,0.00,0,0),(849,'minute_sync','',1,0.00,0,0),(850,'sync_omni_sales_products','1',1,0.00,0,0),(851,'sync_omni_sales_orders','1',1,0.00,0,0),(852,'sync_omni_sales_inventorys','1',1,0.00,0,0),(853,'sync_omni_sales_description','0',1,0.00,0,0),(854,'sync_omni_sales_images','0',1,0.00,0,0),(855,'price_crm_woo','0',1,0.00,0,0),(856,'product_info_enable_disable','0',1,0.00,0,0),(857,'product_info_image_enable_disable','0',1,0.00,0,0),(858,'minute_sync_product_info_time1','',1,0.00,0,0),(859,'minute_sync_inventory_info_time2','',1,0.00,0,0),(860,'minute_sync_price_time3','',1,0.00,0,0),(861,'minute_sync_decriptions_time4','',1,0.00,0,0),(862,'minute_sync_images_time5','',1,0.00,0,0),(863,'minute_sync_product_info_time7','',1,0.00,0,0),(864,'minute_sync_product_info_images_time8','',1,0.00,0,0),(865,'records_time1','2025-07-13 18:59:52',1,0.00,0,0),(866,'records_time2','2025-07-13 18:59:52',1,0.00,0,0),(867,'records_time3','2025-07-13 18:59:52',1,0.00,0,0),(868,'records_time4','2025-07-13 18:59:52',1,0.00,0,0),(869,'records_time5','2025-07-13 18:59:52',1,0.00,0,0),(870,'records_time6','2025-07-13 18:59:52',1,0.00,0,0),(871,'records_time7','2025-07-13 18:59:52',1,0.00,0,0),(872,'records_time8','2025-07-13 18:59:52',1,0.00,0,0),(873,'status_sync','0',1,0.00,0,0),(874,'invoice_sync_configuration','1',1,0.00,0,0),(875,'omni_show_products_by_department','0',1,0.00,0,0),(876,'bill_header_pos','<div class=\"cls_003\" style=\"text-align: center;\"><span class=\"cls_003\"><strong>PURCHASE RECEIPT</strong></span></div>',1,0.00,0,0),(877,'bill_footer_pos','<div class=\"cls_004\"><span class=\"cls_004\">Thank you for shopping with us. Please come again</span></div>',1,0.00,0,0),(878,'omni_default_seller','',1,0.00,0,0),(879,'number_of_days_to_save_diary_sync','30',1,0.00,0,0),(880,'omni_3des_key','3des1213141516ahiocrth',1,0.00,0,0),(881,'omni_allow_showing_shipment_in_public_link','1',1,0.00,0,0),(882,'omni_return_order_prefix','RE',1,0.00,0,0),(883,'omni_return_request_within_x_day','30',1,0.00,0,0),(884,'omni_fee_for_return_order','0',1,0.00,0,0),(885,'omni_refund_loyaty_point','1',1,0.00,0,0),(886,'omni_return_policies_information','',1,0.00,0,0),(887,'omni_pos_shipping_fee','0',1,0.00,0,0),(888,'omni_portal_shipping_fee','0',1,0.00,0,0),(889,'omni_manual_shipping_fee','0',1,0.00,0,0),(890,'omni_order_statuses_are_allowed_to_sync','',1,0.00,0,0),(891,'omni_display_shopping_cart','1',1,0.00,0,0),(892,'omni_pos_shipping_fee_form','fixed',1,0.00,0,0),(893,'omni_synch_invoice_from_woo','',1,0.00,0,0),(894,'omni_show_public_page','1',1,0.00,0,0),(895,'omni_sale_hide_shipping_fee','0',1,0.00,0,0),(896,'omni_sell_the_warehouse_assigned','0',1,0.00,0,0),(897,'identification_key','117415741517524133946873b4d24e912',1,0.00,0,0),(898,'staff_workload_monday','1',1,0.00,0,0),(899,'staff_workload_tuesday','1',1,0.00,0,0),(900,'staff_workload_thursday','1',1,0.00,0,0),(901,'staff_workload_wednesday','1',1,0.00,0,0),(902,'staff_workload_friday','1',1,0.00,0,0),(903,'staff_workload_saturday','0',1,0.00,0,0),(904,'staff_workload_sunday','0',1,0.00,0,0),(905,'staff_workload_monday_visible','1',1,0.00,0,0),(906,'staff_workload_tuesday_visible','1',1,0.00,0,0),(907,'staff_workload_thursday_visible','1',1,0.00,0,0),(908,'staff_workload_wednesday_visible','1',1,0.00,0,0),(909,'staff_workload_friday_visible','1',1,0.00,0,0),(910,'staff_workload_saturday_visible','1',1,0.00,0,0),(911,'staff_workload_sunday_visible','1',1,0.00,0,0),(912,'integrated_timesheet_holiday','0',1,0.00,0,0),(913,'integrated_timesheet_leave','0',1,0.00,0,0),(914,'staff_workload_exception','',1,0.00,0,0),(915,'theme_style','[]',1,0.00,0,0),(916,'theme_style_custom_admin_area','',1,0.00,0,0),(917,'theme_style_custom_clients_area','',1,0.00,0,0),(918,'theme_style_custom_clients_and_admin_area','',1,0.00,0,0);
/*!40000 ALTER TABLE `maxlife_tbloptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblpayment_attempts`
--

DROP TABLE IF EXISTS `maxlife_tblpayment_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblpayment_attempts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference` varchar(100) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `amount` double NOT NULL,
  `fee` double NOT NULL,
  `payment_gateway` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblpayment_attempts`
--

LOCK TABLES `maxlife_tblpayment_attempts` WRITE;
/*!40000 ALTER TABLE `maxlife_tblpayment_attempts` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblpayment_attempts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblpayment_modes`
--

DROP TABLE IF EXISTS `maxlife_tblpayment_modes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblpayment_modes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `show_on_pdf` int(11) NOT NULL DEFAULT 0,
  `invoices_only` int(11) NOT NULL DEFAULT 0,
  `expenses_only` int(11) NOT NULL DEFAULT 0,
  `selected_by_default` int(11) NOT NULL DEFAULT 1,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblpayment_modes`
--

LOCK TABLES `maxlife_tblpayment_modes` WRITE;
/*!40000 ALTER TABLE `maxlife_tblpayment_modes` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblpayment_modes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblpinned_projects`
--

DROP TABLE IF EXISTS `maxlife_tblpinned_projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblpinned_projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblpinned_projects`
--

LOCK TABLES `maxlife_tblpinned_projects` WRITE;
/*!40000 ALTER TABLE `maxlife_tblpinned_projects` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblpinned_projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblproject_activity`
--

DROP TABLE IF EXISTS `maxlife_tblproject_activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblproject_activity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL DEFAULT 0,
  `contact_id` int(11) NOT NULL DEFAULT 0,
  `fullname` varchar(100) DEFAULT NULL,
  `visible_to_customer` int(11) NOT NULL DEFAULT 0,
  `description_key` varchar(191) NOT NULL COMMENT 'Language file key',
  `additional_data` mediumtext DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblproject_activity`
--

LOCK TABLES `maxlife_tblproject_activity` WRITE;
/*!40000 ALTER TABLE `maxlife_tblproject_activity` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblproject_activity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblproject_files`
--

DROP TABLE IF EXISTS `maxlife_tblproject_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblproject_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file_name` varchar(191) NOT NULL,
  `original_file_name` longtext DEFAULT NULL,
  `subject` varchar(191) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `filetype` varchar(50) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  `last_activity` datetime DEFAULT NULL,
  `project_id` int(11) NOT NULL,
  `visible_to_customer` tinyint(1) DEFAULT 0,
  `staffid` int(11) NOT NULL,
  `contact_id` int(11) NOT NULL DEFAULT 0,
  `external` varchar(40) DEFAULT NULL,
  `external_link` mediumtext DEFAULT NULL,
  `thumbnail_link` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblproject_files`
--

LOCK TABLES `maxlife_tblproject_files` WRITE;
/*!40000 ALTER TABLE `maxlife_tblproject_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblproject_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblproject_members`
--

DROP TABLE IF EXISTS `maxlife_tblproject_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblproject_members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`),
  KEY `maxlife_staff_id` (`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblproject_members`
--

LOCK TABLES `maxlife_tblproject_members` WRITE;
/*!40000 ALTER TABLE `maxlife_tblproject_members` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblproject_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblproject_notes`
--

DROP TABLE IF EXISTS `maxlife_tblproject_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblproject_notes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `content` mediumtext NOT NULL,
  `staff_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblproject_notes`
--

LOCK TABLES `maxlife_tblproject_notes` WRITE;
/*!40000 ALTER TABLE `maxlife_tblproject_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblproject_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblproject_settings`
--

DROP TABLE IF EXISTS `maxlife_tblproject_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblproject_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `value` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblproject_settings`
--

LOCK TABLES `maxlife_tblproject_settings` WRITE;
/*!40000 ALTER TABLE `maxlife_tblproject_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblproject_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblprojectdiscussioncomments`
--

DROP TABLE IF EXISTS `maxlife_tblprojectdiscussioncomments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblprojectdiscussioncomments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `discussion_id` int(11) NOT NULL,
  `discussion_type` varchar(10) NOT NULL,
  `parent` int(11) DEFAULT NULL,
  `created` datetime NOT NULL,
  `modified` datetime DEFAULT NULL,
  `content` mediumtext NOT NULL,
  `staff_id` int(11) NOT NULL,
  `contact_id` int(11) DEFAULT 0,
  `fullname` varchar(191) DEFAULT NULL,
  `file_name` varchar(191) DEFAULT NULL,
  `file_mime_type` varchar(70) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblprojectdiscussioncomments`
--

LOCK TABLES `maxlife_tblprojectdiscussioncomments` WRITE;
/*!40000 ALTER TABLE `maxlife_tblprojectdiscussioncomments` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblprojectdiscussioncomments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblprojectdiscussions`
--

DROP TABLE IF EXISTS `maxlife_tblprojectdiscussions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblprojectdiscussions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `subject` varchar(191) NOT NULL,
  `description` mediumtext NOT NULL,
  `show_to_customer` tinyint(1) NOT NULL DEFAULT 0,
  `datecreated` datetime NOT NULL,
  `last_activity` datetime DEFAULT NULL,
  `staff_id` int(11) NOT NULL DEFAULT 0,
  `contact_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblprojectdiscussions`
--

LOCK TABLES `maxlife_tblprojectdiscussions` WRITE;
/*!40000 ALTER TABLE `maxlife_tblprojectdiscussions` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblprojectdiscussions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblprojects`
--

DROP TABLE IF EXISTS `maxlife_tblprojects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblprojects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `clientid` int(11) NOT NULL,
  `billing_type` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `deadline` date DEFAULT NULL,
  `project_created` date NOT NULL,
  `date_finished` datetime DEFAULT NULL,
  `progress` int(11) DEFAULT 0,
  `progress_from_tasks` int(11) NOT NULL DEFAULT 1,
  `project_cost` decimal(15,2) DEFAULT NULL,
  `project_rate_per_hour` decimal(15,2) DEFAULT NULL,
  `estimated_hours` decimal(15,2) DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `contact_notification` int(11) DEFAULT 1,
  `notify_contacts` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblprojects`
--

LOCK TABLES `maxlife_tblprojects` WRITE;
/*!40000 ALTER TABLE `maxlife_tblprojects` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblprojects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblproposal_comments`
--

DROP TABLE IF EXISTS `maxlife_tblproposal_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblproposal_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` longtext DEFAULT NULL,
  `proposalid` int(11) NOT NULL,
  `staffid` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblproposal_comments`
--

LOCK TABLES `maxlife_tblproposal_comments` WRITE;
/*!40000 ALTER TABLE `maxlife_tblproposal_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblproposal_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblproposals`
--

DROP TABLE IF EXISTS `maxlife_tblproposals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblproposals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(191) DEFAULT NULL,
  `content` longtext DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `datecreated` datetime NOT NULL,
  `total` decimal(15,2) DEFAULT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `total_tax` decimal(15,2) NOT NULL DEFAULT 0.00,
  `adjustment` decimal(15,2) DEFAULT NULL,
  `discount_percent` decimal(15,2) NOT NULL,
  `discount_total` decimal(15,2) NOT NULL,
  `discount_type` varchar(30) DEFAULT NULL,
  `show_quantity_as` int(11) NOT NULL DEFAULT 1,
  `currency` int(11) NOT NULL,
  `open_till` date DEFAULT NULL,
  `date` date NOT NULL,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(40) DEFAULT NULL,
  `assigned` int(11) DEFAULT NULL,
  `hash` varchar(32) NOT NULL,
  `proposal_to` varchar(191) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  `country` int(11) NOT NULL DEFAULT 0,
  `zip` varchar(50) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `allow_comments` tinyint(1) NOT NULL DEFAULT 1,
  `status` int(11) NOT NULL,
  `estimate_id` int(11) DEFAULT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `date_converted` datetime DEFAULT NULL,
  `pipeline_order` int(11) DEFAULT 1,
  `is_expiry_notified` int(11) NOT NULL DEFAULT 0,
  `acceptance_firstname` varchar(50) DEFAULT NULL,
  `acceptance_lastname` varchar(50) DEFAULT NULL,
  `acceptance_email` varchar(100) DEFAULT NULL,
  `acceptance_date` datetime DEFAULT NULL,
  `acceptance_ip` varchar(40) DEFAULT NULL,
  `signature` varchar(40) DEFAULT NULL,
  `short_link` varchar(100) DEFAULT NULL,
  `processing` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblproposals`
--

LOCK TABLES `maxlife_tblproposals` WRITE;
/*!40000 ALTER TABLE `maxlife_tblproposals` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblproposals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblpur_activity_log`
--

DROP TABLE IF EXISTS `maxlife_tblpur_activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblpur_activity_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(45) NOT NULL,
  `staffid` int(11) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `note` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblpur_activity_log`
--

LOCK TABLES `maxlife_tblpur_activity_log` WRITE;
/*!40000 ALTER TABLE `maxlife_tblpur_activity_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblpur_activity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblpur_approval_details`
--

DROP TABLE IF EXISTS `maxlife_tblpur_approval_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblpur_approval_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(45) NOT NULL,
  `staffid` varchar(45) DEFAULT NULL,
  `approve` varchar(45) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `approve_action` varchar(255) DEFAULT NULL,
  `reject_action` varchar(255) DEFAULT NULL,
  `approve_value` varchar(255) DEFAULT NULL,
  `reject_value` varchar(255) DEFAULT NULL,
  `staff_approve` int(11) DEFAULT NULL,
  `action` varchar(45) DEFAULT NULL,
  `sender` int(11) DEFAULT NULL,
  `date_send` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblpur_approval_details`
--

LOCK TABLES `maxlife_tblpur_approval_details` WRITE;
/*!40000 ALTER TABLE `maxlife_tblpur_approval_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblpur_approval_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblpur_approval_setting`
--

DROP TABLE IF EXISTS `maxlife_tblpur_approval_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblpur_approval_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `related` varchar(255) NOT NULL,
  `setting` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblpur_approval_setting`
--

LOCK TABLES `maxlife_tblpur_approval_setting` WRITE;
/*!40000 ALTER TABLE `maxlife_tblpur_approval_setting` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblpur_approval_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblpur_comments`
--

DROP TABLE IF EXISTS `maxlife_tblpur_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblpur_comments` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `content` mediumtext DEFAULT NULL,
  `rel_type` varchar(50) NOT NULL,
  `rel_id` int(11) DEFAULT NULL,
  `staffid` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblpur_comments`
--

LOCK TABLES `maxlife_tblpur_comments` WRITE;
/*!40000 ALTER TABLE `maxlife_tblpur_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblpur_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblpur_contacts`
--

DROP TABLE IF EXISTS `maxlife_tblpur_contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblpur_contacts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `is_primary` int(11) NOT NULL DEFAULT 1,
  `firstname` varchar(191) NOT NULL,
  `lastname` varchar(191) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phonenumber` varchar(100) NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `new_pass_key` varchar(32) DEFAULT NULL,
  `new_pass_key_requested` datetime DEFAULT NULL,
  `email_verified_at` datetime DEFAULT NULL,
  `email_verification_key` varchar(32) DEFAULT NULL,
  `email_verification_sent_at` datetime DEFAULT NULL,
  `last_ip` varchar(40) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_password_change` datetime DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `profile_image` varchar(191) DEFAULT NULL,
  `direction` varchar(3) DEFAULT NULL,
  `invoice_emails` tinyint(1) NOT NULL DEFAULT 1,
  `estimate_emails` tinyint(1) NOT NULL DEFAULT 1,
  `credit_note_emails` tinyint(1) NOT NULL DEFAULT 1,
  `contract_emails` tinyint(1) NOT NULL DEFAULT 1,
  `task_emails` tinyint(1) NOT NULL DEFAULT 1,
  `project_emails` tinyint(1) NOT NULL DEFAULT 1,
  `ticket_emails` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblpur_contacts`
--

LOCK TABLES `maxlife_tblpur_contacts` WRITE;
/*!40000 ALTER TABLE `maxlife_tblpur_contacts` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblpur_contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblpur_contracts`
--

DROP TABLE IF EXISTS `maxlife_tblpur_contracts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblpur_contracts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `contract_number` varchar(200) NOT NULL,
  `contract_name` varchar(200) NOT NULL,
  `content` longtext DEFAULT NULL,
  `vendor` int(11) NOT NULL,
  `pur_order` int(11) NOT NULL,
  `contract_value` decimal(15,2) DEFAULT NULL,
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `buyer` int(11) DEFAULT NULL,
  `time_payment` date DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  `signed` int(32) NOT NULL DEFAULT 0,
  `note` longtext DEFAULT NULL,
  `signer` int(11) DEFAULT NULL,
  `signed_date` date DEFAULT NULL,
  `signed_status` varchar(50) DEFAULT NULL,
  `service_category` text DEFAULT NULL,
  `project` int(11) DEFAULT NULL,
  `payment_terms` text DEFAULT NULL,
  `payment_amount` decimal(15,2) DEFAULT NULL,
  `payment_cycle` varchar(50) DEFAULT NULL,
  `department` int(11) DEFAULT NULL,
  `signature` text DEFAULT NULL,
  `marked_as_signed` tinyint(1) DEFAULT 0,
  `acceptance_firstname` text DEFAULT NULL,
  `acceptance_lastname` text DEFAULT NULL,
  `acceptance_email` text DEFAULT NULL,
  `acceptance_date` datetime DEFAULT NULL,
  `acceptance_ip` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblpur_contracts`
--

LOCK TABLES `maxlife_tblpur_contracts` WRITE;
/*!40000 ALTER TABLE `maxlife_tblpur_contracts` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblpur_contracts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblpur_debit_notes`
--

DROP TABLE IF EXISTS `maxlife_tblpur_debit_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblpur_debit_notes` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `vendorid` int(11) DEFAULT NULL,
  `deleted_vendor_name` varchar(100) DEFAULT NULL,
  `number` int(11) DEFAULT NULL,
  `prefix` varchar(50) DEFAULT NULL,
  `number_format` int(11) DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `date` date DEFAULT NULL,
  `adminnote` text DEFAULT NULL,
  `terms` text DEFAULT NULL,
  `vendornote` text DEFAULT NULL,
  `currency` int(11) DEFAULT NULL,
  `subtotal` decimal(15,2) DEFAULT NULL,
  `total_tax` decimal(15,2) DEFAULT NULL,
  `total` decimal(15,2) DEFAULT NULL,
  `adjustment` decimal(15,2) DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `discount_percent` decimal(15,2) DEFAULT NULL,
  `discount_total` decimal(15,2) DEFAULT NULL,
  `discount_type` varchar(30) DEFAULT NULL,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT NULL,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT NULL,
  `include_shipping` tinyint(1) DEFAULT NULL,
  `show_shipping_on_debit_note` tinyint(1) DEFAULT NULL,
  `show_quantity_as` int(11) DEFAULT NULL,
  `reference_no` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblpur_debit_notes`
--

LOCK TABLES `maxlife_tblpur_debit_notes` WRITE;
/*!40000 ALTER TABLE `maxlife_tblpur_debit_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblpur_debit_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblpur_debits`
--

DROP TABLE IF EXISTS `maxlife_tblpur_debits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblpur_debits` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) DEFAULT NULL,
  `debit_id` int(11) DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `date_applied` datetime DEFAULT NULL,
  `date` date DEFAULT NULL,
  `amount` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblpur_debits`
--

LOCK TABLES `maxlife_tblpur_debits` WRITE;
/*!40000 ALTER TABLE `maxlife_tblpur_debits` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblpur_debits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblpur_debits_refunds`
--

DROP TABLE IF EXISTS `maxlife_tblpur_debits_refunds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblpur_debits_refunds` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `debit_note_id` int(11) DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `refunded_on` date DEFAULT NULL,
  `payment_mode` varchar(40) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `amount` decimal(15,2) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblpur_debits_refunds`
--

LOCK TABLES `maxlife_tblpur_debits_refunds` WRITE;
/*!40000 ALTER TABLE `maxlife_tblpur_debits_refunds` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblpur_debits_refunds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblpur_estimate_detail`
--

DROP TABLE IF EXISTS `maxlife_tblpur_estimate_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblpur_estimate_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pur_estimate` int(11) NOT NULL,
  `item_code` varchar(100) NOT NULL,
  `unit_id` int(11) DEFAULT NULL,
  `unit_price` decimal(15,2) DEFAULT NULL,
  `quantity` decimal(15,2) NOT NULL,
  `into_money` decimal(15,2) DEFAULT NULL,
  `tax` text DEFAULT NULL,
  `total` decimal(15,2) DEFAULT NULL,
  `total_money` decimal(15,2) DEFAULT NULL,
  `discount_money` decimal(15,2) DEFAULT NULL,
  `discount_%` decimal(15,2) DEFAULT NULL,
  `tax_value` decimal(15,2) DEFAULT NULL,
  `tax_rate` text DEFAULT NULL,
  `tax_name` text DEFAULT NULL,
  `item_name` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblpur_estimate_detail`
--

LOCK TABLES `maxlife_tblpur_estimate_detail` WRITE;
/*!40000 ALTER TABLE `maxlife_tblpur_estimate_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblpur_estimate_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblpur_estimates`
--

DROP TABLE IF EXISTS `maxlife_tblpur_estimates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblpur_estimates` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sent` tinyint(1) NOT NULL DEFAULT 0,
  `datesend` datetime DEFAULT NULL,
  `vendor` int(11) NOT NULL,
  `deleted_vendor_name` varchar(100) DEFAULT NULL,
  `pur_request` int(11) DEFAULT NULL,
  `number` int(11) NOT NULL,
  `prefix` varchar(50) DEFAULT NULL,
  `number_format` int(11) NOT NULL DEFAULT 0,
  `hash` varchar(32) DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `date` date NOT NULL,
  `expirydate` date DEFAULT NULL,
  `currency` int(11) NOT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `total_tax` decimal(15,2) NOT NULL,
  `total` decimal(15,2) NOT NULL,
  `adjustment` decimal(15,2) DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `vendornote` text DEFAULT NULL,
  `adminnote` text DEFAULT NULL,
  `discount_percent` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `discount_type` varchar(30) DEFAULT NULL,
  `invoiceid` int(11) DEFAULT NULL,
  `invoiced_date` datetime DEFAULT NULL,
  `terms` text DEFAULT NULL,
  `reference_no` varchar(100) DEFAULT NULL,
  `buyer` int(11) NOT NULL DEFAULT 0,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT NULL,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT NULL,
  `include_shipping` tinyint(1) NOT NULL,
  `show_shipping_on_estimate` tinyint(1) NOT NULL DEFAULT 1,
  `show_quantity_as` int(11) NOT NULL DEFAULT 1,
  `pipeline_order` int(11) NOT NULL DEFAULT 0,
  `is_expiry_notified` int(11) NOT NULL DEFAULT 0,
  `acceptance_firstname` varchar(50) DEFAULT NULL,
  `acceptance_lastname` varchar(50) DEFAULT NULL,
  `acceptance_email` varchar(100) DEFAULT NULL,
  `acceptance_date` datetime DEFAULT NULL,
  `acceptance_ip` varchar(40) DEFAULT NULL,
  `signature` varchar(40) DEFAULT NULL,
  `make_a_contract` text DEFAULT NULL,
  `currency_rate` decimal(15,6) DEFAULT NULL,
  `from_currency` varchar(20) DEFAULT NULL,
  `to_currency` varchar(20) DEFAULT NULL,
  `shipping_fee` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblpur_estimates`
--

LOCK TABLES `maxlife_tblpur_estimates` WRITE;
/*!40000 ALTER TABLE `maxlife_tblpur_estimates` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblpur_estimates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblpur_invoice_details`
--

DROP TABLE IF EXISTS `maxlife_tblpur_invoice_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblpur_invoice_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pur_invoice` int(11) NOT NULL,
  `item_code` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `unit_id` int(11) DEFAULT NULL,
  `unit_price` decimal(15,2) DEFAULT NULL,
  `quantity` decimal(15,2) DEFAULT NULL,
  `into_money` decimal(15,2) DEFAULT NULL,
  `tax` text DEFAULT NULL,
  `total` decimal(15,2) DEFAULT NULL,
  `discount_percent` decimal(15,2) DEFAULT NULL,
  `discount_money` decimal(15,2) DEFAULT NULL,
  `total_money` decimal(15,2) DEFAULT NULL,
  `tax_value` decimal(15,2) DEFAULT NULL,
  `tax_rate` text DEFAULT NULL,
  `tax_name` text DEFAULT NULL,
  `item_name` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblpur_invoice_details`
--

LOCK TABLES `maxlife_tblpur_invoice_details` WRITE;
/*!40000 ALTER TABLE `maxlife_tblpur_invoice_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblpur_invoice_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblpur_invoice_payment`
--

DROP TABLE IF EXISTS `maxlife_tblpur_invoice_payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblpur_invoice_payment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pur_invoice` int(11) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `paymentmode` longtext DEFAULT NULL,
  `date` date NOT NULL,
  `daterecorded` datetime NOT NULL,
  `note` text NOT NULL,
  `transactionid` mediumtext DEFAULT NULL,
  `approval_status` int(2) DEFAULT NULL,
  `requester` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblpur_invoice_payment`
--

LOCK TABLES `maxlife_tblpur_invoice_payment` WRITE;
/*!40000 ALTER TABLE `maxlife_tblpur_invoice_payment` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblpur_invoice_payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblpur_invoices`
--

DROP TABLE IF EXISTS `maxlife_tblpur_invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblpur_invoices` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `number` int(11) NOT NULL,
  `invoice_number` text DEFAULT NULL,
  `invoice_date` date DEFAULT NULL,
  `subtotal` decimal(15,2) DEFAULT NULL,
  `tax_rate` int(11) DEFAULT NULL,
  `tax` decimal(15,2) DEFAULT NULL,
  `total` decimal(15,2) DEFAULT NULL,
  `contract` int(11) DEFAULT NULL,
  `vendor` int(11) DEFAULT NULL,
  `transactionid` mediumtext DEFAULT NULL,
  `transaction_date` date DEFAULT NULL,
  `payment_request_status` varchar(30) DEFAULT NULL,
  `payment_status` varchar(30) DEFAULT NULL,
  `vendor_note` text DEFAULT NULL,
  `adminnote` text DEFAULT NULL,
  `terms` text DEFAULT NULL,
  `add_from` int(11) DEFAULT NULL,
  `date_add` date DEFAULT NULL,
  `pur_order` int(11) DEFAULT NULL,
  `recurring` int(11) DEFAULT NULL,
  `recurring_type` varchar(10) DEFAULT NULL,
  `cycles` int(11) DEFAULT 0,
  `total_cycles` int(11) DEFAULT 0,
  `last_recurring_date` date DEFAULT NULL,
  `is_recurring_from` int(11) DEFAULT NULL,
  `duedate` date DEFAULT NULL,
  `add_from_type` varchar(20) DEFAULT NULL,
  `currency` int(11) DEFAULT 0,
  `discount_total` decimal(15,2) DEFAULT NULL,
  `discount_percent` decimal(15,2) DEFAULT NULL,
  `currency_rate` decimal(15,6) DEFAULT NULL,
  `from_currency` varchar(20) DEFAULT NULL,
  `to_currency` varchar(20) DEFAULT NULL,
  `shipping_fee` decimal(15,2) DEFAULT NULL,
  `vendor_invoice_number` text DEFAULT NULL,
  `discount_type` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblpur_invoices`
--

LOCK TABLES `maxlife_tblpur_invoices` WRITE;
/*!40000 ALTER TABLE `maxlife_tblpur_invoices` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblpur_invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblpur_order_detail`
--

DROP TABLE IF EXISTS `maxlife_tblpur_order_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblpur_order_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pur_order` int(11) NOT NULL,
  `item_code` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `unit_id` int(11) DEFAULT NULL,
  `unit_price` decimal(15,2) DEFAULT NULL,
  `quantity` decimal(15,2) NOT NULL,
  `into_money` decimal(15,2) DEFAULT NULL,
  `tax` text DEFAULT NULL,
  `total` decimal(15,2) DEFAULT NULL,
  `discount_%` decimal(15,2) DEFAULT NULL,
  `discount_money` decimal(15,2) DEFAULT NULL,
  `total_money` decimal(15,2) DEFAULT NULL,
  `tax_value` decimal(15,2) DEFAULT NULL,
  `tax_rate` text DEFAULT NULL,
  `tax_name` text DEFAULT NULL,
  `item_name` text DEFAULT NULL,
  `wh_quantity_received` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblpur_order_detail`
--

LOCK TABLES `maxlife_tblpur_order_detail` WRITE;
/*!40000 ALTER TABLE `maxlife_tblpur_order_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblpur_order_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblpur_order_payment`
--

DROP TABLE IF EXISTS `maxlife_tblpur_order_payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblpur_order_payment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pur_order` int(11) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `paymentmode` longtext DEFAULT NULL,
  `date` date NOT NULL,
  `daterecorded` datetime NOT NULL,
  `note` text NOT NULL,
  `transactionid` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblpur_order_payment`
--

LOCK TABLES `maxlife_tblpur_order_payment` WRITE;
/*!40000 ALTER TABLE `maxlife_tblpur_order_payment` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblpur_order_payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblpur_orders`
--

DROP TABLE IF EXISTS `maxlife_tblpur_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblpur_orders` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pur_order_name` varchar(100) NOT NULL,
  `vendor` int(11) NOT NULL,
  `estimate` int(11) NOT NULL,
  `pur_order_number` varchar(30) NOT NULL,
  `order_date` date NOT NULL,
  `status` int(32) NOT NULL DEFAULT 1,
  `approve_status` int(32) NOT NULL DEFAULT 1,
  `datecreated` datetime NOT NULL,
  `days_owed` int(11) NOT NULL,
  `delivery_date` date DEFAULT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `total_tax` decimal(15,2) NOT NULL,
  `total` decimal(15,2) NOT NULL,
  `addedfrom` int(11) NOT NULL,
  `vendornote` text DEFAULT NULL,
  `terms` text DEFAULT NULL,
  `discount_percent` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `discount_type` varchar(30) DEFAULT NULL,
  `buyer` int(11) NOT NULL DEFAULT 0,
  `status_goods` int(11) NOT NULL DEFAULT 0,
  `number` int(11) DEFAULT NULL,
  `expense_convert` int(11) DEFAULT 0,
  `hash` varchar(32) DEFAULT NULL,
  `clients` text DEFAULT NULL,
  `delivery_status` int(2) DEFAULT 0,
  `type` text DEFAULT NULL,
  `project` int(11) DEFAULT NULL,
  `pur_request` int(11) DEFAULT NULL,
  `department` int(11) DEFAULT NULL,
  `tax_order_rate` decimal(15,2) DEFAULT NULL,
  `tax_order_amount` decimal(15,2) DEFAULT NULL,
  `sale_invoice` int(11) DEFAULT NULL,
  `currency` int(11) DEFAULT 0,
  `order_status` varchar(30) DEFAULT NULL,
  `shipping_note` text DEFAULT NULL,
  `currency_rate` decimal(15,6) DEFAULT NULL,
  `from_currency` varchar(20) DEFAULT NULL,
  `to_currency` varchar(20) DEFAULT NULL,
  `shipping_fee` decimal(15,2) DEFAULT NULL,
  `shipping_address` text DEFAULT NULL,
  `shipping_city` text DEFAULT NULL,
  `shipping_state` text DEFAULT NULL,
  `shipping_zip` text DEFAULT NULL,
  `shipping_country` int(11) DEFAULT NULL,
  `shipping_country_text` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblpur_orders`
--

LOCK TABLES `maxlife_tblpur_orders` WRITE;
/*!40000 ALTER TABLE `maxlife_tblpur_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblpur_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblpur_request`
--

DROP TABLE IF EXISTS `maxlife_tblpur_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblpur_request` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pur_rq_code` varchar(45) NOT NULL,
  `pur_rq_name` varchar(100) NOT NULL,
  `rq_description` text DEFAULT NULL,
  `requester` int(11) NOT NULL,
  `department` int(11) DEFAULT NULL,
  `request_date` datetime NOT NULL,
  `status` int(11) DEFAULT NULL,
  `status_goods` int(11) NOT NULL DEFAULT 0,
  `hash` varchar(32) DEFAULT NULL,
  `type` text DEFAULT NULL,
  `project` int(11) DEFAULT NULL,
  `number` int(11) DEFAULT NULL,
  `from_items` int(2) DEFAULT 1,
  `subtotal` decimal(15,2) DEFAULT NULL,
  `total_tax` decimal(15,2) DEFAULT NULL,
  `total` decimal(15,2) DEFAULT NULL,
  `sale_invoice` int(11) DEFAULT NULL,
  `compare_note` text DEFAULT NULL,
  `send_to_vendors` text DEFAULT NULL,
  `currency` int(11) DEFAULT 0,
  `currency_rate` decimal(15,6) DEFAULT NULL,
  `from_currency` varchar(20) DEFAULT NULL,
  `to_currency` varchar(20) DEFAULT NULL,
  `sale_estimate` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblpur_request`
--

LOCK TABLES `maxlife_tblpur_request` WRITE;
/*!40000 ALTER TABLE `maxlife_tblpur_request` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblpur_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblpur_request_detail`
--

DROP TABLE IF EXISTS `maxlife_tblpur_request_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblpur_request_detail` (
  `prd_id` int(11) NOT NULL AUTO_INCREMENT,
  `pur_request` int(11) NOT NULL,
  `item_code` varchar(100) NOT NULL,
  `unit_id` int(11) DEFAULT NULL,
  `unit_price` decimal(15,2) DEFAULT NULL,
  `quantity` decimal(15,2) NOT NULL,
  `into_money` decimal(15,2) DEFAULT NULL,
  `inventory_quantity` int(11) DEFAULT 0,
  `item_text` text DEFAULT NULL,
  `tax` text DEFAULT NULL,
  `tax_rate` text DEFAULT NULL,
  `tax_value` decimal(15,2) DEFAULT NULL,
  `total` decimal(15,2) DEFAULT NULL,
  `tax_name` text DEFAULT NULL,
  PRIMARY KEY (`prd_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblpur_request_detail`
--

LOCK TABLES `maxlife_tblpur_request_detail` WRITE;
/*!40000 ALTER TABLE `maxlife_tblpur_request_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblpur_request_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblpur_unit`
--

DROP TABLE IF EXISTS `maxlife_tblpur_unit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblpur_unit` (
  `unit_id` int(11) NOT NULL AUTO_INCREMENT,
  `unit_name` varchar(100) NOT NULL,
  PRIMARY KEY (`unit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblpur_unit`
--

LOCK TABLES `maxlife_tblpur_unit` WRITE;
/*!40000 ALTER TABLE `maxlife_tblpur_unit` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblpur_unit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblpur_vendor`
--

DROP TABLE IF EXISTS `maxlife_tblpur_vendor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblpur_vendor` (
  `userid` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `company` varchar(200) DEFAULT NULL,
  `vat` varchar(200) DEFAULT NULL,
  `phonenumber` varchar(30) DEFAULT NULL,
  `country` int(11) NOT NULL DEFAULT 0,
  `city` varchar(100) DEFAULT NULL,
  `zip` varchar(15) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `website` varchar(150) DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `active` int(11) NOT NULL DEFAULT 1,
  `leadid` int(11) DEFAULT NULL,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT 0,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT 0,
  `longitude` varchar(191) DEFAULT NULL,
  `latitude` varchar(191) DEFAULT NULL,
  `default_language` varchar(40) DEFAULT NULL,
  `default_currency` int(11) NOT NULL DEFAULT 0,
  `show_primary_contact` int(11) NOT NULL DEFAULT 0,
  `stripe_id` varchar(40) DEFAULT NULL,
  `registration_confirmed` int(11) NOT NULL DEFAULT 1,
  `addedfrom` int(11) NOT NULL DEFAULT 0,
  `category` text DEFAULT NULL,
  `bank_detail` text DEFAULT NULL,
  `payment_terms` text DEFAULT NULL,
  `vendor_code` varchar(100) DEFAULT NULL,
  `return_within_day` int(11) DEFAULT NULL,
  `return_order_fee` decimal(15,2) DEFAULT NULL,
  `return_policies` text DEFAULT NULL,
  `balance` decimal(15,2) DEFAULT NULL,
  `balance_as_of` date DEFAULT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblpur_vendor`
--

LOCK TABLES `maxlife_tblpur_vendor` WRITE;
/*!40000 ALTER TABLE `maxlife_tblpur_vendor` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblpur_vendor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblpur_vendor_admin`
--

DROP TABLE IF EXISTS `maxlife_tblpur_vendor_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblpur_vendor_admin` (
  `staff_id` int(11) NOT NULL,
  `vendor_id` int(11) NOT NULL,
  `date_assigned` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblpur_vendor_admin`
--

LOCK TABLES `maxlife_tblpur_vendor_admin` WRITE;
/*!40000 ALTER TABLE `maxlife_tblpur_vendor_admin` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblpur_vendor_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblpur_vendor_cate`
--

DROP TABLE IF EXISTS `maxlife_tblpur_vendor_cate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblpur_vendor_cate` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblpur_vendor_cate`
--

LOCK TABLES `maxlife_tblpur_vendor_cate` WRITE;
/*!40000 ALTER TABLE `maxlife_tblpur_vendor_cate` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblpur_vendor_cate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblpur_vendor_items`
--

DROP TABLE IF EXISTS `maxlife_tblpur_vendor_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblpur_vendor_items` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `vendor` int(11) NOT NULL,
  `group_items` int(11) DEFAULT NULL,
  `items` int(11) NOT NULL,
  `add_from` int(11) DEFAULT NULL,
  `datecreate` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblpur_vendor_items`
--

LOCK TABLES `maxlife_tblpur_vendor_items` WRITE;
/*!40000 ALTER TABLE `maxlife_tblpur_vendor_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblpur_vendor_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblpurchase_option`
--

DROP TABLE IF EXISTS `maxlife_tblpurchase_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblpurchase_option` (
  `option_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(200) NOT NULL,
  `option_val` longtext DEFAULT NULL,
  `auto` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`option_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblpurchase_option`
--

LOCK TABLES `maxlife_tblpurchase_option` WRITE;
/*!40000 ALTER TABLE `maxlife_tblpurchase_option` DISABLE KEYS */;
INSERT INTO `maxlife_tblpurchase_option` VALUES (1,'purchase_order_setting','1',1),(2,'pur_order_prefix','#PO',1),(3,'next_po_number','1',1),(4,'date_reset_number','',1),(5,'pur_request_prefix','#PR',1),(6,'next_pr_number','1',1),(7,'date_reset_pr_number','',1),(8,'pur_inv_prefix','#INV',1),(9,'next_inv_number','1',1),(10,'create_invoice_by','contract',1),(11,'item_by_vendor','0',1),(12,'terms_and_conditions','',1),(13,'vendor_note','',1);
/*!40000 ALTER TABLE `maxlife_tblpurchase_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblrelated_items`
--

DROP TABLE IF EXISTS `maxlife_tblrelated_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblrelated_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(30) NOT NULL,
  `item_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblrelated_items`
--

LOCK TABLES `maxlife_tblrelated_items` WRITE;
/*!40000 ALTER TABLE `maxlife_tblrelated_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblrelated_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblreminders`
--

DROP TABLE IF EXISTS `maxlife_tblreminders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblreminders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` mediumtext DEFAULT NULL,
  `date` datetime NOT NULL,
  `isnotified` int(11) NOT NULL DEFAULT 0,
  `rel_id` int(11) NOT NULL,
  `staff` int(11) NOT NULL,
  `rel_type` varchar(40) NOT NULL,
  `notify_by_email` int(11) NOT NULL DEFAULT 1,
  `creator` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`),
  KEY `maxlife_staff` (`staff`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblreminders`
--

LOCK TABLES `maxlife_tblreminders` WRITE;
/*!40000 ALTER TABLE `maxlife_tblreminders` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblreminders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblroles`
--

DROP TABLE IF EXISTS `maxlife_tblroles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblroles` (
  `roleid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `permissions` longtext DEFAULT NULL,
  `enable_gg_auth` int(1) DEFAULT 0,
  PRIMARY KEY (`roleid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblroles`
--

LOCK TABLES `maxlife_tblroles` WRITE;
/*!40000 ALTER TABLE `maxlife_tblroles` DISABLE KEYS */;
INSERT INTO `maxlife_tblroles` VALUES (1,'Employee',NULL,0);
/*!40000 ALTER TABLE `maxlife_tblroles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblsales_activity`
--

DROP TABLE IF EXISTS `maxlife_tblsales_activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblsales_activity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_type` varchar(20) DEFAULT NULL,
  `rel_id` int(11) NOT NULL,
  `description` mediumtext NOT NULL,
  `additional_data` mediumtext DEFAULT NULL,
  `staffid` varchar(11) DEFAULT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblsales_activity`
--

LOCK TABLES `maxlife_tblsales_activity` WRITE;
/*!40000 ALTER TABLE `maxlife_tblsales_activity` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblsales_activity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblsales_channel`
--

DROP TABLE IF EXISTS `maxlife_tblsales_channel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblsales_channel` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `channel` varchar(150) NOT NULL,
  `status` varchar(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblsales_channel`
--

LOCK TABLES `maxlife_tblsales_channel` WRITE;
/*!40000 ALTER TABLE `maxlife_tblsales_channel` DISABLE KEYS */;
INSERT INTO `maxlife_tblsales_channel` VALUES (1,'pos','active'),(2,'portal','active'),(3,'woocommerce','deactive'),(4,'pre_order','deactive');
/*!40000 ALTER TABLE `maxlife_tblsales_channel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblsales_channel_detailt`
--

DROP TABLE IF EXISTS `maxlife_tblsales_channel_detailt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblsales_channel_detailt` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `group_product_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `sales_channel_id` int(11) NOT NULL,
  `prices` decimal(15,2) DEFAULT NULL,
  `department` text DEFAULT NULL,
  `pre_order_product_st_id` int(11) DEFAULT NULL,
  `customer_group` text DEFAULT NULL,
  `customer` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblsales_channel_detailt`
--

LOCK TABLES `maxlife_tblsales_channel_detailt` WRITE;
/*!40000 ALTER TABLE `maxlife_tblsales_channel_detailt` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblsales_channel_detailt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblscheduled_emails`
--

DROP TABLE IF EXISTS `maxlife_tblscheduled_emails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblscheduled_emails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(15) NOT NULL,
  `scheduled_at` datetime NOT NULL,
  `contacts` varchar(197) NOT NULL,
  `cc` mediumtext DEFAULT NULL,
  `attach_pdf` tinyint(1) NOT NULL DEFAULT 1,
  `template` varchar(197) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblscheduled_emails`
--

LOCK TABLES `maxlife_tblscheduled_emails` WRITE;
/*!40000 ALTER TABLE `maxlife_tblscheduled_emails` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblscheduled_emails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblservices`
--

DROP TABLE IF EXISTS `maxlife_tblservices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblservices` (
  `serviceid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`serviceid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblservices`
--

LOCK TABLES `maxlife_tblservices` WRITE;
/*!40000 ALTER TABLE `maxlife_tblservices` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblservices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblsessions`
--

DROP TABLE IF EXISTS `maxlife_tblsessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblsessions` (
  `id` varchar(128) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT 0,
  `data` blob NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ci_sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblsessions`
--

LOCK TABLES `maxlife_tblsessions` WRITE;
/*!40000 ALTER TABLE `maxlife_tblsessions` DISABLE KEYS */;
INSERT INTO `maxlife_tblsessions` VALUES ('0005e87g8ha16iieb4154c3sd8afp1ui','82.29.165.22',1752450126,'__ci_last_regenerate|i:1752450126;'),('00tvaqfd97qot3j26go15f632agcpusg','82.29.165.22',1752475088,'__ci_last_regenerate|i:1752475088;'),('06grpqeo44qj38lfjj3rjud19bkf61co','82.29.165.22',1752435067,'__ci_last_regenerate|i:1752435067;'),('09am1ho4nfrhnq677k80a5eofr7aprco','82.29.165.22',1752501305,'__ci_last_regenerate|i:1752501305;'),('0bmk9tn8gslbk9ae01td85l8u3f19ajm','82.29.165.22',1752441067,'__ci_last_regenerate|i:1752441067;'),('0c2ajpofa50litghqjscltdugl2ak91i','82.29.165.22',1752484270,'__ci_last_regenerate|i:1752484270;'),('0f4e0k539j47pomvlo0qfp96bm5b219o','82.29.165.22',1752494769,'__ci_last_regenerate|i:1752494769;'),('0fedcbdt868tm899fgq336fqr4db14dk','82.29.165.22',1752489490,'__ci_last_regenerate|i:1752489490;'),('0pq58200nkkjttrf33t00hk7c7hmeesl','82.29.165.22',1752519248,'__ci_last_regenerate|i:1752519248;'),('0q4q8171ebk4pljhp92bks86ejseuvb9','82.29.165.22',1752444307,'__ci_last_regenerate|i:1752444307;'),('0q652aice0u7ao9sdman3gqtumdn63n0','82.29.165.22',1752424213,'__ci_last_regenerate|i:1752424213;'),('0q6t6ir9c126q2ovguakj4nkp3r43v9v','82.29.165.22',1752496510,'__ci_last_regenerate|i:1752496510;'),('0soqckptr5ml2f8s2on6odad49i1pnbi','82.29.165.22',1752419351,'__ci_last_regenerate|i:1752419351;'),('0tvfjfi16bgr242fmb9s66t1g1vl5cg3','82.29.165.22',1752467768,'__ci_last_regenerate|i:1752467768;'),('13dqrvhog094i0nsjh4d2qeh8u2m8n1n','82.29.165.22',1752470228,'__ci_last_regenerate|i:1752470227;'),('1q35hkodg5qfcng6d5nm1pbr65avl9ub','82.29.165.22',1752488050,'__ci_last_regenerate|i:1752488050;'),('1qqf9m4t1f3v3lmmspeth4568cr5hofq','82.29.165.22',1752482826,'__ci_last_regenerate|i:1752482826;'),('1r98mcps2v2g1qpqp026glgl0281h9s1','82.29.165.22',1752443586,'__ci_last_regenerate|i:1752443586;'),('1uutfas4i0151elph662op9pieo61pqr','82.29.165.22',1752524764,'__ci_last_regenerate|i:1752524764;'),('2bavmuj5e2iklei9ur2cd2g8cgt8lo6f','82.29.165.22',1752418989,'__ci_last_regenerate|i:1752418989;'),('2bsu7c9ta4h5gm8ms2q903dqeaankh2r','82.29.165.22',1752461408,'__ci_last_regenerate|i:1752461408;'),('2de3a3mdqjn5k57jultucuui53eqbvbt','82.29.165.22',1752464287,'__ci_last_regenerate|i:1752464287;'),('2l4l1augqibf7j806crfqk9jbpghovo0','82.29.165.22',1752482530,'__ci_last_regenerate|i:1752482530;'),('2m9ml3cdm92evacduda9v0th4c903b7f','82.29.165.22',1752462127,'__ci_last_regenerate|i:1752462127;'),('2nntgq3racttfp11usv0ihjqs3tsdci1','82.29.165.22',1752458226,'__ci_last_regenerate|i:1752458226;'),('2pt8bji8gots6l5npm4fsandqn6htq3f','82.29.165.22',1752463567,'__ci_last_regenerate|i:1752463567;'),('2suk1c6vrs78e7t0ufrcmss8kln7urui','82.29.165.22',1752439267,'__ci_last_regenerate|i:1752439267;'),('2t67pvnlhbleh3ihcltbqrpg3fvjsmgv','82.29.165.22',1752417245,'__ci_last_regenerate|i:1752417245;'),('3072a8168n992f34d2tuotksoo1suokf','82.29.165.22',1752432608,'__ci_last_regenerate|i:1752432608;'),('314kuvalkm4537k6i9iil352kngisvb8','82.29.165.22',1752437527,'__ci_last_regenerate|i:1752437527;'),('31fqs759ls6uhbln6i2vj9h5tqomeuf2','82.29.165.22',1752429068,'__ci_last_regenerate|i:1752429068;'),('34hm6aioilg1bp8vj5srqj5i4irf6ofm','82.29.165.22',1752459309,'__ci_last_regenerate|i:1752459309;'),('3ah4jainab08cbjmuq47c290pdee29aq','82.29.165.22',1752512287,'__ci_last_regenerate|i:1752512287;'),('3cem0pgd3hresft88efrit3v7ialj08a','82.29.165.22',1752505569,'__ci_last_regenerate|i:1752505569;'),('3k0d2slr76k4c4ifegnhblapisvqo62a','82.29.165.22',1752430868,'__ci_last_regenerate|i:1752430868;'),('3lh6e05gevn9qjtr1rufbpvd8jcrvq8c','82.29.165.22',1752423486,'__ci_last_regenerate|i:1752423486;'),('3lsj73u5ghrqbrgjeseak4p5q3i9glkh','82.29.165.22',1752485952,'__ci_last_regenerate|i:1752485952;'),('3q1nkhrias2fmapnvbjkfau904e6hdqb','82.29.165.22',1752489849,'__ci_last_regenerate|i:1752489849;'),('3qh4l06v49fcn9ie8ngou0c1b6gs675i','82.29.165.22',1752437887,'__ci_last_regenerate|i:1752437887;'),('41miug41ggk4dkgq16m4rfob4n180npj','82.29.165.22',1752483550,'__ci_last_regenerate|i:1752483550;'),('45hapfp6auveum2d143noa57q1pb157i','82.29.165.22',1752499268,'__ci_last_regenerate|i:1752499268;'),('48akorrefsbimbtgc8g0shsvdsad1mmc','82.29.165.22',1752509824,'__ci_last_regenerate|i:1752509824;'),('4opl4nddur4nn7lub80u15kamhbvl4da','82.29.165.22',1752515411,'__ci_last_regenerate|i:1752515411;'),('4pejbjra84usnifhtnmafqo7lf7rtie2','82.29.165.22',1752506648,'__ci_last_regenerate|i:1752506648;'),('4s084s244u4dnjpl19rot7ltvr89pcv0','82.29.165.22',1752521707,'__ci_last_regenerate|i:1752521707;'),('4tcadtcmipohjuf2ng71n25ss0p5teeu','82.29.165.22',1752520627,'__ci_last_regenerate|i:1752520627;'),('52180nqj9vo847tr7i76klnj6dbvgjvd','82.29.165.22',1752457867,'__ci_last_regenerate|i:1752457866;'),('5ch671200lukkoh5e1fehdp58p2g11kj','82.29.165.22',1752500288,'__ci_last_regenerate|i:1752500288;'),('5crnv8kdoaheju07dqrui5cutefq812r','82.29.165.22',1752512647,'__ci_last_regenerate|i:1752512647;'),('5eq4ujt390gdf6iv0jejbf69feh9fonn','82.29.165.22',1752524467,'__ci_last_regenerate|i:1752524467;'),('5fdh7d8tlp8u49gs8tf8qjr5u0cucrg2','82.29.165.22',1752478569,'__ci_last_regenerate|i:1752478569;'),('5gaagk7lom0699te2ic5kidr9cr38kbc','82.29.165.22',1752491886,'__ci_last_regenerate|i:1752491886;'),('5os8kr5fu8chaujl5cgtfrsulkg1jovi','82.29.165.22',1752461048,'__ci_last_regenerate|i:1752461048;'),('5qi77cq99fj8pg2p7ib82afu7m5cvchs','82.29.165.22',1752510911,'__ci_last_regenerate|i:1752510911;'),('64lufkro18jv99iga4dhvp6uimq8vetc','82.29.165.22',1752501616,'__ci_last_regenerate|i:1752501616;'),('6c80rprsp0pa9ra7v01bck8fk54m5224','82.29.165.22',1752456426,'__ci_last_regenerate|i:1752456426;'),('6ek6g0ss10dq048t295bfml9qdq3npu2','82.29.165.22',1752442867,'__ci_last_regenerate|i:1752442867;'),('6nlvi1vebr9puq50a88ekgjjvcdks19r','82.29.165.22',1752447364,'__ci_last_regenerate|i:1752447364;'),('6o29b1j2l7mvo9fqdjapha1cbuajnmn3','82.29.165.22',1752431531,'__ci_last_regenerate|i:1752431531;'),('6p9rn4futtjavf9e0pqae6lss5l6oclo','82.29.165.22',1752490930,'__ci_last_regenerate|i:1752490930;'),('6puig243jd95ria1iollvokhp41l55db','82.29.165.22',1752426668,'__ci_last_regenerate|i:1752426668;'),('70a4pl98jmcjj4svtjtuft9mc8c42j5g','82.29.165.22',1752478929,'__ci_last_regenerate|i:1752478929;'),('7aaj2iq5uj5gtumg052lhsc16j62op35','82.29.165.22',1752520988,'__ci_last_regenerate|i:1752520988;'),('7d95jkbgumagestpgvghim7vs3dd7egi','82.29.165.22',1752506288,'__ci_last_regenerate|i:1752506288;'),('7fqhgdieps8p4htrvk25v5k873tsfjpf','82.29.165.22',1752523388,'__ci_last_regenerate|i:1752523388;'),('7fv8kuk1jjd6ekk9a0h5d5s0pp4kpu1d','82.29.165.22',1752460325,'__ci_last_regenerate|i:1752460325;'),('7ibg422nnk87d8r2i2neqjd98nr9j1tr','82.29.165.22',1752495789,'__ci_last_regenerate|i:1752495789;'),('7jk7jpihpr5nltuc76g7p01rvtk180tq','82.29.165.22',1752497168,'__ci_last_regenerate|i:1752497168;'),('7jpr46h4nq3hb7ofj9s49qabdmu2qll5','82.29.165.22',1752441787,'__ci_last_regenerate|i:1752441787;'),('7o2ban5tv037metss8ce9t0uchj4pifb','82.29.165.22',1752520268,'__ci_last_regenerate|i:1752520268;'),('7qu5135i1e7uhfnm7il568fkfrikqiim','82.29.165.22',1752476466,'__ci_last_regenerate|i:1752476466;'),('7u7a7g8ss1dnpanlo75tqnu272va8381','82.29.165.22',1752440346,'__ci_last_regenerate|i:1752440346;'),('82dt84083lk0qthbpmi3aajeu8tva101','82.29.165.22',1752472028,'__ci_last_regenerate|i:1752472028;'),('86qibnk585bj803lgebe2no9klv7pnaj','82.29.165.22',1752455766,'__ci_last_regenerate|i:1752455766;'),('87924itsnm49q57bi1idpafi0e0vghlm','82.29.165.22',1752486311,'__ci_last_regenerate|i:1752486311;'),('8k76adk1jsn8fbe1krnjj0604qmga2ls','82.29.165.22',1752497828,'__ci_last_regenerate|i:1752497828;'),('8mboda0pvfmnhlicetpara1ltf14bk6p','82.29.165.22',1752488411,'__ci_last_regenerate|i:1752488411;'),('8min0fe7veodt1nvkcc6q5suoh7gtgis','82.29.165.22',1752417551,'__ci_last_regenerate|i:1752417550;'),('8nn0gt5tviqdc8ftgjh23f4qlkb61hg2','82.29.165.22',1752431165,'__ci_last_regenerate|i:1752431165;'),('8q7t4p91enrc7h81hift5sm2vlnme9op','82.29.165.22',1752483189,'__ci_last_regenerate|i:1752483189;'),('8shhjo620s4gqbpr9ekgpv9g0h9tedss','82.29.165.22',1752428047,'__ci_last_regenerate|i:1752428047;'),('9048l5jf032r4oac8kvn2bph9blc3sau','82.29.165.22',1752439987,'__ci_last_regenerate|i:1752439987;'),('92vmoj8c45ajgbp7kqc60pfmab6pp436','82.29.165.22',1752518168,'__ci_last_regenerate|i:1752518168;'),('970t5r7n05c1cp5inb2fjrttolr44n7r','82.29.165.22',1752472689,'__ci_last_regenerate|i:1752472689;'),('9d24ecp10s07e0m1eo9etb0lvgdg32oh','82.29.165.22',1752444666,'__ci_last_regenerate|i:1752444666;'),('9f5uumskihrm1i148f82nphboji4qs6i','82.29.165.22',1752499929,'__ci_last_regenerate|i:1752499929;'),('9h18okoelqldljlrmunutv5t88n7a1so','82.29.165.22',1752456787,'__ci_last_regenerate|i:1752456787;'),('9lu9g863vi2fihq7l2n362mq4va53bl7','82.29.165.22',1752422469,'__ci_last_regenerate|i:1752422469;'),('9ns3r027a0pageninn3pnjpp78iq23gs','82.29.165.22',1752419709,'__ci_last_regenerate|i:1752419709;'),('9odh1po0oi57ail50gjp7clc8ecgf6i0','82.29.165.22',1752414489,'__ci_last_regenerate|i:1752414489;'),('9ol4s9tvgd7g3g7el0l83pmeqhkchp6h','82.29.165.22',1752432247,'__ci_last_regenerate|i:1752432247;'),('9p8oluql8ei5f6kfto9hn19fgke0t0cg','82.29.165.22',1752507014,'__ci_last_regenerate|i:1752507014;'),('9uqfqv1h6uslbtm0p14m5fq10a2jv2mv','82.29.165.22',1752476829,'__ci_last_regenerate|i:1752476829;'),('9v2js0at61j6bm2ftsj7e9d0npfp1h0q','82.29.165.22',1752414129,'__ci_last_regenerate|i:1752414129;'),('a03sdve0splcs390ffj5snfja2vcubof','82.29.165.22',1752413395,'__ci_last_regenerate|i:1752413390;'),('a0jm36ncnig07uq81hknf39fs81e0pak','82.29.165.22',1752428709,'__ci_last_regenerate|i:1752428709;'),('a5umpgrpogcaf44vqbs4cs6bjsadrmup','82.29.165.22',1752453667,'__ci_last_regenerate|i:1752453667;'),('abh635idvs8fee4tl926g43vd2sht9ei','82.29.165.22',1752450486,'__ci_last_regenerate|i:1752450486;'),('amblt4js8ggeujl4guqlb4qeru67gjmm','82.29.165.22',1752516129,'__ci_last_regenerate|i:1752516129;'),('aoaqt7ksks7ov73v39v3hp9hjtkrjocr','82.29.165.22',1752465612,'__ci_last_regenerate|i:1752465612;'),('as4ota0vg0j4llgb1qdo1kob91r953n5','106.219.231.124',1752413396,'__ci_last_regenerate|i:1752413393;staff_user_id|s:1:\"1\";staff_logged_in|b:1;red_url|s:30:\"https://maxlife.techdotbit.in/\";'),('b09jv7ibs6fa94gi3q0tgfa8av4l2od2','82.29.165.22',1752463208,'__ci_last_regenerate|i:1752463208;'),('b0u4rn36750h5vgbu3lochrldtltiduk','82.29.165.22',1752425948,'__ci_last_regenerate|i:1752425948;'),('b2ogeo7sv905918n3psm7lum0pg9s49f','82.29.165.22',1752511564,'__ci_last_regenerate|i:1752511564;'),('b3kgb2qqu3gjgia7075ece5dnpetuc7u','82.29.165.22',1752517144,'__ci_last_regenerate|i:1752517144;'),('bbmnrk0cuqlpejfdhfjj5kk80ujnp5mg','82.29.165.22',1752438247,'__ci_last_regenerate|i:1752438247;'),('be042kccp9bd6infr366asaipbtebfnh','82.29.165.22',1752446708,'__ci_last_regenerate|i:1752446708;'),('bmp47v9ub863f9mgba4lvjl8nj7cbtiq','82.29.165.22',1752518527,'__ci_last_regenerate|i:1752518527;'),('bmsvju4cst2a2cq27icu2nbipabkarp6','82.29.165.22',1752492614,'__ci_last_regenerate|i:1752492614;'),('bnl7kdfqe21e3qph7u4h50j8retellii','82.29.165.22',1752508814,'__ci_last_regenerate|i:1752508814;'),('bpdsueg6kbigmd982ohf4sm57lbjdgum','82.29.165.22',1752513668,'__ci_last_regenerate|i:1752513668;'),('c5el0genl9a1h0b11ugtvobq4bhcacl3','82.29.165.22',1752524110,'__ci_last_regenerate|i:1752524110;'),('c947kreg393j9uu1p2ufv1c10apcnno7','82.29.165.22',1752456064,'__ci_last_regenerate|i:1752456064;'),('ce67jqprkahd49plpbgo29o1nnjminu2','82.29.165.22',1752474007,'__ci_last_regenerate|i:1752474007;'),('cofddo1an0pc5ga58tgq41qq79p7ofsd','82.29.165.22',1752517806,'__ci_last_regenerate|i:1752517806;'),('cvlv346jtflchi70ag155spos5urhqah','82.29.165.22',1752475449,'__ci_last_regenerate|i:1752475449;'),('deq1lb3fiemvb0mlt7d13cb235ohubpj','82.29.165.22',1752503048,'__ci_last_regenerate|i:1752503048;'),('diaih4pt823s7s717qdkaqep70be1u5l','82.29.165.22',1752513009,'__ci_last_regenerate|i:1752513009;'),('dnkr9ue9pgve00mdfu29vkkq4dn1nf6o','82.29.165.22',1752457149,'__ci_last_regenerate|i:1752457149;'),('dp4b7a7toiquk9ac49g2rcg9omcei7eh','82.29.165.22',1752452646,'__ci_last_regenerate|i:1752452646;'),('dtogadoqdbc1avlnu389gc72oohlqihv','82.29.165.22',1752413770,'__ci_last_regenerate|i:1752413770;'),('e4l6c1cftudk2fave3js9rvalpuc3opo','82.29.165.22',1752432904,'__ci_last_regenerate|i:1752432904;'),('e7p917c609t5oomi8dd41u8hre0lod1t','82.29.165.22',1752438544,'__ci_last_regenerate|i:1752438544;'),('e7um6gepb06v847s21ls478p1po8tp5n','82.29.165.22',1752516847,'__ci_last_regenerate|i:1752516847;'),('e8vvpfpio4gsebbudhuk5nbrlcunt3mu','82.29.165.22',1752498909,'__ci_last_regenerate|i:1752498909;'),('ea3jjqjnjc106ko6i1l7v21ib6jadr0b','82.29.165.22',1752517509,'__ci_last_regenerate|i:1752517509;'),('elecgjfkqc261fn53dnvr2efddtdsmlh','82.29.165.22',1752491226,'__ci_last_regenerate|i:1752491226;'),('endamajbjhcmf40s0qhjfnjt47kmrtbs','82.29.165.22',1752415212,'__ci_last_regenerate|i:1752415212;'),('eujvfpqnd0e4l4g6q24gnnrtq7eu0p2i','82.29.165.22',1752509528,'__ci_last_regenerate|i:1752509528;'),('f1v4jo8lo7fjpqn69vmc02fg552c97u4','82.29.165.22',1752436814,'__ci_last_regenerate|i:1752436814;'),('f4mvak04hbrm8uj99n3o36965te39ubm','82.29.165.22',1752434347,'__ci_last_regenerate|i:1752434347;'),('f6dib2encag2htne0jav03qe9hsgbn00','82.29.165.22',1752418628,'__ci_last_regenerate|i:1752418628;'),('f8jub7g363adeu90v5rg0s93bos7f2bj','82.29.165.22',1752514028,'__ci_last_regenerate|i:1752514028;'),('fdkns9s9j9dgftbiehphek8iged2j6ug','82.29.165.22',1752450846,'__ci_last_regenerate|i:1752450846;'),('fe5hid0hvf6letput0v5o79skl8cct2t','82.29.165.22',1752433987,'__ci_last_regenerate|i:1752433987;'),('fh6pr12v8kisjp76da2j5ilqc8kkccah','82.29.165.22',1752435787,'__ci_last_regenerate|i:1752435787;'),('fhaukm76e37vb9b5sd9bs4kl8tou0e2h','82.29.165.22',1752447727,'__ci_last_regenerate|i:1752447727;'),('fju91sj84r7miu1l6okei7b9raeso652','82.29.165.22',1752446348,'__ci_last_regenerate|i:1752446348;'),('fkunfhsumqtplmebl7smamn25kg61jn3','82.29.165.22',1752425588,'__ci_last_regenerate|i:1752425588;'),('foae2ie6bm6up0mnkcvq99olgtp0esn7','82.29.165.22',1752502328,'__ci_last_regenerate|i:1752502328;'),('fqmc4jd94auef71pedrl3ek4tbtgd1ed','82.29.165.22',1752414848,'__ci_last_regenerate|i:1752414848;'),('fuqrkvldjr45b568jna5stm3ad0sdhvt','82.29.165.22',1752495425,'__ci_last_regenerate|i:1752495425;'),('g1d587srcln354lm1698odtg0rutts0q','82.29.165.22',1752454386,'__ci_last_regenerate|i:1752454386;'),('g6sjhgn8tqoq37fgqaej7ik4mcug1th2','82.29.165.22',1752473711,'__ci_last_regenerate|i:1752473711;'),('g7daj67gm7mdvsbohofqt09imf3s513h','82.29.165.22',1752487331,'__ci_last_regenerate|i:1752487331;'),('g7pf0egs16v133kfnu4itesc347uk7v3','82.29.165.22',1752523749,'__ci_last_regenerate|i:1752523749;'),('g9o2c3jt8bjju5b8rv7uigo44t4gma5e','82.29.165.22',1752522727,'__ci_last_regenerate|i:1752522727;'),('ga3jln4ecu1tdvk0th72hh3geu8ltb63','82.29.165.22',1752490569,'__ci_last_regenerate|i:1752490569;'),('gb6oioc4pmgg8vl26gdopiij5ombs0q7','82.29.165.22',1752445984,'__ci_last_regenerate|i:1752445984;'),('gfqf0q8gvmt32nnp90j4ae3enp1e2hc6','82.29.165.22',1752513306,'__ci_last_regenerate|i:1752513306;'),('ggj2qjg64bjeke6b6oaoa256i7ie0876','82.29.165.22',1752505214,'__ci_last_regenerate|i:1752505214;'),('gh7bo393agnlpfdesjipmnksp7ctsg6c','82.29.165.22',1752504849,'__ci_last_regenerate|i:1752504849;'),('gkndh0dj2t7ks9ngj56puh6egr35vgm5','82.29.165.22',1752467049,'__ci_last_regenerate|i:1752467049;'),('glhn9mkuv2ljgrg3j17ik219h26rennq','82.29.165.22',1752468848,'__ci_last_regenerate|i:1752468848;'),('gm2q3grejvpi5dpchqrebvjffiaav0tl','82.29.165.22',1752503412,'__ci_last_regenerate|i:1752503412;'),('gnl4vq8j32i8e9ib19bbv223stm91vh5','82.29.165.22',1752522364,'__ci_last_regenerate|i:1752522364;'),('gs0k4lqokcng1gs08giu915u1jaabrpj','82.29.165.22',1752472986,'__ci_last_regenerate|i:1752472986;'),('h0f4dqasphrs3crs8hesggnp8ukigbrt','82.29.165.22',1752457508,'__ci_last_regenerate|i:1752457508;'),('h251herhskomh1g7jaceovj81fff7mu5','82.29.165.22',1752495128,'__ci_last_regenerate|i:1752495128;'),('h4hsgmt5pj0ep7q02pka435vf8lhihfq','82.29.165.22',1752421388,'__ci_last_regenerate|i:1752421388;'),('hc1k18kasitb6lkhf7k10v5ntahk3emq','82.29.165.22',1752481449,'__ci_last_regenerate|i:1752481449;'),('hf49q500o19pu84jmu8lap4ikipvgacn','82.29.165.22',1752473353,'__ci_last_regenerate|i:1752473353;'),('hikkcq61d85ajp2l0got8dj1hmge551t','82.29.165.22',1752439627,'__ci_last_regenerate|i:1752439627;'),('hpjub88h15if8dbef85iv96jg42tjkqu','82.29.165.22',1752467413,'__ci_last_regenerate|i:1752467413;'),('htj0efj531bfk818pe9fb9patc7fss5n','82.29.165.22',1752511928,'__ci_last_regenerate|i:1752511928;'),('htmt6i1hgha7u7heovt3kven6gll00v5','82.29.165.22',1752468128,'__ci_last_regenerate|i:1752468128;'),('htuv85c2ruetpdvouu5044ukqn9sp3ku','82.29.165.22',1752464948,'__ci_last_regenerate|i:1752464948;'),('huaoc57fti6v3ie2feasin3gd52ci2qc','82.29.165.22',1752436507,'__ci_last_regenerate|i:1752436507;'),('hukm8jll056q0svmdno3g9tj7sstd9tt','82.29.165.22',1752478215,'__ci_last_regenerate|i:1752478215;'),('i0iueanfc06al0iirddtpr4o2ubp44vr','82.29.165.22',1752477849,'__ci_last_regenerate|i:1752477849;'),('i13ntbk7d6khom08bujvj19lvovfm35r','82.29.165.22',1752415506,'__ci_last_regenerate|i:1752415506;'),('i2eup0ousictrthmbmssb9ti6dvdjcd8','82.29.165.22',1752458950,'__ci_last_regenerate|i:1752458950;'),('i3tg8macrr5a8jhe8nc4pqj5p2g7mt9o','82.29.165.22',1752481089,'__ci_last_regenerate|i:1752481089;'),('i4cc811avisd3m01nioe7ugp82up4ta5','82.29.165.22',1752451927,'__ci_last_regenerate|i:1752451927;'),('i4ni0p8rf1d24shjgc35uf3cl6f6snuj','82.29.165.22',1752462487,'__ci_last_regenerate|i:1752462487;'),('i7sgmcic850et4i163sl285a3l82e2gp','82.29.165.22',1752436147,'__ci_last_regenerate|i:1752436147;'),('i8d1ctrpcc0pmui3s0m8f4bf2gsv8bkt','82.29.165.22',1752510189,'__ci_last_regenerate|i:1752510189;'),('i8rboil48surtndbabr39gcubcm2m897','82.29.165.22',1752519905,'__ci_last_regenerate|i:1752519905;'),('i98kuu42vsgeqjie36mvc0bpmqh28qkj','82.29.165.22',1752488769,'__ci_last_regenerate|i:1752488769;'),('idsdc5g63mf3553do8smr2r39ucvdg59','82.29.165.22',1752499565,'__ci_last_regenerate|i:1752499565;'),('ioor4lm1j0aiagfjp1lkb1tgnful9ari','82.29.165.22',1752523086,'__ci_last_regenerate|i:1752523086;'),('iphcnsits13s0qlfb796es2i7ii8mil1','82.29.165.22',1752433268,'__ci_last_regenerate|i:1752433268;'),('itudms2vk5gkdneec5t8b8u8hov2o9nb','82.29.165.22',1752475812,'__ci_last_regenerate|i:1752475812;'),('j3evq1gc7qob3hqbabqld8ulj6bkdl8p','82.29.165.22',1752441427,'__ci_last_regenerate|i:1752441427;'),('j3gug6fev3sjq9p8cu45n4ih23vhcbrm','82.29.165.22',1752449107,'__ci_last_regenerate|i:1752449107;'),('j3sutklqnadq27prnvfhr2ud5t08baib','82.29.165.22',1752477486,'__ci_last_regenerate|i:1752477486;'),('j3vvmc65dltmbppukr8ble0td12b6hvc','82.29.165.22',1752493689,'__ci_last_regenerate|i:1752493689;'),('j7utogb1t62luulffuv7b4fn40a9j1c4','82.29.165.22',1752490212,'__ci_last_regenerate|i:1752490212;'),('j9s97dmddoq78o585oo8qkagohetrvqh','82.29.165.22',1752464585,'__ci_last_regenerate|i:1752464585;'),('jcobjuik3l7cu2fpf5s7tm4ph81hufe1','82.29.165.22',1752522067,'__ci_last_regenerate|i:1752522067;'),('je74b50911chh8d7j5ggal9qgatcsnpj','82.29.165.22',1752496148,'__ci_last_regenerate|i:1752496148;'),('jh2f2tjlltepr25lbleamv4sos6f91u5','82.29.165.22',1752454026,'__ci_last_regenerate|i:1752454026;'),('jinhfp095ti4r5lnksevmiomddrmijar','82.29.165.22',1752427389,'__ci_last_regenerate|i:1752427389;'),('jklfuue3u34trm30ejdt9cjlou3m9c3e','82.29.165.22',1752426309,'__ci_last_regenerate|i:1752426309;'),('jqa0plbc1su3e5g5t507k6l10sm0om4o','82.29.165.22',1752471311,'__ci_last_regenerate|i:1752471311;'),('jvp404s0ai7q89iipv90qcbe7666hpco','82.29.165.22',1752493330,'__ci_last_regenerate|i:1752493330;'),('k0pl2qn9khtetgj92444u0e9tfnuu988','82.29.165.22',1752440707,'__ci_last_regenerate|i:1752440707;'),('k2oiisgjur8vhtj1ptg7f2pog4opni8u','82.29.165.22',1752474729,'__ci_last_regenerate|i:1752474729;'),('k2v67t7b4uab89e48b9gt0eds27qru1s','82.29.165.22',1752466688,'__ci_last_regenerate|i:1752466688;'),('k6q412cncvpr7r4qi99m61ctftcrdscr','82.29.165.22',1752459668,'__ci_last_regenerate|i:1752459668;'),('kbavqtjch39cpdkpjite7vhci02g6udv','82.29.165.22',1752514388,'__ci_last_regenerate|i:1752514387;'),('kcfpe4qb5vgpmosrvsbu4i3bfvjo50kp','82.29.165.22',1752482169,'__ci_last_regenerate|i:1752482169;'),('kdtkr7ds0u25srb7nl7377i4b4t0nja6','82.29.165.22',1752500648,'__ci_last_regenerate|i:1752500648;'),('km8ue8oeoq4ln815u75k4atpg765768c','82.29.165.22',1752462848,'__ci_last_regenerate|i:1752462848;'),('knv8r99vq7211n687in4vgbpbqae0l0v','82.29.165.22',1752501968,'__ci_last_regenerate|i:1752501968;'),('krsp84o0ht2633cpa4l5j6crj00n49gf','82.29.165.22',1752470949,'__ci_last_regenerate|i:1752470949;'),('ksfjogpbpe622s59439tqfp332r4jrp9','82.29.165.22',1752445026,'__ci_last_regenerate|i:1752445026;'),('kv85b7htortgkstkgactm3e9ok4td81t','82.29.165.22',1752491588,'__ci_last_regenerate|i:1752491588;'),('l1ius8o99dpl8hvt0i4at5650og9gq4v','82.29.165.22',1752416227,'__ci_last_regenerate|i:1752416227;'),('l3nj1dietptpk0el2bl6s2ahf3b7rnoc','82.29.165.22',1752429428,'__ci_last_regenerate|i:1752429427;'),('l4a3t44k7rcfr91ftci8b755i7dveaev','82.29.165.22',1752413412,'__ci_last_regenerate|i:1752413412;'),('l8qsjhsu7ct8kils8j7sk0jq9v1thoup','82.29.165.22',1752443227,'__ci_last_regenerate|i:1752443227;'),('lbgob0g6gr1duc3sa3ja352c12vrrh38','82.29.165.22',1752497466,'__ci_last_regenerate|i:1752497466;'),('lc7u52i2a23cneh4cq7cqg3a2a7pa23e','82.29.165.22',1752452287,'__ci_last_regenerate|i:1752452287;'),('letmms896d34ng8ui8ofrgn001n1o724','82.29.165.22',1752447067,'__ci_last_regenerate|i:1752447067;'),('lfpuqn8oojkab3jk2ifkibq1josrfpot','82.29.165.22',1752416587,'__ci_last_regenerate|i:1752416587;'),('lg275a2snoube9o4osh6mnm2ucej7mh0','82.29.165.22',1752498188,'__ci_last_regenerate|i:1752498188;'),('li42anvcad6n88a0i59vht9597e4tg5b','82.29.165.22',1752477189,'__ci_last_regenerate|i:1752477189;'),('lkhfgba8c89f954lgspe3iqph98o1j6q','82.29.165.22',1752472325,'__ci_last_regenerate|i:1752472325;'),('ll0q47po3tmc3ca14la2232lcenfmv77','82.29.165.22',1752448446,'__ci_last_regenerate|i:1752448446;'),('llgcb5a3r418ke03m9uppnacvhccbvu1','82.29.165.22',1752451562,'__ci_last_regenerate|i:1752451562;'),('ltuurvn04v8kh0idat2mddba75ca9kdf','82.29.165.22',1752501009,'__ci_last_regenerate|i:1752501009;'),('lv7sv0p24c69nau1kqukjd49lc8svqff','82.29.165.22',1752494420,'__ci_last_regenerate|i:1752494420;'),('m1mvjqc84ka8n26diaufmvi84nsgvu1e','82.29.165.22',1752423189,'__ci_last_regenerate|i:1752423189;'),('m7rkrv87lg1tpl6t3o54gshi2m8hnffp','82.29.165.22',1752434708,'__ci_last_regenerate|i:1752434708;'),('magl26nqufbs15laao3fq8vju6jm804n','82.29.165.22',1752424929,'__ci_last_regenerate|i:1752424929;'),('mbrg27j287hhk400te0ikjljabralkqn','82.29.165.22',1752479649,'__ci_last_regenerate|i:1752479649;'),('mcnbgt81gcsuec3qmd8i42oi4ccd0pee','82.29.165.22',1752469869,'__ci_last_regenerate|i:1752469869;'),('mn5g38j6faoi1t30218g02gng5pdfmnb','82.29.165.22',1752448086,'__ci_last_regenerate|i:1752448086;'),('mnsfurd0r8l2h78friibudgdjgdedcra','82.29.165.22',1752428350,'__ci_last_regenerate|i:1752428350;'),('mp3odoalfupms7mlfu4udambl5ipkvtn','82.29.165.22',1752458588,'__ci_last_regenerate|i:1752458588;'),('n1kua2diqmd0hk8lpunqgk5goq19gs2j','82.29.165.22',1752420369,'__ci_last_regenerate|i:1752420369;'),('n4musr0fhu3uh8hqn98pndjfcn02ibg4','82.29.165.22',1752420006,'__ci_last_regenerate|i:1752420006;'),('n82popjf334gqik7qs0k0ee6moopcc8j','82.29.165.22',1752480370,'__ci_last_regenerate|i:1752480370;'),('nb0b3u7sk05gpsmc2badu8iof9ibjbo8','82.29.165.22',1752422108,'__ci_last_regenerate|i:1752422108;'),('nlqato1rhje215tl3de8jgeed40eqm2m','82.29.165.22',1752425226,'__ci_last_regenerate|i:1752425226;'),('nlu87q3j52ubfuf6023pfp49t39gg72m','106.219.231.124',1752413398,'__ci_last_regenerate|i:1752413397;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";'),('ntdupic9v81s37ivh83aslat9m9dbipo','82.29.165.22',1752484990,'__ci_last_regenerate|i:1752484990;'),('o56jboe73bgcbt1gicl7hkagfkm3bfnl','82.29.165.22',1752525127,'__ci_last_regenerate|i:1752525127;'),('o5qcnd5pdr8rdh6llaakks1mfmjcdsh7','82.29.165.22',1752455405,'__ci_last_regenerate|i:1752455405;'),('o6hkoiugpe94rbcdsn2un2oh955adpp0','82.29.165.22',1752448744,'__ci_last_regenerate|i:1752448744;'),('o81vuootdcasqdo6aovjlelukpkfqq7t','82.29.165.22',1752485286,'__ci_last_regenerate|i:1752485285;'),('oim21n893uj6qof488obb3q20pm8g3q0','82.29.165.22',1752511268,'__ci_last_regenerate|i:1752511268;'),('ojrgvjohesad0ab8igh7p5jd3gtpudu3','82.29.165.22',1752479289,'__ci_last_regenerate|i:1752479289;'),('okl21tf3i277po2gldu498qvmtoa16kf','82.29.165.22',1752476169,'__ci_last_regenerate|i:1752476169;'),('oklge45le0n4q44ksccsgdhcf6sh6tqb','82.29.165.22',1752492251,'__ci_last_regenerate|i:1752492251;'),('okm9llv9vvgilcsgil9mtssfpk566k0f','82.29.165.22',1752503768,'__ci_last_regenerate|i:1752503768;'),('opngg20509vd8hbmsqm6h8cmepabsq45','82.29.165.22',1752435427,'__ci_last_regenerate|i:1752435427;'),('or2vibvp4jhrkc72fd7q0qv0hfdahlqo','82.29.165.22',1752496806,'__ci_last_regenerate|i:1752496806;'),('orubsvu3mdb12tcn311qdaft2etd9b3c','82.29.165.22',1752504488,'__ci_last_regenerate|i:1752504488;'),('ostjkubrpr483bunaabvbi81623kuc1j','82.29.165.22',1752460028,'__ci_last_regenerate|i:1752460028;'),('otu958g2k5bh8vuvfprd2kbloeo5h4gf','82.29.165.22',1752504128,'__ci_last_regenerate|i:1752504128;'),('ovcnviv420gaf14fiv9g1geoat4ue8db','82.29.165.22',1752430150,'__ci_last_regenerate|i:1752430150;'),('p17jih1c5rmjjt8kljpa17o14vtgens5','82.29.165.22',1752417909,'__ci_last_regenerate|i:1752417909;'),('p27cjntqh4u165s4pvke1511g4sd4n0a','82.29.165.22',1752442147,'__ci_last_regenerate|i:1752442146;'),('p3fvrt0pu82baknce8ngjpog70c1mkvm','82.29.165.22',1752518888,'__ci_last_regenerate|i:1752518888;'),('p4nghubti2jo8lnu4ot6sbccdljj4162','82.29.165.22',1752433627,'__ci_last_regenerate|i:1752433627;'),('p8e640sqrft2vu57r8l71j9ekb45j034','82.29.165.22',1752422827,'__ci_last_regenerate|i:1752422827;'),('p8lfhf7p97rlqohvmqeq8ej48ilsial9','82.29.165.22',1752427028,'__ci_last_regenerate|i:1752427028;'),('paq4aph8g6at345c6teslnl47m21p50n','82.29.165.22',1752509168,'__ci_last_regenerate|i:1752509168;'),('pd64b3l7s18g4oq0a93hpcah53felm02','82.29.165.22',1752508449,'__ci_last_regenerate|i:1752508449;'),('plu0mu7oo3k0skk9908erikt10c81f4k','82.29.165.22',1752515768,'__ci_last_regenerate|i:1752515768;'),('pnf9as0jdkncolag4ejg3u5995vrotlf','82.29.165.22',1752489130,'__ci_last_regenerate|i:1752489130;'),('ppq1c7ge2s9mq991a0k9uprcpbhggq4t','82.29.165.22',1752445324,'__ci_last_regenerate|i:1752445324;'),('pvchemfso0k51abqnl4nnf10ojus7u9k','82.29.165.22',1752445687,'__ci_last_regenerate|i:1752445687;'),('pvq2e4b0467uhl1qu5bh2304cfema3lt','82.29.165.22',1752463928,'__ci_last_regenerate|i:1752463928;'),('q0bbi5qddm3dsnh11ikidqsd48p70mco','82.29.165.22',1752421082,'__ci_last_regenerate|i:1752421082;'),('q1jcei2nmge223g916ot8rpq3froap37','82.29.165.22',1752437166,'__ci_last_regenerate|i:1752437166;'),('q2emdt7uchedahs1mu2k76mo8gdgno8j','82.29.165.22',1752480018,'__ci_last_regenerate|i:1752480018;'),('q48rims3gth95umbi14fvoinro80dbqv','82.29.165.22',1752485649,'__ci_last_regenerate|i:1752485649;'),('q4ld6c7ijpnbuavg8jid79ido2ab8mlj','82.29.165.22',1752505928,'__ci_last_regenerate|i:1752505928;'),('q7amdpqk86kv402mb6t7t8if2tka7491','82.29.165.22',1752465309,'__ci_last_regenerate|i:1752465309;'),('qcncfg7fp3ei7c3qd7rs2n57d781c5r9','82.29.165.22',1752461767,'__ci_last_regenerate|i:1752461767;'),('qd4a4t8vdv8o51qn05pcl6kkq4k0q11k','82.29.165.22',1752487689,'__ci_last_regenerate|i:1752487689;'),('qel8krlchra1p8kvhckrggh30akqsjld','82.29.165.22',1752466328,'__ci_last_regenerate|i:1752466328;'),('qlu6glel1pabqo4v0f4uhsebgpmvl45c','82.29.165.22',1752438908,'__ci_last_regenerate|i:1752438907;'),('qr2r5clsjp31ji8ln3e41dtmeivnso21','82.29.165.22',1752508089,'__ci_last_regenerate|i:1752508089;'),('qs2urgo7q176bljgedc5v1l3141836q2','82.29.165.22',1752469213,'__ci_last_regenerate|i:1752469213;'),('qvih38ogokotjkagb12mco702jnf0jdo','82.29.165.22',1752442507,'__ci_last_regenerate|i:1752442507;'),('r221888jtj19pmihr9fe5qkefb5cpeaq','82.29.165.22',1752416947,'__ci_last_regenerate|i:1752416947;'),('r4cn744bfvdi9g01s24fpbmdpi09t957','82.29.165.22',1752481818,'__ci_last_regenerate|i:1752481818;'),('r4n6p13e7hske78q8olbkeoh4rb56h87','82.29.165.22',1752510548,'__ci_last_regenerate|i:1752510548;'),('r7iin4f2dvb71uqdtn6lvug9eph949ba','82.29.165.22',1752452945,'__ci_last_regenerate|i:1752452944;'),('r8dh0899dc66gbgdobgl3d3s4l4393eb','82.29.165.22',1752484630,'__ci_last_regenerate|i:1752484630;'),('r8qkia6vgoppj87gcj8c0lkkht3psqvo','82.29.165.22',1752443946,'__ci_last_regenerate|i:1752443946;'),('rf3rg5j1igjr7f3e4439m71mjn6kk8ao','82.29.165.22',1752418270,'__ci_last_regenerate|i:1752418270;'),('rg75r3vtklpopu0g0srv0r46lvsfqbk9','82.29.165.22',1752468489,'__ci_last_regenerate|i:1752468488;'),('rk5eal889qnoc3ah86qobg3u476mbhp5','82.29.165.22',1752502688,'__ci_last_regenerate|i:1752502688;'),('rkiiop65ocqolqv05jkpbic02pmcn055','82.29.165.22',1752469505,'__ci_last_regenerate|i:1752469505;'),('rlkj486edjaoqv8b0fbmur3elb0ru9sm','82.29.165.22',1752507368,'__ci_last_regenerate|i:1752507368;'),('rvjq1p7p2ibjqpun1gf9gsv1sfkuusvj','82.29.165.22',1752431887,'__ci_last_regenerate|i:1752431887;'),('s089sjati4mk4gctosbuuai34jt0ksct','82.29.165.22',1752514684,'__ci_last_regenerate|i:1752514684;'),('s8m4hai0i3dnsm0htanb0qbu02j17onp','82.29.165.22',1752453307,'__ci_last_regenerate|i:1752453307;'),('sbd07juk86qluh4drttvdm3cpi41i1ml','82.29.165.22',1752449766,'__ci_last_regenerate|i:1752449766;'),('so0g773k16iqje0vbc3qhlg6ommi61i4','82.29.165.22',1752507731,'__ci_last_regenerate|i:1752507731;'),('t06su69g2cq3fdnfiptm0ur5pfigrb2h','82.29.165.22',1752471671,'__ci_last_regenerate|i:1752471671;'),('t2ionhis4ttgb6lksg0hrti9fle56o5s','82.29.165.22',1752423850,'__ci_last_regenerate|i:1752423850;'),('t5roit5uub1hk4a3fcijg95oignls5nm','82.29.165.22',1752486969,'__ci_last_regenerate|i:1752486969;'),('t72mmgjhphk03t0st21qetp873ohmd7b','82.29.165.22',1752424569,'__ci_last_regenerate|i:1752424569;'),('t9jjps134t5051mb06aqkb3u3en47431','82.29.165.22',1752415867,'__ci_last_regenerate|i:1752415867;'),('te96slsfcmbi5jpu6n9ei0vk69j4ah32','82.29.165.22',1752427685,'__ci_last_regenerate|i:1752427685;'),('tf7vag12ch4lgm5h4bf295eos8frd2a1','82.29.165.22',1752421747,'__ci_last_regenerate|i:1752421747;'),('thl7g693danrlq5d2nqu6rmupam8sksj','82.29.165.22',1752429788,'__ci_last_regenerate|i:1752429788;'),('tkcgj4m3jrobhq5mr5ai6tk6hk27k44t','82.29.165.22',1752494049,'__ci_last_regenerate|i:1752494049;'),('tlqlbae4ifjomsjuasjrflbrvh6e5jmt','82.29.165.22',1752474370,'__ci_last_regenerate|i:1752474370;'),('tm52jamajjrja0u9lbjqbi6sl7sf6a2q','106.219.231.124',1752413396,'__ci_last_regenerate|i:1752413396;'),('trqbk4lrtrqq07mb919ps33linuvv715','82.29.165.22',1752492968,'__ci_last_regenerate|i:1752492968;'),('u05kvela9oh5toen972799c852p5sbd2','82.29.165.22',1752521347,'__ci_last_regenerate|i:1752521347;'),('u20ipgjtq4hij4l8vhgvcf81cb50gesu','82.29.165.22',1752465967,'__ci_last_regenerate|i:1752465967;'),('u40lusf7cum6fouc7c8ladc1nnjmre7p','82.29.165.22',1752498550,'__ci_last_regenerate|i:1752498550;'),('up2kbe2ghluj38vjtcasqksec1j0epq8','82.29.165.22',1752515048,'__ci_last_regenerate|i:1752515048;'),('us0qm1br1efoqtm754bs7bkvki5qgsp4','82.29.165.22',1752430509,'__ci_last_regenerate|i:1752430508;'),('us2lnk6m3kcuo66fpner8niva1f2ij9d','82.29.165.22',1752470588,'__ci_last_regenerate|i:1752470588;'),('usq2tso8h45527hdi723vv27v8e62qo7','82.29.165.22',1752449405,'__ci_last_regenerate|i:1752449405;'),('ut23t5q0rqrnm3n3fcvvta1c5vsengko','82.29.165.22',1752483911,'__ci_last_regenerate|i:1752483911;'),('v52aqtr7j8tjnea01jkfjk7cdvug51h4','82.29.165.22',1752480730,'__ci_last_regenerate|i:1752480730;'),('v88afe1q29ua4cfu19fejf34ah127tn7','82.29.165.22',1752486606,'__ci_last_regenerate|i:1752486606;'),('v8jblndo843r65s103ltj1873bda2gn6','82.29.165.22',1752519614,'__ci_last_regenerate|i:1752519614;'),('v9lmsnopse082tnbjd04duiifcejiff2','82.29.165.22',1752454746,'__ci_last_regenerate|i:1752454746;'),('vt3ao6u9leo4da7ghte5g274e0pgosm1','82.29.165.22',1752460688,'__ci_last_regenerate|i:1752460688;'),('vu0pt9l8is7ccnue4uoe90fdjoibdltj','82.29.165.22',1752455107,'__ci_last_regenerate|i:1752455107;'),('vvpsg2je99r71e3q0901ovnvga2a1te1','82.29.165.22',1752516487,'__ci_last_regenerate|i:1752516487;');
/*!40000 ALTER TABLE `maxlife_tblsessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblshared_customer_files`
--

DROP TABLE IF EXISTS `maxlife_tblshared_customer_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblshared_customer_files` (
  `file_id` int(11) NOT NULL,
  `contact_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblshared_customer_files`
--

LOCK TABLES `maxlife_tblshared_customer_files` WRITE;
/*!40000 ALTER TABLE `maxlife_tblshared_customer_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblshared_customer_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblshift_type`
--

DROP TABLE IF EXISTS `maxlife_tblshift_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblshift_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shift_type_name` varchar(150) DEFAULT NULL,
  `color` varchar(50) DEFAULT NULL,
  `time_start` date DEFAULT NULL,
  `time_end` date DEFAULT NULL,
  `time_start_work` varchar(50) DEFAULT NULL,
  `time_end_work` varchar(50) DEFAULT NULL,
  `start_lunch_break_time` varchar(50) DEFAULT NULL,
  `end_lunch_break_time` varchar(50) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblshift_type`
--

LOCK TABLES `maxlife_tblshift_type` WRITE;
/*!40000 ALTER TABLE `maxlife_tblshift_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblshift_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblsi_custom_status`
--

DROP TABLE IF EXISTS `maxlife_tblsi_custom_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblsi_custom_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '',
  `order` int(11) NOT NULL DEFAULT 0,
  `color` varchar(7) NOT NULL DEFAULT '#757575',
  `filter_default` int(11) NOT NULL DEFAULT 0,
  `relto` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=200 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblsi_custom_status`
--

LOCK TABLES `maxlife_tblsi_custom_status` WRITE;
/*!40000 ALTER TABLE `maxlife_tblsi_custom_status` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblsi_custom_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblsi_custom_status_default`
--

DROP TABLE IF EXISTS `maxlife_tblsi_custom_status_default`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblsi_custom_status_default` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status_id` int(11) NOT NULL DEFAULT 0,
  `name` varchar(50) NOT NULL DEFAULT '',
  `order` int(11) NOT NULL DEFAULT 0,
  `color` varchar(7) NOT NULL DEFAULT '#757575',
  `filter_default` int(11) NOT NULL DEFAULT 0,
  `active` int(11) NOT NULL DEFAULT 1,
  `relto` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblsi_custom_status_default`
--

LOCK TABLES `maxlife_tblsi_custom_status_default` WRITE;
/*!40000 ALTER TABLE `maxlife_tblsi_custom_status_default` DISABLE KEYS */;
INSERT INTO `maxlife_tblsi_custom_status_default` VALUES (1,1,'',1,'#64748b',1,1,'tasks'),(2,2,'',4,'#84cc16',1,1,'tasks'),(3,3,'',3,'#0284c7',1,1,'tasks'),(4,4,'',2,'#3b82f6',1,1,'tasks'),(5,5,'',100,'#22c55e',0,1,'tasks'),(6,1,'',1,'#475569',1,1,'projects'),(7,2,'',2,'#2563eb',1,1,'projects'),(8,3,'',3,'#f97316',1,1,'projects'),(9,4,'',100,'#16a34a',0,1,'projects'),(10,5,'',4,'#94a3b8',0,1,'projects');
/*!40000 ALTER TABLE `maxlife_tblsi_custom_status_default` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblsi_lead_followup_schedule`
--

DROP TABLE IF EXISTS `maxlife_tblsi_lead_followup_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblsi_lead_followup_schedule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `source` int(11) NOT NULL DEFAULT 0,
  `filter_by` varchar(25) NOT NULL,
  `content` text NOT NULL,
  `dlt_template_id_key` varchar(100) NOT NULL DEFAULT '',
  `dlt_template_id_value` varchar(100) NOT NULL DEFAULT '',
  `staff_id` int(11) NOT NULL DEFAULT 0,
  `schedule_days` int(11) NOT NULL DEFAULT 1,
  `schedule_hour` int(11) NOT NULL DEFAULT 12,
  `last_executed` datetime DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `staff_id` (`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblsi_lead_followup_schedule`
--

LOCK TABLES `maxlife_tblsi_lead_followup_schedule` WRITE;
/*!40000 ALTER TABLE `maxlife_tblsi_lead_followup_schedule` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblsi_lead_followup_schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblsi_lead_followup_schedule_rel`
--

DROP TABLE IF EXISTS `maxlife_tblsi_lead_followup_schedule_rel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblsi_lead_followup_schedule_rel` (
  `schedule_id` int(11) NOT NULL DEFAULT 0,
  `rel_id` int(11) NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  KEY `schedule_id` (`schedule_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblsi_lead_followup_schedule_rel`
--

LOCK TABLES `maxlife_tblsi_lead_followup_schedule_rel` WRITE;
/*!40000 ALTER TABLE `maxlife_tblsi_lead_followup_schedule_rel` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblsi_lead_followup_schedule_rel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblspam_filters`
--

DROP TABLE IF EXISTS `maxlife_tblspam_filters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblspam_filters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(40) NOT NULL,
  `rel_type` varchar(10) NOT NULL,
  `value` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblspam_filters`
--

LOCK TABLES `maxlife_tblspam_filters` WRITE;
/*!40000 ALTER TABLE `maxlife_tblspam_filters` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblspam_filters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblstaff`
--

DROP TABLE IF EXISTS `maxlife_tblstaff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblstaff` (
  `staffid` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `facebook` longtext DEFAULT NULL,
  `linkedin` longtext DEFAULT NULL,
  `phonenumber` varchar(30) DEFAULT NULL,
  `skype` varchar(50) DEFAULT NULL,
  `password` varchar(250) NOT NULL,
  `datecreated` datetime NOT NULL,
  `profile_image` varchar(191) DEFAULT NULL,
  `last_ip` varchar(40) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_activity` datetime DEFAULT NULL,
  `last_password_change` datetime DEFAULT NULL,
  `new_pass_key` varchar(32) DEFAULT NULL,
  `new_pass_key_requested` datetime DEFAULT NULL,
  `admin` int(11) NOT NULL DEFAULT 0,
  `role` int(11) DEFAULT NULL,
  `active` int(11) NOT NULL DEFAULT 1,
  `default_language` varchar(40) DEFAULT NULL,
  `direction` varchar(3) DEFAULT NULL,
  `media_path_slug` varchar(191) DEFAULT NULL,
  `is_not_staff` int(11) NOT NULL DEFAULT 0,
  `hourly_rate` decimal(15,2) NOT NULL DEFAULT 0.00,
  `two_factor_auth_enabled` tinyint(1) DEFAULT 0,
  `two_factor_auth_code` varchar(100) DEFAULT NULL,
  `two_factor_auth_code_requested` datetime DEFAULT NULL,
  `email_signature` mediumtext DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `birthplace` varchar(200) DEFAULT NULL,
  `sex` varchar(15) DEFAULT NULL,
  `marital_status` varchar(25) DEFAULT NULL,
  `nation` varchar(25) DEFAULT NULL,
  `religion` varchar(50) DEFAULT NULL,
  `identification` varchar(100) DEFAULT NULL,
  `days_for_identity` date DEFAULT NULL,
  `home_town` varchar(200) DEFAULT NULL,
  `resident` varchar(200) DEFAULT NULL,
  `current_address` varchar(200) DEFAULT NULL,
  `literacy` varchar(50) DEFAULT NULL,
  `orther_infor` text DEFAULT NULL,
  `job_position` int(11) DEFAULT NULL,
  `workplace` int(11) DEFAULT NULL,
  `place_of_issue` varchar(50) DEFAULT NULL,
  `account_number` varchar(50) DEFAULT NULL,
  `name_account` varchar(50) DEFAULT NULL,
  `issue_bank` varchar(200) DEFAULT NULL,
  `records_received` longtext DEFAULT NULL,
  `Personal_tax_code` varchar(50) DEFAULT NULL,
  `google_auth_secret` mediumtext DEFAULT NULL,
  `team_manage` int(11) DEFAULT 0,
  `staff_identifi` varchar(200) DEFAULT NULL,
  `status_work` varchar(100) DEFAULT NULL,
  `date_update` date DEFAULT NULL,
  `epf_no` text DEFAULT NULL,
  `social_security_no` text DEFAULT NULL,
  `mail_password` varchar(250) DEFAULT NULL,
  `mail_signature` varchar(250) DEFAULT NULL,
  `last_email_check` varchar(50) DEFAULT NULL,
  `token` varchar(255) DEFAULT NULL,
  `date_of_joining` date DEFAULT NULL,
  `pan_no` varchar(20) DEFAULT NULL,
  `uan_no` varchar(20) DEFAULT NULL,
  `mother_name` varchar(100) DEFAULT NULL,
  `father_name` varchar(100) DEFAULT NULL,
  `ho_wo_name` varchar(100) DEFAULT NULL,
  `ifsc_code` varchar(20) DEFAULT NULL,
  `account_type` varchar(50) DEFAULT NULL,
  `disability_type` varchar(100) DEFAULT NULL,
  `adhar_no` varchar(20) DEFAULT NULL,
  `esi_insurance_no` varchar(20) DEFAULT NULL,
  `esi_enable` tinyint(1) DEFAULT 0,
  `epf_enable` tinyint(1) DEFAULT 0,
  `enable_contribute_to_employee_pension_scheme` tinyint(1) DEFAULT 0,
  `contribute_eps_on_actual_pf_wages` tinyint(1) DEFAULT 0,
  `mfa_google_ath_enable` tinyint(1) DEFAULT 0,
  `mfa_whatsapp_enable` tinyint(1) DEFAULT 0,
  `mfa_sms_enable` tinyint(1) DEFAULT 0,
  `whatsapp_number` text DEFAULT '',
  `gg_auth_secret_key` text DEFAULT '',
  PRIMARY KEY (`staffid`),
  KEY `firstname` (`firstname`),
  KEY `lastname` (`lastname`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblstaff`
--

LOCK TABLES `maxlife_tblstaff` WRITE;
/*!40000 ALTER TABLE `maxlife_tblstaff` DISABLE KEYS */;
INSERT INTO `maxlife_tblstaff` VALUES (1,'kmayesha1505@gmail.com','Ayesha','Ayesha',NULL,NULL,'+919266417305',NULL,'$2a$08$pKine/rVN9o6wJVU9yv8F.rfTLfboz6uKYR7rBAiCYMsDOvqcd3Py','2025-07-13 18:59:46',NULL,'106.219.231.124','2025-07-13 18:59:57','2025-07-13 18:59:58',NULL,NULL,NULL,1,NULL,1,NULL,NULL,NULL,0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,0,0,'','');
/*!40000 ALTER TABLE `maxlife_tblstaff` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblstaff_departments`
--

DROP TABLE IF EXISTS `maxlife_tblstaff_departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblstaff_departments` (
  `staffdepartmentid` int(11) NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `departmentid` int(11) NOT NULL,
  PRIMARY KEY (`staffdepartmentid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblstaff_departments`
--

LOCK TABLES `maxlife_tblstaff_departments` WRITE;
/*!40000 ALTER TABLE `maxlife_tblstaff_departments` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblstaff_departments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblstaff_permissions`
--

DROP TABLE IF EXISTS `maxlife_tblstaff_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblstaff_permissions` (
  `staff_id` int(11) NOT NULL,
  `feature` varchar(40) NOT NULL,
  `capability` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblstaff_permissions`
--

LOCK TABLES `maxlife_tblstaff_permissions` WRITE;
/*!40000 ALTER TABLE `maxlife_tblstaff_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblstaff_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblstandard_workload`
--

DROP TABLE IF EXISTS `maxlife_tblstandard_workload`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblstandard_workload` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `monday` varchar(45) DEFAULT NULL,
  `tuesday` varchar(45) DEFAULT NULL,
  `wednesday` varchar(45) DEFAULT NULL,
  `thursday` varchar(45) DEFAULT NULL,
  `friday` varchar(45) DEFAULT NULL,
  `saturday` varchar(45) DEFAULT NULL,
  `sunday` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblstandard_workload`
--

LOCK TABLES `maxlife_tblstandard_workload` WRITE;
/*!40000 ALTER TABLE `maxlife_tblstandard_workload` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblstandard_workload` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblsubscriptions`
--

DROP TABLE IF EXISTS `maxlife_tblsubscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblsubscriptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `description_in_item` tinyint(1) NOT NULL DEFAULT 0,
  `clientid` int(11) NOT NULL,
  `date` date DEFAULT NULL,
  `terms` mediumtext DEFAULT NULL,
  `currency` int(11) NOT NULL,
  `tax_id` int(11) NOT NULL DEFAULT 0,
  `stripe_tax_id` varchar(50) DEFAULT NULL,
  `tax_id_2` int(11) NOT NULL DEFAULT 0,
  `stripe_tax_id_2` varchar(50) DEFAULT NULL,
  `stripe_plan_id` mediumtext DEFAULT NULL,
  `stripe_subscription_id` mediumtext NOT NULL,
  `next_billing_cycle` bigint(20) DEFAULT NULL,
  `ends_at` bigint(20) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `project_id` int(11) NOT NULL DEFAULT 0,
  `hash` varchar(32) NOT NULL,
  `created` datetime NOT NULL,
  `created_from` int(11) NOT NULL,
  `date_subscribed` datetime DEFAULT NULL,
  `in_test_environment` int(11) DEFAULT NULL,
  `last_sent_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `currency` (`currency`),
  KEY `tax_id` (`tax_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblsubscriptions`
--

LOCK TABLES `maxlife_tblsubscriptions` WRITE;
/*!40000 ALTER TABLE `maxlife_tblsubscriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblsubscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblsurveyresultsets`
--

DROP TABLE IF EXISTS `maxlife_tblsurveyresultsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblsurveyresultsets` (
  `resultsetid` int(11) NOT NULL AUTO_INCREMENT,
  `surveyid` int(11) NOT NULL,
  `ip` varchar(40) NOT NULL,
  `useragent` varchar(150) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`resultsetid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblsurveyresultsets`
--

LOCK TABLES `maxlife_tblsurveyresultsets` WRITE;
/*!40000 ALTER TABLE `maxlife_tblsurveyresultsets` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblsurveyresultsets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblsurveys`
--

DROP TABLE IF EXISTS `maxlife_tblsurveys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblsurveys` (
  `surveyid` int(11) NOT NULL AUTO_INCREMENT,
  `subject` mediumtext NOT NULL,
  `slug` mediumtext NOT NULL,
  `description` text NOT NULL,
  `viewdescription` text DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `redirect_url` varchar(100) DEFAULT NULL,
  `send` tinyint(1) NOT NULL DEFAULT 0,
  `onlyforloggedin` int(11) DEFAULT 0,
  `fromname` varchar(100) DEFAULT NULL,
  `iprestrict` tinyint(1) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `hash` varchar(32) NOT NULL,
  PRIMARY KEY (`surveyid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblsurveys`
--

LOCK TABLES `maxlife_tblsurveys` WRITE;
/*!40000 ALTER TABLE `maxlife_tblsurveys` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblsurveys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblsurveysemailsendcron`
--

DROP TABLE IF EXISTS `maxlife_tblsurveysemailsendcron`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblsurveysemailsendcron` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `surveyid` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `emailid` int(11) DEFAULT NULL,
  `listid` varchar(11) DEFAULT NULL,
  `log_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblsurveysemailsendcron`
--

LOCK TABLES `maxlife_tblsurveysemailsendcron` WRITE;
/*!40000 ALTER TABLE `maxlife_tblsurveysemailsendcron` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblsurveysemailsendcron` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblsurveysendlog`
--

DROP TABLE IF EXISTS `maxlife_tblsurveysendlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblsurveysendlog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `surveyid` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `iscronfinished` int(11) NOT NULL DEFAULT 0,
  `send_to_mail_lists` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblsurveysendlog`
--

LOCK TABLES `maxlife_tblsurveysendlog` WRITE;
/*!40000 ALTER TABLE `maxlife_tblsurveysendlog` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblsurveysendlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tbltaggables`
--

DROP TABLE IF EXISTS `maxlife_tbltaggables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tbltaggables` (
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) NOT NULL,
  `tag_id` int(11) NOT NULL,
  `tag_order` int(11) NOT NULL DEFAULT 0,
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`),
  KEY `tag_id` (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tbltaggables`
--

LOCK TABLES `maxlife_tbltaggables` WRITE;
/*!40000 ALTER TABLE `maxlife_tbltaggables` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tbltaggables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tbltags`
--

DROP TABLE IF EXISTS `maxlife_tbltags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tbltags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tbltags`
--

LOCK TABLES `maxlife_tbltags` WRITE;
/*!40000 ALTER TABLE `maxlife_tbltags` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tbltags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tbltask_assigned`
--

DROP TABLE IF EXISTS `maxlife_tbltask_assigned`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tbltask_assigned` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `taskid` int(11) NOT NULL,
  `assigned_from` int(11) NOT NULL DEFAULT 0,
  `is_assigned_from_contact` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `taskid` (`taskid`),
  KEY `maxlife_staffid` (`staffid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tbltask_assigned`
--

LOCK TABLES `maxlife_tbltask_assigned` WRITE;
/*!40000 ALTER TABLE `maxlife_tbltask_assigned` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tbltask_assigned` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tbltask_checklist_items`
--

DROP TABLE IF EXISTS `maxlife_tbltask_checklist_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tbltask_checklist_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `taskid` int(11) NOT NULL,
  `description` mediumtext NOT NULL,
  `finished` int(11) NOT NULL DEFAULT 0,
  `dateadded` datetime NOT NULL,
  `addedfrom` int(11) NOT NULL,
  `finished_from` int(11) DEFAULT 0,
  `list_order` int(11) NOT NULL DEFAULT 0,
  `assigned` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `taskid` (`taskid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tbltask_checklist_items`
--

LOCK TABLES `maxlife_tbltask_checklist_items` WRITE;
/*!40000 ALTER TABLE `maxlife_tbltask_checklist_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tbltask_checklist_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tbltask_comments`
--

DROP TABLE IF EXISTS `maxlife_tbltask_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tbltask_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` mediumtext NOT NULL,
  `taskid` int(11) NOT NULL,
  `staffid` int(11) NOT NULL,
  `contact_id` int(11) NOT NULL DEFAULT 0,
  `file_id` int(11) NOT NULL DEFAULT 0,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `file_id` (`file_id`),
  KEY `taskid` (`taskid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tbltask_comments`
--

LOCK TABLES `maxlife_tbltask_comments` WRITE;
/*!40000 ALTER TABLE `maxlife_tbltask_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tbltask_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tbltask_followers`
--

DROP TABLE IF EXISTS `maxlife_tbltask_followers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tbltask_followers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `taskid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tbltask_followers`
--

LOCK TABLES `maxlife_tbltask_followers` WRITE;
/*!40000 ALTER TABLE `maxlife_tbltask_followers` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tbltask_followers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tbltasks`
--

DROP TABLE IF EXISTS `maxlife_tbltasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tbltasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  `startdate` date NOT NULL,
  `duedate` date DEFAULT NULL,
  `datefinished` datetime DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `is_added_from_contact` tinyint(1) NOT NULL DEFAULT 0,
  `status` int(11) NOT NULL DEFAULT 0,
  `recurring_type` varchar(10) DEFAULT NULL,
  `repeat_every` int(11) DEFAULT NULL,
  `recurring` int(11) NOT NULL DEFAULT 0,
  `is_recurring_from` int(11) DEFAULT NULL,
  `cycles` int(11) NOT NULL DEFAULT 0,
  `total_cycles` int(11) NOT NULL DEFAULT 0,
  `custom_recurring` tinyint(1) NOT NULL DEFAULT 0,
  `last_recurring_date` date DEFAULT NULL,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(30) DEFAULT NULL,
  `is_public` tinyint(1) NOT NULL DEFAULT 0,
  `billable` tinyint(1) NOT NULL DEFAULT 0,
  `billed` tinyint(1) NOT NULL DEFAULT 0,
  `invoice_id` int(11) NOT NULL DEFAULT 0,
  `hourly_rate` decimal(15,2) NOT NULL DEFAULT 0.00,
  `milestone` int(11) DEFAULT 0,
  `kanban_order` int(11) DEFAULT 1,
  `milestone_order` int(11) NOT NULL DEFAULT 0,
  `visible_to_client` tinyint(1) NOT NULL DEFAULT 0,
  `deadline_notified` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`),
  KEY `milestone` (`milestone`),
  KEY `kanban_order` (`kanban_order`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tbltasks`
--

LOCK TABLES `maxlife_tbltasks` WRITE;
/*!40000 ALTER TABLE `maxlife_tbltasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tbltasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tbltasks_checklist_templates`
--

DROP TABLE IF EXISTS `maxlife_tbltasks_checklist_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tbltasks_checklist_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tbltasks_checklist_templates`
--

LOCK TABLES `maxlife_tbltasks_checklist_templates` WRITE;
/*!40000 ALTER TABLE `maxlife_tbltasks_checklist_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tbltasks_checklist_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tbltaskstimers`
--

DROP TABLE IF EXISTS `maxlife_tbltaskstimers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tbltaskstimers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) NOT NULL,
  `start_time` varchar(64) NOT NULL,
  `end_time` varchar(64) DEFAULT NULL,
  `staff_id` int(11) NOT NULL,
  `hourly_rate` decimal(15,2) NOT NULL DEFAULT 0.00,
  `note` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `task_id` (`task_id`),
  KEY `maxlife_staff_id` (`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tbltaskstimers`
--

LOCK TABLES `maxlife_tbltaskstimers` WRITE;
/*!40000 ALTER TABLE `maxlife_tbltaskstimers` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tbltaskstimers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tbltaxes`
--

DROP TABLE IF EXISTS `maxlife_tbltaxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tbltaxes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `taxrate` decimal(15,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tbltaxes`
--

LOCK TABLES `maxlife_tbltaxes` WRITE;
/*!40000 ALTER TABLE `maxlife_tbltaxes` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tbltaxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tbltemplates`
--

DROP TABLE IF EXISTS `maxlife_tbltemplates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tbltemplates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `type` varchar(100) NOT NULL,
  `addedfrom` int(11) NOT NULL,
  `content` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tbltemplates`
--

LOCK TABLES `maxlife_tbltemplates` WRITE;
/*!40000 ALTER TABLE `maxlife_tbltemplates` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tbltemplates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblticket_attachments`
--

DROP TABLE IF EXISTS `maxlife_tblticket_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblticket_attachments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticketid` int(11) NOT NULL,
  `replyid` int(11) DEFAULT NULL,
  `file_name` varchar(191) NOT NULL,
  `filetype` varchar(50) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblticket_attachments`
--

LOCK TABLES `maxlife_tblticket_attachments` WRITE;
/*!40000 ALTER TABLE `maxlife_tblticket_attachments` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblticket_attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblticket_replies`
--

DROP TABLE IF EXISTS `maxlife_tblticket_replies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblticket_replies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticketid` int(11) NOT NULL,
  `userid` int(11) DEFAULT NULL,
  `contactid` int(11) NOT NULL DEFAULT 0,
  `name` mediumtext DEFAULT NULL,
  `email` mediumtext DEFAULT NULL,
  `date` datetime NOT NULL,
  `message` mediumtext DEFAULT NULL,
  `attachment` int(11) DEFAULT NULL,
  `admin` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblticket_replies`
--

LOCK TABLES `maxlife_tblticket_replies` WRITE;
/*!40000 ALTER TABLE `maxlife_tblticket_replies` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblticket_replies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tbltickets`
--

DROP TABLE IF EXISTS `maxlife_tbltickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tbltickets` (
  `ticketid` int(11) NOT NULL AUTO_INCREMENT,
  `adminreplying` int(11) NOT NULL DEFAULT 0,
  `userid` int(11) NOT NULL,
  `contactid` int(11) NOT NULL DEFAULT 0,
  `merged_ticket_id` int(11) DEFAULT NULL,
  `email` mediumtext DEFAULT NULL,
  `name` mediumtext DEFAULT NULL,
  `department` int(11) NOT NULL,
  `priority` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `service` int(11) DEFAULT NULL,
  `ticketkey` varchar(32) NOT NULL,
  `subject` varchar(191) NOT NULL,
  `message` mediumtext DEFAULT NULL,
  `admin` int(11) DEFAULT NULL,
  `date` datetime NOT NULL,
  `project_id` int(11) NOT NULL DEFAULT 0,
  `lastreply` datetime DEFAULT NULL,
  `clientread` int(11) NOT NULL DEFAULT 0,
  `adminread` int(11) NOT NULL DEFAULT 0,
  `assigned` int(11) NOT NULL DEFAULT 0,
  `staff_id_replying` int(11) DEFAULT NULL,
  `cc` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`ticketid`),
  KEY `service` (`service`),
  KEY `department` (`department`),
  KEY `status` (`status`),
  KEY `userid` (`userid`),
  KEY `priority` (`priority`),
  KEY `project_id` (`project_id`),
  KEY `contactid` (`contactid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tbltickets`
--

LOCK TABLES `maxlife_tbltickets` WRITE;
/*!40000 ALTER TABLE `maxlife_tbltickets` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tbltickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tbltickets_pipe_log`
--

DROP TABLE IF EXISTS `maxlife_tbltickets_pipe_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tbltickets_pipe_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `email_to` varchar(100) NOT NULL,
  `name` varchar(191) NOT NULL,
  `subject` varchar(191) NOT NULL,
  `message` longtext NOT NULL,
  `email` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tbltickets_pipe_log`
--

LOCK TABLES `maxlife_tbltickets_pipe_log` WRITE;
/*!40000 ALTER TABLE `maxlife_tbltickets_pipe_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tbltickets_pipe_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tbltickets_predefined_replies`
--

DROP TABLE IF EXISTS `maxlife_tbltickets_predefined_replies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tbltickets_predefined_replies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `message` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tbltickets_predefined_replies`
--

LOCK TABLES `maxlife_tbltickets_predefined_replies` WRITE;
/*!40000 ALTER TABLE `maxlife_tbltickets_predefined_replies` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tbltickets_predefined_replies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tbltickets_priorities`
--

DROP TABLE IF EXISTS `maxlife_tbltickets_priorities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tbltickets_priorities` (
  `priorityid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`priorityid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tbltickets_priorities`
--

LOCK TABLES `maxlife_tbltickets_priorities` WRITE;
/*!40000 ALTER TABLE `maxlife_tbltickets_priorities` DISABLE KEYS */;
INSERT INTO `maxlife_tbltickets_priorities` VALUES (1,'Low'),(2,'Medium'),(3,'High');
/*!40000 ALTER TABLE `maxlife_tbltickets_priorities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tbltickets_status`
--

DROP TABLE IF EXISTS `maxlife_tbltickets_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tbltickets_status` (
  `ticketstatusid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `isdefault` int(11) NOT NULL DEFAULT 0,
  `statuscolor` varchar(7) DEFAULT NULL,
  `statusorder` int(11) DEFAULT NULL,
  PRIMARY KEY (`ticketstatusid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tbltickets_status`
--

LOCK TABLES `maxlife_tbltickets_status` WRITE;
/*!40000 ALTER TABLE `maxlife_tbltickets_status` DISABLE KEYS */;
INSERT INTO `maxlife_tbltickets_status` VALUES (1,'Open',1,'#ff2d42',1),(2,'In progress',1,'#22c55e',2),(3,'Answered',1,'#2563eb',3),(4,'On Hold',1,'#64748b',4),(5,'Closed',1,'#03a9f4',5);
/*!40000 ALTER TABLE `maxlife_tbltickets_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tbltimesheets_additional_timesheet`
--

DROP TABLE IF EXISTS `maxlife_tbltimesheets_additional_timesheet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tbltimesheets_additional_timesheet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `additional_day` varchar(45) NOT NULL,
  `status` varchar(45) NOT NULL,
  `timekeeping_type` varchar(50) DEFAULT NULL,
  `timekeeping_value` varchar(45) NOT NULL,
  `approver` int(11) NOT NULL,
  `creator` int(11) NOT NULL,
  `old_timekeeping` varchar(50) DEFAULT NULL,
  `time_in` varchar(45) DEFAULT NULL,
  `time_out` varchar(45) DEFAULT NULL,
  `overtime_setting` int(11) DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `staff_id` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tbltimesheets_additional_timesheet`
--

LOCK TABLES `maxlife_tbltimesheets_additional_timesheet` WRITE;
/*!40000 ALTER TABLE `maxlife_tbltimesheets_additional_timesheet` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tbltimesheets_additional_timesheet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tbltimesheets_approval_details`
--

DROP TABLE IF EXISTS `maxlife_tbltimesheets_approval_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tbltimesheets_approval_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(45) NOT NULL,
  `staffid` varchar(45) DEFAULT NULL,
  `approve` varchar(45) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `approve_action` varchar(255) DEFAULT NULL,
  `reject_action` varchar(255) DEFAULT NULL,
  `approve_value` varchar(255) DEFAULT NULL,
  `reject_value` varchar(255) DEFAULT NULL,
  `staff_approve` int(11) DEFAULT NULL,
  `action` varchar(45) DEFAULT NULL,
  `sender` int(11) DEFAULT NULL,
  `date_send` datetime DEFAULT NULL,
  `notification_recipient` longtext DEFAULT NULL,
  `approval_deadline` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tbltimesheets_approval_details`
--

LOCK TABLES `maxlife_tbltimesheets_approval_details` WRITE;
/*!40000 ALTER TABLE `maxlife_tbltimesheets_approval_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tbltimesheets_approval_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tbltimesheets_approval_setting`
--

DROP TABLE IF EXISTS `maxlife_tbltimesheets_approval_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tbltimesheets_approval_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `related` varchar(255) NOT NULL,
  `setting` longtext NOT NULL,
  `choose_when_approving` int(11) NOT NULL DEFAULT 0,
  `notification_recipient` longtext DEFAULT NULL,
  `number_day_approval` int(11) DEFAULT NULL,
  `departments` text DEFAULT NULL,
  `job_positions` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tbltimesheets_approval_setting`
--

LOCK TABLES `maxlife_tbltimesheets_approval_setting` WRITE;
/*!40000 ALTER TABLE `maxlife_tbltimesheets_approval_setting` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tbltimesheets_approval_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tbltimesheets_day_off`
--

DROP TABLE IF EXISTS `maxlife_tbltimesheets_day_off`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tbltimesheets_day_off` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `year` varchar(45) DEFAULT NULL,
  `total` varchar(45) DEFAULT NULL,
  `remain` varchar(45) DEFAULT NULL,
  `accumulated` varchar(45) DEFAULT NULL,
  `days_off` float DEFAULT 0,
  `type_of_leave` varchar(200) NOT NULL DEFAULT '8',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tbltimesheets_day_off`
--

LOCK TABLES `maxlife_tbltimesheets_day_off` WRITE;
/*!40000 ALTER TABLE `maxlife_tbltimesheets_day_off` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tbltimesheets_day_off` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tbltimesheets_go_bussiness_advance_payment`
--

DROP TABLE IF EXISTS `maxlife_tbltimesheets_go_bussiness_advance_payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tbltimesheets_go_bussiness_advance_payment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `requisition_leave` int(11) NOT NULL,
  `used_to` varchar(200) DEFAULT NULL,
  `amoun_of_money` varchar(200) DEFAULT NULL,
  `request_date` date DEFAULT NULL,
  `advance_payment_reason` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tbltimesheets_go_bussiness_advance_payment`
--

LOCK TABLES `maxlife_tbltimesheets_go_bussiness_advance_payment` WRITE;
/*!40000 ALTER TABLE `maxlife_tbltimesheets_go_bussiness_advance_payment` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tbltimesheets_go_bussiness_advance_payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tbltimesheets_latch_timesheet`
--

DROP TABLE IF EXISTS `maxlife_tbltimesheets_latch_timesheet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tbltimesheets_latch_timesheet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `month_latch` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tbltimesheets_latch_timesheet`
--

LOCK TABLES `maxlife_tbltimesheets_latch_timesheet` WRITE;
/*!40000 ALTER TABLE `maxlife_tbltimesheets_latch_timesheet` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tbltimesheets_latch_timesheet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tbltimesheets_leave`
--

DROP TABLE IF EXISTS `maxlife_tbltimesheets_leave`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tbltimesheets_leave` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `date_work` date NOT NULL,
  `value` text DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tbltimesheets_leave`
--

LOCK TABLES `maxlife_tbltimesheets_leave` WRITE;
/*!40000 ALTER TABLE `maxlife_tbltimesheets_leave` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tbltimesheets_leave` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tbltimesheets_log_send_notify`
--

DROP TABLE IF EXISTS `maxlife_tbltimesheets_log_send_notify`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tbltimesheets_log_send_notify` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sent` int(11) NOT NULL DEFAULT 0,
  `staffid` int(11) NOT NULL DEFAULT 0,
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  `type` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tbltimesheets_log_send_notify`
--

LOCK TABLES `maxlife_tbltimesheets_log_send_notify` WRITE;
/*!40000 ALTER TABLE `maxlife_tbltimesheets_log_send_notify` DISABLE KEYS */;
INSERT INTO `maxlife_tbltimesheets_log_send_notify` VALUES (1,1,0,'2025-07-13 00:00:00','approval_expiration');
/*!40000 ALTER TABLE `maxlife_tbltimesheets_log_send_notify` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tbltimesheets_option`
--

DROP TABLE IF EXISTS `maxlife_tbltimesheets_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tbltimesheets_option` (
  `option_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(200) NOT NULL,
  `option_val` longtext DEFAULT NULL,
  `auto` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`option_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tbltimesheets_option`
--

LOCK TABLES `maxlife_tbltimesheets_option` WRITE;
/*!40000 ALTER TABLE `maxlife_tbltimesheets_option` DISABLE KEYS */;
INSERT INTO `maxlife_tbltimesheets_option` VALUES (1,'shift_applicable_object','',1),(2,'timekeeping_form','timekeeping_manually',1),(3,'timekeeping_manually_role','',1),(4,'timekeeping_task_role','',1),(5,'csv_clsx_role','',1),(6,'attendance_notice_recipient','',1),(7,'allows_updating_check_in_time','1',1),(8,'allows_to_choose_an_older_date','0',1),(9,'allow_attendance_by_coordinates','0',1),(10,'googlemap_api_key','',1),(11,'allow_attendance_by_route','0',1),(12,'auto_checkout','0',1),(13,'auto_checkout_type','1',1),(14,'auto_checkout_value','1',1),(15,'send_notification_if_check_in_forgotten','0',1),(16,'send_notification_if_check_in_forgotten_value','30',1),(17,'start_month_for_annual_leave_cycle','1',1),(18,'start_year_for_annual_leave_cycle','2025',1),(19,'hour_notification_approval_exp','3',1),(20,'timekeeping_enable_valid_ip','0',1),(21,'send_email_check_in_out_customer_location','0',1),(22,'allow_employees_to_create_work_points','0',1),(23,'type_of_leave_selected','8',1);
/*!40000 ALTER TABLE `maxlife_tbltimesheets_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tbltimesheets_requisition_leave`
--

DROP TABLE IF EXISTS `maxlife_tbltimesheets_requisition_leave`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tbltimesheets_requisition_leave` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `subject` varchar(100) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `received_date` date DEFAULT NULL,
  `amount_received` text DEFAULT NULL,
  `approver_id` int(11) NOT NULL,
  `followers_id` int(11) DEFAULT NULL,
  `rel_type` int(11) NOT NULL COMMENT '1:Leave 2:Late_early 3:Go_out 4:Go_on_bussiness',
  `status` int(11) DEFAULT 0 COMMENT '0:Create 1:Approver 2:Reject',
  `place_of_business` longtext DEFAULT NULL,
  `type_of_leave` int(11) DEFAULT 0,
  `according_to_the_plan` int(11) DEFAULT 0,
  `handover_recipients` longtext DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `number_of_days` float DEFAULT NULL,
  `number_of_leaving_day` varchar(45) DEFAULT NULL,
  `type_of_leave_text` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`,`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tbltimesheets_requisition_leave`
--

LOCK TABLES `maxlife_tbltimesheets_requisition_leave` WRITE;
/*!40000 ALTER TABLE `maxlife_tbltimesheets_requisition_leave` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tbltimesheets_requisition_leave` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tbltimesheets_route`
--

DROP TABLE IF EXISTS `maxlife_tbltimesheets_route`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tbltimesheets_route` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `route_point_id` int(11) NOT NULL,
  `date_work` date NOT NULL,
  `order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tbltimesheets_route`
--

LOCK TABLES `maxlife_tbltimesheets_route` WRITE;
/*!40000 ALTER TABLE `maxlife_tbltimesheets_route` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tbltimesheets_route` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tbltimesheets_route_point`
--

DROP TABLE IF EXISTS `maxlife_tbltimesheets_route_point`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tbltimesheets_route_point` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `route_point_address` varchar(400) DEFAULT NULL,
  `latitude` varchar(30) DEFAULT NULL,
  `longitude` varchar(30) DEFAULT NULL,
  `distance` double DEFAULT NULL,
  `related_to` int(11) NOT NULL,
  `related_id` int(11) NOT NULL,
  `default` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tbltimesheets_route_point`
--

LOCK TABLES `maxlife_tbltimesheets_route_point` WRITE;
/*!40000 ALTER TABLE `maxlife_tbltimesheets_route_point` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tbltimesheets_route_point` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tbltimesheets_shift_sc`
--

DROP TABLE IF EXISTS `maxlife_tbltimesheets_shift_sc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tbltimesheets_shift_sc` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shift_symbol` varchar(45) NOT NULL,
  `time_start_work` varchar(45) NOT NULL,
  `time_end_work` varchar(45) NOT NULL,
  `start_lunch_break_time` varchar(45) NOT NULL,
  `end_lunch_break_time` varchar(45) NOT NULL,
  `late_latency_allowed` varchar(45) NOT NULL,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tbltimesheets_shift_sc`
--

LOCK TABLES `maxlife_tbltimesheets_shift_sc` WRITE;
/*!40000 ALTER TABLE `maxlife_tbltimesheets_shift_sc` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tbltimesheets_shift_sc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tbltimesheets_shiftwork_sc`
--

DROP TABLE IF EXISTS `maxlife_tbltimesheets_shiftwork_sc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tbltimesheets_shiftwork_sc` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `date_work` date NOT NULL,
  `shift` int(11) NOT NULL,
  `datecreated` datetime DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tbltimesheets_shiftwork_sc`
--

LOCK TABLES `maxlife_tbltimesheets_shiftwork_sc` WRITE;
/*!40000 ALTER TABLE `maxlife_tbltimesheets_shiftwork_sc` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tbltimesheets_shiftwork_sc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tbltimesheets_timekeeper_data`
--

DROP TABLE IF EXISTS `maxlife_tbltimesheets_timekeeper_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tbltimesheets_timekeeper_data` (
  `staff_identifi` varchar(25) NOT NULL,
  `time` datetime NOT NULL,
  `type` varchar(45) NOT NULL,
  PRIMARY KEY (`staff_identifi`,`time`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tbltimesheets_timekeeper_data`
--

LOCK TABLES `maxlife_tbltimesheets_timekeeper_data` WRITE;
/*!40000 ALTER TABLE `maxlife_tbltimesheets_timekeeper_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tbltimesheets_timekeeper_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tbltimesheets_timesheet`
--

DROP TABLE IF EXISTS `maxlife_tbltimesheets_timesheet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tbltimesheets_timesheet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `date_work` date NOT NULL,
  `value` text DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  `overtime_setting` int(11) DEFAULT NULL,
  `relate_id` int(11) DEFAULT NULL,
  `relate_type` varchar(25) DEFAULT NULL,
  `latch` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tbltimesheets_timesheet`
--

LOCK TABLES `maxlife_tbltimesheets_timesheet` WRITE;
/*!40000 ALTER TABLE `maxlife_tbltimesheets_timesheet` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tbltimesheets_timesheet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tbltimesheets_type_of_leave`
--

DROP TABLE IF EXISTS `maxlife_tbltimesheets_type_of_leave`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tbltimesheets_type_of_leave` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type_name` varchar(200) DEFAULT NULL,
  `slug` varchar(200) DEFAULT NULL,
  `symbol` varchar(5) DEFAULT NULL,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tbltimesheets_type_of_leave`
--

LOCK TABLES `maxlife_tbltimesheets_type_of_leave` WRITE;
/*!40000 ALTER TABLE `maxlife_tbltimesheets_type_of_leave` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tbltimesheets_type_of_leave` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tbltimesheets_valid_ip`
--

DROP TABLE IF EXISTS `maxlife_tbltimesheets_valid_ip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tbltimesheets_valid_ip` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ip` varchar(30) DEFAULT NULL,
  `enable` int(11) NOT NULL DEFAULT 1,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tbltimesheets_valid_ip`
--

LOCK TABLES `maxlife_tbltimesheets_valid_ip` WRITE;
/*!40000 ALTER TABLE `maxlife_tbltimesheets_valid_ip` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tbltimesheets_valid_ip` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tbltimesheets_workplace`
--

DROP TABLE IF EXISTS `maxlife_tbltimesheets_workplace`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tbltimesheets_workplace` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `workplace_address` varchar(400) DEFAULT NULL,
  `latitude` varchar(30) DEFAULT NULL,
  `longitude` varchar(30) DEFAULT NULL,
  `distance` double DEFAULT NULL,
  `default` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tbltimesheets_workplace`
--

LOCK TABLES `maxlife_tbltimesheets_workplace` WRITE;
/*!40000 ALTER TABLE `maxlife_tbltimesheets_workplace` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tbltimesheets_workplace` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tbltimesheets_workplace_assign`
--

DROP TABLE IF EXISTS `maxlife_tbltimesheets_workplace_assign`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tbltimesheets_workplace_assign` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `workplace_id` int(11) NOT NULL,
  `datecreator` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tbltimesheets_workplace_assign`
--

LOCK TABLES `maxlife_tbltimesheets_workplace_assign` WRITE;
/*!40000 ALTER TABLE `maxlife_tbltimesheets_workplace_assign` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tbltimesheets_workplace_assign` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tbltodos`
--

DROP TABLE IF EXISTS `maxlife_tbltodos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tbltodos` (
  `todoid` int(11) NOT NULL AUTO_INCREMENT,
  `description` mediumtext NOT NULL,
  `staffid` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  `finished` tinyint(1) NOT NULL,
  `datefinished` datetime DEFAULT NULL,
  `item_order` int(11) DEFAULT NULL,
  PRIMARY KEY (`todoid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tbltodos`
--

LOCK TABLES `maxlife_tbltodos` WRITE;
/*!40000 ALTER TABLE `maxlife_tbltodos` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tbltodos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tbltracked_mails`
--

DROP TABLE IF EXISTS `maxlife_tbltracked_mails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tbltracked_mails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` varchar(32) NOT NULL,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(40) NOT NULL,
  `date` datetime NOT NULL,
  `email` varchar(100) NOT NULL,
  `opened` tinyint(1) NOT NULL DEFAULT 0,
  `date_opened` datetime DEFAULT NULL,
  `subject` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tbltracked_mails`
--

LOCK TABLES `maxlife_tbltracked_mails` WRITE;
/*!40000 ALTER TABLE `maxlife_tbltracked_mails` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tbltracked_mails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tbltwocheckout_log`
--

DROP TABLE IF EXISTS `maxlife_tbltwocheckout_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tbltwocheckout_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference` varchar(64) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `amount` varchar(25) NOT NULL,
  `created_at` datetime NOT NULL,
  `attempt_reference` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `invoice_id` (`invoice_id`),
  CONSTRAINT `maxlife_tbltwocheckout_log_ibfk_1` FOREIGN KEY (`invoice_id`) REFERENCES `maxlife_tblinvoices` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tbltwocheckout_log`
--

LOCK TABLES `maxlife_tbltwocheckout_log` WRITE;
/*!40000 ALTER TABLE `maxlife_tbltwocheckout_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tbltwocheckout_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tbluser_auto_login`
--

DROP TABLE IF EXISTS `maxlife_tbluser_auto_login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tbluser_auto_login` (
  `key_id` char(32) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_agent` varchar(150) NOT NULL,
  `last_ip` varchar(40) NOT NULL,
  `last_login` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `staff` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tbluser_auto_login`
--

LOCK TABLES `maxlife_tbluser_auto_login` WRITE;
/*!40000 ALTER TABLE `maxlife_tbluser_auto_login` DISABLE KEYS */;
INSERT INTO `maxlife_tbluser_auto_login` VALUES ('47c4e8de17a889eca1a880cf42e8b8bb',1,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','106.219.231.124','2025-07-13 13:29:53',1),('015c885970796c6b993b56d2495750b4',1,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','106.219.231.124','2025-07-13 13:29:56',1),('60d50535ca58c96c926cb7092c86f24f',1,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','106.219.231.124','2025-07-13 13:29:57',1);
/*!40000 ALTER TABLE `maxlife_tbluser_auto_login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tbluser_meta`
--

DROP TABLE IF EXISTS `maxlife_tbluser_meta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tbluser_meta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `staff_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `client_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `contact_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(191) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  `candidate_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`umeta_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tbluser_meta`
--

LOCK TABLES `maxlife_tbluser_meta` WRITE;
/*!40000 ALTER TABLE `maxlife_tbluser_meta` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tbluser_meta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblvault`
--

DROP TABLE IF EXISTS `maxlife_tblvault`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblvault` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `server_address` varchar(191) NOT NULL,
  `port` int(11) DEFAULT NULL,
  `username` varchar(191) NOT NULL,
  `password` mediumtext NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `creator` int(11) NOT NULL,
  `creator_name` varchar(100) DEFAULT NULL,
  `visibility` tinyint(1) NOT NULL DEFAULT 1,
  `share_in_projects` tinyint(1) NOT NULL DEFAULT 0,
  `last_updated` datetime DEFAULT NULL,
  `last_updated_from` varchar(100) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblvault`
--

LOCK TABLES `maxlife_tblvault` WRITE;
/*!40000 ALTER TABLE `maxlife_tblvault` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblvault` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblviews_tracking`
--

DROP TABLE IF EXISTS `maxlife_tblviews_tracking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblviews_tracking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(40) NOT NULL,
  `date` datetime NOT NULL,
  `view_ip` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblviews_tracking`
--

LOCK TABLES `maxlife_tblviews_tracking` WRITE;
/*!40000 ALTER TABLE `maxlife_tblviews_tracking` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblviews_tracking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblware_unit_type`
--

DROP TABLE IF EXISTS `maxlife_tblware_unit_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblware_unit_type` (
  `unit_type_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `unit_code` varchar(100) DEFAULT NULL,
  `unit_name` text DEFAULT NULL,
  `unit_symbol` text DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  `display` int(1) DEFAULT NULL COMMENT 'display 1: display (yes)  0: not displayed (no)',
  `note` text DEFAULT NULL,
  PRIMARY KEY (`unit_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblware_unit_type`
--

LOCK TABLES `maxlife_tblware_unit_type` WRITE;
/*!40000 ALTER TABLE `maxlife_tblware_unit_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblware_unit_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblweb_to_lead`
--

DROP TABLE IF EXISTS `maxlife_tblweb_to_lead`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblweb_to_lead` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `form_key` varchar(32) NOT NULL,
  `lead_source` int(11) NOT NULL,
  `lead_status` int(11) NOT NULL,
  `notify_lead_imported` int(11) NOT NULL DEFAULT 1,
  `notify_type` varchar(20) DEFAULT NULL,
  `notify_ids` longtext DEFAULT NULL,
  `responsible` int(11) NOT NULL DEFAULT 0,
  `name` varchar(191) NOT NULL,
  `form_data` longtext DEFAULT NULL,
  `recaptcha` int(11) NOT NULL DEFAULT 0,
  `submit_btn_name` varchar(40) DEFAULT NULL,
  `submit_btn_text_color` varchar(10) DEFAULT '#ffffff',
  `submit_btn_bg_color` varchar(10) DEFAULT '#84c529',
  `success_submit_msg` mediumtext DEFAULT NULL,
  `submit_action` int(11) DEFAULT 0,
  `lead_name_prefix` varchar(255) DEFAULT NULL,
  `submit_redirect_url` longtext DEFAULT NULL,
  `language` varchar(40) DEFAULT NULL,
  `allow_duplicate` int(11) NOT NULL DEFAULT 1,
  `mark_public` int(11) NOT NULL DEFAULT 0,
  `track_duplicate_field` varchar(20) DEFAULT NULL,
  `track_duplicate_field_and` varchar(20) DEFAULT NULL,
  `create_task_on_duplicate` int(11) NOT NULL DEFAULT 0,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblweb_to_lead`
--

LOCK TABLES `maxlife_tblweb_to_lead` WRITE;
/*!40000 ALTER TABLE `maxlife_tblweb_to_lead` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblweb_to_lead` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblwh_goods_delivery_activity_log`
--

DROP TABLE IF EXISTS `maxlife_tblwh_goods_delivery_activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblwh_goods_delivery_activity_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(100) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `additional_data` text DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `staffid` int(11) DEFAULT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblwh_goods_delivery_activity_log`
--

LOCK TABLES `maxlife_tblwh_goods_delivery_activity_log` WRITE;
/*!40000 ALTER TABLE `maxlife_tblwh_goods_delivery_activity_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblwh_goods_delivery_activity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblwh_order_return_details`
--

DROP TABLE IF EXISTS `maxlife_tblwh_order_return_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblwh_order_return_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_return_id` int(11) NOT NULL,
  `rel_type_detail_id` int(11) DEFAULT NULL,
  `commodity_code` int(11) DEFAULT NULL,
  `commodity_name` text DEFAULT NULL,
  `quantity` decimal(15,2) DEFAULT 0.00,
  `unit_id` int(11) DEFAULT NULL,
  `unit_price` decimal(15,2) DEFAULT 0.00,
  `sub_total` decimal(15,2) DEFAULT 0.00,
  `tax_id` text DEFAULT NULL,
  `tax_rate` text DEFAULT NULL,
  `tax_name` text DEFAULT NULL,
  `total_amount` decimal(15,2) DEFAULT 0.00,
  `discount` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `total_after_discount` decimal(15,2) DEFAULT 0.00,
  `reason_return` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblwh_order_return_details`
--

LOCK TABLES `maxlife_tblwh_order_return_details` WRITE;
/*!40000 ALTER TABLE `maxlife_tblwh_order_return_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblwh_order_return_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblwh_order_returns`
--

DROP TABLE IF EXISTS `maxlife_tblwh_order_returns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblwh_order_returns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(50) NOT NULL COMMENT 'manual, sales_return_order, purchasing_return_order',
  `return_type` varchar(50) DEFAULT NULL COMMENT 'manual, partially, fully',
  `company_id` int(11) DEFAULT NULL,
  `company_name` varchar(500) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phonenumber` varchar(20) DEFAULT NULL,
  `order_number` varchar(500) DEFAULT NULL,
  `order_date` datetime DEFAULT NULL,
  `number_of_item` decimal(15,2) DEFAULT 0.00,
  `order_total` decimal(15,2) DEFAULT 0.00,
  `order_return_number` varchar(200) DEFAULT NULL,
  `order_return_name` varchar(500) DEFAULT NULL,
  `fee_return_order` decimal(15,2) DEFAULT 0.00,
  `refund_loyaty_point` int(11) DEFAULT 0,
  `subtotal` decimal(15,2) DEFAULT 0.00,
  `total_amount` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `additional_discount` decimal(15,2) DEFAULT 0.00,
  `adjustment_amount` decimal(15,2) DEFAULT 0.00,
  `total_after_discount` decimal(15,2) DEFAULT 0.00,
  `return_policies_information` text DEFAULT NULL,
  `admin_note` text DEFAULT NULL,
  `approval` int(11) DEFAULT 0,
  `datecreated` datetime DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `receipt_delivery_id` int(1) DEFAULT 0,
  `return_reason` longtext DEFAULT NULL,
  `receipt_delivery_type` varchar(100) DEFAULT NULL,
  `currency` int(11) DEFAULT NULL,
  `status` varchar(30) DEFAULT 'draft',
  `discount_type` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblwh_order_returns`
--

LOCK TABLES `maxlife_tblwh_order_returns` WRITE;
/*!40000 ALTER TABLE `maxlife_tblwh_order_returns` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblwh_order_returns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblwh_order_returns_refunds`
--

DROP TABLE IF EXISTS `maxlife_tblwh_order_returns_refunds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblwh_order_returns_refunds` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `order_return_id` int(11) DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `refunded_on` date DEFAULT NULL,
  `payment_mode` varchar(40) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `amount` decimal(15,2) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblwh_order_returns_refunds`
--

LOCK TABLES `maxlife_tblwh_order_returns_refunds` WRITE;
/*!40000 ALTER TABLE `maxlife_tblwh_order_returns_refunds` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblwh_order_returns_refunds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblwh_sub_group`
--

DROP TABLE IF EXISTS `maxlife_tblwh_sub_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblwh_sub_group` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sub_group_code` varchar(100) DEFAULT NULL,
  `sub_group_name` text DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  `display` int(1) DEFAULT NULL COMMENT 'display 1: display (yes)  0: not displayed (no)',
  `note` text DEFAULT NULL,
  `group_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblwh_sub_group`
--

LOCK TABLES `maxlife_tblwh_sub_group` WRITE;
/*!40000 ALTER TABLE `maxlife_tblwh_sub_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblwh_sub_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblwoocommere_store`
--

DROP TABLE IF EXISTS `maxlife_tblwoocommere_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblwoocommere_store` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) DEFAULT NULL,
  `ip` varchar(30) DEFAULT NULL,
  `url` varchar(350) DEFAULT NULL,
  `port` varchar(10) DEFAULT NULL,
  `token` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblwoocommere_store`
--

LOCK TABLES `maxlife_tblwoocommere_store` WRITE;
/*!40000 ALTER TABLE `maxlife_tblwoocommere_store` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblwoocommere_store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblwoocommere_store_detailt`
--

DROP TABLE IF EXISTS `maxlife_tblwoocommere_store_detailt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblwoocommere_store_detailt` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `group_product_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `woocommere_store_id` int(11) NOT NULL,
  `prices` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblwoocommere_store_detailt`
--

LOCK TABLES `maxlife_tblwoocommere_store_detailt` WRITE;
/*!40000 ALTER TABLE `maxlife_tblwoocommere_store_detailt` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblwoocommere_store_detailt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblwork_shift`
--

DROP TABLE IF EXISTS `maxlife_tblwork_shift`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblwork_shift` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shift_code` varchar(45) NOT NULL,
  `shift_name` varchar(200) NOT NULL,
  `shift_type` varchar(200) NOT NULL,
  `department` varchar(45) DEFAULT NULL,
  `position` varchar(45) DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  `staff` text DEFAULT NULL,
  `date_create` date DEFAULT NULL,
  `from_date` date DEFAULT NULL,
  `to_date` date DEFAULT NULL,
  `shifts_detail` text NOT NULL,
  `type_shiftwork` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblwork_shift`
--

LOCK TABLES `maxlife_tblwork_shift` WRITE;
/*!40000 ALTER TABLE `maxlife_tblwork_shift` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblwork_shift` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblwork_shift_detail`
--

DROP TABLE IF EXISTS `maxlife_tblwork_shift_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblwork_shift_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `shift_id` int(11) DEFAULT NULL,
  `work_shift_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblwork_shift_detail`
--

LOCK TABLES `maxlife_tblwork_shift_detail` WRITE;
/*!40000 ALTER TABLE `maxlife_tblwork_shift_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblwork_shift_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblwork_shift_detail_day_name`
--

DROP TABLE IF EXISTS `maxlife_tblwork_shift_detail_day_name`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblwork_shift_detail_day_name` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `day_name` varchar(45) DEFAULT NULL,
  `shift_id` int(11) DEFAULT NULL,
  `work_shift_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblwork_shift_detail_day_name`
--

LOCK TABLES `maxlife_tblwork_shift_detail_day_name` WRITE;
/*!40000 ALTER TABLE `maxlife_tblwork_shift_detail_day_name` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblwork_shift_detail_day_name` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblwork_shift_detail_number_day`
--

DROP TABLE IF EXISTS `maxlife_tblwork_shift_detail_number_day`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblwork_shift_detail_number_day` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `number` int(11) DEFAULT NULL,
  `shift_id` int(11) DEFAULT NULL,
  `work_shift_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblwork_shift_detail_number_day`
--

LOCK TABLES `maxlife_tblwork_shift_detail_number_day` WRITE;
/*!40000 ALTER TABLE `maxlife_tblwork_shift_detail_number_day` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblwork_shift_detail_number_day` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maxlife_tblworkload_dayoff`
--

DROP TABLE IF EXISTS `maxlife_tblworkload_dayoff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maxlife_tblworkload_dayoff` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reason` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `addedfrom` int(11) NOT NULL,
  `datecreated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxlife_tblworkload_dayoff`
--

LOCK TABLES `maxlife_tblworkload_dayoff` WRITE;
/*!40000 ALTER TABLE `maxlife_tblworkload_dayoff` DISABLE KEYS */;
/*!40000 ALTER TABLE `maxlife_tblworkload_dayoff` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-14 20:37:58
