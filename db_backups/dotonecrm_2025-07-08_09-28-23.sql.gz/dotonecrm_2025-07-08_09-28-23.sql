/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.5.27-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: dotonecrm
-- ------------------------------------------------------
-- Server version	10.5.27-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tblacc_account_history`
--

DROP TABLE IF EXISTS `tblacc_account_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblacc_account_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account` int(11) NOT NULL,
  `debit` decimal(15,2) NOT NULL DEFAULT 0.00,
  `credit` decimal(15,2) NOT NULL DEFAULT 0.00,
  `description` text DEFAULT NULL,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(45) DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `customer` int(11) DEFAULT NULL,
  `reconcile` int(11) NOT NULL DEFAULT 0,
  `split` int(11) NOT NULL DEFAULT 0,
  `item` int(11) DEFAULT NULL,
  `paid` int(1) NOT NULL DEFAULT 0,
  `date` date DEFAULT NULL,
  `tax` int(11) DEFAULT NULL,
  `payslip_type` varchar(45) DEFAULT NULL,
  `vendor` int(11) DEFAULT NULL,
  `itemable_id` int(11) DEFAULT NULL,
  `cleared` int(11) NOT NULL DEFAULT 0,
  `sub_type` varchar(45) DEFAULT NULL,
  `bill_item` int(11) NOT NULL DEFAULT 0,
  `number` varchar(100) DEFAULT NULL,
  `issue` int(11) NOT NULL DEFAULT 0,
  `added_from_reconcile` int(11) NOT NULL DEFAULT 0,
  `bank_reconcile` int(11) NOT NULL DEFAULT 0,
  `currency_rate` decimal(15,6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_account_history`
--

LOCK TABLES `tblacc_account_history` WRITE;
/*!40000 ALTER TABLE `tblacc_account_history` DISABLE KEYS */;
INSERT INTO `tblacc_account_history` VALUES (11,1,18000.00,0.00,'',3,'invoice','2025-07-08 10:32:34',1,10,0,66,0,0,'2025-07-08',0,NULL,NULL,3,0,NULL,0,NULL,0,0,0,0.000000),(12,66,0.00,18000.00,'',3,'invoice','2025-07-08 10:32:34',1,10,0,1,0,0,'2025-07-08',0,NULL,NULL,3,0,NULL,0,NULL,0,0,0,0.000000),(15,1,18000.00,0.00,'',4,'invoice','2025-07-08 10:54:18',1,11,0,66,0,1,'2025-07-08',0,NULL,NULL,4,0,NULL,0,NULL,0,0,0,0.000000),(16,66,0.00,18000.00,'',4,'invoice','2025-07-08 10:54:18',1,11,0,1,0,1,'2025-07-08',0,NULL,NULL,4,0,NULL,0,NULL,0,0,0,0.000000),(17,13,18000.00,0.00,'',2,'payment','2025-07-08 10:54:18',1,11,0,1,NULL,0,'2025-07-08',NULL,NULL,NULL,NULL,0,NULL,0,NULL,0,0,0,0.000000),(18,1,0.00,18000.00,'',2,'payment','2025-07-08 10:54:18',1,11,0,13,NULL,0,'2025-07-08',NULL,NULL,NULL,NULL,0,NULL,0,NULL,0,0,0,0.000000);
/*!40000 ALTER TABLE `tblacc_account_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblacc_account_type_details`
--

DROP TABLE IF EXISTS `tblacc_account_type_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblacc_account_type_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_type_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `note` text DEFAULT NULL,
  `statement_of_cash_flows` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=200 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_account_type_details`
--

LOCK TABLES `tblacc_account_type_details` WRITE;
/*!40000 ALTER TABLE `tblacc_account_type_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblacc_account_type_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblacc_accounts`
--

DROP TABLE IF EXISTS `tblacc_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblacc_accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `key_name` varchar(255) DEFAULT NULL,
  `number` varchar(45) DEFAULT NULL,
  `parent_account` int(11) DEFAULT NULL,
  `account_type_id` int(11) NOT NULL,
  `account_detail_type_id` int(11) NOT NULL,
  `balance` decimal(15,2) DEFAULT NULL,
  `balance_as_of` date DEFAULT NULL,
  `description` text DEFAULT NULL,
  `default_account` int(11) NOT NULL DEFAULT 0,
  `active` int(11) NOT NULL DEFAULT 1,
  `access_token` text DEFAULT NULL,
  `account_id` varchar(255) DEFAULT NULL,
  `plaid_status` tinyint(5) NOT NULL DEFAULT 0 COMMENT '1=>verified, 0=>not verified',
  `plaid_account_name` varchar(255) DEFAULT NULL,
  `bank_account` text DEFAULT NULL,
  `bank_routing` text DEFAULT NULL,
  `address_line_1` text DEFAULT NULL,
  `address_line_2` text DEFAULT NULL,
  `bank_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_accounts`
--

LOCK TABLES `tblacc_accounts` WRITE;
/*!40000 ALTER TABLE `tblacc_accounts` DISABLE KEYS */;
INSERT INTO `tblacc_accounts` VALUES (1,'','acc_accounts_receivable',NULL,NULL,1,1,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(2,'','acc_accrued_holiday_payable',NULL,NULL,9,61,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(3,'','acc_accrued_liabilities',NULL,NULL,8,44,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(4,'','acc_accrued_non_current_liabilities',NULL,NULL,9,62,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(5,'','acc_accumulated_depreciation_on_property_plant_and_equipment',NULL,NULL,4,22,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(6,'','acc_allowance_for_bad_debts',NULL,NULL,2,2,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(7,'','acc_amortisation_expense',NULL,NULL,14,106,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(8,'','acc_assets_held_for_sale',NULL,NULL,5,32,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(9,'','acc_available_for_sale_assets_short_term',NULL,NULL,2,3,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(10,'','acc_bad_debts',NULL,NULL,14,108,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(11,'','acc_bank_charges',NULL,NULL,14,109,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(12,'','acc_billable_expense_income',NULL,NULL,11,89,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(13,'','acc_cash_and_cash_equivalents',NULL,NULL,3,15,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(14,'','acc_change_in_inventory_cos',NULL,NULL,13,100,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(15,'','acc_commissions_and_fees',NULL,NULL,14,111,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(16,'','acc_cost_of_sales',NULL,NULL,13,104,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(17,'','acc_deferred_tax_assets',NULL,NULL,5,33,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(18,'','acc_direct_labour_cos',NULL,NULL,13,100,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(19,'','acc_discounts_given_cos',NULL,NULL,13,100,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(20,'','acc_dividend_disbursed',NULL,NULL,10,69,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(21,'','acc_dividend_income',NULL,NULL,12,92,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(22,'','acc_dividends_payable',NULL,NULL,8,48,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(23,'','acc_dues_and_subscriptions',NULL,NULL,14,113,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(24,'','acc_equipment_rental',NULL,NULL,14,114,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(25,'','acc_equity_in_earnings_of_subsidiaries',NULL,NULL,10,70,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(26,'','acc_freight_and_delivery_cos',NULL,NULL,13,100,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(27,'','acc_goodwill',NULL,NULL,5,34,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(28,'','acc_income_tax_expense',NULL,NULL,14,116,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(29,'','acc_income_tax_payable',NULL,NULL,8,50,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(30,'','acc_insurance_disability',NULL,NULL,14,117,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(31,'','acc_insurance_general',NULL,NULL,14,117,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(32,'','acc_insurance_liability',NULL,NULL,14,117,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(33,'','acc_intangibles',NULL,NULL,5,35,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(34,'','acc_interest_expense',NULL,NULL,14,118,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(35,'','acc_interest_income',NULL,NULL,12,93,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(36,'','acc_inventory',NULL,NULL,2,5,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(37,'','acc_inventory_asset',NULL,NULL,2,5,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(38,'','acc_legal_and_professional_fees',NULL,NULL,14,119,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(39,'','acc_liabilities_related_to_assets_held_for_sale',NULL,NULL,9,63,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(40,'','acc_long_term_debt',NULL,NULL,9,64,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(41,'','acc_long_term_investments',NULL,NULL,5,38,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(42,'','acc_loss_on_discontinued_operations_net_of_tax',NULL,NULL,14,120,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(43,'','acc_loss_on_disposal_of_assets',NULL,NULL,12,94,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(44,'','acc_management_compensation',NULL,NULL,14,121,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(45,'','acc_materials_cos',NULL,NULL,13,100,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(46,'','acc_meals_and_entertainment',NULL,NULL,14,122,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(47,'','acc_office_expenses',NULL,NULL,14,123,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(48,'','acc_other_cos',NULL,NULL,13,100,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(49,'','acc_other_comprehensive_income',NULL,NULL,10,73,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(50,'','acc_other_general_and_administrative_expenses',NULL,NULL,14,123,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(51,'','acc_other_operating_income_expenses',NULL,NULL,12,97,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(52,'','acc_other_selling_expenses',NULL,NULL,14,125,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(53,'','acc_other_type_of_expenses_advertising_expenses',NULL,NULL,14,105,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(54,'','acc_overhead_cos',NULL,NULL,13,100,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(55,'','acc_payroll_clearing',NULL,NULL,8,55,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(56,'','acc_payroll_expenses',NULL,NULL,14,126,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(57,'','acc_payroll_liabilities',NULL,NULL,8,56,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(58,'','acc_prepaid_expenses',NULL,NULL,2,11,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(59,'','acc_property_plant_and_equipment',NULL,NULL,4,26,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(60,'','acc_purchases',NULL,NULL,14,130,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(61,'','acc_reconciliation_discrepancies',NULL,NULL,15,139,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(62,'','acc_rent_or_lease_payments',NULL,NULL,14,127,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(63,'','acc_repair_and_maintenance',NULL,NULL,14,128,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(64,'','acc_retained_earnings',NULL,NULL,10,80,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(65,'','acc_revenue_general',NULL,NULL,11,86,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(66,'','acc_sales',NULL,NULL,11,89,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(67,'','acc_sales_retail',NULL,NULL,11,87,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(68,'','acc_sales_wholesale',NULL,NULL,11,88,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(69,'','acc_sales_of_product_income',NULL,NULL,11,89,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(70,'','acc_share_capital',NULL,NULL,10,81,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(71,'','acc_shipping_and_delivery_expense',NULL,NULL,14,129,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(72,'','acc_short_term_debit',NULL,NULL,8,54,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(73,'','acc_stationery_and_printing',NULL,NULL,14,123,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(74,'','acc_subcontractors_cos',NULL,NULL,13,100,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(75,'','acc_supplies',NULL,NULL,14,130,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(76,'','acc_travel_expenses_general_and_admin_expenses',NULL,NULL,14,132,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(77,'','acc_travel_expenses_selling_expense',NULL,NULL,14,133,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(78,'','acc_unapplied_cash_payment_income',NULL,NULL,11,91,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(79,'','acc_uncategorised_asset',NULL,NULL,2,10,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(80,'','acc_uncategorised_expense',NULL,NULL,14,124,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(81,'','acc_uncategorised_income',NULL,NULL,11,89,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(82,'','acc_undeposited_funds',NULL,NULL,2,13,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(83,'','acc_unrealised_loss_on_securities_net_of_tax',NULL,NULL,12,99,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(84,'','acc_utilities',NULL,NULL,14,135,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(85,'','acc_wage_expenses',NULL,NULL,14,126,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(86,'','acc_credit_card',NULL,NULL,7,43,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(87,'','acc_accounts_payable',NULL,NULL,6,42,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),(88,'','acc_opening_balance_equity',NULL,NULL,10,71,NULL,NULL,NULL,1,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `tblacc_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblacc_bank_reconciles`
--

DROP TABLE IF EXISTS `tblacc_bank_reconciles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblacc_bank_reconciles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account` int(11) NOT NULL,
  `opening_balance` decimal(15,2) NOT NULL DEFAULT 0.00,
  `beginning_balance` decimal(15,2) NOT NULL,
  `ending_balance` decimal(15,2) NOT NULL,
  `ending_date` date NOT NULL,
  `finish` int(11) NOT NULL DEFAULT 0,
  `debits_for_period` decimal(15,2) NOT NULL,
  `credits_for_period` decimal(15,2) NOT NULL,
  `dateadded` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_bank_reconciles`
--

LOCK TABLES `tblacc_bank_reconciles` WRITE;
/*!40000 ALTER TABLE `tblacc_bank_reconciles` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblacc_bank_reconciles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblacc_banking_rule_details`
--

DROP TABLE IF EXISTS `tblacc_banking_rule_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblacc_banking_rule_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rule_id` int(11) NOT NULL,
  `type` varchar(45) DEFAULT NULL,
  `subtype` varchar(45) DEFAULT NULL,
  `text` varchar(255) DEFAULT NULL,
  `subtype_amount` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_banking_rule_details`
--

LOCK TABLES `tblacc_banking_rule_details` WRITE;
/*!40000 ALTER TABLE `tblacc_banking_rule_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblacc_banking_rule_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblacc_banking_rules`
--

DROP TABLE IF EXISTS `tblacc_banking_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblacc_banking_rules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `transaction` varchar(45) DEFAULT NULL,
  `following` varchar(45) DEFAULT NULL,
  `then` varchar(45) DEFAULT NULL,
  `payment_account` int(11) DEFAULT NULL,
  `deposit_to` int(11) DEFAULT NULL,
  `auto_add` int(11) NOT NULL DEFAULT 0,
  `mapping_type` varchar(25) DEFAULT NULL,
  `account` int(11) DEFAULT NULL,
  `split_percentage` text DEFAULT NULL,
  `split_amount` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_banking_rules`
--

LOCK TABLES `tblacc_banking_rules` WRITE;
/*!40000 ALTER TABLE `tblacc_banking_rules` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblacc_banking_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblacc_bill_mappings`
--

DROP TABLE IF EXISTS `tblacc_bill_mappings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblacc_bill_mappings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bill_id` int(11) DEFAULT NULL,
  `type` varchar(25) DEFAULT NULL,
  `account` int(11) DEFAULT NULL,
  `amount` decimal(15,2) DEFAULT NULL,
  `item_id` int(11) NOT NULL DEFAULT 0,
  `qty` decimal(15,2) NOT NULL DEFAULT 0.00,
  `cost` decimal(15,2) NOT NULL DEFAULT 0.00,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_bill_mappings`
--

LOCK TABLES `tblacc_bill_mappings` WRITE;
/*!40000 ALTER TABLE `tblacc_bill_mappings` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblacc_bill_mappings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblacc_budget_details`
--

DROP TABLE IF EXISTS `tblacc_budget_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblacc_budget_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `budget_id` int(11) NOT NULL,
  `month` int(11) NOT NULL,
  `year` int(11) NOT NULL,
  `account` int(11) DEFAULT NULL,
  `amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_budget_details`
--

LOCK TABLES `tblacc_budget_details` WRITE;
/*!40000 ALTER TABLE `tblacc_budget_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblacc_budget_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblacc_budgets`
--

DROP TABLE IF EXISTS `tblacc_budgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblacc_budgets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `year` int(11) NOT NULL,
  `name` varchar(200) DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  `data_source` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_budgets`
--

LOCK TABLES `tblacc_budgets` WRITE;
/*!40000 ALTER TABLE `tblacc_budgets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblacc_budgets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblacc_check_details`
--

DROP TABLE IF EXISTS `tblacc_check_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblacc_check_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `check_id` int(11) DEFAULT NULL,
  `bill` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_check_details`
--

LOCK TABLES `tblacc_check_details` WRITE;
/*!40000 ALTER TABLE `tblacc_check_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblacc_check_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblacc_checks`
--

DROP TABLE IF EXISTS `tblacc_checks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblacc_checks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(25) DEFAULT NULL,
  `amount` decimal(15,2) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `memo` varchar(255) DEFAULT NULL,
  `dateadded` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `bank_account` int(11) NOT NULL,
  `number` int(11) NOT NULL,
  `signed` int(11) NOT NULL DEFAULT 0,
  `include_company_name_address` int(11) NOT NULL DEFAULT 1,
  `include_routing_account_numbers` int(11) NOT NULL DEFAULT 1,
  `bill` int(11) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `zip` varchar(15) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `issue` int(11) DEFAULT NULL,
  `include_check_number` int(11) NOT NULL DEFAULT 1,
  `include_bank_name` int(11) NOT NULL DEFAULT 1,
  `bank_name` varchar(255) DEFAULT NULL,
  `address_line_1` text DEFAULT NULL,
  `address_line_2` text DEFAULT NULL,
  `vendor_city` varchar(100) DEFAULT NULL,
  `vendor_zip` varchar(15) DEFAULT NULL,
  `vendor_state` varchar(50) DEFAULT NULL,
  `vendor_address` text DEFAULT NULL,
  `reason_for_void` text DEFAULT NULL,
  `bill_items` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_checks`
--

LOCK TABLES `tblacc_checks` WRITE;
/*!40000 ALTER TABLE `tblacc_checks` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblacc_checks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblacc_checks_printed`
--

DROP TABLE IF EXISTS `tblacc_checks_printed`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblacc_checks_printed` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `check_id` int(11) DEFAULT NULL,
  `bank_account` int(11) DEFAULT NULL,
  `first_check_number` int(11) DEFAULT NULL,
  `printed_at` datetime DEFAULT NULL,
  `printed_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_checks_printed`
--

LOCK TABLES `tblacc_checks_printed` WRITE;
/*!40000 ALTER TABLE `tblacc_checks_printed` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblacc_checks_printed` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblacc_expense_category_mapping_details`
--

DROP TABLE IF EXISTS `tblacc_expense_category_mapping_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblacc_expense_category_mapping_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_mapping_id` int(11) NOT NULL,
  `payment_mode_id` int(11) NOT NULL,
  `payment_account` int(11) NOT NULL DEFAULT 0,
  `deposit_to` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_expense_category_mapping_details`
--

LOCK TABLES `tblacc_expense_category_mapping_details` WRITE;
/*!40000 ALTER TABLE `tblacc_expense_category_mapping_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblacc_expense_category_mapping_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblacc_expense_category_mappings`
--

DROP TABLE IF EXISTS `tblacc_expense_category_mappings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblacc_expense_category_mappings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `payment_account` int(11) NOT NULL DEFAULT 0,
  `deposit_to` int(11) NOT NULL DEFAULT 0,
  `preferred_payment_method` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_expense_category_mappings`
--

LOCK TABLES `tblacc_expense_category_mappings` WRITE;
/*!40000 ALTER TABLE `tblacc_expense_category_mappings` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblacc_expense_category_mappings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblacc_income_statement_modifications`
--

DROP TABLE IF EXISTS `tblacc_income_statement_modifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblacc_income_statement_modifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `account` int(11) DEFAULT NULL,
  `active` int(11) NOT NULL DEFAULT 1,
  `account_type` int(11) DEFAULT NULL,
  `options` text DEFAULT NULL,
  `dateadded` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `type` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_income_statement_modifications`
--

LOCK TABLES `tblacc_income_statement_modifications` WRITE;
/*!40000 ALTER TABLE `tblacc_income_statement_modifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblacc_income_statement_modifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblacc_item_automatics`
--

DROP TABLE IF EXISTS `tblacc_item_automatics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblacc_item_automatics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL,
  `inventory_asset_account` int(11) NOT NULL DEFAULT 0,
  `income_account` int(11) NOT NULL DEFAULT 0,
  `expense_account` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_item_automatics`
--

LOCK TABLES `tblacc_item_automatics` WRITE;
/*!40000 ALTER TABLE `tblacc_item_automatics` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblacc_item_automatics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblacc_journal_entries`
--

DROP TABLE IF EXISTS `tblacc_journal_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblacc_journal_entries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `number` varchar(45) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `journal_date` date DEFAULT NULL,
  `amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `reference` varchar(100) DEFAULT NULL,
  `recurring` int(11) NOT NULL DEFAULT 0,
  `recurring_type` varchar(10) DEFAULT NULL,
  `custom_recurring` tinyint(1) NOT NULL DEFAULT 0,
  `cycles` int(11) NOT NULL DEFAULT 0,
  `total_cycles` int(11) NOT NULL DEFAULT 0,
  `is_recurring_from` int(11) DEFAULT NULL,
  `last_recurring_date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_journal_entries`
--

LOCK TABLES `tblacc_journal_entries` WRITE;
/*!40000 ALTER TABLE `tblacc_journal_entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblacc_journal_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblacc_matched_transactions`
--

DROP TABLE IF EXISTS `tblacc_matched_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblacc_matched_transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_history_id` int(11) DEFAULT NULL,
  `history_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(255) DEFAULT NULL,
  `amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `company` int(11) DEFAULT NULL,
  `reconcile` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_matched_transactions`
--

LOCK TABLES `tblacc_matched_transactions` WRITE;
/*!40000 ALTER TABLE `tblacc_matched_transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblacc_matched_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblacc_pay_bill_details`
--

DROP TABLE IF EXISTS `tblacc_pay_bill_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblacc_pay_bill_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pay_bill` int(11) DEFAULT NULL,
  `bill_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_pay_bill_details`
--

LOCK TABLES `tblacc_pay_bill_details` WRITE;
/*!40000 ALTER TABLE `tblacc_pay_bill_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblacc_pay_bill_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblacc_pay_bill_item_paid`
--

DROP TABLE IF EXISTS `tblacc_pay_bill_item_paid`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblacc_pay_bill_item_paid` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pay_bill_id` int(11) NOT NULL DEFAULT 0,
  `item_id` int(11) DEFAULT NULL,
  `item_name` varchar(255) DEFAULT NULL,
  `item_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `amount_paid` decimal(15,2) NOT NULL DEFAULT 0.00,
  `check_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_pay_bill_item_paid`
--

LOCK TABLES `tblacc_pay_bill_item_paid` WRITE;
/*!40000 ALTER TABLE `tblacc_pay_bill_item_paid` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblacc_pay_bill_item_paid` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblacc_pay_bills`
--

DROP TABLE IF EXISTS `tblacc_pay_bills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblacc_pay_bills` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `expense` int(11) DEFAULT NULL,
  `amount` decimal(15,2) DEFAULT NULL,
  `reference_no` varchar(100) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `dateadded` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `company` int(11) DEFAULT NULL,
  `account_debit` int(11) DEFAULT NULL,
  `account_credit` int(11) DEFAULT NULL,
  `bill` int(11) NOT NULL DEFAULT 0,
  `vendor` int(11) NOT NULL DEFAULT 0,
  `pay_number` int(11) DEFAULT NULL,
  `payment_method` varchar(255) DEFAULT NULL,
  `bill_items` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_pay_bills`
--

LOCK TABLES `tblacc_pay_bills` WRITE;
/*!40000 ALTER TABLE `tblacc_pay_bills` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblacc_pay_bills` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblacc_payment_mode_mappings`
--

DROP TABLE IF EXISTS `tblacc_payment_mode_mappings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblacc_payment_mode_mappings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `payment_mode_id` int(11) NOT NULL,
  `payment_account` int(11) NOT NULL DEFAULT 0,
  `deposit_to` int(11) NOT NULL DEFAULT 0,
  `expense_payment_account` int(11) NOT NULL DEFAULT 0,
  `expense_deposit_to` int(11) NOT NULL DEFAULT 0,
  `credit_note_refund_payment_account` int(11) NOT NULL DEFAULT 0,
  `credit_note_refund_deposit_to` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_payment_mode_mappings`
--

LOCK TABLES `tblacc_payment_mode_mappings` WRITE;
/*!40000 ALTER TABLE `tblacc_payment_mode_mappings` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblacc_payment_mode_mappings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblacc_plaid_transaction_logs`
--

DROP TABLE IF EXISTS `tblacc_plaid_transaction_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblacc_plaid_transaction_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bank_id` int(11) DEFAULT NULL,
  `last_updated` date DEFAULT NULL,
  `transaction_count` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `addedFrom` int(11) DEFAULT NULL,
  `company` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_plaid_transaction_logs`
--

LOCK TABLES `tblacc_plaid_transaction_logs` WRITE;
/*!40000 ALTER TABLE `tblacc_plaid_transaction_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblacc_plaid_transaction_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblacc_print_later`
--

DROP TABLE IF EXISTS `tblacc_print_later`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblacc_print_later` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(45) DEFAULT NULL,
  `account` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_print_later`
--

LOCK TABLES `tblacc_print_later` WRITE;
/*!40000 ALTER TABLE `tblacc_print_later` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblacc_print_later` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblacc_reconciles`
--

DROP TABLE IF EXISTS `tblacc_reconciles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblacc_reconciles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account` int(11) NOT NULL,
  `beginning_balance` decimal(15,2) NOT NULL,
  `ending_balance` decimal(15,2) NOT NULL,
  `ending_date` date NOT NULL,
  `expense_date` date DEFAULT NULL,
  `service_charge` decimal(15,2) DEFAULT NULL,
  `expense_account` int(11) DEFAULT NULL,
  `income_date` date DEFAULT NULL,
  `interest_earned` decimal(15,2) DEFAULT NULL,
  `income_account` int(11) DEFAULT NULL,
  `finish` int(11) NOT NULL DEFAULT 0,
  `opening_balance` int(11) NOT NULL DEFAULT 0,
  `debits_for_period` decimal(15,2) DEFAULT NULL,
  `credits_for_period` decimal(15,2) DEFAULT NULL,
  `dateadded` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_reconciles`
--

LOCK TABLES `tblacc_reconciles` WRITE;
/*!40000 ALTER TABLE `tblacc_reconciles` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblacc_reconciles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblacc_tax_mappings`
--

DROP TABLE IF EXISTS `tblacc_tax_mappings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblacc_tax_mappings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tax_id` int(11) NOT NULL,
  `payment_account` int(11) NOT NULL DEFAULT 0,
  `deposit_to` int(11) NOT NULL DEFAULT 0,
  `expense_payment_account` int(11) NOT NULL DEFAULT 0,
  `expense_deposit_to` int(11) NOT NULL DEFAULT 0,
  `purchase_payment_account` int(11) NOT NULL DEFAULT 0,
  `purchase_deposit_to` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_tax_mappings`
--

LOCK TABLES `tblacc_tax_mappings` WRITE;
/*!40000 ALTER TABLE `tblacc_tax_mappings` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblacc_tax_mappings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblacc_transaction_bankings`
--

DROP TABLE IF EXISTS `tblacc_transaction_bankings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblacc_transaction_bankings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `withdrawals` decimal(15,2) NOT NULL DEFAULT 0.00,
  `deposits` decimal(15,2) NOT NULL DEFAULT 0.00,
  `payee` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `transaction_id` varchar(150) DEFAULT NULL,
  `bank_id` int(11) DEFAULT NULL,
  `status` tinyint(5) NOT NULL DEFAULT 0 COMMENT '1=>posted, 2=>pending',
  `matched` int(11) NOT NULL DEFAULT 0,
  `reconcile` int(11) NOT NULL DEFAULT 0,
  `adjusted` int(11) NOT NULL DEFAULT 0,
  `is_imported` int(11) NOT NULL DEFAULT 0,
  `banking_rule` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_transaction_bankings`
--

LOCK TABLES `tblacc_transaction_bankings` WRITE;
/*!40000 ALTER TABLE `tblacc_transaction_bankings` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblacc_transaction_bankings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblacc_transfers`
--

DROP TABLE IF EXISTS `tblacc_transfers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblacc_transfers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transfer_funds_from` int(11) NOT NULL,
  `transfer_funds_to` int(11) NOT NULL,
  `transfer_amount` decimal(15,2) DEFAULT NULL,
  `date` varchar(45) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblacc_transfers`
--

LOCK TABLES `tblacc_transfers` WRITE;
/*!40000 ALTER TABLE `tblacc_transfers` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblacc_transfers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblaccount_planning`
--

DROP TABLE IF EXISTS `tblaccount_planning`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblaccount_planning` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) NOT NULL,
  `vision` varchar(255) DEFAULT NULL,
  `mission` varchar(255) DEFAULT NULL,
  `lead_generation` varchar(45) DEFAULT NULL,
  `current_service_know_pmax` varchar(45) DEFAULT NULL,
  `current_service_facebook` varchar(45) DEFAULT NULL,
  `current_service_sem` varchar(45) DEFAULT NULL,
  `objectives` varchar(255) DEFAULT NULL,
  `threat` varchar(255) DEFAULT NULL,
  `opportunity` varchar(255) DEFAULT NULL,
  `criteria_to_success` varchar(255) DEFAULT NULL,
  `constraints` varchar(255) DEFAULT NULL,
  `data_tree` longtext DEFAULT NULL,
  `latest_update` date DEFAULT NULL,
  `new_update` date DEFAULT NULL,
  `product` varchar(255) DEFAULT NULL,
  `sale_channel_online` varchar(255) DEFAULT NULL,
  `sale_channel_offline` varchar(255) DEFAULT NULL,
  `revenue_next_year` varchar(255) DEFAULT NULL,
  `wallet_share` varchar(255) DEFAULT NULL,
  `client_status` varchar(255) DEFAULT NULL,
  `bcg_model` varchar(255) DEFAULT NULL,
  `margin` varchar(255) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblaccount_planning`
--

LOCK TABLES `tblaccount_planning` WRITE;
/*!40000 ALTER TABLE `tblaccount_planning` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblaccount_planning` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblaccount_planning_current_service`
--

DROP TABLE IF EXISTS `tblaccount_planning_current_service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblaccount_planning_current_service` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_planning_id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `potential` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblaccount_planning_current_service`
--

LOCK TABLES `tblaccount_planning_current_service` WRITE;
/*!40000 ALTER TABLE `tblaccount_planning_current_service` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblaccount_planning_current_service` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblaccount_planning_financial`
--

DROP TABLE IF EXISTS `tblaccount_planning_financial`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblaccount_planning_financial` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_planning_id` int(11) NOT NULL,
  `year` varchar(45) DEFAULT NULL,
  `revenue` varchar(255) DEFAULT NULL,
  `sales_spent` varchar(255) DEFAULT NULL,
  `traffic` varchar(255) DEFAULT NULL,
  `loss` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblaccount_planning_financial`
--

LOCK TABLES `tblaccount_planning_financial` WRITE;
/*!40000 ALTER TABLE `tblaccount_planning_financial` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblaccount_planning_financial` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblaccount_planning_items`
--

DROP TABLE IF EXISTS `tblaccount_planning_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblaccount_planning_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_planning_id` int(11) NOT NULL,
  `objective_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `datecreated` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblaccount_planning_items`
--

LOCK TABLES `tblaccount_planning_items` WRITE;
/*!40000 ALTER TABLE `tblaccount_planning_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblaccount_planning_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblaccount_planning_marketing_activities`
--

DROP TABLE IF EXISTS `tblaccount_planning_marketing_activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblaccount_planning_marketing_activities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_planning_id` int(11) NOT NULL,
  `item` varchar(255) DEFAULT NULL,
  `reference` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblaccount_planning_marketing_activities`
--

LOCK TABLES `tblaccount_planning_marketing_activities` WRITE;
/*!40000 ALTER TABLE `tblaccount_planning_marketing_activities` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblaccount_planning_marketing_activities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblaccount_planning_objective`
--

DROP TABLE IF EXISTS `tblaccount_planning_objective`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblaccount_planning_objective` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_planning_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `datecreated` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblaccount_planning_objective`
--

LOCK TABLES `tblaccount_planning_objective` WRITE;
/*!40000 ALTER TABLE `tblaccount_planning_objective` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblaccount_planning_objective` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblaccount_planning_service_ability_offering`
--

DROP TABLE IF EXISTS `tblaccount_planning_service_ability_offering`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblaccount_planning_service_ability_offering` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_planning_id` int(11) NOT NULL,
  `service` varchar(255) DEFAULT NULL,
  `potential` varchar(255) DEFAULT NULL,
  `scale` varchar(255) DEFAULT NULL,
  `convert` varchar(255) DEFAULT NULL,
  `prioritization` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblaccount_planning_service_ability_offering`
--

LOCK TABLES `tblaccount_planning_service_ability_offering` WRITE;
/*!40000 ALTER TABLE `tblaccount_planning_service_ability_offering` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblaccount_planning_service_ability_offering` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblaccount_planning_task`
--

DROP TABLE IF EXISTS `tblaccount_planning_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblaccount_planning_task` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL,
  `account_planning_id` int(11) DEFAULT NULL,
  `action_needed` varchar(255) NOT NULL,
  `prioritization` varchar(255) DEFAULT NULL,
  `pic` varchar(255) DEFAULT NULL,
  `deadline` date DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `objective` varchar(255) DEFAULT NULL,
  `item` varchar(255) DEFAULT NULL,
  `convert_to_task` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblaccount_planning_task`
--

LOCK TABLES `tblaccount_planning_task` WRITE;
/*!40000 ALTER TABLE `tblaccount_planning_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblaccount_planning_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblaccount_planning_team`
--

DROP TABLE IF EXISTS `tblaccount_planning_team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblaccount_planning_team` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_planning_id` int(11) NOT NULL,
  `rel_id` varchar(45) NOT NULL,
  `rel_type` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblaccount_planning_team`
--

LOCK TABLES `tblaccount_planning_team` WRITE;
/*!40000 ALTER TABLE `tblaccount_planning_team` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblaccount_planning_team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblactivity_log`
--

DROP TABLE IF EXISTS `tblactivity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblactivity_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` longtext NOT NULL,
  `date` datetime NOT NULL,
  `staffid` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `staffid` (`staffid`)
) ENGINE=InnoDB AUTO_INCREMENT=130 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblactivity_log`
--

LOCK TABLES `tblactivity_log` WRITE;
/*!40000 ALTER TABLE `tblactivity_log` DISABLE KEYS */;
INSERT INTO `tblactivity_log` VALUES (1,'Non Existing User Tried to Login [Email: info.vikaasyadav@gmail.com, Is Staff Member: No, IP: 157.48.80.182]','2025-06-25 21:13:25',NULL),(2,'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 157.48.80.182]','2025-06-25 21:13:36','Vikas Yadav'),(3,'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 157.48.80.182]','2025-06-25 22:54:38','Vikas Yadav'),(4,'New Client Created [ID: 1, From Staff: 1]','2025-06-25 23:46:11','Vikas Yadav'),(5,'Contact Created [ID: 1]','2025-06-25 23:46:56','Vikas Yadav'),(6,'User Successfully Logged In [User Id: 1, Is Staff Member: No, IP: 157.48.80.182]','2025-06-25 23:47:45','Dayanand yadav'),(7,'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 157.48.80.182]','2025-06-25 23:51:22','Vikas Yadav'),(8,'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 157.48.80.182]','2025-06-26 05:52:55','Vikas Yadav'),(9,'New Currency Added [ID: INR]','2025-06-26 06:03:11','Vikas Yadav'),(10,'Currency Deleted [2]','2025-06-26 06:03:23','Vikas Yadav'),(11,'User Successfully Logged In [User Id: 1, Is Staff Member: No, IP: 157.48.80.182]','2025-06-26 06:59:48','Dayanand yadav'),(12,'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 157.48.82.220]','2025-06-26 12:14:21','Vikas Yadav'),(13,'Non Existing User Tried to Login [Email: sales@techdotbit.com, Is Staff Member: Yes, IP: 106.219.224.219]','2025-06-26 13:30:19',NULL),(14,'Non Existing User Tried to Login [Email: sales@techdotbit.com, Is Staff Member: Yes, IP: 106.219.224.219]','2025-06-26 13:30:28',NULL),(15,'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 157.48.82.220]','2025-06-26 15:44:39','Vikas Yadav'),(16,'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 157.48.82.220]','2025-06-26 15:57:10','Vikas Yadav'),(17,'Contact Created [ID: 2]','2025-06-26 17:11:40',NULL),(18,'New Client Created [ID: 2]','2025-06-26 17:11:40',NULL),(19,'User Successfully Logged In [User Id: 2, Is Staff Member: No, IP: 157.48.82.220]','2025-06-26 17:11:40','Dayanand Sweden'),(20,'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 157.48.82.220]','2025-06-26 19:58:35','Vikas Yadav'),(21,'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 157.48.221.10]','2025-06-27 06:47:36','Vikas Yadav'),(22,'Failed Login Attempt [Email: info.vikaasyadav@gmail.com, Is Staff Member: No, IP: 2409:40d4:10cd:43f8:f408:13f9:e02c:5190]','2025-06-27 10:39:19',NULL),(23,'Failed Login Attempt [Email: info.vikaasyadav@gmail.com, Is Staff Member: Yes, IP: 2409:40d4:10cd:43f8:f408:13f9:e02c:5190]','2025-06-27 10:39:37',NULL),(24,'Failed Login Attempt [Email: info.vikaasyadav@gmail.com, Is Staff Member: Yes, IP: 2409:40d4:10cd:43f8:f408:13f9:e02c:5190]','2025-06-27 10:39:44',NULL),(25,'User Successfully Logged In [User Id: 2, Is Staff Member: No, IP: 2409:40d4:10cd:43f8:f408:13f9:e02c:5190]','2025-06-27 10:57:07','Dayanand Sweden'),(26,'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 2409:40d4:10cd:43f8:f408:13f9:e02c:5190]','2025-06-27 11:02:09','Dayanand Sweden'),(27,'Failed Login Attempt [Email: info.vikaasyadav@gmail.com, Is Staff Member: No, IP: 2409:40d4:10cd:43f8:f408:13f9:e02c:5190]','2025-06-27 11:32:14','Vikas Yadav'),(28,'User Successfully Logged In [User Id: 2, Is Staff Member: No, IP: 2409:40d4:10cd:43f8:f408:13f9:e02c:5190]','2025-06-27 11:32:24','Dayanand Sweden'),(29,'Contact Created [ID: 3]','2025-06-27 11:57:11',NULL),(30,'New Client Created [ID: 3]','2025-06-27 11:57:11',NULL),(31,'User Successfully Logged In [User Id: 3, Is Staff Member: No, IP: 2409:40d4:10cd:43f8:f408:13f9:e02c:5190]','2025-06-27 11:57:11','Dayanand yadav'),(32,'User Successfully Logged In [User Id: 3, Is Staff Member: No, IP: 2409:40d4:10cd:43f8:f408:13f9:e02c:5190]','2025-06-27 12:01:57','Dayanand yadav'),(33,'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 2409:40d4:10cd:43f8:f408:13f9:e02c:5190]','2025-06-27 12:03:06','Vikas Yadav'),(34,'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 2409:40d4:10cd:43f8:f408:13f9:e02c:5190]','2025-06-27 12:54:06','Vikas Yadav'),(35,'Contact Created [ID: 4]','2025-06-27 12:54:54',NULL),(36,'New Client Created [ID: 4]','2025-06-27 12:54:55',NULL),(37,'User Successfully Logged In [User Id: 4, Is Staff Member: No, IP: 2409:40d4:10cd:43f8:f408:13f9:e02c:5190]','2025-06-27 12:54:55','Dayanand yadav'),(38,'Failed Login Attempt [Email: info.vikaasyadav@gmail.com, Is Staff Member: Yes, IP: 2409:40d4:10cd:43f8:f408:13f9:e02c:5190]','2025-06-27 15:16:39',NULL),(39,'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 2409:40d4:10cd:43f8:f408:13f9:e02c:5190]','2025-06-27 15:16:46','Vikas Yadav'),(40,'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 2409:40d4:10cd:43f8:ccef:f512:e762:56b2]','2025-06-28 08:24:50','Vikas Yadav'),(41,'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 2409:40d4:10cd:43f8:ccef:f512:e762:56b2]','2025-06-29 08:44:49','Vikas Yadav'),(42,'User Successfully Logged In [User Id: 4, Is Staff Member: No, IP: 2409:40d4:10cd:43f8:ccef:f512:e762:56b2]','2025-06-29 10:34:08','Dayanand yadav'),(43,'User Successfully Logged In [User Id: 4, Is Staff Member: No, IP: 2405:201:4018:225d:9952:89b6:f4e2:c984]','2025-07-01 16:36:42','Dayanand yadav'),(44,'Failed Login Attempt [Email: info.vikaasyadav@gmail.com, Is Staff Member: No, IP: 2405:201:4018:225d:9952:89b6:f4e2:c984]','2025-07-01 16:37:19',NULL),(45,'Failed Login Attempt [Email: info.vikaasyadav@gmail.com, Is Staff Member: Yes, IP: 2405:201:4018:225d:9952:89b6:f4e2:c984]','2025-07-01 16:37:35',NULL),(46,'Failed Login Attempt [Email: info.vikaasyadav@gmail.com, Is Staff Member: Yes, IP: 2405:201:4018:225d:9952:89b6:f4e2:c984]','2025-07-01 16:37:38',NULL),(47,'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 2405:201:4018:225d:9952:89b6:f4e2:c984]','2025-07-01 16:37:45','Vikas Yadav'),(48,'User Successfully Logged In [User Id: 4, Is Staff Member: No, IP: 2405:201:4018:225d:9952:89b6:f4e2:c984]','2025-07-01 16:40:29','Dayanand yadav'),(49,'Contact Created [ID: 5]','2025-07-01 17:24:38',NULL),(50,'New Client Created [ID: 5]','2025-07-01 17:24:38',NULL),(51,'User Successfully Logged In [User Id: 5, Is Staff Member: No, IP: 2405:201:4018:225d:25a3:777b:1fb8:f323]','2025-07-01 17:24:38','Vishal Shankar'),(52,'Non Existing User Tried to Login [Email: sales@techdotbit.com, Is Staff Member: Yes, IP: 2405:201:4018:225d:25a3:777b:1fb8:f323]','2025-07-01 17:26:26','Vishal Shankar'),(53,'Non Existing User Tried to Login [Email: sales@techdotbit.com, Is Staff Member: Yes, IP: 2405:201:4018:225d:25a3:777b:1fb8:f323]','2025-07-01 17:26:41','Vishal Shankar'),(54,'User Successfully Logged In [User Id: 2, Is Staff Member: No, IP: 49.36.189.194]','2025-07-05 14:27:46','Dayanand Sweden'),(55,'Failed Login Attempt [Email: info.vikaasyadav@gmail.com, Is Staff Member: Yes, IP: 103.39.118.49]','2025-07-06 20:04:11',NULL),(56,'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 103.39.118.49]','2025-07-06 20:04:22','Vikas Yadav'),(57,'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 103.39.118.49]','2025-07-06 20:05:27','Vikas Yadav'),(58,'Contact Created [ID: 6]','2025-07-06 20:07:29','Vikas Yadav'),(59,'New Client Created [ID: 6, From Staff: 1]','2025-07-06 20:07:29','Vikas Yadav'),(60,'User Successfully Logged In [User Id: 6, Is Staff Member: No, IP: 103.39.118.49]','2025-07-06 20:07:29','Deepanshu Sharma'),(61,'Contact Created [ID: 7]','2025-07-06 23:11:49',NULL),(62,'New Client Created [ID: 7]','2025-07-06 23:11:49',NULL),(63,'User Successfully Logged In [User Id: 7, Is Staff Member: No, IP: 103.39.118.49]','2025-07-06 23:11:49','Vikas Yadav'),(64,'Contact Created [ID: 8]','2025-07-06 23:27:10',NULL),(65,'New Client Created [ID: 8]','2025-07-06 23:27:10',NULL),(66,'User Successfully Logged In [User Id: 8, Is Staff Member: No, IP: 103.39.118.49]','2025-07-06 23:27:10','Sahil Oswal'),(67,'Contact Created [ID: 9]','2025-07-06 23:57:08',NULL),(68,'New Client Created [ID: 9]','2025-07-06 23:57:08',NULL),(69,'User Successfully Logged In [User Id: 9, Is Staff Member: No, IP: 103.39.118.49]','2025-07-06 23:57:08','3456765 yadav'),(70,'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 103.39.118.49]','2025-07-07 00:06:49','Vikas Yadav'),(71,'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 49.36.189.194]','2025-07-07 10:44:30','Vikas Yadav'),(72,'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 49.36.189.194]','2025-07-07 10:44:30','Vikas Yadav'),(73,'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 49.36.189.194]','2025-07-07 15:40:45','Vikas Yadav'),(74,'Failed Login Attempt [Email: info.vikaasyadav@gmail.com, Is Staff Member: No, IP: 49.36.189.194]','2025-07-07 15:42:05','Vikas Yadav'),(75,'Invoice Status Updated [Invoice Number: INV-000002, From: Unpaid To: Paid]','2025-07-07 16:00:47','Vikas Yadav'),(76,'Payment Recorded [ID:1, Invoice Number: INV-000002, Total: ₹18,000.00]','2025-07-07 16:00:47','Vikas Yadav'),(77,'Contact Created [ID: 10]','2025-07-07 16:10:39',NULL),(78,'New Client Created [ID: 10]','2025-07-07 16:10:39',NULL),(79,'User Successfully Logged In [User Id: 10, Is Staff Member: No, IP: 49.36.189.194]','2025-07-07 16:10:39','Deepanshu Sharma'),(80,'Contact Created [ID: 11]','2025-07-07 18:06:11',NULL),(81,'New Client Created [ID: 11]','2025-07-07 18:06:11',NULL),(82,'User Successfully Logged In [User Id: 11, Is Staff Member: No, IP: 110.172.155.237]','2025-07-07 18:06:11','faizan ahmad'),(83,'Email Sent To [Email: sahil@techdotbit.com, Template: New Contact Added/Registered (Welcome Email)]','2025-07-08 00:22:20',NULL),(84,'Email Sent To [Email: sahil@techdotbit.com, Template: Email Verification (Sent to Contact After Registration)]','2025-07-08 00:22:22',NULL),(85,'Contact Created [ID: 12]','2025-07-08 00:22:22',NULL),(86,'New Client Created [ID: 12]','2025-07-08 00:22:22',NULL),(87,'User Successfully Logged In [User Id: 12, Is Staff Member: No, IP: 49.36.189.194]','2025-07-08 00:22:22','Sahil Oswal'),(88,'Email Sent To [Email: info.vikaasyadav@gmail.com, Template: New Customer Registration (Sent to admins)]','2025-07-08 00:22:25','Sahil Oswal'),(89,'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 49.36.189.194]','2025-07-08 00:23:06','Deepanshu Sharma'),(90,'Contact Updated [ID: 12]','2025-07-08 00:23:31','Vikas Yadav'),(91,'Email Sent To [Email: vikas@techdotbit.com, Template: Email Verification (Sent to Contact After Registration)]','2025-07-08 00:23:46','Sahil Oswal'),(92,'Email Sent To [Email: vikas@techdotbit.com, Template: Deployed CRM instance]','2025-07-08 00:24:14','Sahil Oswal'),(93,'Email Sent To [Email: info.vikaasyadav@gmail.com, Template: Deployed CRM instance for admin]','2025-07-08 00:24:17','Sahil Oswal'),(94,'Failed Login Attempt [Email: info.vikaasyadav@gmail.com, Is Staff Member: Yes, IP: 49.36.189.194]','2025-07-08 09:37:04',NULL),(95,'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 49.36.189.194]','2025-07-08 09:37:12','Vikas Yadav'),(96,'Client Deleted [ID: 7]','2025-07-08 09:43:46','Vikas Yadav'),(97,'Client Deleted [ID: 1]','2025-07-08 09:43:46','Vikas Yadav'),(98,'Client Deleted [ID: 8]','2025-07-08 09:43:46','Vikas Yadav'),(99,'Client Deleted [ID: 3]','2025-07-08 09:43:46','Vikas Yadav'),(100,'Client Deleted [ID: 2]','2025-07-08 09:43:46','Vikas Yadav'),(101,'Client Deleted [ID: 5]','2025-07-08 09:43:46','Vikas Yadav'),(102,'Client Deleted [ID: 6]','2025-07-08 09:43:46','Vikas Yadav'),(103,'Invoice Deleted [INV-000002]','2025-07-08 09:44:30','Vikas Yadav'),(104,'Invoice Deleted [INV-000001]','2025-07-08 09:44:41','Vikas Yadav'),(105,'Contact Updated [ID: 10]','2025-07-08 09:50:19','Vikas Yadav'),(106,'Email Sent To [Email: szw@gmail.com, Template: Removed CRM instance]','2025-07-08 09:59:56','Vikas Yadav'),(107,'Email Sent To [Email: info.vikaasyadav@gmail.com, Template: Removed CRM instance for admin]','2025-07-08 09:59:58','Vikas Yadav'),(108,'New Tax Added [ID: 1, CGST]','2025-07-08 10:14:03','Vikas Yadav'),(109,'New Tax Added [ID: 2, SGST]','2025-07-08 10:17:38','Vikas Yadav'),(110,'New Tax Added [ID: 3, UGST]','2025-07-08 10:17:47','Vikas Yadav'),(111,'New Tax Added [ID: 4, IGST]','2025-07-08 10:17:57','Vikas Yadav'),(112,'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 49.36.189.194]','2025-07-08 10:30:33','Vikas Yadav'),(113,'Customer Info Updated [ID: 11]','2025-07-08 10:37:50','Vikas Yadav'),(114,'Customer Info Updated [ID: 11]','2025-07-08 10:39:48','Vikas Yadav'),(115,'Customer Info Updated [ID: 11]','2025-07-08 10:40:04','Vikas Yadav'),(116,'Client Deleted [ID: 9]','2025-07-08 10:43:11','Vikas Yadav'),(117,'Client Deleted [ID: 4]','2025-07-08 10:43:15','Vikas Yadav'),(118,'Invoice Status Updated [Invoice Number: INV-000002, From: Unpaid To: Paid]','2025-07-08 10:54:15','Vikas Yadav'),(119,'Payment Recorded [ID:2, Invoice Number: INV-000002, Total: ₹18,000.00]','2025-07-08 10:54:15','Vikas Yadav'),(120,'Email Sent To [Email: md@spliceply.com, Template: Invoice Payment Recorded (Sent to Customer)]','2025-07-08 10:54:18','Vikas Yadav'),(121,'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 49.36.189.194]','2025-07-08 10:56:45','Vikas Yadav'),(122,'Non Existing User Tried to Login [Email: info.vikaasyadav@gmail.comi, Is Staff Member: Yes, IP: 106.219.229.39]','2025-07-08 11:45:25',NULL),(123,'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 106.219.229.39]','2025-07-08 11:45:44','Vikas Yadav'),(124,'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 49.36.189.194]','2025-07-08 13:08:09','Vikas Yadav'),(125,'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 49.36.189.194]','2025-07-08 13:22:24','Vikas Yadav'),(126,'Failed Login Attempt [Email: info.vikaasyadav@gmail.com, Is Staff Member: Yes, IP: 49.36.189.194]','2025-07-08 14:12:43',NULL),(127,'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 49.36.189.194]','2025-07-08 14:12:51','Vikas Yadav'),(128,'Email Sent To [Email: vikas@techdotbit.com, Template: Removed CRM instance]','2025-07-08 14:14:46','Vikas Yadav'),(129,'Email Sent To [Email: info.vikaasyadav@gmail.com, Template: Removed CRM instance for admin]','2025-07-08 14:14:51','Vikas Yadav');
/*!40000 ALTER TABLE `tblactivity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblaffiliate_m_affiliates`
--

DROP TABLE IF EXISTS `tblaffiliate_m_affiliates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblaffiliate_m_affiliates` (
  `affiliate_id` int(11) NOT NULL AUTO_INCREMENT,
  `affiliate_slug` varchar(255) NOT NULL,
  `group_id` varchar(255) DEFAULT NULL,
  `contact_id` int(11) NOT NULL,
  `total_earnings` decimal(10,2) DEFAULT 0.00,
  `balance` decimal(10,2) DEFAULT 0.00,
  `status` varchar(255) DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`affiliate_id`),
  UNIQUE KEY `unique_tbl_contact_id` (`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblaffiliate_m_affiliates`
--

LOCK TABLES `tblaffiliate_m_affiliates` WRITE;
/*!40000 ALTER TABLE `tblaffiliate_m_affiliates` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblaffiliate_m_affiliates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblaffiliate_m_commissions`
--

DROP TABLE IF EXISTS `tblaffiliate_m_commissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblaffiliate_m_commissions` (
  `commission_id` int(11) NOT NULL AUTO_INCREMENT,
  `referral_id` int(11) NOT NULL,
  `affiliate_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `payment_id` int(11) DEFAULT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `rule_info` varchar(255) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`commission_id`),
  KEY `fk_tbl_commission_referral_id` (`referral_id`),
  KEY `fk_tbl_commission_affiliate_id` (`affiliate_id`),
  CONSTRAINT `fk_tbl_commission_affiliate_id` FOREIGN KEY (`affiliate_id`) REFERENCES `tblaffiliate_m_affiliates` (`affiliate_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tbl_commission_referral_id` FOREIGN KEY (`referral_id`) REFERENCES `tblaffiliate_m_referrals` (`referral_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblaffiliate_m_commissions`
--

LOCK TABLES `tblaffiliate_m_commissions` WRITE;
/*!40000 ALTER TABLE `tblaffiliate_m_commissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblaffiliate_m_commissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblaffiliate_m_payouts`
--

DROP TABLE IF EXISTS `tblaffiliate_m_payouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblaffiliate_m_payouts` (
  `payout_id` int(11) NOT NULL AUTO_INCREMENT,
  `affiliate_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `note_for_affiliate` text DEFAULT NULL,
  `note_for_admin` text DEFAULT NULL,
  `payout_method` varchar(255) NOT NULL,
  `status` varchar(255) DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`payout_id`),
  KEY `fk_tbl_afm_payout_affiliate_id` (`affiliate_id`),
  CONSTRAINT `fk_tbl_afm_payout_affiliate_id` FOREIGN KEY (`affiliate_id`) REFERENCES `tblaffiliate_m_affiliates` (`affiliate_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblaffiliate_m_payouts`
--

LOCK TABLES `tblaffiliate_m_payouts` WRITE;
/*!40000 ALTER TABLE `tblaffiliate_m_payouts` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblaffiliate_m_payouts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblaffiliate_m_referrals`
--

DROP TABLE IF EXISTS `tblaffiliate_m_referrals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblaffiliate_m_referrals` (
  `referral_id` int(11) NOT NULL AUTO_INCREMENT,
  `affiliate_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `ua` text DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`referral_id`),
  UNIQUE KEY `unique_tbl_client_id` (`client_id`),
  KEY `fk_tbl_referral_affiliate_id` (`affiliate_id`),
  CONSTRAINT `fk_tbl_referral_affiliate_id` FOREIGN KEY (`affiliate_id`) REFERENCES `tblaffiliate_m_affiliates` (`affiliate_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblaffiliate_m_referrals`
--

LOCK TABLES `tblaffiliate_m_referrals` WRITE;
/*!40000 ALTER TABLE `tblaffiliate_m_referrals` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblaffiliate_m_referrals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblaffiliate_m_tracking`
--

DROP TABLE IF EXISTS `tblaffiliate_m_tracking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblaffiliate_m_tracking` (
  `tracking_id` int(11) NOT NULL AUTO_INCREMENT,
  `affiliate_slug` varchar(255) NOT NULL,
  `rel_type` varchar(255) NOT NULL,
  `rel_id` int(11) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phonenumber` varchar(255) DEFAULT NULL,
  `metadata` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`tracking_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblaffiliate_m_tracking`
--

LOCK TABLES `tblaffiliate_m_tracking` WRITE;
/*!40000 ALTER TABLE `tblaffiliate_m_tracking` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblaffiliate_m_tracking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblannouncements`
--

DROP TABLE IF EXISTS `tblannouncements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblannouncements` (
  `announcementid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `message` mediumtext DEFAULT NULL,
  `showtousers` int(11) NOT NULL,
  `showtostaff` int(11) NOT NULL,
  `showname` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  `userid` varchar(100) NOT NULL,
  PRIMARY KEY (`announcementid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblannouncements`
--

LOCK TABLES `tblannouncements` WRITE;
/*!40000 ALTER TABLE `tblannouncements` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblannouncements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblbom_scrap`
--

DROP TABLE IF EXISTS `tblbom_scrap`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblbom_scrap` (
  `ScrapID` int(11) NOT NULL,
  `product_id` int(255) NOT NULL,
  `item_type` int(11) NOT NULL,
  `unit_id` int(255) NOT NULL,
  `scrap_type` enum('reuse','waste') NOT NULL DEFAULT 'waste',
  `estimated_quantity` decimal(10,2) DEFAULT NULL,
  `scrap_location_id` int(11) DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `bill_of_material_id` int(11) NOT NULL,
  `routing_id` int(11) NOT NULL,
  `operation_id` int(11) NOT NULL,
  `bill_of_material_product_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblbom_scrap`
--

LOCK TABLES `tblbom_scrap` WRITE;
/*!40000 ALTER TABLE `tblbom_scrap` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblbom_scrap` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblbonus_discipline`
--

DROP TABLE IF EXISTS `tblbonus_discipline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblbonus_discipline` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `id_criteria` varchar(200) DEFAULT NULL,
  `type` int(3) NOT NULL,
  `apply_for` varchar(50) DEFAULT NULL,
  `from_time` datetime DEFAULT NULL,
  `lever_bonus` int(11) DEFAULT NULL,
  `approver` int(11) DEFAULT NULL,
  `url_file` longtext DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `id_admin` int(3) DEFAULT NULL,
  `status` int(3) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblbonus_discipline`
--

LOCK TABLES `tblbonus_discipline` WRITE;
/*!40000 ALTER TABLE `tblbonus_discipline` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblbonus_discipline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblbonus_discipline_detail`
--

DROP TABLE IF EXISTS `tblbonus_discipline_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblbonus_discipline_detail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_bonus_discipline` int(11) NOT NULL,
  `from_time` datetime DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `department_id` longtext DEFAULT NULL,
  `lever_bonus` int(11) DEFAULT NULL,
  `formality` varchar(50) DEFAULT NULL,
  `formality_value` varchar(100) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblbonus_discipline_detail`
--

LOCK TABLES `tblbonus_discipline_detail` WRITE;
/*!40000 ALTER TABLE `tblbonus_discipline_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblbonus_discipline_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblcd_care`
--

DROP TABLE IF EXISTS `tblcd_care`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblcd_care` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `candidate` int(11) NOT NULL,
  `care_time` datetime NOT NULL,
  `care_result` text NOT NULL,
  `description` text DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  `add_time` datetime DEFAULT NULL,
  `type` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcd_care`
--

LOCK TABLES `tblcd_care` WRITE;
/*!40000 ALTER TABLE `tblcd_care` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblcd_care` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblcd_family_infor`
--

DROP TABLE IF EXISTS `tblcd_family_infor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblcd_family_infor` (
  `fi_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `candidate` int(11) NOT NULL,
  `relationship` varchar(100) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `fi_birthday` date DEFAULT NULL,
  `job` varchar(200) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `phone` int(15) DEFAULT NULL,
  PRIMARY KEY (`fi_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcd_family_infor`
--

LOCK TABLES `tblcd_family_infor` WRITE;
/*!40000 ALTER TABLE `tblcd_family_infor` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblcd_family_infor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblcd_interview`
--

DROP TABLE IF EXISTS `tblcd_interview`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblcd_interview` (
  `in_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `candidate` int(11) NOT NULL,
  `interview` int(11) NOT NULL,
  `cd_from_hours` datetime DEFAULT NULL,
  `cd_to_hours` datetime DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`in_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcd_interview`
--

LOCK TABLES `tblcd_interview` WRITE;
/*!40000 ALTER TABLE `tblcd_interview` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblcd_interview` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblcd_literacy`
--

DROP TABLE IF EXISTS `tblcd_literacy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblcd_literacy` (
  `li_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `candidate` int(11) NOT NULL,
  `literacy_from_date` date DEFAULT NULL,
  `literacy_to_date` date DEFAULT NULL,
  `diploma` varchar(200) DEFAULT NULL,
  `training_places` varchar(200) DEFAULT NULL,
  `specialized` varchar(200) DEFAULT NULL,
  `training_form` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`li_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcd_literacy`
--

LOCK TABLES `tblcd_literacy` WRITE;
/*!40000 ALTER TABLE `tblcd_literacy` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblcd_literacy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblcd_skill`
--

DROP TABLE IF EXISTS `tblcd_skill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblcd_skill` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `candidate` int(11) NOT NULL,
  `skill_name` text DEFAULT NULL,
  `skill_description` text DEFAULT NULL,
  PRIMARY KEY (`id`,`candidate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcd_skill`
--

LOCK TABLES `tblcd_skill` WRITE;
/*!40000 ALTER TABLE `tblcd_skill` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblcd_skill` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblcd_work_experience`
--

DROP TABLE IF EXISTS `tblcd_work_experience`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblcd_work_experience` (
  `we_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `candidate` int(11) NOT NULL,
  `from_date` date DEFAULT NULL,
  `to_date` date DEFAULT NULL,
  `company` varchar(200) DEFAULT NULL,
  `position` varchar(200) DEFAULT NULL,
  `contact_person` varchar(200) DEFAULT NULL,
  `salary` varchar(200) DEFAULT NULL,
  `reason_quitwork` varchar(200) DEFAULT NULL,
  `job_description` text DEFAULT NULL,
  PRIMARY KEY (`we_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcd_work_experience`
--

LOCK TABLES `tblcd_work_experience` WRITE;
/*!40000 ALTER TABLE `tblcd_work_experience` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblcd_work_experience` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblcheck_in_out`
--

DROP TABLE IF EXISTS `tblcheck_in_out`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblcheck_in_out` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `type_check` int(11) DEFAULT NULL,
  `type` varchar(5) NOT NULL DEFAULT 'W',
  `route_point_id` int(11) DEFAULT NULL,
  `workplace_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcheck_in_out`
--

LOCK TABLES `tblcheck_in_out` WRITE;
/*!40000 ALTER TABLE `tblcheck_in_out` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblcheck_in_out` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblchecklist`
--

DROP TABLE IF EXISTS `tblchecklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblchecklist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `group_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblchecklist`
--

LOCK TABLES `tblchecklist` WRITE;
/*!40000 ALTER TABLE `tblchecklist` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblchecklist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblchecklist_allocation`
--

DROP TABLE IF EXISTS `tblchecklist_allocation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblchecklist_allocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `group_id` int(11) DEFAULT NULL,
  `staffid` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblchecklist_allocation`
--

LOCK TABLES `tblchecklist_allocation` WRITE;
/*!40000 ALTER TABLE `tblchecklist_allocation` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblchecklist_allocation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblclients`
--

DROP TABLE IF EXISTS `tblclients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblclients` (
  `userid` int(11) NOT NULL AUTO_INCREMENT,
  `company` varchar(191) DEFAULT NULL,
  `vat` varchar(50) DEFAULT NULL,
  `phonenumber` varchar(30) DEFAULT NULL,
  `country` int(11) NOT NULL DEFAULT 0,
  `city` varchar(100) DEFAULT NULL,
  `zip` varchar(15) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `address` varchar(191) DEFAULT NULL,
  `website` varchar(150) DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `active` int(11) NOT NULL DEFAULT 1,
  `leadid` int(11) DEFAULT NULL,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT 0,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT 0,
  `longitude` varchar(191) DEFAULT NULL,
  `latitude` varchar(191) DEFAULT NULL,
  `default_language` varchar(40) DEFAULT NULL,
  `default_currency` int(11) NOT NULL DEFAULT 0,
  `show_primary_contact` int(11) NOT NULL DEFAULT 0,
  `stripe_id` varchar(40) DEFAULT NULL,
  `registration_confirmed` int(11) NOT NULL DEFAULT 1,
  `addedfrom` int(11) NOT NULL DEFAULT 0,
  `balance` decimal(15,2) DEFAULT NULL,
  `balance_as_of` date DEFAULT NULL,
  `loy_point` decimal(10,0) DEFAULT 0,
  `sector` varchar(255) DEFAULT NULL,
  `industry` varchar(255) DEFAULT NULL,
  `continue_from_date` date DEFAULT NULL,
  PRIMARY KEY (`userid`),
  KEY `country` (`country`),
  KEY `leadid` (`leadid`),
  KEY `company` (`company`),
  KEY `active` (`active`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblclients`
--

LOCK TABLES `tblclients` WRITE;
/*!40000 ALTER TABLE `tblclients` DISABLE KEYS */;
INSERT INTO `tblclients` VALUES (10,'demo','08CTAPD2435D1ZA',NULL,0,NULL,NULL,NULL,NULL,NULL,'2025-07-07 16:10:33',1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL,NULL,'english',0,0,NULL,1,0,NULL,NULL,0,'manufacturing','agriculture_and_farming','2025-07-06'),(11,'Splice laminate private limited','09ABDCS2170G1ZE','',102,'Gorakhpur','273209,','U.P','AL-19/A-1, Sector-13, GIDA','','2025-07-07 18:06:05',1,NULL,'AL-19/A-1, Sector-13, GIDA','Gorakhpur','U.P','273209,',102,'AL-19/A-1, Sector-13, GIDA','Gorakhpur','U.P','273209,',102,NULL,NULL,'english',3,0,NULL,1,0,NULL,NULL,0,'manufacturing','furniture__supplies','0000-00-00'),(12,'ABCD','2345678765',NULL,0,NULL,NULL,NULL,NULL,NULL,'2025-07-08 00:22:18',1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL,NULL,'english',0,0,NULL,1,0,NULL,NULL,0,'manufacturing','furniture__supplies','2025-07-08');
/*!40000 ALTER TABLE `tblclients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblconsent_purposes`
--

DROP TABLE IF EXISTS `tblconsent_purposes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblconsent_purposes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `last_updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblconsent_purposes`
--

LOCK TABLES `tblconsent_purposes` WRITE;
/*!40000 ALTER TABLE `tblconsent_purposes` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblconsent_purposes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblconsents`
--

DROP TABLE IF EXISTS `tblconsents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblconsents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action` varchar(10) NOT NULL,
  `date` datetime NOT NULL,
  `ip` varchar(40) NOT NULL,
  `contact_id` int(11) NOT NULL DEFAULT 0,
  `lead_id` int(11) NOT NULL DEFAULT 0,
  `description` mediumtext DEFAULT NULL,
  `opt_in_purpose_description` mediumtext DEFAULT NULL,
  `purpose_id` int(11) NOT NULL,
  `staff_name` varchar(100) DEFAULT NULL,
  `candidate_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `purpose_id` (`purpose_id`),
  KEY `contact_id` (`contact_id`),
  KEY `lead_id` (`lead_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblconsents`
--

LOCK TABLES `tblconsents` WRITE;
/*!40000 ALTER TABLE `tblconsents` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblconsents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblcontact_permissions`
--

DROP TABLE IF EXISTS `tblcontact_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblcontact_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permission_id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=95 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcontact_permissions`
--

LOCK TABLES `tblcontact_permissions` WRITE;
/*!40000 ALTER TABLE `tblcontact_permissions` DISABLE KEYS */;
INSERT INTO `tblcontact_permissions` VALUES (71,1,10),(72,2,10),(73,3,10),(74,4,10),(75,5,10),(76,6,10),(79,1,11),(80,2,11),(81,3,11),(82,4,11),(83,5,11),(84,6,11),(85,311301,11),(86,311302,11),(87,1,12),(88,2,12),(89,3,12),(90,4,12),(91,5,12),(92,6,12),(93,311301,12),(94,311302,12);
/*!40000 ALTER TABLE `tblcontact_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblcontacts`
--

DROP TABLE IF EXISTS `tblcontacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblcontacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `is_primary` int(11) NOT NULL DEFAULT 1,
  `firstname` varchar(191) NOT NULL,
  `lastname` varchar(191) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phonenumber` varchar(100) NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `new_pass_key` varchar(32) DEFAULT NULL,
  `new_pass_key_requested` datetime DEFAULT NULL,
  `email_verified_at` datetime DEFAULT NULL,
  `email_verification_key` varchar(32) DEFAULT NULL,
  `email_verification_sent_at` datetime DEFAULT NULL,
  `last_ip` varchar(40) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_password_change` datetime DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `profile_image` varchar(191) DEFAULT NULL,
  `direction` varchar(3) DEFAULT NULL,
  `invoice_emails` tinyint(1) NOT NULL DEFAULT 1,
  `estimate_emails` tinyint(1) NOT NULL DEFAULT 1,
  `credit_note_emails` tinyint(1) NOT NULL DEFAULT 1,
  `contract_emails` tinyint(1) NOT NULL DEFAULT 1,
  `task_emails` tinyint(1) NOT NULL DEFAULT 1,
  `project_emails` tinyint(1) NOT NULL DEFAULT 1,
  `ticket_emails` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `firstname` (`firstname`),
  KEY `lastname` (`lastname`),
  KEY `email` (`email`),
  KEY `is_primary` (`is_primary`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcontacts`
--

LOCK TABLES `tblcontacts` WRITE;
/*!40000 ALTER TABLE `tblcontacts` DISABLE KEYS */;
INSERT INTO `tblcontacts` VALUES (10,10,1,'Deepanshu','Sharma','demo@techdotbit.com','+9108233081931','','2025-07-07 16:10:33','$2a$08$EV/8XtiLlt2CNKEpIWspTOzNymOL05mC4OytuBcqrw4AqI1Z.G6jC',NULL,NULL,'2025-06-19 19:48:20','5564a8972d5f5eb2793fe5f33323f112',NULL,'49.36.189.194','2025-07-07 16:10:39',NULL,1,NULL,'',1,1,1,1,1,1,1),(11,11,1,'faizan','ahmad','md@spliceply.com','+919415692511',NULL,'2025-07-07 18:06:05','$2a$08$Yzeka42kqcCfeAFFM209z.NwTjamahBdA/r2iVHEzKuJK0ZXaeWnK',NULL,NULL,'2025-06-19 19:48:20','cf45ae9423dc2da652c194d38a75460e',NULL,'110.172.155.237','2025-07-07 18:06:11',NULL,1,NULL,NULL,1,1,1,1,1,1,1),(12,12,1,'Sahil','Oswal','vikas@techdotbit.com','+918888810575','','2025-07-08 00:22:18','$2a$08$O8MPU82ZfJbfCQ6OJmRE1OMRqKoroeIiVjqAK07FxLXw0dQ7SOUmi',NULL,NULL,'2025-07-08 00:24:07',NULL,NULL,'49.36.189.194','2025-07-08 00:22:22',NULL,1,NULL,'',1,1,1,1,1,1,1);
/*!40000 ALTER TABLE `tblcontacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblcontract_comments`
--

DROP TABLE IF EXISTS `tblcontract_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblcontract_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` longtext DEFAULT NULL,
  `contract_id` int(11) NOT NULL,
  `staffid` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcontract_comments`
--

LOCK TABLES `tblcontract_comments` WRITE;
/*!40000 ALTER TABLE `tblcontract_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblcontract_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblcontract_renewals`
--

DROP TABLE IF EXISTS `tblcontract_renewals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblcontract_renewals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contractid` int(11) NOT NULL,
  `old_start_date` date NOT NULL,
  `new_start_date` date NOT NULL,
  `old_end_date` date DEFAULT NULL,
  `new_end_date` date DEFAULT NULL,
  `old_value` decimal(15,2) DEFAULT NULL,
  `new_value` decimal(15,2) DEFAULT NULL,
  `date_renewed` datetime NOT NULL,
  `renewed_by` varchar(100) NOT NULL,
  `renewed_by_staff_id` int(11) NOT NULL DEFAULT 0,
  `is_on_old_expiry_notified` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcontract_renewals`
--

LOCK TABLES `tblcontract_renewals` WRITE;
/*!40000 ALTER TABLE `tblcontract_renewals` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblcontract_renewals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblcontracts`
--

DROP TABLE IF EXISTS `tblcontracts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblcontracts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` longtext DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `subject` varchar(191) DEFAULT NULL,
  `client` int(11) NOT NULL,
  `datestart` date DEFAULT NULL,
  `dateend` date DEFAULT NULL,
  `contract_type` int(11) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  `isexpirynotified` int(11) NOT NULL DEFAULT 0,
  `contract_value` decimal(15,2) DEFAULT NULL,
  `trash` tinyint(1) DEFAULT 0,
  `not_visible_to_client` tinyint(1) NOT NULL DEFAULT 0,
  `hash` varchar(32) DEFAULT NULL,
  `signed` tinyint(1) NOT NULL DEFAULT 0,
  `signature` varchar(40) DEFAULT NULL,
  `marked_as_signed` tinyint(1) NOT NULL DEFAULT 0,
  `acceptance_firstname` varchar(50) DEFAULT NULL,
  `acceptance_lastname` varchar(50) DEFAULT NULL,
  `acceptance_email` varchar(100) DEFAULT NULL,
  `acceptance_date` datetime DEFAULT NULL,
  `acceptance_ip` varchar(40) DEFAULT NULL,
  `short_link` varchar(100) DEFAULT NULL,
  `last_sent_at` datetime DEFAULT NULL,
  `contacts_sent_to` mediumtext DEFAULT NULL,
  `last_sign_reminder_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `client` (`client`),
  KEY `contract_type` (`contract_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcontracts`
--

LOCK TABLES `tblcontracts` WRITE;
/*!40000 ALTER TABLE `tblcontracts` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblcontracts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblcontracts_types`
--

DROP TABLE IF EXISTS `tblcontracts_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblcontracts_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcontracts_types`
--

LOCK TABLES `tblcontracts_types` WRITE;
/*!40000 ALTER TABLE `tblcontracts_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblcontracts_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblcountries`
--

DROP TABLE IF EXISTS `tblcountries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblcountries` (
  `country_id` int(11) NOT NULL AUTO_INCREMENT,
  `iso2` char(2) DEFAULT NULL,
  `short_name` varchar(80) NOT NULL DEFAULT '',
  `long_name` varchar(80) NOT NULL DEFAULT '',
  `iso3` char(3) DEFAULT NULL,
  `numcode` varchar(6) DEFAULT NULL,
  `un_member` varchar(12) DEFAULT NULL,
  `calling_code` varchar(8) DEFAULT NULL,
  `cctld` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`country_id`)
) ENGINE=InnoDB AUTO_INCREMENT=251 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcountries`
--

LOCK TABLES `tblcountries` WRITE;
/*!40000 ALTER TABLE `tblcountries` DISABLE KEYS */;
INSERT INTO `tblcountries` VALUES (1,'AF','Afghanistan','Islamic Republic of Afghanistan','AFG','004','yes','93','.af'),(2,'AX','Aland Islands','&Aring;land Islands','ALA','248','no','358','.ax'),(3,'AL','Albania','Republic of Albania','ALB','008','yes','355','.al'),(4,'DZ','Algeria','People\'s Democratic Republic of Algeria','DZA','012','yes','213','.dz'),(5,'AS','American Samoa','American Samoa','ASM','016','no','1+684','.as'),(6,'AD','Andorra','Principality of Andorra','AND','020','yes','376','.ad'),(7,'AO','Angola','Republic of Angola','AGO','024','yes','244','.ao'),(8,'AI','Anguilla','Anguilla','AIA','660','no','1+264','.ai'),(9,'AQ','Antarctica','Antarctica','ATA','010','no','672','.aq'),(10,'AG','Antigua and Barbuda','Antigua and Barbuda','ATG','028','yes','1+268','.ag'),(11,'AR','Argentina','Argentine Republic','ARG','032','yes','54','.ar'),(12,'AM','Armenia','Republic of Armenia','ARM','051','yes','374','.am'),(13,'AW','Aruba','Aruba','ABW','533','no','297','.aw'),(14,'AU','Australia','Commonwealth of Australia','AUS','036','yes','61','.au'),(15,'AT','Austria','Republic of Austria','AUT','040','yes','43','.at'),(16,'AZ','Azerbaijan','Republic of Azerbaijan','AZE','031','yes','994','.az'),(17,'BS','Bahamas','Commonwealth of The Bahamas','BHS','044','yes','1+242','.bs'),(18,'BH','Bahrain','Kingdom of Bahrain','BHR','048','yes','973','.bh'),(19,'BD','Bangladesh','People\'s Republic of Bangladesh','BGD','050','yes','880','.bd'),(20,'BB','Barbados','Barbados','BRB','052','yes','1+246','.bb'),(21,'BY','Belarus','Republic of Belarus','BLR','112','yes','375','.by'),(22,'BE','Belgium','Kingdom of Belgium','BEL','056','yes','32','.be'),(23,'BZ','Belize','Belize','BLZ','084','yes','501','.bz'),(24,'BJ','Benin','Republic of Benin','BEN','204','yes','229','.bj'),(25,'BM','Bermuda','Bermuda Islands','BMU','060','no','1+441','.bm'),(26,'BT','Bhutan','Kingdom of Bhutan','BTN','064','yes','975','.bt'),(27,'BO','Bolivia','Plurinational State of Bolivia','BOL','068','yes','591','.bo'),(28,'BQ','Bonaire, Sint Eustatius and Saba','Bonaire, Sint Eustatius and Saba','BES','535','no','599','.bq'),(29,'BA','Bosnia and Herzegovina','Bosnia and Herzegovina','BIH','070','yes','387','.ba'),(30,'BW','Botswana','Republic of Botswana','BWA','072','yes','267','.bw'),(31,'BV','Bouvet Island','Bouvet Island','BVT','074','no','NONE','.bv'),(32,'BR','Brazil','Federative Republic of Brazil','BRA','076','yes','55','.br'),(33,'IO','British Indian Ocean Territory','British Indian Ocean Territory','IOT','086','no','246','.io'),(34,'BN','Brunei','Brunei Darussalam','BRN','096','yes','673','.bn'),(35,'BG','Bulgaria','Republic of Bulgaria','BGR','100','yes','359','.bg'),(36,'BF','Burkina Faso','Burkina Faso','BFA','854','yes','226','.bf'),(37,'BI','Burundi','Republic of Burundi','BDI','108','yes','257','.bi'),(38,'KH','Cambodia','Kingdom of Cambodia','KHM','116','yes','855','.kh'),(39,'CM','Cameroon','Republic of Cameroon','CMR','120','yes','237','.cm'),(40,'CA','Canada','Canada','CAN','124','yes','1','.ca'),(41,'CV','Cape Verde','Republic of Cape Verde','CPV','132','yes','238','.cv'),(42,'KY','Cayman Islands','The Cayman Islands','CYM','136','no','1+345','.ky'),(43,'CF','Central African Republic','Central African Republic','CAF','140','yes','236','.cf'),(44,'TD','Chad','Republic of Chad','TCD','148','yes','235','.td'),(45,'CL','Chile','Republic of Chile','CHL','152','yes','56','.cl'),(46,'CN','China','People\'s Republic of China','CHN','156','yes','86','.cn'),(47,'CX','Christmas Island','Christmas Island','CXR','162','no','61','.cx'),(48,'CC','Cocos (Keeling) Islands','Cocos (Keeling) Islands','CCK','166','no','61','.cc'),(49,'CO','Colombia','Republic of Colombia','COL','170','yes','57','.co'),(50,'KM','Comoros','Union of the Comoros','COM','174','yes','269','.km'),(51,'CG','Congo','Republic of the Congo','COG','178','yes','242','.cg'),(52,'CK','Cook Islands','Cook Islands','COK','184','some','682','.ck'),(53,'CR','Costa Rica','Republic of Costa Rica','CRI','188','yes','506','.cr'),(54,'CI','Cote d\'ivoire (Ivory Coast)','Republic of C&ocirc;te D\'Ivoire (Ivory Coast)','CIV','384','yes','225','.ci'),(55,'HR','Croatia','Republic of Croatia','HRV','191','yes','385','.hr'),(56,'CU','Cuba','Republic of Cuba','CUB','192','yes','53','.cu'),(57,'CW','Curacao','Cura&ccedil;ao','CUW','531','no','599','.cw'),(58,'CY','Cyprus','Republic of Cyprus','CYP','196','yes','357','.cy'),(59,'CZ','Czech Republic','Czech Republic','CZE','203','yes','420','.cz'),(60,'CD','Democratic Republic of the Congo','Democratic Republic of the Congo','COD','180','yes','243','.cd'),(61,'DK','Denmark','Kingdom of Denmark','DNK','208','yes','45','.dk'),(62,'DJ','Djibouti','Republic of Djibouti','DJI','262','yes','253','.dj'),(63,'DM','Dominica','Commonwealth of Dominica','DMA','212','yes','1+767','.dm'),(64,'DO','Dominican Republic','Dominican Republic','DOM','214','yes','1+809, 8','.do'),(65,'EC','Ecuador','Republic of Ecuador','ECU','218','yes','593','.ec'),(66,'EG','Egypt','Arab Republic of Egypt','EGY','818','yes','20','.eg'),(67,'SV','El Salvador','Republic of El Salvador','SLV','222','yes','503','.sv'),(68,'GQ','Equatorial Guinea','Republic of Equatorial Guinea','GNQ','226','yes','240','.gq'),(69,'ER','Eritrea','State of Eritrea','ERI','232','yes','291','.er'),(70,'EE','Estonia','Republic of Estonia','EST','233','yes','372','.ee'),(71,'ET','Ethiopia','Federal Democratic Republic of Ethiopia','ETH','231','yes','251','.et'),(72,'FK','Falkland Islands (Malvinas)','The Falkland Islands (Malvinas)','FLK','238','no','500','.fk'),(73,'FO','Faroe Islands','The Faroe Islands','FRO','234','no','298','.fo'),(74,'FJ','Fiji','Republic of Fiji','FJI','242','yes','679','.fj'),(75,'FI','Finland','Republic of Finland','FIN','246','yes','358','.fi'),(76,'FR','France','French Republic','FRA','250','yes','33','.fr'),(77,'GF','French Guiana','French Guiana','GUF','254','no','594','.gf'),(78,'PF','French Polynesia','French Polynesia','PYF','258','no','689','.pf'),(79,'TF','French Southern Territories','French Southern Territories','ATF','260','no',NULL,'.tf'),(80,'GA','Gabon','Gabonese Republic','GAB','266','yes','241','.ga'),(81,'GM','Gambia','Republic of The Gambia','GMB','270','yes','220','.gm'),(82,'GE','Georgia','Georgia','GEO','268','yes','995','.ge'),(83,'DE','Germany','Federal Republic of Germany','DEU','276','yes','49','.de'),(84,'GH','Ghana','Republic of Ghana','GHA','288','yes','233','.gh'),(85,'GI','Gibraltar','Gibraltar','GIB','292','no','350','.gi'),(86,'GR','Greece','Hellenic Republic','GRC','300','yes','30','.gr'),(87,'GL','Greenland','Greenland','GRL','304','no','299','.gl'),(88,'GD','Grenada','Grenada','GRD','308','yes','1+473','.gd'),(89,'GP','Guadaloupe','Guadeloupe','GLP','312','no','590','.gp'),(90,'GU','Guam','Guam','GUM','316','no','1+671','.gu'),(91,'GT','Guatemala','Republic of Guatemala','GTM','320','yes','502','.gt'),(92,'GG','Guernsey','Guernsey','GGY','831','no','44','.gg'),(93,'GN','Guinea','Republic of Guinea','GIN','324','yes','224','.gn'),(94,'GW','Guinea-Bissau','Republic of Guinea-Bissau','GNB','624','yes','245','.gw'),(95,'GY','Guyana','Co-operative Republic of Guyana','GUY','328','yes','592','.gy'),(96,'HT','Haiti','Republic of Haiti','HTI','332','yes','509','.ht'),(97,'HM','Heard Island and McDonald Islands','Heard Island and McDonald Islands','HMD','334','no','NONE','.hm'),(98,'HN','Honduras','Republic of Honduras','HND','340','yes','504','.hn'),(99,'HK','Hong Kong','Hong Kong','HKG','344','no','852','.hk'),(100,'HU','Hungary','Hungary','HUN','348','yes','36','.hu'),(101,'IS','Iceland','Republic of Iceland','ISL','352','yes','354','.is'),(102,'IN','India','Republic of India','IND','356','yes','91','.in'),(103,'ID','Indonesia','Republic of Indonesia','IDN','360','yes','62','.id'),(104,'IR','Iran','Islamic Republic of Iran','IRN','364','yes','98','.ir'),(105,'IQ','Iraq','Republic of Iraq','IRQ','368','yes','964','.iq'),(106,'IE','Ireland','Ireland','IRL','372','yes','353','.ie'),(107,'IM','Isle of Man','Isle of Man','IMN','833','no','44','.im'),(108,'IL','Israel','State of Israel','ISR','376','yes','972','.il'),(109,'IT','Italy','Italian Republic','ITA','380','yes','39','.jm'),(110,'JM','Jamaica','Jamaica','JAM','388','yes','1+876','.jm'),(111,'JP','Japan','Japan','JPN','392','yes','81','.jp'),(112,'JE','Jersey','The Bailiwick of Jersey','JEY','832','no','44','.je'),(113,'JO','Jordan','Hashemite Kingdom of Jordan','JOR','400','yes','962','.jo'),(114,'KZ','Kazakhstan','Republic of Kazakhstan','KAZ','398','yes','7','.kz'),(115,'KE','Kenya','Republic of Kenya','KEN','404','yes','254','.ke'),(116,'KI','Kiribati','Republic of Kiribati','KIR','296','yes','686','.ki'),(117,'XK','Kosovo','Republic of Kosovo','---','---','some','381',''),(118,'KW','Kuwait','State of Kuwait','KWT','414','yes','965','.kw'),(119,'KG','Kyrgyzstan','Kyrgyz Republic','KGZ','417','yes','996','.kg'),(120,'LA','Laos','Lao People\'s Democratic Republic','LAO','418','yes','856','.la'),(121,'LV','Latvia','Republic of Latvia','LVA','428','yes','371','.lv'),(122,'LB','Lebanon','Republic of Lebanon','LBN','422','yes','961','.lb'),(123,'LS','Lesotho','Kingdom of Lesotho','LSO','426','yes','266','.ls'),(124,'LR','Liberia','Republic of Liberia','LBR','430','yes','231','.lr'),(125,'LY','Libya','Libya','LBY','434','yes','218','.ly'),(126,'LI','Liechtenstein','Principality of Liechtenstein','LIE','438','yes','423','.li'),(127,'LT','Lithuania','Republic of Lithuania','LTU','440','yes','370','.lt'),(128,'LU','Luxembourg','Grand Duchy of Luxembourg','LUX','442','yes','352','.lu'),(129,'MO','Macao','The Macao Special Administrative Region','MAC','446','no','853','.mo'),(130,'MK','North Macedonia','Republic of North Macedonia','MKD','807','yes','389','.mk'),(131,'MG','Madagascar','Republic of Madagascar','MDG','450','yes','261','.mg'),(132,'MW','Malawi','Republic of Malawi','MWI','454','yes','265','.mw'),(133,'MY','Malaysia','Malaysia','MYS','458','yes','60','.my'),(134,'MV','Maldives','Republic of Maldives','MDV','462','yes','960','.mv'),(135,'ML','Mali','Republic of Mali','MLI','466','yes','223','.ml'),(136,'MT','Malta','Republic of Malta','MLT','470','yes','356','.mt'),(137,'MH','Marshall Islands','Republic of the Marshall Islands','MHL','584','yes','692','.mh'),(138,'MQ','Martinique','Martinique','MTQ','474','no','596','.mq'),(139,'MR','Mauritania','Islamic Republic of Mauritania','MRT','478','yes','222','.mr'),(140,'MU','Mauritius','Republic of Mauritius','MUS','480','yes','230','.mu'),(141,'YT','Mayotte','Mayotte','MYT','175','no','262','.yt'),(142,'MX','Mexico','United Mexican States','MEX','484','yes','52','.mx'),(143,'FM','Micronesia','Federated States of Micronesia','FSM','583','yes','691','.fm'),(144,'MD','Moldava','Republic of Moldova','MDA','498','yes','373','.md'),(145,'MC','Monaco','Principality of Monaco','MCO','492','yes','377','.mc'),(146,'MN','Mongolia','Mongolia','MNG','496','yes','976','.mn'),(147,'ME','Montenegro','Montenegro','MNE','499','yes','382','.me'),(148,'MS','Montserrat','Montserrat','MSR','500','no','1+664','.ms'),(149,'MA','Morocco','Kingdom of Morocco','MAR','504','yes','212','.ma'),(150,'MZ','Mozambique','Republic of Mozambique','MOZ','508','yes','258','.mz'),(151,'MM','Myanmar (Burma)','Republic of the Union of Myanmar','MMR','104','yes','95','.mm'),(152,'NA','Namibia','Republic of Namibia','NAM','516','yes','264','.na'),(153,'NR','Nauru','Republic of Nauru','NRU','520','yes','674','.nr'),(154,'NP','Nepal','Federal Democratic Republic of Nepal','NPL','524','yes','977','.np'),(155,'NL','Netherlands','Kingdom of the Netherlands','NLD','528','yes','31','.nl'),(156,'NC','New Caledonia','New Caledonia','NCL','540','no','687','.nc'),(157,'NZ','New Zealand','New Zealand','NZL','554','yes','64','.nz'),(158,'NI','Nicaragua','Republic of Nicaragua','NIC','558','yes','505','.ni'),(159,'NE','Niger','Republic of Niger','NER','562','yes','227','.ne'),(160,'NG','Nigeria','Federal Republic of Nigeria','NGA','566','yes','234','.ng'),(161,'NU','Niue','Niue','NIU','570','some','683','.nu'),(162,'NF','Norfolk Island','Norfolk Island','NFK','574','no','672','.nf'),(163,'KP','North Korea','Democratic People\'s Republic of Korea','PRK','408','yes','850','.kp'),(164,'MP','Northern Mariana Islands','Northern Mariana Islands','MNP','580','no','1+670','.mp'),(165,'NO','Norway','Kingdom of Norway','NOR','578','yes','47','.no'),(166,'OM','Oman','Sultanate of Oman','OMN','512','yes','968','.om'),(167,'PK','Pakistan','Islamic Republic of Pakistan','PAK','586','yes','92','.pk'),(168,'PW','Palau','Republic of Palau','PLW','585','yes','680','.pw'),(169,'PS','Palestine','State of Palestine (or Occupied Palestinian Territory)','PSE','275','some','970','.ps'),(170,'PA','Panama','Republic of Panama','PAN','591','yes','507','.pa'),(171,'PG','Papua New Guinea','Independent State of Papua New Guinea','PNG','598','yes','675','.pg'),(172,'PY','Paraguay','Republic of Paraguay','PRY','600','yes','595','.py'),(173,'PE','Peru','Republic of Peru','PER','604','yes','51','.pe'),(174,'PH','Philippines','Republic of the Philippines','PHL','608','yes','63','.ph'),(175,'PN','Pitcairn','Pitcairn','PCN','612','no','NONE','.pn'),(176,'PL','Poland','Republic of Poland','POL','616','yes','48','.pl'),(177,'PT','Portugal','Portuguese Republic','PRT','620','yes','351','.pt'),(178,'PR','Puerto Rico','Commonwealth of Puerto Rico','PRI','630','no','1+939','.pr'),(179,'QA','Qatar','State of Qatar','QAT','634','yes','974','.qa'),(180,'RE','Reunion','R&eacute;union','REU','638','no','262','.re'),(181,'RO','Romania','Romania','ROU','642','yes','40','.ro'),(182,'RU','Russia','Russian Federation','RUS','643','yes','7','.ru'),(183,'RW','Rwanda','Republic of Rwanda','RWA','646','yes','250','.rw'),(184,'BL','Saint Barthelemy','Saint Barth&eacute;lemy','BLM','652','no','590','.bl'),(185,'SH','Saint Helena','Saint Helena, Ascension and Tristan da Cunha','SHN','654','no','290','.sh'),(186,'KN','Saint Kitts and Nevis','Federation of Saint Christopher and Nevis','KNA','659','yes','1+869','.kn'),(187,'LC','Saint Lucia','Saint Lucia','LCA','662','yes','1+758','.lc'),(188,'MF','Saint Martin','Saint Martin','MAF','663','no','590','.mf'),(189,'PM','Saint Pierre and Miquelon','Saint Pierre and Miquelon','SPM','666','no','508','.pm'),(190,'VC','Saint Vincent and the Grenadines','Saint Vincent and the Grenadines','VCT','670','yes','1+784','.vc'),(191,'WS','Samoa','Independent State of Samoa','WSM','882','yes','685','.ws'),(192,'SM','San Marino','Republic of San Marino','SMR','674','yes','378','.sm'),(193,'ST','Sao Tome and Principe','Democratic Republic of S&atilde;o Tom&eacute; and Pr&iacute;ncipe','STP','678','yes','239','.st'),(194,'SA','Saudi Arabia','Kingdom of Saudi Arabia','SAU','682','yes','966','.sa'),(195,'SN','Senegal','Republic of Senegal','SEN','686','yes','221','.sn'),(196,'RS','Serbia','Republic of Serbia','SRB','688','yes','381','.rs'),(197,'SC','Seychelles','Republic of Seychelles','SYC','690','yes','248','.sc'),(198,'SL','Sierra Leone','Republic of Sierra Leone','SLE','694','yes','232','.sl'),(199,'SG','Singapore','Republic of Singapore','SGP','702','yes','65','.sg'),(200,'SX','Sint Maarten','Sint Maarten','SXM','534','no','1+721','.sx'),(201,'SK','Slovakia','Slovak Republic','SVK','703','yes','421','.sk'),(202,'SI','Slovenia','Republic of Slovenia','SVN','705','yes','386','.si'),(203,'SB','Solomon Islands','Solomon Islands','SLB','090','yes','677','.sb'),(204,'SO','Somalia','Somali Republic','SOM','706','yes','252','.so'),(205,'ZA','South Africa','Republic of South Africa','ZAF','710','yes','27','.za'),(206,'GS','South Georgia and the South Sandwich Islands','South Georgia and the South Sandwich Islands','SGS','239','no','500','.gs'),(207,'KR','South Korea','Republic of Korea','KOR','410','yes','82','.kr'),(208,'SS','South Sudan','Republic of South Sudan','SSD','728','yes','211','.ss'),(209,'ES','Spain','Kingdom of Spain','ESP','724','yes','34','.es'),(210,'LK','Sri Lanka','Democratic Socialist Republic of Sri Lanka','LKA','144','yes','94','.lk'),(211,'SD','Sudan','Republic of the Sudan','SDN','729','yes','249','.sd'),(212,'SR','Suriname','Republic of Suriname','SUR','740','yes','597','.sr'),(213,'SJ','Svalbard and Jan Mayen','Svalbard and Jan Mayen','SJM','744','no','47','.sj'),(214,'SZ','Swaziland','Kingdom of Swaziland','SWZ','748','yes','268','.sz'),(215,'SE','Sweden','Kingdom of Sweden','SWE','752','yes','46','.se'),(216,'CH','Switzerland','Swiss Confederation','CHE','756','yes','41','.ch'),(217,'SY','Syria','Syrian Arab Republic','SYR','760','yes','963','.sy'),(218,'TW','Taiwan','Republic of China (Taiwan)','TWN','158','former','886','.tw'),(219,'TJ','Tajikistan','Republic of Tajikistan','TJK','762','yes','992','.tj'),(220,'TZ','Tanzania','United Republic of Tanzania','TZA','834','yes','255','.tz'),(221,'TH','Thailand','Kingdom of Thailand','THA','764','yes','66','.th'),(222,'TL','Timor-Leste (East Timor)','Democratic Republic of Timor-Leste','TLS','626','yes','670','.tl'),(223,'TG','Togo','Togolese Republic','TGO','768','yes','228','.tg'),(224,'TK','Tokelau','Tokelau','TKL','772','no','690','.tk'),(225,'TO','Tonga','Kingdom of Tonga','TON','776','yes','676','.to'),(226,'TT','Trinidad and Tobago','Republic of Trinidad and Tobago','TTO','780','yes','1+868','.tt'),(227,'TN','Tunisia','Republic of Tunisia','TUN','788','yes','216','.tn'),(228,'TR','Turkey','Republic of Turkey','TUR','792','yes','90','.tr'),(229,'TM','Turkmenistan','Turkmenistan','TKM','795','yes','993','.tm'),(230,'TC','Turks and Caicos Islands','Turks and Caicos Islands','TCA','796','no','1+649','.tc'),(231,'TV','Tuvalu','Tuvalu','TUV','798','yes','688','.tv'),(232,'UG','Uganda','Republic of Uganda','UGA','800','yes','256','.ug'),(233,'UA','Ukraine','Ukraine','UKR','804','yes','380','.ua'),(234,'AE','United Arab Emirates','United Arab Emirates','ARE','784','yes','971','.ae'),(235,'GB','United Kingdom','United Kingdom of Great Britain and Nothern Ireland','GBR','826','yes','44','.uk'),(236,'US','United States','United States of America','USA','840','yes','1','.us'),(237,'UM','United States Minor Outlying Islands','United States Minor Outlying Islands','UMI','581','no','NONE','NONE'),(238,'UY','Uruguay','Eastern Republic of Uruguay','URY','858','yes','598','.uy'),(239,'UZ','Uzbekistan','Republic of Uzbekistan','UZB','860','yes','998','.uz'),(240,'VU','Vanuatu','Republic of Vanuatu','VUT','548','yes','678','.vu'),(241,'VA','Vatican City','State of the Vatican City','VAT','336','no','39','.va'),(242,'VE','Venezuela','Bolivarian Republic of Venezuela','VEN','862','yes','58','.ve'),(243,'VN','Vietnam','Socialist Republic of Vietnam','VNM','704','yes','84','.vn'),(244,'VG','Virgin Islands, British','British Virgin Islands','VGB','092','no','1+284','.vg'),(245,'VI','Virgin Islands, US','Virgin Islands of the United States','VIR','850','no','1+340','.vi'),(246,'WF','Wallis and Futuna','Wallis and Futuna','WLF','876','no','681','.wf'),(247,'EH','Western Sahara','Western Sahara','ESH','732','no','212','.eh'),(248,'YE','Yemen','Republic of Yemen','YEM','887','yes','967','.ye'),(249,'ZM','Zambia','Republic of Zambia','ZMB','894','yes','260','.zm'),(250,'ZW','Zimbabwe','Republic of Zimbabwe','ZWE','716','yes','263','.zw');
/*!40000 ALTER TABLE `tblcountries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblcreditnote_refunds`
--

DROP TABLE IF EXISTS `tblcreditnote_refunds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblcreditnote_refunds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `credit_note_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `refunded_on` date NOT NULL,
  `payment_mode` varchar(40) NOT NULL,
  `note` mediumtext DEFAULT NULL,
  `amount` decimal(15,2) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcreditnote_refunds`
--

LOCK TABLES `tblcreditnote_refunds` WRITE;
/*!40000 ALTER TABLE `tblcreditnote_refunds` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblcreditnote_refunds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblcreditnotes`
--

DROP TABLE IF EXISTS `tblcreditnotes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblcreditnotes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clientid` int(11) NOT NULL,
  `deleted_customer_name` varchar(100) DEFAULT NULL,
  `number` int(11) NOT NULL,
  `prefix` varchar(50) DEFAULT NULL,
  `number_format` int(11) NOT NULL DEFAULT 1,
  `datecreated` datetime NOT NULL,
  `date` date NOT NULL,
  `adminnote` mediumtext DEFAULT NULL,
  `terms` mediumtext DEFAULT NULL,
  `clientnote` mediumtext DEFAULT NULL,
  `currency` int(11) NOT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `total_tax` decimal(15,2) NOT NULL DEFAULT 0.00,
  `total` decimal(15,2) NOT NULL,
  `adjustment` decimal(15,2) DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `project_id` int(11) NOT NULL DEFAULT 0,
  `discount_percent` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `discount_type` varchar(30) NOT NULL,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT NULL,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT NULL,
  `include_shipping` tinyint(1) NOT NULL,
  `show_shipping_on_credit_note` tinyint(1) NOT NULL DEFAULT 1,
  `show_quantity_as` int(11) NOT NULL DEFAULT 1,
  `reference_no` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `currency` (`currency`),
  KEY `clientid` (`clientid`),
  KEY `project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcreditnotes`
--

LOCK TABLES `tblcreditnotes` WRITE;
/*!40000 ALTER TABLE `tblcreditnotes` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblcreditnotes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblcredits`
--

DROP TABLE IF EXISTS `tblcredits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblcredits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) NOT NULL,
  `credit_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `date_applied` datetime NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcredits`
--

LOCK TABLES `tblcredits` WRITE;
/*!40000 ALTER TABLE `tblcredits` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblcredits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblcurrencies`
--

DROP TABLE IF EXISTS `tblcurrencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblcurrencies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `decimal_separator` varchar(5) DEFAULT NULL,
  `thousand_separator` varchar(5) DEFAULT NULL,
  `placement` varchar(10) DEFAULT NULL,
  `isdefault` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcurrencies`
--

LOCK TABLES `tblcurrencies` WRITE;
/*!40000 ALTER TABLE `tblcurrencies` DISABLE KEYS */;
INSERT INTO `tblcurrencies` VALUES (1,'$','USD','.',',','before',0),(3,'₹','INR','.',',','before',1);
/*!40000 ALTER TABLE `tblcurrencies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblcurrency_rate_logs`
--

DROP TABLE IF EXISTS `tblcurrency_rate_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblcurrency_rate_logs` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `from_currency_id` int(11) DEFAULT NULL,
  `from_currency_name` varchar(100) DEFAULT NULL,
  `from_currency_rate` decimal(15,6) NOT NULL DEFAULT 0.000000,
  `to_currency_id` int(11) DEFAULT NULL,
  `to_currency_name` varchar(100) DEFAULT NULL,
  `to_currency_rate` decimal(15,6) NOT NULL DEFAULT 0.000000,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcurrency_rate_logs`
--

LOCK TABLES `tblcurrency_rate_logs` WRITE;
/*!40000 ALTER TABLE `tblcurrency_rate_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblcurrency_rate_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblcurrency_rates`
--

DROP TABLE IF EXISTS `tblcurrency_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblcurrency_rates` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `from_currency_id` int(11) DEFAULT NULL,
  `from_currency_name` varchar(100) DEFAULT NULL,
  `from_currency_rate` decimal(15,6) NOT NULL DEFAULT 0.000000,
  `to_currency_id` int(11) DEFAULT NULL,
  `to_currency_name` varchar(100) DEFAULT NULL,
  `to_currency_rate` decimal(15,6) NOT NULL DEFAULT 0.000000,
  `date_updated` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcurrency_rates`
--

LOCK TABLES `tblcurrency_rates` WRITE;
/*!40000 ALTER TABLE `tblcurrency_rates` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblcurrency_rates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblcustomer_admins`
--

DROP TABLE IF EXISTS `tblcustomer_admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblcustomer_admins` (
  `staff_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `date_assigned` mediumtext NOT NULL,
  KEY `customer_id` (`customer_id`),
  KEY `staff_id` (`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcustomer_admins`
--

LOCK TABLES `tblcustomer_admins` WRITE;
/*!40000 ALTER TABLE `tblcustomer_admins` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblcustomer_admins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblcustomer_groups`
--

DROP TABLE IF EXISTS `tblcustomer_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblcustomer_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupid` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `groupid` (`groupid`),
  KEY `customer_id` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcustomer_groups`
--

LOCK TABLES `tblcustomer_groups` WRITE;
/*!40000 ALTER TABLE `tblcustomer_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblcustomer_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblcustomers_groups`
--

DROP TABLE IF EXISTS `tblcustomers_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblcustomers_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcustomers_groups`
--

LOCK TABLES `tblcustomers_groups` WRITE;
/*!40000 ALTER TABLE `tblcustomers_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblcustomers_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblcustomfields`
--

DROP TABLE IF EXISTS `tblcustomfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblcustomfields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldto` varchar(30) DEFAULT NULL,
  `name` varchar(150) NOT NULL,
  `slug` varchar(150) NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT 0,
  `type` varchar(20) NOT NULL,
  `options` longtext DEFAULT NULL,
  `display_inline` tinyint(1) NOT NULL DEFAULT 0,
  `field_order` int(11) DEFAULT 0,
  `active` int(11) NOT NULL DEFAULT 1,
  `show_on_pdf` int(11) NOT NULL DEFAULT 0,
  `show_on_ticket_form` tinyint(1) NOT NULL DEFAULT 0,
  `only_admin` tinyint(1) NOT NULL DEFAULT 0,
  `show_on_table` tinyint(1) NOT NULL DEFAULT 0,
  `show_on_client_portal` int(11) NOT NULL DEFAULT 0,
  `disalow_client_to_edit` int(11) NOT NULL DEFAULT 0,
  `bs_column` int(11) NOT NULL DEFAULT 12,
  `default_value` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcustomfields`
--

LOCK TABLES `tblcustomfields` WRITE;
/*!40000 ALTER TABLE `tblcustomfields` DISABLE KEYS */;
INSERT INTO `tblcustomfields` VALUES (1,'tasks','Estimate hour','tasks_estimate_hour',0,'number','',0,0,1,0,0,0,0,0,0,12,NULL);
/*!40000 ALTER TABLE `tblcustomfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblcustomfieldsvalues`
--

DROP TABLE IF EXISTS `tblcustomfieldsvalues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblcustomfieldsvalues` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `relid` int(11) NOT NULL,
  `fieldid` int(11) NOT NULL,
  `fieldto` varchar(15) NOT NULL,
  `value` mediumtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `relid` (`relid`),
  KEY `fieldto` (`fieldto`),
  KEY `fieldid` (`fieldid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcustomfieldsvalues`
--

LOCK TABLES `tblcustomfieldsvalues` WRITE;
/*!40000 ALTER TABLE `tblcustomfieldsvalues` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblcustomfieldsvalues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblday_off`
--

DROP TABLE IF EXISTS `tblday_off`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblday_off` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `off_reason` varchar(255) NOT NULL,
  `off_type` varchar(100) NOT NULL,
  `break_date` date NOT NULL,
  `timekeeping` varchar(45) DEFAULT NULL,
  `department` varchar(45) DEFAULT NULL,
  `position` varchar(45) DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  `repeat_by_year` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblday_off`
--

LOCK TABLES `tblday_off` WRITE;
/*!40000 ALTER TABLE `tblday_off` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblday_off` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbldepartments`
--

DROP TABLE IF EXISTS `tbldepartments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbldepartments` (
  `departmentid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `imap_username` varchar(191) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `email_from_header` tinyint(1) NOT NULL DEFAULT 0,
  `host` varchar(150) DEFAULT NULL,
  `password` longtext DEFAULT NULL,
  `encryption` varchar(3) DEFAULT NULL,
  `folder` varchar(191) NOT NULL DEFAULT 'INBOX',
  `delete_after_import` int(11) NOT NULL DEFAULT 0,
  `calendar_id` longtext DEFAULT NULL,
  `hidefromclient` tinyint(1) NOT NULL DEFAULT 0,
  `manager_id` int(11) DEFAULT 0,
  `parent_id` int(11) DEFAULT 0,
  PRIMARY KEY (`departmentid`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbldepartments`
--

LOCK TABLES `tbldepartments` WRITE;
/*!40000 ALTER TABLE `tbldepartments` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbldepartments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbldismissed_announcements`
--

DROP TABLE IF EXISTS `tbldismissed_announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbldismissed_announcements` (
  `dismissedannouncementid` int(11) NOT NULL AUTO_INCREMENT,
  `announcementid` int(11) NOT NULL,
  `staff` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  PRIMARY KEY (`dismissedannouncementid`),
  KEY `announcementid` (`announcementid`),
  KEY `staff` (`staff`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbldismissed_announcements`
--

LOCK TABLES `tbldismissed_announcements` WRITE;
/*!40000 ALTER TABLE `tbldismissed_announcements` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbldismissed_announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblemailtemplates`
--

DROP TABLE IF EXISTS `tblemailtemplates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblemailtemplates` (
  `emailtemplateid` int(11) NOT NULL AUTO_INCREMENT,
  `type` longtext NOT NULL,
  `slug` varchar(100) NOT NULL,
  `language` varchar(40) DEFAULT NULL,
  `name` longtext NOT NULL,
  `subject` longtext NOT NULL,
  `message` longtext NOT NULL,
  `fromname` longtext NOT NULL,
  `fromemail` varchar(100) DEFAULT NULL,
  `plaintext` int(11) NOT NULL DEFAULT 0,
  `active` tinyint(4) NOT NULL DEFAULT 0,
  `order` int(11) NOT NULL,
  PRIMARY KEY (`emailtemplateid`)
) ENGINE=InnoDB AUTO_INCREMENT=119 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblemailtemplates`
--

LOCK TABLES `tblemailtemplates` WRITE;
/*!40000 ALTER TABLE `tblemailtemplates` DISABLE KEYS */;
INSERT INTO `tblemailtemplates` VALUES (1,'client','new-client-created','english','New Contact Added/Registered (Welcome Email)','Welcome aboard','Dear {contact_firstname} {contact_lastname}<br /><br />Thank you for registering on the <strong>{companyname}</strong> CRM System.<br /><br />We just wanted to say welcome.<br /><br />Please contact us if you need any help.<br /><br />Click here to view your profile: <a href=\"{crm_url}\">{crm_url}</a><br /><br />Kind Regards, <br />{email_signature}<br /><br />(This is an automated email, so please don\'t reply to this email address)','{companyname} | CRM','',0,1,0),(2,'invoice','invoice-send-to-client','english','Send Invoice to Customer','Invoice with number {invoice_number} created','<span style=\"font-size: 12pt;\">Dear {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">We have prepared the following invoice for you: <strong># {invoice_number}</strong></span><br /><br /><span style=\"font-size: 12pt;\"><strong>Invoice status</strong>: {invoice_status}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the invoice on the following link: <a href=\"{invoice_link}\">{invoice_number}</a></span><br /><br /><span style=\"font-size: 12pt;\">Please contact us for more information.</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(3,'ticket','new-ticket-opened-admin','english','New Ticket Opened (Opened by Staff, Sent to Customer)','New Support Ticket Opened','<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">New support ticket has been opened.</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject:</strong> {ticket_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Department:</strong> {ticket_department}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority:</strong> {ticket_priority}<br /></span><br /><span style=\"font-size: 12pt;\"><strong>Ticket message:</strong></span><br /><span style=\"font-size: 12pt;\">{ticket_message}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_public_url}\">#{ticket_id}</a><br /><br />Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(4,'ticket','ticket-reply','english','Ticket Reply (Sent to Customer)','New Ticket Reply','<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">You have a new ticket reply to ticket <a href=\"{ticket_public_url}\">#{ticket_id}</a></span><br /><br /><span style=\"font-size: 12pt;\"><strong>Ticket Subject:</strong> {ticket_subject}<br /></span><br /><span style=\"font-size: 12pt;\"><strong>Ticket message:</strong></span><br /><span style=\"font-size: 12pt;\">{ticket_message}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_public_url}\">#{ticket_id}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(5,'ticket','ticket-autoresponse','english','New Ticket Opened - Autoresponse','New Support Ticket Opened','<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">Thank you for contacting our support team. A support ticket has now been opened for your request. You will be notified when a response is made by email.</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject:</strong> {ticket_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Department</strong>: {ticket_department}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority:</strong> {ticket_priority}</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Ticket message:</strong></span><br /><span style=\"font-size: 12pt;\">{ticket_message}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_public_url}\">#{ticket_id}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(6,'invoice','invoice-payment-recorded','english','Invoice Payment Recorded (Sent to Customer)','Invoice Payment Recorded','<span style=\"font-size: 12pt;\">Hello {contact_firstname}&nbsp;{contact_lastname}<br /><br /></span>Thank you for the payment. Find the payment details below:<br /><br />-------------------------------------------------<br /><br />Amount:&nbsp;<strong>{payment_total}<br /></strong>Date:&nbsp;<strong>{payment_date}</strong><br />Invoice number:&nbsp;<span style=\"font-size: 12pt;\"><strong># {invoice_number}<br /><br /></strong></span>-------------------------------------------------<br /><br />You can always view the invoice for this payment at the following link:&nbsp;<a href=\"{invoice_link}\"><span style=\"font-size: 12pt;\">{invoice_number}</span></a><br /><br />We are looking forward working with you.<br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(7,'invoice','invoice-overdue-notice','english','Invoice Overdue Notice','Invoice Overdue Notice - {invoice_number}','<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">This is an overdue notice for invoice <strong># {invoice_number}</strong></span><br /><br /><span style=\"font-size: 12pt;\">This invoice was due: {invoice_duedate}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the invoice on the following link: <a href=\"{invoice_link}\">{invoice_number}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(8,'invoice','invoice-already-send','english','Invoice Already Sent to Customer','Invoice # {invoice_number} ','<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">At your request, here is the invoice with number <strong># {invoice_number}</strong></span><br /><br /><span style=\"font-size: 12pt;\">You can view the invoice on the following link: <a href=\"{invoice_link}\">{invoice_number}</a></span><br /><br /><span style=\"font-size: 12pt;\">Please contact us for more information.</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(9,'ticket','new-ticket-created-staff','english','New Ticket Created (Opened by Customer, Sent to Staff Members)','New Ticket Created','<p><span style=\"font-size: 12pt;\">A new support ticket has been opened.</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject</strong>: {ticket_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Department</strong>: {ticket_department}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority</strong>: {ticket_priority}<br /></span><br /><span style=\"font-size: 12pt;\"><strong>Ticket message:</strong></span><br /><span style=\"font-size: 12pt;\">{ticket_message}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_url}\">#{ticket_id}</a></span><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span></p>','{companyname} | CRM','',0,1,0),(10,'estimate','estimate-send-to-client','english','Send Estimate to Customer','Estimate # {estimate_number} created','<span style=\"font-size: 12pt;\">Dear {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">Please find the attached estimate <strong># {estimate_number}</strong></span><br /><br /><span style=\"font-size: 12pt;\"><strong>Estimate status:</strong> {estimate_status}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the estimate on the following link: <a href=\"{estimate_link}\">{estimate_number}</a></span><br /><br /><span style=\"font-size: 12pt;\">We look forward to your communication.</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}<br /></span>','{companyname} | CRM','',0,1,0),(11,'ticket','ticket-reply-to-admin','english','Ticket Reply (Sent to Staff)','New Support Ticket Reply','<span style=\"font-size: 12pt;\">A new support ticket reply from {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject</strong>: {ticket_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Department</strong>: {ticket_department}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority</strong>: {ticket_priority}</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Ticket message:</strong></span><br /><span style=\"font-size: 12pt;\">{ticket_message}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_url}\">#{ticket_id}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(12,'estimate','estimate-already-send','english','Estimate Already Sent to Customer','Estimate # {estimate_number} ','<span style=\"font-size: 12pt;\">Dear {contact_firstname} {contact_lastname}</span><br /> <br /><span style=\"font-size: 12pt;\">Thank you for your estimate request.</span><br /> <br /><span style=\"font-size: 12pt;\">You can view the estimate on the following link: <a href=\"{estimate_link}\">{estimate_number}</a></span><br /> <br /><span style=\"font-size: 12pt;\">Please contact us for more information.</span><br /> <br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(13,'contract','contract-expiration','english','Contract Expiration Reminder (Sent to Customer Contacts)','Contract Expiration Reminder','<span style=\"font-size: 12pt;\">Dear {client_company}</span><br /><br /><span style=\"font-size: 12pt;\">This is a reminder that the following contract will expire soon:</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject:</strong> {contract_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Description:</strong> {contract_description}</span><br /><span style=\"font-size: 12pt;\"><strong>Date Start:</strong> {contract_datestart}</span><br /><span style=\"font-size: 12pt;\"><strong>Date End:</strong> {contract_dateend}</span><br /><br /><span style=\"font-size: 12pt;\">Please contact us for more information.</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(14,'tasks','task-assigned','english','New Task Assigned (Sent to Staff)','New Task Assigned to You - {task_name}','<span style=\"font-size: 12pt;\">Dear {staff_firstname}</span><br /><br /><span style=\"font-size: 12pt;\">You have been assigned to a new task:</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Name:</strong> {task_name}<br /></span><strong>Start Date:</strong> {task_startdate}<br /><span style=\"font-size: 12pt;\"><strong>Due date:</strong> {task_duedate}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority:</strong> {task_priority}<br /><br /></span><span style=\"font-size: 12pt;\"><span>You can view the task on the following link</span>: <a href=\"{task_link}\">{task_name}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(15,'tasks','task-added-as-follower','english','Staff Member Added as Follower on Task (Sent to Staff)','You are added as follower on task - {task_name}','<span style=\"font-size: 12pt;\">Hi {staff_firstname}<br /></span><br /><span style=\"font-size: 12pt;\">You have been added as follower on the following task:</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Name:</strong> {task_name}</span><br /><span style=\"font-size: 12pt;\"><strong>Start date:</strong> {task_startdate}</span><br /><br /><span>You can view the task on the following link</span><span>: </span><a href=\"{task_link}\">{task_name}</a><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(16,'tasks','task-commented','english','New Comment on Task (Sent to Staff)','New Comment on Task - {task_name}','Dear {staff_firstname}<br /><br />A comment has been made on the following task:<br /><br /><strong>Name:</strong> {task_name}<br /><strong>Comment:</strong> {task_comment}<br /><br />You can view the task on the following link: <a href=\"{task_link}\">{task_name}</a><br /><br />Kind Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),(17,'tasks','task-added-attachment','english','New Attachment(s) on Task (Sent to Staff)','New Attachment on Task - {task_name}','Hi {staff_firstname}<br /><br /><strong>{task_user_take_action}</strong> added an attachment on the following task:<br /><br /><strong>Name:</strong> {task_name}<br /><br />You can view the task on the following link: <a href=\"{task_link}\">{task_name}</a><br /><br />Kind Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),(18,'estimate','estimate-declined-to-staff','english','Estimate Declined (Sent to Staff)','Customer Declined Estimate','<span style=\"font-size: 12pt;\">Hi</span><br /> <br /><span style=\"font-size: 12pt;\">Customer ({client_company}) declined estimate with number <strong># {estimate_number}</strong></span><br /> <br /><span style=\"font-size: 12pt;\">You can view the estimate on the following link: <a href=\"{estimate_link}\">{estimate_number}</a></span><br /> <br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(19,'estimate','estimate-accepted-to-staff','english','Estimate Accepted (Sent to Staff)','Customer Accepted Estimate','<span style=\"font-size: 12pt;\">Hi</span><br /> <br /><span style=\"font-size: 12pt;\">Customer ({client_company}) accepted estimate with number <strong># {estimate_number}</strong></span><br /> <br /><span style=\"font-size: 12pt;\">You can view the estimate on the following link: <a href=\"{estimate_link}\">{estimate_number}</a></span><br /> <br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(20,'proposals','proposal-client-accepted','english','Customer Action - Accepted (Sent to Staff)','Customer Accepted Proposal','<div>Hi<br /> <br />Client <strong>{proposal_proposal_to}</strong> accepted the following proposal:<br /> <br /><strong>Number:</strong> {proposal_number}<br /><strong>Subject</strong>: {proposal_subject}<br /><strong>Total</strong>: {proposal_total}<br /> <br />View the proposal on the following link: <a href=\"{proposal_link}\">{proposal_number}</a><br /> <br />Kind Regards,<br />{email_signature}</div>\r\n<div>&nbsp;</div>\r\n<div>&nbsp;</div>\r\n<div>&nbsp;</div>','{companyname} | CRM','',0,1,0),(21,'proposals','proposal-send-to-customer','english','Send Proposal to Customer','Proposal With Number {proposal_number} Created','Dear {proposal_proposal_to}<br /><br />Please find our attached proposal.<br /><br />This proposal is valid until: {proposal_open_till}<br />You can view the proposal on the following link: <a href=\"{proposal_link}\">{proposal_number}</a><br /><br />Please don\'t hesitate to comment online if you have any questions.<br /><br />We look forward to your communication.<br /><br />Kind Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),(22,'proposals','proposal-client-declined','english','Customer Action - Declined (Sent to Staff)','Client Declined Proposal','Hi<br /> <br />Customer <strong>{proposal_proposal_to}</strong> declined the proposal <strong>{proposal_subject}</strong><br /> <br />View the proposal on the following link <a href=\"{proposal_link}\">{proposal_number}</a>&nbsp;or from the admin area.<br /> <br />Kind Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),(23,'proposals','proposal-client-thank-you','english','Thank You Email (Sent to Customer After Accept)','Thank for you accepting proposal','Dear {proposal_proposal_to}<br /> <br />Thank for for accepting the proposal.<br /> <br />We look forward to doing business with you.<br /> <br />We will contact you as soon as possible<br /> <br />Kind Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),(24,'proposals','proposal-comment-to-client','english','New Comment Â (Sent to Customer/Lead)','New Proposal Comment','Dear {proposal_proposal_to}<br /> <br />A new comment has been made on the following proposal: <strong>{proposal_number}</strong><br /> <br />You can view and reply to the comment on the following link: <a href=\"{proposal_link}\">{proposal_number}</a><br /> <br />Kind Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),(25,'proposals','proposal-comment-to-admin','english','New Comment (Sent to Staff) ','New Proposal Comment','Hi<br /> <br />A new comment has been made to the proposal <strong>{proposal_subject}</strong><br /> <br />You can view and reply to the comment on the following link: <a href=\"{proposal_link}\">{proposal_number}</a>&nbsp;or from the admin area.<br /> <br />{email_signature}','{companyname} | CRM','',0,1,0),(26,'estimate','estimate-thank-you-to-customer','english','Thank You Email (Sent to Customer After Accept)','Thank for you accepting estimate','<span style=\"font-size: 12pt;\">Dear {contact_firstname} {contact_lastname}</span><br /> <br /><span style=\"font-size: 12pt;\">Thank for for accepting the estimate.</span><br /> <br /><span style=\"font-size: 12pt;\">We look forward to doing business with you.</span><br /> <br /><span style=\"font-size: 12pt;\">We will contact you as soon as possible.</span><br /> <br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(27,'tasks','task-deadline-notification','english','Task Deadline Reminder - Sent to Assigned Members','Task Deadline Reminder','Hi {staff_firstname}&nbsp;{staff_lastname}<br /><br />This is an automated email from {companyname}.<br /><br />The task <strong>{task_name}</strong> deadline is on <strong>{task_duedate}</strong>. <br />This task is still not finished.<br /><br />You can view the task on the following link: <a href=\"{task_link}\">{task_name}</a><br /><br />Kind Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),(28,'contract','send-contract','english','Send Contract to Customer','Contract - {contract_subject}','<p><span style=\"font-size: 12pt;\">Hi&nbsp;{contact_firstname}&nbsp;{contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">Please find the <a href=\"{contract_link}\">{contract_subject}</a> attached.<br /><br />Description: {contract_description}<br /><br /></span><span style=\"font-size: 12pt;\">Looking forward to hear from you.</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span></p>','{companyname} | CRM','',0,1,0),(29,'invoice','invoice-payment-recorded-to-staff','english','Invoice Payment Recorded (Sent to Staff)','New Invoice Payment','<span style=\"font-size: 12pt;\">Hi</span><br /><br /><span style=\"font-size: 12pt;\">Customer recorded payment for invoice <strong># {invoice_number}</strong></span><br /> <br /><span style=\"font-size: 12pt;\">You can view the invoice on the following link: <a href=\"{invoice_link}\">{invoice_number}</a></span><br /> <br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(30,'ticket','auto-close-ticket','english','Auto Close Ticket','Ticket Auto Closed','<p><span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">Ticket {ticket_subject} has been auto close due to inactivity.</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Ticket #</strong>: <a href=\"{ticket_public_url}\">{ticket_id}</a></span><br /><span style=\"font-size: 12pt;\"><strong>Department</strong>: {ticket_department}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority:</strong> {ticket_priority}</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span></p>','{companyname} | CRM','',0,1,0),(31,'project','new-project-discussion-created-to-staff','english','New Project Discussion (Sent to Project Members)','New Project Discussion Created - {project_name}','<p>Hi {staff_firstname}<br /><br />New project discussion created from <strong>{discussion_creator}</strong><br /><br /><strong>Subject:</strong> {discussion_subject}<br /><strong>Description:</strong> {discussion_description}<br /><br />You can view the discussion on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a><br /><br />Kind Regards,<br />{email_signature}</p>','{companyname} | CRM','',0,1,0),(32,'project','new-project-discussion-created-to-customer','english','New Project Discussion (Sent to Customer Contacts)','New Project Discussion Created - {project_name}','<p>Hello {contact_firstname} {contact_lastname}<br /><br />New project discussion created from <strong>{discussion_creator}</strong><br /><br /><strong>Subject:</strong> {discussion_subject}<br /><strong>Description:</strong> {discussion_description}<br /><br />You can view the discussion on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a><br /><br />Kind Regards,<br />{email_signature}</p>','{companyname} | CRM','',0,1,0),(33,'project','new-project-file-uploaded-to-customer','english','New Project File(s) Uploaded (Sent to Customer Contacts)','New Project File(s) Uploaded - {project_name}','<p>Hello {contact_firstname} {contact_lastname}<br /><br />New project file is uploaded on <strong>{project_name}</strong> from <strong>{file_creator}</strong><br /><br />You can view the project on the following link: <a href=\"{project_link}\">{project_name}</a><br /><br />To view the file in our CRM you can click on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a><br /><br />Kind Regards,<br />{email_signature}</p>','{companyname} | CRM','',0,1,0),(34,'project','new-project-file-uploaded-to-staff','english','New Project File(s) Uploaded (Sent to Project Members)','New Project File(s) Uploaded - {project_name}','<p>Hello&nbsp;{staff_firstname}</p>\r\n<p>New project&nbsp;file is uploaded on&nbsp;<strong>{project_name}</strong> from&nbsp;<strong>{file_creator}</strong></p>\r\n<p>You can view the project on the following link: <a href=\"{project_link}\">{project_name}<br /></a><br />To view&nbsp;the file you can click on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a></p>\r\n<p>Kind Regards,<br />{email_signature}</p>','{companyname} | CRM','',0,1,0),(35,'project','new-project-discussion-comment-to-customer','english','New Discussion Comment  (Sent to Customer Contacts)','New Discussion Comment','<p><span style=\"font-size: 12pt;\">Hello {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">New discussion comment has been made on <strong>{discussion_subject}</strong> from <strong>{comment_creator}</strong></span><br /><br /><span style=\"font-size: 12pt;\"><strong>Discussion subject:</strong> {discussion_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Comment</strong>: {discussion_comment}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the discussion on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span></p>','{companyname} | CRM','',0,1,0),(36,'project','new-project-discussion-comment-to-staff','english','New Discussion Comment (Sent to Project Members)','New Discussion Comment','<p>Hi {staff_firstname}<br /><br />New discussion comment has been made on <strong>{discussion_subject}</strong> from <strong>{comment_creator}</strong><br /><br /><strong>Discussion subject:</strong> {discussion_subject}<br /><strong>Comment:</strong> {discussion_comment}<br /><br />You can view the discussion on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a><br /><br />Kind Regards,<br />{email_signature}</p>','{companyname} | CRM','',0,1,0),(37,'project','staff-added-as-project-member','english','Staff Added as Project Member','New project assigned to you','<p>Hi {staff_firstname}<br /><br />New project has been assigned to you.<br /><br />You can view the project on the following link <a href=\"{project_link}\">{project_name}</a><br /><br />{email_signature}</p>','{companyname} | CRM','',0,1,0),(38,'estimate','estimate-expiry-reminder','english','Estimate Expiration Reminder','Estimate Expiration Reminder','<p><span style=\"font-size: 12pt;\">Hello {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">The estimate with <strong># {estimate_number}</strong> will expire on <strong>{estimate_expirydate}</strong></span><br /><br /><span style=\"font-size: 12pt;\">You can view the estimate on the following link: <a href=\"{estimate_link}\">{estimate_number}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span></p>','{companyname} | CRM','',0,1,0),(39,'proposals','proposal-expiry-reminder','english','Proposal Expiration Reminder','Proposal Expiration Reminder','<p>Hello {proposal_proposal_to}<br /><br />The proposal {proposal_number}&nbsp;will expire on <strong>{proposal_open_till}</strong><br /><br />You can view the proposal on the following link: <a href=\"{proposal_link}\">{proposal_number}</a><br /><br />Kind Regards,<br />{email_signature}</p>','{companyname} | CRM','',0,1,0),(40,'staff','new-staff-created','english','New Staff Created (Welcome Email)','You are added as staff member','Hi {staff_firstname}<br /><br />You are added as member on our CRM.<br /><br />Please use the following logic credentials:<br /><br /><strong>Email:</strong> {staff_email}<br /><strong>Password:</strong> {password}<br /><br />Click <a href=\"{admin_url}\">here </a>to login in the dashboard.<br /><br />Best Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),(41,'client','contact-forgot-password','english','Forgot Password','Create New Password','<h2>Create a new password</h2>\r\nForgot your password?<br /> To create a new password, just follow this link:<br /> <br /><a href=\"{reset_password_url}\">Reset Password</a><br /> <br /> You received this email, because it was requested by a {companyname}&nbsp;user. This is part of the procedure to create a new password on the system. If you DID NOT request a new password then please ignore this email and your password will remain the same. <br /><br /> {email_signature}','{companyname} | CRM','',0,1,0),(42,'client','contact-password-reseted','english','Password Reset - Confirmation','Your password has been changed','<strong><span style=\"font-size: 14pt;\">You have changed your password.</span><br /></strong><br /> Please, keep it in your records so you don\'t forget it.<br /> <br /> Your email address for login is: {contact_email}<br /><br />If this wasnt you, please contact us.<br /><br />{email_signature}','{companyname} | CRM','',0,1,0),(43,'client','contact-set-password','english','Set New Password','Set new password on {companyname} ','<h2><span style=\"font-size: 14pt;\">Setup your new password on {companyname}</span></h2>\r\nPlease use the following link to set up your new password:<br /><br /><a href=\"{set_password_url}\">Set new password</a><br /><br />Keep it in your records so you don\'t forget it.<br /><br />Please set your new password in <strong>48 hours</strong>. After that, you won\'t be able to set your password because this link will expire.<br /><br />You can login at: <a href=\"{crm_url}\">{crm_url}</a><br />Your email address for login: {contact_email}<br /><br />{email_signature}','{companyname} | CRM','',0,1,0),(44,'staff','staff-forgot-password','english','Forgot Password','Create New Password','<h2><span style=\"font-size: 14pt;\">Create a new password</span></h2>\r\nForgot your password?<br /> To create a new password, just follow this link:<br /> <br /><a href=\"{reset_password_url}\">Reset Password</a><br /> <br /> You received this email, because it was requested by a <strong>{companyname}</strong>&nbsp;user. This is part of the procedure to create a new password on the system. If you DID NOT request a new password then please ignore this email and your password will remain the same. <br /><br /> {email_signature}','{companyname} | CRM','',0,1,0),(45,'staff','staff-password-reseted','english','Password Reset - Confirmation','Your password has been changed','<span style=\"font-size: 14pt;\"><strong>You have changed your password.<br /></strong></span><br /> Please, keep it in your records so you don\'t forget it.<br /> <br /> Your email address for login is: {staff_email}<br /><br /> If this wasnt you, please contact us.<br /><br />{email_signature}','{companyname} | CRM','',0,1,0),(46,'project','assigned-to-project','english','New Project Created (Sent to Customer Contacts)','New Project Created','<p>Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}</p>\r\n<p>New project is assigned to your company.<br /><br /><strong>Project Name:</strong>&nbsp;{project_name}<br /><strong>Project Start Date:</strong>&nbsp;{project_start_date}</p>\r\n<p>You can view the project on the following link:&nbsp;<a href=\"{project_link}\">{project_name}</a></p>\r\n<p>We are looking forward hearing from you.<br /><br />Kind Regards,<br />{email_signature}</p>','{companyname} | CRM','',0,1,0),(47,'tasks','task-added-attachment-to-contacts','english','New Attachment(s) on Task (Sent to Customer Contacts)','New Attachment on Task - {task_name}','<span>Hi {contact_firstname} {contact_lastname}</span><br /><br /><strong>{task_user_take_action}</strong><span> added an attachment on the following task:</span><br /><br /><strong>Name:</strong><span> {task_name}</span><br /><br /><span>You can view the task on the following link: </span><a href=\"{task_link}\">{task_name}</a><br /><br /><span>Kind Regards,</span><br /><span>{email_signature}</span>','{companyname} | CRM','',0,1,0),(48,'tasks','task-commented-to-contacts','english','New Comment on Task (Sent to Customer Contacts)','New Comment on Task - {task_name}','<span>Dear {contact_firstname} {contact_lastname}</span><br /><br /><span>A comment has been made on the following task:</span><br /><br /><strong>Name:</strong><span> {task_name}</span><br /><strong>Comment:</strong><span> {task_comment}</span><br /><br /><span>You can view the task on the following link: </span><a href=\"{task_link}\">{task_name}</a><br /><br /><span>Kind Regards,</span><br /><span>{email_signature}</span>','{companyname} | CRM','',0,1,0),(49,'leads','new-lead-assigned','english','New Lead Assigned to Staff Member','New lead assigned to you','<p>Hello {lead_assigned}<br /><br />New lead is assigned to you.<br /><br /><strong>Lead Name:</strong>&nbsp;{lead_name}<br /><strong>Lead Email:</strong>&nbsp;{lead_email}<br /><br />You can view the lead on the following link: <a href=\"{lead_link}\">{lead_name}</a><br /><br />Kind Regards,<br />{email_signature}</p>','{companyname} | CRM','',0,1,0),(50,'client','client-statement','english','Statement - Account Summary','Account Statement from {statement_from} to {statement_to}','Dear {contact_firstname} {contact_lastname}, <br /><br />Its been a great experience working with you.<br /><br />Attached with this email is a list of all transactions for the period between {statement_from} to {statement_to}<br /><br />For your information your account balance due is total:&nbsp;{statement_balance_due}<br /><br />Please contact us if you need more information.<br /> <br />Kind Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),(51,'ticket','ticket-assigned-to-admin','english','New Ticket Assigned (Sent to Staff)','New support ticket has been assigned to you','<p><span style=\"font-size: 12pt;\">Hi</span></p>\r\n<p><span style=\"font-size: 12pt;\">A new support ticket&nbsp;has been assigned to you.</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject</strong>: {ticket_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Department</strong>: {ticket_department}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority</strong>: {ticket_priority}</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Ticket message:</strong></span><br /><span style=\"font-size: 12pt;\">{ticket_message}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_url}\">#{ticket_id}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span></p>','{companyname} | CRM','',0,1,0),(52,'client','new-client-registered-to-admin','english','New Customer Registration (Sent to admins)','New Customer Registration','Hello.<br /><br />New customer registration on your customer portal:<br /><br /><strong>Firstname:</strong>&nbsp;{contact_firstname}<br /><strong>Lastname:</strong>&nbsp;{contact_lastname}<br /><strong>Company:</strong>&nbsp;{client_company}<br /><strong>Email:</strong>&nbsp;{contact_email}<br /><br />Best Regards','{companyname} | CRM','',0,1,0),(53,'leads','new-web-to-lead-form-submitted','english','Web to lead form submitted - Sent to lead','{lead_name} - We Received Your Request','Hello {lead_name}.<br /><br /><strong>Your request has been received.</strong><br /><br />This email is to let you know that we received your request and we will get back to you as soon as possible with more information.<br /><br />Best Regards,<br />{email_signature}','{companyname} | CRM','',0,0,0),(54,'staff','two-factor-authentication','english','Two Factor Authentication','Confirm Your Login','<p>Hi {staff_firstname}</p>\r\n<p style=\"text-align: left;\">You received this email because you have enabled two factor authentication in your account.<br />Use the following code to confirm your login:</p>\r\n<p style=\"text-align: left;\"><span style=\"font-size: 18pt;\"><strong>{two_factor_auth_code}<br /><br /></strong><span style=\"font-size: 12pt;\">{email_signature}</span><strong><br /><br /><br /><br /></strong></span></p>','{companyname} | CRM','',0,1,0),(55,'project','project-finished-to-customer','english','Project Marked as Finished (Sent to Customer Contacts)','Project Marked as Finished','<p>Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}</p>\r\n<p>You are receiving this email because project&nbsp;<strong>{project_name}</strong> has been marked as finished. This project is assigned under your company and we just wanted to keep you up to date.<br /><br />You can view the project on the following link:&nbsp;<a href=\"{project_link}\">{project_name}</a></p>\r\n<p>If you have any questions don\'t hesitate to contact us.<br /><br />Kind Regards,<br />{email_signature}</p>','{companyname} | CRM','',0,1,0),(56,'credit_note','credit-note-send-to-client','english','Send Credit Note To Email','Credit Note With Number #{credit_note_number} Created','Dear&nbsp;{contact_firstname}&nbsp;{contact_lastname}<br /><br />We have attached the credit note with number <strong>#{credit_note_number} </strong>for your reference.<br /><br /><strong>Date:</strong>&nbsp;{credit_note_date}<br /><strong>Total Amount:</strong>&nbsp;{credit_note_total}<br /><br /><span style=\"font-size: 12pt;\">Please contact us for more information.</span><br /> <br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(57,'tasks','task-status-change-to-staff','english','Task Status Changed (Sent to Staff)','Task Status Changed','<span style=\"font-size: 12pt;\">Hi {staff_firstname}</span><br /><br /><span style=\"font-size: 12pt;\"><strong>{task_user_take_action}</strong> marked task as <strong>{task_status}</strong></span><br /><br /><span style=\"font-size: 12pt;\"><strong>Name:</strong> {task_name}</span><br /><span style=\"font-size: 12pt;\"><strong>Due date:</strong> {task_duedate}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the task on the following link: <a href=\"{task_link}\">{task_name}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(58,'tasks','task-status-change-to-contacts','english','Task Status Changed (Sent to Customer Contacts)','Task Status Changed','<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\"><strong>{task_user_take_action}</strong> marked task as <strong>{task_status}</strong></span><br /><br /><span style=\"font-size: 12pt;\"><strong>Name:</strong> {task_name}</span><br /><span style=\"font-size: 12pt;\"><strong>Due date:</strong> {task_duedate}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the task on the following link: <a href=\"{task_link}\">{task_name}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(59,'staff','reminder-email-staff','english','Staff Reminder Email','You Have a New Reminder!','<p>Hello&nbsp;{staff_firstname}<br /><br /><strong>You have a new reminder&nbsp;linked to&nbsp;{staff_reminder_relation_name}!<br /><br />Reminder description:</strong><br />{staff_reminder_description}<br /><br />Click <a href=\"{staff_reminder_relation_link}\">here</a> to view&nbsp;<a href=\"{staff_reminder_relation_link}\">{staff_reminder_relation_name}</a><br /><br />Best Regards<br /><br /></p>','{companyname} | CRM','',0,1,0),(60,'contract','contract-comment-to-client','english','New Comment Â (Sent to Customer Contacts)','New Contract Comment','Dear {contact_firstname} {contact_lastname}<br /> <br />A new comment has been made on the following contract: <strong>{contract_subject}</strong><br /> <br />You can view and reply to the comment on the following link: <a href=\"{contract_link}\">{contract_subject}</a><br /> <br />Kind Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),(61,'contract','contract-comment-to-admin','english','New Comment (Sent to Staff) ','New Contract Comment','Hi {staff_firstname}<br /><br />A new comment has been made to the contract&nbsp;<strong>{contract_subject}</strong><br /><br />You can view and reply to the comment on the following link: <a href=\"{contract_link}\">{contract_subject}</a>&nbsp;or from the admin area.<br /><br />{email_signature}','{companyname} | CRM','',0,1,0),(62,'subscriptions','send-subscription','english','Send Subscription to Customer','Subscription Created','Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}<br /><br />We have prepared the subscription&nbsp;<strong>{subscription_name}</strong> for your company.<br /><br />Click <a href=\"{subscription_link}\">here</a> to review the subscription and subscribe.<br /><br />Best Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),(63,'subscriptions','subscription-payment-failed','english','Subscription Payment Failed','Your most recent invoice payment failed','Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}<br /><br br=\"\" />Unfortunately, your most recent invoice payment for&nbsp;<strong>{subscription_name}</strong> was declined.<br /><br />This could be due to a change in your card number, your card expiring,<br />cancellation of your credit card, or the card issuer not recognizing the<br />payment and therefore taking action to prevent it.<br /><br />Please update your payment information as soon as possible by logging in here:<br /><a href=\"{crm_url}/login\">{crm_url}/login</a><br /><br />Best Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),(64,'subscriptions','subscription-canceled','english','Subscription Canceled (Sent to customer primary contact)','Your subscription has been canceled','Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}<br /><br />Your subscription&nbsp;<strong>{subscription_name} </strong>has been canceled, if you have any questions don\'t hesitate to contact us.<br /><br />It was a pleasure doing business with you.<br /><br />Best Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),(65,'subscriptions','subscription-payment-succeeded','english','Subscription Payment Succeeded (Sent to customer primary contact)','Subscription  Payment Receipt - {subscription_name}','Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}<br /><br />This email is to let you know that we received your payment for subscription&nbsp;<strong>{subscription_name}&nbsp;</strong>of&nbsp;<strong><span>{payment_total}<br /><br /></span></strong>The invoice associated with it is now with status&nbsp;<strong>{invoice_status}<br /></strong><br />Thank you for your confidence.<br /><br />Best Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),(66,'contract','contract-expiration-to-staff','english','Contract Expiration Reminder (Sent to Staff)','Contract Expiration Reminder','Hi {staff_firstname}<br /><br /><span style=\"font-size: 12pt;\">This is a reminder that the following contract will expire soon:</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject:</strong> {contract_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Description:</strong> {contract_description}</span><br /><span style=\"font-size: 12pt;\"><strong>Date Start:</strong> {contract_datestart}</span><br /><span style=\"font-size: 12pt;\"><strong>Date End:</strong> {contract_dateend}</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(67,'gdpr','gdpr-removal-request','english','Removal Request From Contact (Sent to administrators)','Data Removal Request Received','Hello&nbsp;{staff_firstname}&nbsp;{staff_lastname}<br /><br />Data removal has been requested by&nbsp;{contact_firstname} {contact_lastname}<br /><br />You can review this request and take proper actions directly from the admin area.','{companyname} | CRM','',0,1,0),(68,'gdpr','gdpr-removal-request-lead','english','Removal Request From Lead (Sent to administrators)','Data Removal Request Received','Hello&nbsp;{staff_firstname}&nbsp;{staff_lastname}<br /><br />Data removal has been requested by {lead_name}<br /><br />You can review this request and take proper actions directly from the admin area.<br /><br />To view the lead inside the admin area click here:&nbsp;<a href=\"{lead_link}\">{lead_link}</a>','{companyname} | CRM','',0,1,0),(69,'client','client-registration-confirmed','english','Customer Registration Confirmed','Your registration is confirmed','<p>Dear {contact_firstname} {contact_lastname}<br /><br />We just wanted to let you know that your registration at&nbsp;{companyname} is successfully confirmed and your account is now active.<br /><br />You can login at&nbsp;<a href=\"{crm_url}\">{crm_url}</a> with the email and password you provided during registration.<br /><br />Please contact us if you need any help.<br /><br />Kind Regards, <br />{email_signature}</p>\r\n<p><br />(This is an automated email, so please don\'t reply to this email address)</p>','{companyname} | CRM','',0,1,0),(70,'contract','contract-signed-to-staff','english','Contract Signed (Sent to Staff)','Customer Signed a Contract','Hi {staff_firstname}<br /><br />A contract with subject&nbsp;<strong>{contract_subject} </strong>has been successfully signed by the customer.<br /><br />You can view the contract at the following link: <a href=\"{contract_link}\">{contract_subject}</a>&nbsp;or from the admin area.<br /><br />{email_signature}','{companyname} | CRM','',0,1,0),(71,'subscriptions','customer-subscribed-to-staff','english','Customer Subscribed to a Subscription (Sent to administrators and subscription creator)','Customer Subscribed to a Subscription','The customer <strong>{client_company}</strong> subscribed to a subscription with name&nbsp;<strong>{subscription_name}</strong><br /><br /><strong>ID</strong>:&nbsp;{subscription_id}<br /><strong>Subscription name</strong>:&nbsp;{subscription_name}<br /><strong>Subscription description</strong>:&nbsp;{subscription_description}<br /><br />You can view the subscription by clicking <a href=\"{subscription_link}\">here</a><br />\r\n<div style=\"text-align: center;\"><span style=\"font-size: 10pt;\">&nbsp;</span></div>\r\nBest Regards,<br />{email_signature}<br /><br /><span style=\"font-size: 10pt;\"><span style=\"color: #999999;\">You are receiving this email because you are either administrator or you are creator of the subscription.</span></span>','{companyname} | CRM','',0,1,0),(72,'client','contact-verification-email','english','Email Verification (Sent to Contact After Registration)','Verify Email Address','<p>Hello&nbsp;{contact_firstname}<br /><br />Please click the button below to verify your email address.<br /><br /><a href=\"{email_verification_url}\">Verify Email Address</a><br /><br />If you did not create an account, no further action is required</p>\r\n<p><br />{email_signature}</p>','{companyname} | CRM','',0,1,0),(73,'client','new-customer-profile-file-uploaded-to-staff','english','New Customer Profile File(s) Uploaded (Sent to Staff)','Customer Uploaded New File(s) in Profile','Hi!<br /><br />New file(s) is uploaded into the customer ({client_company}) profile by&nbsp;{contact_firstname}<br /><br />You can check the uploaded files into the admin area by clicking <a href=\"{customer_profile_files_admin_link}\">here</a> or at the following link:&nbsp;{customer_profile_files_admin_link}<br /><br />{email_signature}','{companyname} | CRM','',0,1,0),(74,'staff','event-notification-to-staff','english','Event Notification (Calendar)','Upcoming Event - {event_title}','Hi {staff_firstname}! <br /><br />This is a reminder for event <a href=\\\"{event_link}\\\">{event_title}</a> scheduled at {event_start_date}. <br /><br />Regards.','','',0,1,0),(75,'subscriptions','subscription-payment-requires-action','english','Credit Card Authorization Required - SCA','Important: Confirm your subscription {subscription_name} payment','<p>Hello {contact_firstname}</p>\r\n<p><strong>Your bank sometimes requires an additional step to make sure an online transaction was authorized.</strong><br /><br />Because of European regulation to protect consumers, many online payments now require two-factor authentication. Your bank ultimately decides when authentication is required to confirm a payment, but you may notice this step when you start paying for a service or when the cost changes.<br /><br />In order to pay the subscription <strong>{subscription_name}</strong>, you will need to&nbsp;confirm your payment by clicking on the follow link: <strong><a href=\"{subscription_authorize_payment_link}\">{subscription_authorize_payment_link}</a></strong><br /><br />To view the subscription, please click at the following link: <a href=\"{subscription_link}\"><span>{subscription_link}</span></a><br />or you can login in our dedicated area here: <a href=\"{crm_url}/login\">{crm_url}/login</a> in case you want to update your credit card or view the subscriptions you are subscribed.<br /><br />Best Regards,<br />{email_signature}</p>','{companyname} | CRM','',0,1,0),(76,'invoice','invoice-due-notice','english','Invoice Due Notice','Your {invoice_number} will be due soon','<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}<br /><br /></span>You invoice <span style=\"font-size: 12pt;\"><strong># {invoice_number} </strong>will be due on <strong>{invoice_duedate}</strong></span><br /><br /><span style=\"font-size: 12pt;\">You can view the invoice on the following link: <a href=\"{invoice_link}\">{invoice_number}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),(77,'estimate_request','estimate-request-submitted-to-staff','english','Estimate Request Submitted (Sent to Staff)','New Estimate Request Submitted','<span> Hello,&nbsp;</span><br /><br />{estimate_request_email} submitted an estimate request via the {estimate_request_form_name} form.<br /><br />You can view the request at the following link: <a href=\"{estimate_request_link}\">{estimate_request_link}</a><br /><br />==<br /><br />{estimate_request_submitted_data}<br /><br />Kind Regards,<br /><span>{email_signature}</span>','{companyname} | CRM','',0,1,0),(78,'estimate_request','estimate-request-assigned','english','Estimate Request Assigned (Sent to Staff)','New Estimate Request Assigned','<span> Hello {estimate_request_assigned},&nbsp;</span><br /><br />Estimate request #{estimate_request_id} has been assigned to you.<br /><br />You can view the request at the following link: <a href=\"{estimate_request_link}\">{estimate_request_link}</a><br /><br />Kind Regards,<br /><span>{email_signature}</span>','{companyname} | CRM','',0,1,0),(79,'estimate_request','estimate-request-received-to-user','english','Estimate Request Received (Sent to User)','Estimate Request Received','Hello,<br /><br /><strong>Your request has been received.</strong><br /><br />This email is to let you know that we received your request and we will get back to you as soon as possible with more information.<br /><br />Best Regards,<br />{email_signature}','{companyname} | CRM','',0,0,0),(80,'notifications','non-billed-tasks-reminder','english','Non-billed tasks reminder (sent to selected staff members)','Action required: Completed tasks are not billed','Hello {staff_firstname}<br><br>The following tasks are marked as complete but not yet billed:<br><br>{unbilled_tasks_list}<br><br>Kind Regards,<br><br>{email_signature}','{companyname} | CRM','',0,1,0),(81,'invoice','invoices-batch-payments','english','Invoices Payments Recorded in Batch (Sent to Customer)','We have received your payments','Hello {contact_firstname} {contact_lastname}<br><br>Thank you for the payments. Please find the payments details below:<br><br>{batch_payments_list}<br><br>We are looking forward working with you.<br><br>Kind Regards,<br><br>{email_signature}','{companyname} | CRM','',0,1,0),(82,'contract','contract-sign-reminder','english','Contract Sign Reminder (Sent to Customer)','Contract Sign Reminder','<p>Hello {contact_firstname} {contact_lastname}<br /><br />This is a reminder to review and sign the contract:<a href=\"{contract_link}\">{contract_subject}</a></p><p>You can view and sign by visiting: <a href=\"{contract_link}\">{contract_subject}</a></p><p><br />We are looking forward working with you.<br /><br />Kind Regards,<br /><br />{email_signature}</p>','{companyname} | CRM','',0,1,0),(83,'timesheets_attendance_mgt','attendance_notice','english','Attendance notice','Timesheets - Attendance notice','{staff_name} {type_check} at {date_time}','{companyname} | CRM',NULL,0,1,0),(84,'timesheets_attendance_mgt','send_request_approval','english','Send request approval','Timesheets - Send request approval to approver','Hi {approver}! <br>-{staff_name} has created an apply for leave and requires your approval. Please go to this link for details and approval: {link}','{companyname} | CRM',NULL,0,1,0),(85,'timesheets_attendance_mgt','remind_user_check_in','english','Remind user check in','Timesheets - Remind user check in','Remind you to check in today to record the start time of the shift {date_time}','{companyname} | CRM',NULL,0,1,0),(86,'timesheets_attendance_mgt','new_leave_application_send_to_notification_recipient','english','New application (Send to notification recipient)','Timesheets - New application - Send to notification recipient','{staff_name} created a new application {link} at {date_time}','{companyname} | CRM',NULL,0,1,0),(87,'client','affiliate_management_payout_updated','english','Affiliate Payout Request Update','An update regarding your payout request','Dear {contact_firstname},<br/><br/>\n    We hope this message finds you well.\n    <br/>\n    We wanted to inform you about the latest status of your payout request, identified by reference number <b>#{payout_id}</b>. \n    <br/><br/>\n    Amount: {payout_amount}<br/>\n    Status: {payout_status}<br/>\n    Note: {payout_note_for_affiliate}<br/>\n    Created: {payout_created_at}<br/>\n    <br/><br/>\n    If you have any questions or need further clarification, please do not hesitate to reach out. We are here to assist you in any way possible.<br/><br/>\n    \n    Best regards,<br/>\n    {email_signature}','{companyname} | CRM',NULL,0,1,0),(88,'client','affiliate_management_signup_through_affiliate_link','english','Successful Signup through Affiliate Link','Congratulations on a successful signup!','Dear {contact_firstname},<br/><br/>\n    We are delighted to inform you that someone has successfully signed up using your affiliate link.\n    <br/><br/>\n    Company/Contact: {referral_name}<br/>\n    Date: {referral_created_at}<br/>\n    <br/><br/>\n    While this signup may not have resulted in an immediate transaction, your efforts are highly valued. We appreciate your contribution to our community and anticipate further success in the future.\n    <br/><br/>\n    If you have any questions or need additional information, please feel free to reach out.\n    <br/><br/>\n    Best regards,<br/>\n    {email_signature}','{companyname} | CRM',NULL,0,1,0),(89,'client','affiliate_management_successful_referral_commission','english','Successful Referral Commission Notification','A referral commission received!','Dear {contact_firstname},<br/><br/>\n    We are thrilled to inform you that your referral has resulted in a successful transaction, earning you a commission.\n    <br/><br/>\n    Company/Contact: {referral_name}<br/>\n    Transaction Amount: {payment_amount}<br/>\n    Commission Earned: {commission_amount}<br/>\n    New Balance: {affiliate_balance}<br/>\n    Date: {commission_created_at}<br/>\n    <br/><br/>\n    We appreciate your efforts and look forward to more successful collaborations. Should you have any questions or require further information, feel free to reach out.\n    <br/><br/>\n    Best regards,<br/>\n    {email_signature}','{companyname} | CRM',NULL,0,1,0),(90,'staff','affiliate_management_new_payout_request_for_admin','english','Affiliate Payout Request','You have new affiliate payout request','Dear Admin,<br/><br/>\n    I wanted to inform you about a new payout request, identified by reference number <b>#{payout_id}</b>. \n    <br/><br/>\n    Affiliate: {affiliate_name}<br/>\n    Amount: {payout_amount}<br/>\n    Status: {payout_status}<br/>\n    Note: {payout_note_for_admin}<br/>\n    Created: {payout_created_at}<br/>\n    <br/><br/>    \n    Best regards,<br/>\n    {email_signature}','{companyname} | CRM',NULL,0,1,0),(91,'staff','affiliate_management_payout_updated_for_admin','english','Affiliate Payout Request Updated','You marked payout: #{payout_id} as {payout_status}','Dear Admin,<br/><br/>\n    I wanted to update you about the recent update to a payout request, identified by reference number <b>#{payout_id}</b>. \n    <br/><br/>\n    Affiliate: {affiliate_name}<br/>\n    Amount: {payout_amount}<br/>\n    Status: {payout_status}<br/><br/>\n    Admin Note: {payout_note_for_admin}<br/>\n    Note: {payout_note_for_affiliate}<br/>\n    Created: {payout_created_at}<br/>\n    <br/><br/>    \n    Best regards,<br/>\n    {email_signature}','{companyname} | CRM',NULL,0,1,0),(92,'staff','affiliate_management_new_affiliate_signup_for_admin','english','New Affiliate Signup','A new affiliate signup','Dear Admin,<br/><br/>\n    I wanted to inform you about a new affiliate signup, identified by reference number <b>#{affiliate_slug}</b>. \n    <br/><br/>\n    Affiliate: {affiliate_name}<br/>\n    Status: {affiliate_status}<br/>\n    Created: {affiliate_created_at}<br/>\n    <br/><br/>    \n    Best regards,<br/>\n    {email_signature}','{companyname} | CRM',NULL,0,1,0),(93,'client','affiliate_management_referral_commission_reversal','english','Referral Commission Reversal Notification','A referral commission was reversed!','Dear {contact_firstname},<br/><br/>\n    We regret to inform you that the commission previously awarded for your referral has been reversed due to reversal or removal of the rewarded payment.\n    <br/><br/>\n    Company/Contact: {referral_name}<br/>\n    Comission ID: {commission_id}<br/>\n    Amount Reversed: {commission_amount}<br/>\n    New Balance: {affiliate_balance}<br/>\n    Date of commission: {commission_created_at}<br/>\n    <br/><br/>\n    We appreciate your efforts and look forward to more successful collaborations. Should you have any questions or require further information, feel free to reach out.\n    <br/><br/>\n    Best regards,<br/>\n    {email_signature}','{companyname} | CRM',NULL,0,1,0),(94,'inventory_warning','inventory-warning-to-staff','english','Inventory warning (Sent to staff)','Inventory warning','Hi {staff_name}! <br /><br />This is a inventory warning<br />{<span 12pt=\"\">notification_content</span>}. <br /><br />Regards.','{companyname} | CRM',NULL,0,1,0),(95,'client','company-instance-deployed','english','Deployed CRM instance','Company CRM Instance created successfully','Dear {contact_firstname},<br/><br/>\n    I am writing to inform you that we have successfully deployed a CRM instance for your company <b>{instance_name}</b>. \n    <br/><br/>\n    You can access your instance at <b>{instance_admin_url}</b>. Kindly log in with your current email and the respective password. \n    <br/><br/>\n    Your customer can access from <b>{instance_url}</b>.<br/><br/>\n    Please let us know if you have any questions or concerns. We are always happy to help.<br/><br/>\n    \n    Best regards,<br/>\n    {email_signature}','{companyname} | CRM',NULL,0,1,0),(96,'staff','company-instance-deployed-for-admin','english','Deployed CRM instance for admin','A CRM Instance was deployed','Dear Super Admin,<br/><br/>\n\n    I am writing to inform you that a new instance <b>({instance_name})</b> has been created on your platform for <b>{client_company}</b>. You can check the instance at <b>{instance_url}</b>.\n    <br/><br/>\n    Best regards.<br/>\n    {email_signature}','{companyname} | CRM',NULL,0,1,0),(97,'client','company-instance-removed','english','Removed CRM instance','Company CRM Instance removed','\n    Dear {contact_firstname},<br/><br/>\n    \n    I am writing to inform you that your company <b>{instance_name}</b> has been removed successfully. \n    <br/><br/>\n    If this is not from you or your staff, kindly reach out to us.\n    <br/><br/>\n    Best regards,<br/>\n    {email_signature}','{companyname} | CRM',NULL,0,1,0),(98,'staff','company-instance-removed-for-admin','english','Removed CRM instance for admin','Company CRM Instance removed successfully','Dear Super Admin,<br/><br/>\n\n    I am writing to inform you that an instance has been removed from your platform for <b>{client_company}</b>. The name of the instance is <b>{instance_name}</b>.\n    <br/><br/>\n    Best regards.<br/>\n    {email_signature}','{companyname} | CRM',NULL,0,1,0),(99,'client','company-instance-auto-removal-notice','english','Auto removal of inactive CRM instance','Important Notice: Your Company CRM Instance Will Be Removed in {period_left}','\n    Dear {contact_firstname},<br/><br/>\n    \n    I am writing to inform you that your CRM instance <b>{instance_name} ({instance_slug})</b> has not been accessed by any staff for the past {inactive_period}. \n    <br/><br/>\n    Your CRM will be permanently removed in {period_left}. \n    To prevent removal of <b>{instance_name}</b>, \n    kindly login directly now through your staff login page: <a href=\"{instance_admin_url}\">{instance_admin_url}</a> or through your billing portal: <a href=\"{site_login_url}\">{site_login_url}</a>.\n    <br/><br/>\n    Best regards,<br/>\n    {email_signature}','{companyname} | CRM',NULL,0,1,0),(100,'staff','company-instance-custom-domain-request-for-admin','english','Custom domain request for admin','New Custom Domain Request','Dear Super Admin,<br/><br/>\n    I am writing to inform you that you have a new custom domain linking request for <b>{instance_name}</b>. \n    <br/>\n    Tenant ID: {instance_slug}<br/>\n    Custom domain: {instance_custom_domain}<br/>\n    Customer: {contact_firstname} - {contact_email}\n    <br/><br/>\n    You can access the instance directly from <b>{admin_url}saas/companies/edit/{instance_id}</b>.\n    <br/><br/>\n    Best regards,<br/>\n    {email_signature}','{companyname} | CRM',NULL,0,1,0),(101,'client','company-instance-custom-domain-approved','english','Custom domain approved','Custom Domain Added Successfully','Dear {contact_firstname},<br/><br/>\n    I am writing to inform you that we have successfully link your custom domain ( {instance_custom_domain} ) to your company <b>{instance_name}</b>. \n    <br/><br/>\n    You can access your instance at <b>{instance_admin_url}</b>.\n    <br/><br/>\n    Your customer can access from <b>{instance_url}</b>.<br/><br/>\n    {extra_note}<br/>\n    Please let us know if you have any questions or concerns. We are always happy to help.<br/><br/>\n    Best regards,<br/>\n    {email_signature}','{companyname} | CRM',NULL,0,1,0),(102,'client','company-instance-custom-domain-rejected','english','Custom domain cancelled','Custom Domain Request Cancelled','Dear {contact_firstname},<br/><br/>\n    I am writing to inform you that we are unable to link your custom domain ( {instance_custom_domain} ) to your company <b>{instance_name}</b> due to the following reason: \n    <br/>\n    {extra_note}\n    <br/><br/>\n    Please ensure you have followed the instructions for linking the domain as stated outlined on your dashboard.\n    <br/><br/>\n    You can always request new domain at your earliest convenient time.<br/><br/>\n    Best regards,<br/>\n    {email_signature}','{companyname} | CRM',NULL,0,1,0),(103,'purchase_order','purchase-order-to-contact','english','Purchase Order (Sent to contact)','Purchase Order','<span style=\\\"font-size: 12pt;\\\"> Hello !. </span><br /><br /><span style=\\\"font-size: 12pt;\\\"> We would like to share with you a link of Purchase Order information with the number {po_number} </span><br /><br /><span style=\\\"font-size: 12pt;\\\"><br />Please click on the link to view information: {public_link}\r\n  </span><br /><br />','{companyname} | CRM',NULL,0,1,0),(104,'purchase_order','purchase-request-to-contact','english','Purchase Request (Sent to contact)','Purchase Request','<span style=\\\"font-size: 12pt;\\\"> Hello !. </span><br /><br /><span style=\\\"font-size: 12pt;\\\"> We would like to share with you a link of Purchase Request information with the number {pr_number} </span><br /><br /><span style=\\\"font-size: 12pt;\\\"><br />Please click on the link to view information: {public_link}<br/ >{additional_content}\r\n  </span><br /><br />','{companyname} | CRM',NULL,0,1,0),(105,'purchase_order','purchase-quotation-to-contact','english','Purchase Quotation (Sent to contact)','Purchase Quotation','<span style=\\\"font-size: 12pt;\\\"> Hello !. </span><br /><br /><span style=\\\"font-size: 12pt;\\\"> We would like to share with you a link of Purchase Quotation information with the number {pq_number} </span><br /><br /><span style=\\\"font-size: 12pt;\\\"><br />Please click on the link to view information: {quotation_link}<br/ >{additional_content}\r\n  </span><br /><br />','{companyname} | CRM',NULL,0,1,0),(106,'purchase_order','debit-note-to-contact','english','Debit Note (Sent to contact)','Debit Note','<span style=\\\"font-size: 12pt;\\\"> Hello !. </span><br /><br /><span style=\\\"font-size: 12pt;\\\"> We would like to share with you a link of Debit Note information with the number {dn_number} </span><br /><br /><span style=\\\"font-size: 12pt;\\\"><br />{additional_content}\r\n  </span><br /><br />','{companyname} | CRM',NULL,0,1,0),(107,'purchase_order','purchase-statement-to-contact','english','Purchase Statement (Sent to contact)','Purchase Statement','<span style=\\\"font-size: 12pt;\\\"> Dear {contact_firstname} {contact_lastname} !. </span><br /><br /><span style=\\\"font-size: 12pt;\\\">Its been a great experience working with you. </span><br /><br /><span style=\\\"font-size: 12pt;\\\"><br />Attached with this email is a list of all transactions for the period between {statement_from} to {statement_to}<br/ ><br/ >For your information your account balance due is total: {statement_balance_due}<br /><br/ > Please contact us if you need more information.<br/ > <br />{additional_content}\r\n  </span><br /><br />','{companyname} | CRM',NULL,0,1,0),(108,'purchase_order','vendor-registration-confirmed','english','Vendor Registration Confirmed','Your registration is confirmed','<p>Dear {contact_firstname} {contact_lastname}<br /><br />We just wanted to let you know that your registration at&nbsp;{companyname} is successfully confirmed and your account is now active.<br /><br />You can login at&nbsp;<a href=\"{vendor_portal_url}\">{vendor_portal_url}</a> with the email and password you provided during registration.<br /><br />Please contact us if you need any help.<br /><br />Kind Regards, <br />{email_signature}</p>\r\n <p><br />(This is an automated email, so please dont reply to this email address)</p>','{companyname} | CRM',NULL,0,1,0),(109,'purchase_order','purchase-contract-to-contact','english','Purchase Contract (Sent to contact)','Purchase Contract','<span style=\\\"font-size: 12pt;\\\"> Hello !. </span><br /><br /><span style=\\\"font-size: 12pt;\\\"> We would like to share with you a link of Purchase Contract information with the number {contract_number} </span><br /><br /><span style=\\\"font-size: 12pt;\\\"><br />Please click on the link to view information: {contract_link}\r\n  </span><br /><br />','{companyname} | CRM',NULL,0,1,0),(110,'purchase_order','new-contact-created','english','New Contact Added/Registered (Welcome Email)','New Contact Added/Registered (Welcome Email)','<span style=\\\"font-size: 12pt;\\\"> Dear {contact_firstname} {contact_lastname}! </span><br /><br /><span style=\\\"font-size: 12pt;\\\"> Welcome to our system </span><br /><br /><span style=\\\"font-size: 12pt;\\\"><br />Click here to login: {vendor_portal_link}</span><br /></span><br />','{companyname} | CRM',NULL,0,1,0),(111,'purchase_order','purchase-request-approval','english','Request approval','Request approval','<span style=\\\"font-size: 12pt;\\\"> Hello {staff_name}! </span><br /><br /><span style=\\\"font-size: 12pt;\\\"> You receive an approval request: {link} from {from_staff_name}</span>','{companyname} | CRM',NULL,0,1,0),(112,'purchase_order','purchase-send-approved','english','Email send approved','Email send approved','<span style=\\\"font-size: 12pt;\\\"> Hello {staff_name}! </span><br /><br /><span style=\\\"font-size: 12pt;\\\">{type} has been approved by {by_staff_name} </span><br /><span style=\\\"font-size: 12pt;\\\"><br />Click here to view detail: {link} </span><br /></span><br />','{companyname} | CRM',NULL,0,1,0),(113,'purchase_order','purchase-send-rejected','english','Email send rejected','Email send rejected','<span style=\\\"font-size: 12pt;\\\"> Hello {staff_name}! </span><br /><br /><span style=\\\"font-size: 12pt;\\\"> {type} has been declined by {by_staff_name} </span><br /><span style=\\\"font-size: 12pt;\\\"><br />Click here to view detail: {link}  </span><br /></span><br />','{companyname} | CRM',NULL,0,1,0),(114,'change_candidate_status','change-candidate-status-to-candidate','english','Change Candidate Status (Sent to Candidate)','Changed Candidate Status','<br />Hi {candidate_name} {last_name}<br /><br />I would like to inform you that your candidate profile status changed to {candidate_status}<br /><br />I will contact you again as soon as I have any news.<br /><br />Kind Regards,<br />{email_signature}.','{companyname} | CRM',NULL,0,1,0),(115,'change_candidate_job_applied_status','change-candidate-job-applied-status-to-candidate','english','Change Candidate Job Applied Status (Sent to Candidate)','Changed Candidate Job Applied Status','<br />Hi {candidate_name} {last_name}<br /><br />I would like to inform you that your Job Applied status changed to {job_applied_status}<br /><br />I will contact you again as soon as I have any news.<br /><br />Kind Regards,<br />{email_signature}.','{companyname} | CRM',NULL,0,1,0),(116,'change_candidate_interview_schedule_status','change-candidate-interview-schedule-status-to-candidate','english','Change Candidate Interview Schedule Status (Sent to Candidate)','Changed Candidate Interview Schedule Status','<br />Hi {candidate_name} {last_name}<br /><br />I would like to inform you that your Interview Schedule status changed to {interview_schedule_status}<br /><br />I will contact you again as soon as I have any news.<br /><br />Kind Regards,<br />{email_signature}.','{companyname} | CRM',NULL,0,1,0),(117,'new_candidate_have_applied','new-candidate-have-applied','english','New candidate have applied (Sent to Responsible)','New candidate have applied','<p><span style=\"font-size: 12pt;\">New Candidate have been applied.</span><br /><br /><span style=\"font-size: 12pt;\">You can view the Candidate profile on the following link: <a href=\"{candidate_link}\">#{candidate_link}</a><br /><br />Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span></p>','{companyname} | CRM',NULL,0,1,0),(118,'staff','flexibackup-new-backup-to-staff','english','Flexi Backup Notification','New Backup Available  - {backup_name}','Hi there! <br /><br /> Please find attached a copy of your {backup_type} created on {backup_date}.  <br /><br /> Regards.','{companyname} | CRM',NULL,0,1,0);
/*!40000 ALTER TABLE `tblemailtemplates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblestimate_request_forms`
--

DROP TABLE IF EXISTS `tblestimate_request_forms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblestimate_request_forms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `form_key` varchar(32) NOT NULL,
  `type` varchar(100) NOT NULL,
  `name` varchar(191) NOT NULL,
  `form_data` longtext DEFAULT NULL,
  `recaptcha` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL,
  `submit_btn_name` varchar(100) DEFAULT NULL,
  `submit_btn_bg_color` varchar(10) DEFAULT '#84c529',
  `submit_btn_text_color` varchar(10) DEFAULT '#ffffff',
  `success_submit_msg` mediumtext DEFAULT NULL,
  `submit_action` int(11) DEFAULT 0,
  `submit_redirect_url` longtext DEFAULT NULL,
  `language` varchar(100) DEFAULT NULL,
  `dateadded` datetime DEFAULT NULL,
  `notify_type` varchar(100) DEFAULT NULL,
  `notify_ids` longtext DEFAULT NULL,
  `responsible` int(11) DEFAULT NULL,
  `notify_request_submitted` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblestimate_request_forms`
--

LOCK TABLES `tblestimate_request_forms` WRITE;
/*!40000 ALTER TABLE `tblestimate_request_forms` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblestimate_request_forms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblestimate_request_status`
--

DROP TABLE IF EXISTS `tblestimate_request_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblestimate_request_status` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `statusorder` int(11) DEFAULT NULL,
  `color` varchar(10) DEFAULT NULL,
  `flag` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblestimate_request_status`
--

LOCK TABLES `tblestimate_request_status` WRITE;
/*!40000 ALTER TABLE `tblestimate_request_status` DISABLE KEYS */;
INSERT INTO `tblestimate_request_status` VALUES (1,'Cancelled',1,'#808080','cancelled'),(2,'Processing',2,'#007bff','processing'),(3,'Completed',3,'#28a745','completed');
/*!40000 ALTER TABLE `tblestimate_request_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblestimate_requests`
--

DROP TABLE IF EXISTS `tblestimate_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblestimate_requests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `submission` longtext NOT NULL,
  `last_status_change` datetime DEFAULT NULL,
  `date_estimated` datetime DEFAULT NULL,
  `from_form_id` int(11) DEFAULT NULL,
  `assigned` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `default_language` int(11) NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblestimate_requests`
--

LOCK TABLES `tblestimate_requests` WRITE;
/*!40000 ALTER TABLE `tblestimate_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblestimate_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblestimates`
--

DROP TABLE IF EXISTS `tblestimates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblestimates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sent` tinyint(1) NOT NULL DEFAULT 0,
  `datesend` datetime DEFAULT NULL,
  `clientid` int(11) NOT NULL,
  `deleted_customer_name` varchar(100) DEFAULT NULL,
  `project_id` int(11) NOT NULL DEFAULT 0,
  `number` int(11) NOT NULL,
  `prefix` varchar(50) DEFAULT NULL,
  `number_format` int(11) NOT NULL DEFAULT 0,
  `hash` varchar(32) DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `date` date NOT NULL,
  `expirydate` date DEFAULT NULL,
  `currency` int(11) NOT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `total_tax` decimal(15,2) NOT NULL DEFAULT 0.00,
  `total` decimal(15,2) NOT NULL,
  `adjustment` decimal(15,2) DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `clientnote` mediumtext DEFAULT NULL,
  `adminnote` mediumtext DEFAULT NULL,
  `discount_percent` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `discount_type` varchar(30) DEFAULT NULL,
  `invoiceid` int(11) DEFAULT NULL,
  `invoiced_date` datetime DEFAULT NULL,
  `terms` mediumtext DEFAULT NULL,
  `reference_no` varchar(100) DEFAULT NULL,
  `sale_agent` int(11) NOT NULL DEFAULT 0,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT NULL,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT NULL,
  `include_shipping` tinyint(1) NOT NULL,
  `show_shipping_on_estimate` tinyint(1) NOT NULL DEFAULT 1,
  `show_quantity_as` int(11) NOT NULL DEFAULT 1,
  `pipeline_order` int(11) DEFAULT 1,
  `is_expiry_notified` int(11) NOT NULL DEFAULT 0,
  `acceptance_firstname` varchar(50) DEFAULT NULL,
  `acceptance_lastname` varchar(50) DEFAULT NULL,
  `acceptance_email` varchar(100) DEFAULT NULL,
  `acceptance_date` datetime DEFAULT NULL,
  `acceptance_ip` varchar(40) DEFAULT NULL,
  `signature` varchar(40) DEFAULT NULL,
  `short_link` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `currency` (`currency`),
  KEY `project_id` (`project_id`),
  KEY `sale_agent` (`sale_agent`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblestimates`
--

LOCK TABLES `tblestimates` WRITE;
/*!40000 ALTER TABLE `tblestimates` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblestimates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblevents`
--

DROP TABLE IF EXISTS `tblevents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblevents` (
  `eventid` int(11) NOT NULL AUTO_INCREMENT,
  `title` longtext NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `userid` int(11) NOT NULL,
  `start` datetime NOT NULL,
  `end` datetime DEFAULT NULL,
  `public` int(11) NOT NULL DEFAULT 0,
  `color` varchar(10) DEFAULT NULL,
  `isstartnotified` tinyint(1) NOT NULL DEFAULT 0,
  `reminder_before` int(11) NOT NULL DEFAULT 0,
  `reminder_before_type` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`eventid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblevents`
--

LOCK TABLES `tblevents` WRITE;
/*!40000 ALTER TABLE `tblevents` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblevents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblexpenses`
--

DROP TABLE IF EXISTS `tblexpenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblexpenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` int(11) NOT NULL,
  `currency` int(11) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `tax` int(11) DEFAULT NULL,
  `tax2` int(11) NOT NULL DEFAULT 0,
  `reference_no` varchar(100) DEFAULT NULL,
  `note` mediumtext DEFAULT NULL,
  `expense_name` varchar(191) DEFAULT NULL,
  `clientid` int(11) NOT NULL,
  `project_id` int(11) NOT NULL DEFAULT 0,
  `billable` int(11) DEFAULT 0,
  `invoiceid` int(11) DEFAULT NULL,
  `paymentmode` varchar(50) DEFAULT NULL,
  `date` date NOT NULL,
  `recurring_type` varchar(10) DEFAULT NULL,
  `repeat_every` int(11) DEFAULT NULL,
  `recurring` int(11) NOT NULL DEFAULT 0,
  `cycles` int(11) NOT NULL DEFAULT 0,
  `total_cycles` int(11) NOT NULL DEFAULT 0,
  `custom_recurring` int(11) NOT NULL DEFAULT 0,
  `last_recurring_date` date DEFAULT NULL,
  `create_invoice_billable` tinyint(1) DEFAULT NULL,
  `send_invoice_to_customer` tinyint(1) NOT NULL,
  `recurring_from` int(11) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  `addedfrom` int(11) NOT NULL,
  `vendor` int(11) DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `date_paid` date DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `is_bill` int(11) NOT NULL DEFAULT 0,
  `reason_for_void` text DEFAULT NULL,
  `voided` int(11) NOT NULL DEFAULT 0,
  `approved` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `project_id` (`project_id`),
  KEY `category` (`category`),
  KEY `currency` (`currency`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblexpenses`
--

LOCK TABLES `tblexpenses` WRITE;
/*!40000 ALTER TABLE `tblexpenses` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblexpenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblexpenses_categories`
--

DROP TABLE IF EXISTS `tblexpenses_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblexpenses_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblexpenses_categories`
--

LOCK TABLES `tblexpenses_categories` WRITE;
/*!40000 ALTER TABLE `tblexpenses_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblexpenses_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblfiles`
--

DROP TABLE IF EXISTS `tblfiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblfiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) NOT NULL,
  `file_name` varchar(191) NOT NULL,
  `filetype` varchar(40) DEFAULT NULL,
  `visible_to_customer` int(11) NOT NULL DEFAULT 0,
  `attachment_key` varchar(32) DEFAULT NULL,
  `external` varchar(40) DEFAULT NULL,
  `external_link` mediumtext DEFAULT NULL,
  `thumbnail_link` mediumtext DEFAULT NULL COMMENT 'For external usage',
  `staffid` int(11) NOT NULL,
  `contact_id` int(11) DEFAULT 0,
  `task_comment_id` int(11) NOT NULL DEFAULT 0,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblfiles`
--

LOCK TABLES `tblfiles` WRITE;
/*!40000 ALTER TABLE `tblfiles` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblfiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblfilter_defaults`
--

DROP TABLE IF EXISTS `tblfilter_defaults`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblfilter_defaults` (
  `filter_id` int(10) unsigned NOT NULL,
  `staff_id` int(11) NOT NULL,
  `identifier` varchar(191) NOT NULL,
  `view` varchar(191) NOT NULL,
  KEY `filter_id` (`filter_id`),
  KEY `staff_id` (`staff_id`),
  CONSTRAINT `tblfilter_defaults_ibfk_1` FOREIGN KEY (`filter_id`) REFERENCES `tblfilters` (`id`) ON DELETE CASCADE,
  CONSTRAINT `tblfilter_defaults_ibfk_2` FOREIGN KEY (`staff_id`) REFERENCES `tblstaff` (`staffid`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblfilter_defaults`
--

LOCK TABLES `tblfilter_defaults` WRITE;
/*!40000 ALTER TABLE `tblfilter_defaults` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblfilter_defaults` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblfilters`
--

DROP TABLE IF EXISTS `tblfilters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblfilters` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `builder` mediumtext NOT NULL,
  `staff_id` int(10) unsigned NOT NULL,
  `identifier` varchar(191) NOT NULL,
  `is_shared` tinyint(3) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblfilters`
--

LOCK TABLES `tblfilters` WRITE;
/*!40000 ALTER TABLE `tblfilters` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblfilters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblflexibackup`
--

DROP TABLE IF EXISTS `tblflexibackup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblflexibackup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `backup_name` varchar(255) NOT NULL,
  `backup_type` varchar(255) NOT NULL,
  `backup_data` varchar(255) NOT NULL,
  `datecreated` datetime NOT NULL,
  `uploaded_to_remote` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblflexibackup`
--

LOCK TABLES `tblflexibackup` WRITE;
/*!40000 ALTER TABLE `tblflexibackup` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblflexibackup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblform_question_box`
--

DROP TABLE IF EXISTS `tblform_question_box`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblform_question_box` (
  `boxid` int(11) NOT NULL AUTO_INCREMENT,
  `boxtype` varchar(10) NOT NULL,
  `questionid` int(11) NOT NULL,
  PRIMARY KEY (`boxid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblform_question_box`
--

LOCK TABLES `tblform_question_box` WRITE;
/*!40000 ALTER TABLE `tblform_question_box` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblform_question_box` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblform_question_box_description`
--

DROP TABLE IF EXISTS `tblform_question_box_description`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblform_question_box_description` (
  `questionboxdescriptionid` int(11) NOT NULL AUTO_INCREMENT,
  `description` longtext NOT NULL,
  `boxid` longtext NOT NULL,
  `questionid` int(11) NOT NULL,
  PRIMARY KEY (`questionboxdescriptionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblform_question_box_description`
--

LOCK TABLES `tblform_question_box_description` WRITE;
/*!40000 ALTER TABLE `tblform_question_box_description` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblform_question_box_description` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblform_questions`
--

DROP TABLE IF EXISTS `tblform_questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblform_questions` (
  `questionid` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) DEFAULT NULL,
  `question` longtext NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT 0,
  `question_order` int(11) NOT NULL,
  PRIMARY KEY (`questionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblform_questions`
--

LOCK TABLES `tblform_questions` WRITE;
/*!40000 ALTER TABLE `tblform_questions` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblform_questions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblform_results`
--

DROP TABLE IF EXISTS `tblform_results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblform_results` (
  `resultid` int(11) NOT NULL AUTO_INCREMENT,
  `boxid` int(11) NOT NULL,
  `boxdescriptionid` int(11) DEFAULT NULL,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) DEFAULT NULL,
  `questionid` int(11) NOT NULL,
  `answer` mediumtext DEFAULT NULL,
  `resultsetid` int(11) NOT NULL,
  PRIMARY KEY (`resultid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblform_results`
--

LOCK TABLES `tblform_results` WRITE;
/*!40000 ALTER TABLE `tblform_results` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblform_results` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblgdpr_requests`
--

DROP TABLE IF EXISTS `tblgdpr_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblgdpr_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clientid` int(11) NOT NULL DEFAULT 0,
  `contact_id` int(11) NOT NULL DEFAULT 0,
  `lead_id` int(11) NOT NULL DEFAULT 0,
  `request_type` varchar(191) DEFAULT NULL,
  `status` varchar(40) DEFAULT NULL,
  `request_date` datetime NOT NULL,
  `request_from` varchar(150) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblgdpr_requests`
--

LOCK TABLES `tblgdpr_requests` WRITE;
/*!40000 ALTER TABLE `tblgdpr_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblgdpr_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblgoods_delivery`
--

DROP TABLE IF EXISTS `tblgoods_delivery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblgoods_delivery` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rel_type` int(11) DEFAULT NULL COMMENT 'type goods delivery',
  `rel_document` int(11) DEFAULT NULL COMMENT 'document id of goods delivery',
  `customer_code` text DEFAULT NULL,
  `customer_name` varchar(100) DEFAULT NULL,
  `to_` varchar(100) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL COMMENT 'the reason delivery',
  `staff_id` int(11) DEFAULT NULL COMMENT 'salesman',
  `date_c` date DEFAULT NULL,
  `date_add` date DEFAULT NULL,
  `goods_delivery_code` varchar(100) DEFAULT NULL COMMENT 'số chứng từ xuất kho',
  `warehouse_id` int(11) DEFAULT NULL,
  `total_money` varchar(200) DEFAULT NULL,
  `approval` int(11) DEFAULT 0 COMMENT 'status approval ',
  `addedfrom` int(11) DEFAULT NULL,
  `total_discount` varchar(100) DEFAULT NULL,
  `after_discount` varchar(100) DEFAULT NULL,
  `invoice_id` varchar(100) DEFAULT NULL,
  `project` text DEFAULT NULL,
  `type` text DEFAULT NULL,
  `department` int(11) DEFAULT NULL,
  `requester` int(11) DEFAULT NULL,
  `invoice_no` text DEFAULT NULL,
  `pr_order_id` int(11) DEFAULT NULL,
  `type_of_delivery` varchar(100) DEFAULT 'total',
  `additional_discount` decimal(15,2) DEFAULT 0.00,
  `sub_total` decimal(15,2) DEFAULT 0.00,
  `delivery_status` varchar(100) DEFAULT 'ready_for_packing',
  `shipping_fee` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblgoods_delivery`
--

LOCK TABLES `tblgoods_delivery` WRITE;
/*!40000 ALTER TABLE `tblgoods_delivery` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblgoods_delivery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblgoods_delivery_detail`
--

DROP TABLE IF EXISTS `tblgoods_delivery_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblgoods_delivery_detail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `goods_delivery_id` int(11) NOT NULL,
  `commodity_code` varchar(100) DEFAULT NULL,
  `commodity_name` text DEFAULT NULL,
  `warehouse_id` text DEFAULT NULL,
  `unit_id` text DEFAULT NULL,
  `quantities` text DEFAULT NULL,
  `unit_price` varchar(100) DEFAULT NULL,
  `total_money` varchar(200) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `discount` varchar(100) DEFAULT NULL,
  `discount_money` varchar(100) DEFAULT NULL,
  `available_quantity` varchar(100) DEFAULT NULL,
  `tax_id` varchar(100) DEFAULT NULL,
  `total_after_discount` varchar(100) DEFAULT NULL,
  `expiry_date` text DEFAULT NULL,
  `lot_number` text DEFAULT NULL,
  `guarantee_period` text DEFAULT NULL,
  `tax_rate` text DEFAULT NULL,
  `tax_name` text DEFAULT NULL,
  `sub_total` decimal(15,2) DEFAULT 0.00,
  `packing_qty` decimal(15,2) DEFAULT 0.00,
  `serial_number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblgoods_delivery_detail`
--

LOCK TABLES `tblgoods_delivery_detail` WRITE;
/*!40000 ALTER TABLE `tblgoods_delivery_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblgoods_delivery_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblgoods_delivery_invoices_pr_orders`
--

DROP TABLE IF EXISTS `tblgoods_delivery_invoices_pr_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblgoods_delivery_invoices_pr_orders` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) DEFAULT NULL COMMENT 'goods_delivery_id',
  `rel_type` int(11) DEFAULT NULL COMMENT 'invoice_id or purchase order id',
  `type` varchar(100) DEFAULT NULL COMMENT 'invoice,  purchase_orders',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblgoods_delivery_invoices_pr_orders`
--

LOCK TABLES `tblgoods_delivery_invoices_pr_orders` WRITE;
/*!40000 ALTER TABLE `tblgoods_delivery_invoices_pr_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblgoods_delivery_invoices_pr_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblgoods_receipt`
--

DROP TABLE IF EXISTS `tblgoods_receipt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblgoods_receipt` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `supplier_code` varchar(100) DEFAULT NULL,
  `supplier_name` text DEFAULT NULL,
  `deliver_name` text DEFAULT NULL,
  `buyer_id` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `pr_order_id` int(11) DEFAULT NULL COMMENT 'code puchase request agree',
  `date_c` date DEFAULT NULL,
  `date_add` date DEFAULT NULL,
  `goods_receipt_code` varchar(100) DEFAULT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `total_tax_money` varchar(100) DEFAULT NULL,
  `total_goods_money` varchar(100) DEFAULT NULL,
  `value_of_inventory` varchar(100) DEFAULT NULL,
  `total_money` varchar(100) DEFAULT NULL COMMENT 'total_money = total_tax_money +total_goods_money ',
  `addedfrom` int(11) DEFAULT NULL,
  `approval` int(11) DEFAULT 0,
  `project` text DEFAULT NULL,
  `type` text DEFAULT NULL,
  `department` int(11) DEFAULT NULL,
  `requester` int(11) DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `invoice_no` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblgoods_receipt`
--

LOCK TABLES `tblgoods_receipt` WRITE;
/*!40000 ALTER TABLE `tblgoods_receipt` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblgoods_receipt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblgoods_receipt_detail`
--

DROP TABLE IF EXISTS `tblgoods_receipt_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblgoods_receipt_detail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `goods_receipt_id` int(11) NOT NULL,
  `commodity_code` varchar(100) DEFAULT NULL,
  `commodity_name` text DEFAULT NULL,
  `warehouse_id` text DEFAULT NULL,
  `unit_id` text DEFAULT NULL,
  `quantities` text DEFAULT NULL,
  `unit_price` varchar(100) DEFAULT NULL,
  `tax` varchar(100) DEFAULT NULL,
  `tax_money` varchar(100) DEFAULT NULL,
  `goods_money` varchar(100) DEFAULT NULL,
  `date_manufacture` date DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `note` text DEFAULT NULL,
  `discount` varchar(100) DEFAULT NULL,
  `discount_money` varchar(100) DEFAULT NULL,
  `lot_number` varchar(100) DEFAULT NULL,
  `tax_rate` text DEFAULT NULL,
  `sub_total` decimal(15,2) DEFAULT 0.00,
  `tax_name` text DEFAULT NULL,
  `serial_number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblgoods_receipt_detail`
--

LOCK TABLES `tblgoods_receipt_detail` WRITE;
/*!40000 ALTER TABLE `tblgoods_receipt_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblgoods_receipt_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblgoods_transaction_detail`
--

DROP TABLE IF EXISTS `tblgoods_transaction_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblgoods_transaction_detail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `goods_receipt_id` int(11) DEFAULT NULL COMMENT 'id_goods_receipt_id or goods_delivery_id',
  `goods_id` int(11) NOT NULL COMMENT ' is id commodity',
  `old_quantity` varchar(100) DEFAULT NULL,
  `quantity` varchar(100) DEFAULT NULL,
  `date_add` datetime DEFAULT NULL,
  `commodity_id` int(11) NOT NULL,
  `warehouse_id` text NOT NULL,
  `note` text DEFAULT NULL,
  `status` int(2) DEFAULT NULL COMMENT '1:Goods receipt note 2:Goods delivery note',
  `purchase_price` varchar(100) DEFAULT NULL,
  `price` varchar(100) DEFAULT NULL,
  `expiry_date` text DEFAULT NULL,
  `lot_number` text DEFAULT NULL,
  `from_stock_name` int(11) DEFAULT NULL,
  `to_stock_name` int(11) DEFAULT NULL,
  `serial_number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`,`commodity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblgoods_transaction_detail`
--

LOCK TABLES `tblgoods_transaction_detail` WRITE;
/*!40000 ALTER TABLE `tblgoods_transaction_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblgoods_transaction_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblgroup_checklist`
--

DROP TABLE IF EXISTS `tblgroup_checklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblgroup_checklist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(100) NOT NULL,
  `meta` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblgroup_checklist`
--

LOCK TABLES `tblgroup_checklist` WRITE;
/*!40000 ALTER TABLE `tblgroup_checklist` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblgroup_checklist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblgroup_checklist_allocation`
--

DROP TABLE IF EXISTS `tblgroup_checklist_allocation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblgroup_checklist_allocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(100) NOT NULL,
  `meta` varchar(100) DEFAULT NULL,
  `staffid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblgroup_checklist_allocation`
--

LOCK TABLES `tblgroup_checklist_allocation` WRITE;
/*!40000 ALTER TABLE `tblgroup_checklist_allocation` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblgroup_checklist_allocation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_allocation_asset`
--

DROP TABLE IF EXISTS `tblhr_allocation_asset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhr_allocation_asset` (
  `allocation_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) unsigned NOT NULL,
  `asset_name` varchar(100) DEFAULT NULL,
  `assets_amount` int(11) unsigned NOT NULL,
  `status_allocation` int(11) unsigned DEFAULT 0 COMMENT '1: Allocated 0: Unallocated',
  PRIMARY KEY (`allocation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_allocation_asset`
--

LOCK TABLES `tblhr_allocation_asset` WRITE;
/*!40000 ALTER TABLE `tblhr_allocation_asset` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_allocation_asset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_allowance_type`
--

DROP TABLE IF EXISTS `tblhr_allowance_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhr_allowance_type` (
  `type_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type_name` varchar(200) NOT NULL,
  `allowance_val` decimal(15,2) NOT NULL,
  `taxable` tinyint(1) NOT NULL,
  PRIMARY KEY (`type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_allowance_type`
--

LOCK TABLES `tblhr_allowance_type` WRITE;
/*!40000 ALTER TABLE `tblhr_allowance_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_allowance_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_checklist_allocation`
--

DROP TABLE IF EXISTS `tblhr_checklist_allocation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhr_checklist_allocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `group_id` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_checklist_allocation`
--

LOCK TABLES `tblhr_checklist_allocation` WRITE;
/*!40000 ALTER TABLE `tblhr_checklist_allocation` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_checklist_allocation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_contract_template`
--

DROP TABLE IF EXISTS `tblhr_contract_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhr_contract_template` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text DEFAULT NULL,
  `job_position` longtext DEFAULT NULL,
  `content` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_contract_template`
--

LOCK TABLES `tblhr_contract_template` WRITE;
/*!40000 ALTER TABLE `tblhr_contract_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_contract_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_dependent_person`
--

DROP TABLE IF EXISTS `tblhr_dependent_person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhr_dependent_person` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staffid` int(11) unsigned DEFAULT NULL,
  `dependent_name` varchar(100) DEFAULT NULL,
  `relationship` varchar(100) DEFAULT NULL,
  `dependent_bir` date DEFAULT NULL,
  `start_month` date DEFAULT NULL,
  `end_month` date DEFAULT NULL,
  `dependent_iden` varchar(20) NOT NULL,
  `reason` longtext DEFAULT NULL,
  `status` int(11) unsigned DEFAULT 0,
  `status_comment` longtext DEFAULT NULL,
  PRIMARY KEY (`id`,`dependent_iden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_dependent_person`
--

LOCK TABLES `tblhr_dependent_person` WRITE;
/*!40000 ALTER TABLE `tblhr_dependent_person` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_dependent_person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_education`
--

DROP TABLE IF EXISTS `tblhr_education`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhr_education` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `programe_id` int(11) DEFAULT NULL,
  `training_programs_name` text NOT NULL,
  `training_places` text DEFAULT NULL,
  `training_time_from` datetime DEFAULT NULL,
  `training_time_to` datetime DEFAULT NULL,
  `date_create` datetime DEFAULT NULL,
  `training_result` varchar(150) DEFAULT NULL,
  `degree` varchar(150) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_education`
--

LOCK TABLES `tblhr_education` WRITE;
/*!40000 ALTER TABLE `tblhr_education` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_education` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_group_checklist_allocation`
--

DROP TABLE IF EXISTS `tblhr_group_checklist_allocation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhr_group_checklist_allocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(100) NOT NULL,
  `meta` varchar(100) DEFAULT NULL,
  `staffid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_group_checklist_allocation`
--

LOCK TABLES `tblhr_group_checklist_allocation` WRITE;
/*!40000 ALTER TABLE `tblhr_group_checklist_allocation` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_group_checklist_allocation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_job_p`
--

DROP TABLE IF EXISTS `tblhr_job_p`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhr_job_p` (
  `job_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `job_name` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`job_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_job_p`
--

LOCK TABLES `tblhr_job_p` WRITE;
/*!40000 ALTER TABLE `tblhr_job_p` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_job_p` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_job_position`
--

DROP TABLE IF EXISTS `tblhr_job_position`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhr_job_position` (
  `position_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `position_name` varchar(200) NOT NULL,
  `job_position_description` text DEFAULT NULL,
  `job_p_id` int(11) unsigned NOT NULL,
  `position_code` varchar(50) DEFAULT NULL,
  `department_id` text DEFAULT NULL,
  PRIMARY KEY (`position_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_job_position`
--

LOCK TABLES `tblhr_job_position` WRITE;
/*!40000 ALTER TABLE `tblhr_job_position` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_job_position` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_jp_interview_training`
--

DROP TABLE IF EXISTS `tblhr_jp_interview_training`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhr_jp_interview_training` (
  `training_process_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `job_position_id` longtext DEFAULT NULL,
  `training_name` varchar(100) DEFAULT NULL,
  `training_type` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `date_add` datetime DEFAULT NULL,
  `position_training_id` text DEFAULT NULL,
  `mint_point` int(11) DEFAULT NULL,
  `additional_training` varchar(100) DEFAULT '',
  `staff_id` text DEFAULT NULL,
  `time_to_start` date DEFAULT NULL,
  `time_to_end` date DEFAULT NULL,
  PRIMARY KEY (`training_process_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_jp_interview_training`
--

LOCK TABLES `tblhr_jp_interview_training` WRITE;
/*!40000 ALTER TABLE `tblhr_jp_interview_training` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_jp_interview_training` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_jp_salary_scale`
--

DROP TABLE IF EXISTS `tblhr_jp_salary_scale`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhr_jp_salary_scale` (
  `salary_scale_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `job_position_id` int(11) unsigned NOT NULL,
  `rel_type` varchar(100) DEFAULT NULL COMMENT 'salary:allowance:insurance',
  `rel_id` int(11) DEFAULT NULL,
  `value` text DEFAULT NULL,
  PRIMARY KEY (`salary_scale_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_jp_salary_scale`
--

LOCK TABLES `tblhr_jp_salary_scale` WRITE;
/*!40000 ALTER TABLE `tblhr_jp_salary_scale` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_jp_salary_scale` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_knowedge_base_article_feedback`
--

DROP TABLE IF EXISTS `tblhr_knowedge_base_article_feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhr_knowedge_base_article_feedback` (
  `articleanswerid` int(11) NOT NULL AUTO_INCREMENT,
  `articleid` int(11) NOT NULL,
  `answer` int(11) NOT NULL,
  `ip` varchar(40) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`articleanswerid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_knowedge_base_article_feedback`
--

LOCK TABLES `tblhr_knowedge_base_article_feedback` WRITE;
/*!40000 ALTER TABLE `tblhr_knowedge_base_article_feedback` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_knowedge_base_article_feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_knowledge_base`
--

DROP TABLE IF EXISTS `tblhr_knowledge_base`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhr_knowledge_base` (
  `articleid` int(11) NOT NULL AUTO_INCREMENT,
  `articlegroup` int(11) NOT NULL,
  `subject` mediumtext NOT NULL,
  `description` text NOT NULL,
  `slug` mediumtext NOT NULL,
  `active` tinyint(4) NOT NULL,
  `datecreated` datetime NOT NULL,
  `article_order` int(11) NOT NULL DEFAULT 0,
  `staff_article` int(11) NOT NULL DEFAULT 0,
  `question_answers` int(11) DEFAULT 0,
  `file_name` varchar(255) DEFAULT '',
  `curator` varchar(11) DEFAULT '',
  `benchmark` int(11) DEFAULT 0,
  `score` int(11) DEFAULT 0,
  PRIMARY KEY (`articleid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_knowledge_base`
--

LOCK TABLES `tblhr_knowledge_base` WRITE;
/*!40000 ALTER TABLE `tblhr_knowledge_base` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_knowledge_base` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_knowledge_base_groups`
--

DROP TABLE IF EXISTS `tblhr_knowledge_base_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhr_knowledge_base_groups` (
  `groupid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `group_slug` text DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `active` tinyint(4) NOT NULL,
  `color` varchar(10) DEFAULT '#28B8DA',
  `group_order` int(11) DEFAULT 0,
  PRIMARY KEY (`groupid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_knowledge_base_groups`
--

LOCK TABLES `tblhr_knowledge_base_groups` WRITE;
/*!40000 ALTER TABLE `tblhr_knowledge_base_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_knowledge_base_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_list_staff_quitting_work`
--

DROP TABLE IF EXISTS `tblhr_list_staff_quitting_work`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhr_list_staff_quitting_work` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staffid` int(11) DEFAULT NULL,
  `staff_name` text DEFAULT NULL,
  `department_name` text DEFAULT NULL,
  `role_name` text DEFAULT NULL,
  `email` text DEFAULT NULL,
  `dateoff` datetime DEFAULT NULL,
  `approval` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_list_staff_quitting_work`
--

LOCK TABLES `tblhr_list_staff_quitting_work` WRITE;
/*!40000 ALTER TABLE `tblhr_list_staff_quitting_work` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_list_staff_quitting_work` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_p_t_form_question_box`
--

DROP TABLE IF EXISTS `tblhr_p_t_form_question_box`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhr_p_t_form_question_box` (
  `boxid` int(11) NOT NULL AUTO_INCREMENT,
  `boxtype` varchar(10) NOT NULL,
  `questionid` int(11) NOT NULL,
  PRIMARY KEY (`boxid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_p_t_form_question_box`
--

LOCK TABLES `tblhr_p_t_form_question_box` WRITE;
/*!40000 ALTER TABLE `tblhr_p_t_form_question_box` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_p_t_form_question_box` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_p_t_form_question_box_description`
--

DROP TABLE IF EXISTS `tblhr_p_t_form_question_box_description`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhr_p_t_form_question_box_description` (
  `questionboxdescriptionid` int(11) NOT NULL AUTO_INCREMENT,
  `description` mediumtext NOT NULL,
  `boxid` mediumtext NOT NULL,
  `questionid` int(11) NOT NULL,
  `correct` int(11) DEFAULT 1 COMMENT '0: correct 1: incorrect',
  PRIMARY KEY (`questionboxdescriptionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_p_t_form_question_box_description`
--

LOCK TABLES `tblhr_p_t_form_question_box_description` WRITE;
/*!40000 ALTER TABLE `tblhr_p_t_form_question_box_description` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_p_t_form_question_box_description` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_p_t_form_results`
--

DROP TABLE IF EXISTS `tblhr_p_t_form_results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhr_p_t_form_results` (
  `resultid` int(11) NOT NULL AUTO_INCREMENT,
  `boxid` int(11) NOT NULL,
  `boxdescriptionid` int(11) DEFAULT NULL,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) DEFAULT NULL,
  `questionid` int(11) NOT NULL,
  `answer` text DEFAULT NULL,
  `resultsetid` int(11) NOT NULL,
  PRIMARY KEY (`resultid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_p_t_form_results`
--

LOCK TABLES `tblhr_p_t_form_results` WRITE;
/*!40000 ALTER TABLE `tblhr_p_t_form_results` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_p_t_form_results` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_p_t_surveyresultsets`
--

DROP TABLE IF EXISTS `tblhr_p_t_surveyresultsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhr_p_t_surveyresultsets` (
  `resultsetid` int(11) NOT NULL AUTO_INCREMENT,
  `trainingid` int(11) NOT NULL,
  `ip` varchar(40) NOT NULL,
  `useragent` varchar(150) NOT NULL,
  `date` datetime NOT NULL,
  `staff_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`resultsetid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_p_t_surveyresultsets`
--

LOCK TABLES `tblhr_p_t_surveyresultsets` WRITE;
/*!40000 ALTER TABLE `tblhr_p_t_surveyresultsets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_p_t_surveyresultsets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_payroll_option`
--

DROP TABLE IF EXISTS `tblhr_payroll_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhr_payroll_option` (
  `option_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(200) NOT NULL,
  `option_val` longtext DEFAULT NULL,
  `auto` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`option_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_payroll_option`
--

LOCK TABLES `tblhr_payroll_option` WRITE;
/*!40000 ALTER TABLE `tblhr_payroll_option` DISABLE KEYS */;
INSERT INTO `tblhr_payroll_option` VALUES (1,'integrated_hrprofile','0',1),(2,'integrated_timesheets','0',1),(3,'integration_actual_workday','W,B',1),(4,'integration_paid_leave','AL,HO,EB',1),(5,'integration_unpaid_leave','U,SI,UB,P',1),(6,'standard_working_time','160',1),(7,'integrated_commissions','0',1),(8,'hrp_customize_staff_payslip_column','0',1);
/*!40000 ALTER TABLE `tblhr_payroll_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_position_training`
--

DROP TABLE IF EXISTS `tblhr_position_training`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhr_position_training` (
  `training_id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` mediumtext NOT NULL,
  `training_type` int(11) unsigned NOT NULL,
  `slug` mediumtext NOT NULL,
  `description` text DEFAULT NULL,
  `viewdescription` text DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `redirect_url` varchar(100) DEFAULT NULL,
  `send` tinyint(1) NOT NULL DEFAULT 0,
  `onlyforloggedin` int(11) DEFAULT 0,
  `fromname` varchar(100) DEFAULT NULL,
  `iprestrict` tinyint(1) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `hash` varchar(32) NOT NULL,
  `mint_point` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`training_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_position_training`
--

LOCK TABLES `tblhr_position_training` WRITE;
/*!40000 ALTER TABLE `tblhr_position_training` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_position_training` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_position_training_question_form`
--

DROP TABLE IF EXISTS `tblhr_position_training_question_form`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhr_position_training_question_form` (
  `questionid` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) DEFAULT NULL,
  `question` mediumtext NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT 0,
  `question_order` int(11) NOT NULL,
  `point` int(11) NOT NULL,
  PRIMARY KEY (`questionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_position_training_question_form`
--

LOCK TABLES `tblhr_position_training_question_form` WRITE;
/*!40000 ALTER TABLE `tblhr_position_training_question_form` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_position_training_question_form` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_procedure_retire`
--

DROP TABLE IF EXISTS `tblhr_procedure_retire`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhr_procedure_retire` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_name` text DEFAULT NULL,
  `option_name` text DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `people_handle_id` int(11) NOT NULL,
  `procedure_retire_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_procedure_retire`
--

LOCK TABLES `tblhr_procedure_retire` WRITE;
/*!40000 ALTER TABLE `tblhr_procedure_retire` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_procedure_retire` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_procedure_retire_manage`
--

DROP TABLE IF EXISTS `tblhr_procedure_retire_manage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhr_procedure_retire_manage` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name_procedure_retire` text NOT NULL,
  `department` varchar(250) NOT NULL,
  `datecreator` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_procedure_retire_manage`
--

LOCK TABLES `tblhr_procedure_retire_manage` WRITE;
/*!40000 ALTER TABLE `tblhr_procedure_retire_manage` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_procedure_retire_manage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_procedure_retire_of_staff`
--

DROP TABLE IF EXISTS `tblhr_procedure_retire_of_staff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhr_procedure_retire_of_staff` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) DEFAULT NULL,
  `option_name` text DEFAULT NULL,
  `status` int(11) DEFAULT 0,
  `staffid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_procedure_retire_of_staff`
--

LOCK TABLES `tblhr_procedure_retire_of_staff` WRITE;
/*!40000 ALTER TABLE `tblhr_procedure_retire_of_staff` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_procedure_retire_of_staff` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_procedure_retire_of_staff_by_id`
--

DROP TABLE IF EXISTS `tblhr_procedure_retire_of_staff_by_id`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhr_procedure_retire_of_staff_by_id` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_name` text DEFAULT NULL,
  `people_handle_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_procedure_retire_of_staff_by_id`
--

LOCK TABLES `tblhr_procedure_retire_of_staff_by_id` WRITE;
/*!40000 ALTER TABLE `tblhr_procedure_retire_of_staff_by_id` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_procedure_retire_of_staff_by_id` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_profile_option`
--

DROP TABLE IF EXISTS `tblhr_profile_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhr_profile_option` (
  `option_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(200) NOT NULL,
  `option_val` longtext DEFAULT NULL,
  `auto` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`option_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_profile_option`
--

LOCK TABLES `tblhr_profile_option` WRITE;
/*!40000 ALTER TABLE `tblhr_profile_option` DISABLE KEYS */;
INSERT INTO `tblhr_profile_option` VALUES (1,'job_position_prefix','#JOB',1),(2,'job_position_number','1',1),(3,'contract_code_prefix','#CONTRACT',1),(4,'contract_code_number','1',1),(5,'staff_code_prefix','EC',1),(6,'staff_code_number','1',1);
/*!40000 ALTER TABLE `tblhr_profile_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_rec_transfer_records`
--

DROP TABLE IF EXISTS `tblhr_rec_transfer_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhr_rec_transfer_records` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `firstname` varchar(100) DEFAULT NULL,
  `lastname` varchar(100) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `gender` varchar(11) DEFAULT NULL,
  `staff_identifi` varchar(20) DEFAULT NULL,
  `creator` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_rec_transfer_records`
--

LOCK TABLES `tblhr_rec_transfer_records` WRITE;
/*!40000 ALTER TABLE `tblhr_rec_transfer_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_rec_transfer_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_salary_form`
--

DROP TABLE IF EXISTS `tblhr_salary_form`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhr_salary_form` (
  `form_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `form_name` varchar(200) NOT NULL,
  `salary_val` decimal(15,2) NOT NULL,
  `tax` tinyint(1) NOT NULL,
  `calculation_type` int(1) DEFAULT NULL,
  `percentage_val` decimal(5,2) DEFAULT NULL,
  `active` tinyint(1) DEFAULT 1,
  `is_part_of_structure` tinyint(1) DEFAULT 1,
  `is_tax_deducted_monthly` tinyint(1) DEFAULT 1,
  `is_prorated` tinyint(1) DEFAULT 0,
  `consider_for_epf` tinyint(1) DEFAULT 1,
  `consider_for_esi` tinyint(1) DEFAULT 1,
  `show_in_payslip` tinyint(1) DEFAULT 1,
  `pay_type` tinyint(1) DEFAULT 1,
  `epf_condition` varchar(50) DEFAULT 'Always',
  PRIMARY KEY (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_salary_form`
--

LOCK TABLES `tblhr_salary_form` WRITE;
/*!40000 ALTER TABLE `tblhr_salary_form` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_salary_form` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_staff_contract`
--

DROP TABLE IF EXISTS `tblhr_staff_contract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhr_staff_contract` (
  `id_contract` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `contract_code` varchar(200) NOT NULL,
  `name_contract` int(11) NOT NULL,
  `staff` int(11) NOT NULL,
  `start_valid` date DEFAULT NULL,
  `end_valid` date DEFAULT NULL,
  `contract_status` varchar(100) DEFAULT NULL,
  `sign_day` date DEFAULT NULL,
  `staff_delegate` int(11) DEFAULT NULL,
  `hourly_or_month` longtext DEFAULT NULL,
  `content` longtext DEFAULT NULL,
  `hash` varchar(32) DEFAULT NULL,
  `signature` varchar(40) DEFAULT NULL,
  `signer` int(11) DEFAULT NULL,
  `staff_signature` varchar(40) DEFAULT NULL,
  `staff_sign_day` date DEFAULT NULL,
  `ctc` decimal(5,2) DEFAULT NULL,
  PRIMARY KEY (`id_contract`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_staff_contract`
--

LOCK TABLES `tblhr_staff_contract` WRITE;
/*!40000 ALTER TABLE `tblhr_staff_contract` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_staff_contract` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_staff_contract_detail`
--

DROP TABLE IF EXISTS `tblhr_staff_contract_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhr_staff_contract_detail` (
  `contract_detail_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staff_contract_id` int(11) unsigned NOT NULL,
  `type` text DEFAULT NULL,
  `rel_type` text DEFAULT NULL,
  `rel_value` decimal(15,2) DEFAULT 0.00,
  `since_date` date DEFAULT NULL,
  `contract_note` text DEFAULT NULL,
  `annual_value` decimal(10,2) DEFAULT NULL,
  `percentage_value` decimal(5,2) DEFAULT NULL,
  `calculation_type` int(1) DEFAULT NULL,
  PRIMARY KEY (`contract_detail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_staff_contract_detail`
--

LOCK TABLES `tblhr_staff_contract_detail` WRITE;
/*!40000 ALTER TABLE `tblhr_staff_contract_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_staff_contract_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_staff_contract_type`
--

DROP TABLE IF EXISTS `tblhr_staff_contract_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhr_staff_contract_type` (
  `id_contracttype` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name_contracttype` varchar(200) NOT NULL,
  `description` longtext DEFAULT NULL,
  `duration` int(11) DEFAULT NULL,
  `unit` varchar(20) DEFAULT NULL,
  `insurance` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id_contracttype`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_staff_contract_type`
--

LOCK TABLES `tblhr_staff_contract_type` WRITE;
/*!40000 ALTER TABLE `tblhr_staff_contract_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_staff_contract_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_training_allocation`
--

DROP TABLE IF EXISTS `tblhr_training_allocation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhr_training_allocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `training_process_id` varchar(100) NOT NULL,
  `staffid` int(11) DEFAULT NULL,
  `training_type` int(11) DEFAULT NULL,
  `date_add` datetime DEFAULT NULL,
  `training_name` varchar(150) DEFAULT NULL,
  `jp_interview_training_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_training_allocation`
--

LOCK TABLES `tblhr_training_allocation` WRITE;
/*!40000 ALTER TABLE `tblhr_training_allocation` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_training_allocation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_type_of_trainings`
--

DROP TABLE IF EXISTS `tblhr_type_of_trainings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhr_type_of_trainings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_type_of_trainings`
--

LOCK TABLES `tblhr_type_of_trainings` WRITE;
/*!40000 ALTER TABLE `tblhr_type_of_trainings` DISABLE KEYS */;
INSERT INTO `tblhr_type_of_trainings` VALUES (1,'Basic training');
/*!40000 ALTER TABLE `tblhr_type_of_trainings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_views_tracking`
--

DROP TABLE IF EXISTS `tblhr_views_tracking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhr_views_tracking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(40) NOT NULL,
  `date` datetime NOT NULL,
  `view_ip` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_views_tracking`
--

LOCK TABLES `tblhr_views_tracking` WRITE;
/*!40000 ALTER TABLE `tblhr_views_tracking` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_views_tracking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhr_workplace`
--

DROP TABLE IF EXISTS `tblhr_workplace`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhr_workplace` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `workplace_address` varchar(400) DEFAULT NULL,
  `latitude` double DEFAULT NULL,
  `longitude` double DEFAULT NULL,
  `default` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhr_workplace`
--

LOCK TABLES `tblhr_workplace` WRITE;
/*!40000 ALTER TABLE `tblhr_workplace` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhr_workplace` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhrp_bonus_kpi`
--

DROP TABLE IF EXISTS `tblhrp_bonus_kpi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhrp_bonus_kpi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `month_bonus_kpi` varchar(45) DEFAULT NULL,
  `staffid` int(11) DEFAULT NULL,
  `bonus_kpi` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhrp_bonus_kpi`
--

LOCK TABLES `tblhrp_bonus_kpi` WRITE;
/*!40000 ALTER TABLE `tblhrp_bonus_kpi` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhrp_bonus_kpi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhrp_commissions`
--

DROP TABLE IF EXISTS `tblhrp_commissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhrp_commissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `month` date NOT NULL,
  `commission_amount` decimal(15,2) DEFAULT NULL,
  `rel_type` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhrp_commissions`
--

LOCK TABLES `tblhrp_commissions` WRITE;
/*!40000 ALTER TABLE `tblhrp_commissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhrp_commissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhrp_company_contributions_list`
--

DROP TABLE IF EXISTS `tblhrp_company_contributions_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhrp_company_contributions_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(200) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `rate` decimal(15,2) DEFAULT NULL,
  `basis` varchar(200) DEFAULT NULL,
  `earn_inclusion` varchar(200) DEFAULT NULL,
  `earn_exclusion` varchar(200) DEFAULT NULL,
  `earnings_max` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhrp_company_contributions_list`
--

LOCK TABLES `tblhrp_company_contributions_list` WRITE;
/*!40000 ALTER TABLE `tblhrp_company_contributions_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhrp_company_contributions_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhrp_customize_staff_payslip_columns`
--

DROP TABLE IF EXISTS `tblhrp_customize_staff_payslip_columns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhrp_customize_staff_payslip_columns` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `column_name` text DEFAULT NULL,
  `order_number` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhrp_customize_staff_payslip_columns`
--

LOCK TABLES `tblhrp_customize_staff_payslip_columns` WRITE;
/*!40000 ALTER TABLE `tblhrp_customize_staff_payslip_columns` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhrp_customize_staff_payslip_columns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhrp_earnings_list`
--

DROP TABLE IF EXISTS `tblhrp_earnings_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhrp_earnings_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(200) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `short_name` varchar(200) DEFAULT NULL,
  `taxable` decimal(15,2) DEFAULT NULL,
  `basis_type` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhrp_earnings_list`
--

LOCK TABLES `tblhrp_earnings_list` WRITE;
/*!40000 ALTER TABLE `tblhrp_earnings_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhrp_earnings_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhrp_earnings_list_hr_records`
--

DROP TABLE IF EXISTS `tblhrp_earnings_list_hr_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhrp_earnings_list_hr_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(200) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `short_name` varchar(200) DEFAULT NULL,
  `taxable` decimal(15,2) DEFAULT NULL,
  `basis_type` varchar(200) DEFAULT NULL,
  `rel_type` varchar(200) DEFAULT NULL,
  `rel_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhrp_earnings_list_hr_records`
--

LOCK TABLES `tblhrp_earnings_list_hr_records` WRITE;
/*!40000 ALTER TABLE `tblhrp_earnings_list_hr_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhrp_earnings_list_hr_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhrp_employees_timeshee_leaves`
--

DROP TABLE IF EXISTS `tblhrp_employees_timeshee_leaves`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhrp_employees_timeshee_leaves` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `month` date NOT NULL,
  `day_1` text DEFAULT '',
  `day_2` text DEFAULT '',
  `day_3` text DEFAULT '',
  `day_4` text DEFAULT '',
  `day_5` text DEFAULT '',
  `day_6` text DEFAULT '',
  `day_7` text DEFAULT '',
  `day_8` text DEFAULT '',
  `day_9` text DEFAULT '',
  `day_10` text DEFAULT '',
  `day_11` text DEFAULT '',
  `day_12` text DEFAULT '',
  `day_13` text DEFAULT '',
  `day_14` text DEFAULT '',
  `day_15` text DEFAULT '',
  `day_16` text DEFAULT '',
  `day_17` text DEFAULT '',
  `day_18` text DEFAULT '',
  `day_19` text DEFAULT '',
  `day_20` text DEFAULT '',
  `day_21` text DEFAULT '',
  `day_22` text DEFAULT '',
  `day_23` text DEFAULT '',
  `day_24` text DEFAULT '',
  `day_25` text DEFAULT '',
  `day_26` text DEFAULT '',
  `day_27` text DEFAULT '',
  `day_28` text DEFAULT '',
  `day_29` text DEFAULT '',
  `day_30` text DEFAULT '',
  `day_31` text DEFAULT '',
  `paid_leave` decimal(15,2) DEFAULT NULL,
  `unpaid_leave` decimal(15,2) DEFAULT NULL,
  `rel_type` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhrp_employees_timeshee_leaves`
--

LOCK TABLES `tblhrp_employees_timeshee_leaves` WRITE;
/*!40000 ALTER TABLE `tblhrp_employees_timeshee_leaves` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhrp_employees_timeshee_leaves` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhrp_employees_timesheets`
--

DROP TABLE IF EXISTS `tblhrp_employees_timesheets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhrp_employees_timesheets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `month` date NOT NULL,
  `day_1` decimal(15,2) DEFAULT 0.00,
  `day_2` decimal(15,2) DEFAULT 0.00,
  `day_3` decimal(15,2) DEFAULT 0.00,
  `day_4` decimal(15,2) DEFAULT 0.00,
  `day_5` decimal(15,2) DEFAULT 0.00,
  `day_6` decimal(15,2) DEFAULT 0.00,
  `day_7` decimal(15,2) DEFAULT 0.00,
  `day_8` decimal(15,2) DEFAULT 0.00,
  `day_9` decimal(15,2) DEFAULT 0.00,
  `day_10` decimal(15,2) DEFAULT 0.00,
  `day_11` decimal(15,2) DEFAULT 0.00,
  `day_12` decimal(15,2) DEFAULT 0.00,
  `day_13` decimal(15,2) DEFAULT 0.00,
  `day_14` decimal(15,2) DEFAULT 0.00,
  `day_15` decimal(15,2) DEFAULT 0.00,
  `day_16` decimal(15,2) DEFAULT 0.00,
  `day_17` decimal(15,2) DEFAULT 0.00,
  `day_18` decimal(15,2) DEFAULT 0.00,
  `day_19` decimal(15,2) DEFAULT 0.00,
  `day_20` decimal(15,2) DEFAULT 0.00,
  `day_21` decimal(15,2) DEFAULT 0.00,
  `day_22` decimal(15,2) DEFAULT 0.00,
  `day_23` decimal(15,2) DEFAULT 0.00,
  `day_24` decimal(15,2) DEFAULT 0.00,
  `day_25` decimal(15,2) DEFAULT 0.00,
  `day_26` decimal(15,2) DEFAULT 0.00,
  `day_27` decimal(15,2) DEFAULT 0.00,
  `day_28` decimal(15,2) DEFAULT 0.00,
  `day_29` decimal(15,2) DEFAULT 0.00,
  `day_30` decimal(15,2) DEFAULT 0.00,
  `day_31` decimal(15,2) DEFAULT 0.00,
  `standard_workday` decimal(15,2) DEFAULT NULL,
  `actual_workday` decimal(15,2) DEFAULT NULL,
  `paid_leave` decimal(15,2) DEFAULT NULL,
  `unpaid_leave` decimal(15,2) DEFAULT NULL,
  `rel_type` varchar(100) DEFAULT NULL,
  `actual_workday_probation` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhrp_employees_timesheets`
--

LOCK TABLES `tblhrp_employees_timesheets` WRITE;
/*!40000 ALTER TABLE `tblhrp_employees_timesheets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhrp_employees_timesheets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhrp_employees_value`
--

DROP TABLE IF EXISTS `tblhrp_employees_value`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhrp_employees_value` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `month` date NOT NULL,
  `job_title` varchar(200) DEFAULT NULL,
  `income_tax_number` varchar(200) DEFAULT NULL,
  `residential_address` text DEFAULT NULL,
  `income_rebate_code` varchar(200) DEFAULT NULL,
  `income_tax_rate` varchar(200) DEFAULT NULL,
  `probationary_contracts` longtext DEFAULT NULL,
  `primary_contracts` longtext DEFAULT NULL,
  `rel_type` varchar(100) DEFAULT NULL,
  `probationary_effective` date DEFAULT NULL,
  `probationary_expiration` date DEFAULT NULL,
  `primary_effective` date DEFAULT NULL,
  `primary_expiration` date DEFAULT NULL,
  `bank_name` varchar(500) DEFAULT NULL,
  `account_number` varchar(200) DEFAULT NULL,
  `epf_no` text DEFAULT NULL,
  `social_security_no` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhrp_employees_value`
--

LOCK TABLES `tblhrp_employees_value` WRITE;
/*!40000 ALTER TABLE `tblhrp_employees_value` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhrp_employees_value` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhrp_income_tax_rates`
--

DROP TABLE IF EXISTS `tblhrp_income_tax_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhrp_income_tax_rates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tax_bracket_value_from` decimal(15,2) DEFAULT NULL,
  `tax_bracket_value_to` decimal(15,2) DEFAULT NULL,
  `tax_rate` decimal(15,2) DEFAULT NULL,
  `equivalent_value` decimal(15,2) DEFAULT NULL,
  `effective_rate` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhrp_income_tax_rates`
--

LOCK TABLES `tblhrp_income_tax_rates` WRITE;
/*!40000 ALTER TABLE `tblhrp_income_tax_rates` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhrp_income_tax_rates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhrp_income_tax_rebates`
--

DROP TABLE IF EXISTS `tblhrp_income_tax_rebates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhrp_income_tax_rebates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(200) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `value` decimal(15,2) DEFAULT NULL,
  `total` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhrp_income_tax_rebates`
--

LOCK TABLES `tblhrp_income_tax_rebates` WRITE;
/*!40000 ALTER TABLE `tblhrp_income_tax_rebates` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhrp_income_tax_rebates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhrp_income_taxs`
--

DROP TABLE IF EXISTS `tblhrp_income_taxs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhrp_income_taxs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `month` date NOT NULL,
  `gross_amount` decimal(15,2) DEFAULT NULL,
  `total_deduction_amount` decimal(15,2) DEFAULT NULL,
  `income_tax` decimal(15,2) DEFAULT NULL,
  `payslip_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhrp_income_taxs`
--

LOCK TABLES `tblhrp_income_taxs` WRITE;
/*!40000 ALTER TABLE `tblhrp_income_taxs` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhrp_income_taxs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhrp_insurance_list`
--

DROP TABLE IF EXISTS `tblhrp_insurance_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhrp_insurance_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(200) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `rate` decimal(15,2) DEFAULT NULL,
  `basis` varchar(200) DEFAULT NULL,
  `benefit_plan_type` enum('NPS','Other Non-Taxable Deduction') DEFAULT NULL,
  `associated_section` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`associated_section`)),
  `include_employer_contribution` tinyint(1) DEFAULT 0,
  `is_superannuation_fund` tinyint(1) DEFAULT 0,
  `calculate_pro_rata` tinyint(1) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhrp_insurance_list`
--

LOCK TABLES `tblhrp_insurance_list` WRITE;
/*!40000 ALTER TABLE `tblhrp_insurance_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhrp_insurance_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhrp_payroll_columns`
--

DROP TABLE IF EXISTS `tblhrp_payroll_columns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhrp_payroll_columns` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `column_key` text DEFAULT NULL,
  `taking_method` text DEFAULT NULL COMMENT 'get from system, caculator, constant... ',
  `function_name` text DEFAULT NULL COMMENT 'get value for method system',
  `value_related_to` text DEFAULT NULL COMMENT 'salary, allowance value...',
  `display_with_staff` varchar(10) DEFAULT 'true',
  `description` text DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `staff_id_created` int(11) NOT NULL,
  `order_display` int(11) DEFAULT NULL,
  `is_edit` varchar(100) DEFAULT 'yes',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhrp_payroll_columns`
--

LOCK TABLES `tblhrp_payroll_columns` WRITE;
/*!40000 ALTER TABLE `tblhrp_payroll_columns` DISABLE KEYS */;
INSERT INTO `tblhrp_payroll_columns` VALUES (1,'Staff ID','system','staff_id','','true','Staff ID','2025-06-25 21:33:29',1,1,'no'),(2,'Payslip Number','system','pay_slip_number','','true','Pay Slip Number','2025-06-25 21:33:29',1,2,'no'),(3,'Payment Run Date','system','payment_run_date','','true','Payment Run Date','2025-06-25 21:33:29',1,3,'no'),(4,'Employee Number','system','employee_number','','true','Employee Number','2025-06-25 21:33:29',1,4,'no'),(5,'Employee Name','system','employee_name','','true','Employee Name','2025-06-25 21:33:29',1,5,'no'),(6,'Deparment Name','system','dept_name','','true','Dept name Name','2025-06-25 21:33:29',1,6,'no'),(7,'Standard Working Time','system','standard_workday','','true','Standard working time of the month (hours)','2025-06-25 21:33:29',1,7,'no'),(8,'Actual Working Time of Formal contract','system','actual_workday','','true','Actual working time (hours)','2025-06-25 21:33:29',1,8,'no'),(9,'Actual Working Time of Probation contract','system','actual_workday_probation','','true','Actual Working Time of Probation contract (hours)','2025-06-25 21:33:29',1,9,'no'),(10,'Paid Leave Time','system','paid_leave','','true','Paid Leave Time (hours)','2025-06-25 21:33:29',1,10,'no'),(11,'Unpaid Leave Time','system','unpaid_leave','','true','Unpaid Leave Time (hours)','2025-06-25 21:33:29',1,11,'no'),(12,'Salary of the probationary contract','caculator','salary_of_the_probationary_contract','','true','Salary of the probationary contract','2025-06-25 21:33:29',1,12,'no'),(13,'Salary of the formal contract','caculator','salary_of_the_formal_contract','','true','Salary of the formal contract','2025-06-25 21:33:29',1,13,'no'),(14,'Gross Pay','caculator','gross_pay','','true','Gross Pay','2025-06-25 21:33:29',1,14,'no'),(15,'Total Deductions','caculator','total_deductions','','true','Total Deductions','2025-06-25 21:33:29',1,15,'no'),(16,'Total Insurance','caculator','total_insurance','','true','Total Insurance','2025-06-25 21:33:29',1,16,'no'),(17,'Income Tax Rebate Code','system','it_rebate_code','','true','IT Rebate Code','2025-06-25 21:33:29',1,17,'no'),(18,'Income Tax Rebate Value','system','it_rebate_value','','true','IT Rebate Value','2025-06-25 21:33:29',1,18,'no'),(19,'Taxable salary','caculator','taxable_salary','','true','Taxable salary','2025-06-25 21:33:29',1,19,'no'),(20,'Income Tax code','system','income_tax_code','','true','Income Tax code','2025-06-25 21:33:29',1,20,'no'),(21,'Personal Income Tax','system','income_tax_paye','','true','Personal Income Tax','2025-06-25 21:33:29',1,21,'no'),(22,'Commission Amount','system','commission_amount','','true','Commission','2025-06-25 21:33:29',1,22,'no'),(23,'Bonus Kpi','system','bonus_kpi','','true','Bonus Kpi','2025-06-25 21:33:29',1,23,'no'),(24,'Net Pay','caculator','net_pay','','true','Net Pay','2025-06-25 21:33:29',1,24,'no'),(25,'Total Cost','caculator','total_cost','','true','Total cost','2025-06-25 21:33:29',1,25,'no'),(26,'Total hours by tasks','system','total_hours_by_tasks','','true','Total hours by tasks','2025-06-25 21:33:29',1,16,'no'),(27,'Salary from tasks','system','salary_from_tasks','','true','Salary from tasks','2025-06-25 21:33:29',1,16,'no'),(28,'Bank Name','system','bank_name','','true','Bank Name','2025-06-25 21:33:29',1,17,'no'),(29,'Account Number','system','account_number','','true','Account Number','2025-06-25 21:33:29',1,17,'no'),(30,'EPF No','system','epf_no','','true','EPF No','2025-06-25 21:33:29',1,17,'no'),(31,'Social Security No','system','social_security_no','','true','Social Security No','2025-06-25 21:33:29',1,17,'no');
/*!40000 ALTER TABLE `tblhrp_payroll_columns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhrp_payslip_details`
--

DROP TABLE IF EXISTS `tblhrp_payslip_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhrp_payslip_details` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `payslip_id` int(11) DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `month` date NOT NULL,
  `pay_slip_number` text DEFAULT NULL,
  `payment_run_date` date NOT NULL,
  `employee_number` text DEFAULT NULL,
  `employee_name` text DEFAULT NULL,
  `dept_name` text DEFAULT NULL,
  `standard_workday` decimal(15,2) DEFAULT 0.00,
  `actual_workday` decimal(15,2) DEFAULT 0.00,
  `paid_leave` decimal(15,2) DEFAULT 0.00,
  `unpaid_leave` decimal(15,2) DEFAULT 0.00,
  `gross_pay` decimal(15,2) DEFAULT 0.00,
  `income_tax_paye` decimal(15,2) DEFAULT 0.00,
  `total_deductions` decimal(15,2) DEFAULT 0.00,
  `net_pay` decimal(15,2) DEFAULT 0.00,
  `it_rebate_code` text DEFAULT NULL,
  `it_rebate_value` decimal(15,2) DEFAULT 0.00,
  `income_tax_code` text DEFAULT NULL,
  `commission_amount` decimal(15,2) DEFAULT 0.00,
  `bonus_kpi` decimal(15,2) DEFAULT 0.00,
  `total_cost` decimal(15,2) DEFAULT 0.00,
  `total_insurance` decimal(15,2) DEFAULT 0.00,
  `json_data` longtext DEFAULT NULL,
  `salary_of_the_probationary_contract` decimal(15,2) DEFAULT 0.00,
  `salary_of_the_formal_contract` decimal(15,2) DEFAULT 0.00,
  `taxable_salary` decimal(15,2) DEFAULT 0.00,
  `actual_workday_probation` decimal(15,2) DEFAULT 0.00,
  `total_hours_by_tasks` decimal(15,2) DEFAULT 0.00,
  `salary_from_tasks` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhrp_payslip_details`
--

LOCK TABLES `tblhrp_payslip_details` WRITE;
/*!40000 ALTER TABLE `tblhrp_payslip_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhrp_payslip_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhrp_payslip_pdf_templates`
--

DROP TABLE IF EXISTS `tblhrp_payslip_pdf_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhrp_payslip_pdf_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text DEFAULT NULL,
  `payslip_template_id` int(11) DEFAULT NULL,
  `content` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhrp_payslip_pdf_templates`
--

LOCK TABLES `tblhrp_payslip_pdf_templates` WRITE;
/*!40000 ALTER TABLE `tblhrp_payslip_pdf_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhrp_payslip_pdf_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhrp_payslip_templates`
--

DROP TABLE IF EXISTS `tblhrp_payslip_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhrp_payslip_templates` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `templates_name` varchar(100) NOT NULL,
  `payslip_columns` longtext DEFAULT NULL,
  `payslip_id_copy` int(11) unsigned NOT NULL,
  `department_id` longtext DEFAULT NULL,
  `role_employees` longtext DEFAULT NULL,
  `staff_employees` longtext DEFAULT NULL,
  `payslip_template_data` longtext DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `staff_id_created` int(11) NOT NULL,
  `cell_data` longtext DEFAULT NULL,
  `except_staff` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhrp_payslip_templates`
--

LOCK TABLES `tblhrp_payslip_templates` WRITE;
/*!40000 ALTER TABLE `tblhrp_payslip_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhrp_payslip_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhrp_payslips`
--

DROP TABLE IF EXISTS `tblhrp_payslips`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhrp_payslips` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `payslip_name` varchar(100) NOT NULL,
  `payslip_template_id` int(11) DEFAULT NULL,
  `payslip_month` date NOT NULL,
  `staff_id_created` int(11) NOT NULL,
  `date_created` datetime NOT NULL,
  `payslip_data` longtext DEFAULT NULL,
  `file_name` text DEFAULT NULL,
  `payslip_status` varchar(100) DEFAULT 'payslip_opening',
  `payslip_range` varchar(500) DEFAULT NULL,
  `pdf_template_id` int(11) DEFAULT NULL,
  `from_currency_id` int(11) DEFAULT 0,
  `from_currency_name` varchar(100) DEFAULT NULL,
  `from_currency_rate` decimal(15,6) NOT NULL DEFAULT 1.000000,
  `to_currency_id` int(11) DEFAULT 0,
  `to_currency_name` varchar(100) DEFAULT NULL,
  `to_currency_rate` decimal(15,6) NOT NULL DEFAULT 1.000000,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhrp_payslips`
--

LOCK TABLES `tblhrp_payslips` WRITE;
/*!40000 ALTER TABLE `tblhrp_payslips` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhrp_payslips` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhrp_reimbursement_list`
--

DROP TABLE IF EXISTS `tblhrp_reimbursement_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhrp_reimbursement_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reimbursement_type` varchar(100) NOT NULL,
  `name_in_payslip` varchar(100) NOT NULL,
  `is_fbp_component` tinyint(1) DEFAULT 0,
  `restrict_fbp_override` tinyint(1) DEFAULT 0,
  `unclaimed_handling` enum('carry_forward_encash_year_end','encash_monthly') NOT NULL,
  `max_monthly_amount` decimal(10,2) DEFAULT 0.00,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `note` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhrp_reimbursement_list`
--

LOCK TABLES `tblhrp_reimbursement_list` WRITE;
/*!40000 ALTER TABLE `tblhrp_reimbursement_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhrp_reimbursement_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhrp_salary_deductions`
--

DROP TABLE IF EXISTS `tblhrp_salary_deductions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhrp_salary_deductions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `month` date NOT NULL,
  `deduction_list` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhrp_salary_deductions`
--

LOCK TABLES `tblhrp_salary_deductions` WRITE;
/*!40000 ALTER TABLE `tblhrp_salary_deductions` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhrp_salary_deductions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhrp_salary_deductions_list`
--

DROP TABLE IF EXISTS `tblhrp_salary_deductions_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhrp_salary_deductions_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(200) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `rate` decimal(15,2) DEFAULT NULL,
  `basis` varchar(200) DEFAULT NULL,
  `earn_inclusion` varchar(200) DEFAULT NULL,
  `earn_exclusion` varchar(200) DEFAULT NULL,
  `earnings_max` decimal(15,2) DEFAULT NULL,
  `tax` decimal(15,2) DEFAULT NULL,
  `annual_tax_limit` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhrp_salary_deductions_list`
--

LOCK TABLES `tblhrp_salary_deductions_list` WRITE;
/*!40000 ALTER TABLE `tblhrp_salary_deductions_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhrp_salary_deductions_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhrp_salary_reimbursements`
--

DROP TABLE IF EXISTS `tblhrp_salary_reimbursements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhrp_salary_reimbursements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `month` date NOT NULL,
  `reimbursement_list` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhrp_salary_reimbursements`
--

LOCK TABLES `tblhrp_salary_reimbursements` WRITE;
/*!40000 ALTER TABLE `tblhrp_salary_reimbursements` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhrp_salary_reimbursements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblhrp_staff_insurances`
--

DROP TABLE IF EXISTS `tblhrp_staff_insurances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblhrp_staff_insurances` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `month` date NOT NULL,
  `insurance_list` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhrp_staff_insurances`
--

LOCK TABLES `tblhrp_staff_insurances` WRITE;
/*!40000 ALTER TABLE `tblhrp_staff_insurances` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblhrp_staff_insurances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblinternal_delivery_note`
--

DROP TABLE IF EXISTS `tblinternal_delivery_note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblinternal_delivery_note` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `internal_delivery_name` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `date_c` date DEFAULT NULL,
  `date_add` date DEFAULT NULL,
  `internal_delivery_code` varchar(100) DEFAULT NULL,
  `approval` int(11) DEFAULT 0 COMMENT 'status approval ',
  `addedfrom` int(11) DEFAULT NULL,
  `total_amount` decimal(15,2) DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblinternal_delivery_note`
--

LOCK TABLES `tblinternal_delivery_note` WRITE;
/*!40000 ALTER TABLE `tblinternal_delivery_note` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblinternal_delivery_note` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblinternal_delivery_note_detail`
--

DROP TABLE IF EXISTS `tblinternal_delivery_note_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblinternal_delivery_note_detail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `internal_delivery_id` int(11) NOT NULL,
  `commodity_code` varchar(100) DEFAULT NULL,
  `from_stock_name` text DEFAULT NULL,
  `to_stock_name` text DEFAULT NULL,
  `unit_id` text DEFAULT NULL,
  `available_quantity` text DEFAULT NULL,
  `quantities` text DEFAULT NULL,
  `unit_price` varchar(100) DEFAULT NULL,
  `into_money` varchar(100) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `commodity_name` text DEFAULT NULL,
  `serial_number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblinternal_delivery_note_detail`
--

LOCK TABLES `tblinternal_delivery_note_detail` WRITE;
/*!40000 ALTER TABLE `tblinternal_delivery_note_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblinternal_delivery_note_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblinventory_commodity_min`
--

DROP TABLE IF EXISTS `tblinventory_commodity_min`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblinventory_commodity_min` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `commodity_id` int(11) NOT NULL,
  `commodity_code` varchar(100) DEFAULT NULL,
  `commodity_name` varchar(100) DEFAULT NULL,
  `inventory_number_min` varchar(100) DEFAULT NULL,
  `inventory_number_max` varchar(100) DEFAULT '0',
  PRIMARY KEY (`id`,`commodity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblinventory_commodity_min`
--

LOCK TABLES `tblinventory_commodity_min` WRITE;
/*!40000 ALTER TABLE `tblinventory_commodity_min` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblinventory_commodity_min` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblinventory_manage`
--

DROP TABLE IF EXISTS `tblinventory_manage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblinventory_manage` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `warehouse_id` int(11) NOT NULL,
  `commodity_id` int(11) NOT NULL,
  `inventory_number` varchar(100) DEFAULT NULL,
  `date_manufacture` date DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `lot_number` varchar(100) DEFAULT NULL,
  `purchase_price` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`,`commodity_id`,`warehouse_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblinventory_manage`
--

LOCK TABLES `tblinventory_manage` WRITE;
/*!40000 ALTER TABLE `tblinventory_manage` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblinventory_manage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblinvoicepaymentrecords`
--

DROP TABLE IF EXISTS `tblinvoicepaymentrecords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblinvoicepaymentrecords` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoiceid` int(11) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `paymentmode` varchar(40) DEFAULT NULL,
  `paymentmethod` varchar(191) DEFAULT NULL,
  `date` date NOT NULL,
  `daterecorded` datetime NOT NULL,
  `note` mediumtext DEFAULT NULL,
  `transactionid` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `invoiceid` (`invoiceid`),
  KEY `paymentmethod` (`paymentmethod`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblinvoicepaymentrecords`
--

LOCK TABLES `tblinvoicepaymentrecords` WRITE;
/*!40000 ALTER TABLE `tblinvoicepaymentrecords` DISABLE KEYS */;
INSERT INTO `tblinvoicepaymentrecords` VALUES (2,4,18000.00,'1',NULL,'2025-07-08','2025-07-08 10:54:15','','');
/*!40000 ALTER TABLE `tblinvoicepaymentrecords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblinvoices`
--

DROP TABLE IF EXISTS `tblinvoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblinvoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sent` tinyint(1) NOT NULL DEFAULT 0,
  `datesend` datetime DEFAULT NULL,
  `clientid` int(11) NOT NULL,
  `deleted_customer_name` varchar(100) DEFAULT NULL,
  `number` int(11) NOT NULL,
  `prefix` varchar(50) DEFAULT NULL,
  `number_format` int(11) NOT NULL DEFAULT 0,
  `datecreated` datetime NOT NULL,
  `date` date NOT NULL,
  `duedate` date DEFAULT NULL,
  `currency` int(11) NOT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `total_tax` decimal(15,2) NOT NULL DEFAULT 0.00,
  `total` decimal(15,2) NOT NULL,
  `adjustment` decimal(15,2) DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `hash` varchar(32) NOT NULL,
  `status` int(11) DEFAULT 1,
  `clientnote` mediumtext DEFAULT NULL,
  `adminnote` mediumtext DEFAULT NULL,
  `last_overdue_reminder` date DEFAULT NULL,
  `last_due_reminder` date DEFAULT NULL,
  `cancel_overdue_reminders` int(11) NOT NULL DEFAULT 0,
  `allowed_payment_modes` longtext DEFAULT NULL,
  `token` longtext DEFAULT NULL,
  `discount_percent` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `discount_type` varchar(30) NOT NULL,
  `recurring` int(11) NOT NULL DEFAULT 0,
  `recurring_type` varchar(10) DEFAULT NULL,
  `custom_recurring` tinyint(1) NOT NULL DEFAULT 0,
  `cycles` int(11) NOT NULL DEFAULT 0,
  `total_cycles` int(11) NOT NULL DEFAULT 0,
  `is_recurring_from` int(11) DEFAULT NULL,
  `last_recurring_date` date DEFAULT NULL,
  `terms` mediumtext DEFAULT NULL,
  `sale_agent` int(11) NOT NULL DEFAULT 0,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT NULL,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT NULL,
  `include_shipping` tinyint(1) NOT NULL,
  `show_shipping_on_invoice` tinyint(1) NOT NULL DEFAULT 1,
  `show_quantity_as` int(11) NOT NULL DEFAULT 1,
  `project_id` int(11) DEFAULT 0,
  `subscription_id` int(11) NOT NULL DEFAULT 0,
  `perfex_saas_packageid` int(11) DEFAULT NULL,
  `short_link` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `currency` (`currency`),
  KEY `clientid` (`clientid`),
  KEY `project_id` (`project_id`),
  KEY `sale_agent` (`sale_agent`),
  KEY `total` (`total`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblinvoices`
--

LOCK TABLES `tblinvoices` WRITE;
/*!40000 ALTER TABLE `tblinvoices` DISABLE KEYS */;
INSERT INTO `tblinvoices` VALUES (3,0,NULL,10,NULL,1,'INV-',1,'2025-07-08 10:06:55','2025-07-08','2025-07-08',3,18000.00,0.00,18000.00,0.00,1,'b2b2cf7dfb2146a6cba3640cf1ea7618',1,'','',NULL,NULL,0,'a:2:{i:0;s:1:\"1\";i:1;s:8:\"razorpay\";}','{\"amount\":1800000,\"razorpay_order_id\":\"order_QqSAVR0P3uyYmi\"}',0.00,0.00,'',1,NULL,0,0,0,NULL,NULL,'',0,'','','','',0,NULL,NULL,NULL,NULL,NULL,0,1,1,0,0,3,NULL),(4,0,NULL,11,NULL,2,'INV-',1,'2025-07-08 10:52:26','2025-07-08','2025-07-08',3,18000.00,0.00,18000.00,0.00,1,'4bc18b84cc2b7afed9b7f76e5264315d',2,NULL,NULL,NULL,NULL,0,'a:1:{i:0;s:1:\"1\";}',NULL,0.00,0.00,'',1,NULL,0,0,0,NULL,NULL,NULL,0,'AL-19/A-1, Sector-13, GIDA','Gorakhpur','U.P','273209,',102,NULL,NULL,NULL,NULL,NULL,0,1,1,0,0,3,NULL);
/*!40000 ALTER TABLE `tblinvoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblitem_tax`
--

DROP TABLE IF EXISTS `tblitem_tax`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblitem_tax` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemid` int(11) NOT NULL,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) NOT NULL,
  `taxrate` decimal(15,2) NOT NULL,
  `taxname` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `itemid` (`itemid`),
  KEY `rel_id` (`rel_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblitem_tax`
--

LOCK TABLES `tblitem_tax` WRITE;
/*!40000 ALTER TABLE `tblitem_tax` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblitem_tax` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblitemable`
--

DROP TABLE IF EXISTS `tblitemable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblitemable` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(15) NOT NULL,
  `description` longtext NOT NULL,
  `long_description` longtext DEFAULT NULL,
  `qty` decimal(15,2) NOT NULL,
  `rate` decimal(15,2) NOT NULL,
  `unit` varchar(40) DEFAULT NULL,
  `item_order` int(11) DEFAULT NULL,
  `wh_delivered_quantity` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`),
  KEY `qty` (`qty`),
  KEY `rate` (`rate`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblitemable`
--

LOCK TABLES `tblitemable` WRITE;
/*!40000 ALTER TABLE `tblitemable` DISABLE KEYS */;
INSERT INTO `tblitemable` VALUES (3,3,'invoice','Subscription to Business Pro Plan','',1.00,18000.00,'',1,0.00),(4,4,'invoice','Subscription to Business Pro Plan','',1.00,18000.00,'',1,0.00);
/*!40000 ALTER TABLE `tblitemable` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblitems`
--

DROP TABLE IF EXISTS `tblitems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblitems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` longtext NOT NULL,
  `long_description` mediumtext DEFAULT NULL,
  `rate` decimal(15,2) NOT NULL,
  `tax` int(11) DEFAULT NULL,
  `tax2` int(11) DEFAULT NULL,
  `unit` varchar(40) DEFAULT NULL,
  `group_id` int(11) NOT NULL DEFAULT 0,
  `product_type` varchar(100) DEFAULT NULL,
  `description_internal_transfers` text DEFAULT NULL,
  `description_receipts` text DEFAULT NULL,
  `description_delivery_orders` text DEFAULT NULL,
  `customer_lead_time` decimal(15,2) DEFAULT 0.00,
  `replenish_on_order` varchar(100) DEFAULT NULL,
  `supplier_taxes_id` text DEFAULT NULL,
  `description_sale` text DEFAULT NULL,
  `invoice_policy` varchar(100) DEFAULT 'ordered_quantities',
  `purchase_unit_measure` int(11) DEFAULT NULL,
  `can_be_sold` varchar(100) DEFAULT 'can_be_sold',
  `can_be_purchased` varchar(100) DEFAULT 'can_be_purchased',
  `can_be_manufacturing` varchar(100) DEFAULT 'can_be_manufacturing',
  `manufacture` varchar(100) DEFAULT NULL,
  `manufacturing_lead_time` decimal(15,2) DEFAULT 0.00,
  `weight` decimal(15,2) DEFAULT 0.00,
  `volume` decimal(15,2) DEFAULT 0.00,
  `hs_code` varchar(200) DEFAULT NULL,
  `commodity_code` varchar(100) NOT NULL,
  `commodity_barcode` text DEFAULT NULL,
  `commodity_type` int(11) DEFAULT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `origin` varchar(100) DEFAULT NULL,
  `color_id` int(11) DEFAULT NULL,
  `style_id` int(11) DEFAULT NULL,
  `model_id` int(11) DEFAULT NULL,
  `size_id` int(11) DEFAULT NULL,
  `unit_id` int(11) DEFAULT NULL,
  `sku_code` varchar(200) DEFAULT NULL,
  `sku_name` varchar(200) DEFAULT NULL,
  `purchase_price` decimal(15,2) DEFAULT NULL,
  `sub_group` varchar(200) DEFAULT NULL,
  `commodity_name` varchar(200) NOT NULL,
  `color` text DEFAULT NULL,
  `guarantee` text DEFAULT NULL,
  `profif_ratio` text DEFAULT NULL,
  `active` int(11) DEFAULT 1,
  `long_descriptions` longtext DEFAULT NULL,
  `without_checking_warehouse` int(11) DEFAULT 0,
  `series_id` text DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `attributes` longtext DEFAULT NULL,
  `parent_attributes` longtext DEFAULT NULL,
  `can_be_inventory` varchar(100) DEFAULT 'can_be_inventory',
  `from_vendor_item` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tax` (`tax`),
  KEY `tax2` (`tax2`),
  KEY `group_id` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblitems`
--

LOCK TABLES `tblitems` WRITE;
/*!40000 ALTER TABLE `tblitems` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblitems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblitems_groups`
--

DROP TABLE IF EXISTS `tblitems_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblitems_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `commodity_group_code` varchar(100) DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  `display` int(1) DEFAULT NULL,
  `note` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblitems_groups`
--

LOCK TABLES `tblitems_groups` WRITE;
/*!40000 ALTER TABLE `tblitems_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblitems_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblitems_of_vendor`
--

DROP TABLE IF EXISTS `tblitems_of_vendor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblitems_of_vendor` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `vendor_id` int(11) NOT NULL,
  `description` text NOT NULL,
  `long_description` text DEFAULT NULL,
  `rate` decimal(15,2) DEFAULT NULL,
  `tax` int(11) DEFAULT NULL,
  `tax2` int(11) DEFAULT NULL,
  `unit` varchar(40) DEFAULT NULL,
  `group_id` int(11) NOT NULL,
  `commodity_code` varchar(100) NOT NULL,
  `commodity_barcode` text DEFAULT NULL,
  `unit_id` int(11) DEFAULT NULL,
  `sku_code` varchar(200) DEFAULT NULL,
  `sku_name` varchar(200) DEFAULT NULL,
  `sub_group` varchar(200) DEFAULT NULL,
  `active` int(11) DEFAULT NULL,
  `parent` int(11) DEFAULT NULL,
  `attributes` longtext DEFAULT NULL,
  `parent_attributes` longtext DEFAULT NULL,
  `commodity_type` int(11) DEFAULT NULL,
  `origin` varchar(100) DEFAULT NULL,
  `commodity_name` varchar(200) NOT NULL,
  `series_id` text DEFAULT NULL,
  `long_descriptions` longtext DEFAULT NULL,
  `share_status` int(1) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblitems_of_vendor`
--

LOCK TABLES `tblitems_of_vendor` WRITE;
/*!40000 ALTER TABLE `tblitems_of_vendor` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblitems_of_vendor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbljob_industry`
--

DROP TABLE IF EXISTS `tbljob_industry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbljob_industry` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `industry_name` varchar(200) NOT NULL,
  `industry_description` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbljob_industry`
--

LOCK TABLES `tbljob_industry` WRITE;
/*!40000 ALTER TABLE `tbljob_industry` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbljob_industry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblknowedge_base_article_feedback`
--

DROP TABLE IF EXISTS `tblknowedge_base_article_feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblknowedge_base_article_feedback` (
  `articleanswerid` int(11) NOT NULL AUTO_INCREMENT,
  `articleid` int(11) NOT NULL,
  `answer` int(11) NOT NULL,
  `ip` varchar(40) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`articleanswerid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblknowedge_base_article_feedback`
--

LOCK TABLES `tblknowedge_base_article_feedback` WRITE;
/*!40000 ALTER TABLE `tblknowedge_base_article_feedback` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblknowedge_base_article_feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblknowledge_base`
--

DROP TABLE IF EXISTS `tblknowledge_base`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblknowledge_base` (
  `articleid` int(11) NOT NULL AUTO_INCREMENT,
  `articlegroup` int(11) NOT NULL,
  `subject` longtext NOT NULL,
  `description` mediumtext NOT NULL,
  `slug` longtext NOT NULL,
  `active` tinyint(4) NOT NULL,
  `datecreated` datetime NOT NULL,
  `article_order` int(11) NOT NULL DEFAULT 0,
  `staff_article` int(11) NOT NULL DEFAULT 0,
  `question_answers` int(11) DEFAULT 0,
  `file_name` varchar(255) DEFAULT '',
  `curator` varchar(11) DEFAULT '',
  `benchmark` int(11) DEFAULT 0,
  `score` int(11) DEFAULT 0,
  PRIMARY KEY (`articleid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblknowledge_base`
--

LOCK TABLES `tblknowledge_base` WRITE;
/*!40000 ALTER TABLE `tblknowledge_base` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblknowledge_base` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblknowledge_base_groups`
--

DROP TABLE IF EXISTS `tblknowledge_base_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblknowledge_base_groups` (
  `groupid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `group_slug` mediumtext DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `active` tinyint(4) NOT NULL,
  `color` varchar(10) DEFAULT '#28B8DA',
  `group_order` int(11) DEFAULT 0,
  PRIMARY KEY (`groupid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblknowledge_base_groups`
--

LOCK TABLES `tblknowledge_base_groups` WRITE;
/*!40000 ALTER TABLE `tblknowledge_base_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblknowledge_base_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbllead_activity_log`
--

DROP TABLE IF EXISTS `tbllead_activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbllead_activity_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `leadid` int(11) NOT NULL,
  `description` longtext NOT NULL,
  `additional_data` mediumtext DEFAULT NULL,
  `date` datetime NOT NULL,
  `staffid` int(11) NOT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `custom_activity` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbllead_activity_log`
--

LOCK TABLES `tbllead_activity_log` WRITE;
/*!40000 ALTER TABLE `tbllead_activity_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbllead_activity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbllead_integration_emails`
--

DROP TABLE IF EXISTS `tbllead_integration_emails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbllead_integration_emails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` longtext DEFAULT NULL,
  `body` longtext DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  `leadid` int(11) NOT NULL,
  `emailid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbllead_integration_emails`
--

LOCK TABLES `tbllead_integration_emails` WRITE;
/*!40000 ALTER TABLE `tbllead_integration_emails` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbllead_integration_emails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblleads`
--

DROP TABLE IF EXISTS `tblleads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblleads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(65) DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `company` varchar(191) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `country` int(11) NOT NULL DEFAULT 0,
  `zip` varchar(15) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `assigned` int(11) NOT NULL DEFAULT 0,
  `dateadded` datetime NOT NULL,
  `from_form_id` int(11) NOT NULL DEFAULT 0,
  `status` int(11) NOT NULL,
  `source` int(11) NOT NULL,
  `lastcontact` datetime DEFAULT NULL,
  `dateassigned` date DEFAULT NULL,
  `last_status_change` datetime DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `website` varchar(150) DEFAULT NULL,
  `leadorder` int(11) DEFAULT 1,
  `phonenumber` varchar(50) DEFAULT NULL,
  `date_converted` datetime DEFAULT NULL,
  `lost` tinyint(1) NOT NULL DEFAULT 0,
  `junk` int(11) NOT NULL DEFAULT 0,
  `last_lead_status` int(11) NOT NULL DEFAULT 0,
  `is_imported_from_email_integration` tinyint(1) NOT NULL DEFAULT 0,
  `email_integration_uid` varchar(30) DEFAULT NULL,
  `is_public` tinyint(1) NOT NULL DEFAULT 0,
  `default_language` varchar(40) DEFAULT NULL,
  `client_id` int(11) NOT NULL DEFAULT 0,
  `lead_value` decimal(15,2) DEFAULT NULL,
  `vat` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `company` (`company`),
  KEY `email` (`email`),
  KEY `assigned` (`assigned`),
  KEY `status` (`status`),
  KEY `source` (`source`),
  KEY `lastcontact` (`lastcontact`),
  KEY `dateadded` (`dateadded`),
  KEY `leadorder` (`leadorder`),
  KEY `from_form_id` (`from_form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblleads`
--

LOCK TABLES `tblleads` WRITE;
/*!40000 ALTER TABLE `tblleads` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblleads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblleads_email_integration`
--

DROP TABLE IF EXISTS `tblleads_email_integration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblleads_email_integration` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'the ID always must be 1',
  `active` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `imap_server` varchar(100) NOT NULL,
  `password` longtext NOT NULL,
  `check_every` int(11) NOT NULL DEFAULT 5,
  `responsible` int(11) NOT NULL,
  `lead_source` int(11) NOT NULL,
  `lead_status` int(11) NOT NULL,
  `encryption` varchar(3) DEFAULT NULL,
  `folder` varchar(100) NOT NULL,
  `last_run` varchar(50) DEFAULT NULL,
  `notify_lead_imported` tinyint(1) NOT NULL DEFAULT 1,
  `notify_lead_contact_more_times` tinyint(1) NOT NULL DEFAULT 1,
  `notify_type` varchar(20) DEFAULT NULL,
  `notify_ids` longtext DEFAULT NULL,
  `mark_public` int(11) NOT NULL DEFAULT 0,
  `only_loop_on_unseen_emails` tinyint(1) NOT NULL DEFAULT 1,
  `delete_after_import` int(11) NOT NULL DEFAULT 0,
  `create_task_if_customer` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblleads_email_integration`
--

LOCK TABLES `tblleads_email_integration` WRITE;
/*!40000 ALTER TABLE `tblleads_email_integration` DISABLE KEYS */;
INSERT INTO `tblleads_email_integration` VALUES (1,0,'','','',10,0,0,0,'tls','INBOX','',1,1,'assigned','',0,1,0,1);
/*!40000 ALTER TABLE `tblleads_email_integration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblleads_sources`
--

DROP TABLE IF EXISTS `tblleads_sources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblleads_sources` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblleads_sources`
--

LOCK TABLES `tblleads_sources` WRITE;
/*!40000 ALTER TABLE `tblleads_sources` DISABLE KEYS */;
INSERT INTO `tblleads_sources` VALUES (2,'Facebook'),(1,'Google');
/*!40000 ALTER TABLE `tblleads_sources` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblleads_status`
--

DROP TABLE IF EXISTS `tblleads_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblleads_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `statusorder` int(11) DEFAULT NULL,
  `color` varchar(10) DEFAULT '#28B8DA',
  `isdefault` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblleads_status`
--

LOCK TABLES `tblleads_status` WRITE;
/*!40000 ALTER TABLE `tblleads_status` DISABLE KEYS */;
INSERT INTO `tblleads_status` VALUES (1,'Customer',1000,'#7cb342',1);
/*!40000 ALTER TABLE `tblleads_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblleave_of_the_year`
--

DROP TABLE IF EXISTS `tblleave_of_the_year`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblleave_of_the_year` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `value` double DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblleave_of_the_year`
--

LOCK TABLES `tblleave_of_the_year` WRITE;
/*!40000 ALTER TABLE `tblleave_of_the_year` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblleave_of_the_year` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblloy_card`
--

DROP TABLE IF EXISTS `tblloy_card`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblloy_card` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `add_from` int(11) NOT NULL,
  `date_create` date DEFAULT NULL,
  `subject_card` int(2) DEFAULT 0,
  `client_name` int(2) DEFAULT 0,
  `membership` int(2) DEFAULT 0,
  `company_name` int(2) DEFAULT 0,
  `member_since` int(2) DEFAULT 0,
  `custom_field` int(2) DEFAULT 0,
  `custom_field_content` varchar(200) DEFAULT NULL,
  `text_color` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblloy_card`
--

LOCK TABLES `tblloy_card` WRITE;
/*!40000 ALTER TABLE `tblloy_card` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblloy_card` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblloy_mbs_program`
--

DROP TABLE IF EXISTS `tblloy_mbs_program`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblloy_mbs_program` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `program_name` varchar(200) NOT NULL,
  `add_from` int(11) NOT NULL,
  `date_create` date DEFAULT NULL,
  `voucher_code` text NOT NULL,
  `discount` varchar(30) DEFAULT NULL,
  `discount_percent` int(5) DEFAULT NULL,
  `loyalty_point_from` decimal(15,0) DEFAULT NULL,
  `loyalty_point_to` decimal(15,0) DEFAULT NULL,
  `membership` text NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `note` text DEFAULT NULL,
  `voucher_value` decimal(15,2) DEFAULT 0.00,
  `formal` int(1) DEFAULT 1,
  `minium_purchase` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblloy_mbs_program`
--

LOCK TABLES `tblloy_mbs_program` WRITE;
/*!40000 ALTER TABLE `tblloy_mbs_program` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblloy_mbs_program` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblloy_mbs_rule`
--

DROP TABLE IF EXISTS `tblloy_mbs_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblloy_mbs_rule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `add_from` int(11) NOT NULL,
  `date_create` date DEFAULT NULL,
  `client_group` int(11) DEFAULT NULL,
  `client` text NOT NULL,
  `loyalty_point_from` decimal(15,0) DEFAULT NULL,
  `loyalty_point_to` decimal(15,0) DEFAULT NULL,
  `card` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblloy_mbs_rule`
--

LOCK TABLES `tblloy_mbs_rule` WRITE;
/*!40000 ALTER TABLE `tblloy_mbs_rule` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblloy_mbs_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblloy_program_detail`
--

DROP TABLE IF EXISTS `tblloy_program_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblloy_program_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mbs_program` int(11) NOT NULL,
  `rel_type` varchar(30) NOT NULL,
  `rel_id` text NOT NULL,
  `percent` int(5) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblloy_program_detail`
--

LOCK TABLES `tblloy_program_detail` WRITE;
/*!40000 ALTER TABLE `tblloy_program_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblloy_program_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblloy_redeem_log`
--

DROP TABLE IF EXISTS `tblloy_redeem_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblloy_redeem_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client` int(11) NOT NULL,
  `cart` int(11) DEFAULT NULL,
  `invoice` int(11) DEFAULT NULL,
  `time` datetime DEFAULT NULL,
  `old_point` decimal(10,0) DEFAULT NULL,
  `new_point` decimal(10,0) DEFAULT NULL,
  `redeep_from` decimal(10,0) DEFAULT NULL,
  `redeep_to` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblloy_redeem_log`
--

LOCK TABLES `tblloy_redeem_log` WRITE;
/*!40000 ALTER TABLE `tblloy_redeem_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblloy_redeem_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblloy_redemp_detail`
--

DROP TABLE IF EXISTS `tblloy_redemp_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblloy_redemp_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `loy_rule` int(11) NOT NULL,
  `rule_name` varchar(200) NOT NULL,
  `point_from` decimal(15,0) DEFAULT NULL,
  `point_to` decimal(15,0) DEFAULT NULL,
  `point_weight` decimal(15,2) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblloy_redemp_detail`
--

LOCK TABLES `tblloy_redemp_detail` WRITE;
/*!40000 ALTER TABLE `tblloy_redemp_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblloy_redemp_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblloy_rule`
--

DROP TABLE IF EXISTS `tblloy_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblloy_rule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(200) NOT NULL,
  `add_from` int(11) NOT NULL,
  `date_create` date DEFAULT NULL,
  `enable` int(2) DEFAULT 0,
  `redeemp_type` varchar(15) DEFAULT NULL,
  `min_poin_to_redeem` decimal(15,0) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `rule_base` varchar(30) DEFAULT NULL,
  `minium_purchase` decimal(15,0) DEFAULT NULL,
  `poin_awarded` decimal(15,0) DEFAULT NULL,
  `purchase_value` decimal(15,0) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `redeem_portal` int(1) DEFAULT 0,
  `redeem_pos` int(1) DEFAULT 0,
  `client_group` int(11) DEFAULT 0,
  `client` text NOT NULL,
  `max_amount_received` int(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblloy_rule`
--

LOCK TABLES `tblloy_rule` WRITE;
/*!40000 ALTER TABLE `tblloy_rule` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblloy_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblloy_rule_detail`
--

DROP TABLE IF EXISTS `tblloy_rule_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblloy_rule_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `loy_rule` int(11) NOT NULL,
  `rel_type` varchar(30) NOT NULL,
  `rel_id` text NOT NULL,
  `loyalty_point` decimal(15,0) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblloy_rule_detail`
--

LOCK TABLES `tblloy_rule_detail` WRITE;
/*!40000 ALTER TABLE `tblloy_rule_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblloy_rule_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblloy_transation`
--

DROP TABLE IF EXISTS `tblloy_transation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblloy_transation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference` varchar(30) NOT NULL,
  `invoice` int(11) DEFAULT NULL,
  `client` int(11) NOT NULL,
  `add_from` int(11) DEFAULT NULL,
  `date_create` datetime DEFAULT NULL,
  `loyalty_point` decimal(15,0) DEFAULT NULL,
  `type` varchar(30) DEFAULT NULL,
  `note` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblloy_transation`
--

LOCK TABLES `tblloy_transation` WRITE;
/*!40000 ALTER TABLE `tblloy_transation` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblloy_transation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmail_attachment`
--

DROP TABLE IF EXISTS `tblmail_attachment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblmail_attachment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `mail_id` int(11) NOT NULL,
  `file_name` varchar(191) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `file_type` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(45) NOT NULL DEFAULT 'inbox',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmail_attachment`
--

LOCK TABLES `tblmail_attachment` WRITE;
/*!40000 ALTER TABLE `tblmail_attachment` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblmail_attachment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmail_inbox`
--

DROP TABLE IF EXISTS `tblmail_inbox`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblmail_inbox` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `from_staff_id` int(11) NOT NULL DEFAULT 0,
  `to_staff_id` int(11) NOT NULL DEFAULT 0,
  `to` varchar(500) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `cc` varchar(500) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `bcc` varchar(500) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `sender_name` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `subject` mediumtext CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `body` mediumtext CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `has_attachment` tinyint(1) NOT NULL DEFAULT 0,
  `date_received` datetime NOT NULL,
  `read` tinyint(1) NOT NULL DEFAULT 0,
  `folder` varchar(45) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'inbox',
  `stared` tinyint(1) NOT NULL DEFAULT 0,
  `important` tinyint(1) NOT NULL DEFAULT 0,
  `trash` tinyint(1) NOT NULL DEFAULT 0,
  `from_email` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmail_inbox`
--

LOCK TABLES `tblmail_inbox` WRITE;
/*!40000 ALTER TABLE `tblmail_inbox` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblmail_inbox` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmail_outbox`
--

DROP TABLE IF EXISTS `tblmail_outbox`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblmail_outbox` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sender_staff_id` int(11) NOT NULL DEFAULT 0,
  `to` varchar(500) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `cc` varchar(500) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `bcc` varchar(500) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `sender_name` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `subject` mediumtext CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `body` mediumtext CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `has_attachment` tinyint(1) NOT NULL DEFAULT 0,
  `date_sent` datetime NOT NULL,
  `stared` tinyint(1) NOT NULL DEFAULT 0,
  `important` tinyint(1) NOT NULL DEFAULT 0,
  `trash` tinyint(1) NOT NULL DEFAULT 0,
  `reply_from_id` int(11) DEFAULT NULL,
  `reply_type` varchar(45) NOT NULL DEFAULT 'inbox',
  `draft` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmail_outbox`
--

LOCK TABLES `tblmail_outbox` WRITE;
/*!40000 ALTER TABLE `tblmail_outbox` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblmail_outbox` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmail_queue`
--

DROP TABLE IF EXISTS `tblmail_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblmail_queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `engine` varchar(40) DEFAULT NULL,
  `email` varchar(191) NOT NULL,
  `cc` mediumtext DEFAULT NULL,
  `bcc` mediumtext DEFAULT NULL,
  `message` longtext NOT NULL,
  `alt_message` longtext DEFAULT NULL,
  `status` enum('pending','sending','sent','failed') DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `headers` mediumtext DEFAULT NULL,
  `attachments` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmail_queue`
--

LOCK TABLES `tblmail_queue` WRITE;
/*!40000 ALTER TABLE `tblmail_queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblmail_queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmanage_leave`
--

DROP TABLE IF EXISTS `tblmanage_leave`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblmanage_leave` (
  `leave_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_staff` int(11) NOT NULL,
  `leave_date` int(11) DEFAULT NULL,
  `leave_year` int(11) DEFAULT NULL,
  `accumulated_leave` int(11) DEFAULT NULL,
  `seniority_leave` int(11) DEFAULT NULL,
  `borrow_leave` int(11) DEFAULT NULL,
  `actual_leave` int(11) DEFAULT NULL,
  `expected_leave` int(11) DEFAULT NULL,
  PRIMARY KEY (`leave_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmanage_leave`
--

LOCK TABLES `tblmanage_leave` WRITE;
/*!40000 ALTER TABLE `tblmanage_leave` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblmanage_leave` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmigrations`
--

DROP TABLE IF EXISTS `tblmigrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblmigrations` (
  `version` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmigrations`
--

LOCK TABLES `tblmigrations` WRITE;
/*!40000 ALTER TABLE `tblmigrations` DISABLE KEYS */;
INSERT INTO `tblmigrations` VALUES (310);
/*!40000 ALTER TABLE `tblmigrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmilestones`
--

DROP TABLE IF EXISTS `tblmilestones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblmilestones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `description_visible_to_customer` tinyint(1) DEFAULT 0,
  `start_date` date DEFAULT NULL,
  `due_date` date NOT NULL,
  `project_id` int(11) NOT NULL,
  `color` varchar(10) DEFAULT NULL,
  `milestone_order` int(11) NOT NULL DEFAULT 0,
  `datecreated` date NOT NULL,
  `hide_from_customer` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmilestones`
--

LOCK TABLES `tblmilestones` WRITE;
/*!40000 ALTER TABLE `tblmilestones` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblmilestones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmo_scrap`
--

DROP TABLE IF EXISTS `tblmo_scrap`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblmo_scrap` (
  `ScrapID` int(11) NOT NULL,
  `manufacturing_order_id` int(11) NOT NULL,
  `work_order_id` int(11) DEFAULT NULL,
  `product_id` int(255) NOT NULL,
  `item_type` int(11) NOT NULL,
  `unit_id` int(255) NOT NULL,
  `scrap_type` enum('reuse','waste') NOT NULL DEFAULT 'waste',
  `scrap_source` enum('bom','routing','work_order','manual') NOT NULL DEFAULT 'manual',
  `expected_scrap_percentage` decimal(5,2) DEFAULT NULL,
  `estimated_quantity` decimal(10,2) DEFAULT NULL,
  `actual_quantity` decimal(10,2) NOT NULL,
  `scrap_value` decimal(10,2) DEFAULT NULL,
  `cost_allocation` decimal(10,2) DEFAULT NULL,
  `oee_impact` decimal(5,2) DEFAULT NULL,
  `scrap_status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `scrap_location_id` int(11) DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `bill_of_material_id` int(11) NOT NULL,
  `routing_id` int(11) NOT NULL,
  `operation_id` int(11) NOT NULL,
  `bill_of_material_product_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmo_scrap`
--

LOCK TABLES `tblmo_scrap` WRITE;
/*!40000 ALTER TABLE `tblmo_scrap` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblmo_scrap` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmodules`
--

DROP TABLE IF EXISTS `tblmodules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblmodules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module_name` varchar(55) NOT NULL,
  `installed_version` varchar(11) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmodules`
--

LOCK TABLES `tblmodules` WRITE;
/*!40000 ALTER TABLE `tblmodules` DISABLE KEYS */;
INSERT INTO `tblmodules` VALUES (1,'hr_payroll','1.0.9',1),(2,'manufacturing','1.0.5',1),(3,'hr_profile','1.0.9',1),(4,'account_planning','1.0.0',1),(5,'mailbox','2.0.1',1),(6,'timesheets','1.1.9',1),(7,'accounting','1.3.4',1),(8,'user_mention','1.0.2',1),(9,'affiliate_management','1.0.6',1),(10,'loyalty','1.0.0',1),(11,'warehouse','1.3.9',1),(12,'resource_workload','1.0.7',1),(13,'menu_setup','2.3.0',1),(14,'perfex_saas','0.3.3',1),(15,'perfex_office_theme','1.2.6',1),(16,'purchase','1.5.0',1),(17,'whatsapp_api','1.2.1',1),(18,'razorpay','2.3.0',1),(19,'recruitment','1.2.3',1),(20,'flexibackup','1.0.1',1);
/*!40000 ALTER TABLE `tblmodules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmrp_bill_of_material_details`
--

DROP TABLE IF EXISTS `tblmrp_bill_of_material_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblmrp_bill_of_material_details` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `bill_of_material_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL COMMENT 'Only Product variant do not get parent Product',
  `product_qty` decimal(15,2) DEFAULT 0.00,
  `unit_id` int(11) DEFAULT NULL,
  `apply_on_variants` text DEFAULT NULL,
  `operation_id` int(11) DEFAULT NULL,
  `display_order` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmrp_bill_of_material_details`
--

LOCK TABLES `tblmrp_bill_of_material_details` WRITE;
/*!40000 ALTER TABLE `tblmrp_bill_of_material_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblmrp_bill_of_material_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmrp_bill_of_materials`
--

DROP TABLE IF EXISTS `tblmrp_bill_of_materials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblmrp_bill_of_materials` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `bom_code` varchar(100) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `product_variant_id` int(11) DEFAULT NULL,
  `product_qty` decimal(15,2) DEFAULT 0.00,
  `unit_id` int(11) DEFAULT NULL,
  `routing_id` int(11) DEFAULT NULL,
  `bom_type` varchar(100) DEFAULT NULL,
  `ready_to_produce` varchar(200) DEFAULT NULL,
  `consumption` varchar(200) DEFAULT NULL,
  `labour_charges` decimal(10,2) DEFAULT NULL,
  `machinery_charges` decimal(10,2) DEFAULT NULL,
  `electricity_charges` decimal(10,2) DEFAULT NULL,
  `other_charges` decimal(10,2) DEFAULT NULL,
  `labour_charges_description` text DEFAULT NULL,
  `machinery_charges_description` text DEFAULT NULL,
  `electricity_charges_description` text DEFAULT NULL,
  `other_charges_description` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmrp_bill_of_materials`
--

LOCK TABLES `tblmrp_bill_of_materials` WRITE;
/*!40000 ALTER TABLE `tblmrp_bill_of_materials` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblmrp_bill_of_materials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmrp_bom_changes_logs`
--

DROP TABLE IF EXISTS `tblmrp_bom_changes_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblmrp_bom_changes_logs` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `manufacturing_order_id` int(11) DEFAULT NULL,
  `parent_product_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `unit_id` int(11) DEFAULT 0,
  `change_type` text DEFAULT NULL,
  `change_quantity` decimal(15,2) DEFAULT 0.00,
  `created_at` datetime DEFAULT NULL,
  `staff_id` int(11) DEFAULT 0,
  `description` text DEFAULT NULL,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` text DEFAULT NULL COMMENT 'receipt_note, delivery_note',
  `check_availability` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmrp_bom_changes_logs`
--

LOCK TABLES `tblmrp_bom_changes_logs` WRITE;
/*!40000 ALTER TABLE `tblmrp_bom_changes_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblmrp_bom_changes_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmrp_manufacturing_order_details`
--

DROP TABLE IF EXISTS `tblmrp_manufacturing_order_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblmrp_manufacturing_order_details` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `manufacturing_order_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `unit_id` int(11) DEFAULT NULL,
  `qty_to_consume` decimal(15,2) DEFAULT 0.00,
  `qty_reserved` decimal(15,2) DEFAULT 0.00,
  `qty_done` decimal(15,2) DEFAULT 0.00,
  `check_inventory_qty` varchar(10) DEFAULT NULL,
  `warehouse_id` text DEFAULT NULL,
  `lot_number` text DEFAULT NULL,
  `expiry_date` text DEFAULT NULL,
  `available_quantity` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmrp_manufacturing_order_details`
--

LOCK TABLES `tblmrp_manufacturing_order_details` WRITE;
/*!40000 ALTER TABLE `tblmrp_manufacturing_order_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblmrp_manufacturing_order_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmrp_manufacturing_orders`
--

DROP TABLE IF EXISTS `tblmrp_manufacturing_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblmrp_manufacturing_orders` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `manufacturing_order_code` varchar(100) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL COMMENT 'Only Product variant do not get parent Product',
  `product_qty` decimal(15,2) DEFAULT 0.00,
  `unit_id` int(11) DEFAULT NULL,
  `bom_id` int(11) DEFAULT NULL,
  `routing_id` int(11) DEFAULT NULL,
  `date_deadline` datetime DEFAULT NULL,
  `date_plan_from` datetime DEFAULT NULL,
  `date_planned_start` datetime DEFAULT NULL,
  `date_planned_finished` datetime DEFAULT NULL,
  `status` varchar(100) DEFAULT 'draft',
  `material_availability_status` varchar(100) DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `components_warehouse_id` text DEFAULT NULL,
  `finished_products_warehouse_id` text DEFAULT NULL,
  `purchase_request_id` int(11) DEFAULT NULL,
  `contact_id` int(11) DEFAULT NULL,
  `labour_charges` decimal(10,2) DEFAULT NULL,
  `machinery_charges` decimal(10,2) DEFAULT NULL,
  `electricity_charges` decimal(10,2) DEFAULT NULL,
  `other_charges` decimal(10,2) DEFAULT NULL,
  `labour_charges_description` text DEFAULT NULL,
  `machinery_charges_description` text DEFAULT NULL,
  `electricity_charges_description` text DEFAULT NULL,
  `other_charges_description` text DEFAULT NULL,
  `expected_labour_charges` decimal(10,2) DEFAULT NULL,
  `expected_machinery_charges` decimal(10,2) DEFAULT NULL,
  `expected_electricity_charges` decimal(10,2) DEFAULT NULL,
  `expected_other_charges` decimal(10,2) DEFAULT NULL,
  `estimate_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmrp_manufacturing_orders`
--

LOCK TABLES `tblmrp_manufacturing_orders` WRITE;
/*!40000 ALTER TABLE `tblmrp_manufacturing_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblmrp_manufacturing_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmrp_option`
--

DROP TABLE IF EXISTS `tblmrp_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblmrp_option` (
  `option_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(200) NOT NULL,
  `option_val` longtext DEFAULT NULL,
  `auto` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`option_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmrp_option`
--

LOCK TABLES `tblmrp_option` WRITE;
/*!40000 ALTER TABLE `tblmrp_option` DISABLE KEYS */;
INSERT INTO `tblmrp_option` VALUES (1,'bom_prefix','#BOM_',1),(2,'bom_number','1',1),(3,'routing_prefix','#RO_',1),(4,'routing_number','1',1),(5,'mo_prefix','#MO_',1),(6,'mo_number','1',1),(7,'cost_hour','0',1);
/*!40000 ALTER TABLE `tblmrp_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmrp_routing_details`
--

DROP TABLE IF EXISTS `tblmrp_routing_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblmrp_routing_details` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `routing_id` int(11) NOT NULL,
  `operation` varchar(200) DEFAULT NULL,
  `work_center_id` int(11) DEFAULT NULL,
  `duration_computation` varchar(200) DEFAULT NULL,
  `based_on` decimal(15,2) DEFAULT 0.00,
  `default_duration` decimal(15,2) DEFAULT 0.00,
  `start_next_operation` varchar(200) DEFAULT NULL,
  `quantity_process` decimal(15,2) DEFAULT 0.00,
  `description` text DEFAULT NULL,
  `display_order` decimal(15,2) DEFAULT 0.00,
  `staff_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmrp_routing_details`
--

LOCK TABLES `tblmrp_routing_details` WRITE;
/*!40000 ALTER TABLE `tblmrp_routing_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblmrp_routing_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmrp_routings`
--

DROP TABLE IF EXISTS `tblmrp_routings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblmrp_routings` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `routing_code` varchar(200) DEFAULT NULL,
  `routing_name` varchar(200) DEFAULT NULL,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmrp_routings`
--

LOCK TABLES `tblmrp_routings` WRITE;
/*!40000 ALTER TABLE `tblmrp_routings` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblmrp_routings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmrp_scrap`
--

DROP TABLE IF EXISTS `tblmrp_scrap`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblmrp_scrap` (
  `ScrapID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `manufacturing_order_id` int(11) NOT NULL,
  `product_id` int(255) NOT NULL,
  `unit_id` int(255) NOT NULL,
  `scrap_type` enum('component','finished_good') NOT NULL,
  `estimated_quantity` decimal(10,2) DEFAULT NULL,
  `actual_quantity` decimal(10,2) NOT NULL,
  `cost_allocation` decimal(10,2) DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`ScrapID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmrp_scrap`
--

LOCK TABLES `tblmrp_scrap` WRITE;
/*!40000 ALTER TABLE `tblmrp_scrap` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblmrp_scrap` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmrp_unit_measure_categories`
--

DROP TABLE IF EXISTS `tblmrp_unit_measure_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblmrp_unit_measure_categories` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `category_name` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmrp_unit_measure_categories`
--

LOCK TABLES `tblmrp_unit_measure_categories` WRITE;
/*!40000 ALTER TABLE `tblmrp_unit_measure_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblmrp_unit_measure_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmrp_work_centers`
--

DROP TABLE IF EXISTS `tblmrp_work_centers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblmrp_work_centers` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `work_center_name` varchar(200) DEFAULT NULL,
  `work_center_code` varchar(200) DEFAULT NULL,
  `working_hours` varchar(200) DEFAULT NULL,
  `time_efficiency` decimal(15,2) DEFAULT 0.00,
  `capacity` decimal(15,2) DEFAULT 0.00,
  `oee_target` decimal(15,2) DEFAULT 0.00,
  `time_start` decimal(15,2) DEFAULT 0.00,
  `time_stop` decimal(15,2) DEFAULT 0.00,
  `costs_hour` decimal(15,2) DEFAULT 0.00,
  `description` text DEFAULT NULL,
  `is_subcontract` tinyint(1) DEFAULT 0,
  `subcontractor_id` int(11) DEFAULT NULL,
  `vendor_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmrp_work_centers`
--

LOCK TABLES `tblmrp_work_centers` WRITE;
/*!40000 ALTER TABLE `tblmrp_work_centers` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblmrp_work_centers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmrp_work_order_details`
--

DROP TABLE IF EXISTS `tblmrp_work_order_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblmrp_work_order_details` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `work_order_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `to_consume` decimal(15,2) DEFAULT 0.00,
  `reserved` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmrp_work_order_details`
--

LOCK TABLES `tblmrp_work_order_details` WRITE;
/*!40000 ALTER TABLE `tblmrp_work_order_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblmrp_work_order_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmrp_work_order_time_trackings`
--

DROP TABLE IF EXISTS `tblmrp_work_order_time_trackings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblmrp_work_order_time_trackings` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `work_order_id` int(11) NOT NULL,
  `from_date` datetime DEFAULT NULL,
  `to_date` datetime DEFAULT NULL,
  `duration` decimal(15,2) DEFAULT 0.00,
  `staff_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmrp_work_order_time_trackings`
--

LOCK TABLES `tblmrp_work_order_time_trackings` WRITE;
/*!40000 ALTER TABLE `tblmrp_work_order_time_trackings` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblmrp_work_order_time_trackings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmrp_work_orders`
--

DROP TABLE IF EXISTS `tblmrp_work_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblmrp_work_orders` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `manufacturing_order_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `qty_produced` decimal(15,2) DEFAULT 0.00,
  `qty_production` decimal(15,2) DEFAULT 0.00,
  `qty_producing` decimal(15,2) DEFAULT 0.00,
  `unit_id` int(11) DEFAULT NULL,
  `routing_detail_id` int(11) DEFAULT NULL,
  `operation_name` text DEFAULT NULL,
  `work_center_id` int(11) DEFAULT NULL,
  `date_planned_start` datetime DEFAULT NULL,
  `date_planned_finished` datetime DEFAULT NULL,
  `date_start` datetime DEFAULT NULL,
  `date_finished` datetime DEFAULT NULL,
  `duration_expected` decimal(15,2) DEFAULT 0.00,
  `real_duration` decimal(15,2) DEFAULT 0.00,
  `status` varchar(100) DEFAULT NULL,
  `is_subcontract` tinyint(1) DEFAULT 0,
  `subcontractor_id` int(11) DEFAULT NULL,
  `subcontractor_name` varchar(255) DEFAULT NULL,
  `expected_delivery_date` date DEFAULT NULL,
  `subcontract_notes` text DEFAULT NULL,
  `subcontract_status` varchar(50) DEFAULT 'pending',
  `staff_id` int(11) DEFAULT NULL,
  `contact_id` int(11) DEFAULT NULL,
  `labour_charges` decimal(10,2) DEFAULT NULL,
  `machinery_charges` decimal(10,2) DEFAULT NULL,
  `electricity_charges` decimal(10,2) DEFAULT NULL,
  `other_charges` decimal(10,2) DEFAULT NULL,
  `labour_charges_description` text DEFAULT NULL,
  `machinery_charges_description` text DEFAULT NULL,
  `electricity_charges_description` text DEFAULT NULL,
  `other_charges_description` text DEFAULT NULL,
  `expected_labour_charges` decimal(10,2) DEFAULT NULL,
  `expected_machinery_charges` decimal(10,2) DEFAULT NULL,
  `expected_electricity_charges` decimal(10,2) DEFAULT NULL,
  `expected_other_charges` decimal(10,2) DEFAULT NULL,
  `estimate_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmrp_work_orders`
--

LOCK TABLES `tblmrp_work_orders` WRITE;
/*!40000 ALTER TABLE `tblmrp_work_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblmrp_work_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmrp_working_hour_time_off`
--

DROP TABLE IF EXISTS `tblmrp_working_hour_time_off`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblmrp_working_hour_time_off` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `working_hour_id` int(11) NOT NULL,
  `reason` varchar(200) DEFAULT NULL,
  `starting_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmrp_working_hour_time_off`
--

LOCK TABLES `tblmrp_working_hour_time_off` WRITE;
/*!40000 ALTER TABLE `tblmrp_working_hour_time_off` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblmrp_working_hour_time_off` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmrp_working_hour_times`
--

DROP TABLE IF EXISTS `tblmrp_working_hour_times`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblmrp_working_hour_times` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `working_hour_id` int(11) NOT NULL,
  `working_hour_name` varchar(200) DEFAULT NULL,
  `day_of_week` varchar(100) DEFAULT NULL,
  `day_period` varchar(100) DEFAULT NULL,
  `work_from` time DEFAULT NULL,
  `work_to` time DEFAULT NULL,
  `starting_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmrp_working_hour_times`
--

LOCK TABLES `tblmrp_working_hour_times` WRITE;
/*!40000 ALTER TABLE `tblmrp_working_hour_times` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblmrp_working_hour_times` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmrp_working_hours`
--

DROP TABLE IF EXISTS `tblmrp_working_hours`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblmrp_working_hours` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `working_hour_name` varchar(200) DEFAULT NULL,
  `hours_per_day` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmrp_working_hours`
--

LOCK TABLES `tblmrp_working_hours` WRITE;
/*!40000 ALTER TABLE `tblmrp_working_hours` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblmrp_working_hours` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblnewsfeed_comment_likes`
--

DROP TABLE IF EXISTS `tblnewsfeed_comment_likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblnewsfeed_comment_likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `postid` int(11) NOT NULL,
  `commentid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `dateliked` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblnewsfeed_comment_likes`
--

LOCK TABLES `tblnewsfeed_comment_likes` WRITE;
/*!40000 ALTER TABLE `tblnewsfeed_comment_likes` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblnewsfeed_comment_likes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblnewsfeed_post_comments`
--

DROP TABLE IF EXISTS `tblnewsfeed_post_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblnewsfeed_post_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` mediumtext DEFAULT NULL,
  `userid` int(11) NOT NULL,
  `postid` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblnewsfeed_post_comments`
--

LOCK TABLES `tblnewsfeed_post_comments` WRITE;
/*!40000 ALTER TABLE `tblnewsfeed_post_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblnewsfeed_post_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblnewsfeed_post_likes`
--

DROP TABLE IF EXISTS `tblnewsfeed_post_likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblnewsfeed_post_likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `postid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `dateliked` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblnewsfeed_post_likes`
--

LOCK TABLES `tblnewsfeed_post_likes` WRITE;
/*!40000 ALTER TABLE `tblnewsfeed_post_likes` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblnewsfeed_post_likes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblnewsfeed_posts`
--

DROP TABLE IF EXISTS `tblnewsfeed_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblnewsfeed_posts` (
  `postid` int(11) NOT NULL AUTO_INCREMENT,
  `creator` int(11) NOT NULL,
  `datecreated` datetime NOT NULL,
  `visibility` varchar(100) NOT NULL,
  `content` mediumtext NOT NULL,
  `pinned` int(11) NOT NULL,
  `datepinned` datetime DEFAULT NULL,
  PRIMARY KEY (`postid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblnewsfeed_posts`
--

LOCK TABLES `tblnewsfeed_posts` WRITE;
/*!40000 ALTER TABLE `tblnewsfeed_posts` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblnewsfeed_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblnotes`
--

DROP TABLE IF EXISTS `tblnotes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblnotes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `date_contacted` datetime DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblnotes`
--

LOCK TABLES `tblnotes` WRITE;
/*!40000 ALTER TABLE `tblnotes` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblnotes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblnotifications`
--

DROP TABLE IF EXISTS `tblnotifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblnotifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `isread` int(11) NOT NULL DEFAULT 0,
  `isread_inline` tinyint(1) NOT NULL DEFAULT 0,
  `date` datetime NOT NULL,
  `description` mediumtext NOT NULL,
  `fromuserid` int(11) NOT NULL,
  `fromclientid` int(11) NOT NULL DEFAULT 0,
  `from_fullname` varchar(100) NOT NULL,
  `touserid` int(11) NOT NULL,
  `fromcompany` int(11) DEFAULT NULL,
  `link` longtext DEFAULT NULL,
  `additional_data` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblnotifications`
--

LOCK TABLES `tblnotifications` WRITE;
/*!40000 ALTER TABLE `tblnotifications` DISABLE KEYS */;
INSERT INTO `tblnotifications` VALUES (1,1,0,'2025-06-26 07:01:51','perfex_saas_not_customer_create_instance',0,1,'Dayanand yadav',1,NULL,'clients/client/1','a:1:{i:0;s:6:\"FECUNI\";}'),(2,1,0,'2025-06-27 10:57:12','perfex_saas_not_customer_create_instance',0,2,'Dayanand Sweden',1,NULL,'clients/client/2','a:1:{i:0;s:32:\"Minera software Solution ,Sweden\";}'),(3,1,0,'2025-06-27 11:59:33','perfex_saas_not_customer_create_instance',0,3,'Dayanand yadav',1,NULL,'clients/client/3','a:1:{i:0;s:10:\"INDIA TECH\";}'),(4,1,0,'2025-06-27 13:12:22','perfex_saas_not_customer_create_instance',0,4,'Dayanand yadav',1,NULL,'clients/client/4','a:1:{i:0;s:4:\"Audi\";}'),(5,1,0,'2025-07-01 17:29:51','perfex_saas_not_customer_create_instance',0,5,'Vishal Shankar',1,NULL,'clients/client/5','a:1:{i:0;s:4:\"tata\";}'),(6,1,0,'2025-07-06 20:17:56','perfex_saas_not_customer_create_instance',0,6,'Deepanshu Sharma',1,NULL,'clients/client/6','a:1:{i:0;s:12:\"Techdotbit45\";}'),(7,1,0,'2025-07-06 20:22:36','perfex_saas_not_customer_create_instance_failed',1,0,'Vikas Yadav',1,NULL,'clients/client/5','a:2:{i:0;s:4:\"tata\";i:1;s:30:\"Error finding valid datacenter\";}'),(8,1,0,'2025-07-06 20:22:43','perfex_saas_not_customer_create_instance_failed',1,0,'Vikas Yadav',1,NULL,'clients/client/4','a:2:{i:0;s:4:\"Audi\";i:1;s:30:\"Error finding valid datacenter\";}'),(9,1,0,'2025-07-06 20:22:49','perfex_saas_not_customer_create_instance_failed',1,0,'Vikas Yadav',1,NULL,'clients/client/1','a:2:{i:0;s:6:\"FECUNI\";i:1;s:30:\"Error finding valid datacenter\";}'),(10,1,0,'2025-07-06 20:22:52','perfex_saas_not_customer_create_instance_failed',1,0,'Vikas Yadav',1,NULL,'clients/client/2','a:2:{i:0;s:32:\"Minera software Solution ,Sweden\";i:1;s:30:\"Error finding valid datacenter\";}'),(11,1,0,'2025-07-06 20:22:57','perfex_saas_not_customer_create_instance_failed',1,0,'Vikas Yadav',1,NULL,'clients/client/3','a:2:{i:0;s:10:\"INDIA TECH\";i:1;s:30:\"Error finding valid datacenter\";}'),(12,1,0,'2025-07-06 23:12:36','perfex_saas_not_customer_create_instance',0,7,'Vikas Yadav',1,NULL,'clients/client/7','a:1:{i:0;s:3:\"DAC\";}'),(13,1,0,'2025-07-06 23:27:49','perfex_saas_not_customer_create_instance',0,8,'Sahil Oswal',1,NULL,'clients/client/8','a:1:{i:0;s:3:\"HCL\";}'),(14,1,0,'2025-07-06 23:57:41','perfex_saas_not_customer_create_instance',0,9,'3456765 yadav',1,NULL,'clients/client/9','a:1:{i:0;s:3:\"szw\";}'),(15,1,0,'2025-07-07 16:11:47','perfex_saas_not_customer_create_instance',0,10,'Deepanshu Sharma',1,NULL,'clients/client/10','a:1:{i:0;s:4:\"demo\";}'),(16,1,0,'2025-07-07 18:06:21','perfex_saas_not_customer_create_instance',0,11,'faizan ahmad',1,NULL,'clients/client/11','a:1:{i:0;s:31:\"splice laminate private limited\";}'),(17,1,0,'2025-07-08 00:24:12','perfex_saas_not_customer_create_instance',0,12,'Sahil Oswal',1,NULL,'clients/client/12','a:1:{i:0;s:4:\"ABCD\";}'),(18,1,0,'2025-07-08 09:59:53','perfex_saas_not_customer_instance_removed',1,0,'Vikas Yadav',1,NULL,'clients/client/9','a:1:{i:0;s:3:\"szw\";}'),(19,1,0,'2025-07-08 10:00:05','perfex_saas_not_customer_instance_removed',1,0,'Vikas Yadav',1,NULL,'clients/client/6','a:1:{i:0;s:12:\"Techdotbit45\";}'),(20,1,0,'2025-07-08 10:00:12','perfex_saas_not_customer_instance_removed',1,0,'Vikas Yadav',1,NULL,'clients/client/7','a:1:{i:0;s:3:\"DAC\";}'),(21,1,0,'2025-07-08 10:00:18','perfex_saas_not_customer_instance_removed',1,0,'Vikas Yadav',1,NULL,'clients/client/8','a:1:{i:0;s:3:\"HCL\";}'),(22,1,0,'2025-07-08 10:27:11','not_customer_viewed_invoice',0,0,'',1,1,'invoices/list_invoices/3','a:1:{i:0;s:10:\"INV-000001\";}'),(23,1,0,'2025-07-08 14:14:44','perfex_saas_not_customer_instance_removed',1,0,'Vikas Yadav',1,NULL,'clients/client/12','a:1:{i:0;s:4:\"ABCD\";}');
/*!40000 ALTER TABLE `tblnotifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbloptions`
--

DROP TABLE IF EXISTS `tbloptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbloptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `value` longtext NOT NULL,
  `autoload` tinyint(1) NOT NULL DEFAULT 1,
  `annual_turnover` decimal(15,2) DEFAULT 0.00 COMMENT 'Yearly turnover (₹) as declared by admin or fetched from GSTR-3B',
  `einvoice_enabled` tinyint(1) DEFAULT 0 COMMENT 'True/False – whether E-Invoicing is enabled for this company',
  `einvoice_enforced` tinyint(1) DEFAULT 0 COMMENT 'True if system decides it must be enabled (auto based on turnover)',
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=799 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbloptions`
--

LOCK TABLES `tbloptions` WRITE;
/*!40000 ALTER TABLE `tbloptions` DISABLE KEYS */;
INSERT INTO `tbloptions` VALUES (1,'dateformat','Y-m-d|%Y-%m-%d',1,0.00,0,0),(2,'companyname','',1,0.00,0,0),(3,'services','1',1,0.00,0,0),(4,'maximum_allowed_ticket_attachments','4',1,0.00,0,0),(5,'ticket_attachments_file_extensions','.jpg,.png,.pdf,.doc,.zip,.rar',1,0.00,0,0),(6,'staff_access_only_assigned_departments','1',1,0.00,0,0),(7,'use_knowledge_base','1',1,0.00,0,0),(8,'smtp_email','noreply@techdotbit.com',1,0.00,0,0),(9,'smtp_password','9806cd6decd82f3c008ea63e6a110b9bf36ee4fe8013b0ebfee71b9489c627c98bd79bd7a486539d584b8faa337ca915c32f8ef0f5e60042980bb73a99e7acdfG4fwpsk2fex2R8qgMK/ZQTCT1heaKKt3jCN5IZ0dWJk=',1,0.00,0,0),(10,'company_info_format','{company_name}<br />\r\n      {address}<br />\r\n      {city} {state}<br />\r\n      {country_code} {zip_code}<br />\r\n      {vat_number_with_label}',0,0.00,0,0),(11,'smtp_port','587',1,0.00,0,0),(12,'smtp_host','smtp.hostinger.com',1,0.00,0,0),(13,'smtp_email_charset','utf-8',1,0.00,0,0),(14,'default_timezone','Asia/Kolkata',1,0.00,0,0),(15,'clients_default_theme','perfex',1,0.00,0,0),(16,'company_logo','',1,0.00,0,0),(17,'tables_pagination_limit','25',1,0.00,0,0),(18,'main_domain','',1,0.00,0,0),(19,'allow_registration','1',1,0.00,0,0),(20,'knowledge_base_without_registration','1',1,0.00,0,0),(21,'email_signature','<br><br>\r\n--<br>\r\n<b>DOT ONE ERP System</b><br>\r\nAutomated Notification Service<br>\r\n📧 no-reply@techdotbit.in<br>\r\n🌐 <a href=\"https://www.techdotbit.in\" target=\"_blank\">www.techdotbit.in</a><br>\r\n<small><i>Please do not reply to this email. For assistance, contact support@techdotbit.com</i></small>',1,0.00,0,0),(22,'default_staff_role','1',1,0.00,0,0),(23,'newsfeed_maximum_files_upload','10',1,0.00,0,0),(24,'contract_expiration_before','4',1,0.00,0,0),(25,'invoice_prefix','INV-',1,0.00,0,0),(26,'decimal_separator','.',1,0.00,0,0),(27,'thousand_separator',',',1,0.00,0,0),(28,'invoice_company_name','',1,0.00,0,0),(29,'invoice_company_address','',1,0.00,0,0),(30,'invoice_company_city','',1,0.00,0,0),(31,'invoice_company_country_code','',1,0.00,0,0),(32,'invoice_company_postal_code','',1,0.00,0,0),(33,'invoice_company_phonenumber','',1,0.00,0,0),(34,'view_invoice_only_logged_in','1',1,0.00,0,0),(35,'invoice_number_format','1',1,0.00,0,0),(36,'next_invoice_number','3',0,0.00,0,0),(37,'active_language','english',1,0.00,0,0),(38,'invoice_number_decrement_on_delete','1',1,0.00,0,0),(39,'automatically_send_invoice_overdue_reminder_after','1',1,0.00,0,0),(40,'automatically_resend_invoice_overdue_reminder_after','3',1,0.00,0,0),(41,'expenses_auto_operations_hour','21',1,0.00,0,0),(42,'delete_only_on_last_invoice','1',1,0.00,0,0),(43,'delete_only_on_last_estimate','1',1,0.00,0,0),(44,'create_invoice_from_recurring_only_on_paid_invoices','0',1,0.00,0,0),(45,'allow_payment_amount_to_be_modified','0',1,0.00,0,0),(46,'rtl_support_client','0',1,0.00,0,0),(47,'limit_top_search_bar_results_to','10',1,0.00,0,0),(48,'estimate_prefix','EST-',1,0.00,0,0),(49,'next_estimate_number','1',0,0.00,0,0),(50,'estimate_number_decrement_on_delete','1',1,0.00,0,0),(51,'estimate_number_format','1',1,0.00,0,0),(52,'estimate_auto_convert_to_invoice_on_client_accept','1',1,0.00,0,0),(53,'exclude_estimate_from_client_area_with_draft_status','1',1,0.00,0,0),(54,'rtl_support_admin','0',1,0.00,0,0),(55,'last_cron_run','1751966762',1,0.00,0,0),(56,'show_sale_agent_on_estimates','1',1,0.00,0,0),(57,'show_sale_agent_on_invoices','1',1,0.00,0,0),(58,'predefined_terms_invoice','',1,0.00,0,0),(59,'predefined_terms_estimate','',1,0.00,0,0),(60,'default_task_priority','2',1,0.00,0,0),(61,'dropbox_app_key','',1,0.00,0,0),(62,'show_expense_reminders_on_calendar','1',1,0.00,0,0),(63,'only_show_contact_tickets','1',1,0.00,0,0),(64,'predefined_clientnote_invoice','',1,0.00,0,0),(65,'predefined_clientnote_estimate','',1,0.00,0,0),(66,'custom_pdf_logo_image_url','',1,0.00,0,0),(67,'favicon','',1,0.00,0,0),(68,'invoice_due_after','30',1,0.00,0,0),(69,'google_api_key','',1,0.00,0,0),(70,'google_calendar_main_calendar','',1,0.00,0,0),(71,'default_tax','a:0:{}',1,0.00,0,0),(72,'show_invoices_on_calendar','1',1,0.00,0,0),(73,'show_estimates_on_calendar','1',1,0.00,0,0),(74,'show_contracts_on_calendar','1',1,0.00,0,0),(75,'show_tasks_on_calendar','1',1,0.00,0,0),(76,'show_customer_reminders_on_calendar','1',1,0.00,0,0),(77,'output_client_pdfs_from_admin_area_in_client_language','0',1,0.00,0,0),(78,'show_lead_reminders_on_calendar','1',1,0.00,0,0),(79,'send_estimate_expiry_reminder_before','4',1,0.00,0,0),(80,'leads_default_source','',1,0.00,0,0),(81,'leads_default_status','',1,0.00,0,0),(82,'proposal_expiry_reminder_enabled','1',1,0.00,0,0),(83,'send_proposal_expiry_reminder_before','4',1,0.00,0,0),(84,'default_contact_permissions','a:8:{i:0;s:1:\"1\";i:1;s:1:\"2\";i:2;s:1:\"3\";i:3;s:1:\"4\";i:4;s:1:\"5\";i:5;s:1:\"6\";i:6;s:6:\"311301\";i:7;s:6:\"311302\";}',1,0.00,0,0),(85,'pdf_logo_width','150',1,0.00,0,0),(86,'access_tickets_to_none_staff_members','0',1,0.00,0,0),(87,'customer_default_country','102',1,0.00,0,0),(88,'view_estimate_only_logged_in','0',1,0.00,0,0),(89,'show_status_on_pdf_ei','1',1,0.00,0,0),(90,'email_piping_only_replies','0',1,0.00,0,0),(91,'email_piping_only_registered','0',1,0.00,0,0),(92,'default_view_calendar','dayGridMonth',1,0.00,0,0),(93,'email_piping_default_priority','2',1,0.00,0,0),(94,'total_to_words_lowercase','0',1,0.00,0,0),(95,'show_tax_per_item','1',1,0.00,0,0),(96,'total_to_words_enabled','0',1,0.00,0,0),(97,'receive_notification_on_new_ticket','1',0,0.00,0,0),(98,'autoclose_tickets_after','0',1,0.00,0,0),(99,'media_max_file_size_upload','10',1,0.00,0,0),(100,'client_staff_add_edit_delete_task_comments_first_hour','0',1,0.00,0,0),(101,'show_projects_on_calendar','1',1,0.00,0,0),(102,'leads_kanban_limit','50',1,0.00,0,0),(103,'tasks_reminder_notification_before','2',1,0.00,0,0),(104,'pdf_font','freesans',1,0.00,0,0),(105,'pdf_table_heading_color','#323a45',1,0.00,0,0),(106,'pdf_table_heading_text_color','#ffffff',1,0.00,0,0),(107,'pdf_font_size','10',1,0.00,0,0),(108,'default_leads_kanban_sort','leadorder',1,0.00,0,0),(109,'default_leads_kanban_sort_type','asc',1,0.00,0,0),(110,'allowed_files','.png,.jpg,.pdf,.doc,.docx,.xls,.xlsx,.zip,.rar,.txt',1,0.00,0,0),(111,'show_all_tasks_for_project_member','1',1,0.00,0,0),(112,'email_protocol','smtp',1,0.00,0,0),(113,'calendar_first_day','0',1,0.00,0,0),(114,'recaptcha_secret_key','',1,0.00,0,0),(115,'show_help_on_setup_menu','1',1,0.00,0,0),(116,'show_proposals_on_calendar','1',1,0.00,0,0),(117,'smtp_encryption','ssl',1,0.00,0,0),(118,'recaptcha_site_key','',1,0.00,0,0),(119,'smtp_username','noreply@techdotbit.com',1,0.00,0,0),(120,'auto_stop_tasks_timers_on_new_timer','1',1,0.00,0,0),(121,'notification_when_customer_pay_invoice','1',1,0.00,0,0),(122,'calendar_invoice_color','#FF6F00',1,0.00,0,0),(123,'calendar_estimate_color','#FF6F00',1,0.00,0,0),(124,'calendar_proposal_color','#84c529',1,0.00,0,0),(125,'new_task_auto_assign_current_member','1',1,0.00,0,0),(126,'calendar_reminder_color','#03A9F4',1,0.00,0,0),(127,'calendar_contract_color','#B72974',1,0.00,0,0),(128,'calendar_project_color','#B72974',1,0.00,0,0),(129,'update_info_message','',1,0.00,0,0),(130,'show_estimate_reminders_on_calendar','1',1,0.00,0,0),(131,'show_invoice_reminders_on_calendar','1',1,0.00,0,0),(132,'show_proposal_reminders_on_calendar','1',1,0.00,0,0),(133,'proposal_due_after','7',1,0.00,0,0),(134,'allow_customer_to_change_ticket_status','0',1,0.00,0,0),(135,'lead_lock_after_convert_to_customer','0',1,0.00,0,0),(136,'default_proposals_pipeline_sort','pipeline_order',1,0.00,0,0),(137,'default_proposals_pipeline_sort_type','asc',1,0.00,0,0),(138,'default_estimates_pipeline_sort','pipeline_order',1,0.00,0,0),(139,'default_estimates_pipeline_sort_type','asc',1,0.00,0,0),(140,'use_recaptcha_customers_area','0',1,0.00,0,0),(141,'remove_decimals_on_zero','0',1,0.00,0,0),(142,'remove_tax_name_from_item_table','0',1,0.00,0,0),(143,'pdf_format_invoice','A4-PORTRAIT',1,0.00,0,0),(144,'pdf_format_estimate','A4-PORTRAIT',1,0.00,0,0),(145,'pdf_format_proposal','A4-PORTRAIT',1,0.00,0,0),(146,'pdf_format_payment','A4-PORTRAIT',1,0.00,0,0),(147,'pdf_format_contract','A4-PORTRAIT',1,0.00,0,0),(148,'swap_pdf_info','0',1,0.00,0,0),(149,'exclude_invoice_from_client_area_with_draft_status','1',1,0.00,0,0),(150,'cron_has_run_from_cli','1',1,0.00,0,0),(151,'hide_cron_is_required_message','0',0,0.00,0,0),(152,'auto_assign_customer_admin_after_lead_convert','1',1,0.00,0,0),(153,'show_transactions_on_invoice_pdf','1',1,0.00,0,0),(154,'show_pay_link_to_invoice_pdf','1',1,0.00,0,0),(155,'tasks_kanban_limit','50',1,0.00,0,0),(156,'purchase_key','',1,0.00,0,0),(157,'estimates_pipeline_limit','50',1,0.00,0,0),(158,'proposals_pipeline_limit','50',1,0.00,0,0),(159,'proposal_number_prefix','PRO-',1,0.00,0,0),(160,'number_padding_prefixes','6',1,0.00,0,0),(161,'show_page_number_on_pdf','0',1,0.00,0,0),(162,'calendar_events_limit','4',1,0.00,0,0),(163,'show_setup_menu_item_only_on_hover','0',1,0.00,0,0),(164,'company_requires_vat_number_field','1',1,0.00,0,0),(165,'company_is_required','1',1,0.00,0,0),(166,'allow_contact_to_delete_files','0',1,0.00,0,0),(167,'company_vat','',1,0.00,0,0),(168,'di','1750847029',1,0.00,0,0),(169,'invoice_auto_operations_hour','21',1,0.00,0,0),(170,'use_minified_files','1',1,0.00,0,0),(171,'only_own_files_contacts','0',1,0.00,0,0),(172,'allow_primary_contact_to_view_edit_billing_and_shipping','0',1,0.00,0,0),(173,'estimate_due_after','7',1,0.00,0,0),(174,'staff_members_open_tickets_to_all_contacts','1',1,0.00,0,0),(175,'time_format','24',1,0.00,0,0),(176,'delete_activity_log_older_then','1',1,0.00,0,0),(177,'disable_language','0',1,0.00,0,0),(178,'company_state','',1,0.00,0,0),(179,'email_header','<!doctype html>\r\n      <html>\r\n      <head>\r\n      <meta name=\"viewport\" content=\"width=device-width\" />\r\n      <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />\r\n      <style>\r\n      body {\r\n        background-color: #f6f6f6;\r\n        font-family: sans-serif;\r\n        -webkit-font-smoothing: antialiased;\r\n        font-size: 14px;\r\n        line-height: 1.4;\r\n        margin: 0;\r\n        padding: 0;\r\n        -ms-text-size-adjust: 100%;\r\n        -webkit-text-size-adjust: 100%;\r\n      }\r\n      table {\r\n        border-collapse: separate;\r\n        mso-table-lspace: 0pt;\r\n        mso-table-rspace: 0pt;\r\n        width: 100%;\r\n      }\r\n      table td {\r\n        font-family: sans-serif;\r\n        font-size: 14px;\r\n        vertical-align: top;\r\n      }\r\n      /* -------------------------------------\r\n      BODY & CONTAINER\r\n      ------------------------------------- */\r\n      .body {\r\n        background-color: #f6f6f6;\r\n        width: 100%;\r\n      }\r\n      /* Set a max-width, and make it display as block so it will automatically stretch to that width, but will also shrink down on a phone or something */\r\n      \r\n      .container {\r\n        display: block;\r\n        margin: 0 auto !important;\r\n        /* makes it centered */\r\n        max-width: 680px;\r\n        padding: 10px;\r\n        width: 680px;\r\n      }\r\n      /* This should also be a block element, so that it will fill 100% of the .container */\r\n      \r\n      .content {\r\n        box-sizing: border-box;\r\n        display: block;\r\n        margin: 0 auto;\r\n        max-width: 680px;\r\n        padding: 10px;\r\n      }\r\n      /* -------------------------------------\r\n      HEADER, FOOTER, MAIN\r\n      ------------------------------------- */\r\n      \r\n      .main {\r\n        background: #fff;\r\n        border-radius: 3px;\r\n        width: 100%;\r\n      }\r\n      .wrapper {\r\n        box-sizing: border-box;\r\n        padding: 20px;\r\n      }\r\n      .footer {\r\n        clear: both;\r\n        padding-top: 10px;\r\n        text-align: center;\r\n        width: 100%;\r\n      }\r\n      .footer td,\r\n      .footer p,\r\n      .footer span,\r\n      .footer a {\r\n        color: #999999;\r\n        font-size: 12px;\r\n        text-align: center;\r\n      }\r\n      hr {\r\n        border: 0;\r\n        border-bottom: 1px solid #f6f6f6;\r\n        margin: 20px 0;\r\n      }\r\n      /* -------------------------------------\r\n      RESPONSIVE AND MOBILE FRIENDLY STYLES\r\n      ------------------------------------- */\r\n      \r\n      @media only screen and (max-width: 620px) {\r\n        table[class=body] .content {\r\n          padding: 0 !important;\r\n        }\r\n        table[class=body] .container {\r\n          padding: 0 !important;\r\n          width: 100% !important;\r\n        }\r\n        table[class=body] .main {\r\n          border-left-width: 0 !important;\r\n          border-radius: 0 !important;\r\n          border-right-width: 0 !important;\r\n        }\r\n      }\r\n      </style>\r\n      </head>\r\n      <body class=\"\">\r\n      <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" class=\"body\">\r\n      <tr>\r\n      <td>&nbsp;</td>\r\n      <td class=\"container\">\r\n      <div class=\"content\">\r\n      <!-- START CENTERED WHITE CONTAINER -->\r\n      <table class=\"main\">\r\n      <!-- START MAIN CONTENT AREA -->\r\n      <tr>\r\n      <td class=\"wrapper\">\r\n      <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\r\n      <tr>\r\n      <td>',1,0.00,0,0),(180,'show_pdf_signature_invoice','1',0,0.00,0,0),(181,'show_pdf_signature_estimate','1',0,0.00,0,0),(182,'signature_image','',0,0.00,0,0),(183,'email_footer','</td>\r\n      </tr>\r\n      </table>\r\n      </td>\r\n      </tr>\r\n      <!-- END MAIN CONTENT AREA -->\r\n      </table>\r\n      <!-- START FOOTER -->\r\n      <div class=\"footer\">\r\n      <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\r\n      <tr>\r\n      <td class=\"content-block\">\r\n      <span>{companyname}</span>\r\n      </td>\r\n      </tr>\r\n      </table>\r\n      </div>\r\n      <!-- END FOOTER -->\r\n      <!-- END CENTERED WHITE CONTAINER -->\r\n      </div>\r\n      </td>\r\n      <td>&nbsp;</td>\r\n      </tr>\r\n      </table>\r\n      </body>\r\n      </html>',1,0.00,0,0),(184,'exclude_proposal_from_client_area_with_draft_status','1',1,0.00,0,0),(185,'pusher_app_key','',1,0.00,0,0),(186,'pusher_app_secret','',1,0.00,0,0),(187,'pusher_app_id','',1,0.00,0,0),(188,'pusher_realtime_notifications','0',1,0.00,0,0),(189,'pdf_format_statement','A4-PORTRAIT',1,0.00,0,0),(190,'pusher_cluster','',1,0.00,0,0),(191,'show_table_export_button','to_all',1,0.00,0,0),(192,'allow_staff_view_proposals_assigned','1',1,0.00,0,0),(193,'show_cloudflare_notice','1',0,0.00,0,0),(194,'task_modal_class','modal-lg',1,0.00,0,0),(195,'lead_modal_class','modal-lg',1,0.00,0,0),(196,'show_timesheets_overview_all_members_notice_admins','0',1,0.00,0,0),(197,'desktop_notifications','0',1,0.00,0,0),(198,'hide_notified_reminders_from_calendar','1',0,0.00,0,0),(199,'customer_info_format','{company_name}<br />\r\n      {street}<br />\r\n      {city} {state}<br />\r\n      {country_code} {zip_code}<br />\r\n      {vat_number_with_label}',0,0.00,0,0),(200,'timer_started_change_status_in_progress','1',0,0.00,0,0),(201,'default_ticket_reply_status','3',1,0.00,0,0),(202,'default_task_status','auto',1,0.00,0,0),(203,'email_queue_skip_with_attachments','1',1,0.00,0,0),(204,'email_queue_enabled','0',1,0.00,0,0),(205,'last_email_queue_retry','1751966762',1,0.00,0,0),(206,'auto_dismiss_desktop_notifications_after','0',1,0.00,0,0),(207,'proposal_info_format','{proposal_to}<br />\r\n      {address}<br />\r\n      {city} {state}<br />\r\n      {country_code} {zip_code}<br />\r\n      {phone}<br />\r\n      {email}',0,0.00,0,0),(208,'ticket_replies_order','asc',1,0.00,0,0),(209,'new_recurring_invoice_action','generate_and_send',0,0.00,0,0),(210,'bcc_emails','',0,0.00,0,0),(211,'email_templates_language_checks','',0,0.00,0,0),(212,'proposal_accept_identity_confirmation','1',0,0.00,0,0),(213,'estimate_accept_identity_confirmation','1',0,0.00,0,0),(214,'new_task_auto_follower_current_member','0',1,0.00,0,0),(215,'task_biillable_checked_on_creation','1',1,0.00,0,0),(216,'predefined_clientnote_credit_note','',1,0.00,0,0),(217,'predefined_terms_credit_note','',1,0.00,0,0),(218,'next_credit_note_number','1',1,0.00,0,0),(219,'credit_note_prefix','CN-',1,0.00,0,0),(220,'credit_note_number_decrement_on_delete','1',1,0.00,0,0),(221,'pdf_format_credit_note','A4-PORTRAIT',1,0.00,0,0),(222,'show_pdf_signature_credit_note','1',0,0.00,0,0),(223,'show_credit_note_reminders_on_calendar','1',1,0.00,0,0),(224,'show_amount_due_on_invoice','1',1,0.00,0,0),(225,'show_total_paid_on_invoice','1',1,0.00,0,0),(226,'show_credits_applied_on_invoice','1',1,0.00,0,0),(227,'staff_members_create_inline_lead_status','1',1,0.00,0,0),(228,'staff_members_create_inline_customer_groups','1',1,0.00,0,0),(229,'staff_members_create_inline_ticket_services','1',1,0.00,0,0),(230,'staff_members_save_tickets_predefined_replies','1',1,0.00,0,0),(231,'staff_members_create_inline_contract_types','1',1,0.00,0,0),(232,'staff_members_create_inline_expense_categories','1',1,0.00,0,0),(233,'show_project_on_credit_note','1',1,0.00,0,0),(234,'proposals_auto_operations_hour','21',1,0.00,0,0),(235,'estimates_auto_operations_hour','21',1,0.00,0,0),(236,'contracts_auto_operations_hour','21',1,0.00,0,0),(237,'credit_note_number_format','1',1,0.00,0,0),(238,'allow_non_admin_members_to_import_leads','0',1,0.00,0,0),(239,'e_sign_legal_text','By clicking on \"Sign\", I consent to be legally bound by this electronic representation of my signature.',1,0.00,0,0),(240,'show_pdf_signature_contract','1',1,0.00,0,0),(241,'view_contract_only_logged_in','0',1,0.00,0,0),(242,'show_subscriptions_in_customers_area','1',1,0.00,0,0),(243,'calendar_only_assigned_tasks','0',1,0.00,0,0),(244,'after_subscription_payment_captured','send_invoice_and_receipt',1,0.00,0,0),(245,'mail_engine','phpmailer',1,0.00,0,0),(246,'gdpr_enable_terms_and_conditions','0',1,0.00,0,0),(247,'privacy_policy','',1,0.00,0,0),(248,'terms_and_conditions','',1,0.00,0,0),(249,'gdpr_enable_terms_and_conditions_lead_form','0',1,0.00,0,0),(250,'gdpr_enable_terms_and_conditions_ticket_form','0',1,0.00,0,0),(251,'gdpr_contact_enable_right_to_be_forgotten','0',1,0.00,0,0),(252,'show_gdpr_in_customers_menu','1',1,0.00,0,0),(253,'show_gdpr_link_in_footer','1',1,0.00,0,0),(254,'enable_gdpr','0',1,0.00,0,0),(255,'gdpr_on_forgotten_remove_invoices_credit_notes','0',1,0.00,0,0),(256,'gdpr_on_forgotten_remove_estimates','0',1,0.00,0,0),(257,'gdpr_enable_consent_for_contacts','0',1,0.00,0,0),(258,'gdpr_consent_public_page_top_block','',1,0.00,0,0),(259,'gdpr_page_top_information_block','',1,0.00,0,0),(260,'gdpr_enable_lead_public_form','0',1,0.00,0,0),(261,'gdpr_show_lead_custom_fields_on_public_form','0',1,0.00,0,0),(262,'gdpr_lead_attachments_on_public_form','0',1,0.00,0,0),(263,'gdpr_enable_consent_for_leads','0',1,0.00,0,0),(264,'gdpr_lead_enable_right_to_be_forgotten','0',1,0.00,0,0),(265,'allow_staff_view_invoices_assigned','1',1,0.00,0,0),(266,'gdpr_data_portability_leads','0',1,0.00,0,0),(267,'gdpr_lead_data_portability_allowed','',1,0.00,0,0),(268,'gdpr_contact_data_portability_allowed','',1,0.00,0,0),(269,'gdpr_data_portability_contacts','0',1,0.00,0,0),(270,'allow_staff_view_estimates_assigned','1',1,0.00,0,0),(271,'gdpr_after_lead_converted_delete','0',1,0.00,0,0),(272,'gdpr_show_terms_and_conditions_in_footer','0',1,0.00,0,0),(273,'save_last_order_for_tables','0',1,0.00,0,0),(274,'company_logo_dark','',1,0.00,0,0),(275,'customers_register_require_confirmation','0',1,0.00,0,0),(276,'allow_non_admin_staff_to_delete_ticket_attachments','0',1,0.00,0,0),(277,'receive_notification_on_new_ticket_replies','1',0,0.00,0,0),(278,'google_client_id','',1,0.00,0,0),(279,'enable_google_picker','1',1,0.00,0,0),(280,'show_ticket_reminders_on_calendar','1',1,0.00,0,0),(281,'ticket_import_reply_only','0',1,0.00,0,0),(282,'visible_customer_profile_tabs','a:19:{s:7:\"profile\";b:0;s:8:\"contacts\";b:0;s:5:\"notes\";b:1;s:9:\"statement\";b:1;s:8:\"invoices\";b:1;s:8:\"payments\";b:1;s:9:\"proposals\";b:1;s:12:\"credit_notes\";b:1;s:9:\"estimates\";b:1;s:13:\"subscriptions\";b:1;s:8:\"expenses\";b:1;s:9:\"contracts\";b:1;s:8:\"projects\";b:1;s:5:\"tasks\";b:1;s:7:\"tickets\";b:1;s:11:\"attachments\";b:1;s:5:\"vault\";b:1;s:9:\"reminders\";b:1;s:3:\"map\";b:1;}',0,0.00,0,0),(283,'show_project_on_invoice','0',1,0.00,0,0),(284,'show_project_on_estimate','1',1,0.00,0,0),(285,'staff_members_create_inline_lead_source','1',1,0.00,0,0),(286,'lead_unique_validation','[\"email\"]',1,0.00,0,0),(287,'last_upgrade_copy_data','',1,0.00,0,0),(288,'custom_js_admin_scripts','',1,0.00,0,0),(289,'custom_js_customer_scripts','0',1,0.00,0,0),(290,'stripe_webhook_id','',1,0.00,0,0),(291,'stripe_webhook_signing_secret','',1,0.00,0,0),(292,'stripe_ideal_webhook_id','',1,0.00,0,0),(293,'stripe_ideal_webhook_signing_secret','',1,0.00,0,0),(294,'show_php_version_notice','1',0,0.00,0,0),(295,'recaptcha_ignore_ips','',1,0.00,0,0),(296,'show_task_reminders_on_calendar','1',1,0.00,0,0),(297,'customer_settings','true',1,0.00,0,0),(298,'tasks_reminder_notification_hour','21',1,0.00,0,0),(299,'allow_primary_contact_to_manage_other_contacts','0',1,0.00,0,0),(300,'items_table_amounts_exclude_currency_symbol','1',1,0.00,0,0),(301,'round_off_task_timer_option','0',1,0.00,0,0),(302,'round_off_task_timer_time','5',1,0.00,0,0),(303,'bitly_access_token','',1,0.00,0,0),(304,'enable_support_menu_badges','0',1,0.00,0,0),(305,'attach_invoice_to_payment_receipt_email','0',1,0.00,0,0),(306,'invoice_due_notice_before','2',1,0.00,0,0),(307,'invoice_due_notice_resend_after','0',1,0.00,0,0),(308,'_leads_settings','true',1,0.00,0,0),(309,'show_estimate_request_in_customers_area','0',1,0.00,0,0),(310,'gdpr_enable_terms_and_conditions_estimate_request_form','0',1,0.00,0,0),(311,'identification_key','19730308581750866216685c1928b9351',1,0.00,0,0),(312,'automatically_stop_task_timer_after_hours','8',1,0.00,0,0),(313,'automatically_assign_ticket_to_first_staff_responding','0',1,0.00,0,0),(314,'reminder_for_completed_but_not_billed_tasks','0',1,0.00,0,0),(315,'staff_notify_completed_but_not_billed_tasks','',1,0.00,0,0),(316,'reminder_for_completed_but_not_billed_tasks_days','',1,0.00,0,0),(317,'tasks_reminder_notification_last_notified_day','',1,0.00,0,0),(318,'staff_related_ticket_notification_to_assignee_only','0',1,0.00,0,0),(319,'show_pdf_signature_proposal','1',1,0.00,0,0),(320,'enable_honeypot_spam_validation','1',1,0.00,0,0),(321,'microsoft_mail_client_id','',1,0.00,0,0),(322,'microsoft_mail_client_secret','',1,0.00,0,0),(323,'microsoft_mail_azure_tenant_id','',1,0.00,0,0),(324,'google_mail_client_id','',1,0.00,0,0),(325,'google_mail_client_secret','',1,0.00,0,0),(326,'google_mail_refresh_token','',1,0.00,0,0),(327,'microsoft_mail_refresh_token','',1,0.00,0,0),(328,'automatically_set_logged_in_staff_sales_agent','1',1,0.00,0,0),(329,'contract_sign_reminder_every_days','0',1,0.00,0,0),(330,'last_updated_date','',1,0.00,0,0),(331,'v310_incompatible_tables','[]',1,0.00,0,0),(332,'upgraded_from_version','',0,0.00,0,0),(333,'sms_clickatell_api_key','',1,0.00,0,0),(334,'sms_clickatell_active','0',1,0.00,0,0),(335,'sms_clickatell_initialized','1',1,0.00,0,0),(336,'sms_msg91_sender_id','',1,0.00,0,0),(337,'sms_msg91_api_type','api',1,0.00,0,0),(338,'sms_msg91_auth_key','',1,0.00,0,0),(339,'sms_msg91_active','0',1,0.00,0,0),(340,'sms_msg91_initialized','1',1,0.00,0,0),(341,'sms_twilio_account_sid','',1,0.00,0,0),(342,'sms_twilio_auth_token','',1,0.00,0,0),(343,'sms_twilio_phone_number','',1,0.00,0,0),(344,'sms_twilio_sender_id','',1,0.00,0,0),(345,'sms_twilio_active','0',1,0.00,0,0),(346,'sms_twilio_initialized','1',1,0.00,0,0),(347,'cr_date_cronjob_currency_rates','2025-06-28',1,0.00,0,0),(348,'cr_automatically_get_currency_rate','1',1,0.00,0,0),(349,'cr_global_amount_expiration','0',1,0.00,0,0),(350,'hr_profile_hide_menu','1',1,0.00,0,0),(351,'account_planning_enabled','1',1,0.00,0,0),(352,'mailbox_verification_id','MTIzNA==',1,0.00,0,0),(353,'mailbox_last_verification','1750867445',1,0.00,0,0),(354,'mailbox_product_token','product_token',1,0.00,0,0),(355,'mailbox_enabled','1',1,0.00,0,0),(356,'mailbox_imap_server','',1,0.00,0,0),(357,'mailbox_encryption','',1,0.00,0,0),(358,'mailbox_folder_scan','Inbox',1,0.00,0,0),(359,'mailbox_check_every','3',1,0.00,0,0),(360,'mailbox_only_loop_on_unseen_emails','1',1,0.00,0,0),(361,'acc_first_month_of_financial_year','January',1,0.00,0,0),(362,'acc_first_month_of_tax_year','same_as_financial_year',1,0.00,0,0),(363,'acc_accounting_method','accrual',1,0.00,0,0),(364,'acc_close_the_books','0',1,0.00,0,0),(365,'acc_allow_changes_after_viewing','allow_changes_after_viewing_a_warning',1,0.00,0,0),(366,'acc_close_book_password','',1,0.00,0,0),(367,'acc_close_book_passwordr','',1,0.00,0,0),(368,'acc_enable_account_numbers','0',1,0.00,0,0),(369,'acc_show_account_numbers','0',1,0.00,0,0),(370,'acc_closing_date','',1,0.00,0,0),(371,'acc_add_default_account','1',1,0.00,0,0),(372,'acc_add_default_account_new','0',1,0.00,0,0),(373,'acc_invoice_automatic_conversion','1',1,0.00,0,0),(374,'acc_payment_automatic_conversion','1',1,0.00,0,0),(375,'acc_credit_note_automatic_conversion','1',1,0.00,0,0),(376,'acc_credit_note_refund_automatic_conversion','1',1,0.00,0,0),(377,'acc_expense_automatic_conversion','1',1,0.00,0,0),(378,'acc_tax_automatic_conversion','1',1,0.00,0,0),(379,'acc_invoice_payment_account','66',1,0.00,0,0),(380,'acc_invoice_deposit_to','1',1,0.00,0,0),(381,'acc_payment_payment_account','1',1,0.00,0,0),(382,'acc_payment_deposit_to','13',1,0.00,0,0),(383,'acc_credit_note_payment_account','1',1,0.00,0,0),(384,'acc_credit_note_deposit_to','13',1,0.00,0,0),(385,'acc_credit_note_refund_payment_account','1',1,0.00,0,0),(386,'acc_credit_note_refund_deposit_to','13',1,0.00,0,0),(387,'acc_expense_payment_account','13',1,0.00,0,0),(388,'acc_expense_deposit_to','80',1,0.00,0,0),(389,'acc_tax_payment_account','29',1,0.00,0,0),(390,'acc_tax_deposit_to','1',1,0.00,0,0),(391,'acc_expense_tax_payment_account','13',1,0.00,0,0),(392,'acc_expense_tax_deposit_to','29',1,0.00,0,0),(393,'acc_active_payment_mode_mapping','1',1,0.00,0,0),(394,'acc_active_expense_category_mapping','1',1,0.00,0,0),(395,'acc_payment_expense_automatic_conversion','1',1,0.00,0,0),(396,'acc_payment_sale_automatic_conversion','1',1,0.00,0,0),(397,'acc_expense_payment_payment_account','1',1,0.00,0,0),(398,'acc_expense_payment_deposit_to','1',1,0.00,0,0),(399,'acc_pl_total_insurance_automatic_conversion','1',1,0.00,0,0),(400,'acc_pl_total_insurance_payment_account','13',1,0.00,0,0),(401,'acc_pl_total_insurance_deposit_to','32',1,0.00,0,0),(402,'acc_pl_tax_paye_automatic_conversion','1',1,0.00,0,0),(403,'acc_pl_tax_paye_payment_account','13',1,0.00,0,0),(404,'acc_pl_tax_paye_deposit_to','28',1,0.00,0,0),(405,'acc_pl_net_pay_automatic_conversion','1',1,0.00,0,0),(406,'acc_pl_net_pay_payment_account','13',1,0.00,0,0),(407,'acc_pl_net_pay_deposit_to','56',1,0.00,0,0),(408,'acc_wh_stock_import_automatic_conversion','1',1,0.00,0,0),(409,'acc_wh_stock_import_payment_account','87',1,0.00,0,0),(410,'acc_wh_stock_import_deposit_to','37',1,0.00,0,0),(411,'acc_wh_stock_export_automatic_conversion','1',1,0.00,0,0),(412,'acc_wh_stock_export_payment_account','37',1,0.00,0,0),(413,'acc_wh_stock_export_deposit_to','1',1,0.00,0,0),(414,'acc_wh_loss_adjustment_automatic_conversion','1',1,0.00,0,0),(415,'acc_wh_decrease_payment_account','37',1,0.00,0,0),(416,'acc_wh_decrease_deposit_to','1',1,0.00,0,0),(417,'acc_wh_increase_payment_account','87',1,0.00,0,0),(418,'acc_wh_increase_deposit_to','37',1,0.00,0,0),(419,'acc_wh_opening_stock_automatic_conversion','1',1,0.00,0,0),(420,'acc_wh_opening_stock_payment_account','88',1,0.00,0,0),(421,'acc_wh_opening_stock_deposit_to','37',1,0.00,0,0),(422,'acc_pur_order_automatic_conversion','1',1,0.00,0,0),(423,'acc_pur_order_payment_account','13',1,0.00,0,0),(424,'acc_pur_order_deposit_to','80',1,0.00,0,0),(425,'acc_pur_payment_automatic_conversion','1',1,0.00,0,0),(426,'acc_pur_payment_payment_account','16',1,0.00,0,0),(427,'acc_pur_payment_deposit_to','37',1,0.00,0,0),(428,'acc_mrp_manufacturing_order_automatic_conversion','1',1,0.00,0,0),(429,'acc_mrp_material_cost_payment_account','13',1,0.00,0,0),(430,'acc_mrp_material_cost_deposit_to','45',1,0.00,0,0),(431,'acc_mrp_labour_cost_payment_account','13',1,0.00,0,0),(432,'acc_mrp_labour_cost_deposit_to','18',1,0.00,0,0),(433,'acc_pur_order_return_automatic_conversion','1',1,0.00,0,0),(434,'acc_pur_order_return_payment_account','80',1,0.00,0,0),(435,'acc_pur_order_return_deposit_to','13',1,0.00,0,0),(436,'acc_pur_refund_automatic_conversion','1',1,0.00,0,0),(437,'acc_pur_refund_payment_account','37',1,0.00,0,0),(438,'acc_pur_refund_deposit_to','16',1,0.00,0,0),(439,'acc_pur_invoice_automatic_conversion','1',1,0.00,0,0),(440,'acc_pur_invoice_payment_account','13',1,0.00,0,0),(441,'acc_pur_invoice_deposit_to','80',1,0.00,0,0),(442,'acc_omni_sales_order_return_automatic_conversion','1',1,0.00,0,0),(443,'acc_omni_sales_order_return_payment_account','1',1,0.00,0,0),(444,'acc_omni_sales_order_return_deposit_to','66',1,0.00,0,0),(445,'acc_omni_sales_refund_automatic_conversion','1',1,0.00,0,0),(446,'acc_omni_sales_refund_payment_account','13',1,0.00,0,0),(447,'acc_omni_sales_refund_deposit_to','1',1,0.00,0,0),(448,'acc_routing_number_icon_a','a',1,0.00,0,0),(449,'acc_routing_number_icon_b','a',1,0.00,0,0),(450,'acc_bank_account_icon_a','a',1,0.00,0,0),(451,'acc_bank_account_icon_b','a',1,0.00,0,0),(452,'acc_current_check_no_icon_a','a',1,0.00,0,0),(453,'acc_current_check_no_icon_b','a',1,0.00,0,0),(454,'acc_check_type','type_1',1,0.00,0,0),(455,'acc_fe_asset_automatic_conversion','1',1,0.00,0,0),(456,'acc_fe_asset_payment_account','13',1,0.00,0,0),(457,'acc_fe_asset_deposit_to','1',1,0.00,0,0),(458,'acc_fe_license_automatic_conversion','1',1,0.00,0,0),(459,'acc_fe_license_payment_account','13',1,0.00,0,0),(460,'acc_fe_license_deposit_to','1',1,0.00,0,0),(461,'acc_fe_consumable_automatic_conversion','1',1,0.00,0,0),(462,'acc_fe_consumable_payment_account','13',1,0.00,0,0),(463,'acc_fe_consumable_deposit_to','1',1,0.00,0,0),(464,'acc_fe_component_automatic_conversion','1',1,0.00,0,0),(465,'acc_fe_component_payment_account','13',1,0.00,0,0),(466,'acc_fe_component_deposit_to','1',1,0.00,0,0),(467,'acc_fe_maintenance_automatic_conversion','1',1,0.00,0,0),(468,'acc_fe_maintenance_payment_account','13',1,0.00,0,0),(469,'acc_fe_maintenance_deposit_to','1',1,0.00,0,0),(470,'acc_fe_depreciation_automatic_conversion','1',1,0.00,0,0),(471,'acc_fe_depreciation_payment_account','13',1,0.00,0,0),(472,'acc_fe_depreciation_deposit_to','1',1,0.00,0,0),(473,'acc_wh_stock_export_profit_payment_account','66',1,0.00,0,0),(474,'acc_wh_stock_export_profit_deposit_to','1',1,0.00,0,0),(475,'update_bank_account_v124','1',1,0.00,0,0),(476,'update_income_statement_modifications_v125','1',1,0.00,0,0),(477,'acc_enable_income_statement_modifications','0',1,0.00,0,0),(478,'acc_invoice_discount_payment_account','1',1,0.00,0,0),(479,'acc_invoice_discount_deposit_to','19',1,0.00,0,0),(480,'acc_pur_tax_automatic_conversion','1',1,0.00,0,0),(481,'acc_pur_tax_payment_account','13',1,0.00,0,0),(482,'acc_pur_tax_deposit_to','29',1,0.00,0,0),(483,'acc_wh_stock_import_return_automatic_conversion','0',1,0.00,0,0),(484,'acc_wh_stock_import_return_payment_account','1',1,0.00,0,0),(485,'acc_wh_stock_import_return_deposit_to','37',1,0.00,0,0),(486,'acc_wh_stock_export_profit_automatic_conversion','1',1,0.00,0,0),(487,'affiliate_management_auto_approve_signup','1',1,0.00,0,0),(488,'affiliate_management_save_referral_client_info','1',1,0.00,0,0),(489,'affiliate_management_groups','{\"general\":{\"name\":\"General\",\"settings\":{\"affiliate_management_commission_enabled\":\"1\",\"affiliate_management_commission_rule\":\"first-invoice-payment\",\"affiliate_management_commission_type\":\"percent\",\"affiliate_management_commission_amount\":\"15\",\"affiliate_management_commission_cap\":\"-1\",\"affiliate_management_payout_min\":\"50\",\"affiliate_management_payout_methods\":\"bank, paypal\"}}}',1,0.00,0,0),(490,'affiliate_management_join_page_content','\n                    <div class=\"jumbotron text-center\">\n                        <h1>Welcome to Our Affiliate Program!</h1>\n                        <p>Join us and start earning today.</p>\n                        <a href=\"{SIGNUP_LINK}\" class=\"btn btn-primary btn-lg\">Join Now</a>\n                    </div>\n                    <div id=\"referral\" class=\"row\">\n                        <div class=\"col-md-6\">\n                            <h2>Referral Program</h2>\n                            <p>Join our referral program and start earning rewards!</p>\n                            <p>Earn {COMMISSION_AMOUNT} on every referral\'s first payment.</p>\n                            <p>Minimum payout is {MIN_PAYOUT}.</p>\n                        </div>\n                        <div class=\"col-md-6\">\n                            <h2>How It Works</h2>\n                            <p>1. Register for the affiliate program.</p>\n                            <p>2. Share your referral link with friends and colleagues.</p>\n                            <p>3. When someone signs up using your link and makes their first payment, you earn {COMMISSION_AMOUNT}.</p>\n                            <p>4. Once your earnings reach {MIN_PAYOUT}, you can request a payout.</p>\n                        </div>\n                    </div>\n                ',1,0.00,0,0),(491,'affiliate_management_affiliate_model','first-click',1,0.00,0,0),(492,'affiliate_management_enable_referral_removal','0',1,0.00,0,0),(493,'loyalty_setting','1',1,0.00,0,0),(494,'warehouse_selling_price_rule_profif_ratio','0',1,0.00,0,0),(495,'profit_rate_by_purchase_price_sale','0',1,0.00,0,0),(496,'warehouse_the_fractional_part','0',1,0.00,0,0),(497,'warehouse_integer_part','0',1,0.00,0,0),(498,'auto_create_goods_received','0',1,0.00,0,0),(499,'auto_create_goods_delivery','0',1,0.00,0,0),(500,'goods_receipt_warehouse','0',1,0.00,0,0),(501,'barcode_with_sku_code','0',1,0.00,0,0),(502,'revert_goods_receipt_goods_delivery','0',1,0.00,0,0),(503,'cancelled_invoice_reverse_inventory_delivery_voucher','0',1,0.00,0,0),(504,'uncancelled_invoice_create_inventory_delivery_voucher','0',1,0.00,0,0),(505,'inventory_auto_operations_hour','0',1,0.00,0,0),(506,'automatically_send_items_expired_before','0',1,0.00,0,0),(507,'inventorys_cronjob_active','0',1,0.00,0,0),(508,'inventory_cronjob_notification_recipients','',1,0.00,0,0),(509,'inventory_received_number_prefix','NK',1,0.00,0,0),(510,'next_inventory_received_mumber','1',1,0.00,0,0),(511,'inventory_delivery_number_prefix','XK',1,0.00,0,0),(512,'next_inventory_delivery_mumber','1',1,0.00,0,0),(513,'internal_delivery_number_prefix','ID',1,0.00,0,0),(514,'next_internal_delivery_mumber','1',1,0.00,0,0),(515,'item_sku_prefix','',1,0.00,0,0),(516,'goods_receipt_required_po','0',1,0.00,0,0),(517,'goods_delivery_required_po','0',1,0.00,0,0),(518,'goods_delivery_pdf_display','0',1,0.00,0,0),(519,'display_product_name_when_print_barcode','0',1,0.00,0,0),(520,'show_item_cf_on_pdf','0',1,0.00,0,0),(521,'goods_delivery_pdf_display_outstanding','0',1,0.00,0,0),(522,'goods_delivery_pdf_display_warehouse_lotnumber_bottom_infor','0',1,0.00,0,0),(523,'packing_list_number_prefix','PL',1,0.00,0,0),(524,'next_packing_list_number','1',1,0.00,0,0),(525,'wh_return_request_within_x_day','30',1,0.00,0,0),(526,'wh_fee_for_return_order','0',1,0.00,0,0),(527,'wh_return_policies_information','',1,0.00,0,0),(528,'wh_refund_loyaty_point','1',1,0.00,0,0),(529,'order_return_number_prefix','ReReturn',1,0.00,0,0),(530,'next_order_return_number','1',1,0.00,0,0),(531,'e_order_return_number_prefix','DEReturn',1,0.00,0,0),(532,'e_next_order_return_number','1',1,0.00,0,0),(533,'warehouse_receive_return_order ','0',1,0.00,0,0),(534,'wh_display_shipment_on_client_portal','1',1,0.00,0,0),(535,'wh_on_total_items','200',1,0.00,0,0),(536,'wh_products_by_serial','1',1,0.00,0,0),(537,'wh_shortened_form_pdf','0',1,0.00,0,0),(538,'wh_show_price_when_print_barcode','1',1,0.00,0,0),(539,'notify_customer_when_change_delivery_status','1',1,0.00,0,0),(540,'wh_hide_shipping_fee','0',1,0.00,0,0),(541,'lot_number_prefix','LOT',1,0.00,0,0),(542,'next_lot_number','1',1,0.00,0,0),(543,'auto_generate_lotnumber','0',1,0.00,0,0),(544,'custom_name_for_meter','m',1,0.00,0,0),(545,'custom_name_for_kg','kg',1,0.00,0,0),(546,'custom_name_for_m3','m3',1,0.00,0,0),(547,'packing_list_pdf_display_rate','1',1,0.00,0,0),(548,'packing_list_pdf_display_tax','1',1,0.00,0,0),(549,'packing_list_pdf_display_subtotal','1',1,0.00,0,0),(550,'packing_list_pdf_display_discount_percent','1',1,0.00,0,0),(551,'packing_list_pdf_display_discount_amount','1',1,0.00,0,0),(552,'packing_list_pdf_display_totalpayment','1',1,0.00,0,0),(553,'packing_list_pdf_display_summary','1',1,0.00,0,0),(554,'standard_workload','8',1,0.00,0,0),(555,'aside_menu_active','[]',1,0.00,0,0),(556,'setup_menu_active','[]',1,0.00,0,0),(557,'perfex_saas_enable_auto_trial','1',1,0.00,0,0),(558,'perfex_saas_autocreate_first_company','1',1,0.00,0,0),(559,'perfex_saas_reserved_slugs','www,app,deal,controller,master,ww3,hack,dotone,techdotbit',1,0.00,0,0),(560,'perfex_saas_control_client_menu','0',1,0.00,0,0),(561,'perfex_saas_cron_cache','{\"last_proccessed_instance_id\":0,\"cron_last_success_runtime\":1751173203,\"package-update\":[\"2\",\"1\",\"3\",\"4\"]}',1,0.00,0,0),(562,'perfex_saas_tenants_seed_tables','[\"tblcountries\",\"tblcurrencies\",\"tblcustomfields\",\"tblemailtemplates\",\"tblleads_email_integration\",\"tblleads_sources\",\"tblleads_status\",\"tblmigrations\",\"tblroles\",\"tbltickets_priorities\",\"tbltickets_status\"]',1,0.00,0,0),(563,'perfex_saas_sensitive_options','[\"acc_close_book_password\",\"acc_close_book_passwordr\",\"bitly_access_token\",\"company_logo\",\"company_logo_dark\",\"company_state\",\"company_vat\",\"dropbox_app_key\",\"favicon\",\"google_api_key\",\"google_client_id\",\"google_mail_client_id\",\"google_mail_client_secret\",\"google_mail_refresh_token\",\"identification_key\",\"invoice_company_address\",\"invoice_company_city\",\"invoice_company_country_code\",\"invoice_company_name\",\"invoice_company_phonenumber\",\"invoice_company_postal_code\",\"mailbox_product_token\",\"mailbox_verification_id\",\"main_domain\",\"microsoft_mail_azure_tenant_id\",\"microsoft_mail_client_id\",\"microsoft_mail_client_secret\",\"microsoft_mail_refresh_token\",\"paymentmethod_authorize_acceptjs_api_login_id\",\"paymentmethod_authorize_acceptjs_api_transaction_key\",\"paymentmethod_authorize_acceptjs_public_key\",\"paymentmethod_instamojo_api_key\",\"paymentmethod_instamojo_auth_token\",\"paymentmethod_mollie_api_key\",\"paymentmethod_paypal_braintree_api_private_key\",\"paymentmethod_paypal_braintree_api_public_key\",\"paymentmethod_paypal_braintree_merchant_id\",\"paymentmethod_paypal_checkout_client_id\",\"paymentmethod_paypal_checkout_secret\",\"paymentmethod_paypal_password\",\"paymentmethod_payu_money_key\",\"paymentmethod_stripe_api_publishable_key\",\"paymentmethod_stripe_api_secret_key\",\"paymentmethod_stripe_ideal_api_publishable_key\",\"paymentmethod_stripe_ideal_api_secret_key\",\"paymentmethod_two_checkout_secret_key\",\"purchase_key\",\"pusher_app_id\",\"pusher_app_key\",\"pusher_app_secret\",\"recaptcha_secret_key\",\"recaptcha_site_key\",\"sms_clickatell_api_key\",\"sms_msg91_auth_key\",\"sms_msg91_sender_id\",\"sms_twilio_auth_token\",\"sms_twilio_sender_id\",\"smtp_password\",\"stripe_ideal_webhook_id\",\"stripe_ideal_webhook_signing_secret\",\"stripe_webhook_id\",\"stripe_webhook_signing_secret\"]',1,0.00,0,0),(564,'perfex_saas_enable_single_package_mode','1',1,0.00,0,0),(565,'perfex_saas_enable_client_menu_in_bridge','1',1,0.00,0,0),(566,'perfex_saas_enable_custom_module_request','1',1,0.00,0,0),(567,'perfex_saas_enable_deploy_splash_screen','1',1,0.00,0,0),(568,'perfex_saas_deploy_splash_screen_theme','verbose',1,0.00,0,0),(569,'perfex_saas_enable_client_menu_in_interim_pages','0',1,0.00,0,0),(570,'perfex_saas_client_bridge_account_menu_position','setup',1,0.00,0,0),(571,'perfex_saas_registered_global_active_modules','[]',1,0.00,0,0),(572,'perfex_saas_masked_settings_pages','',1,0.00,0,0),(573,'perfex_saas_autolaunch_instance','new',1,0.00,0,0),(574,'perfex_saas_restricted_clients_id','[\"\"]',1,0.00,0,0),(575,'perfex_saas_tenant_seeding_source','tenant',1,0.00,0,0),(576,'perfex_saas_instance_delete_pending_days','0',1,0.00,0,0),(577,'perfex_saas_allow_customer_cancel_subscription','1',1,0.00,0,0),(578,'perfex_saas_enable_api','0',1,0.00,0,0),(579,'perfex_saas_api_allow_public_access_to_doc','0',1,0.00,0,0),(580,'perfex_saas_enable_client_bridge','1',1,0.00,0,0),(581,'perfex_saas_enable_cross_domain_bridge','0',1,0.00,0,0),(582,'perfex_saas_enable_instance_switch','1',1,0.00,0,0),(583,'perfex_saas_enable_package_grouping','1',1,0.00,0,0),(584,'perfex_saas_custom_domain_guide','<p><strong>For Linking Your Root Domain (e.g., yourbusiness.com):<br></strong></p>\r\n<ol>\r\n<li>\r\n<p><strong>Get Your Domain:</strong> Purchase your domain name from a registrar like Namecheap or GoDaddy (or any of your choice), if you haven\'t already.</p>\r\n</li>\r\n<li>\r\n<p><strong>Access DNS Records:</strong> Log in to your domain registrar\'s website and find the DNS settings section.</p>\r\n</li>\r\n<li>\r\n<p><strong>Configure DNS Settings for Root Domain:<br></strong></p>\r\n<ul>\r\n<li>Add a new \"A Record\" for the root domain:<br>\r\n<ul>\r\n<li><strong>Host:</strong> @</li>\r\n<li><strong>Value:</strong> {ip_address}</li>\r\n<li><strong>TTL:</strong> Automatic<br><br></li>\r\n</ul>\r\n</li>\r\n<li>Add another \"A Record\" for the \"www\" version (optional):<br>\r\n<ul>\r\n<li><strong>Host:</strong> www</li>\r\n<li><strong>Value:</strong> {ip_address}</li>\r\n<li><strong>TTL:</strong> Automatic<br><br></li>\r\n</ul>\r\n</li>\r\n</ul>\r\n</li>\r\n<li>\r\n<p><strong>Wait for Changes:</strong> Allow up to 48 hours for the changes to propagate across the internet.</p>\r\n</li>\r\n<li>\r\n<p><strong>Done!:</strong> Once propagated, both your root domain and optional \"www\" version will be linked to your SaaS platform.<br><br><br></p>\r\n</li>\r\n</ol>\r\n<p><strong>For Linking a Subdomain (e.g., crm.yourbusiness.com):<br></strong></p>\r\n<ol>\r\n<li>\r\n<p><strong>Create Your Subdomain:</strong></p>\r\n<ul>\r\n<li>In the DNS settings section of your registrar\'s website, find the option to create a subdomain.<br><br></li>\r\n<li>Enter \"crm\" (or your desired prefix) as the subdomain.<br><br></li>\r\n</ul>\r\n</li>\r\n<li>\r\n<p><strong>Access DNS Records:</strong></p>\r\n<ul>\r\n<li>Once the subdomain is created, locate the DNS settings for the subdomain.<br><br></li>\r\n</ul>\r\n</li>\r\n<li>\r\n<p><strong>Configure DNS Settings for Subdomain:</strong></p>\r\n<ul>\r\n<li>Add a new \"CNAME Record\" for the subdomain:<br>\r\n<ul>\r\n<li><strong>Host:</strong> crm (or your chosen prefix)</li>\r\n<li><strong>Value:</strong> {subdomain}</li>\r\n<li><strong>TTL:</strong> Automatic<br><br></li>\r\n</ul>\r\n</li>\r\n<li>Add another \"CNAME Record\" for the \"www\" version (optional):<br>\r\n<ul>\r\n<li><strong>Host:</strong> <a href=\"http://www.crm\">www.crm</a> (or your chosen prefix)</li>\r\n<li><strong>Value:</strong> {subdomain}</li>\r\n<li><strong>TTL:</strong> Automatic<br><br></li>\r\n</ul>\r\n</li>\r\n</ul>\r\n</li>\r\n<li>\r\n<p><strong>Wait for Changes:</strong> Allow up to 48 hours for the changes to propagate.</p>\r\n</li>\r\n<li>\r\n<p><strong>Test Your Subdomain:</strong> After propagation, enter the subdomain URL (e.g., crm.yourbusiness.com) into a browser to ensure it loads correctly.</p>\r\n</li>\r\n</ol>',1,0.00,0,0),(585,'paymentmethod_affiliate_management_gateway_active','0',1,0.00,0,0),(586,'paymentmethod_affiliate_management_gateway_label','Affiliate Earnings',1,0.00,0,0),(587,'paymentmethod_affiliate_management_gateway_currencies','USD',0,0.00,0,0),(588,'paymentmethod_affiliate_management_gateway_default_selected','1',1,0.00,0,0),(589,'paymentmethod_affiliate_management_gateway_initialized','1',1,0.00,0,0),(590,'paymentmethod_authorize_acceptjs_active','0',1,0.00,0,0),(591,'paymentmethod_authorize_acceptjs_label','Authorize.net Accept.js',1,0.00,0,0),(592,'paymentmethod_authorize_acceptjs_public_key','',0,0.00,0,0),(593,'paymentmethod_authorize_acceptjs_api_login_id','',0,0.00,0,0),(594,'paymentmethod_authorize_acceptjs_api_transaction_key','',0,0.00,0,0),(595,'paymentmethod_authorize_acceptjs_description_dashboard','Payment for Invoice {invoice_number}',0,0.00,0,0),(596,'paymentmethod_authorize_acceptjs_currencies','USD',0,0.00,0,0),(597,'paymentmethod_authorize_acceptjs_test_mode_enabled','0',0,0.00,0,0),(598,'paymentmethod_authorize_acceptjs_default_selected','1',1,0.00,0,0),(599,'paymentmethod_authorize_acceptjs_initialized','1',1,0.00,0,0),(600,'paymentmethod_instamojo_active','0',1,0.00,0,0),(601,'paymentmethod_instamojo_label','Instamojo',1,0.00,0,0),(602,'paymentmethod_instamojo_fee_fixed','0',0,0.00,0,0),(603,'paymentmethod_instamojo_fee_percent','0',0,0.00,0,0),(604,'paymentmethod_instamojo_api_key','',0,0.00,0,0),(605,'paymentmethod_instamojo_auth_token','',0,0.00,0,0),(606,'paymentmethod_instamojo_description_dashboard','Payment for Invoice {invoice_number}',0,0.00,0,0),(607,'paymentmethod_instamojo_currencies','INR',0,0.00,0,0),(608,'paymentmethod_instamojo_test_mode_enabled','1',0,0.00,0,0),(609,'paymentmethod_instamojo_default_selected','1',1,0.00,0,0),(610,'paymentmethod_instamojo_initialized','1',1,0.00,0,0),(611,'paymentmethod_mollie_active','0',1,0.00,0,0),(612,'paymentmethod_mollie_label','Mollie',1,0.00,0,0),(613,'paymentmethod_mollie_api_key','',0,0.00,0,0),(614,'paymentmethod_mollie_description_dashboard','Payment for Invoice {invoice_number}',0,0.00,0,0),(615,'paymentmethod_mollie_currencies','EUR',0,0.00,0,0),(616,'paymentmethod_mollie_test_mode_enabled','1',0,0.00,0,0),(617,'paymentmethod_mollie_default_selected','1',1,0.00,0,0),(618,'paymentmethod_mollie_initialized','1',1,0.00,0,0),(619,'paymentmethod_paypal_braintree_active','0',1,0.00,0,0),(620,'paymentmethod_paypal_braintree_label','Braintree',1,0.00,0,0),(621,'paymentmethod_paypal_braintree_merchant_id','',0,0.00,0,0),(622,'paymentmethod_paypal_braintree_api_public_key','',0,0.00,0,0),(623,'paymentmethod_paypal_braintree_api_private_key','',0,0.00,0,0),(624,'paymentmethod_paypal_braintree_currencies','USD',0,0.00,0,0),(625,'paymentmethod_paypal_braintree_paypal_enabled','1',0,0.00,0,0),(626,'paymentmethod_paypal_braintree_test_mode_enabled','1',0,0.00,0,0),(627,'paymentmethod_paypal_braintree_default_selected','1',1,0.00,0,0),(628,'paymentmethod_paypal_braintree_initialized','1',1,0.00,0,0),(629,'paymentmethod_paypal_checkout_active','0',1,0.00,0,0),(630,'paymentmethod_paypal_checkout_label','Paypal Smart Checkout',1,0.00,0,0),(631,'paymentmethod_paypal_checkout_fee_fixed','0',0,0.00,0,0),(632,'paymentmethod_paypal_checkout_fee_percent','0',0,0.00,0,0),(633,'paymentmethod_paypal_checkout_client_id','',0,0.00,0,0),(634,'paymentmethod_paypal_checkout_secret','',0,0.00,0,0),(635,'paymentmethod_paypal_checkout_payment_description','Payment for Invoice {invoice_number}',0,0.00,0,0),(636,'paymentmethod_paypal_checkout_currencies','USD,CAD,EUR',0,0.00,0,0),(637,'paymentmethod_paypal_checkout_test_mode_enabled','1',0,0.00,0,0),(638,'paymentmethod_paypal_checkout_default_selected','1',1,0.00,0,0),(639,'paymentmethod_paypal_checkout_initialized','1',1,0.00,0,0),(640,'paymentmethod_paypal_active','0',1,0.00,0,0),(641,'paymentmethod_paypal_label','Paypal',1,0.00,0,0),(642,'paymentmethod_paypal_fee_fixed','0',0,0.00,0,0),(643,'paymentmethod_paypal_fee_percent','0',0,0.00,0,0),(644,'paymentmethod_paypal_username','',0,0.00,0,0),(645,'paymentmethod_paypal_password','',0,0.00,0,0),(646,'paymentmethod_paypal_signature','',0,0.00,0,0),(647,'paymentmethod_paypal_description_dashboard','Payment for Invoice {invoice_number}',0,0.00,0,0),(648,'paymentmethod_paypal_currencies','EUR,USD',0,0.00,0,0),(649,'paymentmethod_paypal_test_mode_enabled','1',0,0.00,0,0),(650,'paymentmethod_paypal_default_selected','1',1,0.00,0,0),(651,'paymentmethod_paypal_initialized','1',1,0.00,0,0),(652,'paymentmethod_payu_money_active','0',1,0.00,0,0),(653,'paymentmethod_payu_money_label','PayU Money',1,0.00,0,0),(654,'paymentmethod_payu_money_fee_fixed','0',0,0.00,0,0),(655,'paymentmethod_payu_money_fee_percent','0',0,0.00,0,0),(656,'paymentmethod_payu_money_key','',0,0.00,0,0),(657,'paymentmethod_payu_money_salt','',0,0.00,0,0),(658,'paymentmethod_payu_money_description_dashboard','Payment for Invoice {invoice_number}',0,0.00,0,0),(659,'paymentmethod_payu_money_currencies','INR',0,0.00,0,0),(660,'paymentmethod_payu_money_test_mode_enabled','1',0,0.00,0,0),(661,'paymentmethod_payu_money_default_selected','1',1,0.00,0,0),(662,'paymentmethod_payu_money_initialized','1',1,0.00,0,0),(663,'paymentmethod_stripe_active','1',1,0.00,0,0),(664,'paymentmethod_stripe_label','Stripe Checkout',1,0.00,0,0),(665,'paymentmethod_stripe_fee_fixed','0',0,0.00,0,0),(666,'paymentmethod_stripe_fee_percent','0',0,0.00,0,0),(667,'paymentmethod_stripe_api_publishable_key','',0,0.00,0,0),(668,'paymentmethod_stripe_api_secret_key','',0,0.00,0,0),(669,'paymentmethod_stripe_description_dashboard','Payment for Invoice {invoice_number}',0,0.00,0,0),(670,'paymentmethod_stripe_currencies','USD,CAD',0,0.00,0,0),(671,'paymentmethod_stripe_allow_primary_contact_to_update_credit_card','1',0,0.00,0,0),(672,'paymentmethod_stripe_default_selected','1',1,0.00,0,0),(673,'paymentmethod_stripe_initialized','1',1,0.00,0,0),(674,'paymentmethod_stripe_ideal_active','0',1,0.00,0,0),(675,'paymentmethod_stripe_ideal_label','Stripe iDEAL',1,0.00,0,0),(676,'paymentmethod_stripe_ideal_api_secret_key','',0,0.00,0,0),(677,'paymentmethod_stripe_ideal_api_publishable_key','',0,0.00,0,0),(678,'paymentmethod_stripe_ideal_description_dashboard','Payment for Invoice {invoice_number}',0,0.00,0,0),(679,'paymentmethod_stripe_ideal_statement_descriptor','Payment for Invoice {invoice_number}',0,0.00,0,0),(680,'paymentmethod_stripe_ideal_currencies','EUR',0,0.00,0,0),(681,'paymentmethod_stripe_ideal_default_selected','1',1,0.00,0,0),(682,'paymentmethod_stripe_ideal_initialized','1',1,0.00,0,0),(683,'paymentmethod_two_checkout_active','0',1,0.00,0,0),(684,'paymentmethod_two_checkout_label','2Checkout',1,0.00,0,0),(685,'paymentmethod_two_checkout_fee_fixed','0',0,0.00,0,0),(686,'paymentmethod_two_checkout_fee_percent','0',0,0.00,0,0),(687,'paymentmethod_two_checkout_merchant_code','',0,0.00,0,0),(688,'paymentmethod_two_checkout_secret_key','',0,0.00,0,0),(689,'paymentmethod_two_checkout_description','Payment for Invoice {invoice_number}',0,0.00,0,0),(690,'paymentmethod_two_checkout_currencies','USD, EUR, GBP',0,0.00,0,0),(691,'paymentmethod_two_checkout_test_mode_enabled','1',0,0.00,0,0),(692,'paymentmethod_two_checkout_default_selected','1',1,0.00,0,0),(693,'paymentmethod_two_checkout_initialized','1',1,0.00,0,0),(694,'perfex_saas_demo_instance_last_reset_time','1751962581',1,0.00,0,0),(695,'perfex_saas_require_invoice_payment_status','[\"\",\"4\",\"1\"]',1,0.00,0,0),(696,'perfex_saas_deferred_billing_status','1',1,0.00,0,0),(697,'perfex_saas_landing_page_url','',1,0.00,0,0),(698,'perfex_saas_landing_page_url_mode','proxy',1,0.00,0,0),(699,'perfex_saas_clients_default_theme_whitelabel_name','perfex',1,0.00,0,0),(700,'perfex_saas_seeding_tenant','szw',1,0.00,0,0),(701,'perfex_saas_custom_module_request_form','',1,0.00,0,0),(702,'perfex_saas_custom_modules_name','{\"account_planning\":\"Account Planning\",\"accounting\":\"Accounting and Bookkeeping\",\"affiliate_management\":\"Affiliate Management\",\"appointly\":\"Appointly\",\"aws_integration\":\"AWS S3 Integration\",\"exports\":\"CSV Export Manager\",\"loyalty\":\"Customer Loyalty & Membership\",\"backup\":\"Database Backup\",\"facebook_leads_integration\":\"Facebook leads integration\",\"fixed_equipment\":\"Fixed Equipment Management\",\"fleet\":\"Fleet Management\",\"flexstage\":\"Flex Stage - Event Manager\",\"flexibackup\":\"Flexi Backup\",\"goals\":\"Goals\",\"hr_payroll\":\"HR Payroll\",\"hr_profile\":\"HR Records\",\"si_lead_followup\":\"Lead Follow up Scheduler\",\"mailbox\":\"Mailbox\",\"mailflow\":\"MailFlow - Customers & Leads Newsletter\",\"si_custom_status\":\"Manage Custom Statuses\",\"manufacturing\":\"Manufacturing Management\",\"ma\":\"Marketing Automation\",\"menu_setup\":\"Menu Setup\",\"mfa\":\"Multi-factor authentication\",\"perfex_office_theme\":\"Office Flat Pro Theme\",\"omni_sales\":\"Omni Sales\",\"project_roadmap\":\"Project Roadmap\",\"purchase\":\"Purchase\",\"quickbooks_integration\":\"Quickbooks integration\",\"recruitment\":\"Recruitment\",\"resource_workload\":\"Staff workload\",\"surveys\":\"Surveys\",\"theme_style\":\"Theme Style\",\"timesheets\":\"Timesheet Attendance Management\",\"user_mention\":\"User Mention\",\"warehouse\":\"Warehouse\",\"webhooks\":\"Webhooks\",\"whatsapp_api\":\"WhatsApp Cloud API Business Integration module\",\"whatsbot\":\"WhatsBot\",\"dfm_contracts\":\"Contracts\",\"dfm_credit_notes\":\"Credit notes\",\"dfm_custom_fields\":\"Custom fields\",\"dfm_estimate_request\":\"Estimate request\",\"dfm_estimates\":\"Estimates\",\"dfm_expenses\":\"Expenses\",\"dfm_invoices\":\"Invoices\",\"dfm_items\":\"Items\",\"dfm_knowledge_base\":\"Knowledge base\",\"dfm_leads\":\"Leads\",\"dfm_payments\":\"Payments\",\"dfm_projects\":\"Projects\",\"dfm_proposals\":\"Proposals\",\"dfm_reports\":\"Reports\",\"dfm_subscriptions\":\"Subscriptions\",\"dfm_tasks\":\"Tasks\",\"dfm_tickets\":\"Tickets\"}',1,0.00,0,0),(703,'perfex_saas_modules_marketplace','{\"account_planning\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"accounting\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"affiliate_management\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"appointly\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"aws_integration\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"exports\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"loyalty\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"backup\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"facebook_leads_integration\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"fixed_equipment\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"fleet\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"flexstage\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"flexibackup\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"goals\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"hr_payroll\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"hr_profile\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"si_lead_followup\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"mailbox\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"mailflow\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"si_custom_status\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"manufacturing\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"ma\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"menu_setup\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"mfa\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"perfex_office_theme\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"omni_sales\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"project_roadmap\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"purchase\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"quickbooks_integration\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"recruitment\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"resource_workload\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"surveys\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"theme_style\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"timesheets\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"user_mention\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"warehouse\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"webhooks\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"whatsapp_api\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"whatsbot\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"dfm_contracts\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"dfm_credit_notes\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"dfm_custom_fields\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"dfm_estimate_request\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"dfm_estimates\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"dfm_expenses\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"dfm_invoices\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"dfm_items\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"dfm_knowledge_base\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"dfm_leads\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"dfm_payments\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"dfm_projects\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"dfm_proposals\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"dfm_reports\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"dfm_subscriptions\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"dfm_tasks\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"},\"dfm_tickets\":{\"description\":\"\",\"price\":\"\",\"billing_mode\":\"billing_cycle\",\"image\":\"\"}}',1,0.00,0,0),(704,'perfex_saas_custom_service_request_form','',1,0.00,0,0),(705,'perfex_saas_custom_services','[\"\"]',1,0.00,0,0),(706,'perfex_saas_cpanel_login_domain','',1,0.00,0,0),(707,'perfex_saas_cpanel_port','2083',1,0.00,0,0),(708,'perfex_saas_cpanel_username','',1,0.00,0,0),(709,'perfex_saas_cpanel_password','53b11bf7b542d0d2445ed2ab711e618825eae2d3f5e25e467f9ea562b96587f2f41f3d897330100107f1fb38b0f11f9a8ca3b307d1131038c11599d6d267b7feYZFAJ/ikyrUzuoe/bty2PV1/hA/aD09W1gxKb6yeBuA=',1,0.00,0,0),(710,'perfex_saas_cpanel_db_prefix','',1,0.00,0,0),(711,'perfex_saas_cpanel_enable_addondomain','0',1,0.00,0,0),(712,'perfex_saas_cpanel_addondomain_mode','all',1,0.00,0,0),(713,'perfex_saas_cpanel_primary_domain','82.29.165.22',1,0.00,0,0),(714,'perfex_saas_cpanel_document_root','/var/www/html/',1,0.00,0,0),(715,'perfex_saas_plesk_host','',1,0.00,0,0),(716,'perfex_saas_plesk_primary_domain','82.29.165.22',1,0.00,0,0),(717,'perfex_saas_plesk_username','',1,0.00,0,0),(718,'perfex_saas_plesk_password','dc4ee7e33fe73d47414aa5b19c9c06a429174f20185f50c180afb7461913e4ae293d0801cae4a7705355ec4b0b6fdb38c4ce3b2fe424baa2d4218f1a6514883c3+nFPYIK7D+kRu5t0EoV+9R9CyLYhlCGJJC5vqgSRkI=',1,0.00,0,0),(719,'perfex_saas_plesk_enable_aliasdomain','0',1,0.00,0,0),(720,'perfex_saas_plesk_addondomain_mode','all',1,0.00,0,0),(721,'perfex_saas_mysql_root_enabled','1',1,0.00,0,0),(722,'perfex_saas_mysql_root_host','localhost',1,0.00,0,0),(723,'perfex_saas_mysql_root_port','3306',1,0.00,0,0),(724,'perfex_saas_mysql_root_username','dotadmin',1,0.00,0,0),(725,'perfex_saas_mysql_root_password','4c4cbcca1a41b6f0d853465041304f0a5434fc09f32a09ff2739f43ef50c74e92511e6e77c64cf76aa0c9a821b860ffcfbbc90c286a9b5985abfca05214aab457Vt1x35we69n+/AivuJj1z9UBpbvzlDkWmHcWM2vUInNOPRLLpFyt0xy+UecaAMV',1,0.00,0,0),(726,'perfex_saas_mysql_root_enable_separate_user','1',1,0.00,0,0),(727,'perfex_saas_after_first_instance_redirect_url','',1,0.00,0,0),(728,'perfex_saas_trial_expire_page_url','',1,0.00,0,0),(729,'perfex_saas_client_restriction_mode','',1,0.00,0,0),(730,'perfex_saas_trial_notification_day','0',1,0.00,0,0),(731,'perfex_saas_demo_instance','[\"\"]',1,0.00,0,0),(732,'perfex_saas_demo_instance_reset_hour','24',1,0.00,0,0),(733,'perfex_saas_alternative_base_host','',1,0.00,0,0),(734,'perfex_saas_route_id','tenant-ps',1,0.00,0,0),(735,'perfex_saas_cpanel_enabled','1',1,0.00,0,0),(736,'sms_trigger_invoice_overdue_notice','',0,0.00,0,0),(737,'sms_trigger_invoice_due_notice','',0,0.00,0,0),(738,'sms_trigger_invoice_payment_recorded','',0,0.00,0,0),(739,'sms_trigger_estimate_expiration_reminder','',0,0.00,0,0),(740,'sms_trigger_proposal_expiration_reminder','',0,0.00,0,0),(741,'sms_trigger_proposal_new_comment_to_customer','',0,0.00,0,0),(742,'sms_trigger_proposal_new_comment_to_staff','',0,0.00,0,0),(743,'sms_trigger_contract_new_comment_to_customer','',0,0.00,0,0),(744,'sms_trigger_contract_new_comment_to_staff','',0,0.00,0,0),(745,'sms_trigger_contract_expiration_reminder','',0,0.00,0,0),(746,'sms_trigger_contract_sign_reminder_to_customer','',0,0.00,0,0),(747,'sms_trigger_staff_reminder','',0,0.00,0,0),(748,'perfex_office_theme_customers','1',1,0.00,0,0),(749,'perfex_saas_enable_subdomain_input_on_signup_form','1',1,0.00,0,0),(750,'perfex_saas_enable_customdomain_input_on_signup_form','0',1,0.00,0,0),(751,'perfex_saas_force_redirect_to_dashboard','1',1,0.00,0,0),(752,'required_register_fields','[\"contact_firstname\",\"contact_lastname\"]',1,0.00,0,0),(753,'perfex_saas_allow_default_modules_on_marketplace','1',1,0.00,0,0),(754,'perfex_saas_enable_tenant_admin_modules_page','1',1,0.00,0,0),(755,'perfex_saas_enable_tenant_seeding_caching','1',1,0.00,0,0),(756,'pur_invoice_auto_operations_hour','21',1,0.00,0,0),(757,'next_debit_note_number','1',1,0.00,0,0),(758,'debit_note_number_format','1',1,0.00,0,0),(759,'debit_note_prefix','DN-',1,0.00,0,0),(760,'show_purchase_tax_column','1',1,0.00,0,0),(761,'po_only_prefix_and_number','0',1,0.00,0,0),(762,'pur_return_request_within_x_day','30',1,0.00,0,0),(763,'pur_fee_for_return_order','0',1,0.00,0,0),(764,'pur_return_policies_information','',1,0.00,0,0),(765,'pur_order_return_number_prefix','OReturn',1,0.00,0,0),(766,'next_pur_order_return_number','1',1,0.00,0,0),(767,'send_email_welcome_for_new_contact','1',1,0.00,0,0),(768,'reset_purchase_order_number_every_month','1',1,0.00,0,0),(769,'pur_company_address','',1,0.00,0,0),(770,'pur_company_city','',1,0.00,0,0),(771,'pur_company_state','',1,0.00,0,0),(772,'pur_company_zipcode','',1,0.00,0,0),(773,'pur_company_country_code','',1,0.00,0,0),(774,'allow_vendors_to_register','1',1,0.00,0,0),(775,'pur_company_country_text','',1,0.00,0,0),(776,'whatsapp_api_verification_id','38690826',1,0.00,0,0),(777,'whatsapp_api_last_verification','999999999',1,0.00,0,0),(778,'whatsapp_api_verified','1',1,0.00,0,0),(779,'whatsapp_api_heartbeat','1',1,0.00,0,0),(780,'whatsapp_api_enabled','1',1,0.00,0,0),(781,'recruitment_create_campaign_with_plan ','1',1,0.00,0,0),(782,'display_quantity_to_be_recruited','1',1,0.00,0,0),(783,'candidate_code_prefix','ID',1,0.00,0,0),(784,'candidate_code_number','1',1,0.00,0,0),(785,'send_email_welcome_for_new_candidate','1',1,0.00,0,0),(786,'flexibackup_files_backup_schedule','1',1,0.00,0,0),(787,'flexibackup_database_backup_schedule','1',1,0.00,0,0),(788,'flexibackup_remote_storage','',1,0.00,0,0),(789,'last_flexi_backup_file','',1,0.00,0,0),(790,'last_flexi_backup_database','',1,0.00,0,0),(791,'paymentmethod_razorpay_active','1',1,0.00,0,0),(792,'paymentmethod_razorpay_label','Razorpay',1,0.00,0,0),(793,'paymentmethod_razorpay_key_id','rzp_live_HI0V07stWalvUa',0,0.00,0,0),(794,'paymentmethod_razorpay_key_secret','a47c2140b2a4df8aa3a442d35af770c4d785e019650f49d8c66bae44850594e3b08118198a17d37714082727d27cfa11330653dea32ef9e0a937380752e6b94dBGCxpf++61fQn/fsjYXvgN7HaninjzUIZC6UAooL0+RV3RP+gOfX6yji7P1z6oQn',0,0.00,0,0),(795,'paymentmethod_razorpay_description_dashboard','Payment for Invoice {invoice_number}',0,0.00,0,0),(796,'paymentmethod_razorpay_currencies','INR',0,0.00,0,0),(797,'paymentmethod_razorpay_default_selected','1',1,0.00,0,0),(798,'paymentmethod_razorpay_initialized','1',1,0.00,0,0);
/*!40000 ALTER TABLE `tbloptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblp_t_form_question_box_description`
--

DROP TABLE IF EXISTS `tblp_t_form_question_box_description`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblp_t_form_question_box_description` (
  `questionboxdescriptionid` int(11) NOT NULL AUTO_INCREMENT,
  `description` mediumtext NOT NULL,
  `boxid` mediumtext NOT NULL,
  `questionid` int(11) NOT NULL,
  `correct` int(11) DEFAULT 1 COMMENT '0: correct 1: incorrect',
  PRIMARY KEY (`questionboxdescriptionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblp_t_form_question_box_description`
--

LOCK TABLES `tblp_t_form_question_box_description` WRITE;
/*!40000 ALTER TABLE `tblp_t_form_question_box_description` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblp_t_form_question_box_description` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblpayment_attempts`
--

DROP TABLE IF EXISTS `tblpayment_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblpayment_attempts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference` varchar(100) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `amount` double NOT NULL,
  `fee` double NOT NULL,
  `payment_gateway` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblpayment_attempts`
--

LOCK TABLES `tblpayment_attempts` WRITE;
/*!40000 ALTER TABLE `tblpayment_attempts` DISABLE KEYS */;
INSERT INTO `tblpayment_attempts` VALUES (1,'99c261c2ef8ccf88ccc474653c137ed9',3,18000,0,'razorpay','2025-07-08 10:42:16');
/*!40000 ALTER TABLE `tblpayment_attempts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblpayment_modes`
--

DROP TABLE IF EXISTS `tblpayment_modes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblpayment_modes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `show_on_pdf` int(11) NOT NULL DEFAULT 0,
  `invoices_only` int(11) NOT NULL DEFAULT 0,
  `expenses_only` int(11) NOT NULL DEFAULT 0,
  `selected_by_default` int(11) NOT NULL DEFAULT 1,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblpayment_modes`
--

LOCK TABLES `tblpayment_modes` WRITE;
/*!40000 ALTER TABLE `tblpayment_modes` DISABLE KEYS */;
INSERT INTO `tblpayment_modes` VALUES (1,'Bank',NULL,0,0,0,1,1);
/*!40000 ALTER TABLE `tblpayment_modes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblperfex_saas_api_users`
--

DROP TABLE IF EXISTS `tblperfex_saas_api_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblperfex_saas_api_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `token` varchar(150) NOT NULL,
  `permissions` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pf_api_users_token` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblperfex_saas_api_users`
--

LOCK TABLES `tblperfex_saas_api_users` WRITE;
/*!40000 ALTER TABLE `tblperfex_saas_api_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblperfex_saas_api_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblperfex_saas_client_metadata`
--

DROP TABLE IF EXISTS `tblperfex_saas_client_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblperfex_saas_client_metadata` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clientid` int(11) NOT NULL,
  `metadata` text DEFAULT NULL COMMENT 'Extra data',
  PRIMARY KEY (`id`),
  UNIQUE KEY `clientid` (`clientid`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblperfex_saas_client_metadata`
--

LOCK TABLES `tblperfex_saas_client_metadata` WRITE;
/*!40000 ALTER TABLE `tblperfex_saas_client_metadata` DISABLE KEYS */;
INSERT INTO `tblperfex_saas_client_metadata` VALUES (1,1,'{\"trial_period_start\":\"2025-06-26\",\"trial_period_ends\":\"2025-07-03\",\"trial_package_id\":\"1\",\"trial_cancelled\":\"\",\"last_cancelled_invoice\":\"\",\"subscription_id\":\"\",\"magic_code\":\"9c1f25426679dc831c53f33cef2586a6160e100ee565ff2cd7e47107504e5f62605abbcd1e1019bac45ac5a4e3fd226468506e19c964692f6970cbfc69b2cf2bR4VpO0IQ216Tendj2xnIi3/Z+/bh7+VPK0YsrVeUNInsN40TgAAt2sq1UvYa/RtA\"}'),(2,2,'{\"trial_period_start\":\"2025-06-27\",\"trial_period_ends\":\"2025-07-04\",\"trial_package_id\":\"1\",\"trial_cancelled\":\"\",\"last_cancelled_invoice\":\"\",\"subscription_id\":\"\",\"magic_code\":\"d1628ec7bbb77e3e68c92ee77f2c0fc80ee394deb7c61fafac07292e535f4f87f5cb9b98a8b594d9872efeb27e960696659f375abeb8a4d5ab86eb88ee0c9de8/Ps2N2k2dBNXTjoXO4pCJKZg9DpIErZ1wqWSwpZv9X0dnSRGUFL2DHwUuKIWhbNF\"}'),(3,3,'{\"trial_period_start\":\"2025-06-27\",\"trial_period_ends\":\"2025-07-04\",\"trial_package_id\":\"1\",\"trial_cancelled\":\"\",\"last_cancelled_invoice\":\"\",\"subscription_id\":\"\",\"magic_code\":\"5f45ffdc173c4737d71041c0fda3e2596fc2b17f36804e3cf54a4747d5b72ae1f129637e05686f6b74bf819279a89e07afc5e3fc0a5cbcea75ee03fd5355911cPh9dgfLloYQ5D3ro6L37nDFdqE9uIk3qWs8DcwgFyEkJXTXy7tuQq4kox6dWtQ9Y\"}'),(4,4,'{\"trial_period_start\":\"2025-06-27\",\"trial_period_ends\":\"2025-07-04\",\"trial_package_id\":\"1\",\"trial_cancelled\":\"true\",\"last_cancelled_invoice\":\"\",\"subscription_id\":\"\",\"last_cancelled_invoice_recurring\":null,\"magic_code\":\"ba44c20ee1eec03836822bc8931815f15730c84986bd53425d063a1a7cfddd80ac8090dda9a324fbf675b0128fc21b26e8a0c5bdce7eef481dd201fc18fa421c1wEbLxt9Az9FVxNmsUuHEiiamV1yx0tf7+X4aOe5RMDikr2ktDtZhyNx2wH2hFnN\"}'),(5,5,'{\"trial_period_start\":\"2025-07-01\",\"trial_period_ends\":\"2025-07-08\",\"trial_package_id\":\"1\",\"trial_cancelled\":\"\",\"last_cancelled_invoice\":\"\",\"subscription_id\":\"\",\"magic_code\":\"e7464683cc8a675d7ba21d94bdf40d85263375583039ba847c3f91851b9398e961b902e0f63efd10866450a400a610cbcd079fe2fb259cd43b69d12cccdd2680wD2PLBm2hmWyjKftRS14tBLqTpQ4lMl1iMzhvg9EoO+X28chNa7HZtFJ2Gkl18TQ\"}'),(6,6,'{\"trial_period_start\":\"2025-07-06\",\"trial_period_ends\":\"2025-07-13\",\"trial_package_id\":\"1\",\"trial_cancelled\":\"\",\"last_cancelled_invoice\":\"\",\"subscription_id\":\"\",\"magic_code\":\"99367c39bfa6383fb30c25ae5af09d39d53167cc505f2b93508c22cd2465bad1458f51f1202267b621487229f9f3cc4d45929b6be893e50b47710dcb2f8b85bbWpgr37jRvkeox8AY19p6GitKv9FoIBfizJygLLRQks0OTQreWi245cRC/1++rW4M\"}'),(7,7,'{\"trial_period_start\":\"2025-07-06\",\"trial_period_ends\":\"2025-07-13\",\"trial_package_id\":\"1\",\"trial_cancelled\":\"\",\"last_cancelled_invoice\":\"\",\"subscription_id\":\"\",\"magic_code\":\"a5396d6e9d11c2eb02d63acaf3ff28f3eeff2b334fc37c89e316ce0fa5e3876ac161734b8e719e4b69ac32f103f7166d0648ad2ad2268073dda618db0520367bWBIGMq4dAG5lA5TRdW2s6QFvgn0j+IDY6mUmVYaEqtdJpTN0LuLAlK92DHv8USvZ\"}'),(8,8,'{\"trial_period_start\":\"2025-07-06\",\"trial_period_ends\":\"2025-07-13\",\"trial_package_id\":\"1\",\"trial_cancelled\":\"\",\"last_cancelled_invoice\":\"\",\"subscription_id\":\"\",\"magic_code\":\"dfa3d7ac753329a7d276796f95a7da3022749e435e5d79093fd409572f3bed476fde2b86df2e16bb00f91eab111fe072c625b340e854fcb2239850135e924eb0eWQnbqj2QxDVF3xu/ctppBvHXuikhYJ6lC4ufRHA1sRq1SiCnfiq0CcSOx07qBgR\"}'),(9,9,'{\"trial_period_start\":\"2025-07-06\",\"trial_period_ends\":\"2025-07-13\",\"trial_package_id\":\"3\",\"trial_cancelled\":\"true\",\"last_cancelled_invoice\":\"\",\"subscription_id\":\"\",\"magic_code\":\"975c5b3bc58f67b6d879ad6998c71b75ac69718bb168059ba41187efd281c2e71bbf9ad8de16517b6225f27582895fe039497d968fed469fe2bc021079316681tWi96I9bbDebFJNEYhDgbfgK2OHK/unD+t0hrhBNHVdwjCC0R/H44/baZEUZFpBQ\",\"last_cancelled_invoice_recurring\":null}'),(10,10,'{\"trial_period_start\":\"2025-07-07\",\"trial_period_ends\":\"2025-07-14\",\"trial_package_id\":\"3\",\"trial_cancelled\":\"true\",\"last_cancelled_invoice\":\"\",\"subscription_id\":\"\",\"magic_code\":\"c1ef0ac879f5a12a7664b6d8fc8510ec247678e70bea1544ee5ca578ad0e54bde9af2fca238c9659007f894d0d7e140a274bb7205222ae221520b5e198dd4bfaLT9nAHFz2xeunB9xa7nObq/PsAwUXj1HTYxTrEXotvPr8tAHjzopo4vYkVK7dSSO\",\"last_cancelled_invoice_recurring\":null}'),(11,11,'{\"trial_period_start\":\"2025-07-07\",\"trial_period_ends\":\"2025-07-14\",\"trial_package_id\":\"3\",\"trial_cancelled\":\"true\",\"last_cancelled_invoice\":\"\",\"subscription_id\":\"\",\"magic_code\":\"d74043f1b6e21b305ae7d85362c466473c92396ece9bd4bc8991494df1e7d127eaeabc9c76411fb9e0a5cb0a66d99b34e592044f46d81b3f921046d973e32b383M2F0mBmzastFC8ScZZgjf5q+FFjDqfpnwcRdvEU+4AhEms2DF0JhuzUwPWfnjhB\",\"last_cancelled_invoice_recurring\":null}'),(12,12,'{\"trial_period_start\":\"2025-07-08\",\"trial_period_ends\":\"2025-07-15\",\"trial_package_id\":\"1\",\"trial_cancelled\":\"\",\"last_cancelled_invoice\":\"\",\"subscription_id\":\"\",\"magic_code\":\"681d35cc5544c1a1733144580fd5749152bf78312eb3a8c62faf377a9c2c2db17a028789c144465aa5f0110b28f79fbcbf565d0253bea479b40a678b5b3af478U+4z9uBp4Su94n6ibRc83L4bWkTGGf4oXB1CfCqa+b84froACFf2Yr6rGlKOs+Xk\"}');
/*!40000 ALTER TABLE `tblperfex_saas_client_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblperfex_saas_companies`
--

DROP TABLE IF EXISTS `tblperfex_saas_companies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblperfex_saas_companies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clientid` int(11) NOT NULL,
  `slug` varchar(30) NOT NULL,
  `name` varchar(100) NOT NULL,
  `status` enum('active','inactive','disabled','banned','pending','deploying','pending-delete') NOT NULL DEFAULT 'pending',
  `status_note` text DEFAULT NULL,
  `dsn` text DEFAULT NULL,
  `custom_domain` varchar(150) DEFAULT NULL,
  `metadata` text DEFAULT NULL COMMENT 'Extra data',
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblperfex_saas_companies`
--

LOCK TABLES `tblperfex_saas_companies` WRITE;
/*!40000 ALTER TABLE `tblperfex_saas_companies` DISABLE KEYS */;
INSERT INTO `tblperfex_saas_companies` VALUES (10,10,'demo','demo','active','','911a2f97806122e8be59496e48d821778279a30724bbc1a90028d204d3db8735330ab3b748277b062717901b8c7ed1f74faac1a4a97240fdcf25df70e8f8eb8asyAd0vPcpr1U66A2BWhWCoS2kaXKSaHtuIp4OOeZ7Fb03Q2nm1kZNHsVTPduj5q+uMdayppfn6KhUynHSJ1+rBVhHWikwHdmiHBx+O0x9Qxz3SS7EuCDxKJiODVnC1kb',NULL,'{\"storage\":{\"upload_size_in_bytes\":300,\"media_size_in_bytes\":0,\"total\":300}}','2025-07-07 16:11:45','2025-07-08 08:16:02'),(11,11,'splice','splice laminate private limited','active','','f597fc9cbc07194075da487008e2ab76eaac18a816002216128b856ee03cbcb940947191c9f4062e3e557839fb972e26895be7ef21bab52b751abb3f60ae4d3dnYU1GaXj8Smh4tbmKXdnSmI+yr42hrPMFcBjgjEQb5DXb/99eeVqusSvkfjiqiR3+qesjdyVrVM4w/6YPV2xR+u5J52Qn9euW2XdxD5DlNq8vCYduf7Es5zZov8QU/4puZzbxwvql2A79NzklDeSgA==',NULL,'{\"storage\":{\"upload_size_in_bytes\":300,\"media_size_in_bytes\":0,\"total\":300}}','2025-07-07 18:06:14','2025-07-08 08:16:02');
/*!40000 ALTER TABLE `tblperfex_saas_companies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblperfex_saas_packages`
--

DROP TABLE IF EXISTS `tblperfex_saas_packages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblperfex_saas_packages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `slug` varchar(150) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT 0.00,
  `bill_interval` varchar(150) DEFAULT NULL,
  `is_default` int(11) NOT NULL DEFAULT 0,
  `is_private` int(11) NOT NULL DEFAULT 0,
  `db_scheme` varchar(50) DEFAULT NULL,
  `db_pools` text DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `modules` text DEFAULT NULL,
  `metadata` text DEFAULT NULL COMMENT 'Extra data such as modules that are shown on package view list',
  `trial_period` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblperfex_saas_packages`
--

LOCK TABLES `tblperfex_saas_packages` WRITE;
/*!40000 ALTER TABLE `tblperfex_saas_packages` DISABLE KEYS */;
INSERT INTO `tblperfex_saas_packages` VALUES (1,'Starter Plan',NULL,'starter-plan',0.00,NULL,1,0,'mysql_root','08945c11f3860715cd78d519456bc6603a7cfb1005c7f5e7a0fc58725eeed43771b8481bdb2c5e415ff3321c6a62f494499e99c23554ffb3f69fac08afec8bdcIFyiEzUzVA/acs36PRGLPRS3ismWAqCWzH+lM09hcZg=',1,'[\"\",\"account_planning\",\"accounting\",\"affiliate_management\",\"appointly\",\"aws_integration\",\"exports\",\"loyalty\",\"backup\",\"facebook_leads_integration\",\"fixed_equipment\",\"goals\",\"si_lead_followup\",\"mailbox\",\"mailflow\",\"si_custom_status\",\"ma\",\"menu_setup\",\"mfa\",\"omni_sales\",\"project_roadmap\",\"purchase\",\"resource_workload\",\"surveys\",\"theme_style\",\"timesheets\",\"user_mention\",\"webhooks\"]','{\"invoice\":{\"recurring\":\"1\",\"repeat_every_custom\":\"1\",\"repeat_type_custom\":\"day\",\"allowed_payment_modes\":[\"1\"],\"sale_agent\":\"\"},\"client_theme\":\"single\",\"enable_subdomain\":\"1\",\"show_modules_list\":\"yes\",\"show_limits_on_package\":\"yes_3\",\"disabled_default_modules\":[\"\",\"contracts\",\"credit_notes\",\"custom_fields\",\"estimate_request\",\"estimates\",\"expenses\",\"invoices\",\"items\",\"knowledge_base\",\"leads\",\"payments\",\"projects\",\"proposals\",\"reports\",\"subscriptions\",\"tasks\",\"tickets\"],\"max_instance_limit\":\"1\",\"limitations_unit_price\":{\"tenant_instance\":\"\",\"staff\":\"1000\",\"clients\":\"1000\",\"contacts\":\"0\",\"contracts\":\"\",\"invoices\":\"1000\",\"estimates\":\"1000\",\"creditnotes\":\"\",\"proposals\":\"\",\"projects\":\"\",\"tasks\":\"\",\"tickets\":\"\",\"leads\":\"\",\"items\":\"2000\"},\"resource_limit_period\":\"billing_cycle\",\"limitations\":{\"staff\":\"3\",\"clients\":\"5\",\"contacts\":\"-1\",\"contracts\":\"-1\",\"invoices\":\"5\",\"estimates\":\"5\",\"creditnotes\":\"-1\",\"proposals\":\"-1\",\"projects\":\"2\",\"tasks\":\"10\",\"tickets\":\"-1\",\"leads\":\"-1\",\"items\":\"5\"},\"storage_limit\":{\"size\":\"1\",\"unit\":\"GB\",\"unit_price\":\"5000\"},\"dashboard_quota_visibility\":\"yes\",\"hidden_quota_widgets\":[\"\"],\"hidden_app_tabs\":{\"settings\":[\"\",\"admin-theme-settings\"],\"customer_profile\":[\"\",\"subscriptions\"],\"project\":[\"\"]},\"allow_customization\":\"yes\",\"disable_module_marketplace\":\"no\",\"disable_service_marketplace\":\"no\",\"assigned_clients\":[\"\"],\"seeding_tenant\":\"\",\"auto_remove_inactive_instance\":\"no\",\"auto_remove_inactive_instance_days\":\"30\",\"enable_custom_domain\":\"\",\"is_liftetime_deal\":\"\"}',7),(2,'Growth Plan','<p><strong>Ideal for growing businesses with expanding needs</strong></p>\n<p><strong>Everything in Starter, plus:</strong></p>\n<ul>\n<li>\n<p>Up to 10 users</p>\n</li>\n<li>\n<p>Custom Fields &amp; Roles</p>\n</li>\n<li>\n<p>Mobile App Access (iOS/Android)</p>\n</li>\n<li>\n<p>Automated Notifications &amp; Reminders</p>\n</li>\n<li>\n<p>API Access (Limited)</p>\n</li>\n<li>\n<p>10GB File Storage</p>\n</li>\n<li>\n<p>Basic Vision AI Tools (e.g., Attendance via Face Recognition)</p>\n</li>\n</ul>','growth-plan',12000.00,NULL,0,0,'mysql_root','b89df83e71a61e70306380976f90e87a8896d06d65b405193396c33712712f4a43eb02d95b437771d20cbcf4800b329101764d8874af3df038f57040cd190780GH1qtAMz00M5SWAWgRsm9psqRHeLqt5EQVNp5P6JvDs=',1,'[\"\",\"account_planning\",\"accounting\",\"affiliate_management\",\"appointly\",\"aws_integration\",\"exports\",\"loyalty\",\"backup\",\"facebook_leads_integration\",\"fixed_equipment\",\"fleet\",\"flexstage\",\"flexibackup\",\"goals\",\"hr_payroll\",\"hr_profile\",\"si_lead_followup\",\"mailbox\",\"mailflow\",\"si_custom_status\",\"manufacturing\",\"ma\",\"menu_setup\",\"mfa\",\"perfex_office_theme\",\"omni_sales\",\"project_roadmap\",\"purchase\",\"quickbooks_integration\",\"recruitment\",\"resource_workload\",\"surveys\",\"theme_style\",\"timesheets\",\"user_mention\",\"warehouse\",\"webhooks\",\"whatsapp_api\",\"whatsbot\"]','{\"invoice\":{\"recurring\":\"1\",\"repeat_every_custom\":\"1\",\"repeat_type_custom\":\"day\",\"allowed_payment_modes\":[\"1\"],\"sale_agent\":\"\"},\"client_theme\":\"single\",\"enable_subdomain\":\"1\",\"show_modules_list\":\"yes\",\"show_limits_on_package\":\"yes_3\",\"disabled_default_modules\":[\"\"],\"max_instance_limit\":\"1\",\"limitations_unit_price\":{\"tenant_instance\":\"\",\"staff\":\"\",\"clients\":\"\",\"contacts\":\"\",\"contracts\":\"\",\"invoices\":\"2000\",\"estimates\":\"\",\"creditnotes\":\"\",\"proposals\":\"\",\"projects\":\"\",\"tasks\":\"\",\"tickets\":\"\",\"leads\":\"\",\"items\":\"\"},\"resource_limit_period\":\"lifetime\",\"limitations\":{\"staff\":\"10\",\"clients\":\"15\",\"contacts\":\"-1\",\"contracts\":\"-1\",\"invoices\":\"100\",\"estimates\":\"100\",\"creditnotes\":\"-1\",\"proposals\":\"-1\",\"projects\":\"150\",\"tasks\":\"-1\",\"tickets\":\"-1\",\"leads\":\"-1\",\"items\":\"-1\"},\"storage_limit\":{\"size\":\"-1\",\"unit\":\"MB\",\"unit_price\":\"\"},\"dashboard_quota_visibility\":\"limited-only\",\"hidden_quota_widgets\":[\"\"],\"hidden_app_tabs\":{\"settings\":[\"\"],\"customer_profile\":[\"\"],\"project\":[\"\"]},\"allow_customization\":\"yes\",\"disable_module_marketplace\":\"no\",\"disable_service_marketplace\":\"no\",\"assigned_clients\":[\"\"],\"seeding_tenant\":\"\",\"auto_remove_inactive_instance\":\"no\",\"auto_remove_inactive_instance_days\":\"30\",\"enable_custom_domain\":\"\",\"is_liftetime_deal\":\"\"}',7),(3,'Business Pro Plan','<p><strong>Built for mid-sized enterprises needing automation &amp; AI</strong></p>\n<p><strong>Everything in Growth, plus:</strong></p>\n<ul>\n<li>\n<ul>\n<li>\n<p>Unlimited users (upto 15 )</p>\n</li>\n<li>\n<p>Advanced Modules (Project Mgmt, Asset Mgmt, Payroll)</p>\n</li>\n<li>\n<p>AI Reports &amp; Forecasting</p>\n</li>\n<li>\n<p>Advanced Vision AI Tools (e.g., Student/Employee Tracking, CCTV Monitoring Integration)</p>\n</li>\n<li>\n<p>Role-Based Access Control</p>\n</li>\n<li>\n<p>50GB File Storage</p>\n</li>\n<li>\n<p>Priority Support with WhatsApp</p>\n</li>\n</ul>\n</li>\n</ul>','growth_plan_3',18000.00,NULL,0,0,'mysql_root','dbb1e2b681f6636bb130e0db6740a1ac8ff6f3f907e518d24603ae52f4624b2e41a35ad6968df72763f52b15f46a5d854b49b3042df255868501586bcf7a06a5b80mHKbW6EX1d8ZO1U1i/JUSc2zu4yjlfDaluGlqLLE=',1,'[\"\",\"account_planning\",\"accounting\",\"affiliate_management\",\"appointly\",\"aws_integration\",\"exports\",\"loyalty\",\"backup\",\"facebook_leads_integration\",\"fixed_equipment\",\"fleet\",\"flexstage\",\"flexibackup\",\"goals\",\"hr_payroll\",\"hr_profile\",\"si_lead_followup\",\"mailbox\",\"mailflow\",\"si_custom_status\",\"manufacturing\",\"ma\",\"menu_setup\",\"mfa\",\"perfex_office_theme\",\"omni_sales\",\"project_roadmap\",\"purchase\",\"quickbooks_integration\",\"recruitment\",\"resource_workload\",\"surveys\",\"theme_style\",\"timesheets\",\"user_mention\",\"warehouse\",\"webhooks\",\"whatsapp_api\",\"whatsbot\"]','{\"invoice\":{\"recurring\":\"1\",\"repeat_every_custom\":\"1\",\"repeat_type_custom\":\"day\",\"allowed_payment_modes\":[\"1\"],\"sale_agent\":\"\"},\"client_theme\":\"single\",\"enable_subdomain\":\"1\",\"show_modules_list\":\"yes\",\"show_limits_on_package\":\"yes_3\",\"disabled_default_modules\":[\"\"],\"max_instance_limit\":\"1\",\"limitations_unit_price\":{\"tenant_instance\":\"\",\"staff\":\"\",\"clients\":\"\",\"contacts\":\"\",\"contracts\":\"\",\"invoices\":\"2000\",\"estimates\":\"\",\"creditnotes\":\"\",\"proposals\":\"\",\"projects\":\"\",\"tasks\":\"\",\"tickets\":\"\",\"leads\":\"\",\"items\":\"\"},\"resource_limit_period\":\"lifetime\",\"limitations\":{\"staff\":\"15\",\"clients\":\"150\",\"contacts\":\"-1\",\"contracts\":\"-1\",\"invoices\":\"150\",\"estimates\":\"148\",\"creditnotes\":\"-1\",\"proposals\":\"-1\",\"projects\":\"150\",\"tasks\":\"-1\",\"tickets\":\"-1\",\"leads\":\"-1\",\"items\":\"-1\"},\"storage_limit\":{\"size\":\"-1\",\"unit\":\"MB\",\"unit_price\":\"\"},\"dashboard_quota_visibility\":\"limited-only\",\"hidden_quota_widgets\":[\"\"],\"hidden_app_tabs\":{\"settings\":[\"\"],\"customer_profile\":[\"\"],\"project\":[\"\"]},\"allow_customization\":\"yes\",\"disable_module_marketplace\":\"no\",\"disable_service_marketplace\":\"no\",\"assigned_clients\":[\"\"],\"seeding_tenant\":\"\",\"auto_remove_inactive_instance\":\"no\",\"auto_remove_inactive_instance_days\":\"30\",\"enable_custom_domain\":\"\",\"is_liftetime_deal\":\"\"}',7),(4,'Enterprise AI Plan – Custom Pricing','<h3><strong>Enterprise AI Plan</strong> &#8211; Custom Pricing</h3>\n<p><strong>Tailored for large institutions or government projects</strong></p>\n<p><strong>Everything in Pro, plus:</strong></p>\n<ul>\n<li>\n<p>Custom Module Development</p>\n</li>\n<li>\n<p>Dedicated Account Manager</p>\n</li>\n<li>\n<p>White-labeled Solution</p>\n</li>\n<li>\n<p>On-Premise or Private Cloud Deployment</p>\n</li>\n<li>\n<p>99.9% SLA Guarantee</p>\n</li>\n<li>\n<p>Unlimited Storage</p>\n</li>\n<li>\n<p>Full Vision AI Suite + Audio/Voice Processing</p>\n</li>\n<li>\n<p>24x7 Dedicated Support &amp; Training</p>\n</li>\n</ul>','business_pro_plan_4',22000.00,NULL,0,0,'mysql_root','828cb35e4a329dc2dcb590ff249306914e8359663646be5ff48f204328221e1117b657ac59de40da094e40f7505a8b8fc3e58050b15abc81f3210ebbf06c34abXTfzeeK1rZHV0b36ZuEa+pEf0H+j0XZOvhUNJEvpwug=',1,'[\"\",\"account_planning\",\"accounting\",\"affiliate_management\",\"appointly\",\"aws_integration\",\"exports\",\"loyalty\",\"backup\",\"facebook_leads_integration\",\"fixed_equipment\",\"fleet\",\"flexstage\",\"flexibackup\",\"goals\",\"hr_payroll\",\"hr_profile\",\"si_lead_followup\",\"mailbox\",\"mailflow\",\"si_custom_status\",\"manufacturing\",\"ma\",\"menu_setup\",\"mfa\",\"perfex_office_theme\",\"omni_sales\",\"project_roadmap\",\"purchase\",\"quickbooks_integration\",\"recruitment\",\"resource_workload\",\"surveys\",\"theme_style\",\"timesheets\",\"user_mention\",\"warehouse\",\"webhooks\",\"whatsapp_api\",\"whatsbot\"]','{\"invoice\":{\"recurring\":\"1\",\"repeat_every_custom\":\"1\",\"repeat_type_custom\":\"day\",\"allowed_payment_modes\":[\"1\"],\"sale_agent\":\"\"},\"client_theme\":\"single\",\"enable_subdomain\":\"1\",\"show_modules_list\":\"yes\",\"show_limits_on_package\":\"yes_3\",\"disabled_default_modules\":[\"\"],\"max_instance_limit\":\"1\",\"limitations_unit_price\":{\"tenant_instance\":\"\",\"staff\":\"\",\"clients\":\"\",\"contacts\":\"\",\"contracts\":\"\",\"invoices\":\"2000\",\"estimates\":\"\",\"creditnotes\":\"\",\"proposals\":\"\",\"projects\":\"\",\"tasks\":\"\",\"tickets\":\"\",\"leads\":\"\",\"items\":\"\"},\"resource_limit_period\":\"lifetime\",\"limitations\":{\"staff\":\"20\",\"clients\":\"200\",\"contacts\":\"-1\",\"contracts\":\"-1\",\"invoices\":\"200\",\"estimates\":\"200\",\"creditnotes\":\"-1\",\"proposals\":\"-1\",\"projects\":\"200\",\"tasks\":\"1000\",\"tickets\":\"-1\",\"leads\":\"-1\",\"items\":\"1000\"},\"storage_limit\":{\"size\":\"-1\",\"unit\":\"MB\",\"unit_price\":\"\"},\"dashboard_quota_visibility\":\"limited-only\",\"hidden_quota_widgets\":[\"\"],\"hidden_app_tabs\":{\"settings\":[\"\"],\"customer_profile\":[\"\"],\"project\":[\"\"]},\"allow_customization\":\"yes\",\"disable_module_marketplace\":\"no\",\"disable_service_marketplace\":\"no\",\"assigned_clients\":[\"\"],\"seeding_tenant\":\"\",\"auto_remove_inactive_instance\":\"no\",\"auto_remove_inactive_instance_days\":\"30\",\"enable_custom_domain\":\"\",\"is_liftetime_deal\":\"\"}',7);
/*!40000 ALTER TABLE `tblperfex_saas_packages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblpinned_projects`
--

DROP TABLE IF EXISTS `tblpinned_projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblpinned_projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblpinned_projects`
--

LOCK TABLES `tblpinned_projects` WRITE;
/*!40000 ALTER TABLE `tblpinned_projects` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblpinned_projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblposition_training_question_form`
--

DROP TABLE IF EXISTS `tblposition_training_question_form`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblposition_training_question_form` (
  `questionid` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) DEFAULT NULL,
  `question` mediumtext NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT 0,
  `question_order` int(11) NOT NULL,
  `point` int(11) NOT NULL,
  PRIMARY KEY (`questionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblposition_training_question_form`
--

LOCK TABLES `tblposition_training_question_form` WRITE;
/*!40000 ALTER TABLE `tblposition_training_question_form` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblposition_training_question_form` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblproject_activity`
--

DROP TABLE IF EXISTS `tblproject_activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblproject_activity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL DEFAULT 0,
  `contact_id` int(11) NOT NULL DEFAULT 0,
  `fullname` varchar(100) DEFAULT NULL,
  `visible_to_customer` int(11) NOT NULL DEFAULT 0,
  `description_key` varchar(191) NOT NULL COMMENT 'Language file key',
  `additional_data` mediumtext DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblproject_activity`
--

LOCK TABLES `tblproject_activity` WRITE;
/*!40000 ALTER TABLE `tblproject_activity` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblproject_activity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblproject_files`
--

DROP TABLE IF EXISTS `tblproject_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblproject_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file_name` varchar(191) NOT NULL,
  `original_file_name` longtext DEFAULT NULL,
  `subject` varchar(191) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `filetype` varchar(50) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  `last_activity` datetime DEFAULT NULL,
  `project_id` int(11) NOT NULL,
  `visible_to_customer` tinyint(1) DEFAULT 0,
  `staffid` int(11) NOT NULL,
  `contact_id` int(11) NOT NULL DEFAULT 0,
  `external` varchar(40) DEFAULT NULL,
  `external_link` mediumtext DEFAULT NULL,
  `thumbnail_link` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblproject_files`
--

LOCK TABLES `tblproject_files` WRITE;
/*!40000 ALTER TABLE `tblproject_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblproject_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblproject_members`
--

DROP TABLE IF EXISTS `tblproject_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblproject_members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`),
  KEY `staff_id` (`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblproject_members`
--

LOCK TABLES `tblproject_members` WRITE;
/*!40000 ALTER TABLE `tblproject_members` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblproject_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblproject_notes`
--

DROP TABLE IF EXISTS `tblproject_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblproject_notes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `content` mediumtext NOT NULL,
  `staff_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblproject_notes`
--

LOCK TABLES `tblproject_notes` WRITE;
/*!40000 ALTER TABLE `tblproject_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblproject_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblproject_settings`
--

DROP TABLE IF EXISTS `tblproject_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblproject_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `value` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblproject_settings`
--

LOCK TABLES `tblproject_settings` WRITE;
/*!40000 ALTER TABLE `tblproject_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblproject_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblprojectdiscussioncomments`
--

DROP TABLE IF EXISTS `tblprojectdiscussioncomments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblprojectdiscussioncomments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `discussion_id` int(11) NOT NULL,
  `discussion_type` varchar(10) NOT NULL,
  `parent` int(11) DEFAULT NULL,
  `created` datetime NOT NULL,
  `modified` datetime DEFAULT NULL,
  `content` mediumtext NOT NULL,
  `staff_id` int(11) NOT NULL,
  `contact_id` int(11) DEFAULT 0,
  `fullname` varchar(191) DEFAULT NULL,
  `file_name` varchar(191) DEFAULT NULL,
  `file_mime_type` varchar(70) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblprojectdiscussioncomments`
--

LOCK TABLES `tblprojectdiscussioncomments` WRITE;
/*!40000 ALTER TABLE `tblprojectdiscussioncomments` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblprojectdiscussioncomments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblprojectdiscussions`
--

DROP TABLE IF EXISTS `tblprojectdiscussions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblprojectdiscussions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `subject` varchar(191) NOT NULL,
  `description` mediumtext NOT NULL,
  `show_to_customer` tinyint(1) NOT NULL DEFAULT 0,
  `datecreated` datetime NOT NULL,
  `last_activity` datetime DEFAULT NULL,
  `staff_id` int(11) NOT NULL DEFAULT 0,
  `contact_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblprojectdiscussions`
--

LOCK TABLES `tblprojectdiscussions` WRITE;
/*!40000 ALTER TABLE `tblprojectdiscussions` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblprojectdiscussions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblprojects`
--

DROP TABLE IF EXISTS `tblprojects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblprojects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `clientid` int(11) NOT NULL,
  `billing_type` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `deadline` date DEFAULT NULL,
  `project_created` date NOT NULL,
  `date_finished` datetime DEFAULT NULL,
  `progress` int(11) DEFAULT 0,
  `progress_from_tasks` int(11) NOT NULL DEFAULT 1,
  `project_cost` decimal(15,2) DEFAULT NULL,
  `project_rate_per_hour` decimal(15,2) DEFAULT NULL,
  `estimated_hours` decimal(15,2) DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `contact_notification` int(11) DEFAULT 1,
  `notify_contacts` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblprojects`
--

LOCK TABLES `tblprojects` WRITE;
/*!40000 ALTER TABLE `tblprojects` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblprojects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblproposal_comments`
--

DROP TABLE IF EXISTS `tblproposal_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblproposal_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` longtext DEFAULT NULL,
  `proposalid` int(11) NOT NULL,
  `staffid` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblproposal_comments`
--

LOCK TABLES `tblproposal_comments` WRITE;
/*!40000 ALTER TABLE `tblproposal_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblproposal_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblproposals`
--

DROP TABLE IF EXISTS `tblproposals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblproposals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(191) DEFAULT NULL,
  `content` longtext DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `datecreated` datetime NOT NULL,
  `total` decimal(15,2) DEFAULT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `total_tax` decimal(15,2) NOT NULL DEFAULT 0.00,
  `adjustment` decimal(15,2) DEFAULT NULL,
  `discount_percent` decimal(15,2) NOT NULL,
  `discount_total` decimal(15,2) NOT NULL,
  `discount_type` varchar(30) DEFAULT NULL,
  `show_quantity_as` int(11) NOT NULL DEFAULT 1,
  `currency` int(11) NOT NULL,
  `open_till` date DEFAULT NULL,
  `date` date NOT NULL,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(40) DEFAULT NULL,
  `assigned` int(11) DEFAULT NULL,
  `hash` varchar(32) NOT NULL,
  `proposal_to` varchar(191) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  `country` int(11) NOT NULL DEFAULT 0,
  `zip` varchar(50) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `allow_comments` tinyint(1) NOT NULL DEFAULT 1,
  `status` int(11) NOT NULL,
  `estimate_id` int(11) DEFAULT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `date_converted` datetime DEFAULT NULL,
  `pipeline_order` int(11) DEFAULT 1,
  `is_expiry_notified` int(11) NOT NULL DEFAULT 0,
  `acceptance_firstname` varchar(50) DEFAULT NULL,
  `acceptance_lastname` varchar(50) DEFAULT NULL,
  `acceptance_email` varchar(100) DEFAULT NULL,
  `acceptance_date` datetime DEFAULT NULL,
  `acceptance_ip` varchar(40) DEFAULT NULL,
  `signature` varchar(40) DEFAULT NULL,
  `short_link` varchar(100) DEFAULT NULL,
  `processing` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblproposals`
--

LOCK TABLES `tblproposals` WRITE;
/*!40000 ALTER TABLE `tblproposals` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblproposals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblpur_activity_log`
--

DROP TABLE IF EXISTS `tblpur_activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblpur_activity_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(45) NOT NULL,
  `staffid` int(11) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `note` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblpur_activity_log`
--

LOCK TABLES `tblpur_activity_log` WRITE;
/*!40000 ALTER TABLE `tblpur_activity_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblpur_activity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblpur_approval_details`
--

DROP TABLE IF EXISTS `tblpur_approval_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblpur_approval_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(45) NOT NULL,
  `staffid` varchar(45) DEFAULT NULL,
  `approve` varchar(45) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `approve_action` varchar(255) DEFAULT NULL,
  `reject_action` varchar(255) DEFAULT NULL,
  `approve_value` varchar(255) DEFAULT NULL,
  `reject_value` varchar(255) DEFAULT NULL,
  `staff_approve` int(11) DEFAULT NULL,
  `action` varchar(45) DEFAULT NULL,
  `sender` int(11) DEFAULT NULL,
  `date_send` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblpur_approval_details`
--

LOCK TABLES `tblpur_approval_details` WRITE;
/*!40000 ALTER TABLE `tblpur_approval_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblpur_approval_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblpur_approval_setting`
--

DROP TABLE IF EXISTS `tblpur_approval_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblpur_approval_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `related` varchar(255) NOT NULL,
  `setting` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblpur_approval_setting`
--

LOCK TABLES `tblpur_approval_setting` WRITE;
/*!40000 ALTER TABLE `tblpur_approval_setting` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblpur_approval_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblpur_comments`
--

DROP TABLE IF EXISTS `tblpur_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblpur_comments` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `content` mediumtext DEFAULT NULL,
  `rel_type` varchar(50) NOT NULL,
  `rel_id` int(11) DEFAULT NULL,
  `staffid` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblpur_comments`
--

LOCK TABLES `tblpur_comments` WRITE;
/*!40000 ALTER TABLE `tblpur_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblpur_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblpur_contacts`
--

DROP TABLE IF EXISTS `tblpur_contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblpur_contacts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `is_primary` int(11) NOT NULL DEFAULT 1,
  `firstname` varchar(191) NOT NULL,
  `lastname` varchar(191) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phonenumber` varchar(100) NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `new_pass_key` varchar(32) DEFAULT NULL,
  `new_pass_key_requested` datetime DEFAULT NULL,
  `email_verified_at` datetime DEFAULT NULL,
  `email_verification_key` varchar(32) DEFAULT NULL,
  `email_verification_sent_at` datetime DEFAULT NULL,
  `last_ip` varchar(40) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_password_change` datetime DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `profile_image` varchar(191) DEFAULT NULL,
  `direction` varchar(3) DEFAULT NULL,
  `invoice_emails` tinyint(1) NOT NULL DEFAULT 1,
  `estimate_emails` tinyint(1) NOT NULL DEFAULT 1,
  `credit_note_emails` tinyint(1) NOT NULL DEFAULT 1,
  `contract_emails` tinyint(1) NOT NULL DEFAULT 1,
  `task_emails` tinyint(1) NOT NULL DEFAULT 1,
  `project_emails` tinyint(1) NOT NULL DEFAULT 1,
  `ticket_emails` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblpur_contacts`
--

LOCK TABLES `tblpur_contacts` WRITE;
/*!40000 ALTER TABLE `tblpur_contacts` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblpur_contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblpur_contracts`
--

DROP TABLE IF EXISTS `tblpur_contracts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblpur_contracts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `contract_number` varchar(200) NOT NULL,
  `contract_name` varchar(200) NOT NULL,
  `content` longtext DEFAULT NULL,
  `vendor` int(11) NOT NULL,
  `pur_order` int(11) NOT NULL,
  `contract_value` decimal(15,2) DEFAULT NULL,
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `buyer` int(11) DEFAULT NULL,
  `time_payment` date DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  `signed` int(32) NOT NULL DEFAULT 0,
  `note` longtext DEFAULT NULL,
  `signer` int(11) DEFAULT NULL,
  `signed_date` date DEFAULT NULL,
  `signed_status` varchar(50) DEFAULT NULL,
  `service_category` text DEFAULT NULL,
  `project` int(11) DEFAULT NULL,
  `payment_terms` text DEFAULT NULL,
  `payment_amount` decimal(15,2) DEFAULT NULL,
  `payment_cycle` varchar(50) DEFAULT NULL,
  `department` int(11) DEFAULT NULL,
  `signature` text DEFAULT NULL,
  `marked_as_signed` tinyint(1) DEFAULT 0,
  `acceptance_firstname` text DEFAULT NULL,
  `acceptance_lastname` text DEFAULT NULL,
  `acceptance_email` text DEFAULT NULL,
  `acceptance_date` datetime DEFAULT NULL,
  `acceptance_ip` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblpur_contracts`
--

LOCK TABLES `tblpur_contracts` WRITE;
/*!40000 ALTER TABLE `tblpur_contracts` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblpur_contracts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblpur_debit_notes`
--

DROP TABLE IF EXISTS `tblpur_debit_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblpur_debit_notes` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `vendorid` int(11) DEFAULT NULL,
  `deleted_vendor_name` varchar(100) DEFAULT NULL,
  `number` int(11) DEFAULT NULL,
  `prefix` varchar(50) DEFAULT NULL,
  `number_format` int(11) DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `date` date DEFAULT NULL,
  `adminnote` text DEFAULT NULL,
  `terms` text DEFAULT NULL,
  `vendornote` text DEFAULT NULL,
  `currency` int(11) DEFAULT NULL,
  `subtotal` decimal(15,2) DEFAULT NULL,
  `total_tax` decimal(15,2) DEFAULT NULL,
  `total` decimal(15,2) DEFAULT NULL,
  `adjustment` decimal(15,2) DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `discount_percent` decimal(15,2) DEFAULT NULL,
  `discount_total` decimal(15,2) DEFAULT NULL,
  `discount_type` varchar(30) DEFAULT NULL,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT NULL,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT NULL,
  `include_shipping` tinyint(1) DEFAULT NULL,
  `show_shipping_on_debit_note` tinyint(1) DEFAULT NULL,
  `show_quantity_as` int(11) DEFAULT NULL,
  `reference_no` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblpur_debit_notes`
--

LOCK TABLES `tblpur_debit_notes` WRITE;
/*!40000 ALTER TABLE `tblpur_debit_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblpur_debit_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblpur_debits`
--

DROP TABLE IF EXISTS `tblpur_debits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblpur_debits` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) DEFAULT NULL,
  `debit_id` int(11) DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `date_applied` datetime DEFAULT NULL,
  `date` date DEFAULT NULL,
  `amount` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblpur_debits`
--

LOCK TABLES `tblpur_debits` WRITE;
/*!40000 ALTER TABLE `tblpur_debits` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblpur_debits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblpur_debits_refunds`
--

DROP TABLE IF EXISTS `tblpur_debits_refunds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblpur_debits_refunds` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `debit_note_id` int(11) DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `refunded_on` date DEFAULT NULL,
  `payment_mode` varchar(40) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `amount` decimal(15,2) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblpur_debits_refunds`
--

LOCK TABLES `tblpur_debits_refunds` WRITE;
/*!40000 ALTER TABLE `tblpur_debits_refunds` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblpur_debits_refunds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblpur_estimate_detail`
--

DROP TABLE IF EXISTS `tblpur_estimate_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblpur_estimate_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pur_estimate` int(11) NOT NULL,
  `item_code` varchar(100) NOT NULL,
  `unit_id` int(11) DEFAULT NULL,
  `unit_price` decimal(15,2) DEFAULT NULL,
  `quantity` decimal(15,2) NOT NULL,
  `into_money` decimal(15,2) DEFAULT NULL,
  `tax` text DEFAULT NULL,
  `total` decimal(15,2) DEFAULT NULL,
  `total_money` decimal(15,2) DEFAULT NULL,
  `discount_money` decimal(15,2) DEFAULT NULL,
  `discount_%` decimal(15,2) DEFAULT NULL,
  `tax_value` decimal(15,2) DEFAULT NULL,
  `tax_rate` text DEFAULT NULL,
  `tax_name` text DEFAULT NULL,
  `item_name` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblpur_estimate_detail`
--

LOCK TABLES `tblpur_estimate_detail` WRITE;
/*!40000 ALTER TABLE `tblpur_estimate_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblpur_estimate_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblpur_estimates`
--

DROP TABLE IF EXISTS `tblpur_estimates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblpur_estimates` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sent` tinyint(1) NOT NULL DEFAULT 0,
  `datesend` datetime DEFAULT NULL,
  `vendor` int(11) NOT NULL,
  `deleted_vendor_name` varchar(100) DEFAULT NULL,
  `pur_request` int(11) DEFAULT NULL,
  `number` int(11) NOT NULL,
  `prefix` varchar(50) DEFAULT NULL,
  `number_format` int(11) NOT NULL DEFAULT 0,
  `hash` varchar(32) DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `date` date NOT NULL,
  `expirydate` date DEFAULT NULL,
  `currency` int(11) NOT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `total_tax` decimal(15,2) NOT NULL,
  `total` decimal(15,2) NOT NULL,
  `adjustment` decimal(15,2) DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `vendornote` text DEFAULT NULL,
  `adminnote` text DEFAULT NULL,
  `discount_percent` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `discount_type` varchar(30) DEFAULT NULL,
  `invoiceid` int(11) DEFAULT NULL,
  `invoiced_date` datetime DEFAULT NULL,
  `terms` text DEFAULT NULL,
  `reference_no` varchar(100) DEFAULT NULL,
  `buyer` int(11) NOT NULL DEFAULT 0,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT NULL,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT NULL,
  `include_shipping` tinyint(1) NOT NULL,
  `show_shipping_on_estimate` tinyint(1) NOT NULL DEFAULT 1,
  `show_quantity_as` int(11) NOT NULL DEFAULT 1,
  `pipeline_order` int(11) NOT NULL DEFAULT 0,
  `is_expiry_notified` int(11) NOT NULL DEFAULT 0,
  `acceptance_firstname` varchar(50) DEFAULT NULL,
  `acceptance_lastname` varchar(50) DEFAULT NULL,
  `acceptance_email` varchar(100) DEFAULT NULL,
  `acceptance_date` datetime DEFAULT NULL,
  `acceptance_ip` varchar(40) DEFAULT NULL,
  `signature` varchar(40) DEFAULT NULL,
  `make_a_contract` text DEFAULT NULL,
  `currency_rate` decimal(15,6) DEFAULT NULL,
  `from_currency` varchar(20) DEFAULT NULL,
  `to_currency` varchar(20) DEFAULT NULL,
  `shipping_fee` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblpur_estimates`
--

LOCK TABLES `tblpur_estimates` WRITE;
/*!40000 ALTER TABLE `tblpur_estimates` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblpur_estimates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblpur_invoice_details`
--

DROP TABLE IF EXISTS `tblpur_invoice_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblpur_invoice_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pur_invoice` int(11) NOT NULL,
  `item_code` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `unit_id` int(11) DEFAULT NULL,
  `unit_price` decimal(15,2) DEFAULT NULL,
  `quantity` decimal(15,2) DEFAULT NULL,
  `into_money` decimal(15,2) DEFAULT NULL,
  `tax` text DEFAULT NULL,
  `total` decimal(15,2) DEFAULT NULL,
  `discount_percent` decimal(15,2) DEFAULT NULL,
  `discount_money` decimal(15,2) DEFAULT NULL,
  `total_money` decimal(15,2) DEFAULT NULL,
  `tax_value` decimal(15,2) DEFAULT NULL,
  `tax_rate` text DEFAULT NULL,
  `tax_name` text DEFAULT NULL,
  `item_name` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblpur_invoice_details`
--

LOCK TABLES `tblpur_invoice_details` WRITE;
/*!40000 ALTER TABLE `tblpur_invoice_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblpur_invoice_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblpur_invoice_payment`
--

DROP TABLE IF EXISTS `tblpur_invoice_payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblpur_invoice_payment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pur_invoice` int(11) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `paymentmode` longtext DEFAULT NULL,
  `date` date NOT NULL,
  `daterecorded` datetime NOT NULL,
  `note` text NOT NULL,
  `transactionid` mediumtext DEFAULT NULL,
  `approval_status` int(2) DEFAULT NULL,
  `requester` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblpur_invoice_payment`
--

LOCK TABLES `tblpur_invoice_payment` WRITE;
/*!40000 ALTER TABLE `tblpur_invoice_payment` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblpur_invoice_payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblpur_invoices`
--

DROP TABLE IF EXISTS `tblpur_invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblpur_invoices` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `number` int(11) NOT NULL,
  `invoice_number` text DEFAULT NULL,
  `invoice_date` date DEFAULT NULL,
  `subtotal` decimal(15,2) DEFAULT NULL,
  `tax_rate` int(11) DEFAULT NULL,
  `tax` decimal(15,2) DEFAULT NULL,
  `total` decimal(15,2) DEFAULT NULL,
  `contract` int(11) DEFAULT NULL,
  `vendor` int(11) DEFAULT NULL,
  `transactionid` mediumtext DEFAULT NULL,
  `transaction_date` date DEFAULT NULL,
  `payment_request_status` varchar(30) DEFAULT NULL,
  `payment_status` varchar(30) DEFAULT NULL,
  `vendor_note` text DEFAULT NULL,
  `adminnote` text DEFAULT NULL,
  `terms` text DEFAULT NULL,
  `add_from` int(11) DEFAULT NULL,
  `date_add` date DEFAULT NULL,
  `pur_order` int(11) DEFAULT NULL,
  `recurring` int(11) DEFAULT NULL,
  `recurring_type` varchar(10) DEFAULT NULL,
  `cycles` int(11) DEFAULT 0,
  `total_cycles` int(11) DEFAULT 0,
  `last_recurring_date` date DEFAULT NULL,
  `is_recurring_from` int(11) DEFAULT NULL,
  `duedate` date DEFAULT NULL,
  `add_from_type` varchar(20) DEFAULT NULL,
  `currency` int(11) DEFAULT 0,
  `discount_total` decimal(15,2) DEFAULT NULL,
  `discount_percent` decimal(15,2) DEFAULT NULL,
  `currency_rate` decimal(15,6) DEFAULT NULL,
  `from_currency` varchar(20) DEFAULT NULL,
  `to_currency` varchar(20) DEFAULT NULL,
  `shipping_fee` decimal(15,2) DEFAULT NULL,
  `vendor_invoice_number` text DEFAULT NULL,
  `discount_type` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblpur_invoices`
--

LOCK TABLES `tblpur_invoices` WRITE;
/*!40000 ALTER TABLE `tblpur_invoices` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblpur_invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblpur_order_detail`
--

DROP TABLE IF EXISTS `tblpur_order_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblpur_order_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pur_order` int(11) NOT NULL,
  `item_code` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `unit_id` int(11) DEFAULT NULL,
  `unit_price` decimal(15,2) DEFAULT NULL,
  `quantity` decimal(15,2) NOT NULL,
  `into_money` decimal(15,2) DEFAULT NULL,
  `tax` text DEFAULT NULL,
  `total` decimal(15,2) DEFAULT NULL,
  `discount_%` decimal(15,2) DEFAULT NULL,
  `discount_money` decimal(15,2) DEFAULT NULL,
  `total_money` decimal(15,2) DEFAULT NULL,
  `tax_value` decimal(15,2) DEFAULT NULL,
  `tax_rate` text DEFAULT NULL,
  `tax_name` text DEFAULT NULL,
  `item_name` text DEFAULT NULL,
  `wh_quantity_received` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblpur_order_detail`
--

LOCK TABLES `tblpur_order_detail` WRITE;
/*!40000 ALTER TABLE `tblpur_order_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblpur_order_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblpur_order_payment`
--

DROP TABLE IF EXISTS `tblpur_order_payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblpur_order_payment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pur_order` int(11) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `paymentmode` longtext DEFAULT NULL,
  `date` date NOT NULL,
  `daterecorded` datetime NOT NULL,
  `note` text NOT NULL,
  `transactionid` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblpur_order_payment`
--

LOCK TABLES `tblpur_order_payment` WRITE;
/*!40000 ALTER TABLE `tblpur_order_payment` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblpur_order_payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblpur_orders`
--

DROP TABLE IF EXISTS `tblpur_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblpur_orders` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pur_order_name` varchar(100) NOT NULL,
  `vendor` int(11) NOT NULL,
  `estimate` int(11) NOT NULL,
  `pur_order_number` varchar(30) NOT NULL,
  `order_date` date NOT NULL,
  `status` int(32) NOT NULL DEFAULT 1,
  `approve_status` int(32) NOT NULL DEFAULT 1,
  `datecreated` datetime NOT NULL,
  `days_owed` int(11) NOT NULL,
  `delivery_date` date DEFAULT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `total_tax` decimal(15,2) NOT NULL,
  `total` decimal(15,2) NOT NULL,
  `addedfrom` int(11) NOT NULL,
  `vendornote` text DEFAULT NULL,
  `terms` text DEFAULT NULL,
  `discount_percent` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `discount_type` varchar(30) DEFAULT NULL,
  `buyer` int(11) NOT NULL DEFAULT 0,
  `status_goods` int(11) NOT NULL DEFAULT 0,
  `number` int(11) DEFAULT NULL,
  `expense_convert` int(11) DEFAULT 0,
  `hash` varchar(32) DEFAULT NULL,
  `clients` text DEFAULT NULL,
  `delivery_status` int(2) DEFAULT 0,
  `type` text DEFAULT NULL,
  `project` int(11) DEFAULT NULL,
  `pur_request` int(11) DEFAULT NULL,
  `department` int(11) DEFAULT NULL,
  `tax_order_rate` decimal(15,2) DEFAULT NULL,
  `tax_order_amount` decimal(15,2) DEFAULT NULL,
  `sale_invoice` int(11) DEFAULT NULL,
  `currency` int(11) DEFAULT 0,
  `order_status` varchar(30) DEFAULT NULL,
  `shipping_note` text DEFAULT NULL,
  `currency_rate` decimal(15,6) DEFAULT NULL,
  `from_currency` varchar(20) DEFAULT NULL,
  `to_currency` varchar(20) DEFAULT NULL,
  `shipping_fee` decimal(15,2) DEFAULT NULL,
  `shipping_address` text DEFAULT NULL,
  `shipping_city` text DEFAULT NULL,
  `shipping_state` text DEFAULT NULL,
  `shipping_zip` text DEFAULT NULL,
  `shipping_country` int(11) DEFAULT NULL,
  `shipping_country_text` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblpur_orders`
--

LOCK TABLES `tblpur_orders` WRITE;
/*!40000 ALTER TABLE `tblpur_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblpur_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblpur_request`
--

DROP TABLE IF EXISTS `tblpur_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblpur_request` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pur_rq_code` varchar(45) NOT NULL,
  `pur_rq_name` varchar(100) NOT NULL,
  `rq_description` text DEFAULT NULL,
  `requester` int(11) NOT NULL,
  `department` int(11) DEFAULT NULL,
  `request_date` datetime NOT NULL,
  `status` int(11) DEFAULT NULL,
  `status_goods` int(11) NOT NULL DEFAULT 0,
  `hash` varchar(32) DEFAULT NULL,
  `type` text DEFAULT NULL,
  `project` int(11) DEFAULT NULL,
  `number` int(11) DEFAULT NULL,
  `from_items` int(2) DEFAULT 1,
  `subtotal` decimal(15,2) DEFAULT NULL,
  `total_tax` decimal(15,2) DEFAULT NULL,
  `total` decimal(15,2) DEFAULT NULL,
  `sale_invoice` int(11) DEFAULT NULL,
  `compare_note` text DEFAULT NULL,
  `send_to_vendors` text DEFAULT NULL,
  `currency` int(11) DEFAULT 0,
  `currency_rate` decimal(15,6) DEFAULT NULL,
  `from_currency` varchar(20) DEFAULT NULL,
  `to_currency` varchar(20) DEFAULT NULL,
  `sale_estimate` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblpur_request`
--

LOCK TABLES `tblpur_request` WRITE;
/*!40000 ALTER TABLE `tblpur_request` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblpur_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblpur_request_detail`
--

DROP TABLE IF EXISTS `tblpur_request_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblpur_request_detail` (
  `prd_id` int(11) NOT NULL AUTO_INCREMENT,
  `pur_request` int(11) NOT NULL,
  `item_code` varchar(100) NOT NULL,
  `unit_id` int(11) DEFAULT NULL,
  `unit_price` decimal(15,2) DEFAULT NULL,
  `quantity` decimal(15,2) NOT NULL,
  `into_money` decimal(15,2) DEFAULT NULL,
  `inventory_quantity` int(11) DEFAULT 0,
  `item_text` text DEFAULT NULL,
  `tax` text DEFAULT NULL,
  `tax_rate` text DEFAULT NULL,
  `tax_value` decimal(15,2) DEFAULT NULL,
  `total` decimal(15,2) DEFAULT NULL,
  `tax_name` text DEFAULT NULL,
  PRIMARY KEY (`prd_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblpur_request_detail`
--

LOCK TABLES `tblpur_request_detail` WRITE;
/*!40000 ALTER TABLE `tblpur_request_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblpur_request_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblpur_unit`
--

DROP TABLE IF EXISTS `tblpur_unit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblpur_unit` (
  `unit_id` int(11) NOT NULL AUTO_INCREMENT,
  `unit_name` varchar(100) NOT NULL,
  PRIMARY KEY (`unit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblpur_unit`
--

LOCK TABLES `tblpur_unit` WRITE;
/*!40000 ALTER TABLE `tblpur_unit` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblpur_unit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblpur_vendor`
--

DROP TABLE IF EXISTS `tblpur_vendor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblpur_vendor` (
  `userid` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `company` varchar(200) DEFAULT NULL,
  `vat` varchar(200) DEFAULT NULL,
  `phonenumber` varchar(30) DEFAULT NULL,
  `country` int(11) NOT NULL DEFAULT 0,
  `city` varchar(100) DEFAULT NULL,
  `zip` varchar(15) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `website` varchar(150) DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `active` int(11) NOT NULL DEFAULT 1,
  `leadid` int(11) DEFAULT NULL,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT 0,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT 0,
  `longitude` varchar(191) DEFAULT NULL,
  `latitude` varchar(191) DEFAULT NULL,
  `default_language` varchar(40) DEFAULT NULL,
  `default_currency` int(11) NOT NULL DEFAULT 0,
  `show_primary_contact` int(11) NOT NULL DEFAULT 0,
  `stripe_id` varchar(40) DEFAULT NULL,
  `registration_confirmed` int(11) NOT NULL DEFAULT 1,
  `addedfrom` int(11) NOT NULL DEFAULT 0,
  `category` text DEFAULT NULL,
  `bank_detail` text DEFAULT NULL,
  `payment_terms` text DEFAULT NULL,
  `vendor_code` varchar(100) DEFAULT NULL,
  `return_within_day` int(11) DEFAULT NULL,
  `return_order_fee` decimal(15,2) DEFAULT NULL,
  `return_policies` text DEFAULT NULL,
  `balance` decimal(15,2) DEFAULT NULL,
  `balance_as_of` date DEFAULT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblpur_vendor`
--

LOCK TABLES `tblpur_vendor` WRITE;
/*!40000 ALTER TABLE `tblpur_vendor` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblpur_vendor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblpur_vendor_admin`
--

DROP TABLE IF EXISTS `tblpur_vendor_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblpur_vendor_admin` (
  `staff_id` int(11) NOT NULL,
  `vendor_id` int(11) NOT NULL,
  `date_assigned` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblpur_vendor_admin`
--

LOCK TABLES `tblpur_vendor_admin` WRITE;
/*!40000 ALTER TABLE `tblpur_vendor_admin` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblpur_vendor_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblpur_vendor_cate`
--

DROP TABLE IF EXISTS `tblpur_vendor_cate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblpur_vendor_cate` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblpur_vendor_cate`
--

LOCK TABLES `tblpur_vendor_cate` WRITE;
/*!40000 ALTER TABLE `tblpur_vendor_cate` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblpur_vendor_cate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblpur_vendor_items`
--

DROP TABLE IF EXISTS `tblpur_vendor_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblpur_vendor_items` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `vendor` int(11) NOT NULL,
  `group_items` int(11) DEFAULT NULL,
  `items` int(11) NOT NULL,
  `add_from` int(11) DEFAULT NULL,
  `datecreate` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblpur_vendor_items`
--

LOCK TABLES `tblpur_vendor_items` WRITE;
/*!40000 ALTER TABLE `tblpur_vendor_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblpur_vendor_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblpurchase_option`
--

DROP TABLE IF EXISTS `tblpurchase_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblpurchase_option` (
  `option_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(200) NOT NULL,
  `option_val` longtext DEFAULT NULL,
  `auto` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`option_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblpurchase_option`
--

LOCK TABLES `tblpurchase_option` WRITE;
/*!40000 ALTER TABLE `tblpurchase_option` DISABLE KEYS */;
INSERT INTO `tblpurchase_option` VALUES (1,'purchase_order_setting','1',1),(2,'pur_order_prefix','#PO',1),(3,'next_po_number','1',1),(4,'date_reset_number','',1),(5,'pur_request_prefix','#PR',1),(6,'next_pr_number','1',1),(7,'date_reset_pr_number','',1),(8,'pur_inv_prefix','#INV',1),(9,'next_inv_number','1',1),(10,'create_invoice_by','contract',1),(11,'item_by_vendor','0',1),(12,'terms_and_conditions','',1),(13,'vendor_note','',1);
/*!40000 ALTER TABLE `tblpurchase_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblrec_activity_log`
--

DROP TABLE IF EXISTS `tblrec_activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblrec_activity_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(100) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `additional_data` text DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `staffid` int(11) DEFAULT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblrec_activity_log`
--

LOCK TABLES `tblrec_activity_log` WRITE;
/*!40000 ALTER TABLE `tblrec_activity_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblrec_activity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblrec_applied_jobs`
--

DROP TABLE IF EXISTS `tblrec_applied_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblrec_applied_jobs` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `candidate_id` int(11) DEFAULT NULL,
  `campaign_id` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `status` text DEFAULT NULL,
  `activate` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblrec_applied_jobs`
--

LOCK TABLES `tblrec_applied_jobs` WRITE;
/*!40000 ALTER TABLE `tblrec_applied_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblrec_applied_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblrec_campaign`
--

DROP TABLE IF EXISTS `tblrec_campaign`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblrec_campaign` (
  `cp_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `campaign_code` varchar(200) NOT NULL,
  `campaign_name` varchar(200) NOT NULL,
  `cp_proposal` text DEFAULT NULL,
  `cp_position` int(11) NOT NULL,
  `cp_department` int(11) DEFAULT NULL,
  `cp_amount_recruiment` int(11) DEFAULT NULL,
  `cp_form_work` varchar(45) DEFAULT NULL,
  `cp_workplace` varchar(255) DEFAULT NULL,
  `cp_salary_from` decimal(15,0) DEFAULT NULL,
  `cp_salary_to` decimal(15,0) DEFAULT NULL,
  `cp_from_date` date DEFAULT NULL,
  `cp_to_date` date NOT NULL,
  `cp_reason_recruitment` text DEFAULT NULL,
  `cp_job_description` text DEFAULT NULL,
  `cp_manager` text DEFAULT NULL,
  `cp_follower` text DEFAULT NULL,
  `cp_ages_from` int(11) DEFAULT NULL,
  `cp_ages_to` int(11) DEFAULT NULL,
  `cp_gender` varchar(10) DEFAULT NULL,
  `cp_height` float DEFAULT NULL,
  `cp_weight` float DEFAULT NULL,
  `cp_literacy` varchar(200) DEFAULT NULL,
  `cp_experience` varchar(200) DEFAULT NULL,
  `cp_add_from` int(11) NOT NULL,
  `cp_date_add` date NOT NULL,
  `cp_status` int(11) NOT NULL,
  `display_salary` int(15) DEFAULT NULL,
  `rec_channel_form_id` int(15) DEFAULT NULL,
  `company_id` int(15) DEFAULT NULL,
  `job_meta_title` text DEFAULT NULL,
  `job_meta_description` text DEFAULT NULL,
  PRIMARY KEY (`cp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblrec_campaign`
--

LOCK TABLES `tblrec_campaign` WRITE;
/*!40000 ALTER TABLE `tblrec_campaign` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblrec_campaign` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblrec_campaign_form_web`
--

DROP TABLE IF EXISTS `tblrec_campaign_form_web`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblrec_campaign_form_web` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rec_campaign_id` int(11) NOT NULL,
  `form_type` int(11) DEFAULT NULL,
  `lead_source` varchar(10) DEFAULT NULL,
  `lead_status` varchar(10) DEFAULT NULL,
  `notify_ids_staff` text DEFAULT NULL,
  `notify_ids_roles` text DEFAULT NULL,
  `form_key` varchar(32) DEFAULT NULL,
  `notify_lead_imported` int(11) DEFAULT 1,
  `notify_type` varchar(20) DEFAULT NULL,
  `notify_ids` mediumtext DEFAULT NULL,
  `responsible` int(11) DEFAULT 0,
  `r_form_name` varchar(191) DEFAULT NULL,
  `form_data` mediumtext DEFAULT NULL,
  `recaptcha` int(11) DEFAULT 0,
  `submit_btn_name` varchar(40) DEFAULT NULL,
  `success_submit_msg` text DEFAULT NULL,
  `language` varchar(40) DEFAULT NULL,
  `allow_duplicate` int(11) DEFAULT 1,
  `mark_public` int(11) DEFAULT 0,
  `track_duplicate_field` varchar(20) DEFAULT NULL,
  `track_duplicate_field_and` varchar(20) DEFAULT NULL,
  `create_task_on_duplicate` int(11) DEFAULT 0,
  PRIMARY KEY (`id`,`rec_campaign_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblrec_campaign_form_web`
--

LOCK TABLES `tblrec_campaign_form_web` WRITE;
/*!40000 ALTER TABLE `tblrec_campaign_form_web` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblrec_campaign_form_web` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblrec_candidate`
--

DROP TABLE IF EXISTS `tblrec_candidate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblrec_candidate` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rec_campaign` int(11) DEFAULT NULL,
  `candidate_code` varchar(200) NOT NULL,
  `candidate_name` varchar(200) NOT NULL,
  `birthday` date DEFAULT NULL,
  `gender` varchar(11) DEFAULT NULL,
  `birthplace` text DEFAULT NULL,
  `home_town` text DEFAULT NULL,
  `identification` varchar(45) DEFAULT NULL,
  `days_for_identity` date DEFAULT NULL,
  `place_of_issue` varchar(255) DEFAULT NULL,
  `marital_status` varchar(11) DEFAULT NULL,
  `nationality` varchar(100) DEFAULT NULL,
  `nation` varchar(100) NOT NULL,
  `religion` varchar(100) DEFAULT NULL,
  `height` float DEFAULT NULL,
  `weight` float DEFAULT NULL,
  `introduce_yourself` text DEFAULT NULL,
  `phonenumber` text DEFAULT NULL,
  `email` text DEFAULT NULL,
  `skype` text DEFAULT NULL,
  `facebook` text DEFAULT NULL,
  `resident` text DEFAULT NULL,
  `current_accommodation` text DEFAULT NULL,
  `status` int(11) NOT NULL,
  `rate` int(11) DEFAULT NULL,
  `desired_salary` decimal(15,0) DEFAULT NULL,
  `date_add` date DEFAULT NULL,
  `recruitment_channel` int(11) DEFAULT NULL,
  `skill` text DEFAULT NULL,
  `interests` text DEFAULT NULL,
  `linkedin` text DEFAULT NULL,
  `alternate_contact_number` varchar(15) DEFAULT NULL,
  `last_name` varchar(200) DEFAULT NULL,
  `year_experience` varchar(200) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `new_pass_key` varchar(32) DEFAULT NULL,
  `new_pass_key_requested` datetime DEFAULT NULL,
  `email_verified_at` datetime DEFAULT NULL,
  `email_verification_key` varchar(32) DEFAULT NULL,
  `email_verification_sent_at` datetime DEFAULT NULL,
  `last_ip` varchar(40) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_password_change` datetime DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblrec_candidate`
--

LOCK TABLES `tblrec_candidate` WRITE;
/*!40000 ALTER TABLE `tblrec_candidate` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblrec_candidate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblrec_cd_evaluation`
--

DROP TABLE IF EXISTS `tblrec_cd_evaluation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblrec_cd_evaluation` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `criteria` int(11) NOT NULL,
  `rate_score` int(11) NOT NULL,
  `assessor` int(11) NOT NULL,
  `evaluation_date` datetime NOT NULL,
  `percent` int(11) NOT NULL,
  `candidate` int(11) NOT NULL,
  `feedback` text NOT NULL,
  `group_criteria` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblrec_cd_evaluation`
--

LOCK TABLES `tblrec_cd_evaluation` WRITE;
/*!40000 ALTER TABLE `tblrec_cd_evaluation` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblrec_cd_evaluation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblrec_company`
--

DROP TABLE IF EXISTS `tblrec_company`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblrec_company` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `company_name` varchar(200) NOT NULL,
  `company_description` text DEFAULT NULL,
  `company_address` varchar(200) DEFAULT NULL,
  `company_industry` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblrec_company`
--

LOCK TABLES `tblrec_company` WRITE;
/*!40000 ALTER TABLE `tblrec_company` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblrec_company` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblrec_criteria`
--

DROP TABLE IF EXISTS `tblrec_criteria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblrec_criteria` (
  `criteria_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `criteria_type` varchar(45) NOT NULL,
  `criteria_title` varchar(200) NOT NULL,
  `group_criteria` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  `add_date` date DEFAULT NULL,
  `score_des1` text DEFAULT NULL,
  `score_des2` text DEFAULT NULL,
  `score_des3` text DEFAULT NULL,
  `score_des4` text DEFAULT NULL,
  `score_des5` text DEFAULT NULL,
  PRIMARY KEY (`criteria_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblrec_criteria`
--

LOCK TABLES `tblrec_criteria` WRITE;
/*!40000 ALTER TABLE `tblrec_criteria` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblrec_criteria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblrec_evaluation_form`
--

DROP TABLE IF EXISTS `tblrec_evaluation_form`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblrec_evaluation_form` (
  `form_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `form_name` varchar(200) NOT NULL,
  `position` int(11) DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  `add_date` date DEFAULT NULL,
  PRIMARY KEY (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblrec_evaluation_form`
--

LOCK TABLES `tblrec_evaluation_form` WRITE;
/*!40000 ALTER TABLE `tblrec_evaluation_form` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblrec_evaluation_form` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblrec_interview`
--

DROP TABLE IF EXISTS `tblrec_interview`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblrec_interview` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `campaign` int(11) NOT NULL,
  `is_name` varchar(100) NOT NULL,
  `interview_day` varchar(200) NOT NULL,
  `from_time` text NOT NULL,
  `to_time` text NOT NULL,
  `from_hours` datetime DEFAULT NULL,
  `to_hours` datetime DEFAULT NULL,
  `interviewer` text NOT NULL,
  `added_from` int(11) NOT NULL,
  `added_date` date NOT NULL,
  `position` int(15) DEFAULT NULL,
  `send_notify` int(1) DEFAULT 0,
  `interview_location` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblrec_interview`
--

LOCK TABLES `tblrec_interview` WRITE;
/*!40000 ALTER TABLE `tblrec_interview` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblrec_interview` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblrec_job_position`
--

DROP TABLE IF EXISTS `tblrec_job_position`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblrec_job_position` (
  `position_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `position_name` varchar(200) NOT NULL,
  `position_description` text DEFAULT NULL,
  `industry_id` int(15) DEFAULT NULL,
  `company_id` int(15) DEFAULT NULL,
  `job_skill` text DEFAULT NULL,
  PRIMARY KEY (`position_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblrec_job_position`
--

LOCK TABLES `tblrec_job_position` WRITE;
/*!40000 ALTER TABLE `tblrec_job_position` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblrec_job_position` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblrec_list_criteria`
--

DROP TABLE IF EXISTS `tblrec_list_criteria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblrec_list_criteria` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `evaluation_form` int(11) NOT NULL,
  `group_criteria` int(11) NOT NULL,
  `evaluation_criteria` int(11) NOT NULL,
  `percent` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblrec_list_criteria`
--

LOCK TABLES `tblrec_list_criteria` WRITE;
/*!40000 ALTER TABLE `tblrec_list_criteria` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblrec_list_criteria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblrec_notifications`
--

DROP TABLE IF EXISTS `tblrec_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblrec_notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `isread` int(11) NOT NULL DEFAULT 0,
  `isread_inline` tinyint(1) NOT NULL DEFAULT 0,
  `date` datetime NOT NULL,
  `description` text NOT NULL,
  `fromuserid` int(11) NOT NULL,
  `fromclientid` int(11) NOT NULL DEFAULT 0,
  `from_fullname` varchar(100) NOT NULL,
  `touserid` int(11) NOT NULL,
  `fromcompany` int(11) DEFAULT NULL,
  `link` mediumtext DEFAULT NULL,
  `additional_data` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblrec_notifications`
--

LOCK TABLES `tblrec_notifications` WRITE;
/*!40000 ALTER TABLE `tblrec_notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblrec_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblrec_proposal`
--

DROP TABLE IF EXISTS `tblrec_proposal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblrec_proposal` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `proposal_name` varchar(200) NOT NULL,
  `position` int(11) NOT NULL,
  `department` int(11) DEFAULT NULL,
  `amount_recruiment` int(11) DEFAULT NULL,
  `form_work` varchar(45) DEFAULT NULL,
  `workplace` varchar(255) DEFAULT NULL,
  `salary_from` decimal(15,0) DEFAULT NULL,
  `salary_to` decimal(15,0) DEFAULT NULL,
  `from_date` date DEFAULT NULL,
  `to_date` date NOT NULL,
  `reason_recruitment` text DEFAULT NULL,
  `job_description` text DEFAULT NULL,
  `approver` int(11) NOT NULL,
  `ages_from` int(11) DEFAULT NULL,
  `ages_to` int(11) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `height` float DEFAULT NULL,
  `weight` float DEFAULT NULL,
  `literacy` varchar(200) DEFAULT NULL,
  `experience` varchar(200) DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  `date_add` date NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblrec_proposal`
--

LOCK TABLES `tblrec_proposal` WRITE;
/*!40000 ALTER TABLE `tblrec_proposal` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblrec_proposal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblrec_set_transfer_record`
--

DROP TABLE IF EXISTS `tblrec_set_transfer_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblrec_set_transfer_record` (
  `set_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `send_to` varchar(45) NOT NULL,
  `email_to` text DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  `add_date` date NOT NULL,
  `subject` text NOT NULL,
  `content` text DEFAULT NULL,
  `order` int(11) NOT NULL,
  PRIMARY KEY (`set_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblrec_set_transfer_record`
--

LOCK TABLES `tblrec_set_transfer_record` WRITE;
/*!40000 ALTER TABLE `tblrec_set_transfer_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblrec_set_transfer_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblrec_skill`
--

DROP TABLE IF EXISTS `tblrec_skill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblrec_skill` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `skill_name` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblrec_skill`
--

LOCK TABLES `tblrec_skill` WRITE;
/*!40000 ALTER TABLE `tblrec_skill` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblrec_skill` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblrec_transfer_records`
--

DROP TABLE IF EXISTS `tblrec_transfer_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblrec_transfer_records` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `firstname` varchar(100) DEFAULT NULL,
  `lastname` varchar(100) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `gender` varchar(11) DEFAULT NULL,
  `staff_identifi` varchar(20) DEFAULT NULL,
  `creator` int(11) DEFAULT NULL,
  `datecreator` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblrec_transfer_records`
--

LOCK TABLES `tblrec_transfer_records` WRITE;
/*!40000 ALTER TABLE `tblrec_transfer_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblrec_transfer_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblrecords_meta`
--

DROP TABLE IF EXISTS `tblrecords_meta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblrecords_meta` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) DEFAULT NULL,
  `meta` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblrecords_meta`
--

LOCK TABLES `tblrecords_meta` WRITE;
/*!40000 ALTER TABLE `tblrecords_meta` DISABLE KEYS */;
INSERT INTO `tblrecords_meta` VALUES (1,'staff_identifi','staff_identifi'),(2,'firstname','firstname'),(3,'email','email'),(4,'phonenumber','phonenumber'),(5,'facebook','facebook'),(6,'skype','skype'),(7,'birthday','birthday'),(8,'birthplace','birthplace'),(9,'home_town','home_town'),(10,'marital_status','marital_status'),(11,'nation','nation'),(12,'religion','religion'),(13,'identification','identification'),(14,'days_for_identity','days_for_identity'),(15,'place_of_issue','place_of_issue'),(16,'resident','resident'),(17,'current_address','current_address'),(18,'literacy','literacy');
/*!40000 ALTER TABLE `tblrecords_meta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblrelated_items`
--

DROP TABLE IF EXISTS `tblrelated_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblrelated_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(30) NOT NULL,
  `item_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblrelated_items`
--

LOCK TABLES `tblrelated_items` WRITE;
/*!40000 ALTER TABLE `tblrelated_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblrelated_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblreminders`
--

DROP TABLE IF EXISTS `tblreminders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblreminders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` mediumtext DEFAULT NULL,
  `date` datetime NOT NULL,
  `isnotified` int(11) NOT NULL DEFAULT 0,
  `rel_id` int(11) NOT NULL,
  `staff` int(11) NOT NULL,
  `rel_type` varchar(40) NOT NULL,
  `notify_by_email` int(11) NOT NULL DEFAULT 1,
  `creator` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`),
  KEY `staff` (`staff`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblreminders`
--

LOCK TABLES `tblreminders` WRITE;
/*!40000 ALTER TABLE `tblreminders` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblreminders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblroles`
--

DROP TABLE IF EXISTS `tblroles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblroles` (
  `roleid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `permissions` longtext DEFAULT NULL,
  PRIMARY KEY (`roleid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblroles`
--

LOCK TABLES `tblroles` WRITE;
/*!40000 ALTER TABLE `tblroles` DISABLE KEYS */;
INSERT INTO `tblroles` VALUES (1,'Employee',NULL);
/*!40000 ALTER TABLE `tblroles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblsales_activity`
--

DROP TABLE IF EXISTS `tblsales_activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblsales_activity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_type` varchar(20) DEFAULT NULL,
  `rel_id` int(11) NOT NULL,
  `description` mediumtext NOT NULL,
  `additional_data` mediumtext DEFAULT NULL,
  `staffid` varchar(11) DEFAULT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblsales_activity`
--

LOCK TABLES `tblsales_activity` WRITE;
/*!40000 ALTER TABLE `tblsales_activity` DISABLE KEYS */;
INSERT INTO `tblsales_activity` VALUES (5,'invoice',3,'invoice_activity_created','','1','Vikas Yadav','2025-07-08 10:06:55'),(6,'invoice',4,'invoice_activity_created','','1','Vikas Yadav','2025-07-08 10:52:26'),(7,'invoice',4,'invoice_activity_status_updated','a:2:{i:0;s:36:\"<original_status>1</original_status>\";i:1;s:26:\"<new_status>2</new_status>\";}','1','Vikas Yadav','2025-07-08 10:54:15'),(8,'invoice',4,'invoice_activity_payment_made_by_staff','a:2:{i:0;s:12:\"₹18,000.00\";i:1;s:79:\"<a href=\"https://techdotbit.in/admin/payments/payment/2\" target=\"_blank\">#2</a>\";}','1','Vikas Yadav','2025-07-08 10:54:15'),(9,'invoice',4,'invoice_activity_record_payment_email_to_customer','a:1:{i:0;s:16:\"md@spliceply.com\";}','1','Vikas Yadav','2025-07-08 10:54:18');
/*!40000 ALTER TABLE `tblsales_activity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblscheduled_emails`
--

DROP TABLE IF EXISTS `tblscheduled_emails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblscheduled_emails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(15) NOT NULL,
  `scheduled_at` datetime NOT NULL,
  `contacts` varchar(197) NOT NULL,
  `cc` mediumtext DEFAULT NULL,
  `attach_pdf` tinyint(1) NOT NULL DEFAULT 1,
  `template` varchar(197) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblscheduled_emails`
--

LOCK TABLES `tblscheduled_emails` WRITE;
/*!40000 ALTER TABLE `tblscheduled_emails` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblscheduled_emails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblservices`
--

DROP TABLE IF EXISTS `tblservices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblservices` (
  `serviceid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`serviceid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblservices`
--

LOCK TABLES `tblservices` WRITE;
/*!40000 ALTER TABLE `tblservices` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblservices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblsessions`
--

DROP TABLE IF EXISTS `tblsessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblsessions` (
  `id` varchar(128) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT 0,
  `data` blob NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ci_sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblsessions`
--

LOCK TABLES `tblsessions` WRITE;
/*!40000 ALTER TABLE `tblsessions` DISABLE KEYS */;
INSERT INTO `tblsessions` VALUES ('0bgopumlbfn3udtq0himqa53t3og8imk','49.36.189.194',1751962495,'__ci_last_regenerate|i:1751962495;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"old\";}'),('0j0sk8u3t5rfarcak2cp8ildjpjkpsjv','82.29.165.22',1751962621,'__ci_last_regenerate|i:1751962621;'),('0p3eq72hkcipk1cns3s91e9smg3cu1hl','82.29.165.22',1751963701,'__ci_last_regenerate|i:1751963701;'),('0uvv6aqeprer3ue0jcujaua95fppg8ec','82.29.165.22',1751966162,'__ci_last_regenerate|i:1751966161;'),('14sjruk819i1895s3umjnudo0n5j2a4t','40.77.167.0',1751956174,'__ci_last_regenerate|i:1751956174;'),('174j8cgc2grj38okkev18fn0cr8jfght','49.36.189.194',1751962507,'__ci_last_regenerate|i:1751962495;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),('17ddl9rbvijf1bo1q30bsq3llinoeaus','49.36.189.194',1751947929,'__ci_last_regenerate|i:1751947929;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),('181s5ivcd45qmag9qfv1bpkgb2vkmjhf','82.29.165.22',1751962925,'__ci_last_regenerate|i:1751962921;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),('1dhq05h9ll2bb1efgu4n9h04pd9vos5s','82.29.165.22',1751963521,'__ci_last_regenerate|i:1751963521;'),('1e0tgkn7lpebocf80k0jk04eja3rhsn8','82.29.165.22',1751963101,'__ci_last_regenerate|i:1751963101;'),('1tpd7rr0a5u8scalmsin5crcsiah0lju','49.36.189.194',1751950349,'__ci_last_regenerate|i:1751950320;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;red_url|s:39:\"https://techdotbit.in/clients?companies\";message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),('25thi90rkm6c1mvua42vofd48h0muqqt','82.29.165.22',1751962862,'__ci_last_regenerate|i:1751962862;'),('27267o2to99785vakbvip7phsqdji2v1','82.29.165.22',1751964842,'__ci_last_regenerate|i:1751964842;'),('2casf23h6q4n655bg06v48aplevmjbcn','82.29.165.22',1751965561,'__ci_last_regenerate|i:1751965561;'),('2q2pgl4tpi3jngqlcj2mdb7mhhpaf3v2','180.149.125.169',1751952654,'__ci_last_regenerate|i:1751952654;red_url|s:22:\"https://techdotbit.in/\";'),('2qq4hd0h7b8nsdnanr7e9sb6l9n8norr','49.36.189.194',1751950320,'__ci_last_regenerate|i:1751950320;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;red_url|s:39:\"https://techdotbit.in/clients?companies\";message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),('2u7rm7qace83tgf5vtnjfn4rppb8hpc4','82.29.165.22',1751965382,'__ci_last_regenerate|i:1751965382;'),('321jgqjp9p4c127epal449ac9lhn1doc','82.29.165.22',1751964542,'__ci_last_regenerate|i:1751964542;'),('36hooemfrm3u6277kmgjk5l8f1jubh3b','82.29.165.22',1751963224,'__ci_last_regenerate|i:1751963221;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),('3evibrdd22hgeve2e93jqpbini6208dd','49.36.189.194',1751951241,'__ci_last_regenerate|i:1751951241;staff_user_id|s:1:\"1\";staff_logged_in|b:1;red_url|s:39:\"https://techdotbit.in/clients?companies\";setup-menu-open|s:0:\"\";'),('449oqn2ojpjuq609l0nv0q4em4r05ila','107.170.31.151',1751963329,'__ci_last_regenerate|i:1751963329;red_url|s:22:\"https://techdotbit.in/\";'),('4mautif5ialkbdga78ibrod0e62ok9fs','49.36.189.194',1751949701,'__ci_last_regenerate|i:1751949701;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),('52onqja7jpuh46ti3hj54bes3b38td71','35.93.83.62',1751953484,'__ci_last_regenerate|i:1751953483;is_mobile|b:1;red_url|s:22:\"https://techdotbit.in/\";'),('56cla7jiq0m64fvh9icaucir8m47uefp','49.36.189.194',1751963189,'__ci_last_regenerate|i:1751963189;red_url|s:39:\"https://techdotbit.in/clients?companies\";'),('5877p9bfqem18jj1b1679ofqpu2pj40e','49.36.189.194',1751962843,'__ci_last_regenerate|i:1751962843;red_url|s:39:\"https://techdotbit.in/clients?companies\";'),('5gf0ljdvi4h9qckv4d9ngn339o78cttb','49.36.189.194',1751966780,'__ci_last_regenerate|i:1751966770;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";magic_auth|a:2:{s:12:\"cross_domain\";i:0;s:10:\"source_url\";s:53:\"https://splice.techdotbit.in/admin/billing/my_account\";}tenant-ps_slug|s:3:\"add\";message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),('5ompfun7ud6eusbv1gbr2pi71ve4jktn','82.29.165.22',1751966642,'__ci_last_regenerate|i:1751966641;'),('66tpig3ihecn92v5cui0q3lddm2bukr8','49.36.189.194',1751965096,'__ci_last_regenerate|i:1751965096;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;magic_auth|a:2:{s:12:\"cross_domain\";i:0;s:10:\"source_url\";s:53:\"https://splice.techdotbit.in/admin/billing/my_account\";}message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),('6h9chpol6nfgu71uugmjcd4udei8fj69','44.242.246.213',1751947334,'__ci_last_regenerate|i:1751947333;is_mobile|b:1;red_url|s:22:\"https://techdotbit.in/\";'),('6r2i2ggfp6rpqp00fd22m8sle7smbr7e','82.29.165.22',1751964181,'__ci_last_regenerate|i:1751964181;'),('70rj7fts20ck3nt7ltht60cs1vp453eo','82.29.165.22',1751963762,'__ci_last_regenerate|i:1751963762;'),('7be509sqvncrd1gs6s81h28j93cl2vf3','167.94.138.193',1751947892,'__ci_last_regenerate|i:1751947892;red_url|s:22:\"https://techdotbit.in/\";'),('807ieiocutu1da0jcvgqu1c3135pj8kq','82.29.165.22',1751965502,'__ci_last_regenerate|i:1751965502;'),('809tiu6g1190ku1svtnd9g7k38kg8u76','49.36.189.194',1751952111,'__ci_last_regenerate|i:1751952111;staff_user_id|s:1:\"1\";staff_logged_in|b:1;red_url|s:39:\"https://techdotbit.in/clients?companies\";setup-menu-open|b:1;client_user_id|s:2:\"10\";contact_user_id|s:2:\"10\";client_logged_in|b:1;logged_in_as_client|b:1;'),('80kik7u00g0q1uabcur6h0lfg1di9d7u','49.36.189.194',1751948675,'__ci_last_regenerate|i:1751948675;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";'),('8cvm6iamhrt77ssb8qb74i1qci9qqjql','143.110.186.58',1751940128,'__ci_last_regenerate|i:1751940127;red_url|s:22:\"https://techdotbit.in/\";'),('8pua763c4gjce7tif3h1353hgipq2hcb','82.29.165.22',1751962682,'__ci_last_regenerate|i:1751962682;'),('9iklmmqrdv68jmvqu888n0g7ate3md2m','106.219.224.39',1751962304,'__ci_last_regenerate|i:1751962304;red_url|s:39:\"https://techdotbit.in/clients?companies\";'),('a8qp8jgq5a74etknf338diqkk9cecjrg','49.36.189.194',1751950938,'__ci_last_regenerate|i:1751950938;staff_user_id|s:1:\"1\";staff_logged_in|b:1;red_url|s:39:\"https://techdotbit.in/clients?companies\";message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),('afbka0t62juqg06rftd92v1hsl3hg5i3','84.168.0.43',1751960209,'__ci_last_regenerate|i:1751960209;red_url|s:22:\"https://techdotbit.in/\";'),('ailpdotvaas3mk6krdvtv1ub1fp59dqv','82.29.165.22',1751965981,'__ci_last_regenerate|i:1751965981;'),('ajgau60o73nfild3k0cfj32ebjv6ea7p','44.242.246.213',1751947343,'__ci_last_regenerate|i:1751947342;is_mobile|b:1;red_url|s:22:\"https://techdotbit.in/\";'),('ak4sbdskjd9tvkkhvrv4ttte3du22dlk','82.29.165.22',1751964781,'__ci_last_regenerate|i:1751964781;'),('amqmbmbc1b0kepfi00p4ug0lpumaufqf','82.29.165.22',1751963642,'__ci_last_regenerate|i:1751963642;'),('b7lnv6odlqks8omfvh97u2qidrnpsgoi','49.36.189.194',1751951571,'__ci_last_regenerate|i:1751951571;staff_user_id|s:1:\"1\";staff_logged_in|b:1;red_url|s:39:\"https://techdotbit.in/clients?companies\";setup-menu-open|s:0:\"\";'),('bu0kt0kjan8l4d9i7gqgn17r45l2iei4','82.29.165.22',1751963162,'__ci_last_regenerate|i:1751963162;'),('buv2tk527k48os354vk7mhine2obnu6v','106.219.229.39',1751961476,'__ci_last_regenerate|i:1751961476;red_url|s:39:\"https://techdotbit.in/clients?companies\";'),('c424a5oueol7naac4ef8r2enukakp24f','106.219.224.174',1751963691,'__ci_last_regenerate|i:1751963691;red_url|s:39:\"https://techdotbit.in/clients?companies\";'),('c5s06gutaak5d6g8kd8jusi8skvemsar','82.29.165.22',1751964061,'__ci_last_regenerate|i:1751964061;'),('ceo9f6k6e0o090tq8l3qer3rvp49edse','82.29.165.22',1751964604,'__ci_last_regenerate|i:1751964601;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),('cg1k0f97pcq877fnrjr7t6e8lah5q670','49.36.189.194',1751961518,'__ci_last_regenerate|i:1751961518;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";red_url|s:39:\"https://techdotbit.in/clients?companies\";message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),('ch4hkfi14iniltu5egfum99a0v1uvr7j','49.36.189.194',1751948986,'__ci_last_regenerate|i:1751948986;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"old\";}'),('ci9c37h37lqhubq3q0i3njaqo2hq1npc','82.29.165.22',1751965862,'__ci_last_regenerate|i:1751965862;'),('csllv9f1kv2shsq00c1c2et4vonmo2h9','49.36.189.194',1751953423,'__ci_last_regenerate|i:1751953423;red_url|s:39:\"https://techdotbit.in/clients?companies\";'),('dngor11p8l81eoba4fua2pgr1ntispkq','82.29.165.22',1751964242,'__ci_last_regenerate|i:1751964241;'),('efdugo6an8fp0fqf0v4p6aj9pqibnlr8','82.29.165.22',1751964902,'__ci_last_regenerate|i:1751964901;'),('ekot5d7q8bch6j9kibh3skk03tc5531q','82.29.165.22',1751966405,'__ci_last_regenerate|i:1751966402;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),('g2p856nql1j3rbekmgkt6uo0fb9v9v5k','49.36.189.194',1751961892,'__ci_last_regenerate|i:1751961892;red_url|s:39:\"https://techdotbit.in/clients?companies\";'),('gra7b89ua25p1jj53msdsaf04qo1069l','91.231.89.125',1751950848,'__ci_last_regenerate|i:1751950848;red_url|s:22:\"https://techdotbit.in/\";'),('gu3iga25h6ipd6n83uhtsvcnrnprq3gp','49.36.189.194',1751964553,'__ci_last_regenerate|i:1751964553;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;magic_auth|a:2:{s:12:\"cross_domain\";i:0;s:10:\"source_url\";s:53:\"https://splice.techdotbit.in/admin/billing/my_account\";}'),('gua9s1k1kh8em4ek6eo9ivuejs6pl7mj','82.29.165.22',1751965082,'__ci_last_regenerate|i:1751965081;'),('h9e8ih4mje57oplndof9r5in8rpn1cpd','106.219.224.174',1751966308,'__ci_last_regenerate|i:1751966308;red_url|s:39:\"https://techdotbit.in/clients?companies\";'),('hc2akakd929ouqdhpdejogtfr7isphba','82.29.165.22',1751964481,'__ci_last_regenerate|i:1751964481;'),('hgclrviirgmmufv9foqpds670dj5jdu4','40.77.167.131',1751956180,'__ci_last_regenerate|i:1751956179;'),('hpd0pbuh7ak2folseql819bv8uber9i4','82.29.165.22',1751965801,'__ci_last_regenerate|i:1751965801;'),('hqktedlpcig6d2l9krfkd04tq7gmm5u9','82.29.165.22',1751963342,'__ci_last_regenerate|i:1751963342;'),('i7ddt970p8nntdm9gdi1qis0hgeg5fql','82.29.165.22',1751966102,'__ci_last_regenerate|i:1751966102;'),('i86rcb2qh6dn9l4lbqb19o6abnon7uft','84.239.7.18',1751937579,'__ci_last_regenerate|i:1751937579;red_url|s:22:\"https://techdotbit.in/\";'),('i9u3ddge5hhnlo853sh76vvvmcff7f1j','106.219.224.174',1751965056,'__ci_last_regenerate|i:1751965056;red_url|s:39:\"https://techdotbit.in/clients?companies\";'),('iap7smedo92kadvr92in40k2q6oai3lu','49.36.189.194',1751966770,'__ci_last_regenerate|i:1751966770;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";magic_auth|a:2:{s:12:\"cross_domain\";i:0;s:10:\"source_url\";s:53:\"https://splice.techdotbit.in/admin/billing/my_account\";}message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),('il7jqibupmuft7f84nftp0jjn0sai8a7','82.29.165.22',1751966341,'__ci_last_regenerate|i:1751966341;'),('j51nkvt3mubgfr3qsfqhl8rt2cbg3168','40.77.167.131',1751956179,'__ci_last_regenerate|i:1751956179;'),('jetd0u22jnol8bkea48fuf4qqloil02i','34.222.175.103',1751949644,'__ci_last_regenerate|i:1751949643;is_mobile|b:1;red_url|s:22:\"https://techdotbit.in/\";'),('jgpiidn3vn2jevfgub21dbg7dmhbuh4q','44.248.156.206',1751941374,'__ci_last_regenerate|i:1751941373;is_mobile|b:1;red_url|s:22:\"https://techdotbit.in/\";'),('jhm9jdg4n1bji329js5fbq0ovf2d2jas','106.219.224.174',1751965966,'__ci_last_regenerate|i:1751965966;red_url|s:39:\"https://techdotbit.in/clients?companies\";'),('kjejsn1nekfq4k2tge46til4m2dsjrv9','77.170.31.190',1751946242,'__ci_last_regenerate|i:1751946241;red_url|s:22:\"https://techdotbit.in/\";'),('ktd7jihmee0dkrs3oivnat1gcmmlqioj','82.29.165.22',1751966043,'__ci_last_regenerate|i:1751966041;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),('kulndm04k8tcovcjo2vmjomrc8fl6i51','82.29.165.22',1751963882,'__ci_last_regenerate|i:1751963882;'),('lcbor9t9gc1337tfabf3hq2icc8rkgtr','82.29.165.22',1751965441,'__ci_last_regenerate|i:1751965441;'),('levjqg011qfvab6e2emc1pr93qr6goht','49.36.189.194',1751961217,'__ci_last_regenerate|i:1751961217;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),('llt2rvfs0rm0acdi3k7te415eh48gkod','82.29.165.22',1751963585,'__ci_last_regenerate|i:1751963582;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),('lo4582i8a3dtcqs82vlq86ta8jg6dmed','82.29.165.22',1751963402,'__ci_last_regenerate|i:1751963402;'),('m3vkcaciott46tn1rpata7ls5bs2vd22','49.36.189.194',1751949399,'__ci_last_regenerate|i:1751949399;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),('m837gdedrugohn2ndhlg7e1v3iln6hnt','82.29.165.22',1751964362,'__ci_last_regenerate|i:1751964362;'),('m9o0bc0eoq62i0k26otc9rpfhqovucrm','82.29.165.22',1751962802,'__ci_last_regenerate|i:1751962802;'),('mi13ee0gu98i0vai2lhaguem330bic7j','106.219.224.174',1751966870,'__ci_last_regenerate|i:1751966714;red_url|s:39:\"https://techdotbit.in/clients?companies\";'),('mijpr0hjuks8oqv758n32vl394gvo2gi','84.239.7.18',1751937573,'__ci_last_regenerate|i:1751937573;red_url|s:22:\"https://techdotbit.in/\";'),('mjc9ak39ffv22e3veepl6jj7pnt1ehh6','82.29.165.22',1751964422,'__ci_last_regenerate|i:1751964421;'),('mjqrahlcl4h0jf4c6krel3v83j4jlhmq','82.29.165.22',1751966764,'__ci_last_regenerate|i:1751966761;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),('mtpo3m1vrq3ef3lc5jnoplj84r6ni4pa','82.29.165.22',1751963042,'__ci_last_regenerate|i:1751963041;'),('n39ele4mal9h5num8dlkaq3degeccb86','106.219.229.39',1751955170,'__ci_last_regenerate|i:1751955170;red_url|s:39:\"https://techdotbit.in/clients?companies\";'),('n3dgb6k6vr708g5181iu334ra69lk9pb','82.29.165.22',1751964964,'__ci_last_regenerate|i:1751964961;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),('nbg43jhmjg41f5bj5g7j48k8ff8pmoca','82.29.165.22',1751966821,'__ci_last_regenerate|i:1751966821;'),('ndvvqjduujvulej5ibgri3jkou2tj3vv','82.29.165.22',1751963281,'__ci_last_regenerate|i:1751963281;'),('nh4o4o7ijcekqj2ccqu0trrv8ae7n44t','82.29.165.22',1751965261,'__ci_last_regenerate|i:1751965261;'),('og6mh0iar17vqers2cd7539fo311mipk','82.29.165.22',1751964662,'__ci_last_regenerate|i:1751964662;'),('p2mkn1beahme4tdu7j1ot6kct5u9050d','82.29.165.22',1751966882,'__ci_last_regenerate|i:1751966882;'),('p5tmjh0d3kamlaic498qn0v8o165n2vf','106.219.229.39',1751954709,'__ci_last_regenerate|i:1751954709;red_url|s:27:\"https://techdotbit.in/admin\";'),('p8dntspvtvm70mq4uoua65t4lsfdjn6t','82.29.165.22',1751962981,'__ci_last_regenerate|i:1751962981;'),('p8fagppnl7mg39sot5a8jaq3rhh5fnue','82.29.165.22',1751966701,'__ci_last_regenerate|i:1751966701;'),('p9dr8ctk42k0410cgu1a4ki5sj3pn5i0','35.86.232.84',1751964859,'__ci_last_regenerate|i:1751964859;red_url|s:22:\"https://techdotbit.in/\";'),('pa6q8mjacuapso1q1d194aif5mc4qlec','167.172.190.149',1751959415,'__ci_last_regenerate|i:1751959415;red_url|s:22:\"https://techdotbit.in/\";'),('pgkqkdck8u53ik1rnsapu05o6a8ilvp7','167.94.138.193',1751947931,'__ci_last_regenerate|i:1751947931;'),('pkrokjd7rfhud1cbkagfnk5ap5bqqn19','82.29.165.22',1751962741,'__ci_last_regenerate|i:1751962741;'),('plnhn0q76aq6jkc0kkovd7qup828926b','82.29.165.22',1751965742,'__ci_last_regenerate|i:1751965741;'),('pnaa78fe09umnrit97j04jmcjvf29m8f','49.36.189.194',1751950003,'__ci_last_regenerate|i:1751950003;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;red_url|s:39:\"https://techdotbit.in/clients?companies\";message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),('psha3smvkpg1u0v3p9la3hio1umu813s','82.29.165.22',1751964122,'__ci_last_regenerate|i:1751964122;'),('qbvfkltb3k71jla4au39ib24r8kqk786','82.29.165.22',1751965202,'__ci_last_regenerate|i:1751965201;'),('qd4lf9uqv605jv5fu7n4aglosp34uc6g','106.219.224.174',1751963372,'__ci_last_regenerate|i:1751963372;red_url|s:39:\"https://techdotbit.in/clients?companies\";'),('qdm61t0rm1b7ap9ditobaer0q53mqnds','82.29.165.22',1751963946,'__ci_last_regenerate|i:1751963942;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),('ql1tfgafdicnvoog62d73cnstj7vmivk','82.29.165.22',1751966461,'__ci_last_regenerate|i:1751966461;'),('qm3scspio7qirod3h1agbkbnqecttp5s','82.29.165.22',1751966522,'__ci_last_regenerate|i:1751966522;'),('r0eqsfut10cnuhjnquno4d1b9j392ra6','82.29.165.22',1751963462,'__ci_last_regenerate|i:1751963462;'),('r0n742jojdpbk5nev3c3qi18id9f4gna','82.29.165.22',1751966282,'__ci_last_regenerate|i:1751966281;'),('re1j7rdrqnae70k3n8td10scgtbjhojs','82.29.165.22',1751965684,'__ci_last_regenerate|i:1751965681;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),('rnv2qhc0pakl6j0mt93md1oder3i2odc','82.29.165.22',1751964002,'__ci_last_regenerate|i:1751964002;'),('romul8phpj4i48t0c60uvv2a9b9m51kl','82.29.165.22',1751966581,'__ci_last_regenerate|i:1751966581;'),('s6ck6tdmt1c92psfou9t4qla55hha3al','106.219.224.174',1751962689,'__ci_last_regenerate|i:1751962689;red_url|s:39:\"https://techdotbit.in/clients?companies\";'),('sbofd645g3596c125csf5tauchjvorgt','106.219.224.174',1751966714,'__ci_last_regenerate|i:1751966714;red_url|s:39:\"https://techdotbit.in/clients?companies\";'),('sckqflsclf09j1bpo5mn0seh15c4s8r1','49.36.189.194',1751960273,'__ci_last_regenerate|i:1751960273;red_url|s:39:\"https://techdotbit.in/clients?companies\";'),('sn51akig3js7uf4e8imj4r15m8j9j1cl','82.29.165.22',1751963821,'__ci_last_regenerate|i:1751963821;'),('srvr7ceaeeahhsjvtgf6haigabsh8j7d','49.36.189.194',1751948355,'__ci_last_regenerate|i:1751948355;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),('t80b3ho2r355djjo2t1gqkep7n9r9rvc','82.29.165.22',1751965622,'__ci_last_regenerate|i:1751965622;'),('tbrg4137g2reb12dvclr7ea7ef239rko','49.36.189.194',1751964157,'__ci_last_regenerate|i:1751964157;red_url|s:39:\"https://techdotbit.in/clients?companies\";'),('tc8ko2ath4s917d5v5slfbdmoc389hg3','82.29.165.22',1751965922,'__ci_last_regenerate|i:1751965921;'),('tqmfq7hsk5sjp3bkq2lf5eit8m93khif','106.219.229.39',1751954050,'__ci_last_regenerate|i:1751954050;red_url|s:27:\"https://techdotbit.in/admin\";'),('u3ridmohk2p0cf795vc4vtv08tv3one1','82.29.165.22',1751964722,'__ci_last_regenerate|i:1751964722;'),('u5ce9v1gcmkeru8u7n98esj8sqtkm19k','82.29.165.22',1751966221,'__ci_last_regenerate|i:1751966221;'),('ubrai794mu758f9g2b1ciinjaknotomv','82.29.165.22',1751962581,'__ci_last_regenerate|i:1751962561;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),('ul9cqlbqt6f5nohgm0lvljvl3gjcgfl4','106.219.224.174',1751965616,'__ci_last_regenerate|i:1751965616;red_url|s:39:\"https://techdotbit.in/clients?companies\";'),('uvdsh0g57pcrr754aphg1l3ss92tgokn','82.29.165.22',1751964304,'__ci_last_regenerate|i:1751964301;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),('v46jpp0k4vvhv70fgr48vnpdb0r8nimq','82.29.165.22',1751965141,'__ci_last_regenerate|i:1751965141;'),('vahaubbu688u0e3agku577d0bnfhsfuu','180.149.125.169',1751952656,'__ci_last_regenerate|i:1751952656;'),('vdgphe3hv22p10scod6pohh73il85ndv','82.29.165.22',1751965324,'__ci_last_regenerate|i:1751965322;message-danger|s:0:\"\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"new\";}'),('vgmk236o4qmd81374qmqlq96gmjn6ej4','106.219.224.174',1751963061,'__ci_last_regenerate|i:1751963061;red_url|s:39:\"https://techdotbit.in/clients?companies\";');
/*!40000 ALTER TABLE `tblsessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblsetting_asset_allocation`
--

DROP TABLE IF EXISTS `tblsetting_asset_allocation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblsetting_asset_allocation` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) DEFAULT NULL,
  `meta` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblsetting_asset_allocation`
--

LOCK TABLES `tblsetting_asset_allocation` WRITE;
/*!40000 ALTER TABLE `tblsetting_asset_allocation` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblsetting_asset_allocation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblsetting_training`
--

DROP TABLE IF EXISTS `tblsetting_training`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblsetting_training` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `training_type` int(11) NOT NULL,
  `position_training` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblsetting_training`
--

LOCK TABLES `tblsetting_training` WRITE;
/*!40000 ALTER TABLE `tblsetting_training` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblsetting_training` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblsetting_transfer_records`
--

DROP TABLE IF EXISTS `tblsetting_transfer_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblsetting_transfer_records` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) DEFAULT NULL,
  `meta` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblsetting_transfer_records`
--

LOCK TABLES `tblsetting_transfer_records` WRITE;
/*!40000 ALTER TABLE `tblsetting_transfer_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblsetting_transfer_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblshared_customer_files`
--

DROP TABLE IF EXISTS `tblshared_customer_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblshared_customer_files` (
  `file_id` int(11) NOT NULL,
  `contact_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblshared_customer_files`
--

LOCK TABLES `tblshared_customer_files` WRITE;
/*!40000 ALTER TABLE `tblshared_customer_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblshared_customer_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblshift_type`
--

DROP TABLE IF EXISTS `tblshift_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblshift_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shift_type_name` varchar(150) DEFAULT NULL,
  `color` varchar(50) DEFAULT NULL,
  `time_start` date DEFAULT NULL,
  `time_end` date DEFAULT NULL,
  `time_start_work` varchar(50) DEFAULT NULL,
  `time_end_work` varchar(50) DEFAULT NULL,
  `start_lunch_break_time` varchar(50) DEFAULT NULL,
  `end_lunch_break_time` varchar(50) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblshift_type`
--

LOCK TABLES `tblshift_type` WRITE;
/*!40000 ALTER TABLE `tblshift_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblshift_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblspam_filters`
--

DROP TABLE IF EXISTS `tblspam_filters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblspam_filters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(40) NOT NULL,
  `rel_type` varchar(10) NOT NULL,
  `value` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblspam_filters`
--

LOCK TABLES `tblspam_filters` WRITE;
/*!40000 ALTER TABLE `tblspam_filters` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblspam_filters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblstaff`
--

DROP TABLE IF EXISTS `tblstaff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblstaff` (
  `staffid` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `facebook` longtext DEFAULT NULL,
  `linkedin` longtext DEFAULT NULL,
  `phonenumber` varchar(30) DEFAULT NULL,
  `skype` varchar(50) DEFAULT NULL,
  `password` varchar(250) NOT NULL,
  `datecreated` datetime NOT NULL,
  `profile_image` varchar(191) DEFAULT NULL,
  `last_ip` varchar(40) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_activity` datetime DEFAULT NULL,
  `last_password_change` datetime DEFAULT NULL,
  `new_pass_key` varchar(32) DEFAULT NULL,
  `new_pass_key_requested` datetime DEFAULT NULL,
  `admin` int(11) NOT NULL DEFAULT 0,
  `role` int(11) DEFAULT NULL,
  `active` int(11) NOT NULL DEFAULT 1,
  `default_language` varchar(40) DEFAULT NULL,
  `direction` varchar(3) DEFAULT NULL,
  `media_path_slug` varchar(191) DEFAULT NULL,
  `is_not_staff` int(11) NOT NULL DEFAULT 0,
  `hourly_rate` decimal(15,2) NOT NULL DEFAULT 0.00,
  `two_factor_auth_enabled` tinyint(1) DEFAULT 0,
  `two_factor_auth_code` varchar(100) DEFAULT NULL,
  `two_factor_auth_code_requested` datetime DEFAULT NULL,
  `email_signature` mediumtext DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `birthplace` varchar(200) DEFAULT NULL,
  `sex` varchar(15) DEFAULT NULL,
  `marital_status` varchar(25) DEFAULT NULL,
  `nation` varchar(25) DEFAULT NULL,
  `religion` varchar(50) DEFAULT NULL,
  `identification` varchar(100) DEFAULT NULL,
  `days_for_identity` date DEFAULT NULL,
  `home_town` varchar(200) DEFAULT NULL,
  `resident` varchar(200) DEFAULT NULL,
  `current_address` varchar(200) DEFAULT NULL,
  `literacy` varchar(50) DEFAULT NULL,
  `orther_infor` text DEFAULT NULL,
  `job_position` int(11) DEFAULT NULL,
  `workplace` int(11) DEFAULT NULL,
  `place_of_issue` varchar(50) DEFAULT NULL,
  `account_number` varchar(50) DEFAULT NULL,
  `name_account` varchar(50) DEFAULT NULL,
  `issue_bank` varchar(200) DEFAULT NULL,
  `records_received` longtext DEFAULT NULL,
  `Personal_tax_code` varchar(50) DEFAULT NULL,
  `google_auth_secret` mediumtext DEFAULT NULL,
  `team_manage` int(11) DEFAULT 0,
  `staff_identifi` varchar(200) DEFAULT NULL,
  `status_work` varchar(100) DEFAULT NULL,
  `date_update` date DEFAULT NULL,
  `epf_no` text DEFAULT NULL,
  `social_security_no` text DEFAULT NULL,
  `mail_password` varchar(250) DEFAULT NULL,
  `mail_signature` varchar(250) DEFAULT NULL,
  `last_email_check` varchar(50) DEFAULT NULL,
  `token` varchar(255) DEFAULT NULL,
  `date_of_joining` date DEFAULT NULL,
  `pan_no` varchar(20) DEFAULT NULL,
  `uan_no` varchar(20) DEFAULT NULL,
  `mother_name` varchar(100) DEFAULT NULL,
  `father_name` varchar(100) DEFAULT NULL,
  `ho_wo_name` varchar(100) DEFAULT NULL,
  `ifsc_code` varchar(20) DEFAULT NULL,
  `account_type` varchar(50) DEFAULT NULL,
  `disability_type` varchar(100) DEFAULT NULL,
  `adhar_no` varchar(20) DEFAULT NULL,
  `esi_insurance_no` varchar(20) DEFAULT NULL,
  `esi_enable` tinyint(1) DEFAULT 0,
  `epf_enable` tinyint(1) DEFAULT 0,
  `enable_contribute_to_employee_pension_scheme` tinyint(1) DEFAULT 0,
  `contribute_eps_on_actual_pf_wages` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`staffid`),
  KEY `firstname` (`firstname`),
  KEY `lastname` (`lastname`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblstaff`
--

LOCK TABLES `tblstaff` WRITE;
/*!40000 ALTER TABLE `tblstaff` DISABLE KEYS */;
INSERT INTO `tblstaff` VALUES (1,'info.vikaasyadav@gmail.com','Vikas','Yadav',NULL,NULL,NULL,NULL,'$2a$08$iVdiZvGItuLfkqKIXo3Gt.KwMpmFnO8RvJJS.nB0ABx3NNLI3PxMW','2025-06-25 10:23:49',NULL,'49.36.189.194','2025-07-08 14:12:51','2025-07-08 14:56:20',NULL,NULL,NULL,1,NULL,1,NULL,NULL,NULL,0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0);
/*!40000 ALTER TABLE `tblstaff` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblstaff_departments`
--

DROP TABLE IF EXISTS `tblstaff_departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblstaff_departments` (
  `staffdepartmentid` int(11) NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `departmentid` int(11) NOT NULL,
  PRIMARY KEY (`staffdepartmentid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblstaff_departments`
--

LOCK TABLES `tblstaff_departments` WRITE;
/*!40000 ALTER TABLE `tblstaff_departments` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblstaff_departments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblstaff_permissions`
--

DROP TABLE IF EXISTS `tblstaff_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblstaff_permissions` (
  `staff_id` int(11) NOT NULL,
  `feature` varchar(40) NOT NULL,
  `capability` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblstaff_permissions`
--

LOCK TABLES `tblstaff_permissions` WRITE;
/*!40000 ALTER TABLE `tblstaff_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblstaff_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblstock_take`
--

DROP TABLE IF EXISTS `tblstock_take`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblstock_take` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `description` text DEFAULT NULL COMMENT 'the reason stock take',
  `warehouse_id` int(11) DEFAULT NULL,
  `date_stock_take` date DEFAULT NULL,
  `stock_take_code` varchar(100) DEFAULT NULL COMMENT 'số kiểm kê kho',
  `date_add` date DEFAULT NULL,
  `hour_add` date DEFAULT NULL,
  `staff_id` varchar(100) DEFAULT NULL,
  `approval` int(11) DEFAULT 0 COMMENT 'status approval ',
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblstock_take`
--

LOCK TABLES `tblstock_take` WRITE;
/*!40000 ALTER TABLE `tblstock_take` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblstock_take` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblstock_take_detail`
--

DROP TABLE IF EXISTS `tblstock_take_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblstock_take_detail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `stock_take_id` int(11) NOT NULL,
  `commodity_code` varchar(100) DEFAULT NULL,
  `commodity_name` text DEFAULT NULL,
  `unit_id` text DEFAULT NULL,
  `unit_price` varchar(100) DEFAULT NULL,
  `quantity_stock_take` varchar(100) DEFAULT NULL,
  `quantity_accounting_book` varchar(100) DEFAULT NULL,
  `quantity_change` varchar(100) DEFAULT NULL,
  `handling` text DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `approval` int(11) DEFAULT 0 COMMENT 'status approval ',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblstock_take_detail`
--

LOCK TABLES `tblstock_take_detail` WRITE;
/*!40000 ALTER TABLE `tblstock_take_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblstock_take_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblsubscriptions`
--

DROP TABLE IF EXISTS `tblsubscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblsubscriptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `description_in_item` tinyint(1) NOT NULL DEFAULT 0,
  `clientid` int(11) NOT NULL,
  `date` date DEFAULT NULL,
  `terms` mediumtext DEFAULT NULL,
  `currency` int(11) NOT NULL,
  `tax_id` int(11) NOT NULL DEFAULT 0,
  `stripe_tax_id` varchar(50) DEFAULT NULL,
  `tax_id_2` int(11) NOT NULL DEFAULT 0,
  `stripe_tax_id_2` varchar(50) DEFAULT NULL,
  `stripe_plan_id` mediumtext DEFAULT NULL,
  `stripe_subscription_id` mediumtext NOT NULL,
  `next_billing_cycle` bigint(20) DEFAULT NULL,
  `ends_at` bigint(20) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `project_id` int(11) NOT NULL DEFAULT 0,
  `hash` varchar(32) NOT NULL,
  `created` datetime NOT NULL,
  `created_from` int(11) NOT NULL,
  `date_subscribed` datetime DEFAULT NULL,
  `in_test_environment` int(11) DEFAULT NULL,
  `last_sent_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `currency` (`currency`),
  KEY `tax_id` (`tax_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblsubscriptions`
--

LOCK TABLES `tblsubscriptions` WRITE;
/*!40000 ALTER TABLE `tblsubscriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblsubscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltaggables`
--

DROP TABLE IF EXISTS `tbltaggables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbltaggables` (
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) NOT NULL,
  `tag_id` int(11) NOT NULL,
  `tag_order` int(11) NOT NULL DEFAULT 0,
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`),
  KEY `tag_id` (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltaggables`
--

LOCK TABLES `tbltaggables` WRITE;
/*!40000 ALTER TABLE `tbltaggables` DISABLE KEYS */;
INSERT INTO `tbltaggables` VALUES (3,'invoice',1,1),(4,'invoice',1,1);
/*!40000 ALTER TABLE `tbltaggables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltags`
--

DROP TABLE IF EXISTS `tbltags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbltags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltags`
--

LOCK TABLES `tbltags` WRITE;
/*!40000 ALTER TABLE `tbltags` DISABLE KEYS */;
INSERT INTO `tbltags` VALUES (1,'psaas');
/*!40000 ALTER TABLE `tbltags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltask_assigned`
--

DROP TABLE IF EXISTS `tbltask_assigned`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbltask_assigned` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `taskid` int(11) NOT NULL,
  `assigned_from` int(11) NOT NULL DEFAULT 0,
  `is_assigned_from_contact` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `taskid` (`taskid`),
  KEY `staffid` (`staffid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltask_assigned`
--

LOCK TABLES `tbltask_assigned` WRITE;
/*!40000 ALTER TABLE `tbltask_assigned` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltask_assigned` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltask_checklist_items`
--

DROP TABLE IF EXISTS `tbltask_checklist_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbltask_checklist_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `taskid` int(11) NOT NULL,
  `description` mediumtext NOT NULL,
  `finished` int(11) NOT NULL DEFAULT 0,
  `dateadded` datetime NOT NULL,
  `addedfrom` int(11) NOT NULL,
  `finished_from` int(11) DEFAULT 0,
  `list_order` int(11) NOT NULL DEFAULT 0,
  `assigned` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `taskid` (`taskid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltask_checklist_items`
--

LOCK TABLES `tbltask_checklist_items` WRITE;
/*!40000 ALTER TABLE `tbltask_checklist_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltask_checklist_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltask_comments`
--

DROP TABLE IF EXISTS `tbltask_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbltask_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` mediumtext NOT NULL,
  `taskid` int(11) NOT NULL,
  `staffid` int(11) NOT NULL,
  `contact_id` int(11) NOT NULL DEFAULT 0,
  `file_id` int(11) NOT NULL DEFAULT 0,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `file_id` (`file_id`),
  KEY `taskid` (`taskid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltask_comments`
--

LOCK TABLES `tbltask_comments` WRITE;
/*!40000 ALTER TABLE `tbltask_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltask_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltask_followers`
--

DROP TABLE IF EXISTS `tbltask_followers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbltask_followers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `taskid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltask_followers`
--

LOCK TABLES `tbltask_followers` WRITE;
/*!40000 ALTER TABLE `tbltask_followers` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltask_followers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltasks`
--

DROP TABLE IF EXISTS `tbltasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbltasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  `startdate` date NOT NULL,
  `duedate` date DEFAULT NULL,
  `datefinished` datetime DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `is_added_from_contact` tinyint(1) NOT NULL DEFAULT 0,
  `status` int(11) NOT NULL DEFAULT 0,
  `recurring_type` varchar(10) DEFAULT NULL,
  `repeat_every` int(11) DEFAULT NULL,
  `recurring` int(11) NOT NULL DEFAULT 0,
  `is_recurring_from` int(11) DEFAULT NULL,
  `cycles` int(11) NOT NULL DEFAULT 0,
  `total_cycles` int(11) NOT NULL DEFAULT 0,
  `custom_recurring` tinyint(1) NOT NULL DEFAULT 0,
  `last_recurring_date` date DEFAULT NULL,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(30) DEFAULT NULL,
  `is_public` tinyint(1) NOT NULL DEFAULT 0,
  `billable` tinyint(1) NOT NULL DEFAULT 0,
  `billed` tinyint(1) NOT NULL DEFAULT 0,
  `invoice_id` int(11) NOT NULL DEFAULT 0,
  `hourly_rate` decimal(15,2) NOT NULL DEFAULT 0.00,
  `milestone` int(11) DEFAULT 0,
  `kanban_order` int(11) DEFAULT 1,
  `milestone_order` int(11) NOT NULL DEFAULT 0,
  `visible_to_client` tinyint(1) NOT NULL DEFAULT 0,
  `deadline_notified` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`),
  KEY `milestone` (`milestone`),
  KEY `kanban_order` (`kanban_order`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltasks`
--

LOCK TABLES `tbltasks` WRITE;
/*!40000 ALTER TABLE `tbltasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltasks_checklist_templates`
--

DROP TABLE IF EXISTS `tbltasks_checklist_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbltasks_checklist_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltasks_checklist_templates`
--

LOCK TABLES `tbltasks_checklist_templates` WRITE;
/*!40000 ALTER TABLE `tbltasks_checklist_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltasks_checklist_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltaskstimers`
--

DROP TABLE IF EXISTS `tbltaskstimers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbltaskstimers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) NOT NULL,
  `start_time` varchar(64) NOT NULL,
  `end_time` varchar(64) DEFAULT NULL,
  `staff_id` int(11) NOT NULL,
  `hourly_rate` decimal(15,2) NOT NULL DEFAULT 0.00,
  `note` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `task_id` (`task_id`),
  KEY `staff_id` (`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltaskstimers`
--

LOCK TABLES `tbltaskstimers` WRITE;
/*!40000 ALTER TABLE `tbltaskstimers` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltaskstimers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltaxes`
--

DROP TABLE IF EXISTS `tbltaxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbltaxes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `taxrate` decimal(15,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltaxes`
--

LOCK TABLES `tbltaxes` WRITE;
/*!40000 ALTER TABLE `tbltaxes` DISABLE KEYS */;
INSERT INTO `tbltaxes` VALUES (1,'CGST',9.00),(2,'SGST',9.00),(3,'UGST',9.00),(4,'IGST',18.00);
/*!40000 ALTER TABLE `tbltaxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltemplates`
--

DROP TABLE IF EXISTS `tbltemplates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbltemplates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `type` varchar(100) NOT NULL,
  `addedfrom` int(11) NOT NULL,
  `content` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltemplates`
--

LOCK TABLES `tbltemplates` WRITE;
/*!40000 ALTER TABLE `tbltemplates` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltemplates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblticket_attachments`
--

DROP TABLE IF EXISTS `tblticket_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblticket_attachments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticketid` int(11) NOT NULL,
  `replyid` int(11) DEFAULT NULL,
  `file_name` varchar(191) NOT NULL,
  `filetype` varchar(50) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblticket_attachments`
--

LOCK TABLES `tblticket_attachments` WRITE;
/*!40000 ALTER TABLE `tblticket_attachments` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblticket_attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblticket_replies`
--

DROP TABLE IF EXISTS `tblticket_replies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblticket_replies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticketid` int(11) NOT NULL,
  `userid` int(11) DEFAULT NULL,
  `contactid` int(11) NOT NULL DEFAULT 0,
  `name` mediumtext DEFAULT NULL,
  `email` mediumtext DEFAULT NULL,
  `date` datetime NOT NULL,
  `message` mediumtext DEFAULT NULL,
  `attachment` int(11) DEFAULT NULL,
  `admin` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblticket_replies`
--

LOCK TABLES `tblticket_replies` WRITE;
/*!40000 ALTER TABLE `tblticket_replies` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblticket_replies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltickets`
--

DROP TABLE IF EXISTS `tbltickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbltickets` (
  `ticketid` int(11) NOT NULL AUTO_INCREMENT,
  `adminreplying` int(11) NOT NULL DEFAULT 0,
  `userid` int(11) NOT NULL,
  `contactid` int(11) NOT NULL DEFAULT 0,
  `merged_ticket_id` int(11) DEFAULT NULL,
  `email` mediumtext DEFAULT NULL,
  `name` mediumtext DEFAULT NULL,
  `department` int(11) NOT NULL,
  `priority` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `service` int(11) DEFAULT NULL,
  `ticketkey` varchar(32) NOT NULL,
  `subject` varchar(191) NOT NULL,
  `message` mediumtext DEFAULT NULL,
  `admin` int(11) DEFAULT NULL,
  `date` datetime NOT NULL,
  `project_id` int(11) NOT NULL DEFAULT 0,
  `lastreply` datetime DEFAULT NULL,
  `clientread` int(11) NOT NULL DEFAULT 0,
  `adminread` int(11) NOT NULL DEFAULT 0,
  `assigned` int(11) NOT NULL DEFAULT 0,
  `staff_id_replying` int(11) DEFAULT NULL,
  `cc` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`ticketid`),
  KEY `service` (`service`),
  KEY `department` (`department`),
  KEY `status` (`status`),
  KEY `userid` (`userid`),
  KEY `priority` (`priority`),
  KEY `project_id` (`project_id`),
  KEY `contactid` (`contactid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltickets`
--

LOCK TABLES `tbltickets` WRITE;
/*!40000 ALTER TABLE `tbltickets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltickets_pipe_log`
--

DROP TABLE IF EXISTS `tbltickets_pipe_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbltickets_pipe_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `email_to` varchar(100) NOT NULL,
  `name` varchar(191) NOT NULL,
  `subject` varchar(191) NOT NULL,
  `message` longtext NOT NULL,
  `email` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltickets_pipe_log`
--

LOCK TABLES `tbltickets_pipe_log` WRITE;
/*!40000 ALTER TABLE `tbltickets_pipe_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltickets_pipe_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltickets_predefined_replies`
--

DROP TABLE IF EXISTS `tbltickets_predefined_replies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbltickets_predefined_replies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `message` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltickets_predefined_replies`
--

LOCK TABLES `tbltickets_predefined_replies` WRITE;
/*!40000 ALTER TABLE `tbltickets_predefined_replies` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltickets_predefined_replies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltickets_priorities`
--

DROP TABLE IF EXISTS `tbltickets_priorities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbltickets_priorities` (
  `priorityid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`priorityid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltickets_priorities`
--

LOCK TABLES `tbltickets_priorities` WRITE;
/*!40000 ALTER TABLE `tbltickets_priorities` DISABLE KEYS */;
INSERT INTO `tbltickets_priorities` VALUES (1,'Low'),(2,'Medium'),(3,'High');
/*!40000 ALTER TABLE `tbltickets_priorities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltickets_status`
--

DROP TABLE IF EXISTS `tbltickets_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbltickets_status` (
  `ticketstatusid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `isdefault` int(11) NOT NULL DEFAULT 0,
  `statuscolor` varchar(7) DEFAULT NULL,
  `statusorder` int(11) DEFAULT NULL,
  PRIMARY KEY (`ticketstatusid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltickets_status`
--

LOCK TABLES `tbltickets_status` WRITE;
/*!40000 ALTER TABLE `tbltickets_status` DISABLE KEYS */;
INSERT INTO `tbltickets_status` VALUES (1,'Open',1,'#ff2d42',1),(2,'In progress',1,'#22c55e',2),(3,'Answered',1,'#2563eb',3),(4,'On Hold',1,'#64748b',4),(5,'Closed',1,'#03a9f4',5);
/*!40000 ALTER TABLE `tbltickets_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltimesheets_additional_timesheet`
--

DROP TABLE IF EXISTS `tbltimesheets_additional_timesheet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbltimesheets_additional_timesheet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `additional_day` varchar(45) NOT NULL,
  `status` varchar(45) NOT NULL,
  `timekeeping_type` varchar(50) DEFAULT NULL,
  `timekeeping_value` varchar(45) NOT NULL,
  `approver` int(11) NOT NULL,
  `creator` int(11) NOT NULL,
  `old_timekeeping` varchar(50) DEFAULT NULL,
  `time_in` varchar(45) DEFAULT NULL,
  `time_out` varchar(45) DEFAULT NULL,
  `overtime_setting` int(11) DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `staff_id` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltimesheets_additional_timesheet`
--

LOCK TABLES `tbltimesheets_additional_timesheet` WRITE;
/*!40000 ALTER TABLE `tbltimesheets_additional_timesheet` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltimesheets_additional_timesheet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltimesheets_approval_details`
--

DROP TABLE IF EXISTS `tbltimesheets_approval_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbltimesheets_approval_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(45) NOT NULL,
  `staffid` varchar(45) DEFAULT NULL,
  `approve` varchar(45) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `approve_action` varchar(255) DEFAULT NULL,
  `reject_action` varchar(255) DEFAULT NULL,
  `approve_value` varchar(255) DEFAULT NULL,
  `reject_value` varchar(255) DEFAULT NULL,
  `staff_approve` int(11) DEFAULT NULL,
  `action` varchar(45) DEFAULT NULL,
  `sender` int(11) DEFAULT NULL,
  `date_send` datetime DEFAULT NULL,
  `notification_recipient` longtext DEFAULT NULL,
  `approval_deadline` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltimesheets_approval_details`
--

LOCK TABLES `tbltimesheets_approval_details` WRITE;
/*!40000 ALTER TABLE `tbltimesheets_approval_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltimesheets_approval_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltimesheets_approval_setting`
--

DROP TABLE IF EXISTS `tbltimesheets_approval_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbltimesheets_approval_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `related` varchar(255) NOT NULL,
  `setting` longtext NOT NULL,
  `choose_when_approving` int(11) NOT NULL DEFAULT 0,
  `notification_recipient` longtext DEFAULT NULL,
  `number_day_approval` int(11) DEFAULT NULL,
  `departments` text DEFAULT NULL,
  `job_positions` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltimesheets_approval_setting`
--

LOCK TABLES `tbltimesheets_approval_setting` WRITE;
/*!40000 ALTER TABLE `tbltimesheets_approval_setting` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltimesheets_approval_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltimesheets_day_off`
--

DROP TABLE IF EXISTS `tbltimesheets_day_off`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbltimesheets_day_off` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `year` varchar(45) DEFAULT NULL,
  `total` varchar(45) DEFAULT NULL,
  `remain` varchar(45) DEFAULT NULL,
  `accumulated` varchar(45) DEFAULT NULL,
  `days_off` float DEFAULT 0,
  `type_of_leave` varchar(200) NOT NULL DEFAULT '8',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltimesheets_day_off`
--

LOCK TABLES `tbltimesheets_day_off` WRITE;
/*!40000 ALTER TABLE `tbltimesheets_day_off` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltimesheets_day_off` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltimesheets_go_bussiness_advance_payment`
--

DROP TABLE IF EXISTS `tbltimesheets_go_bussiness_advance_payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbltimesheets_go_bussiness_advance_payment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `requisition_leave` int(11) NOT NULL,
  `used_to` varchar(200) DEFAULT NULL,
  `amoun_of_money` varchar(200) DEFAULT NULL,
  `request_date` date DEFAULT NULL,
  `advance_payment_reason` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltimesheets_go_bussiness_advance_payment`
--

LOCK TABLES `tbltimesheets_go_bussiness_advance_payment` WRITE;
/*!40000 ALTER TABLE `tbltimesheets_go_bussiness_advance_payment` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltimesheets_go_bussiness_advance_payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltimesheets_latch_timesheet`
--

DROP TABLE IF EXISTS `tbltimesheets_latch_timesheet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbltimesheets_latch_timesheet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `month_latch` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltimesheets_latch_timesheet`
--

LOCK TABLES `tbltimesheets_latch_timesheet` WRITE;
/*!40000 ALTER TABLE `tbltimesheets_latch_timesheet` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltimesheets_latch_timesheet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltimesheets_leave`
--

DROP TABLE IF EXISTS `tbltimesheets_leave`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbltimesheets_leave` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `date_work` date NOT NULL,
  `value` text DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltimesheets_leave`
--

LOCK TABLES `tbltimesheets_leave` WRITE;
/*!40000 ALTER TABLE `tbltimesheets_leave` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltimesheets_leave` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltimesheets_log_send_notify`
--

DROP TABLE IF EXISTS `tbltimesheets_log_send_notify`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbltimesheets_log_send_notify` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sent` int(11) NOT NULL DEFAULT 0,
  `staffid` int(11) NOT NULL DEFAULT 0,
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  `type` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltimesheets_log_send_notify`
--

LOCK TABLES `tbltimesheets_log_send_notify` WRITE;
/*!40000 ALTER TABLE `tbltimesheets_log_send_notify` DISABLE KEYS */;
INSERT INTO `tbltimesheets_log_send_notify` VALUES (1,1,0,'2025-06-25 00:00:00','approval_expiration'),(2,1,0,'2025-06-26 00:00:00','approval_expiration'),(3,1,0,'2025-06-27 00:00:00','approval_expiration'),(4,1,0,'2025-06-28 00:00:00','approval_expiration'),(5,1,0,'2025-06-29 00:00:00','approval_expiration'),(6,1,0,'2025-07-08 00:00:00','approval_expiration');
/*!40000 ALTER TABLE `tbltimesheets_log_send_notify` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltimesheets_option`
--

DROP TABLE IF EXISTS `tbltimesheets_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbltimesheets_option` (
  `option_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(200) NOT NULL,
  `option_val` longtext DEFAULT NULL,
  `auto` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`option_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltimesheets_option`
--

LOCK TABLES `tbltimesheets_option` WRITE;
/*!40000 ALTER TABLE `tbltimesheets_option` DISABLE KEYS */;
INSERT INTO `tbltimesheets_option` VALUES (1,'shift_applicable_object','',1),(2,'timekeeping_form','timekeeping_manually',1),(3,'timekeeping_manually_role','',1),(4,'timekeeping_task_role','',1),(5,'csv_clsx_role','',1),(6,'attendance_notice_recipient','',1),(7,'allows_updating_check_in_time','1',1),(8,'allows_to_choose_an_older_date','0',1),(9,'allow_attendance_by_coordinates','0',1),(10,'googlemap_api_key','',1),(11,'allow_attendance_by_route','0',1),(12,'auto_checkout','0',1),(13,'auto_checkout_type','1',1),(14,'auto_checkout_value','1',1),(15,'send_notification_if_check_in_forgotten','0',1),(16,'send_notification_if_check_in_forgotten_value','30',1),(17,'start_month_for_annual_leave_cycle','1',1),(18,'start_year_for_annual_leave_cycle','2025',1),(19,'hour_notification_approval_exp','3',1),(20,'timekeeping_enable_valid_ip','0',1),(21,'send_email_check_in_out_customer_location','0',1),(22,'allow_employees_to_create_work_points','0',1),(23,'type_of_leave_selected','8',1);
/*!40000 ALTER TABLE `tbltimesheets_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltimesheets_requisition_leave`
--

DROP TABLE IF EXISTS `tbltimesheets_requisition_leave`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbltimesheets_requisition_leave` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `subject` varchar(100) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `received_date` date DEFAULT NULL,
  `amount_received` text DEFAULT NULL,
  `approver_id` int(11) NOT NULL,
  `followers_id` int(11) DEFAULT NULL,
  `rel_type` int(11) NOT NULL COMMENT '1:Leave 2:Late_early 3:Go_out 4:Go_on_bussiness',
  `status` int(11) DEFAULT 0 COMMENT '0:Create 1:Approver 2:Reject',
  `place_of_business` longtext DEFAULT NULL,
  `type_of_leave` int(11) DEFAULT 0,
  `according_to_the_plan` int(11) DEFAULT 0,
  `handover_recipients` longtext DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `number_of_days` float DEFAULT NULL,
  `number_of_leaving_day` varchar(45) DEFAULT NULL,
  `type_of_leave_text` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`,`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltimesheets_requisition_leave`
--

LOCK TABLES `tbltimesheets_requisition_leave` WRITE;
/*!40000 ALTER TABLE `tbltimesheets_requisition_leave` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltimesheets_requisition_leave` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltimesheets_route`
--

DROP TABLE IF EXISTS `tbltimesheets_route`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbltimesheets_route` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `route_point_id` int(11) NOT NULL,
  `date_work` date NOT NULL,
  `order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltimesheets_route`
--

LOCK TABLES `tbltimesheets_route` WRITE;
/*!40000 ALTER TABLE `tbltimesheets_route` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltimesheets_route` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltimesheets_route_point`
--

DROP TABLE IF EXISTS `tbltimesheets_route_point`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbltimesheets_route_point` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `route_point_address` varchar(400) DEFAULT NULL,
  `latitude` varchar(30) DEFAULT NULL,
  `longitude` varchar(30) DEFAULT NULL,
  `distance` double DEFAULT NULL,
  `related_to` int(11) NOT NULL,
  `related_id` int(11) NOT NULL,
  `default` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltimesheets_route_point`
--

LOCK TABLES `tbltimesheets_route_point` WRITE;
/*!40000 ALTER TABLE `tbltimesheets_route_point` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltimesheets_route_point` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltimesheets_shift_sc`
--

DROP TABLE IF EXISTS `tbltimesheets_shift_sc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbltimesheets_shift_sc` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shift_symbol` varchar(45) NOT NULL,
  `time_start_work` varchar(45) NOT NULL,
  `time_end_work` varchar(45) NOT NULL,
  `start_lunch_break_time` varchar(45) NOT NULL,
  `end_lunch_break_time` varchar(45) NOT NULL,
  `late_latency_allowed` varchar(45) NOT NULL,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltimesheets_shift_sc`
--

LOCK TABLES `tbltimesheets_shift_sc` WRITE;
/*!40000 ALTER TABLE `tbltimesheets_shift_sc` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltimesheets_shift_sc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltimesheets_shiftwork_sc`
--

DROP TABLE IF EXISTS `tbltimesheets_shiftwork_sc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbltimesheets_shiftwork_sc` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `date_work` date NOT NULL,
  `shift` int(11) NOT NULL,
  `datecreated` datetime DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltimesheets_shiftwork_sc`
--

LOCK TABLES `tbltimesheets_shiftwork_sc` WRITE;
/*!40000 ALTER TABLE `tbltimesheets_shiftwork_sc` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltimesheets_shiftwork_sc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltimesheets_timekeeper_data`
--

DROP TABLE IF EXISTS `tbltimesheets_timekeeper_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbltimesheets_timekeeper_data` (
  `staff_identifi` varchar(25) NOT NULL,
  `time` datetime NOT NULL,
  `type` varchar(45) NOT NULL,
  PRIMARY KEY (`staff_identifi`,`time`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltimesheets_timekeeper_data`
--

LOCK TABLES `tbltimesheets_timekeeper_data` WRITE;
/*!40000 ALTER TABLE `tbltimesheets_timekeeper_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltimesheets_timekeeper_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltimesheets_timesheet`
--

DROP TABLE IF EXISTS `tbltimesheets_timesheet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbltimesheets_timesheet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `date_work` date NOT NULL,
  `value` text DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  `overtime_setting` int(11) DEFAULT NULL,
  `relate_id` int(11) DEFAULT NULL,
  `relate_type` varchar(25) DEFAULT NULL,
  `latch` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltimesheets_timesheet`
--

LOCK TABLES `tbltimesheets_timesheet` WRITE;
/*!40000 ALTER TABLE `tbltimesheets_timesheet` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltimesheets_timesheet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltimesheets_type_of_leave`
--

DROP TABLE IF EXISTS `tbltimesheets_type_of_leave`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbltimesheets_type_of_leave` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type_name` varchar(200) DEFAULT NULL,
  `slug` varchar(200) DEFAULT NULL,
  `symbol` varchar(5) DEFAULT NULL,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltimesheets_type_of_leave`
--

LOCK TABLES `tbltimesheets_type_of_leave` WRITE;
/*!40000 ALTER TABLE `tbltimesheets_type_of_leave` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltimesheets_type_of_leave` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltimesheets_valid_ip`
--

DROP TABLE IF EXISTS `tbltimesheets_valid_ip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbltimesheets_valid_ip` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ip` varchar(30) DEFAULT NULL,
  `enable` int(11) NOT NULL DEFAULT 1,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltimesheets_valid_ip`
--

LOCK TABLES `tbltimesheets_valid_ip` WRITE;
/*!40000 ALTER TABLE `tbltimesheets_valid_ip` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltimesheets_valid_ip` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltimesheets_workplace`
--

DROP TABLE IF EXISTS `tbltimesheets_workplace`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbltimesheets_workplace` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `workplace_address` varchar(400) DEFAULT NULL,
  `latitude` varchar(30) DEFAULT NULL,
  `longitude` varchar(30) DEFAULT NULL,
  `distance` double DEFAULT NULL,
  `default` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltimesheets_workplace`
--

LOCK TABLES `tbltimesheets_workplace` WRITE;
/*!40000 ALTER TABLE `tbltimesheets_workplace` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltimesheets_workplace` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltimesheets_workplace_assign`
--

DROP TABLE IF EXISTS `tbltimesheets_workplace_assign`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbltimesheets_workplace_assign` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `workplace_id` int(11) NOT NULL,
  `datecreator` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltimesheets_workplace_assign`
--

LOCK TABLES `tbltimesheets_workplace_assign` WRITE;
/*!40000 ALTER TABLE `tbltimesheets_workplace_assign` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltimesheets_workplace_assign` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltodos`
--

DROP TABLE IF EXISTS `tbltodos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbltodos` (
  `todoid` int(11) NOT NULL AUTO_INCREMENT,
  `description` mediumtext NOT NULL,
  `staffid` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  `finished` tinyint(1) NOT NULL,
  `datefinished` datetime DEFAULT NULL,
  `item_order` int(11) DEFAULT NULL,
  PRIMARY KEY (`todoid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltodos`
--

LOCK TABLES `tbltodos` WRITE;
/*!40000 ALTER TABLE `tbltodos` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltodos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltracked_mails`
--

DROP TABLE IF EXISTS `tbltracked_mails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbltracked_mails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` varchar(32) NOT NULL,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(40) NOT NULL,
  `date` datetime NOT NULL,
  `email` varchar(100) NOT NULL,
  `opened` tinyint(1) NOT NULL DEFAULT 0,
  `date_opened` datetime DEFAULT NULL,
  `subject` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltracked_mails`
--

LOCK TABLES `tbltracked_mails` WRITE;
/*!40000 ALTER TABLE `tbltracked_mails` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltracked_mails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltraining_allocation`
--

DROP TABLE IF EXISTS `tbltraining_allocation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbltraining_allocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `training_process_id` varchar(100) NOT NULL,
  `staffid` int(11) DEFAULT NULL,
  `training_type` int(11) DEFAULT NULL,
  `date_add` datetime DEFAULT NULL,
  `training_name` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltraining_allocation`
--

LOCK TABLES `tbltraining_allocation` WRITE;
/*!40000 ALTER TABLE `tbltraining_allocation` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltraining_allocation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltransfer_records_reception`
--

DROP TABLE IF EXISTS `tbltransfer_records_reception`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbltransfer_records_reception` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) DEFAULT NULL,
  `meta` varchar(50) DEFAULT NULL,
  `staffid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltransfer_records_reception`
--

LOCK TABLES `tbltransfer_records_reception` WRITE;
/*!40000 ALTER TABLE `tbltransfer_records_reception` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltransfer_records_reception` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbltwocheckout_log`
--

DROP TABLE IF EXISTS `tbltwocheckout_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbltwocheckout_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference` varchar(64) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `amount` varchar(25) NOT NULL,
  `created_at` datetime NOT NULL,
  `attempt_reference` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `invoice_id` (`invoice_id`),
  CONSTRAINT `tbltwocheckout_log_ibfk_1` FOREIGN KEY (`invoice_id`) REFERENCES `tblinvoices` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbltwocheckout_log`
--

LOCK TABLES `tbltwocheckout_log` WRITE;
/*!40000 ALTER TABLE `tbltwocheckout_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbltwocheckout_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbluser_auto_login`
--

DROP TABLE IF EXISTS `tbluser_auto_login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbluser_auto_login` (
  `key_id` char(32) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_agent` varchar(150) NOT NULL,
  `last_ip` varchar(40) NOT NULL,
  `last_login` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `staff` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbluser_auto_login`
--

LOCK TABLES `tbluser_auto_login` WRITE;
/*!40000 ALTER TABLE `tbluser_auto_login` DISABLE KEYS */;
INSERT INTO `tbluser_auto_login` VALUES ('b7eb7a01e5b989ed4155f0ef4ed28c83',1,'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','157.48.80.182','2025-06-26 00:22:55',1),('39823036f55604a98c7a975dd661f76d',1,'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','157.48.82.220','2025-06-26 06:44:21',1),('3998ba2cb859056e0e1f0e0207076d8c',1,'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','157.48.82.220','2025-06-26 14:28:35',1),('3410c96287d842cf741c20a1dfc3b85b',1,'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2409:40d4:10cd:43f8:f408:13f9:e02c:5190','2025-06-27 05:32:09',1),('03e950af7ea972be6880bbcefac0f4f3',1,'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2409:40d4:10cd:43f8:f408:13f9:e02c:5190','2025-06-27 07:24:06',1),('31456b4b9028ebcb2907b8139cd1d463',1,'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2409:40d4:10cd:43f8:f408:13f9:e02c:5190','2025-06-27 09:46:46',1),('4c51b610477a45e5726196ae72560cc3',1,'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','103.39.118.49','2025-07-06 14:34:22',1),('eac310608c035db4c02042a58781dd07',1,'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','49.36.189.194','2025-07-07 18:53:06',1),('25eaea83587922621a27e4852c5b1165',1,'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','49.36.189.194','2025-07-08 04:07:12',1);
/*!40000 ALTER TABLE `tbluser_auto_login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbluser_meta`
--

DROP TABLE IF EXISTS `tbluser_meta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbluser_meta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `staff_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `client_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `contact_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(191) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  `candidate_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`umeta_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbluser_meta`
--

LOCK TABLES `tbluser_meta` WRITE;
/*!40000 ALTER TABLE `tbluser_meta` DISABLE KEYS */;
INSERT INTO `tbluser_meta` VALUES (10,0,0,10,'consent_key','3365662ca8a4a5b9527114d427f0de54-8a46e83bb9ff8797b133c6cf3fed2b98',0),(11,0,0,11,'consent_key','63fa91f4b63efa8f2fdda40f06f27c4b-30b556268243fbc235b252cda3dc16ba',0),(12,0,0,12,'consent_key','5dfc4fbf353b2366d8cbf7c1e3376953-f0ae1e8d5803f63fa39ad23910de0c5b',0);
/*!40000 ALTER TABLE `tbluser_meta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblvault`
--

DROP TABLE IF EXISTS `tblvault`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblvault` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `server_address` varchar(191) NOT NULL,
  `port` int(11) DEFAULT NULL,
  `username` varchar(191) NOT NULL,
  `password` mediumtext NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `creator` int(11) NOT NULL,
  `creator_name` varchar(100) DEFAULT NULL,
  `visibility` tinyint(1) NOT NULL DEFAULT 1,
  `share_in_projects` tinyint(1) NOT NULL DEFAULT 0,
  `last_updated` datetime DEFAULT NULL,
  `last_updated_from` varchar(100) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblvault`
--

LOCK TABLES `tblvault` WRITE;
/*!40000 ALTER TABLE `tblvault` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblvault` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblviews_tracking`
--

DROP TABLE IF EXISTS `tblviews_tracking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblviews_tracking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(40) NOT NULL,
  `date` datetime NOT NULL,
  `view_ip` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblviews_tracking`
--

LOCK TABLES `tblviews_tracking` WRITE;
/*!40000 ALTER TABLE `tblviews_tracking` DISABLE KEYS */;
INSERT INTO `tblviews_tracking` VALUES (2,3,'invoice','2025-07-08 10:27:11','49.36.189.194');
/*!40000 ALTER TABLE `tblviews_tracking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblware_body_type`
--

DROP TABLE IF EXISTS `tblware_body_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblware_body_type` (
  `body_type_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `body_code` varchar(100) DEFAULT NULL,
  `body_name` text DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  `display` int(1) DEFAULT NULL COMMENT 'display 1: display (yes)  0: not displayed (no)',
  `note` text DEFAULT NULL,
  PRIMARY KEY (`body_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblware_body_type`
--

LOCK TABLES `tblware_body_type` WRITE;
/*!40000 ALTER TABLE `tblware_body_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblware_body_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblware_color`
--

DROP TABLE IF EXISTS `tblware_color`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblware_color` (
  `color_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `color_code` varchar(100) DEFAULT NULL,
  `color_name` varchar(100) DEFAULT NULL,
  `color_hex` text DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  `display` int(1) DEFAULT NULL COMMENT 'display 1: display (yes)  0: not displayed (no)',
  `note` text DEFAULT NULL,
  PRIMARY KEY (`color_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblware_color`
--

LOCK TABLES `tblware_color` WRITE;
/*!40000 ALTER TABLE `tblware_color` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblware_color` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblware_commodity_type`
--

DROP TABLE IF EXISTS `tblware_commodity_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblware_commodity_type` (
  `commodity_type_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `commondity_code` varchar(100) DEFAULT NULL,
  `commondity_name` text DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  `display` int(1) DEFAULT NULL COMMENT 'display 1: display (yes)  0: not displayed (no)',
  `note` text DEFAULT NULL,
  PRIMARY KEY (`commodity_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblware_commodity_type`
--

LOCK TABLES `tblware_commodity_type` WRITE;
/*!40000 ALTER TABLE `tblware_commodity_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblware_commodity_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblware_size_type`
--

DROP TABLE IF EXISTS `tblware_size_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblware_size_type` (
  `size_type_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `size_code` varchar(100) DEFAULT NULL,
  `size_name` text DEFAULT NULL,
  `size_symbol` text DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  `display` int(1) DEFAULT NULL COMMENT 'display 1: display (yes)  0: not displayed (no)',
  `note` text DEFAULT NULL,
  PRIMARY KEY (`size_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblware_size_type`
--

LOCK TABLES `tblware_size_type` WRITE;
/*!40000 ALTER TABLE `tblware_size_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblware_size_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblware_style_type`
--

DROP TABLE IF EXISTS `tblware_style_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblware_style_type` (
  `style_type_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `style_code` varchar(100) DEFAULT NULL,
  `style_barcode` text DEFAULT NULL,
  `style_name` text DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  `display` int(1) DEFAULT NULL COMMENT 'display 1: display (yes)  0: not displayed (no)',
  `note` text DEFAULT NULL,
  PRIMARY KEY (`style_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblware_style_type`
--

LOCK TABLES `tblware_style_type` WRITE;
/*!40000 ALTER TABLE `tblware_style_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblware_style_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblware_unit_type`
--

DROP TABLE IF EXISTS `tblware_unit_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblware_unit_type` (
  `unit_type_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `unit_code` varchar(100) DEFAULT NULL,
  `unit_name` text DEFAULT NULL,
  `unit_symbol` text DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  `display` int(1) DEFAULT NULL COMMENT 'display 1: display (yes)  0: not displayed (no)',
  `note` text DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `unit_measure_type` varchar(100) DEFAULT 'reference',
  `bigger_ratio` decimal(15,5) DEFAULT 0.00000,
  `smaller_ratio` decimal(15,5) DEFAULT 0.00000,
  `rounding` decimal(15,5) DEFAULT 0.00000,
  PRIMARY KEY (`unit_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblware_unit_type`
--

LOCK TABLES `tblware_unit_type` WRITE;
/*!40000 ALTER TABLE `tblware_unit_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblware_unit_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblwarehouse`
--

DROP TABLE IF EXISTS `tblwarehouse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblwarehouse` (
  `warehouse_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `warehouse_code` varchar(100) DEFAULT NULL,
  `warehouse_name` text DEFAULT NULL,
  `warehouse_address` text DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  `display` int(1) DEFAULT NULL COMMENT 'display 1: display (yes)  0: not displayed (no)',
  `note` text DEFAULT NULL,
  `city` text DEFAULT NULL,
  `state` text DEFAULT NULL,
  `zip_code` text DEFAULT NULL,
  `country` text DEFAULT NULL,
  `hide_warehouse_when_out_of_stock` int(11) DEFAULT 0 COMMENT ' 1: yes  0: no',
  PRIMARY KEY (`warehouse_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblwarehouse`
--

LOCK TABLES `tblwarehouse` WRITE;
/*!40000 ALTER TABLE `tblwarehouse` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblwarehouse` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblweb_to_lead`
--

DROP TABLE IF EXISTS `tblweb_to_lead`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblweb_to_lead` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `form_key` varchar(32) NOT NULL,
  `lead_source` int(11) NOT NULL,
  `lead_status` int(11) NOT NULL,
  `notify_lead_imported` int(11) NOT NULL DEFAULT 1,
  `notify_type` varchar(20) DEFAULT NULL,
  `notify_ids` longtext DEFAULT NULL,
  `responsible` int(11) NOT NULL DEFAULT 0,
  `name` varchar(191) NOT NULL,
  `form_data` longtext DEFAULT NULL,
  `recaptcha` int(11) NOT NULL DEFAULT 0,
  `submit_btn_name` varchar(40) DEFAULT NULL,
  `submit_btn_text_color` varchar(10) DEFAULT '#ffffff',
  `submit_btn_bg_color` varchar(10) DEFAULT '#84c529',
  `success_submit_msg` mediumtext DEFAULT NULL,
  `submit_action` int(11) DEFAULT 0,
  `lead_name_prefix` varchar(255) DEFAULT NULL,
  `submit_redirect_url` longtext DEFAULT NULL,
  `language` varchar(40) DEFAULT NULL,
  `allow_duplicate` int(11) NOT NULL DEFAULT 1,
  `mark_public` int(11) NOT NULL DEFAULT 0,
  `track_duplicate_field` varchar(20) DEFAULT NULL,
  `track_duplicate_field_and` varchar(20) DEFAULT NULL,
  `create_task_on_duplicate` int(11) NOT NULL DEFAULT 0,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblweb_to_lead`
--

LOCK TABLES `tblweb_to_lead` WRITE;
/*!40000 ALTER TABLE `tblweb_to_lead` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblweb_to_lead` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblweb_to_recruitment`
--

DROP TABLE IF EXISTS `tblweb_to_recruitment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblweb_to_recruitment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `campaign_code` varchar(200) DEFAULT NULL,
  `campaign_name` varchar(200) DEFAULT NULL,
  `cp_proposal` text DEFAULT NULL,
  `cp_position` int(11) DEFAULT NULL,
  `cp_department` int(11) DEFAULT NULL,
  `cp_amount_recruiment` int(11) DEFAULT NULL,
  `cp_form_work` varchar(45) DEFAULT NULL,
  `cp_workplace` varchar(255) DEFAULT NULL,
  `cp_salary_from` decimal(15,0) DEFAULT NULL,
  `cp_salary_to` decimal(15,0) DEFAULT NULL,
  `cp_from_date` date DEFAULT NULL,
  `cp_to_date` date DEFAULT NULL,
  `cp_reason_recruitment` text DEFAULT NULL,
  `cp_job_description` text DEFAULT NULL,
  `cp_manager` text DEFAULT NULL,
  `cp_follower` text DEFAULT NULL,
  `cp_ages_from` int(11) DEFAULT NULL,
  `cp_ages_to` int(11) DEFAULT NULL,
  `cp_gender` varchar(10) DEFAULT NULL,
  `cp_height` float DEFAULT NULL,
  `cp_weight` float DEFAULT NULL,
  `cp_literacy` varchar(200) DEFAULT NULL,
  `cp_experience` varchar(200) DEFAULT NULL,
  `cp_add_from` int(11) DEFAULT NULL,
  `cp_date_add` date DEFAULT NULL,
  `cp_status` int(11) DEFAULT NULL,
  `nation` varchar(15) DEFAULT NULL,
  `nationality` varchar(15) DEFAULT NULL,
  `religion` varchar(15) DEFAULT NULL,
  `marital_status` varchar(15) DEFAULT NULL,
  `birthplace` varchar(200) DEFAULT NULL,
  `home_town` varchar(200) DEFAULT NULL,
  `resident` varchar(200) DEFAULT NULL,
  `current_accommodation` varchar(200) DEFAULT NULL,
  `cp_desired_salary` varchar(10) DEFAULT NULL,
  `specialized` varchar(100) DEFAULT NULL,
  `training_form` varchar(50) DEFAULT NULL,
  `training_places` varchar(50) DEFAULT NULL,
  `lead_source` varchar(10) DEFAULT NULL,
  `lead_status` varchar(10) DEFAULT NULL,
  `notify_ids_staff` text DEFAULT NULL,
  `notify_ids_roles` text DEFAULT NULL,
  `form_key` varchar(32) DEFAULT NULL,
  `notify_lead_imported` int(11) DEFAULT 1,
  `notify_type` varchar(20) DEFAULT NULL,
  `notify_ids` mediumtext DEFAULT NULL,
  `responsible` int(11) DEFAULT 0,
  `name` varchar(191) DEFAULT NULL,
  `form_data` mediumtext DEFAULT NULL,
  `recaptcha` int(11) DEFAULT 0,
  `submit_btn_name` varchar(40) DEFAULT NULL,
  `success_submit_msg` text DEFAULT NULL,
  `language` varchar(40) DEFAULT NULL,
  `allow_duplicate` int(11) DEFAULT 1,
  `mark_public` int(11) DEFAULT 0,
  `track_duplicate_field` varchar(20) DEFAULT NULL,
  `track_duplicate_field_and` varchar(20) DEFAULT NULL,
  `create_task_on_duplicate` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblweb_to_recruitment`
--

LOCK TABLES `tblweb_to_recruitment` WRITE;
/*!40000 ALTER TABLE `tblweb_to_recruitment` DISABLE KEYS */;
INSERT INTO `tblweb_to_recruitment` VALUES (1,'','','',0,0,1,'','',0,0,'0000-00-00','0000-00-00','','','','',15,60,'',1,40,'','',0,'0000-00-00',0,'','','','','','','','','','','','','','','','','046aa3c2188fa5eed1119c81b8a100d9',0,'','',0,'recruitment_form','[{\"label\":\"Croatia\",\"value\":\"55\"},{\"label\":\"Cuba\",\"value\":\"56\"},{\"label\":\"Curacao\",\"value\":\"57\"},{\"label\":\"Cyprus\",\"value\":\"58\"},{\"label\":\"Czech Republic\",\"value\":\"59\"},{\"label\":\"Democratic Republic of the Congo\",\"value\":\"60\"},{\"label\":\"Denmark\",\"value\":\"61\"},{\"label\":\"Djibouti\",\"value\":\"62\"},{\"label\":\"Dominica\",\"value\":\"63\"},{\"label\":\"Dominican Republic\",\"value\":\"64\"},{\"label\":\"Ecuador\",\"value\":\"65\"},{\"label\":\"Egypt\",\"value\":\"66\"},{\"label\":\"El Salvador\",\"value\":\"67\"},{\"label\":\"Equatorial Guinea\",\"value\":\"68\"},{\"label\":\"Eritrea\",\"value\":\"69\"},{\"label\":\"Estonia\",\"value\":\"70\"},{\"label\":\"Ethiopia\",\"value\":\"71\"},{\"label\":\"Falkland Islands (Malvinas)\",\"value\":\"72\"},{\"label\":\"Faroe Islands\",\"value\":\"73\"},{\"label\":\"Fiji\",\"value\":\"74\"},{\"label\":\"Finland\",\"value\":\"75\"},{\"label\":\"France\",\"value\":\"76\"},{\"label\":\"French Guiana\",\"value\":\"77\"},{\"label\":\"French Polynesia\",\"value\":\"78\"},{\"label\":\"French Southern Territories\",\"value\":\"79\"},{\"label\":\"Gabon\",\"value\":\"80\"},{\"label\":\"Gambia\",\"value\":\"81\"},{\"label\":\"Georgia\",\"value\":\"82\"},{\"label\":\"Germany\",\"value\":\"83\"},{\"label\":\"Ghana\",\"value\":\"84\"},{\"label\":\"Gibraltar\",\"value\":\"85\"},{\"label\":\"Greece\",\"value\":\"86\"},{\"label\":\"Greenland\",\"value\":\"87\"},{\"label\":\"Grenada\",\"value\":\"88\"},{\"label\":\"Guadaloupe\",\"value\":\"89\"},{\"label\":\"Guam\",\"value\":\"90\"},{\"label\":\"Guatemala\",\"value\":\"91\"},{\"label\":\"Guernsey\",\"value\":\"92\"},{\"label\":\"Guinea\",\"value\":\"93\"},{\"label\":\"Guinea-Bissau\",\"value\":\"94\"},{\"label\":\"Guyana\",\"value\":\"95\"},{\"label\":\"Haiti\",\"value\":\"96\"},{\"label\":\"Heard Island and McDonald Islands\",\"value\":\"97\"},{\"label\":\"Honduras\",\"value\":\"98\"},{\"label\":\"Hong Kong\",\"value\":\"99\"},{\"label\":\"Hungary\",\"value\":\"100\"},{\"label\":\"Iceland\",\"value\":\"101\"},{\"label\":\"India\",\"value\":\"102\"},{\"label\":\"Indonesia\",\"value\":\"103\"},{\"label\":\"Iran\",\"value\":\"104\"},{\"label\":\"Iraq\",\"value\":\"105\"},{\"label\":\"Ireland\",\"value\":\"106\"},{\"label\":\"Isle of Man\",\"value\":\"107\"},{\"label\":\"Israel\",\"value\":\"108\"},{\"label\":\"Italy\",\"value\":\"109\"},{\"label\":\"Jamaica\",\"value\":\"110\"},{\"label\":\"Japan\",\"value\":\"111\"},{\"label\":\"Jersey\",\"value\":\"112\"},{\"label\":\"Jordan\",\"value\":\"113\"},{\"label\":\"Kazakhstan\",\"value\":\"114\"},{\"label\":\"Kenya\",\"value\":\"115\"},{\"label\":\"Kiribati\",\"value\":\"116\"},{\"label\":\"Kosovo\",\"value\":\"117\"},{\"label\":\"Kuwait\",\"value\":\"118\"},{\"label\":\"Kyrgyzstan\",\"value\":\"119\"},{\"label\":\"Laos\",\"value\":\"120\"},{\"label\":\"Latvia\",\"value\":\"121\"},{\"label\":\"Lebanon\",\"value\":\"122\"},{\"label\":\"Lesotho\",\"value\":\"123\"},{\"label\":\"Liberia\",\"value\":\"124\"},{\"label\":\"Libya\",\"value\":\"125\"},{\"label\":\"Liechtenstein\",\"value\":\"126\"},{\"label\":\"Lithuania\",\"value\":\"127\"},{\"label\":\"Luxembourg\",\"value\":\"128\"},{\"label\":\"Macao\",\"value\":\"129\"},{\"label\":\"North Macedonia\",\"value\":\"130\"},{\"label\":\"Madagascar\",\"value\":\"131\"},{\"label\":\"Malawi\",\"value\":\"132\"},{\"label\":\"Malaysia\",\"value\":\"133\"},{\"label\":\"Maldives\",\"value\":\"134\"},{\"label\":\"Mali\",\"value\":\"135\"},{\"label\":\"Malta\",\"value\":\"136\"},{\"label\":\"Marshall Islands\",\"value\":\"137\"},{\"label\":\"Martinique\",\"value\":\"138\"},{\"label\":\"Mauritania\",\"value\":\"139\"},{\"label\":\"Mauritius\",\"value\":\"140\"},{\"label\":\"Mayotte\",\"value\":\"141\"},{\"label\":\"Mexico\",\"value\":\"142\"},{\"label\":\"Micronesia\",\"value\":\"143\"},{\"label\":\"Moldava\",\"value\":\"144\"},{\"label\":\"Monaco\",\"value\":\"145\"},{\"label\":\"Mongolia\",\"value\":\"146\"},{\"label\":\"Montenegro\",\"value\":\"147\"},{\"label\":\"Montserrat\",\"value\":\"148\"},{\"label\":\"Morocco\",\"value\":\"149\"},{\"label\":\"Mozambique\",\"value\":\"150\"},{\"label\":\"Myanmar (Burma)\",\"value\":\"151\"},{\"label\":\"Namibia\",\"value\":\"152\"},{\"label\":\"Nauru\",\"value\":\"153\"},{\"label\":\"Nepal\",\"value\":\"154\"},{\"label\":\"Netherlands\",\"value\":\"155\"},{\"label\":\"New Caledonia\",\"value\":\"156\"},{\"label\":\"New Zealand\",\"value\":\"157\"},{\"label\":\"Nicaragua\",\"value\":\"158\"},{\"label\":\"Niger\",\"value\":\"159\"},{\"label\":\"Nigeria\",\"value\":\"160\"},{\"label\":\"Niue\",\"value\":\"161\"},{\"label\":\"Norfolk Island\",\"value\":\"162\"},{\"label\":\"North Korea\",\"value\":\"163\"},{\"label\":\"Northern Mariana Islands\",\"value\":\"164\"},{\"label\":\"Norway\",\"value\":\"165\"},{\"label\":\"Oman\",\"value\":\"166\"},{\"label\":\"Pakistan\",\"value\":\"167\"},{\"label\":\"Palau\",\"value\":\"168\"},{\"label\":\"Palestine\",\"value\":\"169\"},{\"label\":\"Panama\",\"value\":\"170\"},{\"label\":\"Papua New Guinea\",\"value\":\"171\"},{\"label\":\"Paraguay\",\"value\":\"172\"},{\"label\":\"Peru\",\"value\":\"173\"},{\"label\":\"Phillipines\",\"value\":\"174\"},{\"label\":\"Pitcairn\",\"value\":\"175\"},{\"label\":\"Poland\",\"value\":\"176\"},{\"label\":\"Portugal\",\"value\":\"177\"},{\"label\":\"Puerto Rico\",\"value\":\"178\"},{\"label\":\"Qatar\",\"value\":\"179\"},{\"label\":\"Reunion\",\"value\":\"180\"},{\"label\":\"Romania\",\"value\":\"181\"},{\"label\":\"Russia\",\"value\":\"182\"},{\"label\":\"Rwanda\",\"value\":\"183\"},{\"label\":\"Saint Barthelemy\",\"value\":\"184\"},{\"label\":\"Saint Helena\",\"value\":\"185\"},{\"label\":\"Saint Kitts and Nevis\",\"value\":\"186\"},{\"label\":\"Saint Lucia\",\"value\":\"187\"},{\"label\":\"Saint Martin\",\"value\":\"188\"},{\"label\":\"Saint Pierre and Miquelon\",\"value\":\"189\"},{\"label\":\"Saint Vincent and the Grenadines\",\"value\":\"190\"},{\"label\":\"Samoa\",\"value\":\"191\"},{\"label\":\"San Marino\",\"value\":\"192\"},{\"label\":\"Sao Tome and Principe\",\"value\":\"193\"},{\"label\":\"Saudi Arabia\",\"value\":\"194\"},{\"label\":\"Senegal\",\"value\":\"195\"},{\"label\":\"Serbia\",\"value\":\"196\"},{\"label\":\"Seychelles\",\"value\":\"197\"},{\"label\":\"Sierra Leone\",\"value\":\"198\"},{\"label\":\"Singapore\",\"value\":\"199\"},{\"label\":\"Sint Maarten\",\"value\":\"200\"},{\"label\":\"Slovakia\",\"value\":\"201\"},{\"label\":\"Slovenia\",\"value\":\"202\"},{\"label\":\"Solomon Islands\",\"value\":\"203\"},{\"label\":\"Somalia\",\"value\":\"204\"},{\"label\":\"South Africa\",\"value\":\"205\"},{\"label\":\"South Georgia and the South Sandwich Islands\",\"value\":\"206\"},{\"label\":\"South Korea\",\"value\":\"207\"},{\"label\":\"South Sudan\",\"value\":\"208\"},{\"label\":\"Spain\",\"value\":\"209\"},{\"label\":\"Sri Lanka\",\"value\":\"210\"},{\"label\":\"Sudan\",\"value\":\"211\"},{\"label\":\"Suriname\",\"value\":\"212\"},{\"label\":\"Svalbard and Jan Mayen\",\"value\":\"213\"},{\"label\":\"Swaziland\",\"value\":\"214\"},{\"label\":\"Sweden\",\"value\":\"215\"},{\"label\":\"Switzerland\",\"value\":\"216\"},{\"label\":\"Syria\",\"value\":\"217\"},{\"label\":\"Taiwan\",\"value\":\"218\"},{\"label\":\"Tajikistan\",\"value\":\"219\"},{\"label\":\"Tanzania\",\"value\":\"220\"},{\"label\":\"Thailand\",\"value\":\"221\"},{\"label\":\"Timor-Leste (East Timor)\",\"value\":\"222\"},{\"label\":\"Togo\",\"value\":\"223\"},{\"label\":\"Tokelau\",\"value\":\"224\"},{\"label\":\"Tonga\",\"value\":\"225\"},{\"label\":\"Trinidad and Tobago\",\"value\":\"226\"},{\"label\":\"Tunisia\",\"value\":\"227\"},{\"label\":\"Turkey\",\"value\":\"228\"},{\"label\":\"Turkmenistan\",\"value\":\"229\"},{\"label\":\"Turks and Caicos Islands\",\"value\":\"230\"},{\"label\":\"Tuvalu\",\"value\":\"231\"},{\"label\":\"Uganda\",\"value\":\"232\"},{\"label\":\"Ukraine\",\"value\":\"233\"},{\"label\":\"United Arab Emirates\",\"value\":\"234\"},{\"label\":\"United Kingdom\",\"value\":\"235\"},{\"label\":\"United States\",\"value\":\"236\"},{\"label\":\"United States Minor Outlying Islands\",\"value\":\"237\"},{\"label\":\"Uruguay\",\"value\":\"238\"},{\"label\":\"Uzbekistan\",\"value\":\"239\"},{\"label\":\"Vanuatu\",\"value\":\"240\"},{\"label\":\"Vatican City\",\"value\":\"241\"},{\"label\":\"Venezuela\",\"value\":\"242\"},{\"label\":\"Vietnam\",\"value\":\"243\",\"selected\":true},{\"label\":\"Virgin Islands, British\",\"value\":\"244\"},{\"label\":\"Virgin Islands, US\",\"value\":\"245\"},{\"label\":\"Wallis and Futuna\",\"value\":\"246\"},{\"label\":\"Western Sahara\",\"value\":\"247\"},{\"label\":\"Yemen\",\"value\":\"248\"},{\"label\":\"Zambia\",\"value\":\"249\"},{\"label\":\"Zimbabwe\",\"value\":\"250\"}]},{\"type\":\"text\",\"label\":\"_national\",\"className\":\"form-control\",\"name\":\"nation\",\"subtype\":\"text\"},{\"type\":\"text\",\"label\":\"_religion\",\"className\":\"form-control\",\"name\":\"religion\",\"subtype\":\"text\"},{\"type\":\"text\",\"label\":\"_phone\",\"className\":\"form-control\",\"name\":\"phonenumber\",\"subtype\":\"text\"},{\"type\":\"select\",\"label\":\"_diploma\",\"className\":\"form-control\",\"name\":\"diploma\",\"values\":[{\"label\":\"\",\"value\":\"\"},{\"label\":\"master_s_degree\",\"value\":\"0\"},{\"label\":\"Ph_D\",\"value\":\"1\"},{\"label\":\"bachelor\",\"value\":\"2\"},{\"label\":\"university\",\"value\":\"3\"},{\"label\":\"vocational_colleges\",\"value\":\"4\"},{\"label\":\"vocational\",\"value\":\"5\"},{\"label\":\"high_school\",\"value\":\"6\"}]},{\"type\":\"text\",\"label\":\"training_places\",\"className\":\"form-control\",\"name\":\"training_places\",\"subtype\":\"text\"},{\"type\":\"text\",\"label\":\"specialized\",\"className\":\"form-control\",\"name\":\"specialized\",\"subtype\":\"text\"},{\"type\":\"text\",\"label\":\"forms_of_training\",\"className\":\"form-control\",\"name\":\"training_form\",\"subtype\":\"text\"},{\"type\":\"text\",\"label\":\"issue_date_identification_card\",\"className\":\"form-control fc-datepicker\",\"name\":\"days_for_identity\",\"subtype\":\"text\"}]',0,'sent','sent_successfully','',0,0,'','',0);
/*!40000 ALTER TABLE `tblweb_to_recruitment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblwh_activity_log`
--

DROP TABLE IF EXISTS `tblwh_activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblwh_activity_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(45) NOT NULL,
  `staffid` int(11) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `note` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblwh_activity_log`
--

LOCK TABLES `tblwh_activity_log` WRITE;
/*!40000 ALTER TABLE `tblwh_activity_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblwh_activity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblwh_approval_details`
--

DROP TABLE IF EXISTS `tblwh_approval_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblwh_approval_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(45) NOT NULL,
  `staffid` varchar(45) DEFAULT NULL,
  `approve` varchar(45) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `approve_action` varchar(255) DEFAULT NULL,
  `reject_action` varchar(255) DEFAULT NULL,
  `approve_value` varchar(255) DEFAULT NULL,
  `reject_value` varchar(255) DEFAULT NULL,
  `staff_approve` int(11) DEFAULT NULL,
  `action` varchar(45) DEFAULT NULL,
  `sender` int(11) DEFAULT NULL,
  `date_send` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblwh_approval_details`
--

LOCK TABLES `tblwh_approval_details` WRITE;
/*!40000 ALTER TABLE `tblwh_approval_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblwh_approval_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblwh_approval_setting`
--

DROP TABLE IF EXISTS `tblwh_approval_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblwh_approval_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `related` varchar(255) NOT NULL,
  `setting` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblwh_approval_setting`
--

LOCK TABLES `tblwh_approval_setting` WRITE;
/*!40000 ALTER TABLE `tblwh_approval_setting` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblwh_approval_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblwh_brand`
--

DROP TABLE IF EXISTS `tblwh_brand`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblwh_brand` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblwh_brand`
--

LOCK TABLES `tblwh_brand` WRITE;
/*!40000 ALTER TABLE `tblwh_brand` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblwh_brand` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblwh_custom_fields`
--

DROP TABLE IF EXISTS `tblwh_custom_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblwh_custom_fields` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `custom_fields_id` int(11) DEFAULT NULL,
  `warehouse_id` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblwh_custom_fields`
--

LOCK TABLES `tblwh_custom_fields` WRITE;
/*!40000 ALTER TABLE `tblwh_custom_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblwh_custom_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblwh_goods_delivery_activity_log`
--

DROP TABLE IF EXISTS `tblwh_goods_delivery_activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblwh_goods_delivery_activity_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(100) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `additional_data` text DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `staffid` int(11) DEFAULT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblwh_goods_delivery_activity_log`
--

LOCK TABLES `tblwh_goods_delivery_activity_log` WRITE;
/*!40000 ALTER TABLE `tblwh_goods_delivery_activity_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblwh_goods_delivery_activity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblwh_inventory_serial_numbers`
--

DROP TABLE IF EXISTS `tblwh_inventory_serial_numbers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblwh_inventory_serial_numbers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `commodity_id` int(11) NOT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `inventory_manage_id` int(11) DEFAULT NULL,
  `serial_number` varchar(255) DEFAULT NULL,
  `is_used` varchar(20) DEFAULT 'no',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblwh_inventory_serial_numbers`
--

LOCK TABLES `tblwh_inventory_serial_numbers` WRITE;
/*!40000 ALTER TABLE `tblwh_inventory_serial_numbers` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblwh_inventory_serial_numbers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblwh_loss_adjustment`
--

DROP TABLE IF EXISTS `tblwh_loss_adjustment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblwh_loss_adjustment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(15) DEFAULT NULL,
  `addfrom` int(11) DEFAULT NULL,
  `reason` longtext DEFAULT NULL,
  `time` datetime DEFAULT NULL,
  `date_create` date NOT NULL,
  `status` int(11) NOT NULL,
  `warehouses` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblwh_loss_adjustment`
--

LOCK TABLES `tblwh_loss_adjustment` WRITE;
/*!40000 ALTER TABLE `tblwh_loss_adjustment` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblwh_loss_adjustment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblwh_loss_adjustment_detail`
--

DROP TABLE IF EXISTS `tblwh_loss_adjustment_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblwh_loss_adjustment_detail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `items` int(11) DEFAULT NULL,
  `unit` int(11) DEFAULT NULL,
  `current_number` int(15) DEFAULT NULL,
  `updates_number` int(15) DEFAULT NULL,
  `loss_adjustment` int(11) DEFAULT NULL,
  `expiry_date` text DEFAULT NULL,
  `lot_number` text DEFAULT NULL,
  `commodity_name` text DEFAULT NULL,
  `serial_number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblwh_loss_adjustment_detail`
--

LOCK TABLES `tblwh_loss_adjustment_detail` WRITE;
/*!40000 ALTER TABLE `tblwh_loss_adjustment_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblwh_loss_adjustment_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblwh_model`
--

DROP TABLE IF EXISTS `tblwh_model`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblwh_model` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` text DEFAULT NULL,
  `brand_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`brand_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblwh_model`
--

LOCK TABLES `tblwh_model` WRITE;
/*!40000 ALTER TABLE `tblwh_model` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblwh_model` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblwh_omni_shipments`
--

DROP TABLE IF EXISTS `tblwh_omni_shipments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblwh_omni_shipments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cart_id` int(11) DEFAULT NULL,
  `shipment_number` varchar(100) DEFAULT NULL,
  `planned_shipping_date` datetime DEFAULT NULL,
  `shipment_status` varchar(50) DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `goods_delivery_id` int(11) DEFAULT NULL,
  `shipment_hash` varchar(32) DEFAULT NULL,
  `order_id` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblwh_omni_shipments`
--

LOCK TABLES `tblwh_omni_shipments` WRITE;
/*!40000 ALTER TABLE `tblwh_omni_shipments` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblwh_omni_shipments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblwh_order_return_details`
--

DROP TABLE IF EXISTS `tblwh_order_return_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblwh_order_return_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_return_id` int(11) NOT NULL,
  `rel_type_detail_id` int(11) DEFAULT NULL,
  `commodity_code` int(11) DEFAULT NULL,
  `commodity_name` text DEFAULT NULL,
  `quantity` decimal(15,2) DEFAULT 0.00,
  `unit_id` int(11) DEFAULT NULL,
  `unit_price` decimal(15,2) DEFAULT 0.00,
  `sub_total` decimal(15,2) DEFAULT 0.00,
  `tax_id` text DEFAULT NULL,
  `tax_rate` text DEFAULT NULL,
  `tax_name` text DEFAULT NULL,
  `total_amount` decimal(15,2) DEFAULT 0.00,
  `discount` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `total_after_discount` decimal(15,2) DEFAULT 0.00,
  `reason_return` varchar(200) DEFAULT NULL,
  `purchase_price` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblwh_order_return_details`
--

LOCK TABLES `tblwh_order_return_details` WRITE;
/*!40000 ALTER TABLE `tblwh_order_return_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblwh_order_return_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblwh_order_returns`
--

DROP TABLE IF EXISTS `tblwh_order_returns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblwh_order_returns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(50) NOT NULL COMMENT 'manual, sales_return_order, purchasing_return_order',
  `return_type` varchar(50) DEFAULT NULL COMMENT 'manual, partially, fully',
  `company_id` int(11) DEFAULT NULL,
  `company_name` varchar(500) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phonenumber` varchar(20) DEFAULT NULL,
  `order_number` varchar(500) DEFAULT NULL,
  `order_date` datetime DEFAULT NULL,
  `number_of_item` decimal(15,2) DEFAULT 0.00,
  `order_total` decimal(15,2) DEFAULT 0.00,
  `order_return_number` varchar(200) DEFAULT NULL,
  `order_return_name` varchar(500) DEFAULT NULL,
  `fee_return_order` decimal(15,2) DEFAULT 0.00,
  `refund_loyaty_point` int(11) DEFAULT 0,
  `subtotal` decimal(15,2) DEFAULT 0.00,
  `total_amount` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `additional_discount` decimal(15,2) DEFAULT 0.00,
  `adjustment_amount` decimal(15,2) DEFAULT 0.00,
  `total_after_discount` decimal(15,2) DEFAULT 0.00,
  `return_policies_information` text DEFAULT NULL,
  `admin_note` text DEFAULT NULL,
  `approval` int(11) DEFAULT 0,
  `datecreated` datetime DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `receipt_delivery_id` int(1) DEFAULT 0,
  `currency` int(11) DEFAULT NULL,
  `return_reason` longtext DEFAULT NULL,
  `receipt_delivery_type` varchar(100) DEFAULT NULL,
  `status` varchar(30) DEFAULT 'draft',
  `discount_type` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblwh_order_returns`
--

LOCK TABLES `tblwh_order_returns` WRITE;
/*!40000 ALTER TABLE `tblwh_order_returns` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblwh_order_returns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblwh_order_returns_refunds`
--

DROP TABLE IF EXISTS `tblwh_order_returns_refunds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblwh_order_returns_refunds` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `order_return_id` int(11) DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `refunded_on` date DEFAULT NULL,
  `payment_mode` varchar(40) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `amount` decimal(15,2) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblwh_order_returns_refunds`
--

LOCK TABLES `tblwh_order_returns_refunds` WRITE;
/*!40000 ALTER TABLE `tblwh_order_returns_refunds` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblwh_order_returns_refunds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblwh_packing_list_details`
--

DROP TABLE IF EXISTS `tblwh_packing_list_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblwh_packing_list_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `packing_list_id` int(11) NOT NULL,
  `delivery_detail_id` int(11) DEFAULT NULL,
  `commodity_code` int(11) DEFAULT NULL,
  `commodity_name` text DEFAULT NULL,
  `quantity` decimal(15,2) DEFAULT 0.00,
  `unit_id` int(11) DEFAULT NULL,
  `unit_price` decimal(15,2) DEFAULT 0.00,
  `sub_total` decimal(15,2) DEFAULT 0.00,
  `tax_id` text DEFAULT NULL,
  `tax_rate` text DEFAULT NULL,
  `tax_name` text DEFAULT NULL,
  `total_amount` decimal(15,2) DEFAULT 0.00,
  `discount` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `total_after_discount` decimal(15,2) DEFAULT 0.00,
  `serial_number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblwh_packing_list_details`
--

LOCK TABLES `tblwh_packing_list_details` WRITE;
/*!40000 ALTER TABLE `tblwh_packing_list_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblwh_packing_list_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblwh_packing_lists`
--

DROP TABLE IF EXISTS `tblwh_packing_lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblwh_packing_lists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `delivery_note_id` int(11) DEFAULT NULL,
  `packing_list_number` varchar(100) DEFAULT NULL,
  `packing_list_name` varchar(200) DEFAULT NULL,
  `width` decimal(15,2) DEFAULT 0.00,
  `height` decimal(15,2) DEFAULT 0.00,
  `lenght` decimal(15,2) DEFAULT 0.00,
  `weight` decimal(15,2) DEFAULT 0.00,
  `volume` decimal(15,2) DEFAULT 0.00,
  `clientid` int(11) DEFAULT NULL,
  `subtotal` decimal(15,2) DEFAULT 0.00,
  `total_amount` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `additional_discount` decimal(15,2) DEFAULT 0.00,
  `total_after_discount` decimal(15,2) DEFAULT 0.00,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT NULL,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT NULL,
  `client_note` text DEFAULT NULL,
  `admin_note` text DEFAULT NULL,
  `approval` int(11) DEFAULT 0,
  `datecreated` datetime DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `type_of_packing_list` varchar(100) DEFAULT 'total',
  `delivery_status` varchar(100) DEFAULT 'wh_ready_to_deliver',
  `shipping_fee` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblwh_packing_lists`
--

LOCK TABLES `tblwh_packing_lists` WRITE;
/*!40000 ALTER TABLE `tblwh_packing_lists` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblwh_packing_lists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblwh_series`
--

DROP TABLE IF EXISTS `tblwh_series`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblwh_series` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` text DEFAULT NULL,
  `model_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`model_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblwh_series`
--

LOCK TABLES `tblwh_series` WRITE;
/*!40000 ALTER TABLE `tblwh_series` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblwh_series` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblwh_staff_warehouses`
--

DROP TABLE IF EXISTS `tblwh_staff_warehouses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblwh_staff_warehouses` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblwh_staff_warehouses`
--

LOCK TABLES `tblwh_staff_warehouses` WRITE;
/*!40000 ALTER TABLE `tblwh_staff_warehouses` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblwh_staff_warehouses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblwh_sub_group`
--

DROP TABLE IF EXISTS `tblwh_sub_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblwh_sub_group` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sub_group_code` varchar(100) DEFAULT NULL,
  `sub_group_name` text DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  `display` int(1) DEFAULT NULL COMMENT 'display 1: display (yes)  0: not displayed (no)',
  `note` text DEFAULT NULL,
  `group_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblwh_sub_group`
--

LOCK TABLES `tblwh_sub_group` WRITE;
/*!40000 ALTER TABLE `tblwh_sub_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblwh_sub_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblwhatsapp_api_debug_log`
--

DROP TABLE IF EXISTS `tblwhatsapp_api_debug_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblwhatsapp_api_debug_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `api_endpoint` varchar(255) DEFAULT NULL,
  `phone_number_id` varchar(255) DEFAULT NULL,
  `access_token` text DEFAULT NULL,
  `business_account_id` varchar(255) DEFAULT NULL,
  `response_code` varchar(4) NOT NULL,
  `response_data` text NOT NULL,
  `send_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`send_json`)),
  `message_category` varchar(50) NOT NULL,
  `category_params` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`category_params`)),
  `merge_field_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`merge_field_data`)),
  `recorded_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblwhatsapp_api_debug_log`
--

LOCK TABLES `tblwhatsapp_api_debug_log` WRITE;
/*!40000 ALTER TABLE `tblwhatsapp_api_debug_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblwhatsapp_api_debug_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblwhatsapp_templates`
--

DROP TABLE IF EXISTS `tblwhatsapp_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblwhatsapp_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_id` bigint(20) unsigned NOT NULL COMMENT 'id from api',
  `template_name` varchar(255) NOT NULL,
  `language` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  `category` varchar(100) NOT NULL,
  `header_data_format` varchar(10) NOT NULL,
  `header_data_text` text DEFAULT NULL,
  `header_params_count` int(11) NOT NULL,
  `body_data` text NOT NULL,
  `body_params_count` int(11) NOT NULL,
  `footer_data` text DEFAULT NULL,
  `footer_params_count` int(11) NOT NULL,
  `buttons_data` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `template_id` (`template_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblwhatsapp_templates`
--

LOCK TABLES `tblwhatsapp_templates` WRITE;
/*!40000 ALTER TABLE `tblwhatsapp_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblwhatsapp_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblwhatsapp_templates_mapping`
--

DROP TABLE IF EXISTS `tblwhatsapp_templates_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblwhatsapp_templates_mapping` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_id` int(11) NOT NULL,
  `category` varchar(100) NOT NULL,
  `send_to` varchar(50) NOT NULL,
  `header_params` varchar(255) NOT NULL,
  `body_params` varchar(255) NOT NULL,
  `footer_params` varchar(255) NOT NULL,
  `active` tinyint(4) NOT NULL DEFAULT 1,
  `debug_mode` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblwhatsapp_templates_mapping`
--

LOCK TABLES `tblwhatsapp_templates_mapping` WRITE;
/*!40000 ALTER TABLE `tblwhatsapp_templates_mapping` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblwhatsapp_templates_mapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblwork_shift`
--

DROP TABLE IF EXISTS `tblwork_shift`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblwork_shift` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shift_code` varchar(45) NOT NULL,
  `shift_name` varchar(200) NOT NULL,
  `shift_type` varchar(200) NOT NULL,
  `department` varchar(45) DEFAULT NULL,
  `position` varchar(45) DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  `staff` text DEFAULT NULL,
  `date_create` date DEFAULT NULL,
  `from_date` date DEFAULT NULL,
  `to_date` date DEFAULT NULL,
  `shifts_detail` text NOT NULL,
  `type_shiftwork` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblwork_shift`
--

LOCK TABLES `tblwork_shift` WRITE;
/*!40000 ALTER TABLE `tblwork_shift` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblwork_shift` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblwork_shift_detail`
--

DROP TABLE IF EXISTS `tblwork_shift_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblwork_shift_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `shift_id` int(11) DEFAULT NULL,
  `work_shift_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblwork_shift_detail`
--

LOCK TABLES `tblwork_shift_detail` WRITE;
/*!40000 ALTER TABLE `tblwork_shift_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblwork_shift_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblwork_shift_detail_day_name`
--

DROP TABLE IF EXISTS `tblwork_shift_detail_day_name`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblwork_shift_detail_day_name` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `day_name` varchar(45) DEFAULT NULL,
  `shift_id` int(11) DEFAULT NULL,
  `work_shift_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblwork_shift_detail_day_name`
--

LOCK TABLES `tblwork_shift_detail_day_name` WRITE;
/*!40000 ALTER TABLE `tblwork_shift_detail_day_name` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblwork_shift_detail_day_name` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblwork_shift_detail_number_day`
--

DROP TABLE IF EXISTS `tblwork_shift_detail_number_day`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblwork_shift_detail_number_day` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `number` int(11) DEFAULT NULL,
  `shift_id` int(11) DEFAULT NULL,
  `work_shift_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblwork_shift_detail_number_day`
--

LOCK TABLES `tblwork_shift_detail_number_day` WRITE;
/*!40000 ALTER TABLE `tblwork_shift_detail_number_day` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblwork_shift_detail_number_day` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-08  9:28:24
