/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.13-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: ps_techdotbit
-- ------------------------------------------------------
-- Server version	10.11.13-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `techdotbit_tblactivity_log`
--

DROP TABLE IF EXISTS `techdotbit_tblactivity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblactivity_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` longtext NOT NULL,
  `date` datetime NOT NULL,
  `staffid` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `techdotbit_staffid` (`staffid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblactivity_log`
--

LOCK TABLES `techdotbit_tblactivity_log` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblactivity_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblactivity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblannouncements`
--

DROP TABLE IF EXISTS `techdotbit_tblannouncements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblannouncements` (
  `announcementid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `message` mediumtext DEFAULT NULL,
  `showtousers` int(11) NOT NULL,
  `showtostaff` int(11) NOT NULL,
  `showname` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  `userid` varchar(100) NOT NULL,
  PRIMARY KEY (`announcementid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblannouncements`
--

LOCK TABLES `techdotbit_tblannouncements` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblannouncements` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblannouncements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblclients`
--

DROP TABLE IF EXISTS `techdotbit_tblclients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblclients` (
  `userid` int(11) NOT NULL AUTO_INCREMENT,
  `company` varchar(191) DEFAULT NULL,
  `vat` varchar(50) DEFAULT NULL,
  `phonenumber` varchar(30) DEFAULT NULL,
  `country` int(11) NOT NULL DEFAULT 0,
  `city` varchar(100) DEFAULT NULL,
  `zip` varchar(15) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `address` varchar(191) DEFAULT NULL,
  `website` varchar(150) DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `active` int(11) NOT NULL DEFAULT 1,
  `leadid` int(11) DEFAULT NULL,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT 0,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT 0,
  `longitude` varchar(191) DEFAULT NULL,
  `latitude` varchar(191) DEFAULT NULL,
  `default_language` varchar(40) DEFAULT NULL,
  `default_currency` int(11) NOT NULL DEFAULT 0,
  `show_primary_contact` int(11) NOT NULL DEFAULT 0,
  `stripe_id` varchar(40) DEFAULT NULL,
  `registration_confirmed` int(11) NOT NULL DEFAULT 1,
  `addedfrom` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`userid`),
  KEY `country` (`country`),
  KEY `leadid` (`leadid`),
  KEY `company` (`company`),
  KEY `active` (`active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblclients`
--

LOCK TABLES `techdotbit_tblclients` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblclients` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblclients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblconsent_purposes`
--

DROP TABLE IF EXISTS `techdotbit_tblconsent_purposes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblconsent_purposes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `last_updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblconsent_purposes`
--

LOCK TABLES `techdotbit_tblconsent_purposes` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblconsent_purposes` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblconsent_purposes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblconsents`
--

DROP TABLE IF EXISTS `techdotbit_tblconsents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblconsents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action` varchar(10) NOT NULL,
  `date` datetime NOT NULL,
  `ip` varchar(40) NOT NULL,
  `contact_id` int(11) NOT NULL DEFAULT 0,
  `lead_id` int(11) NOT NULL DEFAULT 0,
  `description` mediumtext DEFAULT NULL,
  `opt_in_purpose_description` mediumtext DEFAULT NULL,
  `purpose_id` int(11) NOT NULL,
  `staff_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `purpose_id` (`purpose_id`),
  KEY `contact_id` (`contact_id`),
  KEY `lead_id` (`lead_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblconsents`
--

LOCK TABLES `techdotbit_tblconsents` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblconsents` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblconsents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblcontact_permissions`
--

DROP TABLE IF EXISTS `techdotbit_tblcontact_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblcontact_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permission_id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblcontact_permissions`
--

LOCK TABLES `techdotbit_tblcontact_permissions` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblcontact_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblcontact_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblcontacts`
--

DROP TABLE IF EXISTS `techdotbit_tblcontacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblcontacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `is_primary` int(11) NOT NULL DEFAULT 1,
  `firstname` varchar(191) NOT NULL,
  `lastname` varchar(191) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phonenumber` varchar(100) NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `new_pass_key` varchar(32) DEFAULT NULL,
  `new_pass_key_requested` datetime DEFAULT NULL,
  `email_verified_at` datetime DEFAULT NULL,
  `email_verification_key` varchar(32) DEFAULT NULL,
  `email_verification_sent_at` datetime DEFAULT NULL,
  `last_ip` varchar(40) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_password_change` datetime DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `profile_image` varchar(191) DEFAULT NULL,
  `direction` varchar(3) DEFAULT NULL,
  `invoice_emails` tinyint(1) NOT NULL DEFAULT 1,
  `estimate_emails` tinyint(1) NOT NULL DEFAULT 1,
  `credit_note_emails` tinyint(1) NOT NULL DEFAULT 1,
  `contract_emails` tinyint(1) NOT NULL DEFAULT 1,
  `task_emails` tinyint(1) NOT NULL DEFAULT 1,
  `project_emails` tinyint(1) NOT NULL DEFAULT 1,
  `ticket_emails` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `firstname` (`firstname`),
  KEY `lastname` (`lastname`),
  KEY `email` (`email`),
  KEY `is_primary` (`is_primary`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblcontacts`
--

LOCK TABLES `techdotbit_tblcontacts` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblcontacts` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblcontacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblcontract_comments`
--

DROP TABLE IF EXISTS `techdotbit_tblcontract_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblcontract_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` longtext DEFAULT NULL,
  `contract_id` int(11) NOT NULL,
  `staffid` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblcontract_comments`
--

LOCK TABLES `techdotbit_tblcontract_comments` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblcontract_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblcontract_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblcontract_renewals`
--

DROP TABLE IF EXISTS `techdotbit_tblcontract_renewals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblcontract_renewals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contractid` int(11) NOT NULL,
  `old_start_date` date NOT NULL,
  `new_start_date` date NOT NULL,
  `old_end_date` date DEFAULT NULL,
  `new_end_date` date DEFAULT NULL,
  `old_value` decimal(15,2) DEFAULT NULL,
  `new_value` decimal(15,2) DEFAULT NULL,
  `date_renewed` datetime NOT NULL,
  `renewed_by` varchar(100) NOT NULL,
  `renewed_by_staff_id` int(11) NOT NULL DEFAULT 0,
  `is_on_old_expiry_notified` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblcontract_renewals`
--

LOCK TABLES `techdotbit_tblcontract_renewals` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblcontract_renewals` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblcontract_renewals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblcontracts`
--

DROP TABLE IF EXISTS `techdotbit_tblcontracts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblcontracts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` longtext DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `subject` varchar(191) DEFAULT NULL,
  `client` int(11) NOT NULL,
  `datestart` date DEFAULT NULL,
  `dateend` date DEFAULT NULL,
  `contract_type` int(11) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  `isexpirynotified` int(11) NOT NULL DEFAULT 0,
  `contract_value` decimal(15,2) DEFAULT NULL,
  `trash` tinyint(1) DEFAULT 0,
  `not_visible_to_client` tinyint(1) NOT NULL DEFAULT 0,
  `hash` varchar(32) DEFAULT NULL,
  `signed` tinyint(1) NOT NULL DEFAULT 0,
  `signature` varchar(40) DEFAULT NULL,
  `marked_as_signed` tinyint(1) NOT NULL DEFAULT 0,
  `acceptance_firstname` varchar(50) DEFAULT NULL,
  `acceptance_lastname` varchar(50) DEFAULT NULL,
  `acceptance_email` varchar(100) DEFAULT NULL,
  `acceptance_date` datetime DEFAULT NULL,
  `acceptance_ip` varchar(40) DEFAULT NULL,
  `short_link` varchar(100) DEFAULT NULL,
  `last_sent_at` datetime DEFAULT NULL,
  `contacts_sent_to` mediumtext DEFAULT NULL,
  `last_sign_reminder_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `client` (`client`),
  KEY `contract_type` (`contract_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblcontracts`
--

LOCK TABLES `techdotbit_tblcontracts` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblcontracts` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblcontracts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblcontracts_types`
--

DROP TABLE IF EXISTS `techdotbit_tblcontracts_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblcontracts_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblcontracts_types`
--

LOCK TABLES `techdotbit_tblcontracts_types` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblcontracts_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblcontracts_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblcountries`
--

DROP TABLE IF EXISTS `techdotbit_tblcountries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblcountries` (
  `country_id` int(11) NOT NULL AUTO_INCREMENT,
  `iso2` char(2) DEFAULT NULL,
  `short_name` varchar(80) NOT NULL DEFAULT '',
  `long_name` varchar(80) NOT NULL DEFAULT '',
  `iso3` char(3) DEFAULT NULL,
  `numcode` varchar(6) DEFAULT NULL,
  `un_member` varchar(12) DEFAULT NULL,
  `calling_code` varchar(8) DEFAULT NULL,
  `cctld` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`country_id`)
) ENGINE=InnoDB AUTO_INCREMENT=251 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblcountries`
--

LOCK TABLES `techdotbit_tblcountries` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblcountries` DISABLE KEYS */;
INSERT INTO `techdotbit_tblcountries` VALUES
(1,'AF','Afghanistan','Islamic Republic of Afghanistan','AFG','004','yes','93','.af'),
(2,'AX','Aland Islands','&Aring;land Islands','ALA','248','no','358','.ax'),
(3,'AL','Albania','Republic of Albania','ALB','008','yes','355','.al'),
(4,'DZ','Algeria','People\'s Democratic Republic of Algeria','DZA','012','yes','213','.dz'),
(5,'AS','American Samoa','American Samoa','ASM','016','no','1+684','.as'),
(6,'AD','Andorra','Principality of Andorra','AND','020','yes','376','.ad'),
(7,'AO','Angola','Republic of Angola','AGO','024','yes','244','.ao'),
(8,'AI','Anguilla','Anguilla','AIA','660','no','1+264','.ai'),
(9,'AQ','Antarctica','Antarctica','ATA','010','no','672','.aq'),
(10,'AG','Antigua and Barbuda','Antigua and Barbuda','ATG','028','yes','1+268','.ag'),
(11,'AR','Argentina','Argentine Republic','ARG','032','yes','54','.ar'),
(12,'AM','Armenia','Republic of Armenia','ARM','051','yes','374','.am'),
(13,'AW','Aruba','Aruba','ABW','533','no','297','.aw'),
(14,'AU','Australia','Commonwealth of Australia','AUS','036','yes','61','.au'),
(15,'AT','Austria','Republic of Austria','AUT','040','yes','43','.at'),
(16,'AZ','Azerbaijan','Republic of Azerbaijan','AZE','031','yes','994','.az'),
(17,'BS','Bahamas','Commonwealth of The Bahamas','BHS','044','yes','1+242','.bs'),
(18,'BH','Bahrain','Kingdom of Bahrain','BHR','048','yes','973','.bh'),
(19,'BD','Bangladesh','People\'s Republic of Bangladesh','BGD','050','yes','880','.bd'),
(20,'BB','Barbados','Barbados','BRB','052','yes','1+246','.bb'),
(21,'BY','Belarus','Republic of Belarus','BLR','112','yes','375','.by'),
(22,'BE','Belgium','Kingdom of Belgium','BEL','056','yes','32','.be'),
(23,'BZ','Belize','Belize','BLZ','084','yes','501','.bz'),
(24,'BJ','Benin','Republic of Benin','BEN','204','yes','229','.bj'),
(25,'BM','Bermuda','Bermuda Islands','BMU','060','no','1+441','.bm'),
(26,'BT','Bhutan','Kingdom of Bhutan','BTN','064','yes','975','.bt'),
(27,'BO','Bolivia','Plurinational State of Bolivia','BOL','068','yes','591','.bo'),
(28,'BQ','Bonaire, Sint Eustatius and Saba','Bonaire, Sint Eustatius and Saba','BES','535','no','599','.bq'),
(29,'BA','Bosnia and Herzegovina','Bosnia and Herzegovina','BIH','070','yes','387','.ba'),
(30,'BW','Botswana','Republic of Botswana','BWA','072','yes','267','.bw'),
(31,'BV','Bouvet Island','Bouvet Island','BVT','074','no','NONE','.bv'),
(32,'BR','Brazil','Federative Republic of Brazil','BRA','076','yes','55','.br'),
(33,'IO','British Indian Ocean Territory','British Indian Ocean Territory','IOT','086','no','246','.io'),
(34,'BN','Brunei','Brunei Darussalam','BRN','096','yes','673','.bn'),
(35,'BG','Bulgaria','Republic of Bulgaria','BGR','100','yes','359','.bg'),
(36,'BF','Burkina Faso','Burkina Faso','BFA','854','yes','226','.bf'),
(37,'BI','Burundi','Republic of Burundi','BDI','108','yes','257','.bi'),
(38,'KH','Cambodia','Kingdom of Cambodia','KHM','116','yes','855','.kh'),
(39,'CM','Cameroon','Republic of Cameroon','CMR','120','yes','237','.cm'),
(40,'CA','Canada','Canada','CAN','124','yes','1','.ca'),
(41,'CV','Cape Verde','Republic of Cape Verde','CPV','132','yes','238','.cv'),
(42,'KY','Cayman Islands','The Cayman Islands','CYM','136','no','1+345','.ky'),
(43,'CF','Central African Republic','Central African Republic','CAF','140','yes','236','.cf'),
(44,'TD','Chad','Republic of Chad','TCD','148','yes','235','.td'),
(45,'CL','Chile','Republic of Chile','CHL','152','yes','56','.cl'),
(46,'CN','China','People\'s Republic of China','CHN','156','yes','86','.cn'),
(47,'CX','Christmas Island','Christmas Island','CXR','162','no','61','.cx'),
(48,'CC','Cocos (Keeling) Islands','Cocos (Keeling) Islands','CCK','166','no','61','.cc'),
(49,'CO','Colombia','Republic of Colombia','COL','170','yes','57','.co'),
(50,'KM','Comoros','Union of the Comoros','COM','174','yes','269','.km'),
(51,'CG','Congo','Republic of the Congo','COG','178','yes','242','.cg'),
(52,'CK','Cook Islands','Cook Islands','COK','184','some','682','.ck'),
(53,'CR','Costa Rica','Republic of Costa Rica','CRI','188','yes','506','.cr'),
(54,'CI','Cote d\'ivoire (Ivory Coast)','Republic of C&ocirc;te D\'Ivoire (Ivory Coast)','CIV','384','yes','225','.ci'),
(55,'HR','Croatia','Republic of Croatia','HRV','191','yes','385','.hr'),
(56,'CU','Cuba','Republic of Cuba','CUB','192','yes','53','.cu'),
(57,'CW','Curacao','Cura&ccedil;ao','CUW','531','no','599','.cw'),
(58,'CY','Cyprus','Republic of Cyprus','CYP','196','yes','357','.cy'),
(59,'CZ','Czech Republic','Czech Republic','CZE','203','yes','420','.cz'),
(60,'CD','Democratic Republic of the Congo','Democratic Republic of the Congo','COD','180','yes','243','.cd'),
(61,'DK','Denmark','Kingdom of Denmark','DNK','208','yes','45','.dk'),
(62,'DJ','Djibouti','Republic of Djibouti','DJI','262','yes','253','.dj'),
(63,'DM','Dominica','Commonwealth of Dominica','DMA','212','yes','1+767','.dm'),
(64,'DO','Dominican Republic','Dominican Republic','DOM','214','yes','1+809, 8','.do'),
(65,'EC','Ecuador','Republic of Ecuador','ECU','218','yes','593','.ec'),
(66,'EG','Egypt','Arab Republic of Egypt','EGY','818','yes','20','.eg'),
(67,'SV','El Salvador','Republic of El Salvador','SLV','222','yes','503','.sv'),
(68,'GQ','Equatorial Guinea','Republic of Equatorial Guinea','GNQ','226','yes','240','.gq'),
(69,'ER','Eritrea','State of Eritrea','ERI','232','yes','291','.er'),
(70,'EE','Estonia','Republic of Estonia','EST','233','yes','372','.ee'),
(71,'ET','Ethiopia','Federal Democratic Republic of Ethiopia','ETH','231','yes','251','.et'),
(72,'FK','Falkland Islands (Malvinas)','The Falkland Islands (Malvinas)','FLK','238','no','500','.fk'),
(73,'FO','Faroe Islands','The Faroe Islands','FRO','234','no','298','.fo'),
(74,'FJ','Fiji','Republic of Fiji','FJI','242','yes','679','.fj'),
(75,'FI','Finland','Republic of Finland','FIN','246','yes','358','.fi'),
(76,'FR','France','French Republic','FRA','250','yes','33','.fr'),
(77,'GF','French Guiana','French Guiana','GUF','254','no','594','.gf'),
(78,'PF','French Polynesia','French Polynesia','PYF','258','no','689','.pf'),
(79,'TF','French Southern Territories','French Southern Territories','ATF','260','no',NULL,'.tf'),
(80,'GA','Gabon','Gabonese Republic','GAB','266','yes','241','.ga'),
(81,'GM','Gambia','Republic of The Gambia','GMB','270','yes','220','.gm'),
(82,'GE','Georgia','Georgia','GEO','268','yes','995','.ge'),
(83,'DE','Germany','Federal Republic of Germany','DEU','276','yes','49','.de'),
(84,'GH','Ghana','Republic of Ghana','GHA','288','yes','233','.gh'),
(85,'GI','Gibraltar','Gibraltar','GIB','292','no','350','.gi'),
(86,'GR','Greece','Hellenic Republic','GRC','300','yes','30','.gr'),
(87,'GL','Greenland','Greenland','GRL','304','no','299','.gl'),
(88,'GD','Grenada','Grenada','GRD','308','yes','1+473','.gd'),
(89,'GP','Guadaloupe','Guadeloupe','GLP','312','no','590','.gp'),
(90,'GU','Guam','Guam','GUM','316','no','1+671','.gu'),
(91,'GT','Guatemala','Republic of Guatemala','GTM','320','yes','502','.gt'),
(92,'GG','Guernsey','Guernsey','GGY','831','no','44','.gg'),
(93,'GN','Guinea','Republic of Guinea','GIN','324','yes','224','.gn'),
(94,'GW','Guinea-Bissau','Republic of Guinea-Bissau','GNB','624','yes','245','.gw'),
(95,'GY','Guyana','Co-operative Republic of Guyana','GUY','328','yes','592','.gy'),
(96,'HT','Haiti','Republic of Haiti','HTI','332','yes','509','.ht'),
(97,'HM','Heard Island and McDonald Islands','Heard Island and McDonald Islands','HMD','334','no','NONE','.hm'),
(98,'HN','Honduras','Republic of Honduras','HND','340','yes','504','.hn'),
(99,'HK','Hong Kong','Hong Kong','HKG','344','no','852','.hk'),
(100,'HU','Hungary','Hungary','HUN','348','yes','36','.hu'),
(101,'IS','Iceland','Republic of Iceland','ISL','352','yes','354','.is'),
(102,'IN','India','Republic of India','IND','356','yes','91','.in'),
(103,'ID','Indonesia','Republic of Indonesia','IDN','360','yes','62','.id'),
(104,'IR','Iran','Islamic Republic of Iran','IRN','364','yes','98','.ir'),
(105,'IQ','Iraq','Republic of Iraq','IRQ','368','yes','964','.iq'),
(106,'IE','Ireland','Ireland','IRL','372','yes','353','.ie'),
(107,'IM','Isle of Man','Isle of Man','IMN','833','no','44','.im'),
(108,'IL','Israel','State of Israel','ISR','376','yes','972','.il'),
(109,'IT','Italy','Italian Republic','ITA','380','yes','39','.jm'),
(110,'JM','Jamaica','Jamaica','JAM','388','yes','1+876','.jm'),
(111,'JP','Japan','Japan','JPN','392','yes','81','.jp'),
(112,'JE','Jersey','The Bailiwick of Jersey','JEY','832','no','44','.je'),
(113,'JO','Jordan','Hashemite Kingdom of Jordan','JOR','400','yes','962','.jo'),
(114,'KZ','Kazakhstan','Republic of Kazakhstan','KAZ','398','yes','7','.kz'),
(115,'KE','Kenya','Republic of Kenya','KEN','404','yes','254','.ke'),
(116,'KI','Kiribati','Republic of Kiribati','KIR','296','yes','686','.ki'),
(117,'XK','Kosovo','Republic of Kosovo','---','---','some','381',''),
(118,'KW','Kuwait','State of Kuwait','KWT','414','yes','965','.kw'),
(119,'KG','Kyrgyzstan','Kyrgyz Republic','KGZ','417','yes','996','.kg'),
(120,'LA','Laos','Lao People\'s Democratic Republic','LAO','418','yes','856','.la'),
(121,'LV','Latvia','Republic of Latvia','LVA','428','yes','371','.lv'),
(122,'LB','Lebanon','Republic of Lebanon','LBN','422','yes','961','.lb'),
(123,'LS','Lesotho','Kingdom of Lesotho','LSO','426','yes','266','.ls'),
(124,'LR','Liberia','Republic of Liberia','LBR','430','yes','231','.lr'),
(125,'LY','Libya','Libya','LBY','434','yes','218','.ly'),
(126,'LI','Liechtenstein','Principality of Liechtenstein','LIE','438','yes','423','.li'),
(127,'LT','Lithuania','Republic of Lithuania','LTU','440','yes','370','.lt'),
(128,'LU','Luxembourg','Grand Duchy of Luxembourg','LUX','442','yes','352','.lu'),
(129,'MO','Macao','The Macao Special Administrative Region','MAC','446','no','853','.mo'),
(130,'MK','North Macedonia','Republic of North Macedonia','MKD','807','yes','389','.mk'),
(131,'MG','Madagascar','Republic of Madagascar','MDG','450','yes','261','.mg'),
(132,'MW','Malawi','Republic of Malawi','MWI','454','yes','265','.mw'),
(133,'MY','Malaysia','Malaysia','MYS','458','yes','60','.my'),
(134,'MV','Maldives','Republic of Maldives','MDV','462','yes','960','.mv'),
(135,'ML','Mali','Republic of Mali','MLI','466','yes','223','.ml'),
(136,'MT','Malta','Republic of Malta','MLT','470','yes','356','.mt'),
(137,'MH','Marshall Islands','Republic of the Marshall Islands','MHL','584','yes','692','.mh'),
(138,'MQ','Martinique','Martinique','MTQ','474','no','596','.mq'),
(139,'MR','Mauritania','Islamic Republic of Mauritania','MRT','478','yes','222','.mr'),
(140,'MU','Mauritius','Republic of Mauritius','MUS','480','yes','230','.mu'),
(141,'YT','Mayotte','Mayotte','MYT','175','no','262','.yt'),
(142,'MX','Mexico','United Mexican States','MEX','484','yes','52','.mx'),
(143,'FM','Micronesia','Federated States of Micronesia','FSM','583','yes','691','.fm'),
(144,'MD','Moldava','Republic of Moldova','MDA','498','yes','373','.md'),
(145,'MC','Monaco','Principality of Monaco','MCO','492','yes','377','.mc'),
(146,'MN','Mongolia','Mongolia','MNG','496','yes','976','.mn'),
(147,'ME','Montenegro','Montenegro','MNE','499','yes','382','.me'),
(148,'MS','Montserrat','Montserrat','MSR','500','no','1+664','.ms'),
(149,'MA','Morocco','Kingdom of Morocco','MAR','504','yes','212','.ma'),
(150,'MZ','Mozambique','Republic of Mozambique','MOZ','508','yes','258','.mz'),
(151,'MM','Myanmar (Burma)','Republic of the Union of Myanmar','MMR','104','yes','95','.mm'),
(152,'NA','Namibia','Republic of Namibia','NAM','516','yes','264','.na'),
(153,'NR','Nauru','Republic of Nauru','NRU','520','yes','674','.nr'),
(154,'NP','Nepal','Federal Democratic Republic of Nepal','NPL','524','yes','977','.np'),
(155,'NL','Netherlands','Kingdom of the Netherlands','NLD','528','yes','31','.nl'),
(156,'NC','New Caledonia','New Caledonia','NCL','540','no','687','.nc'),
(157,'NZ','New Zealand','New Zealand','NZL','554','yes','64','.nz'),
(158,'NI','Nicaragua','Republic of Nicaragua','NIC','558','yes','505','.ni'),
(159,'NE','Niger','Republic of Niger','NER','562','yes','227','.ne'),
(160,'NG','Nigeria','Federal Republic of Nigeria','NGA','566','yes','234','.ng'),
(161,'NU','Niue','Niue','NIU','570','some','683','.nu'),
(162,'NF','Norfolk Island','Norfolk Island','NFK','574','no','672','.nf'),
(163,'KP','North Korea','Democratic People\'s Republic of Korea','PRK','408','yes','850','.kp'),
(164,'MP','Northern Mariana Islands','Northern Mariana Islands','MNP','580','no','1+670','.mp'),
(165,'NO','Norway','Kingdom of Norway','NOR','578','yes','47','.no'),
(166,'OM','Oman','Sultanate of Oman','OMN','512','yes','968','.om'),
(167,'PK','Pakistan','Islamic Republic of Pakistan','PAK','586','yes','92','.pk'),
(168,'PW','Palau','Republic of Palau','PLW','585','yes','680','.pw'),
(169,'PS','Palestine','State of Palestine (or Occupied Palestinian Territory)','PSE','275','some','970','.ps'),
(170,'PA','Panama','Republic of Panama','PAN','591','yes','507','.pa'),
(171,'PG','Papua New Guinea','Independent State of Papua New Guinea','PNG','598','yes','675','.pg'),
(172,'PY','Paraguay','Republic of Paraguay','PRY','600','yes','595','.py'),
(173,'PE','Peru','Republic of Peru','PER','604','yes','51','.pe'),
(174,'PH','Philippines','Republic of the Philippines','PHL','608','yes','63','.ph'),
(175,'PN','Pitcairn','Pitcairn','PCN','612','no','NONE','.pn'),
(176,'PL','Poland','Republic of Poland','POL','616','yes','48','.pl'),
(177,'PT','Portugal','Portuguese Republic','PRT','620','yes','351','.pt'),
(178,'PR','Puerto Rico','Commonwealth of Puerto Rico','PRI','630','no','1+939','.pr'),
(179,'QA','Qatar','State of Qatar','QAT','634','yes','974','.qa'),
(180,'RE','Reunion','R&eacute;union','REU','638','no','262','.re'),
(181,'RO','Romania','Romania','ROU','642','yes','40','.ro'),
(182,'RU','Russia','Russian Federation','RUS','643','yes','7','.ru'),
(183,'RW','Rwanda','Republic of Rwanda','RWA','646','yes','250','.rw'),
(184,'BL','Saint Barthelemy','Saint Barth&eacute;lemy','BLM','652','no','590','.bl'),
(185,'SH','Saint Helena','Saint Helena, Ascension and Tristan da Cunha','SHN','654','no','290','.sh'),
(186,'KN','Saint Kitts and Nevis','Federation of Saint Christopher and Nevis','KNA','659','yes','1+869','.kn'),
(187,'LC','Saint Lucia','Saint Lucia','LCA','662','yes','1+758','.lc'),
(188,'MF','Saint Martin','Saint Martin','MAF','663','no','590','.mf'),
(189,'PM','Saint Pierre and Miquelon','Saint Pierre and Miquelon','SPM','666','no','508','.pm'),
(190,'VC','Saint Vincent and the Grenadines','Saint Vincent and the Grenadines','VCT','670','yes','1+784','.vc'),
(191,'WS','Samoa','Independent State of Samoa','WSM','882','yes','685','.ws'),
(192,'SM','San Marino','Republic of San Marino','SMR','674','yes','378','.sm'),
(193,'ST','Sao Tome and Principe','Democratic Republic of S&atilde;o Tom&eacute; and Pr&iacute;ncipe','STP','678','yes','239','.st'),
(194,'SA','Saudi Arabia','Kingdom of Saudi Arabia','SAU','682','yes','966','.sa'),
(195,'SN','Senegal','Republic of Senegal','SEN','686','yes','221','.sn'),
(196,'RS','Serbia','Republic of Serbia','SRB','688','yes','381','.rs'),
(197,'SC','Seychelles','Republic of Seychelles','SYC','690','yes','248','.sc'),
(198,'SL','Sierra Leone','Republic of Sierra Leone','SLE','694','yes','232','.sl'),
(199,'SG','Singapore','Republic of Singapore','SGP','702','yes','65','.sg'),
(200,'SX','Sint Maarten','Sint Maarten','SXM','534','no','1+721','.sx'),
(201,'SK','Slovakia','Slovak Republic','SVK','703','yes','421','.sk'),
(202,'SI','Slovenia','Republic of Slovenia','SVN','705','yes','386','.si'),
(203,'SB','Solomon Islands','Solomon Islands','SLB','090','yes','677','.sb'),
(204,'SO','Somalia','Somali Republic','SOM','706','yes','252','.so'),
(205,'ZA','South Africa','Republic of South Africa','ZAF','710','yes','27','.za'),
(206,'GS','South Georgia and the South Sandwich Islands','South Georgia and the South Sandwich Islands','SGS','239','no','500','.gs'),
(207,'KR','South Korea','Republic of Korea','KOR','410','yes','82','.kr'),
(208,'SS','South Sudan','Republic of South Sudan','SSD','728','yes','211','.ss'),
(209,'ES','Spain','Kingdom of Spain','ESP','724','yes','34','.es'),
(210,'LK','Sri Lanka','Democratic Socialist Republic of Sri Lanka','LKA','144','yes','94','.lk'),
(211,'SD','Sudan','Republic of the Sudan','SDN','729','yes','249','.sd'),
(212,'SR','Suriname','Republic of Suriname','SUR','740','yes','597','.sr'),
(213,'SJ','Svalbard and Jan Mayen','Svalbard and Jan Mayen','SJM','744','no','47','.sj'),
(214,'SZ','Swaziland','Kingdom of Swaziland','SWZ','748','yes','268','.sz'),
(215,'SE','Sweden','Kingdom of Sweden','SWE','752','yes','46','.se'),
(216,'CH','Switzerland','Swiss Confederation','CHE','756','yes','41','.ch'),
(217,'SY','Syria','Syrian Arab Republic','SYR','760','yes','963','.sy'),
(218,'TW','Taiwan','Republic of China (Taiwan)','TWN','158','former','886','.tw'),
(219,'TJ','Tajikistan','Republic of Tajikistan','TJK','762','yes','992','.tj'),
(220,'TZ','Tanzania','United Republic of Tanzania','TZA','834','yes','255','.tz'),
(221,'TH','Thailand','Kingdom of Thailand','THA','764','yes','66','.th'),
(222,'TL','Timor-Leste (East Timor)','Democratic Republic of Timor-Leste','TLS','626','yes','670','.tl'),
(223,'TG','Togo','Togolese Republic','TGO','768','yes','228','.tg'),
(224,'TK','Tokelau','Tokelau','TKL','772','no','690','.tk'),
(225,'TO','Tonga','Kingdom of Tonga','TON','776','yes','676','.to'),
(226,'TT','Trinidad and Tobago','Republic of Trinidad and Tobago','TTO','780','yes','1+868','.tt'),
(227,'TN','Tunisia','Republic of Tunisia','TUN','788','yes','216','.tn'),
(228,'TR','Turkey','Republic of Turkey','TUR','792','yes','90','.tr'),
(229,'TM','Turkmenistan','Turkmenistan','TKM','795','yes','993','.tm'),
(230,'TC','Turks and Caicos Islands','Turks and Caicos Islands','TCA','796','no','1+649','.tc'),
(231,'TV','Tuvalu','Tuvalu','TUV','798','yes','688','.tv'),
(232,'UG','Uganda','Republic of Uganda','UGA','800','yes','256','.ug'),
(233,'UA','Ukraine','Ukraine','UKR','804','yes','380','.ua'),
(234,'AE','United Arab Emirates','United Arab Emirates','ARE','784','yes','971','.ae'),
(235,'GB','United Kingdom','United Kingdom of Great Britain and Nothern Ireland','GBR','826','yes','44','.uk'),
(236,'US','United States','United States of America','USA','840','yes','1','.us'),
(237,'UM','United States Minor Outlying Islands','United States Minor Outlying Islands','UMI','581','no','NONE','NONE'),
(238,'UY','Uruguay','Eastern Republic of Uruguay','URY','858','yes','598','.uy'),
(239,'UZ','Uzbekistan','Republic of Uzbekistan','UZB','860','yes','998','.uz'),
(240,'VU','Vanuatu','Republic of Vanuatu','VUT','548','yes','678','.vu'),
(241,'VA','Vatican City','State of the Vatican City','VAT','336','no','39','.va'),
(242,'VE','Venezuela','Bolivarian Republic of Venezuela','VEN','862','yes','58','.ve'),
(243,'VN','Vietnam','Socialist Republic of Vietnam','VNM','704','yes','84','.vn'),
(244,'VG','Virgin Islands, British','British Virgin Islands','VGB','092','no','1+284','.vg'),
(245,'VI','Virgin Islands, US','Virgin Islands of the United States','VIR','850','no','1+340','.vi'),
(246,'WF','Wallis and Futuna','Wallis and Futuna','WLF','876','no','681','.wf'),
(247,'EH','Western Sahara','Western Sahara','ESH','732','no','212','.eh'),
(248,'YE','Yemen','Republic of Yemen','YEM','887','yes','967','.ye'),
(249,'ZM','Zambia','Republic of Zambia','ZMB','894','yes','260','.zm'),
(250,'ZW','Zimbabwe','Republic of Zimbabwe','ZWE','716','yes','263','.zw');
/*!40000 ALTER TABLE `techdotbit_tblcountries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblcreditnote_refunds`
--

DROP TABLE IF EXISTS `techdotbit_tblcreditnote_refunds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblcreditnote_refunds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `credit_note_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `refunded_on` date NOT NULL,
  `payment_mode` varchar(40) NOT NULL,
  `note` mediumtext DEFAULT NULL,
  `amount` decimal(15,2) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblcreditnote_refunds`
--

LOCK TABLES `techdotbit_tblcreditnote_refunds` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblcreditnote_refunds` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblcreditnote_refunds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblcreditnotes`
--

DROP TABLE IF EXISTS `techdotbit_tblcreditnotes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblcreditnotes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clientid` int(11) NOT NULL,
  `deleted_customer_name` varchar(100) DEFAULT NULL,
  `number` int(11) NOT NULL,
  `prefix` varchar(50) DEFAULT NULL,
  `number_format` int(11) NOT NULL DEFAULT 1,
  `datecreated` datetime NOT NULL,
  `date` date NOT NULL,
  `adminnote` mediumtext DEFAULT NULL,
  `terms` mediumtext DEFAULT NULL,
  `clientnote` mediumtext DEFAULT NULL,
  `currency` int(11) NOT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `total_tax` decimal(15,2) NOT NULL DEFAULT 0.00,
  `total` decimal(15,2) NOT NULL,
  `adjustment` decimal(15,2) DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `project_id` int(11) NOT NULL DEFAULT 0,
  `discount_percent` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `discount_type` varchar(30) NOT NULL,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT NULL,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT NULL,
  `include_shipping` tinyint(1) NOT NULL,
  `show_shipping_on_credit_note` tinyint(1) NOT NULL DEFAULT 1,
  `show_quantity_as` int(11) NOT NULL DEFAULT 1,
  `reference_no` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `currency` (`currency`),
  KEY `clientid` (`clientid`),
  KEY `project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblcreditnotes`
--

LOCK TABLES `techdotbit_tblcreditnotes` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblcreditnotes` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblcreditnotes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblcredits`
--

DROP TABLE IF EXISTS `techdotbit_tblcredits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblcredits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) NOT NULL,
  `credit_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `date_applied` datetime NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblcredits`
--

LOCK TABLES `techdotbit_tblcredits` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblcredits` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblcredits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblcurrencies`
--

DROP TABLE IF EXISTS `techdotbit_tblcurrencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblcurrencies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `decimal_separator` varchar(5) DEFAULT NULL,
  `thousand_separator` varchar(5) DEFAULT NULL,
  `placement` varchar(10) DEFAULT NULL,
  `isdefault` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblcurrencies`
--

LOCK TABLES `techdotbit_tblcurrencies` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblcurrencies` DISABLE KEYS */;
INSERT INTO `techdotbit_tblcurrencies` VALUES
(2,'â‚¬','EUR',',','.','before',0),
(3,'?','INR','.',',','before',1);
/*!40000 ALTER TABLE `techdotbit_tblcurrencies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblcustomer_admins`
--

DROP TABLE IF EXISTS `techdotbit_tblcustomer_admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblcustomer_admins` (
  `staff_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `date_assigned` mediumtext NOT NULL,
  KEY `customer_id` (`customer_id`),
  KEY `techdotbit_staff_id` (`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblcustomer_admins`
--

LOCK TABLES `techdotbit_tblcustomer_admins` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblcustomer_admins` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblcustomer_admins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblcustomer_groups`
--

DROP TABLE IF EXISTS `techdotbit_tblcustomer_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblcustomer_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupid` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `groupid` (`groupid`),
  KEY `customer_id` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblcustomer_groups`
--

LOCK TABLES `techdotbit_tblcustomer_groups` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblcustomer_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblcustomer_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblcustomers_groups`
--

DROP TABLE IF EXISTS `techdotbit_tblcustomers_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblcustomers_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblcustomers_groups`
--

LOCK TABLES `techdotbit_tblcustomers_groups` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblcustomers_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblcustomers_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblcustomfields`
--

DROP TABLE IF EXISTS `techdotbit_tblcustomfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblcustomfields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldto` varchar(30) DEFAULT NULL,
  `name` varchar(150) NOT NULL,
  `slug` varchar(150) NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT 0,
  `type` varchar(20) NOT NULL,
  `options` longtext DEFAULT NULL,
  `display_inline` tinyint(1) NOT NULL DEFAULT 0,
  `field_order` int(11) DEFAULT 0,
  `active` int(11) NOT NULL DEFAULT 1,
  `show_on_pdf` int(11) NOT NULL DEFAULT 0,
  `show_on_ticket_form` tinyint(1) NOT NULL DEFAULT 0,
  `only_admin` tinyint(1) NOT NULL DEFAULT 0,
  `show_on_table` tinyint(1) NOT NULL DEFAULT 0,
  `show_on_client_portal` int(11) NOT NULL DEFAULT 0,
  `disalow_client_to_edit` int(11) NOT NULL DEFAULT 0,
  `bs_column` int(11) NOT NULL DEFAULT 12,
  `default_value` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblcustomfields`
--

LOCK TABLES `techdotbit_tblcustomfields` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblcustomfields` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblcustomfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblcustomfieldsvalues`
--

DROP TABLE IF EXISTS `techdotbit_tblcustomfieldsvalues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblcustomfieldsvalues` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `relid` int(11) NOT NULL,
  `fieldid` int(11) NOT NULL,
  `fieldto` varchar(15) NOT NULL,
  `value` mediumtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `relid` (`relid`),
  KEY `fieldto` (`fieldto`),
  KEY `fieldid` (`fieldid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblcustomfieldsvalues`
--

LOCK TABLES `techdotbit_tblcustomfieldsvalues` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblcustomfieldsvalues` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblcustomfieldsvalues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tbldepartments`
--

DROP TABLE IF EXISTS `techdotbit_tbldepartments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tbldepartments` (
  `departmentid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `imap_username` varchar(191) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `email_from_header` tinyint(1) NOT NULL DEFAULT 0,
  `host` varchar(150) DEFAULT NULL,
  `password` longtext DEFAULT NULL,
  `encryption` varchar(3) DEFAULT NULL,
  `folder` varchar(191) NOT NULL DEFAULT 'INBOX',
  `delete_after_import` int(11) NOT NULL DEFAULT 0,
  `calendar_id` longtext DEFAULT NULL,
  `hidefromclient` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`departmentid`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tbldepartments`
--

LOCK TABLES `techdotbit_tbldepartments` WRITE;
/*!40000 ALTER TABLE `techdotbit_tbldepartments` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tbldepartments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tbldismissed_announcements`
--

DROP TABLE IF EXISTS `techdotbit_tbldismissed_announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tbldismissed_announcements` (
  `dismissedannouncementid` int(11) NOT NULL AUTO_INCREMENT,
  `announcementid` int(11) NOT NULL,
  `staff` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  PRIMARY KEY (`dismissedannouncementid`),
  KEY `announcementid` (`announcementid`),
  KEY `techdotbit_staff` (`staff`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tbldismissed_announcements`
--

LOCK TABLES `techdotbit_tbldismissed_announcements` WRITE;
/*!40000 ALTER TABLE `techdotbit_tbldismissed_announcements` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tbldismissed_announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblemaillists`
--

DROP TABLE IF EXISTS `techdotbit_tblemaillists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblemaillists` (
  `listid` int(11) NOT NULL AUTO_INCREMENT,
  `name` mediumtext NOT NULL,
  `creator` varchar(100) NOT NULL,
  `datecreated` datetime NOT NULL,
  PRIMARY KEY (`listid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblemaillists`
--

LOCK TABLES `techdotbit_tblemaillists` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblemaillists` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblemaillists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblemailtemplates`
--

DROP TABLE IF EXISTS `techdotbit_tblemailtemplates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblemailtemplates` (
  `emailtemplateid` int(11) NOT NULL AUTO_INCREMENT,
  `type` longtext NOT NULL,
  `slug` varchar(100) NOT NULL,
  `language` varchar(40) DEFAULT NULL,
  `name` longtext NOT NULL,
  `subject` longtext NOT NULL,
  `message` longtext NOT NULL,
  `fromname` longtext NOT NULL,
  `fromemail` varchar(100) DEFAULT NULL,
  `plaintext` int(11) NOT NULL DEFAULT 0,
  `active` tinyint(4) NOT NULL DEFAULT 0,
  `order` int(11) NOT NULL,
  PRIMARY KEY (`emailtemplateid`)
) ENGINE=InnoDB AUTO_INCREMENT=91 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblemailtemplates`
--

LOCK TABLES `techdotbit_tblemailtemplates` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblemailtemplates` DISABLE KEYS */;
INSERT INTO `techdotbit_tblemailtemplates` VALUES
(1,'client','new-client-created','english','New Contact Added/Registered (Welcome Email)','Welcome aboard','Dear {contact_firstname} {contact_lastname}<br /><br />Thank you for registering on the <strong>{companyname}</strong> CRM System.<br /><br />We just wanted to say welcome.<br /><br />Please contact us if you need any help.<br /><br />Click here to view your profile: <a href=\"{crm_url}\">{crm_url}</a><br /><br />Kind Regards, <br />{email_signature}<br /><br />(This is an automated email, so please don\'t reply to this email address)','{companyname} | CRM','',0,1,0),
(2,'invoice','invoice-send-to-client','english','Send Invoice to Customer','Invoice with number {invoice_number} created','<span style=\"font-size: 12pt;\">Dear {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">We have prepared the following invoice for you: <strong># {invoice_number}</strong></span><br /><br /><span style=\"font-size: 12pt;\"><strong>Invoice status</strong>: {invoice_status}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the invoice on the following link: <a href=\"{invoice_link}\">{invoice_number}</a></span><br /><br /><span style=\"font-size: 12pt;\">Please contact us for more information.</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),
(3,'ticket','new-ticket-opened-admin','english','New Ticket Opened (Opened by Staff, Sent to Customer)','New Support Ticket Opened','<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">New support ticket has been opened.</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject:</strong> {ticket_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Department:</strong> {ticket_department}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority:</strong> {ticket_priority}<br /></span><br /><span style=\"font-size: 12pt;\"><strong>Ticket message:</strong></span><br /><span style=\"font-size: 12pt;\">{ticket_message}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_public_url}\">#{ticket_id}</a><br /><br />Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),
(4,'ticket','ticket-reply','english','Ticket Reply (Sent to Customer)','New Ticket Reply','<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">You have a new ticket reply to ticket <a href=\"{ticket_public_url}\">#{ticket_id}</a></span><br /><br /><span style=\"font-size: 12pt;\"><strong>Ticket Subject:</strong> {ticket_subject}<br /></span><br /><span style=\"font-size: 12pt;\"><strong>Ticket message:</strong></span><br /><span style=\"font-size: 12pt;\">{ticket_message}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_public_url}\">#{ticket_id}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),
(5,'ticket','ticket-autoresponse','english','New Ticket Opened - Autoresponse','New Support Ticket Opened','<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">Thank you for contacting our support team. A support ticket has now been opened for your request. You will be notified when a response is made by email.</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject:</strong> {ticket_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Department</strong>: {ticket_department}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority:</strong> {ticket_priority}</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Ticket message:</strong></span><br /><span style=\"font-size: 12pt;\">{ticket_message}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_public_url}\">#{ticket_id}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),
(6,'invoice','invoice-payment-recorded','english','Invoice Payment Recorded (Sent to Customer)','Invoice Payment Recorded','<span style=\"font-size: 12pt;\">Hello {contact_firstname}&nbsp;{contact_lastname}<br /><br /></span>Thank you for the payment. Find the payment details below:<br /><br />-------------------------------------------------<br /><br />Amount:&nbsp;<strong>{payment_total}<br /></strong>Date:&nbsp;<strong>{payment_date}</strong><br />Invoice number:&nbsp;<span style=\"font-size: 12pt;\"><strong># {invoice_number}<br /><br /></strong></span>-------------------------------------------------<br /><br />You can always view the invoice for this payment at the following link:&nbsp;<a href=\"{invoice_link}\"><span style=\"font-size: 12pt;\">{invoice_number}</span></a><br /><br />We are looking forward working with you.<br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),
(7,'invoice','invoice-overdue-notice','english','Invoice Overdue Notice','Invoice Overdue Notice - {invoice_number}','<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">This is an overdue notice for invoice <strong># {invoice_number}</strong></span><br /><br /><span style=\"font-size: 12pt;\">This invoice was due: {invoice_duedate}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the invoice on the following link: <a href=\"{invoice_link}\">{invoice_number}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),
(8,'invoice','invoice-already-send','english','Invoice Already Sent to Customer','Invoice # {invoice_number} ','<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">At your request, here is the invoice with number <strong># {invoice_number}</strong></span><br /><br /><span style=\"font-size: 12pt;\">You can view the invoice on the following link: <a href=\"{invoice_link}\">{invoice_number}</a></span><br /><br /><span style=\"font-size: 12pt;\">Please contact us for more information.</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),
(9,'ticket','new-ticket-created-staff','english','New Ticket Created (Opened by Customer, Sent to Staff Members)','New Ticket Created','<p><span style=\"font-size: 12pt;\">A new support ticket has been opened.</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject</strong>: {ticket_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Department</strong>: {ticket_department}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority</strong>: {ticket_priority}<br /></span><br /><span style=\"font-size: 12pt;\"><strong>Ticket message:</strong></span><br /><span style=\"font-size: 12pt;\">{ticket_message}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_url}\">#{ticket_id}</a></span><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span></p>','{companyname} | CRM','',0,1,0),
(10,'estimate','estimate-send-to-client','english','Send Estimate to Customer','Estimate # {estimate_number} created','<span style=\"font-size: 12pt;\">Dear {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">Please find the attached estimate <strong># {estimate_number}</strong></span><br /><br /><span style=\"font-size: 12pt;\"><strong>Estimate status:</strong> {estimate_status}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the estimate on the following link: <a href=\"{estimate_link}\">{estimate_number}</a></span><br /><br /><span style=\"font-size: 12pt;\">We look forward to your communication.</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}<br /></span>','{companyname} | CRM','',0,1,0),
(11,'ticket','ticket-reply-to-admin','english','Ticket Reply (Sent to Staff)','New Support Ticket Reply','<span style=\"font-size: 12pt;\">A new support ticket reply from {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject</strong>: {ticket_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Department</strong>: {ticket_department}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority</strong>: {ticket_priority}</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Ticket message:</strong></span><br /><span style=\"font-size: 12pt;\">{ticket_message}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_url}\">#{ticket_id}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),
(12,'estimate','estimate-already-send','english','Estimate Already Sent to Customer','Estimate # {estimate_number} ','<span style=\"font-size: 12pt;\">Dear {contact_firstname} {contact_lastname}</span><br /> <br /><span style=\"font-size: 12pt;\">Thank you for your estimate request.</span><br /> <br /><span style=\"font-size: 12pt;\">You can view the estimate on the following link: <a href=\"{estimate_link}\">{estimate_number}</a></span><br /> <br /><span style=\"font-size: 12pt;\">Please contact us for more information.</span><br /> <br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),
(13,'contract','contract-expiration','english','Contract Expiration Reminder (Sent to Customer Contacts)','Contract Expiration Reminder','<span style=\"font-size: 12pt;\">Dear {client_company}</span><br /><br /><span style=\"font-size: 12pt;\">This is a reminder that the following contract will expire soon:</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject:</strong> {contract_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Description:</strong> {contract_description}</span><br /><span style=\"font-size: 12pt;\"><strong>Date Start:</strong> {contract_datestart}</span><br /><span style=\"font-size: 12pt;\"><strong>Date End:</strong> {contract_dateend}</span><br /><br /><span style=\"font-size: 12pt;\">Please contact us for more information.</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),
(14,'tasks','task-assigned','english','New Task Assigned (Sent to Staff)','New Task Assigned to You - {task_name}','<span style=\"font-size: 12pt;\">Dear {staff_firstname}</span><br /><br /><span style=\"font-size: 12pt;\">You have been assigned to a new task:</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Name:</strong> {task_name}<br /></span><strong>Start Date:</strong> {task_startdate}<br /><span style=\"font-size: 12pt;\"><strong>Due date:</strong> {task_duedate}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority:</strong> {task_priority}<br /><br /></span><span style=\"font-size: 12pt;\"><span>You can view the task on the following link</span>: <a href=\"{task_link}\">{task_name}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),
(15,'tasks','task-added-as-follower','english','Staff Member Added as Follower on Task (Sent to Staff)','You are added as follower on task - {task_name}','<span style=\"font-size: 12pt;\">Hi {staff_firstname}<br /></span><br /><span style=\"font-size: 12pt;\">You have been added as follower on the following task:</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Name:</strong> {task_name}</span><br /><span style=\"font-size: 12pt;\"><strong>Start date:</strong> {task_startdate}</span><br /><br /><span>You can view the task on the following link</span><span>: </span><a href=\"{task_link}\">{task_name}</a><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),
(16,'tasks','task-commented','english','New Comment on Task (Sent to Staff)','New Comment on Task - {task_name}','Dear {staff_firstname}<br /><br />A comment has been made on the following task:<br /><br /><strong>Name:</strong> {task_name}<br /><strong>Comment:</strong> {task_comment}<br /><br />You can view the task on the following link: <a href=\"{task_link}\">{task_name}</a><br /><br />Kind Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),
(17,'tasks','task-added-attachment','english','New Attachment(s) on Task (Sent to Staff)','New Attachment on Task - {task_name}','Hi {staff_firstname}<br /><br /><strong>{task_user_take_action}</strong> added an attachment on the following task:<br /><br /><strong>Name:</strong> {task_name}<br /><br />You can view the task on the following link: <a href=\"{task_link}\">{task_name}</a><br /><br />Kind Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),
(18,'estimate','estimate-declined-to-staff','english','Estimate Declined (Sent to Staff)','Customer Declined Estimate','<span style=\"font-size: 12pt;\">Hi</span><br /> <br /><span style=\"font-size: 12pt;\">Customer ({client_company}) declined estimate with number <strong># {estimate_number}</strong></span><br /> <br /><span style=\"font-size: 12pt;\">You can view the estimate on the following link: <a href=\"{estimate_link}\">{estimate_number}</a></span><br /> <br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),
(19,'estimate','estimate-accepted-to-staff','english','Estimate Accepted (Sent to Staff)','Customer Accepted Estimate','<span style=\"font-size: 12pt;\">Hi</span><br /> <br /><span style=\"font-size: 12pt;\">Customer ({client_company}) accepted estimate with number <strong># {estimate_number}</strong></span><br /> <br /><span style=\"font-size: 12pt;\">You can view the estimate on the following link: <a href=\"{estimate_link}\">{estimate_number}</a></span><br /> <br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),
(20,'proposals','proposal-client-accepted','english','Customer Action - Accepted (Sent to Staff)','Customer Accepted Proposal','<div>Hi<br /> <br />Client <strong>{proposal_proposal_to}</strong> accepted the following proposal:<br /> <br /><strong>Number:</strong> {proposal_number}<br /><strong>Subject</strong>: {proposal_subject}<br /><strong>Total</strong>: {proposal_total}<br /> <br />View the proposal on the following link: <a href=\"{proposal_link}\">{proposal_number}</a><br /> <br />Kind Regards,<br />{email_signature}</div>\r\n<div>&nbsp;</div>\r\n<div>&nbsp;</div>\r\n<div>&nbsp;</div>','{companyname} | CRM','',0,1,0),
(21,'proposals','proposal-send-to-customer','english','Send Proposal to Customer','Proposal With Number {proposal_number} Created','Dear {proposal_proposal_to}<br /><br />Please find our attached proposal.<br /><br />This proposal is valid until: {proposal_open_till}<br />You can view the proposal on the following link: <a href=\"{proposal_link}\">{proposal_number}</a><br /><br />Please don\'t hesitate to comment online if you have any questions.<br /><br />We look forward to your communication.<br /><br />Kind Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),
(22,'proposals','proposal-client-declined','english','Customer Action - Declined (Sent to Staff)','Client Declined Proposal','Hi<br /> <br />Customer <strong>{proposal_proposal_to}</strong> declined the proposal <strong>{proposal_subject}</strong><br /> <br />View the proposal on the following link <a href=\"{proposal_link}\">{proposal_number}</a>&nbsp;or from the admin area.<br /> <br />Kind Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),
(23,'proposals','proposal-client-thank-you','english','Thank You Email (Sent to Customer After Accept)','Thank for you accepting proposal','Dear {proposal_proposal_to}<br /> <br />Thank for for accepting the proposal.<br /> <br />We look forward to doing business with you.<br /> <br />We will contact you as soon as possible<br /> <br />Kind Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),
(24,'proposals','proposal-comment-to-client','english','New Comment Â (Sent to Customer/Lead)','New Proposal Comment','Dear {proposal_proposal_to}<br /> <br />A new comment has been made on the following proposal: <strong>{proposal_number}</strong><br /> <br />You can view and reply to the comment on the following link: <a href=\"{proposal_link}\">{proposal_number}</a><br /> <br />Kind Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),
(25,'proposals','proposal-comment-to-admin','english','New Comment (Sent to Staff) ','New Proposal Comment','Hi<br /> <br />A new comment has been made to the proposal <strong>{proposal_subject}</strong><br /> <br />You can view and reply to the comment on the following link: <a href=\"{proposal_link}\">{proposal_number}</a>&nbsp;or from the admin area.<br /> <br />{email_signature}','{companyname} | CRM','',0,1,0),
(26,'estimate','estimate-thank-you-to-customer','english','Thank You Email (Sent to Customer After Accept)','Thank for you accepting estimate','<span style=\"font-size: 12pt;\">Dear {contact_firstname} {contact_lastname}</span><br /> <br /><span style=\"font-size: 12pt;\">Thank for for accepting the estimate.</span><br /> <br /><span style=\"font-size: 12pt;\">We look forward to doing business with you.</span><br /> <br /><span style=\"font-size: 12pt;\">We will contact you as soon as possible.</span><br /> <br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),
(27,'tasks','task-deadline-notification','english','Task Deadline Reminder - Sent to Assigned Members','Task Deadline Reminder','Hi {staff_firstname}&nbsp;{staff_lastname}<br /><br />This is an automated email from {companyname}.<br /><br />The task <strong>{task_name}</strong> deadline is on <strong>{task_duedate}</strong>. <br />This task is still not finished.<br /><br />You can view the task on the following link: <a href=\"{task_link}\">{task_name}</a><br /><br />Kind Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),
(28,'contract','send-contract','english','Send Contract to Customer','Contract - {contract_subject}','<p><span style=\"font-size: 12pt;\">Hi&nbsp;{contact_firstname}&nbsp;{contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">Please find the <a href=\"{contract_link}\">{contract_subject}</a> attached.<br /><br />Description: {contract_description}<br /><br /></span><span style=\"font-size: 12pt;\">Looking forward to hear from you.</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span></p>','{companyname} | CRM','',0,1,0),
(29,'invoice','invoice-payment-recorded-to-staff','english','Invoice Payment Recorded (Sent to Staff)','New Invoice Payment','<span style=\"font-size: 12pt;\">Hi</span><br /><br /><span style=\"font-size: 12pt;\">Customer recorded payment for invoice <strong># {invoice_number}</strong></span><br /> <br /><span style=\"font-size: 12pt;\">You can view the invoice on the following link: <a href=\"{invoice_link}\">{invoice_number}</a></span><br /> <br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),
(30,'ticket','auto-close-ticket','english','Auto Close Ticket','Ticket Auto Closed','<p><span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">Ticket {ticket_subject} has been auto close due to inactivity.</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Ticket #</strong>: <a href=\"{ticket_public_url}\">{ticket_id}</a></span><br /><span style=\"font-size: 12pt;\"><strong>Department</strong>: {ticket_department}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority:</strong> {ticket_priority}</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span></p>','{companyname} | CRM','',0,1,0),
(31,'project','new-project-discussion-created-to-staff','english','New Project Discussion (Sent to Project Members)','New Project Discussion Created - {project_name}','<p>Hi {staff_firstname}<br /><br />New project discussion created from <strong>{discussion_creator}</strong><br /><br /><strong>Subject:</strong> {discussion_subject}<br /><strong>Description:</strong> {discussion_description}<br /><br />You can view the discussion on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a><br /><br />Kind Regards,<br />{email_signature}</p>','{companyname} | CRM','',0,1,0),
(32,'project','new-project-discussion-created-to-customer','english','New Project Discussion (Sent to Customer Contacts)','New Project Discussion Created - {project_name}','<p>Hello {contact_firstname} {contact_lastname}<br /><br />New project discussion created from <strong>{discussion_creator}</strong><br /><br /><strong>Subject:</strong> {discussion_subject}<br /><strong>Description:</strong> {discussion_description}<br /><br />You can view the discussion on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a><br /><br />Kind Regards,<br />{email_signature}</p>','{companyname} | CRM','',0,1,0),
(33,'project','new-project-file-uploaded-to-customer','english','New Project File(s) Uploaded (Sent to Customer Contacts)','New Project File(s) Uploaded - {project_name}','<p>Hello {contact_firstname} {contact_lastname}<br /><br />New project file is uploaded on <strong>{project_name}</strong> from <strong>{file_creator}</strong><br /><br />You can view the project on the following link: <a href=\"{project_link}\">{project_name}</a><br /><br />To view the file in our CRM you can click on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a><br /><br />Kind Regards,<br />{email_signature}</p>','{companyname} | CRM','',0,1,0),
(34,'project','new-project-file-uploaded-to-staff','english','New Project File(s) Uploaded (Sent to Project Members)','New Project File(s) Uploaded - {project_name}','<p>Hello&nbsp;{staff_firstname}</p>\r\n<p>New project&nbsp;file is uploaded on&nbsp;<strong>{project_name}</strong> from&nbsp;<strong>{file_creator}</strong></p>\r\n<p>You can view the project on the following link: <a href=\"{project_link}\">{project_name}<br /></a><br />To view&nbsp;the file you can click on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a></p>\r\n<p>Kind Regards,<br />{email_signature}</p>','{companyname} | CRM','',0,1,0),
(35,'project','new-project-discussion-comment-to-customer','english','New Discussion Comment  (Sent to Customer Contacts)','New Discussion Comment','<p><span style=\"font-size: 12pt;\">Hello {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">New discussion comment has been made on <strong>{discussion_subject}</strong> from <strong>{comment_creator}</strong></span><br /><br /><span style=\"font-size: 12pt;\"><strong>Discussion subject:</strong> {discussion_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Comment</strong>: {discussion_comment}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the discussion on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span></p>','{companyname} | CRM','',0,1,0),
(36,'project','new-project-discussion-comment-to-staff','english','New Discussion Comment (Sent to Project Members)','New Discussion Comment','<p>Hi {staff_firstname}<br /><br />New discussion comment has been made on <strong>{discussion_subject}</strong> from <strong>{comment_creator}</strong><br /><br /><strong>Discussion subject:</strong> {discussion_subject}<br /><strong>Comment:</strong> {discussion_comment}<br /><br />You can view the discussion on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a><br /><br />Kind Regards,<br />{email_signature}</p>','{companyname} | CRM','',0,1,0),
(37,'project','staff-added-as-project-member','english','Staff Added as Project Member','New project assigned to you','<p>Hi {staff_firstname}<br /><br />New project has been assigned to you.<br /><br />You can view the project on the following link <a href=\"{project_link}\">{project_name}</a><br /><br />{email_signature}</p>','{companyname} | CRM','',0,1,0),
(38,'estimate','estimate-expiry-reminder','english','Estimate Expiration Reminder','Estimate Expiration Reminder','<p><span style=\"font-size: 12pt;\">Hello {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">The estimate with <strong># {estimate_number}</strong> will expire on <strong>{estimate_expirydate}</strong></span><br /><br /><span style=\"font-size: 12pt;\">You can view the estimate on the following link: <a href=\"{estimate_link}\">{estimate_number}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span></p>','{companyname} | CRM','',0,1,0),
(39,'proposals','proposal-expiry-reminder','english','Proposal Expiration Reminder','Proposal Expiration Reminder','<p>Hello {proposal_proposal_to}<br /><br />The proposal {proposal_number}&nbsp;will expire on <strong>{proposal_open_till}</strong><br /><br />You can view the proposal on the following link: <a href=\"{proposal_link}\">{proposal_number}</a><br /><br />Kind Regards,<br />{email_signature}</p>','{companyname} | CRM','',0,1,0),
(40,'staff','new-staff-created','english','New Staff Created (Welcome Email)','You are added as staff member','Hi {staff_firstname}<br /><br />You are added as member on our CRM.<br /><br />Please use the following logic credentials:<br /><br /><strong>Email:</strong> {staff_email}<br /><strong>Password:</strong> {password}<br /><br />Click <a href=\"{admin_url}\">here </a>to login in the dashboard.<br /><br />Best Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),
(41,'client','contact-forgot-password','english','Forgot Password','Create New Password','<h2>Create a new password</h2>\r\nForgot your password?<br /> To create a new password, just follow this link:<br /> <br /><a href=\"{reset_password_url}\">Reset Password</a><br /> <br /> You received this email, because it was requested by a {companyname}&nbsp;user. This is part of the procedure to create a new password on the system. If you DID NOT request a new password then please ignore this email and your password will remain the same. <br /><br /> {email_signature}','{companyname} | CRM','',0,1,0),
(42,'client','contact-password-reseted','english','Password Reset - Confirmation','Your password has been changed','<strong><span style=\"font-size: 14pt;\">You have changed your password.</span><br /></strong><br /> Please, keep it in your records so you don\'t forget it.<br /> <br /> Your email address for login is: {contact_email}<br /><br />If this wasnt you, please contact us.<br /><br />{email_signature}','{companyname} | CRM','',0,1,0),
(43,'client','contact-set-password','english','Set New Password','Set new password on {companyname} ','<h2><span style=\"font-size: 14pt;\">Setup your new password on {companyname}</span></h2>\r\nPlease use the following link to set up your new password:<br /><br /><a href=\"{set_password_url}\">Set new password</a><br /><br />Keep it in your records so you don\'t forget it.<br /><br />Please set your new password in <strong>48 hours</strong>. After that, you won\'t be able to set your password because this link will expire.<br /><br />You can login at: <a href=\"{crm_url}\">{crm_url}</a><br />Your email address for login: {contact_email}<br /><br />{email_signature}','{companyname} | CRM','',0,1,0),
(44,'staff','staff-forgot-password','english','Forgot Password','Create New Password','<h2><span style=\"font-size: 14pt;\">Create a new password</span></h2>\r\nForgot your password?<br /> To create a new password, just follow this link:<br /> <br /><a href=\"{reset_password_url}\">Reset Password</a><br /> <br /> You received this email, because it was requested by a <strong>{companyname}</strong>&nbsp;user. This is part of the procedure to create a new password on the system. If you DID NOT request a new password then please ignore this email and your password will remain the same. <br /><br /> {email_signature}','{companyname} | CRM','',0,1,0),
(45,'staff','staff-password-reseted','english','Password Reset - Confirmation','Your password has been changed','<span style=\"font-size: 14pt;\"><strong>You have changed your password.<br /></strong></span><br /> Please, keep it in your records so you don\'t forget it.<br /> <br /> Your email address for login is: {staff_email}<br /><br /> If this wasnt you, please contact us.<br /><br />{email_signature}','{companyname} | CRM','',0,1,0),
(46,'project','assigned-to-project','english','New Project Created (Sent to Customer Contacts)','New Project Created','<p>Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}</p>\r\n<p>New project is assigned to your company.<br /><br /><strong>Project Name:</strong>&nbsp;{project_name}<br /><strong>Project Start Date:</strong>&nbsp;{project_start_date}</p>\r\n<p>You can view the project on the following link:&nbsp;<a href=\"{project_link}\">{project_name}</a></p>\r\n<p>We are looking forward hearing from you.<br /><br />Kind Regards,<br />{email_signature}</p>','{companyname} | CRM','',0,1,0),
(47,'tasks','task-added-attachment-to-contacts','english','New Attachment(s) on Task (Sent to Customer Contacts)','New Attachment on Task - {task_name}','<span>Hi {contact_firstname} {contact_lastname}</span><br /><br /><strong>{task_user_take_action}</strong><span> added an attachment on the following task:</span><br /><br /><strong>Name:</strong><span> {task_name}</span><br /><br /><span>You can view the task on the following link: </span><a href=\"{task_link}\">{task_name}</a><br /><br /><span>Kind Regards,</span><br /><span>{email_signature}</span>','{companyname} | CRM','',0,1,0),
(48,'tasks','task-commented-to-contacts','english','New Comment on Task (Sent to Customer Contacts)','New Comment on Task - {task_name}','<span>Dear {contact_firstname} {contact_lastname}</span><br /><br /><span>A comment has been made on the following task:</span><br /><br /><strong>Name:</strong><span> {task_name}</span><br /><strong>Comment:</strong><span> {task_comment}</span><br /><br /><span>You can view the task on the following link: </span><a href=\"{task_link}\">{task_name}</a><br /><br /><span>Kind Regards,</span><br /><span>{email_signature}</span>','{companyname} | CRM','',0,1,0),
(49,'leads','new-lead-assigned','english','New Lead Assigned to Staff Member','New lead assigned to you','<p>Hello {lead_assigned}<br /><br />New lead is assigned to you.<br /><br /><strong>Lead Name:</strong>&nbsp;{lead_name}<br /><strong>Lead Email:</strong>&nbsp;{lead_email}<br /><br />You can view the lead on the following link: <a href=\"{lead_link}\">{lead_name}</a><br /><br />Kind Regards,<br />{email_signature}</p>','{companyname} | CRM','',0,1,0),
(50,'client','client-statement','english','Statement - Account Summary','Account Statement from {statement_from} to {statement_to}','Dear {contact_firstname} {contact_lastname}, <br /><br />Its been a great experience working with you.<br /><br />Attached with this email is a list of all transactions for the period between {statement_from} to {statement_to}<br /><br />For your information your account balance due is total:&nbsp;{statement_balance_due}<br /><br />Please contact us if you need more information.<br /> <br />Kind Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),
(51,'ticket','ticket-assigned-to-admin','english','New Ticket Assigned (Sent to Staff)','New support ticket has been assigned to you','<p><span style=\"font-size: 12pt;\">Hi</span></p>\r\n<p><span style=\"font-size: 12pt;\">A new support ticket&nbsp;has been assigned to you.</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject</strong>: {ticket_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Department</strong>: {ticket_department}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority</strong>: {ticket_priority}</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Ticket message:</strong></span><br /><span style=\"font-size: 12pt;\">{ticket_message}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_url}\">#{ticket_id}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span></p>','{companyname} | CRM','',0,1,0),
(52,'client','new-client-registered-to-admin','english','New Customer Registration (Sent to admins)','New Customer Registration','Hello.<br /><br />New customer registration on your customer portal:<br /><br /><strong>Firstname:</strong>&nbsp;{contact_firstname}<br /><strong>Lastname:</strong>&nbsp;{contact_lastname}<br /><strong>Company:</strong>&nbsp;{client_company}<br /><strong>Email:</strong>&nbsp;{contact_email}<br /><br />Best Regards','{companyname} | CRM','',0,1,0),
(53,'leads','new-web-to-lead-form-submitted','english','Web to lead form submitted - Sent to lead','{lead_name} - We Received Your Request','Hello {lead_name}.<br /><br /><strong>Your request has been received.</strong><br /><br />This email is to let you know that we received your request and we will get back to you as soon as possible with more information.<br /><br />Best Regards,<br />{email_signature}','{companyname} | CRM','',0,0,0),
(54,'staff','two-factor-authentication','english','Two Factor Authentication','Confirm Your Login','<p>Hi {staff_firstname}</p>\r\n<p style=\"text-align: left;\">You received this email because you have enabled two factor authentication in your account.<br />Use the following code to confirm your login:</p>\r\n<p style=\"text-align: left;\"><span style=\"font-size: 18pt;\"><strong>{two_factor_auth_code}<br /><br /></strong><span style=\"font-size: 12pt;\">{email_signature}</span><strong><br /><br /><br /><br /></strong></span></p>','{companyname} | CRM','',0,1,0),
(55,'project','project-finished-to-customer','english','Project Marked as Finished (Sent to Customer Contacts)','Project Marked as Finished','<p>Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}</p>\r\n<p>You are receiving this email because project&nbsp;<strong>{project_name}</strong> has been marked as finished. This project is assigned under your company and we just wanted to keep you up to date.<br /><br />You can view the project on the following link:&nbsp;<a href=\"{project_link}\">{project_name}</a></p>\r\n<p>If you have any questions don\'t hesitate to contact us.<br /><br />Kind Regards,<br />{email_signature}</p>','{companyname} | CRM','',0,1,0),
(56,'credit_note','credit-note-send-to-client','english','Send Credit Note To Email','Credit Note With Number #{credit_note_number} Created','Dear&nbsp;{contact_firstname}&nbsp;{contact_lastname}<br /><br />We have attached the credit note with number <strong>#{credit_note_number} </strong>for your reference.<br /><br /><strong>Date:</strong>&nbsp;{credit_note_date}<br /><strong>Total Amount:</strong>&nbsp;{credit_note_total}<br /><br /><span style=\"font-size: 12pt;\">Please contact us for more information.</span><br /> <br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),
(57,'tasks','task-status-change-to-staff','english','Task Status Changed (Sent to Staff)','Task Status Changed','<span style=\"font-size: 12pt;\">Hi {staff_firstname}</span><br /><br /><span style=\"font-size: 12pt;\"><strong>{task_user_take_action}</strong> marked task as <strong>{task_status}</strong></span><br /><br /><span style=\"font-size: 12pt;\"><strong>Name:</strong> {task_name}</span><br /><span style=\"font-size: 12pt;\"><strong>Due date:</strong> {task_duedate}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the task on the following link: <a href=\"{task_link}\">{task_name}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),
(58,'tasks','task-status-change-to-contacts','english','Task Status Changed (Sent to Customer Contacts)','Task Status Changed','<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\"><strong>{task_user_take_action}</strong> marked task as <strong>{task_status}</strong></span><br /><br /><span style=\"font-size: 12pt;\"><strong>Name:</strong> {task_name}</span><br /><span style=\"font-size: 12pt;\"><strong>Due date:</strong> {task_duedate}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the task on the following link: <a href=\"{task_link}\">{task_name}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),
(59,'staff','reminder-email-staff','english','Staff Reminder Email','You Have a New Reminder!','<p>Hello&nbsp;{staff_firstname}<br /><br /><strong>You have a new reminder&nbsp;linked to&nbsp;{staff_reminder_relation_name}!<br /><br />Reminder description:</strong><br />{staff_reminder_description}<br /><br />Click <a href=\"{staff_reminder_relation_link}\">here</a> to view&nbsp;<a href=\"{staff_reminder_relation_link}\">{staff_reminder_relation_name}</a><br /><br />Best Regards<br /><br /></p>','{companyname} | CRM','',0,1,0),
(60,'contract','contract-comment-to-client','english','New Comment Â (Sent to Customer Contacts)','New Contract Comment','Dear {contact_firstname} {contact_lastname}<br /> <br />A new comment has been made on the following contract: <strong>{contract_subject}</strong><br /> <br />You can view and reply to the comment on the following link: <a href=\"{contract_link}\">{contract_subject}</a><br /> <br />Kind Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),
(61,'contract','contract-comment-to-admin','english','New Comment (Sent to Staff) ','New Contract Comment','Hi {staff_firstname}<br /><br />A new comment has been made to the contract&nbsp;<strong>{contract_subject}</strong><br /><br />You can view and reply to the comment on the following link: <a href=\"{contract_link}\">{contract_subject}</a>&nbsp;or from the admin area.<br /><br />{email_signature}','{companyname} | CRM','',0,1,0),
(62,'subscriptions','send-subscription','english','Send Subscription to Customer','Subscription Created','Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}<br /><br />We have prepared the subscription&nbsp;<strong>{subscription_name}</strong> for your company.<br /><br />Click <a href=\"{subscription_link}\">here</a> to review the subscription and subscribe.<br /><br />Best Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),
(63,'subscriptions','subscription-payment-failed','english','Subscription Payment Failed','Your most recent invoice payment failed','Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}<br /><br br=\"\" />Unfortunately, your most recent invoice payment for&nbsp;<strong>{subscription_name}</strong> was declined.<br /><br />This could be due to a change in your card number, your card expiring,<br />cancellation of your credit card, or the card issuer not recognizing the<br />payment and therefore taking action to prevent it.<br /><br />Please update your payment information as soon as possible by logging in here:<br /><a href=\"{crm_url}/login\">{crm_url}/login</a><br /><br />Best Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),
(64,'subscriptions','subscription-canceled','english','Subscription Canceled (Sent to customer primary contact)','Your subscription has been canceled','Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}<br /><br />Your subscription&nbsp;<strong>{subscription_name} </strong>has been canceled, if you have any questions don\'t hesitate to contact us.<br /><br />It was a pleasure doing business with you.<br /><br />Best Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),
(65,'subscriptions','subscription-payment-succeeded','english','Subscription Payment Succeeded (Sent to customer primary contact)','Subscription  Payment Receipt - {subscription_name}','Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}<br /><br />This email is to let you know that we received your payment for subscription&nbsp;<strong>{subscription_name}&nbsp;</strong>of&nbsp;<strong><span>{payment_total}<br /><br /></span></strong>The invoice associated with it is now with status&nbsp;<strong>{invoice_status}<br /></strong><br />Thank you for your confidence.<br /><br />Best Regards,<br />{email_signature}','{companyname} | CRM','',0,1,0),
(66,'contract','contract-expiration-to-staff','english','Contract Expiration Reminder (Sent to Staff)','Contract Expiration Reminder','Hi {staff_firstname}<br /><br /><span style=\"font-size: 12pt;\">This is a reminder that the following contract will expire soon:</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject:</strong> {contract_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Description:</strong> {contract_description}</span><br /><span style=\"font-size: 12pt;\"><strong>Date Start:</strong> {contract_datestart}</span><br /><span style=\"font-size: 12pt;\"><strong>Date End:</strong> {contract_dateend}</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),
(67,'gdpr','gdpr-removal-request','english','Removal Request From Contact (Sent to administrators)','Data Removal Request Received','Hello&nbsp;{staff_firstname}&nbsp;{staff_lastname}<br /><br />Data removal has been requested by&nbsp;{contact_firstname} {contact_lastname}<br /><br />You can review this request and take proper actions directly from the admin area.','{companyname} | CRM','',0,1,0),
(68,'gdpr','gdpr-removal-request-lead','english','Removal Request From Lead (Sent to administrators)','Data Removal Request Received','Hello&nbsp;{staff_firstname}&nbsp;{staff_lastname}<br /><br />Data removal has been requested by {lead_name}<br /><br />You can review this request and take proper actions directly from the admin area.<br /><br />To view the lead inside the admin area click here:&nbsp;<a href=\"{lead_link}\">{lead_link}</a>','{companyname} | CRM','',0,1,0),
(69,'client','client-registration-confirmed','english','Customer Registration Confirmed','Your registration is confirmed','<p>Dear {contact_firstname} {contact_lastname}<br /><br />We just wanted to let you know that your registration at&nbsp;{companyname} is successfully confirmed and your account is now active.<br /><br />You can login at&nbsp;<a href=\"{crm_url}\">{crm_url}</a> with the email and password you provided during registration.<br /><br />Please contact us if you need any help.<br /><br />Kind Regards, <br />{email_signature}</p>\r\n<p><br />(This is an automated email, so please don\'t reply to this email address)</p>','{companyname} | CRM','',0,1,0),
(70,'contract','contract-signed-to-staff','english','Contract Signed (Sent to Staff)','Customer Signed a Contract','Hi {staff_firstname}<br /><br />A contract with subject&nbsp;<strong>{contract_subject} </strong>has been successfully signed by the customer.<br /><br />You can view the contract at the following link: <a href=\"{contract_link}\">{contract_subject}</a>&nbsp;or from the admin area.<br /><br />{email_signature}','{companyname} | CRM','',0,1,0),
(71,'subscriptions','customer-subscribed-to-staff','english','Customer Subscribed to a Subscription (Sent to administrators and subscription creator)','Customer Subscribed to a Subscription','The customer <strong>{client_company}</strong> subscribed to a subscription with name&nbsp;<strong>{subscription_name}</strong><br /><br /><strong>ID</strong>:&nbsp;{subscription_id}<br /><strong>Subscription name</strong>:&nbsp;{subscription_name}<br /><strong>Subscription description</strong>:&nbsp;{subscription_description}<br /><br />You can view the subscription by clicking <a href=\"{subscription_link}\">here</a><br />\r\n<div style=\"text-align: center;\"><span style=\"font-size: 10pt;\">&nbsp;</span></div>\r\nBest Regards,<br />{email_signature}<br /><br /><span style=\"font-size: 10pt;\"><span style=\"color: #999999;\">You are receiving this email because you are either administrator or you are creator of the subscription.</span></span>','{companyname} | CRM','',0,1,0),
(72,'client','contact-verification-email','english','Email Verification (Sent to Contact After Registration)','Verify Email Address','<p>Hello&nbsp;{contact_firstname}<br /><br />Please click the button below to verify your email address.<br /><br /><a href=\"{email_verification_url}\">Verify Email Address</a><br /><br />If you did not create an account, no further action is required</p>\r\n<p><br />{email_signature}</p>','{companyname} | CRM','',0,1,0),
(73,'client','new-customer-profile-file-uploaded-to-staff','english','New Customer Profile File(s) Uploaded (Sent to Staff)','Customer Uploaded New File(s) in Profile','Hi!<br /><br />New file(s) is uploaded into the customer ({client_company}) profile by&nbsp;{contact_firstname}<br /><br />You can check the uploaded files into the admin area by clicking <a href=\"{customer_profile_files_admin_link}\">here</a> or at the following link:&nbsp;{customer_profile_files_admin_link}<br /><br />{email_signature}','{companyname} | CRM','',0,1,0),
(74,'staff','event-notification-to-staff','english','Event Notification (Calendar)','Upcoming Event - {event_title}','Hi {staff_firstname}! <br /><br />This is a reminder for event <a href=\\\"{event_link}\\\">{event_title}</a> scheduled at {event_start_date}. <br /><br />Regards.','','',0,1,0),
(75,'subscriptions','subscription-payment-requires-action','english','Credit Card Authorization Required - SCA','Important: Confirm your subscription {subscription_name} payment','<p>Hello {contact_firstname}</p>\r\n<p><strong>Your bank sometimes requires an additional step to make sure an online transaction was authorized.</strong><br /><br />Because of European regulation to protect consumers, many online payments now require two-factor authentication. Your bank ultimately decides when authentication is required to confirm a payment, but you may notice this step when you start paying for a service or when the cost changes.<br /><br />In order to pay the subscription <strong>{subscription_name}</strong>, you will need to&nbsp;confirm your payment by clicking on the follow link: <strong><a href=\"{subscription_authorize_payment_link}\">{subscription_authorize_payment_link}</a></strong><br /><br />To view the subscription, please click at the following link: <a href=\"{subscription_link}\"><span>{subscription_link}</span></a><br />or you can login in our dedicated area here: <a href=\"{crm_url}/login\">{crm_url}/login</a> in case you want to update your credit card or view the subscriptions you are subscribed.<br /><br />Best Regards,<br />{email_signature}</p>','{companyname} | CRM','',0,1,0),
(76,'invoice','invoice-due-notice','english','Invoice Due Notice','Your {invoice_number} will be due soon','<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}<br /><br /></span>You invoice <span style=\"font-size: 12pt;\"><strong># {invoice_number} </strong>will be due on <strong>{invoice_duedate}</strong></span><br /><br /><span style=\"font-size: 12pt;\">You can view the invoice on the following link: <a href=\"{invoice_link}\">{invoice_number}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>','{companyname} | CRM','',0,1,0),
(77,'estimate_request','estimate-request-submitted-to-staff','english','Estimate Request Submitted (Sent to Staff)','New Estimate Request Submitted','<span> Hello,&nbsp;</span><br /><br />{estimate_request_email} submitted an estimate request via the {estimate_request_form_name} form.<br /><br />You can view the request at the following link: <a href=\"{estimate_request_link}\">{estimate_request_link}</a><br /><br />==<br /><br />{estimate_request_submitted_data}<br /><br />Kind Regards,<br /><span>{email_signature}</span>','{companyname} | CRM','',0,1,0),
(78,'estimate_request','estimate-request-assigned','english','Estimate Request Assigned (Sent to Staff)','New Estimate Request Assigned','<span> Hello {estimate_request_assigned},&nbsp;</span><br /><br />Estimate request #{estimate_request_id} has been assigned to you.<br /><br />You can view the request at the following link: <a href=\"{estimate_request_link}\">{estimate_request_link}</a><br /><br />Kind Regards,<br /><span>{email_signature}</span>','{companyname} | CRM','',0,1,0),
(79,'estimate_request','estimate-request-received-to-user','english','Estimate Request Received (Sent to User)','Estimate Request Received','Hello,<br /><br /><strong>Your request has been received.</strong><br /><br />This email is to let you know that we received your request and we will get back to you as soon as possible with more information.<br /><br />Best Regards,<br />{email_signature}','{companyname} | CRM','',0,0,0),
(80,'notifications','non-billed-tasks-reminder','english','Non-billed tasks reminder (sent to selected staff members)','Action required: Completed tasks are not billed','Hello {staff_firstname}<br><br>The following tasks are marked as complete but not yet billed:<br><br>{unbilled_tasks_list}<br><br>Kind Regards,<br><br>{email_signature}','{companyname} | CRM','',0,1,0),
(81,'invoice','invoices-batch-payments','english','Invoices Payments Recorded in Batch (Sent to Customer)','We have received your payments','Hello {contact_firstname} {contact_lastname}<br><br>Thank you for the payments. Please find the payments details below:<br><br>{batch_payments_list}<br><br>We are looking forward working with you.<br><br>Kind Regards,<br><br>{email_signature}','{companyname} | CRM','',0,1,0),
(82,'contract','contract-sign-reminder','english','Contract Sign Reminder (Sent to Customer)','Contract Sign Reminder','<p>Hello {contact_firstname} {contact_lastname}<br /><br />This is a reminder to review and sign the contract:<a href=\"{contract_link}\">{contract_subject}</a></p><p>You can view and sign by visiting: <a href=\"{contract_link}\">{contract_subject}</a></p><p><br />We are looking forward working with you.<br /><br />Kind Regards,<br /><br />{email_signature}</p>','{companyname} | CRM','',0,1,0);
/*!40000 ALTER TABLE `techdotbit_tblemailtemplates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblestimate_request_forms`
--

DROP TABLE IF EXISTS `techdotbit_tblestimate_request_forms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblestimate_request_forms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `form_key` varchar(32) NOT NULL,
  `type` varchar(100) NOT NULL,
  `name` varchar(191) NOT NULL,
  `form_data` longtext DEFAULT NULL,
  `recaptcha` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL,
  `submit_btn_name` varchar(100) DEFAULT NULL,
  `submit_btn_bg_color` varchar(10) DEFAULT '#84c529',
  `submit_btn_text_color` varchar(10) DEFAULT '#ffffff',
  `success_submit_msg` mediumtext DEFAULT NULL,
  `submit_action` int(11) DEFAULT 0,
  `submit_redirect_url` longtext DEFAULT NULL,
  `language` varchar(100) DEFAULT NULL,
  `dateadded` datetime DEFAULT NULL,
  `notify_type` varchar(100) DEFAULT NULL,
  `notify_ids` longtext DEFAULT NULL,
  `responsible` int(11) DEFAULT NULL,
  `notify_request_submitted` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblestimate_request_forms`
--

LOCK TABLES `techdotbit_tblestimate_request_forms` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblestimate_request_forms` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblestimate_request_forms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblestimate_request_status`
--

DROP TABLE IF EXISTS `techdotbit_tblestimate_request_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblestimate_request_status` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `statusorder` int(11) DEFAULT NULL,
  `color` varchar(10) DEFAULT NULL,
  `flag` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblestimate_request_status`
--

LOCK TABLES `techdotbit_tblestimate_request_status` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblestimate_request_status` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblestimate_request_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblestimate_requests`
--

DROP TABLE IF EXISTS `techdotbit_tblestimate_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblestimate_requests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `submission` longtext NOT NULL,
  `last_status_change` datetime DEFAULT NULL,
  `date_estimated` datetime DEFAULT NULL,
  `from_form_id` int(11) DEFAULT NULL,
  `assigned` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `default_language` int(11) NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblestimate_requests`
--

LOCK TABLES `techdotbit_tblestimate_requests` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblestimate_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblestimate_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblestimates`
--

DROP TABLE IF EXISTS `techdotbit_tblestimates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblestimates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sent` tinyint(1) NOT NULL DEFAULT 0,
  `datesend` datetime DEFAULT NULL,
  `clientid` int(11) NOT NULL,
  `deleted_customer_name` varchar(100) DEFAULT NULL,
  `project_id` int(11) NOT NULL DEFAULT 0,
  `number` int(11) NOT NULL,
  `prefix` varchar(50) DEFAULT NULL,
  `number_format` int(11) NOT NULL DEFAULT 0,
  `hash` varchar(32) DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `date` date NOT NULL,
  `expirydate` date DEFAULT NULL,
  `currency` int(11) NOT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `total_tax` decimal(15,2) NOT NULL DEFAULT 0.00,
  `total` decimal(15,2) NOT NULL,
  `adjustment` decimal(15,2) DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `clientnote` mediumtext DEFAULT NULL,
  `adminnote` mediumtext DEFAULT NULL,
  `discount_percent` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `discount_type` varchar(30) DEFAULT NULL,
  `invoiceid` int(11) DEFAULT NULL,
  `invoiced_date` datetime DEFAULT NULL,
  `terms` mediumtext DEFAULT NULL,
  `reference_no` varchar(100) DEFAULT NULL,
  `sale_agent` int(11) NOT NULL DEFAULT 0,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT NULL,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT NULL,
  `include_shipping` tinyint(1) NOT NULL,
  `show_shipping_on_estimate` tinyint(1) NOT NULL DEFAULT 1,
  `show_quantity_as` int(11) NOT NULL DEFAULT 1,
  `pipeline_order` int(11) DEFAULT 1,
  `is_expiry_notified` int(11) NOT NULL DEFAULT 0,
  `acceptance_firstname` varchar(50) DEFAULT NULL,
  `acceptance_lastname` varchar(50) DEFAULT NULL,
  `acceptance_email` varchar(100) DEFAULT NULL,
  `acceptance_date` datetime DEFAULT NULL,
  `acceptance_ip` varchar(40) DEFAULT NULL,
  `signature` varchar(40) DEFAULT NULL,
  `short_link` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `currency` (`currency`),
  KEY `project_id` (`project_id`),
  KEY `sale_agent` (`sale_agent`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblestimates`
--

LOCK TABLES `techdotbit_tblestimates` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblestimates` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblestimates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblevents`
--

DROP TABLE IF EXISTS `techdotbit_tblevents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblevents` (
  `eventid` int(11) NOT NULL AUTO_INCREMENT,
  `title` longtext NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `userid` int(11) NOT NULL,
  `start` datetime NOT NULL,
  `end` datetime DEFAULT NULL,
  `public` int(11) NOT NULL DEFAULT 0,
  `color` varchar(10) DEFAULT NULL,
  `isstartnotified` tinyint(1) NOT NULL DEFAULT 0,
  `reminder_before` int(11) NOT NULL DEFAULT 0,
  `reminder_before_type` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`eventid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblevents`
--

LOCK TABLES `techdotbit_tblevents` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblevents` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblevents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblexpenses`
--

DROP TABLE IF EXISTS `techdotbit_tblexpenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblexpenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` int(11) NOT NULL,
  `currency` int(11) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `tax` int(11) DEFAULT NULL,
  `tax2` int(11) NOT NULL DEFAULT 0,
  `reference_no` varchar(100) DEFAULT NULL,
  `note` mediumtext DEFAULT NULL,
  `expense_name` varchar(191) DEFAULT NULL,
  `clientid` int(11) NOT NULL,
  `project_id` int(11) NOT NULL DEFAULT 0,
  `billable` int(11) DEFAULT 0,
  `invoiceid` int(11) DEFAULT NULL,
  `paymentmode` varchar(50) DEFAULT NULL,
  `date` date NOT NULL,
  `recurring_type` varchar(10) DEFAULT NULL,
  `repeat_every` int(11) DEFAULT NULL,
  `recurring` int(11) NOT NULL DEFAULT 0,
  `cycles` int(11) NOT NULL DEFAULT 0,
  `total_cycles` int(11) NOT NULL DEFAULT 0,
  `custom_recurring` int(11) NOT NULL DEFAULT 0,
  `last_recurring_date` date DEFAULT NULL,
  `create_invoice_billable` tinyint(1) DEFAULT NULL,
  `send_invoice_to_customer` tinyint(1) NOT NULL,
  `recurring_from` int(11) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  `addedfrom` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `project_id` (`project_id`),
  KEY `category` (`category`),
  KEY `currency` (`currency`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblexpenses`
--

LOCK TABLES `techdotbit_tblexpenses` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblexpenses` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblexpenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblexpenses_categories`
--

DROP TABLE IF EXISTS `techdotbit_tblexpenses_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblexpenses_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblexpenses_categories`
--

LOCK TABLES `techdotbit_tblexpenses_categories` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblexpenses_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblexpenses_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblfiles`
--

DROP TABLE IF EXISTS `techdotbit_tblfiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblfiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) NOT NULL,
  `file_name` varchar(191) NOT NULL,
  `filetype` varchar(40) DEFAULT NULL,
  `visible_to_customer` int(11) NOT NULL DEFAULT 0,
  `attachment_key` varchar(32) DEFAULT NULL,
  `external` varchar(40) DEFAULT NULL,
  `external_link` mediumtext DEFAULT NULL,
  `thumbnail_link` mediumtext DEFAULT NULL COMMENT 'For external usage',
  `staffid` int(11) NOT NULL,
  `contact_id` int(11) DEFAULT 0,
  `task_comment_id` int(11) NOT NULL DEFAULT 0,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblfiles`
--

LOCK TABLES `techdotbit_tblfiles` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblfiles` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblfiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblfilter_defaults`
--

DROP TABLE IF EXISTS `techdotbit_tblfilter_defaults`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblfilter_defaults` (
  `filter_id` int(10) unsigned NOT NULL,
  `staff_id` int(11) NOT NULL,
  `identifier` varchar(191) NOT NULL,
  `view` varchar(191) NOT NULL,
  KEY `filter_id` (`filter_id`),
  KEY `techdotbit_staff_id` (`staff_id`),
  CONSTRAINT `techdotbit_tblfilter_defaults_ibfk_1` FOREIGN KEY (`filter_id`) REFERENCES `techdotbit_tblfilters` (`id`) ON DELETE CASCADE,
  CONSTRAINT `techdotbit_tblfilter_defaults_ibfk_2` FOREIGN KEY (`staff_id`) REFERENCES `techdotbit_tblstaff` (`staffid`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblfilter_defaults`
--

LOCK TABLES `techdotbit_tblfilter_defaults` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblfilter_defaults` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblfilter_defaults` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblfilters`
--

DROP TABLE IF EXISTS `techdotbit_tblfilters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblfilters` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `builder` mediumtext NOT NULL,
  `staff_id` int(10) unsigned NOT NULL,
  `identifier` varchar(191) NOT NULL,
  `is_shared` tinyint(3) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblfilters`
--

LOCK TABLES `techdotbit_tblfilters` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblfilters` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblfilters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblform_question_box`
--

DROP TABLE IF EXISTS `techdotbit_tblform_question_box`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblform_question_box` (
  `boxid` int(11) NOT NULL AUTO_INCREMENT,
  `boxtype` varchar(10) NOT NULL,
  `questionid` int(11) NOT NULL,
  PRIMARY KEY (`boxid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblform_question_box`
--

LOCK TABLES `techdotbit_tblform_question_box` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblform_question_box` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblform_question_box` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblform_question_box_description`
--

DROP TABLE IF EXISTS `techdotbit_tblform_question_box_description`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblform_question_box_description` (
  `questionboxdescriptionid` int(11) NOT NULL AUTO_INCREMENT,
  `description` longtext NOT NULL,
  `boxid` longtext NOT NULL,
  `questionid` int(11) NOT NULL,
  PRIMARY KEY (`questionboxdescriptionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblform_question_box_description`
--

LOCK TABLES `techdotbit_tblform_question_box_description` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblform_question_box_description` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblform_question_box_description` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblform_questions`
--

DROP TABLE IF EXISTS `techdotbit_tblform_questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblform_questions` (
  `questionid` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) DEFAULT NULL,
  `question` longtext NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT 0,
  `question_order` int(11) NOT NULL,
  PRIMARY KEY (`questionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblform_questions`
--

LOCK TABLES `techdotbit_tblform_questions` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblform_questions` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblform_questions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblform_results`
--

DROP TABLE IF EXISTS `techdotbit_tblform_results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblform_results` (
  `resultid` int(11) NOT NULL AUTO_INCREMENT,
  `boxid` int(11) NOT NULL,
  `boxdescriptionid` int(11) DEFAULT NULL,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) DEFAULT NULL,
  `questionid` int(11) NOT NULL,
  `answer` mediumtext DEFAULT NULL,
  `resultsetid` int(11) NOT NULL,
  PRIMARY KEY (`resultid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblform_results`
--

LOCK TABLES `techdotbit_tblform_results` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblform_results` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblform_results` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblgdpr_requests`
--

DROP TABLE IF EXISTS `techdotbit_tblgdpr_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblgdpr_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clientid` int(11) NOT NULL DEFAULT 0,
  `contact_id` int(11) NOT NULL DEFAULT 0,
  `lead_id` int(11) NOT NULL DEFAULT 0,
  `request_type` varchar(191) DEFAULT NULL,
  `status` varchar(40) DEFAULT NULL,
  `request_date` datetime NOT NULL,
  `request_from` varchar(150) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblgdpr_requests`
--

LOCK TABLES `techdotbit_tblgdpr_requests` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblgdpr_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblgdpr_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblgoals`
--

DROP TABLE IF EXISTS `techdotbit_tblgoals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblgoals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(191) NOT NULL,
  `description` text NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `goal_type` int(11) NOT NULL,
  `contract_type` int(11) NOT NULL DEFAULT 0,
  `achievement` int(11) NOT NULL,
  `notify_when_fail` tinyint(1) NOT NULL DEFAULT 1,
  `notify_when_achieve` tinyint(1) NOT NULL DEFAULT 1,
  `notified` int(11) NOT NULL DEFAULT 0,
  `staff_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `staff_id` (`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblgoals`
--

LOCK TABLES `techdotbit_tblgoals` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblgoals` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblgoals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblinvoicepaymentrecords`
--

DROP TABLE IF EXISTS `techdotbit_tblinvoicepaymentrecords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblinvoicepaymentrecords` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoiceid` int(11) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `paymentmode` varchar(40) DEFAULT NULL,
  `paymentmethod` varchar(191) DEFAULT NULL,
  `date` date NOT NULL,
  `daterecorded` datetime NOT NULL,
  `note` mediumtext DEFAULT NULL,
  `transactionid` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `invoiceid` (`invoiceid`),
  KEY `paymentmethod` (`paymentmethod`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblinvoicepaymentrecords`
--

LOCK TABLES `techdotbit_tblinvoicepaymentrecords` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblinvoicepaymentrecords` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblinvoicepaymentrecords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblinvoices`
--

DROP TABLE IF EXISTS `techdotbit_tblinvoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblinvoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sent` tinyint(1) NOT NULL DEFAULT 0,
  `datesend` datetime DEFAULT NULL,
  `clientid` int(11) NOT NULL,
  `deleted_customer_name` varchar(100) DEFAULT NULL,
  `number` int(11) NOT NULL,
  `prefix` varchar(50) DEFAULT NULL,
  `number_format` int(11) NOT NULL DEFAULT 0,
  `datecreated` datetime NOT NULL,
  `date` date NOT NULL,
  `duedate` date DEFAULT NULL,
  `currency` int(11) NOT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `total_tax` decimal(15,2) NOT NULL DEFAULT 0.00,
  `total` decimal(15,2) NOT NULL,
  `adjustment` decimal(15,2) DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `hash` varchar(32) NOT NULL,
  `status` int(11) DEFAULT 1,
  `clientnote` mediumtext DEFAULT NULL,
  `adminnote` mediumtext DEFAULT NULL,
  `last_overdue_reminder` date DEFAULT NULL,
  `last_due_reminder` date DEFAULT NULL,
  `cancel_overdue_reminders` int(11) NOT NULL DEFAULT 0,
  `allowed_payment_modes` longtext DEFAULT NULL,
  `token` longtext DEFAULT NULL,
  `discount_percent` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `discount_type` varchar(30) NOT NULL,
  `recurring` int(11) NOT NULL DEFAULT 0,
  `recurring_type` varchar(10) DEFAULT NULL,
  `custom_recurring` tinyint(1) NOT NULL DEFAULT 0,
  `cycles` int(11) NOT NULL DEFAULT 0,
  `total_cycles` int(11) NOT NULL DEFAULT 0,
  `is_recurring_from` int(11) DEFAULT NULL,
  `last_recurring_date` date DEFAULT NULL,
  `terms` mediumtext DEFAULT NULL,
  `sale_agent` int(11) NOT NULL DEFAULT 0,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT NULL,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT NULL,
  `include_shipping` tinyint(1) NOT NULL,
  `show_shipping_on_invoice` tinyint(1) NOT NULL DEFAULT 1,
  `show_quantity_as` int(11) NOT NULL DEFAULT 1,
  `project_id` int(11) DEFAULT 0,
  `subscription_id` int(11) NOT NULL DEFAULT 0,
  `perfex_saas_packageid` int(11) DEFAULT NULL,
  `short_link` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `currency` (`currency`),
  KEY `clientid` (`clientid`),
  KEY `project_id` (`project_id`),
  KEY `sale_agent` (`sale_agent`),
  KEY `total` (`total`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblinvoices`
--

LOCK TABLES `techdotbit_tblinvoices` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblinvoices` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblinvoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblitem_tax`
--

DROP TABLE IF EXISTS `techdotbit_tblitem_tax`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblitem_tax` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemid` int(11) NOT NULL,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) NOT NULL,
  `taxrate` decimal(15,2) NOT NULL,
  `taxname` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `itemid` (`itemid`),
  KEY `rel_id` (`rel_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblitem_tax`
--

LOCK TABLES `techdotbit_tblitem_tax` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblitem_tax` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblitem_tax` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblitemable`
--

DROP TABLE IF EXISTS `techdotbit_tblitemable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblitemable` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(15) NOT NULL,
  `description` longtext NOT NULL,
  `long_description` longtext DEFAULT NULL,
  `qty` decimal(15,2) NOT NULL,
  `rate` decimal(15,2) NOT NULL,
  `unit` varchar(40) DEFAULT NULL,
  `item_order` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`),
  KEY `qty` (`qty`),
  KEY `rate` (`rate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblitemable`
--

LOCK TABLES `techdotbit_tblitemable` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblitemable` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblitemable` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblitems`
--

DROP TABLE IF EXISTS `techdotbit_tblitems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblitems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` longtext NOT NULL,
  `long_description` mediumtext DEFAULT NULL,
  `rate` decimal(15,2) NOT NULL,
  `tax` int(11) DEFAULT NULL,
  `tax2` int(11) DEFAULT NULL,
  `unit` varchar(40) DEFAULT NULL,
  `group_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `tax` (`tax`),
  KEY `tax2` (`tax2`),
  KEY `group_id` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblitems`
--

LOCK TABLES `techdotbit_tblitems` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblitems` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblitems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblitems_groups`
--

DROP TABLE IF EXISTS `techdotbit_tblitems_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblitems_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblitems_groups`
--

LOCK TABLES `techdotbit_tblitems_groups` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblitems_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblitems_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblknowedge_base_article_feedback`
--

DROP TABLE IF EXISTS `techdotbit_tblknowedge_base_article_feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblknowedge_base_article_feedback` (
  `articleanswerid` int(11) NOT NULL AUTO_INCREMENT,
  `articleid` int(11) NOT NULL,
  `answer` int(11) NOT NULL,
  `ip` varchar(40) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`articleanswerid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblknowedge_base_article_feedback`
--

LOCK TABLES `techdotbit_tblknowedge_base_article_feedback` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblknowedge_base_article_feedback` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblknowedge_base_article_feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblknowledge_base`
--

DROP TABLE IF EXISTS `techdotbit_tblknowledge_base`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblknowledge_base` (
  `articleid` int(11) NOT NULL AUTO_INCREMENT,
  `articlegroup` int(11) NOT NULL,
  `subject` longtext NOT NULL,
  `description` mediumtext NOT NULL,
  `slug` longtext NOT NULL,
  `active` tinyint(4) NOT NULL,
  `datecreated` datetime NOT NULL,
  `article_order` int(11) NOT NULL DEFAULT 0,
  `staff_article` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`articleid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblknowledge_base`
--

LOCK TABLES `techdotbit_tblknowledge_base` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblknowledge_base` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblknowledge_base` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblknowledge_base_groups`
--

DROP TABLE IF EXISTS `techdotbit_tblknowledge_base_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblknowledge_base_groups` (
  `groupid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `group_slug` mediumtext DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `active` tinyint(4) NOT NULL,
  `color` varchar(10) DEFAULT '#28B8DA',
  `group_order` int(11) DEFAULT 0,
  PRIMARY KEY (`groupid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblknowledge_base_groups`
--

LOCK TABLES `techdotbit_tblknowledge_base_groups` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblknowledge_base_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblknowledge_base_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tbllead_activity_log`
--

DROP TABLE IF EXISTS `techdotbit_tbllead_activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tbllead_activity_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `leadid` int(11) NOT NULL,
  `description` longtext NOT NULL,
  `additional_data` mediumtext DEFAULT NULL,
  `date` datetime NOT NULL,
  `staffid` int(11) NOT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `custom_activity` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tbllead_activity_log`
--

LOCK TABLES `techdotbit_tbllead_activity_log` WRITE;
/*!40000 ALTER TABLE `techdotbit_tbllead_activity_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tbllead_activity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tbllead_integration_emails`
--

DROP TABLE IF EXISTS `techdotbit_tbllead_integration_emails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tbllead_integration_emails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` longtext DEFAULT NULL,
  `body` longtext DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  `leadid` int(11) NOT NULL,
  `emailid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tbllead_integration_emails`
--

LOCK TABLES `techdotbit_tbllead_integration_emails` WRITE;
/*!40000 ALTER TABLE `techdotbit_tbllead_integration_emails` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tbllead_integration_emails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblleads`
--

DROP TABLE IF EXISTS `techdotbit_tblleads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblleads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(65) DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `company` varchar(191) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `country` int(11) NOT NULL DEFAULT 0,
  `zip` varchar(15) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `assigned` int(11) NOT NULL DEFAULT 0,
  `dateadded` datetime NOT NULL,
  `from_form_id` int(11) NOT NULL DEFAULT 0,
  `status` int(11) NOT NULL,
  `source` int(11) NOT NULL,
  `lastcontact` datetime DEFAULT NULL,
  `dateassigned` date DEFAULT NULL,
  `last_status_change` datetime DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `website` varchar(150) DEFAULT NULL,
  `leadorder` int(11) DEFAULT 1,
  `phonenumber` varchar(50) DEFAULT NULL,
  `date_converted` datetime DEFAULT NULL,
  `lost` tinyint(1) NOT NULL DEFAULT 0,
  `junk` int(11) NOT NULL DEFAULT 0,
  `last_lead_status` int(11) NOT NULL DEFAULT 0,
  `is_imported_from_email_integration` tinyint(1) NOT NULL DEFAULT 0,
  `email_integration_uid` varchar(30) DEFAULT NULL,
  `is_public` tinyint(1) NOT NULL DEFAULT 0,
  `default_language` varchar(40) DEFAULT NULL,
  `client_id` int(11) NOT NULL DEFAULT 0,
  `lead_value` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `company` (`company`),
  KEY `email` (`email`),
  KEY `assigned` (`assigned`),
  KEY `status` (`status`),
  KEY `source` (`source`),
  KEY `lastcontact` (`lastcontact`),
  KEY `dateadded` (`dateadded`),
  KEY `leadorder` (`leadorder`),
  KEY `from_form_id` (`from_form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblleads`
--

LOCK TABLES `techdotbit_tblleads` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblleads` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblleads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblleads_email_integration`
--

DROP TABLE IF EXISTS `techdotbit_tblleads_email_integration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblleads_email_integration` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'the ID always must be 1',
  `active` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `imap_server` varchar(100) NOT NULL,
  `password` longtext NOT NULL,
  `check_every` int(11) NOT NULL DEFAULT 5,
  `responsible` int(11) NOT NULL,
  `lead_source` int(11) NOT NULL,
  `lead_status` int(11) NOT NULL,
  `encryption` varchar(3) DEFAULT NULL,
  `folder` varchar(100) NOT NULL,
  `last_run` varchar(50) DEFAULT NULL,
  `notify_lead_imported` tinyint(1) NOT NULL DEFAULT 1,
  `notify_lead_contact_more_times` tinyint(1) NOT NULL DEFAULT 1,
  `notify_type` varchar(20) DEFAULT NULL,
  `notify_ids` longtext DEFAULT NULL,
  `mark_public` int(11) NOT NULL DEFAULT 0,
  `only_loop_on_unseen_emails` tinyint(1) NOT NULL DEFAULT 1,
  `delete_after_import` int(11) NOT NULL DEFAULT 0,
  `create_task_if_customer` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblleads_email_integration`
--

LOCK TABLES `techdotbit_tblleads_email_integration` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblleads_email_integration` DISABLE KEYS */;
INSERT INTO `techdotbit_tblleads_email_integration` VALUES
(1,0,'','','',10,0,0,0,'tls','INBOX','',1,1,'assigned','',0,1,0,1);
/*!40000 ALTER TABLE `techdotbit_tblleads_email_integration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblleads_sources`
--

DROP TABLE IF EXISTS `techdotbit_tblleads_sources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblleads_sources` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblleads_sources`
--

LOCK TABLES `techdotbit_tblleads_sources` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblleads_sources` DISABLE KEYS */;
INSERT INTO `techdotbit_tblleads_sources` VALUES
(2,'Facebook'),
(1,'Google');
/*!40000 ALTER TABLE `techdotbit_tblleads_sources` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblleads_status`
--

DROP TABLE IF EXISTS `techdotbit_tblleads_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblleads_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `statusorder` int(11) DEFAULT NULL,
  `color` varchar(10) DEFAULT '#28B8DA',
  `isdefault` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblleads_status`
--

LOCK TABLES `techdotbit_tblleads_status` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblleads_status` DISABLE KEYS */;
INSERT INTO `techdotbit_tblleads_status` VALUES
(1,'Customer',1000,'#7cb342',1);
/*!40000 ALTER TABLE `techdotbit_tblleads_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tbllistemails`
--

DROP TABLE IF EXISTS `techdotbit_tbllistemails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tbllistemails` (
  `emailid` int(11) NOT NULL AUTO_INCREMENT,
  `listid` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`emailid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tbllistemails`
--

LOCK TABLES `techdotbit_tbllistemails` WRITE;
/*!40000 ALTER TABLE `techdotbit_tbllistemails` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tbllistemails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblmail_queue`
--

DROP TABLE IF EXISTS `techdotbit_tblmail_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblmail_queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `engine` varchar(40) DEFAULT NULL,
  `email` varchar(191) NOT NULL,
  `cc` mediumtext DEFAULT NULL,
  `bcc` mediumtext DEFAULT NULL,
  `message` longtext NOT NULL,
  `alt_message` longtext DEFAULT NULL,
  `status` enum('pending','sending','sent','failed') DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `headers` mediumtext DEFAULT NULL,
  `attachments` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblmail_queue`
--

LOCK TABLES `techdotbit_tblmail_queue` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblmail_queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblmail_queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblmaillistscustomfields`
--

DROP TABLE IF EXISTS `techdotbit_tblmaillistscustomfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblmaillistscustomfields` (
  `customfieldid` int(11) NOT NULL AUTO_INCREMENT,
  `listid` int(11) NOT NULL,
  `fieldname` varchar(150) NOT NULL,
  `fieldslug` varchar(100) NOT NULL,
  PRIMARY KEY (`customfieldid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblmaillistscustomfields`
--

LOCK TABLES `techdotbit_tblmaillistscustomfields` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblmaillistscustomfields` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblmaillistscustomfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblmaillistscustomfieldvalues`
--

DROP TABLE IF EXISTS `techdotbit_tblmaillistscustomfieldvalues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblmaillistscustomfieldvalues` (
  `customfieldvalueid` int(11) NOT NULL AUTO_INCREMENT,
  `listid` int(11) NOT NULL,
  `customfieldid` int(11) NOT NULL,
  `emailid` int(11) NOT NULL,
  `value` varchar(100) NOT NULL,
  PRIMARY KEY (`customfieldvalueid`),
  KEY `listid` (`listid`),
  KEY `customfieldid` (`customfieldid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblmaillistscustomfieldvalues`
--

LOCK TABLES `techdotbit_tblmaillistscustomfieldvalues` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblmaillistscustomfieldvalues` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblmaillistscustomfieldvalues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblmigrations`
--

DROP TABLE IF EXISTS `techdotbit_tblmigrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblmigrations` (
  `version` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblmigrations`
--

LOCK TABLES `techdotbit_tblmigrations` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblmigrations` DISABLE KEYS */;
INSERT INTO `techdotbit_tblmigrations` VALUES
(310),
(310);
/*!40000 ALTER TABLE `techdotbit_tblmigrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblmilestones`
--

DROP TABLE IF EXISTS `techdotbit_tblmilestones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblmilestones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `description_visible_to_customer` tinyint(1) DEFAULT 0,
  `start_date` date DEFAULT NULL,
  `due_date` date NOT NULL,
  `project_id` int(11) NOT NULL,
  `color` varchar(10) DEFAULT NULL,
  `milestone_order` int(11) NOT NULL DEFAULT 0,
  `datecreated` date NOT NULL,
  `hide_from_customer` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblmilestones`
--

LOCK TABLES `techdotbit_tblmilestones` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblmilestones` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblmilestones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblmodules`
--

DROP TABLE IF EXISTS `techdotbit_tblmodules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblmodules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module_name` varchar(55) NOT NULL,
  `installed_version` varchar(11) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblmodules`
--

LOCK TABLES `techdotbit_tblmodules` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblmodules` DISABLE KEYS */;
INSERT INTO `techdotbit_tblmodules` VALUES
(1,'surveys','2.3.0',0),
(2,'goals','2.3.0',0);
/*!40000 ALTER TABLE `techdotbit_tblmodules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblnewsfeed_comment_likes`
--

DROP TABLE IF EXISTS `techdotbit_tblnewsfeed_comment_likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblnewsfeed_comment_likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `postid` int(11) NOT NULL,
  `commentid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `dateliked` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblnewsfeed_comment_likes`
--

LOCK TABLES `techdotbit_tblnewsfeed_comment_likes` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblnewsfeed_comment_likes` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblnewsfeed_comment_likes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblnewsfeed_post_comments`
--

DROP TABLE IF EXISTS `techdotbit_tblnewsfeed_post_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblnewsfeed_post_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` mediumtext DEFAULT NULL,
  `userid` int(11) NOT NULL,
  `postid` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblnewsfeed_post_comments`
--

LOCK TABLES `techdotbit_tblnewsfeed_post_comments` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblnewsfeed_post_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblnewsfeed_post_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblnewsfeed_post_likes`
--

DROP TABLE IF EXISTS `techdotbit_tblnewsfeed_post_likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblnewsfeed_post_likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `postid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `dateliked` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblnewsfeed_post_likes`
--

LOCK TABLES `techdotbit_tblnewsfeed_post_likes` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblnewsfeed_post_likes` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblnewsfeed_post_likes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblnewsfeed_posts`
--

DROP TABLE IF EXISTS `techdotbit_tblnewsfeed_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblnewsfeed_posts` (
  `postid` int(11) NOT NULL AUTO_INCREMENT,
  `creator` int(11) NOT NULL,
  `datecreated` datetime NOT NULL,
  `visibility` varchar(100) NOT NULL,
  `content` mediumtext NOT NULL,
  `pinned` int(11) NOT NULL,
  `datepinned` datetime DEFAULT NULL,
  PRIMARY KEY (`postid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblnewsfeed_posts`
--

LOCK TABLES `techdotbit_tblnewsfeed_posts` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblnewsfeed_posts` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblnewsfeed_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblnotes`
--

DROP TABLE IF EXISTS `techdotbit_tblnotes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblnotes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `date_contacted` datetime DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblnotes`
--

LOCK TABLES `techdotbit_tblnotes` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblnotes` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblnotes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblnotifications`
--

DROP TABLE IF EXISTS `techdotbit_tblnotifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblnotifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `isread` int(11) NOT NULL DEFAULT 0,
  `isread_inline` tinyint(1) NOT NULL DEFAULT 0,
  `date` datetime NOT NULL,
  `description` mediumtext NOT NULL,
  `fromuserid` int(11) NOT NULL,
  `fromclientid` int(11) NOT NULL DEFAULT 0,
  `from_fullname` varchar(100) NOT NULL,
  `touserid` int(11) NOT NULL,
  `fromcompany` int(11) DEFAULT NULL,
  `link` longtext DEFAULT NULL,
  `additional_data` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblnotifications`
--

LOCK TABLES `techdotbit_tblnotifications` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblnotifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblnotifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tbloptions`
--

DROP TABLE IF EXISTS `techdotbit_tbloptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tbloptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `value` longtext NOT NULL,
  `autoload` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=454 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tbloptions`
--

LOCK TABLES `techdotbit_tbloptions` WRITE;
/*!40000 ALTER TABLE `techdotbit_tbloptions` DISABLE KEYS */;
INSERT INTO `techdotbit_tbloptions` VALUES
(1,'dateformat','Y-m-d|%Y-%m-%d',1),
(2,'companyname','Techdotbit',1),
(3,'services','1',1),
(4,'maximum_allowed_ticket_attachments','4',1),
(5,'ticket_attachments_file_extensions','.jpg,.png,.pdf,.doc,.zip,.rar',1),
(6,'staff_access_only_assigned_departments','1',1),
(7,'use_knowledge_base','1',1),
(8,'smtp_email','reena@techdotbit.com',1),
(10,'company_info_format','{company_name}<br />\r\n      {address}<br />\r\n      {city} {state}<br />\r\n      {country_code} {zip_code}<br />\r\n      {vat_number_with_label}',0),
(11,'smtp_port','587',1),
(12,'smtp_host','autoconfig.srv810535.hstgr.cloud',1),
(13,'smtp_email_charset','utf-8',1),
(14,'default_timezone','Asia/Kolkata',1),
(15,'clients_default_theme','perfex',1),
(17,'tables_pagination_limit','25',1),
(19,'allow_registration','1',1),
(20,'knowledge_base_without_registration','1',1),
(21,'email_signature','DOT ONE',1),
(22,'default_staff_role','1',1),
(23,'newsfeed_maximum_files_upload','10',1),
(24,'contract_expiration_before','4',1),
(25,'invoice_prefix','INV-',1),
(26,'decimal_separator','.',1),
(27,'thousand_separator',',',1),
(34,'view_invoice_only_logged_in','0',1),
(35,'invoice_number_format','1',1),
(36,'next_invoice_number','1',0),
(37,'active_language','english',1),
(38,'invoice_number_decrement_on_delete','1',1),
(39,'automatically_send_invoice_overdue_reminder_after','1',1),
(40,'automatically_resend_invoice_overdue_reminder_after','3',1),
(41,'expenses_auto_operations_hour','21',1),
(42,'delete_only_on_last_invoice','1',1),
(43,'delete_only_on_last_estimate','1',1),
(44,'create_invoice_from_recurring_only_on_paid_invoices','0',1),
(45,'allow_payment_amount_to_be_modified','1',1),
(46,'rtl_support_client','0',1),
(47,'limit_top_search_bar_results_to','10',1),
(48,'estimate_prefix','EST-',1),
(49,'next_estimate_number','1',0),
(50,'estimate_number_decrement_on_delete','1',1),
(51,'estimate_number_format','1',1),
(52,'estimate_auto_convert_to_invoice_on_client_accept','1',1),
(53,'exclude_estimate_from_client_area_with_draft_status','1',1),
(54,'rtl_support_admin','0',1),
(55,'last_cron_run','1750844102',1),
(56,'show_sale_agent_on_estimates','1',1),
(57,'show_sale_agent_on_invoices','1',1),
(58,'predefined_terms_invoice','',1),
(59,'predefined_terms_estimate','',1),
(60,'default_task_priority','2',1),
(62,'show_expense_reminders_on_calendar','1',1),
(63,'only_show_contact_tickets','1',1),
(64,'predefined_clientnote_invoice','',1),
(65,'predefined_clientnote_estimate','',1),
(66,'custom_pdf_logo_image_url','',1),
(68,'invoice_due_after','30',1),
(70,'google_calendar_main_calendar','',1),
(71,'default_tax','a:0:{}',1),
(72,'show_invoices_on_calendar','1',1),
(73,'show_estimates_on_calendar','1',1),
(74,'show_contracts_on_calendar','1',1),
(75,'show_tasks_on_calendar','1',1),
(76,'show_customer_reminders_on_calendar','1',1),
(77,'output_client_pdfs_from_admin_area_in_client_language','0',1),
(78,'show_lead_reminders_on_calendar','1',1),
(79,'send_estimate_expiry_reminder_before','4',1),
(80,'leads_default_source','',1),
(81,'leads_default_status','',1),
(82,'proposal_expiry_reminder_enabled','1',1),
(83,'send_proposal_expiry_reminder_before','4',1),
(84,'default_contact_permissions','a:8:{i:0;s:1:\"1\";i:1;s:1:\"2\";i:2;s:1:\"3\";i:3;s:1:\"4\";i:4;s:1:\"5\";i:5;s:1:\"6\";i:6;s:6:\"311301\";i:7;s:6:\"311302\";}',1),
(85,'pdf_logo_width','150',1),
(86,'access_tickets_to_none_staff_members','0',1),
(87,'customer_default_country','102',1),
(88,'view_estimate_only_logged_in','0',1),
(89,'show_status_on_pdf_ei','1',1),
(90,'email_piping_only_replies','0',1),
(91,'email_piping_only_registered','0',1),
(92,'default_view_calendar','dayGridMonth',1),
(93,'email_piping_default_priority','2',1),
(94,'total_to_words_lowercase','0',1),
(95,'show_tax_per_item','1',1),
(96,'total_to_words_enabled','0',1),
(97,'receive_notification_on_new_ticket','1',0),
(98,'autoclose_tickets_after','0',1),
(99,'media_max_file_size_upload','10',1),
(100,'client_staff_add_edit_delete_task_comments_first_hour','0',1),
(101,'show_projects_on_calendar','1',1),
(102,'leads_kanban_limit','50',1),
(103,'tasks_reminder_notification_before','2',1),
(104,'pdf_font','freesans',1),
(105,'pdf_table_heading_color','#323a45',1),
(106,'pdf_table_heading_text_color','#ffffff',1),
(107,'pdf_font_size','10',1),
(108,'default_leads_kanban_sort','leadorder',1),
(109,'default_leads_kanban_sort_type','asc',1),
(110,'allowed_files','.png,.jpg,.pdf,.doc,.docx,.xls,.xlsx,.zip,.rar,.txt',1),
(111,'show_all_tasks_for_project_member','1',1),
(112,'email_protocol','smtp',1),
(113,'calendar_first_day','0',1),
(115,'show_help_on_setup_menu','1',1),
(116,'show_proposals_on_calendar','1',1),
(117,'smtp_encryption','tls',1),
(119,'smtp_username','reena@techdotbit.com',1),
(120,'auto_stop_tasks_timers_on_new_timer','1',1),
(121,'notification_when_customer_pay_invoice','1',1),
(122,'calendar_invoice_color','#FF6F00',1),
(123,'calendar_estimate_color','#FF6F00',1),
(124,'calendar_proposal_color','#84c529',1),
(125,'new_task_auto_assign_current_member','1',1),
(126,'calendar_reminder_color','#03A9F4',1),
(127,'calendar_contract_color','#B72974',1),
(128,'calendar_project_color','#B72974',1),
(129,'update_info_message','',1),
(130,'show_estimate_reminders_on_calendar','1',1),
(131,'show_invoice_reminders_on_calendar','1',1),
(132,'show_proposal_reminders_on_calendar','1',1),
(133,'proposal_due_after','7',1),
(134,'allow_customer_to_change_ticket_status','0',1),
(135,'lead_lock_after_convert_to_customer','0',1),
(136,'default_proposals_pipeline_sort','pipeline_order',1),
(137,'default_proposals_pipeline_sort_type','asc',1),
(138,'default_estimates_pipeline_sort','pipeline_order',1),
(139,'default_estimates_pipeline_sort_type','asc',1),
(140,'use_recaptcha_customers_area','0',1),
(141,'remove_decimals_on_zero','0',1),
(142,'remove_tax_name_from_item_table','0',1),
(143,'pdf_format_invoice','A4-PORTRAIT',1),
(144,'pdf_format_estimate','A4-PORTRAIT',1),
(145,'pdf_format_proposal','A4-PORTRAIT',1),
(146,'pdf_format_payment','A4-PORTRAIT',1),
(147,'pdf_format_contract','A4-PORTRAIT',1),
(148,'swap_pdf_info','0',1),
(149,'exclude_invoice_from_client_area_with_draft_status','1',1),
(150,'cron_has_run_from_cli','1',1),
(151,'hide_cron_is_required_message','0',0),
(152,'auto_assign_customer_admin_after_lead_convert','1',1),
(153,'show_transactions_on_invoice_pdf','1',1),
(154,'show_pay_link_to_invoice_pdf','1',1),
(155,'tasks_kanban_limit','50',1),
(157,'estimates_pipeline_limit','50',1),
(158,'proposals_pipeline_limit','50',1),
(159,'proposal_number_prefix','PRO-',1),
(160,'number_padding_prefixes','6',1),
(161,'show_page_number_on_pdf','0',1),
(162,'calendar_events_limit','4',1),
(163,'show_setup_menu_item_only_on_hover','0',1),
(164,'company_requires_vat_number_field','1',1),
(165,'company_is_required','1',1),
(166,'allow_contact_to_delete_files','0',1),
(168,'di','1750754494',1),
(169,'invoice_auto_operations_hour','21',1),
(170,'use_minified_files','1',1),
(171,'only_own_files_contacts','0',1),
(172,'allow_primary_contact_to_view_edit_billing_and_shipping','0',1),
(173,'estimate_due_after','7',1),
(174,'staff_members_open_tickets_to_all_contacts','1',1),
(175,'time_format','24',1),
(176,'delete_activity_log_older_then','1',1),
(177,'disable_language','0',1),
(179,'email_header','<!doctype html>\r\n      <html>\r\n      <head>\r\n      <meta name=\"viewport\" content=\"width=device-width\" />\r\n      <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />\r\n      <style>\r\n      body {\r\n        background-color: #f6f6f6;\r\n        font-family: sans-serif;\r\n        -webkit-font-smoothing: antialiased;\r\n        font-size: 14px;\r\n        line-height: 1.4;\r\n        margin: 0;\r\n        padding: 0;\r\n        -ms-text-size-adjust: 100%;\r\n        -webkit-text-size-adjust: 100%;\r\n      }\r\n      table {\r\n        border-collapse: separate;\r\n        mso-table-lspace: 0pt;\r\n        mso-table-rspace: 0pt;\r\n        width: 100%;\r\n      }\r\n      table td {\r\n        font-family: sans-serif;\r\n        font-size: 14px;\r\n        vertical-align: top;\r\n      }\r\n      /* -------------------------------------\r\n      BODY & CONTAINER\r\n      ------------------------------------- */\r\n      .body {\r\n        background-color: #f6f6f6;\r\n        width: 100%;\r\n      }\r\n      /* Set a max-width, and make it display as block so it will automatically stretch to that width, but will also shrink down on a phone or something */\r\n      \r\n      .container {\r\n        display: block;\r\n        margin: 0 auto !important;\r\n        /* makes it centered */\r\n        max-width: 680px;\r\n        padding: 10px;\r\n        width: 680px;\r\n      }\r\n      /* This should also be a block element, so that it will fill 100% of the .container */\r\n      \r\n      .content {\r\n        box-sizing: border-box;\r\n        display: block;\r\n        margin: 0 auto;\r\n        max-width: 680px;\r\n        padding: 10px;\r\n      }\r\n      /* -------------------------------------\r\n      HEADER, FOOTER, MAIN\r\n      ------------------------------------- */\r\n      \r\n      .main {\r\n        background: #fff;\r\n        border-radius: 3px;\r\n        width: 100%;\r\n      }\r\n      .wrapper {\r\n        box-sizing: border-box;\r\n        padding: 20px;\r\n      }\r\n      .footer {\r\n        clear: both;\r\n        padding-top: 10px;\r\n        text-align: center;\r\n        width: 100%;\r\n      }\r\n      .footer td,\r\n      .footer p,\r\n      .footer span,\r\n      .footer a {\r\n        color: #999999;\r\n        font-size: 12px;\r\n        text-align: center;\r\n      }\r\n      hr {\r\n        border: 0;\r\n        border-bottom: 1px solid #f6f6f6;\r\n        margin: 20px 0;\r\n      }\r\n      /* -------------------------------------\r\n      RESPONSIVE AND MOBILE FRIENDLY STYLES\r\n      ------------------------------------- */\r\n      \r\n      @media only screen and (max-width: 620px) {\r\n        table[class=body] .content {\r\n          padding: 0 !important;\r\n        }\r\n        table[class=body] .container {\r\n          padding: 0 !important;\r\n          width: 100% !important;\r\n        }\r\n        table[class=body] .main {\r\n          border-left-width: 0 !important;\r\n          border-radius: 0 !important;\r\n          border-right-width: 0 !important;\r\n        }\r\n      }\r\n      </style>\r\n      </head>\r\n      <body class=\"\">\r\n      <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" class=\"body\">\r\n      <tr>\r\n      <td>&nbsp;</td>\r\n      <td class=\"container\">\r\n      <div class=\"content\">\r\n      <!-- START CENTERED WHITE CONTAINER -->\r\n      <table class=\"main\">\r\n      <!-- START MAIN CONTENT AREA -->\r\n      <tr>\r\n      <td class=\"wrapper\">\r\n      <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\r\n      <tr>\r\n      <td>',1),
(180,'show_pdf_signature_invoice','1',0),
(181,'show_pdf_signature_estimate','1',0),
(182,'signature_image','',0),
(183,'email_footer','',1),
(184,'exclude_proposal_from_client_area_with_draft_status','1',1),
(188,'pusher_realtime_notifications','0',1),
(189,'pdf_format_statement','A4-PORTRAIT',1),
(190,'pusher_cluster','',1),
(191,'show_table_export_button','to_all',1),
(192,'allow_staff_view_proposals_assigned','1',1),
(193,'show_cloudflare_notice','1',0),
(194,'task_modal_class','modal-lg',1),
(195,'lead_modal_class','modal-lg',1),
(196,'show_timesheets_overview_all_members_notice_admins','0',1),
(197,'desktop_notifications','0',1),
(198,'hide_notified_reminders_from_calendar','1',0),
(199,'customer_info_format','{company_name}<br />\r\n      {street}<br />\r\n      {city} {state}<br />\r\n      {country_code} {zip_code}<br />\r\n      {vat_number_with_label}',0),
(200,'timer_started_change_status_in_progress','1',0),
(201,'default_ticket_reply_status','3',1),
(202,'default_task_status','auto',1),
(203,'email_queue_skip_with_attachments','1',1),
(204,'email_queue_enabled','0',1),
(205,'last_email_queue_retry','1750843502',1),
(206,'auto_dismiss_desktop_notifications_after','0',1),
(207,'proposal_info_format','{proposal_to}<br />\r\n      {address}<br />\r\n      {city} {state}<br />\r\n      {country_code} {zip_code}<br />\r\n      {phone}<br />\r\n      {email}',0),
(208,'ticket_replies_order','asc',1),
(209,'new_recurring_invoice_action','generate_and_send',0),
(210,'bcc_emails','',0),
(211,'email_templates_language_checks','',0),
(212,'proposal_accept_identity_confirmation','1',0),
(213,'estimate_accept_identity_confirmation','1',0),
(214,'new_task_auto_follower_current_member','0',1),
(215,'task_biillable_checked_on_creation','1',1),
(216,'predefined_clientnote_credit_note','',1),
(217,'predefined_terms_credit_note','',1),
(218,'next_credit_note_number','1',1),
(219,'credit_note_prefix','CN-',1),
(220,'credit_note_number_decrement_on_delete','1',1),
(221,'pdf_format_credit_note','A4-PORTRAIT',1),
(222,'show_pdf_signature_credit_note','1',0),
(223,'show_credit_note_reminders_on_calendar','1',1),
(224,'show_amount_due_on_invoice','1',1),
(225,'show_total_paid_on_invoice','1',1),
(226,'show_credits_applied_on_invoice','1',1),
(227,'staff_members_create_inline_lead_status','1',1),
(228,'staff_members_create_inline_customer_groups','1',1),
(229,'staff_members_create_inline_ticket_services','1',1),
(230,'staff_members_save_tickets_predefined_replies','1',1),
(231,'staff_members_create_inline_contract_types','1',1),
(232,'staff_members_create_inline_expense_categories','1',1),
(233,'show_project_on_credit_note','1',1),
(234,'proposals_auto_operations_hour','21',1),
(235,'estimates_auto_operations_hour','21',1),
(236,'contracts_auto_operations_hour','21',1),
(237,'credit_note_number_format','1',1),
(238,'allow_non_admin_members_to_import_leads','0',1),
(239,'e_sign_legal_text','By clicking on \"Sign\", I consent to be legally bound by this electronic representation of my signature.',1),
(240,'show_pdf_signature_contract','1',1),
(241,'view_contract_only_logged_in','0',1),
(242,'show_subscriptions_in_customers_area','1',1),
(243,'calendar_only_assigned_tasks','0',1),
(244,'after_subscription_payment_captured','send_invoice_and_receipt',1),
(245,'mail_engine','phpmailer',1),
(246,'gdpr_enable_terms_and_conditions','0',1),
(247,'privacy_policy','',1),
(248,'terms_and_conditions','',1),
(249,'gdpr_enable_terms_and_conditions_lead_form','0',1),
(250,'gdpr_enable_terms_and_conditions_ticket_form','0',1),
(251,'gdpr_contact_enable_right_to_be_forgotten','0',1),
(252,'show_gdpr_in_customers_menu','1',1),
(253,'show_gdpr_link_in_footer','1',1),
(254,'enable_gdpr','0',1),
(255,'gdpr_on_forgotten_remove_invoices_credit_notes','0',1),
(256,'gdpr_on_forgotten_remove_estimates','0',1),
(257,'gdpr_enable_consent_for_contacts','0',1),
(258,'gdpr_consent_public_page_top_block','',1),
(259,'gdpr_page_top_information_block','',1),
(260,'gdpr_enable_lead_public_form','0',1),
(261,'gdpr_show_lead_custom_fields_on_public_form','0',1),
(262,'gdpr_lead_attachments_on_public_form','0',1),
(263,'gdpr_enable_consent_for_leads','0',1),
(264,'gdpr_lead_enable_right_to_be_forgotten','0',1),
(265,'allow_staff_view_invoices_assigned','1',1),
(266,'gdpr_data_portability_leads','0',1),
(267,'gdpr_lead_data_portability_allowed','',1),
(268,'gdpr_contact_data_portability_allowed','',1),
(269,'gdpr_data_portability_contacts','0',1),
(270,'allow_staff_view_estimates_assigned','1',1),
(271,'gdpr_after_lead_converted_delete','0',1),
(272,'gdpr_show_terms_and_conditions_in_footer','0',1),
(273,'save_last_order_for_tables','0',1),
(275,'customers_register_require_confirmation','1',1),
(276,'allow_non_admin_staff_to_delete_ticket_attachments','0',1),
(277,'receive_notification_on_new_ticket_replies','1',0),
(279,'enable_google_picker','1',1),
(280,'show_ticket_reminders_on_calendar','1',1),
(281,'ticket_import_reply_only','0',1),
(282,'visible_customer_profile_tabs','all',0),
(283,'show_project_on_invoice','1',1),
(284,'show_project_on_estimate','1',1),
(285,'staff_members_create_inline_lead_source','1',1),
(286,'lead_unique_validation','[\"email\"]',1),
(287,'last_upgrade_copy_data','',1),
(288,'custom_js_admin_scripts','',1),
(289,'custom_js_customer_scripts','0',1),
(294,'show_php_version_notice','1',0),
(295,'recaptcha_ignore_ips','',1),
(296,'show_task_reminders_on_calendar','1',1),
(297,'customer_settings','true',1),
(298,'tasks_reminder_notification_hour','21',1),
(299,'allow_primary_contact_to_manage_other_contacts','1',1),
(300,'items_table_amounts_exclude_currency_symbol','1',1),
(301,'round_off_task_timer_option','0',1),
(302,'round_off_task_timer_time','5',1),
(304,'enable_support_menu_badges','0',1),
(305,'attach_invoice_to_payment_receipt_email','0',1),
(306,'invoice_due_notice_before','2',1),
(307,'invoice_due_notice_resend_after','0',1),
(308,'_leads_settings','true',1),
(309,'show_estimate_request_in_customers_area','0',1),
(310,'gdpr_enable_terms_and_conditions_estimate_request_form','0',1),
(312,'automatically_stop_task_timer_after_hours','8',1),
(313,'automatically_assign_ticket_to_first_staff_responding','0',1),
(314,'reminder_for_completed_but_not_billed_tasks','0',1),
(315,'staff_notify_completed_but_not_billed_tasks','',1),
(316,'reminder_for_completed_but_not_billed_tasks_days','',1),
(317,'tasks_reminder_notification_last_notified_day','',1),
(318,'staff_related_ticket_notification_to_assignee_only','0',1),
(319,'show_pdf_signature_proposal','1',1),
(320,'enable_honeypot_spam_validation','1',1),
(328,'automatically_set_logged_in_staff_sales_agent','1',1),
(329,'contract_sign_reminder_every_days','0',1),
(330,'last_updated_date','',1),
(331,'v310_incompatible_tables','[]',1),
(332,'upgraded_from_version','',0),
(334,'sms_clickatell_active','0',1),
(335,'sms_clickatell_initialized','1',1),
(337,'sms_msg91_api_type','api',1),
(339,'sms_msg91_active','0',1),
(340,'sms_msg91_initialized','1',1),
(341,'sms_twilio_account_sid','',1),
(343,'sms_twilio_phone_number','',1),
(345,'sms_twilio_active','0',1),
(346,'sms_twilio_initialized','1',1),
(347,'paymentmethod_authorize_acceptjs_active','0',1),
(348,'paymentmethod_authorize_acceptjs_label','Authorize.net Accept.js',1),
(352,'paymentmethod_authorize_acceptjs_description_dashboard','Payment for Invoice {invoice_number}',0),
(353,'paymentmethod_authorize_acceptjs_currencies','USD',0),
(354,'paymentmethod_authorize_acceptjs_test_mode_enabled','0',0),
(355,'paymentmethod_authorize_acceptjs_default_selected','1',1),
(356,'paymentmethod_authorize_acceptjs_initialized','1',1),
(357,'paymentmethod_instamojo_active','0',1),
(358,'paymentmethod_instamojo_label','Instamojo',1),
(359,'paymentmethod_instamojo_fee_fixed','0',0),
(360,'paymentmethod_instamojo_fee_percent','0',0),
(363,'paymentmethod_instamojo_description_dashboard','Payment for Invoice {invoice_number}',0),
(364,'paymentmethod_instamojo_currencies','INR',0),
(365,'paymentmethod_instamojo_test_mode_enabled','1',0),
(366,'paymentmethod_instamojo_default_selected','1',1),
(367,'paymentmethod_instamojo_initialized','1',1),
(368,'paymentmethod_mollie_active','0',1),
(369,'paymentmethod_mollie_label','Mollie',1),
(371,'paymentmethod_mollie_description_dashboard','Payment for Invoice {invoice_number}',0),
(372,'paymentmethod_mollie_currencies','EUR',0),
(373,'paymentmethod_mollie_test_mode_enabled','1',0),
(374,'paymentmethod_mollie_default_selected','1',1),
(375,'paymentmethod_mollie_initialized','1',1),
(376,'paymentmethod_paypal_braintree_active','0',1),
(377,'paymentmethod_paypal_braintree_label','Braintree',1),
(381,'paymentmethod_paypal_braintree_currencies','USD',0),
(382,'paymentmethod_paypal_braintree_paypal_enabled','1',0),
(383,'paymentmethod_paypal_braintree_test_mode_enabled','1',0),
(384,'paymentmethod_paypal_braintree_default_selected','1',1),
(385,'paymentmethod_paypal_braintree_initialized','1',1),
(386,'paymentmethod_paypal_checkout_active','0',1),
(387,'paymentmethod_paypal_checkout_label','Paypal Smart Checkout',1),
(388,'paymentmethod_paypal_checkout_fee_fixed','0',0),
(389,'paymentmethod_paypal_checkout_fee_percent','0',0),
(392,'paymentmethod_paypal_checkout_payment_description','Payment for Invoice {invoice_number}',0),
(393,'paymentmethod_paypal_checkout_currencies','USD,CAD,EUR',0),
(394,'paymentmethod_paypal_checkout_test_mode_enabled','1',0),
(395,'paymentmethod_paypal_checkout_default_selected','1',1),
(396,'paymentmethod_paypal_checkout_initialized','1',1),
(397,'paymentmethod_paypal_active','0',1),
(398,'paymentmethod_paypal_label','Paypal',1),
(399,'paymentmethod_paypal_fee_fixed','0',0),
(400,'paymentmethod_paypal_fee_percent','0',0),
(401,'paymentmethod_paypal_username','',0),
(403,'paymentmethod_paypal_signature','',0),
(404,'paymentmethod_paypal_description_dashboard','Payment for Invoice {invoice_number}',0),
(405,'paymentmethod_paypal_currencies','EUR,USD',0),
(406,'paymentmethod_paypal_test_mode_enabled','1',0),
(407,'paymentmethod_paypal_default_selected','1',1),
(408,'paymentmethod_paypal_initialized','1',1),
(409,'paymentmethod_payu_money_active','0',1),
(410,'paymentmethod_payu_money_label','PayU Money',1),
(411,'paymentmethod_payu_money_fee_fixed','0',0),
(412,'paymentmethod_payu_money_fee_percent','0',0),
(414,'paymentmethod_payu_money_salt','',0),
(415,'paymentmethod_payu_money_description_dashboard','Payment for Invoice {invoice_number}',0),
(416,'paymentmethod_payu_money_currencies','INR',0),
(417,'paymentmethod_payu_money_test_mode_enabled','1',0),
(418,'paymentmethod_payu_money_default_selected','1',1),
(419,'paymentmethod_payu_money_initialized','1',1),
(420,'paymentmethod_stripe_active','0',1),
(421,'paymentmethod_stripe_label','Stripe Checkout',1),
(422,'paymentmethod_stripe_fee_fixed','0',0),
(423,'paymentmethod_stripe_fee_percent','0',0),
(426,'paymentmethod_stripe_description_dashboard','Payment for Invoice {invoice_number}',0),
(427,'paymentmethod_stripe_currencies','USD,CAD',0),
(428,'paymentmethod_stripe_allow_primary_contact_to_update_credit_card','1',0),
(429,'paymentmethod_stripe_default_selected','1',1),
(430,'paymentmethod_stripe_initialized','1',1),
(431,'paymentmethod_stripe_ideal_active','0',1),
(432,'paymentmethod_stripe_ideal_label','Stripe iDEAL',1),
(435,'paymentmethod_stripe_ideal_description_dashboard','Payment for Invoice {invoice_number}',0),
(436,'paymentmethod_stripe_ideal_statement_descriptor','Payment for Invoice {invoice_number}',0),
(437,'paymentmethod_stripe_ideal_currencies','EUR',0),
(438,'paymentmethod_stripe_ideal_default_selected','1',1),
(439,'paymentmethod_stripe_ideal_initialized','1',1),
(440,'paymentmethod_two_checkout_active','0',1),
(441,'paymentmethod_two_checkout_label','2Checkout',1),
(442,'paymentmethod_two_checkout_fee_fixed','0',0),
(443,'paymentmethod_two_checkout_fee_percent','0',0),
(444,'paymentmethod_two_checkout_merchant_code','',0),
(446,'paymentmethod_two_checkout_description','Payment for Invoice {invoice_number}',0),
(447,'paymentmethod_two_checkout_currencies','USD, EUR, GBP',0),
(448,'paymentmethod_two_checkout_test_mode_enabled','1',0),
(449,'paymentmethod_two_checkout_default_selected','1',1),
(450,'paymentmethod_two_checkout_initialized','1',1),
(451,'perfex_saas_installation_secured','true',0),
(452,'survey_send_emails_per_cron_run','100',1),
(453,'last_survey_send_cron','',1);
/*!40000 ALTER TABLE `techdotbit_tbloptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblpayment_attempts`
--

DROP TABLE IF EXISTS `techdotbit_tblpayment_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblpayment_attempts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference` varchar(100) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `amount` double NOT NULL,
  `fee` double NOT NULL,
  `payment_gateway` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblpayment_attempts`
--

LOCK TABLES `techdotbit_tblpayment_attempts` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblpayment_attempts` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblpayment_attempts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblpayment_modes`
--

DROP TABLE IF EXISTS `techdotbit_tblpayment_modes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblpayment_modes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `show_on_pdf` int(11) NOT NULL DEFAULT 0,
  `invoices_only` int(11) NOT NULL DEFAULT 0,
  `expenses_only` int(11) NOT NULL DEFAULT 0,
  `selected_by_default` int(11) NOT NULL DEFAULT 1,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblpayment_modes`
--

LOCK TABLES `techdotbit_tblpayment_modes` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblpayment_modes` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblpayment_modes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblpinned_projects`
--

DROP TABLE IF EXISTS `techdotbit_tblpinned_projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblpinned_projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblpinned_projects`
--

LOCK TABLES `techdotbit_tblpinned_projects` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblpinned_projects` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblpinned_projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblproject_activity`
--

DROP TABLE IF EXISTS `techdotbit_tblproject_activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblproject_activity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL DEFAULT 0,
  `contact_id` int(11) NOT NULL DEFAULT 0,
  `fullname` varchar(100) DEFAULT NULL,
  `visible_to_customer` int(11) NOT NULL DEFAULT 0,
  `description_key` varchar(191) NOT NULL COMMENT 'Language file key',
  `additional_data` mediumtext DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblproject_activity`
--

LOCK TABLES `techdotbit_tblproject_activity` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblproject_activity` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblproject_activity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblproject_files`
--

DROP TABLE IF EXISTS `techdotbit_tblproject_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblproject_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file_name` varchar(191) NOT NULL,
  `original_file_name` longtext DEFAULT NULL,
  `subject` varchar(191) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `filetype` varchar(50) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  `last_activity` datetime DEFAULT NULL,
  `project_id` int(11) NOT NULL,
  `visible_to_customer` tinyint(1) DEFAULT 0,
  `staffid` int(11) NOT NULL,
  `contact_id` int(11) NOT NULL DEFAULT 0,
  `external` varchar(40) DEFAULT NULL,
  `external_link` mediumtext DEFAULT NULL,
  `thumbnail_link` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblproject_files`
--

LOCK TABLES `techdotbit_tblproject_files` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblproject_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblproject_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblproject_members`
--

DROP TABLE IF EXISTS `techdotbit_tblproject_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblproject_members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`),
  KEY `techdotbit_staff_id` (`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblproject_members`
--

LOCK TABLES `techdotbit_tblproject_members` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblproject_members` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblproject_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblproject_notes`
--

DROP TABLE IF EXISTS `techdotbit_tblproject_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblproject_notes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `content` mediumtext NOT NULL,
  `staff_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblproject_notes`
--

LOCK TABLES `techdotbit_tblproject_notes` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblproject_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblproject_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblproject_settings`
--

DROP TABLE IF EXISTS `techdotbit_tblproject_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblproject_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `value` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblproject_settings`
--

LOCK TABLES `techdotbit_tblproject_settings` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblproject_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblproject_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblprojectdiscussioncomments`
--

DROP TABLE IF EXISTS `techdotbit_tblprojectdiscussioncomments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblprojectdiscussioncomments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `discussion_id` int(11) NOT NULL,
  `discussion_type` varchar(10) NOT NULL,
  `parent` int(11) DEFAULT NULL,
  `created` datetime NOT NULL,
  `modified` datetime DEFAULT NULL,
  `content` mediumtext NOT NULL,
  `staff_id` int(11) NOT NULL,
  `contact_id` int(11) DEFAULT 0,
  `fullname` varchar(191) DEFAULT NULL,
  `file_name` varchar(191) DEFAULT NULL,
  `file_mime_type` varchar(70) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblprojectdiscussioncomments`
--

LOCK TABLES `techdotbit_tblprojectdiscussioncomments` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblprojectdiscussioncomments` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblprojectdiscussioncomments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblprojectdiscussions`
--

DROP TABLE IF EXISTS `techdotbit_tblprojectdiscussions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblprojectdiscussions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `subject` varchar(191) NOT NULL,
  `description` mediumtext NOT NULL,
  `show_to_customer` tinyint(1) NOT NULL DEFAULT 0,
  `datecreated` datetime NOT NULL,
  `last_activity` datetime DEFAULT NULL,
  `staff_id` int(11) NOT NULL DEFAULT 0,
  `contact_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblprojectdiscussions`
--

LOCK TABLES `techdotbit_tblprojectdiscussions` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblprojectdiscussions` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblprojectdiscussions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblprojects`
--

DROP TABLE IF EXISTS `techdotbit_tblprojects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblprojects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `clientid` int(11) NOT NULL,
  `billing_type` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `deadline` date DEFAULT NULL,
  `project_created` date NOT NULL,
  `date_finished` datetime DEFAULT NULL,
  `progress` int(11) DEFAULT 0,
  `progress_from_tasks` int(11) NOT NULL DEFAULT 1,
  `project_cost` decimal(15,2) DEFAULT NULL,
  `project_rate_per_hour` decimal(15,2) DEFAULT NULL,
  `estimated_hours` decimal(15,2) DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `contact_notification` int(11) DEFAULT 1,
  `notify_contacts` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblprojects`
--

LOCK TABLES `techdotbit_tblprojects` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblprojects` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblprojects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblproposal_comments`
--

DROP TABLE IF EXISTS `techdotbit_tblproposal_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblproposal_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` longtext DEFAULT NULL,
  `proposalid` int(11) NOT NULL,
  `staffid` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblproposal_comments`
--

LOCK TABLES `techdotbit_tblproposal_comments` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblproposal_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblproposal_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblproposals`
--

DROP TABLE IF EXISTS `techdotbit_tblproposals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblproposals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(191) DEFAULT NULL,
  `content` longtext DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `datecreated` datetime NOT NULL,
  `total` decimal(15,2) DEFAULT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `total_tax` decimal(15,2) NOT NULL DEFAULT 0.00,
  `adjustment` decimal(15,2) DEFAULT NULL,
  `discount_percent` decimal(15,2) NOT NULL,
  `discount_total` decimal(15,2) NOT NULL,
  `discount_type` varchar(30) DEFAULT NULL,
  `show_quantity_as` int(11) NOT NULL DEFAULT 1,
  `currency` int(11) NOT NULL,
  `open_till` date DEFAULT NULL,
  `date` date NOT NULL,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(40) DEFAULT NULL,
  `assigned` int(11) DEFAULT NULL,
  `hash` varchar(32) NOT NULL,
  `proposal_to` varchar(191) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  `country` int(11) NOT NULL DEFAULT 0,
  `zip` varchar(50) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `allow_comments` tinyint(1) NOT NULL DEFAULT 1,
  `status` int(11) NOT NULL,
  `estimate_id` int(11) DEFAULT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `date_converted` datetime DEFAULT NULL,
  `pipeline_order` int(11) DEFAULT 1,
  `is_expiry_notified` int(11) NOT NULL DEFAULT 0,
  `acceptance_firstname` varchar(50) DEFAULT NULL,
  `acceptance_lastname` varchar(50) DEFAULT NULL,
  `acceptance_email` varchar(100) DEFAULT NULL,
  `acceptance_date` datetime DEFAULT NULL,
  `acceptance_ip` varchar(40) DEFAULT NULL,
  `signature` varchar(40) DEFAULT NULL,
  `short_link` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblproposals`
--

LOCK TABLES `techdotbit_tblproposals` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblproposals` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblproposals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblrelated_items`
--

DROP TABLE IF EXISTS `techdotbit_tblrelated_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblrelated_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(30) NOT NULL,
  `item_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblrelated_items`
--

LOCK TABLES `techdotbit_tblrelated_items` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblrelated_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblrelated_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblreminders`
--

DROP TABLE IF EXISTS `techdotbit_tblreminders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblreminders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` mediumtext DEFAULT NULL,
  `date` datetime NOT NULL,
  `isnotified` int(11) NOT NULL DEFAULT 0,
  `rel_id` int(11) NOT NULL,
  `staff` int(11) NOT NULL,
  `rel_type` varchar(40) NOT NULL,
  `notify_by_email` int(11) NOT NULL DEFAULT 1,
  `creator` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`),
  KEY `techdotbit_staff` (`staff`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblreminders`
--

LOCK TABLES `techdotbit_tblreminders` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblreminders` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblreminders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblroles`
--

DROP TABLE IF EXISTS `techdotbit_tblroles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblroles` (
  `roleid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `permissions` longtext DEFAULT NULL,
  PRIMARY KEY (`roleid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblroles`
--

LOCK TABLES `techdotbit_tblroles` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblroles` DISABLE KEYS */;
INSERT INTO `techdotbit_tblroles` VALUES
(1,'Employee',NULL);
/*!40000 ALTER TABLE `techdotbit_tblroles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblsales_activity`
--

DROP TABLE IF EXISTS `techdotbit_tblsales_activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblsales_activity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_type` varchar(20) DEFAULT NULL,
  `rel_id` int(11) NOT NULL,
  `description` mediumtext NOT NULL,
  `additional_data` mediumtext DEFAULT NULL,
  `staffid` varchar(11) DEFAULT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblsales_activity`
--

LOCK TABLES `techdotbit_tblsales_activity` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblsales_activity` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblsales_activity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblscheduled_emails`
--

DROP TABLE IF EXISTS `techdotbit_tblscheduled_emails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblscheduled_emails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(15) NOT NULL,
  `scheduled_at` datetime NOT NULL,
  `contacts` varchar(197) NOT NULL,
  `cc` mediumtext DEFAULT NULL,
  `attach_pdf` tinyint(1) NOT NULL DEFAULT 1,
  `template` varchar(197) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblscheduled_emails`
--

LOCK TABLES `techdotbit_tblscheduled_emails` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblscheduled_emails` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblscheduled_emails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblservices`
--

DROP TABLE IF EXISTS `techdotbit_tblservices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblservices` (
  `serviceid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`serviceid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblservices`
--

LOCK TABLES `techdotbit_tblservices` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblservices` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblservices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblsessions`
--

DROP TABLE IF EXISTS `techdotbit_tblsessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblsessions` (
  `id` varchar(128) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT 0,
  `data` blob NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ci_sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblsessions`
--

LOCK TABLES `techdotbit_tblsessions` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblsessions` DISABLE KEYS */;
INSERT INTO `techdotbit_tblsessions` VALUES
('014eb28547aa0f2c39e448af3f00d438e34e4b92','82.29.165.22',1750791002,'__ci_last_regenerate|i:1750791002;'),
('018559031cd82eb048db74a82f4d023f47f67165','82.29.165.22',1750830002,'__ci_last_regenerate|i:1750830002;'),
('019e2e430aa67c063b6ec687316b7f23cd56ef80','82.29.165.22',1750813802,'__ci_last_regenerate|i:1750813801;'),
('05f59f05ab613c32dd0e9545f0cf9fb3a2911448','82.29.165.22',1750842902,'__ci_last_regenerate|i:1750842902;'),
('086d285c53c17c2379446aee9b38b8cfcca497cd','82.29.165.22',1750827002,'__ci_last_regenerate|i:1750827002;'),
('090f87ee7fac7ecfe63508decea12807dfc6c78c','82.29.165.22',1750831202,'__ci_last_regenerate|i:1750831202;'),
('0acd0ce8ffb48fa6c7a98e4cfa58ef3443ae1c77','82.29.165.22',1750812002,'__ci_last_regenerate|i:1750812002;'),
('1169cd0bf21b64b3534a2887ac80798d525a853c','82.29.165.22',1750838702,'__ci_last_regenerate|i:1750838702;'),
('131c9edf342841747ec4b79d4c0a849481c11b8e','82.29.165.22',1750824005,'__ci_last_regenerate|i:1750824004;'),
('14562d3d6efdd2ed4db115dbf339ded1765b227b','82.29.165.22',1750801202,'__ci_last_regenerate|i:1750801202;'),
('148f699f3024f00fea749c5e243cd35fb66e895a','82.29.165.22',1750810502,'__ci_last_regenerate|i:1750810502;'),
('183cdb464359c7756bb72fda985eab226781d9b0','82.29.165.22',1750782603,'__ci_last_regenerate|i:1750782602;'),
('185c8197003b4a229abcec86a8e9acd4b42c0611','82.29.165.22',1750783203,'__ci_last_regenerate|i:1750783202;'),
('1ab645558eab59faec3a8052edcf4aa2cb6a4eb1','82.29.165.22',1750781402,'__ci_last_regenerate|i:1750781402;'),
('1b0f176069c64888a6bef5ff4517bfab0f27fc45','82.29.165.22',1750828801,'__ci_last_regenerate|i:1750828801;'),
('1b10f134e54b14d527c2d6acaac4507b7ca1493f','82.29.165.22',1750820102,'__ci_last_regenerate|i:1750820102;'),
('1e0ec47eef06513bc6390dddf7dab33f5d1db1c2','82.29.165.22',1750781247,'__ci_last_regenerate|i:1750781247;'),
('1f8db4b5be3550ef66123f8f3f6b7bcea1029dca','82.29.165.22',1750833602,'__ci_last_regenerate|i:1750833602;'),
('205bb7ebcaa9f0f50e485a0d495b455366c7ea79','82.29.165.22',1750794603,'__ci_last_regenerate|i:1750794603;'),
('20f1abe525e2af3dd95e1d4911cd16f5ec83a322','82.29.165.22',1750800602,'__ci_last_regenerate|i:1750800602;'),
('258517be009cae489886abe4e9db3f0f415d36d2','82.29.165.22',1750785603,'__ci_last_regenerate|i:1750785602;'),
('26d7857a0b0664783a45b4ac70056712424fd6af','82.29.165.22',1750809002,'__ci_last_regenerate|i:1750809002;'),
('28a838ee15baf884d43d0f140e7d99b9afb0605f','82.29.165.22',1750783802,'__ci_last_regenerate|i:1750783802;'),
('29225b95abbcd8ee6a400fa8a4e2f261b7360eaa','82.29.165.22',1750816804,'__ci_last_regenerate|i:1750816803;'),
('30c9b597bcb7246cd593952565af793536008261','82.29.165.22',1750800002,'__ci_last_regenerate|i:1750800002;'),
('31c58f65c94cd88ba597e64e1b1209815fba1cfc','82.29.165.22',1750841103,'__ci_last_regenerate|i:1750841102;'),
('333bd9da994c06bd20bc53bd933482ec272b6f82','82.29.165.22',1750805402,'__ci_last_regenerate|i:1750805402;'),
('359a1856af35272ee26fdcc341d1d3c7cd7232b7','82.29.165.22',1750811403,'__ci_last_regenerate|i:1750811403;'),
('3654bd1733c4fd6e1170b7dafe7637c34fe9451d','82.29.165.22',1750804202,'__ci_last_regenerate|i:1750804202;'),
('3805264518b620d164440865bb8e0f8d8c85b0fd','82.29.165.22',1750797002,'__ci_last_regenerate|i:1750797002;'),
('3aef558d975b45411adf723418eecafadfe17c1b','82.29.165.22',1750837203,'__ci_last_regenerate|i:1750837202;'),
('3ce176d392f69ae1d9d3d7208799e94050c02733','82.29.165.22',1750807802,'__ci_last_regenerate|i:1750807802;'),
('3f4bde9f1ab7b94cb90569610de271e320321a5d','82.29.165.22',1750797602,'__ci_last_regenerate|i:1750797602;'),
('3faddfa7658150807cb604e8dc6c0adb9551a5d1','82.29.165.22',1750805102,'__ci_last_regenerate|i:1750805102;'),
('40b55505d7a5c9af5e47c40df15c5bc6c18e19bf','82.29.165.22',1750794003,'__ci_last_regenerate|i:1750794002;'),
('415375c3e6fcc6ffc58aec07ff72cd7ecf125660','82.29.165.22',1750789202,'__ci_last_regenerate|i:1750789202;'),
('42471818f53b49478f3fdf4c7a37f4edb49b0721','82.29.165.22',1750818003,'__ci_last_regenerate|i:1750818002;'),
('45d26b0872788350836d7d6a8cc1bdc66a9804d2','82.29.165.22',1750840501,'__ci_last_regenerate|i:1750840501;'),
('4970e44b4d950767c3b80fa143a27877441cabe1','82.29.165.22',1750798202,'__ci_last_regenerate|i:1750798202;'),
('498942782da6bdb656ab89f48ddcbe39a1afb721','82.29.165.22',1750793102,'__ci_last_regenerate|i:1750793102;'),
('4d7c9917c244910807948028074e0a5b56681a62','82.29.165.22',1750836002,'__ci_last_regenerate|i:1750836002;'),
('53c30ed17660514130b883a566f6514f18eb8133','82.29.165.22',1750789804,'__ci_last_regenerate|i:1750789803;'),
('59587e6113446dd4f0215fc24f623a2b4f8761ff','82.29.165.22',1750808402,'__ci_last_regenerate|i:1750808402;'),
('5afe36d7d07779b485dcbaac58df45b58d96248a','82.29.165.22',1750802404,'__ci_last_regenerate|i:1750802403;'),
('5b3f9ef00ab3eeb13b7d866c6ca0cfc262a260cc','82.29.165.22',1750822502,'__ci_last_regenerate|i:1750822502;'),
('5cdffee62797f9c91bdc9d7c5c42ae276ee4ddc3','82.29.165.22',1750795203,'__ci_last_regenerate|i:1750795203;'),
('6114f7dd0f63f103139622d894ff3f3f84a3003b','82.29.165.22',1750814102,'__ci_last_regenerate|i:1750814102;'),
('623386d3e4dd2b9cdadf7d33630f2513c739c840','82.29.165.22',1750830602,'__ci_last_regenerate|i:1750830602;'),
('6720d58ec357b07f10e59f526ae691c1d33bc0ca','82.29.165.22',1750832403,'__ci_last_regenerate|i:1750832402;'),
('676f23c2196e724df2c04ec2e49e246b3f254e18','82.29.165.22',1750821903,'__ci_last_regenerate|i:1750821903;'),
('6770995162140345cd862388a8ea443219a6bc28','82.29.165.22',1750834202,'__ci_last_regenerate|i:1750834202;'),
('6b594150e4193b0ff3fed6d314851ed7f4614e1c','82.29.165.22',1750818604,'__ci_last_regenerate|i:1750818603;'),
('7694cbeea400b6c81db0ccf2d6245bdbf2370882','82.29.165.22',1750811102,'__ci_last_regenerate|i:1750811102;'),
('78e04245ca2b45e844c96784871e63811fe52940','82.29.165.22',1750804502,'__ci_last_regenerate|i:1750804502;'),
('7c49a195ed38ee4913a3788f2f2f57fbaf8b8652','82.29.165.22',1750792502,'__ci_last_regenerate|i:1750792502;'),
('7d51cd7868b42a45fc077d5716ee3c234c30f624','82.29.165.22',1750827302,'__ci_last_regenerate|i:1750827302;'),
('7d541e38d9520db5aa7b5351062d86fb065f6049','82.29.165.22',1750819202,'__ci_last_regenerate|i:1750819202;'),
('7e3ba3893dfda01dbd28d85e997bd43efd2632cf','82.29.165.22',1750839302,'__ci_last_regenerate|i:1750839302;'),
('80007629376fdb298f5a98c1b1369c236bf382f4','82.29.165.22',1750825802,'__ci_last_regenerate|i:1750825802;'),
('803e8039ea550984ca90536265162e9089db5bb0','82.29.165.22',1750788003,'__ci_last_regenerate|i:1750788002;'),
('836944cbe12fc09286a3c11de90013d18b2c32d2','82.29.165.22',1750803002,'__ci_last_regenerate|i:1750803002;'),
('841e2e5aee0d64406c3e1c51a1ed59677070087b','82.29.165.22',1750782002,'__ci_last_regenerate|i:1750782001;'),
('86698fd4e11ad8e90ff109cf59068dafeb92b66d','82.29.165.22',1750815602,'__ci_last_regenerate|i:1750815602;'),
('87114db8e1fe1a823eb6f46d16a986ee418ad6c7','82.29.165.22',1750815003,'__ci_last_regenerate|i:1750815003;'),
('888aa586424db9f3195dfedb09e6cc0575a44c63','82.29.165.22',1750820404,'__ci_last_regenerate|i:1750820404;'),
('899325ed631254ac47e4f1ded69c352fc1d09ba7','82.29.165.22',1750796402,'__ci_last_regenerate|i:1750796402;'),
('8b5fd1a45db873b9dc3a4610b512b06e839e42e5','82.29.165.22',1750809604,'__ci_last_regenerate|i:1750809603;'),
('90bd600de720e81b41c6c6747d4fc8e0a9e3257b','82.29.165.22',1750784403,'__ci_last_regenerate|i:1750784402;'),
('92463f4f1de644e6c79e582537af1b2309b61034','82.29.165.22',1750817403,'__ci_last_regenerate|i:1750817402;'),
('936746357c7cf5eeebd8236edd2be3c9f0408e48','82.29.165.22',1750823403,'__ci_last_regenerate|i:1750823403;'),
('96f51ae0744c8d6b775c5e49f660baad84765516','82.29.165.22',1750807202,'__ci_last_regenerate|i:1750807202;'),
('981506cd241ee016335578c57a090666c28266c6','82.29.165.22',1750824603,'__ci_last_regenerate|i:1750824603;'),
('9bc6a228af74c5005a00a7be6fefc75c466722d3','82.29.165.22',1750844102,'__ci_last_regenerate|i:1750844102;'),
('9db51d0a15c7652506365fe8cb719c0bd9dcf128','82.29.165.22',1750819502,'__ci_last_regenerate|i:1750819502;'),
('a0c1be562743cd84ace43dadb71d84e30c129155','82.29.165.22',1750803602,'__ci_last_regenerate|i:1750803602;'),
('a1e2b159e1c457906e3d7e9a3a352fa1fdc6d6cc','82.29.165.22',1750790403,'__ci_last_regenerate|i:1750790402;'),
('a5fa4712f427744ec6c324947b779510f9e700ef','82.29.165.22',1750799403,'__ci_last_regenerate|i:1750799402;'),
('a6e3ec2f797bd269d0d62e5ed13032b28086de8b','82.29.165.22',1750810202,'__ci_last_regenerate|i:1750810202;'),
('a760f8c26e1ad314e33c4c18311571b33313a5eb','82.29.165.22',1750829403,'__ci_last_regenerate|i:1750829402;'),
('aec6a4e5ae092c8835f93864617dc764428e4a9e','82.29.165.22',1750812602,'__ci_last_regenerate|i:1750812602;'),
('afc3e6723382e38f6f6ef41afd073d249fc6b961','82.29.165.22',1750826402,'__ci_last_regenerate|i:1750826402;'),
('b5b6496c677f83eeac839ae897dc22cd58dc5c73','82.29.165.22',1750814702,'__ci_last_regenerate|i:1750814702;'),
('b8f4f3d4db072e80f683b8b470828b3c017654c8','82.29.165.22',1750833002,'__ci_last_regenerate|i:1750833001;'),
('b9103a01d4582a20ea19c4b81928a5be3970c101','82.29.165.22',1750842303,'__ci_last_regenerate|i:1750842302;'),
('b95058f96afa301e45e3e83fe20414c015a96aa9','82.29.165.22',1750827902,'__ci_last_regenerate|i:1750827902;'),
('b9915f343e8d608288d4ae3121a1bb2a93403c6b','82.29.165.22',1750822802,'__ci_last_regenerate|i:1750822802;'),
('b99587b2c70f7b8d4ccb6d0c1f9fe182b3c72afe','82.29.165.22',1750785002,'__ci_last_regenerate|i:1750785001;'),
('ba4f87415a92f28996927604989dab753a6cf145','82.29.165.22',1750831804,'__ci_last_regenerate|i:1750831804;'),
('bf4c0f12362c694732a45a775e2f16eab9209d83','82.29.165.22',1750795802,'__ci_last_regenerate|i:1750795802;'),
('c188bc4045e76df3bced8e970974986804d8a873','82.29.165.22',1750838403,'__ci_last_regenerate|i:1750838402;'),
('c1c30624eccc880dcf54bb9c5b6fd64af5ce2774','82.29.165.22',1750787401,'__ci_last_regenerate|i:1750787401;'),
('c5090e893dc13dbaea776378c63753458f49ee20','82.29.165.22',1750813204,'__ci_last_regenerate|i:1750813203;'),
('cb8c102ffe1593087c5ff8557508754046c45e77','82.29.165.22',1750843502,'__ci_last_regenerate|i:1750843502;'),
('cc066793b17dbb00a282acc22db715d90e16bb82','82.29.165.22',1750835402,'__ci_last_regenerate|i:1750835402;'),
('d16434df3085a3dee9159624140ac21a04625ad3','82.29.165.22',1750792202,'__ci_last_regenerate|i:1750792201;'),
('d71726bfe691cf8bcd12f7d08a94ff79b0c4394f','82.29.165.22',1750821304,'__ci_last_regenerate|i:1750821303;'),
('dbad6921bf4a0bd266d50131db13b95c40f9db8a','82.29.165.22',1750802102,'__ci_last_regenerate|i:1750802102;'),
('dbccc75cbedb949b882d7258624a197f5b0fa1ea','82.29.165.22',1750839902,'__ci_last_regenerate|i:1750839902;'),
('dbefff2fa9625bc0fa23a5fc5d00bf29a595a6f5','82.29.165.22',1750836902,'__ci_last_regenerate|i:1750836902;'),
('dcd51b2ac1f34bceb3b3b436174b22b8f066a0f3','82.29.165.22',1750837803,'__ci_last_regenerate|i:1750837802;'),
('e0511df660b693b371aeaf77242337a187887849','82.29.165.22',1750806603,'__ci_last_regenerate|i:1750806602;'),
('e05296fcf538ad7c5ba5c4dbd87908639f18da26','82.29.165.22',1750816202,'__ci_last_regenerate|i:1750816202;'),
('e19e9195543b0f7b1b8d0886021a8f4f1cfa8919','82.29.165.22',1750825202,'__ci_last_regenerate|i:1750825202;'),
('e3f185bad5aeaf8574543e9e3d877791f874cf5d','82.29.165.22',1750801502,'__ci_last_regenerate|i:1750801502;'),
('e4f2f97bcd1f5a25f7e83e599575603258cd7d8c','82.29.165.22',1750806003,'__ci_last_regenerate|i:1750806003;'),
('e51e8966ed73c5b9e810b12464367e27ed8c86e4','82.29.165.22',1750786802,'__ci_last_regenerate|i:1750786801;'),
('e78c081933af0fbdf9118127e5e3c6fdbe4da5e1','82.29.165.22',1750841702,'__ci_last_regenerate|i:1750841702;'),
('e969401f757bfa27d1b75476c657e5a5ed2674fb','82.29.165.22',1750798805,'__ci_last_regenerate|i:1750798805;'),
('eafe82089660564f234ca5925efabc0362393981','82.29.165.22',1750786203,'__ci_last_regenerate|i:1750786203;'),
('eeedcf6e27e9566d902eca3b8f11d85fd88b2276','82.29.165.22',1750828203,'__ci_last_regenerate|i:1750828202;'),
('f2a6bc06590f8e25150e776cb881ab08bcd2ceae','82.29.165.22',1750791604,'__ci_last_regenerate|i:1750791603;'),
('f2e748029a3b19afc085fb2b3a9aa760e7ae1f70','82.29.165.22',1750793403,'__ci_last_regenerate|i:1750793403;'),
('f6cb51009515a403a9ab1b93fcfeb7e63e62986d','82.29.165.22',1750788603,'__ci_last_regenerate|i:1750788602;'),
('f7fde1a071b1c8f7f8afc0f9c6d38bf460372890','82.29.165.22',1750834804,'__ci_last_regenerate|i:1750834804;'),
('fdff501ea80a1729bd86fcef26fb4b876bf27575','82.29.165.22',1750821003,'__ci_last_regenerate|i:1750821002;');
/*!40000 ALTER TABLE `techdotbit_tblsessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblshared_customer_files`
--

DROP TABLE IF EXISTS `techdotbit_tblshared_customer_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblshared_customer_files` (
  `file_id` int(11) NOT NULL,
  `contact_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblshared_customer_files`
--

LOCK TABLES `techdotbit_tblshared_customer_files` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblshared_customer_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblshared_customer_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblspam_filters`
--

DROP TABLE IF EXISTS `techdotbit_tblspam_filters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblspam_filters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(40) NOT NULL,
  `rel_type` varchar(10) NOT NULL,
  `value` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblspam_filters`
--

LOCK TABLES `techdotbit_tblspam_filters` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblspam_filters` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblspam_filters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblstaff`
--

DROP TABLE IF EXISTS `techdotbit_tblstaff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblstaff` (
  `staffid` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `facebook` longtext DEFAULT NULL,
  `linkedin` longtext DEFAULT NULL,
  `phonenumber` varchar(30) DEFAULT NULL,
  `skype` varchar(50) DEFAULT NULL,
  `password` varchar(250) NOT NULL,
  `datecreated` datetime NOT NULL,
  `profile_image` varchar(191) DEFAULT NULL,
  `last_ip` varchar(40) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_activity` datetime DEFAULT NULL,
  `last_password_change` datetime DEFAULT NULL,
  `new_pass_key` varchar(32) DEFAULT NULL,
  `new_pass_key_requested` datetime DEFAULT NULL,
  `admin` int(11) NOT NULL DEFAULT 0,
  `role` int(11) DEFAULT NULL,
  `active` int(11) NOT NULL DEFAULT 1,
  `default_language` varchar(40) DEFAULT NULL,
  `direction` varchar(3) DEFAULT NULL,
  `media_path_slug` varchar(191) DEFAULT NULL,
  `is_not_staff` int(11) NOT NULL DEFAULT 0,
  `hourly_rate` decimal(15,2) NOT NULL DEFAULT 0.00,
  `two_factor_auth_enabled` tinyint(1) DEFAULT 0,
  `two_factor_auth_code` varchar(100) DEFAULT NULL,
  `two_factor_auth_code_requested` datetime DEFAULT NULL,
  `email_signature` mediumtext DEFAULT NULL,
  `google_auth_secret` mediumtext DEFAULT NULL,
  PRIMARY KEY (`staffid`),
  KEY `firstname` (`firstname`),
  KEY `lastname` (`lastname`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblstaff`
--

LOCK TABLES `techdotbit_tblstaff` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblstaff` DISABLE KEYS */;
INSERT INTO `techdotbit_tblstaff` VALUES
(1,'info.vikaasyadav@gmail.com','miki','Yadav',NULL,NULL,'+9108077841585',NULL,'$2a$08$lxJl8gjCJyWZayC4jA9Pi.QrPtccecOFrkZ/dy./xb7u/FS4OnUha','2025-06-24 21:37:19',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,NULL,NULL,NULL,0,0.00,0,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `techdotbit_tblstaff` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblstaff_departments`
--

DROP TABLE IF EXISTS `techdotbit_tblstaff_departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblstaff_departments` (
  `staffdepartmentid` int(11) NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `departmentid` int(11) NOT NULL,
  PRIMARY KEY (`staffdepartmentid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblstaff_departments`
--

LOCK TABLES `techdotbit_tblstaff_departments` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblstaff_departments` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblstaff_departments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblstaff_permissions`
--

DROP TABLE IF EXISTS `techdotbit_tblstaff_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblstaff_permissions` (
  `staff_id` int(11) NOT NULL,
  `feature` varchar(40) NOT NULL,
  `capability` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblstaff_permissions`
--

LOCK TABLES `techdotbit_tblstaff_permissions` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblstaff_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblstaff_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblsubscriptions`
--

DROP TABLE IF EXISTS `techdotbit_tblsubscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblsubscriptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `description_in_item` tinyint(1) NOT NULL DEFAULT 0,
  `clientid` int(11) NOT NULL,
  `date` date DEFAULT NULL,
  `terms` mediumtext DEFAULT NULL,
  `currency` int(11) NOT NULL,
  `tax_id` int(11) NOT NULL DEFAULT 0,
  `stripe_tax_id` varchar(50) DEFAULT NULL,
  `tax_id_2` int(11) NOT NULL DEFAULT 0,
  `stripe_tax_id_2` varchar(50) DEFAULT NULL,
  `stripe_plan_id` mediumtext DEFAULT NULL,
  `stripe_subscription_id` mediumtext NOT NULL,
  `next_billing_cycle` bigint(20) DEFAULT NULL,
  `ends_at` bigint(20) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `project_id` int(11) NOT NULL DEFAULT 0,
  `hash` varchar(32) NOT NULL,
  `created` datetime NOT NULL,
  `created_from` int(11) NOT NULL,
  `date_subscribed` datetime DEFAULT NULL,
  `in_test_environment` int(11) DEFAULT NULL,
  `last_sent_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `currency` (`currency`),
  KEY `tax_id` (`tax_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblsubscriptions`
--

LOCK TABLES `techdotbit_tblsubscriptions` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblsubscriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblsubscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblsurveyresultsets`
--

DROP TABLE IF EXISTS `techdotbit_tblsurveyresultsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblsurveyresultsets` (
  `resultsetid` int(11) NOT NULL AUTO_INCREMENT,
  `surveyid` int(11) NOT NULL,
  `ip` varchar(40) NOT NULL,
  `useragent` varchar(150) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`resultsetid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblsurveyresultsets`
--

LOCK TABLES `techdotbit_tblsurveyresultsets` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblsurveyresultsets` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblsurveyresultsets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblsurveys`
--

DROP TABLE IF EXISTS `techdotbit_tblsurveys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblsurveys` (
  `surveyid` int(11) NOT NULL AUTO_INCREMENT,
  `subject` mediumtext NOT NULL,
  `slug` mediumtext NOT NULL,
  `description` text NOT NULL,
  `viewdescription` text DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `redirect_url` varchar(100) DEFAULT NULL,
  `send` tinyint(1) NOT NULL DEFAULT 0,
  `onlyforloggedin` int(11) DEFAULT 0,
  `fromname` varchar(100) DEFAULT NULL,
  `iprestrict` tinyint(1) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `hash` varchar(32) NOT NULL,
  PRIMARY KEY (`surveyid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblsurveys`
--

LOCK TABLES `techdotbit_tblsurveys` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblsurveys` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblsurveys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblsurveysemailsendcron`
--

DROP TABLE IF EXISTS `techdotbit_tblsurveysemailsendcron`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblsurveysemailsendcron` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `surveyid` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `emailid` int(11) DEFAULT NULL,
  `listid` varchar(11) DEFAULT NULL,
  `log_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblsurveysemailsendcron`
--

LOCK TABLES `techdotbit_tblsurveysemailsendcron` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblsurveysemailsendcron` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblsurveysemailsendcron` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblsurveysendlog`
--

DROP TABLE IF EXISTS `techdotbit_tblsurveysendlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblsurveysendlog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `surveyid` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `iscronfinished` int(11) NOT NULL DEFAULT 0,
  `send_to_mail_lists` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblsurveysendlog`
--

LOCK TABLES `techdotbit_tblsurveysendlog` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblsurveysendlog` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblsurveysendlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tbltaggables`
--

DROP TABLE IF EXISTS `techdotbit_tbltaggables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tbltaggables` (
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) NOT NULL,
  `tag_id` int(11) NOT NULL,
  `tag_order` int(11) NOT NULL DEFAULT 0,
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`),
  KEY `tag_id` (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tbltaggables`
--

LOCK TABLES `techdotbit_tbltaggables` WRITE;
/*!40000 ALTER TABLE `techdotbit_tbltaggables` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tbltaggables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tbltags`
--

DROP TABLE IF EXISTS `techdotbit_tbltags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tbltags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tbltags`
--

LOCK TABLES `techdotbit_tbltags` WRITE;
/*!40000 ALTER TABLE `techdotbit_tbltags` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tbltags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tbltask_assigned`
--

DROP TABLE IF EXISTS `techdotbit_tbltask_assigned`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tbltask_assigned` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `taskid` int(11) NOT NULL,
  `assigned_from` int(11) NOT NULL DEFAULT 0,
  `is_assigned_from_contact` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `taskid` (`taskid`),
  KEY `techdotbit_staffid` (`staffid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tbltask_assigned`
--

LOCK TABLES `techdotbit_tbltask_assigned` WRITE;
/*!40000 ALTER TABLE `techdotbit_tbltask_assigned` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tbltask_assigned` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tbltask_checklist_items`
--

DROP TABLE IF EXISTS `techdotbit_tbltask_checklist_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tbltask_checklist_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `taskid` int(11) NOT NULL,
  `description` mediumtext NOT NULL,
  `finished` int(11) NOT NULL DEFAULT 0,
  `dateadded` datetime NOT NULL,
  `addedfrom` int(11) NOT NULL,
  `finished_from` int(11) DEFAULT 0,
  `list_order` int(11) NOT NULL DEFAULT 0,
  `assigned` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `taskid` (`taskid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tbltask_checklist_items`
--

LOCK TABLES `techdotbit_tbltask_checklist_items` WRITE;
/*!40000 ALTER TABLE `techdotbit_tbltask_checklist_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tbltask_checklist_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tbltask_comments`
--

DROP TABLE IF EXISTS `techdotbit_tbltask_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tbltask_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` mediumtext NOT NULL,
  `taskid` int(11) NOT NULL,
  `staffid` int(11) NOT NULL,
  `contact_id` int(11) NOT NULL DEFAULT 0,
  `file_id` int(11) NOT NULL DEFAULT 0,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `file_id` (`file_id`),
  KEY `taskid` (`taskid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tbltask_comments`
--

LOCK TABLES `techdotbit_tbltask_comments` WRITE;
/*!40000 ALTER TABLE `techdotbit_tbltask_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tbltask_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tbltask_followers`
--

DROP TABLE IF EXISTS `techdotbit_tbltask_followers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tbltask_followers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `taskid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tbltask_followers`
--

LOCK TABLES `techdotbit_tbltask_followers` WRITE;
/*!40000 ALTER TABLE `techdotbit_tbltask_followers` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tbltask_followers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tbltasks`
--

DROP TABLE IF EXISTS `techdotbit_tbltasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tbltasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  `startdate` date NOT NULL,
  `duedate` date DEFAULT NULL,
  `datefinished` datetime DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `is_added_from_contact` tinyint(1) NOT NULL DEFAULT 0,
  `status` int(11) NOT NULL DEFAULT 0,
  `recurring_type` varchar(10) DEFAULT NULL,
  `repeat_every` int(11) DEFAULT NULL,
  `recurring` int(11) NOT NULL DEFAULT 0,
  `is_recurring_from` int(11) DEFAULT NULL,
  `cycles` int(11) NOT NULL DEFAULT 0,
  `total_cycles` int(11) NOT NULL DEFAULT 0,
  `custom_recurring` tinyint(1) NOT NULL DEFAULT 0,
  `last_recurring_date` date DEFAULT NULL,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(30) DEFAULT NULL,
  `is_public` tinyint(1) NOT NULL DEFAULT 0,
  `billable` tinyint(1) NOT NULL DEFAULT 0,
  `billed` tinyint(1) NOT NULL DEFAULT 0,
  `invoice_id` int(11) NOT NULL DEFAULT 0,
  `hourly_rate` decimal(15,2) NOT NULL DEFAULT 0.00,
  `milestone` int(11) DEFAULT 0,
  `kanban_order` int(11) DEFAULT 1,
  `milestone_order` int(11) NOT NULL DEFAULT 0,
  `visible_to_client` tinyint(1) NOT NULL DEFAULT 0,
  `deadline_notified` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`),
  KEY `milestone` (`milestone`),
  KEY `kanban_order` (`kanban_order`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tbltasks`
--

LOCK TABLES `techdotbit_tbltasks` WRITE;
/*!40000 ALTER TABLE `techdotbit_tbltasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tbltasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tbltasks_checklist_templates`
--

DROP TABLE IF EXISTS `techdotbit_tbltasks_checklist_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tbltasks_checklist_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tbltasks_checklist_templates`
--

LOCK TABLES `techdotbit_tbltasks_checklist_templates` WRITE;
/*!40000 ALTER TABLE `techdotbit_tbltasks_checklist_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tbltasks_checklist_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tbltaskstimers`
--

DROP TABLE IF EXISTS `techdotbit_tbltaskstimers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tbltaskstimers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) NOT NULL,
  `start_time` varchar(64) NOT NULL,
  `end_time` varchar(64) DEFAULT NULL,
  `staff_id` int(11) NOT NULL,
  `hourly_rate` decimal(15,2) NOT NULL DEFAULT 0.00,
  `note` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `task_id` (`task_id`),
  KEY `techdotbit_staff_id` (`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tbltaskstimers`
--

LOCK TABLES `techdotbit_tbltaskstimers` WRITE;
/*!40000 ALTER TABLE `techdotbit_tbltaskstimers` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tbltaskstimers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tbltaxes`
--

DROP TABLE IF EXISTS `techdotbit_tbltaxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tbltaxes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `taxrate` decimal(15,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tbltaxes`
--

LOCK TABLES `techdotbit_tbltaxes` WRITE;
/*!40000 ALTER TABLE `techdotbit_tbltaxes` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tbltaxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tbltemplates`
--

DROP TABLE IF EXISTS `techdotbit_tbltemplates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tbltemplates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `type` varchar(100) NOT NULL,
  `addedfrom` int(11) NOT NULL,
  `content` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tbltemplates`
--

LOCK TABLES `techdotbit_tbltemplates` WRITE;
/*!40000 ALTER TABLE `techdotbit_tbltemplates` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tbltemplates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblticket_attachments`
--

DROP TABLE IF EXISTS `techdotbit_tblticket_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblticket_attachments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticketid` int(11) NOT NULL,
  `replyid` int(11) DEFAULT NULL,
  `file_name` varchar(191) NOT NULL,
  `filetype` varchar(50) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblticket_attachments`
--

LOCK TABLES `techdotbit_tblticket_attachments` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblticket_attachments` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblticket_attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblticket_replies`
--

DROP TABLE IF EXISTS `techdotbit_tblticket_replies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblticket_replies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticketid` int(11) NOT NULL,
  `userid` int(11) DEFAULT NULL,
  `contactid` int(11) NOT NULL DEFAULT 0,
  `name` mediumtext DEFAULT NULL,
  `email` mediumtext DEFAULT NULL,
  `date` datetime NOT NULL,
  `message` mediumtext DEFAULT NULL,
  `attachment` int(11) DEFAULT NULL,
  `admin` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblticket_replies`
--

LOCK TABLES `techdotbit_tblticket_replies` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblticket_replies` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblticket_replies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tbltickets`
--

DROP TABLE IF EXISTS `techdotbit_tbltickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tbltickets` (
  `ticketid` int(11) NOT NULL AUTO_INCREMENT,
  `adminreplying` int(11) NOT NULL DEFAULT 0,
  `userid` int(11) NOT NULL,
  `contactid` int(11) NOT NULL DEFAULT 0,
  `merged_ticket_id` int(11) DEFAULT NULL,
  `email` mediumtext DEFAULT NULL,
  `name` mediumtext DEFAULT NULL,
  `department` int(11) NOT NULL,
  `priority` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `service` int(11) DEFAULT NULL,
  `ticketkey` varchar(32) NOT NULL,
  `subject` varchar(191) NOT NULL,
  `message` mediumtext DEFAULT NULL,
  `admin` int(11) DEFAULT NULL,
  `date` datetime NOT NULL,
  `project_id` int(11) NOT NULL DEFAULT 0,
  `lastreply` datetime DEFAULT NULL,
  `clientread` int(11) NOT NULL DEFAULT 0,
  `adminread` int(11) NOT NULL DEFAULT 0,
  `assigned` int(11) NOT NULL DEFAULT 0,
  `staff_id_replying` int(11) DEFAULT NULL,
  `cc` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`ticketid`),
  KEY `service` (`service`),
  KEY `department` (`department`),
  KEY `status` (`status`),
  KEY `userid` (`userid`),
  KEY `priority` (`priority`),
  KEY `project_id` (`project_id`),
  KEY `contactid` (`contactid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tbltickets`
--

LOCK TABLES `techdotbit_tbltickets` WRITE;
/*!40000 ALTER TABLE `techdotbit_tbltickets` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tbltickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tbltickets_pipe_log`
--

DROP TABLE IF EXISTS `techdotbit_tbltickets_pipe_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tbltickets_pipe_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `email_to` varchar(100) NOT NULL,
  `name` varchar(191) NOT NULL,
  `subject` varchar(191) NOT NULL,
  `message` longtext NOT NULL,
  `email` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tbltickets_pipe_log`
--

LOCK TABLES `techdotbit_tbltickets_pipe_log` WRITE;
/*!40000 ALTER TABLE `techdotbit_tbltickets_pipe_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tbltickets_pipe_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tbltickets_predefined_replies`
--

DROP TABLE IF EXISTS `techdotbit_tbltickets_predefined_replies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tbltickets_predefined_replies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `message` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tbltickets_predefined_replies`
--

LOCK TABLES `techdotbit_tbltickets_predefined_replies` WRITE;
/*!40000 ALTER TABLE `techdotbit_tbltickets_predefined_replies` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tbltickets_predefined_replies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tbltickets_priorities`
--

DROP TABLE IF EXISTS `techdotbit_tbltickets_priorities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tbltickets_priorities` (
  `priorityid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`priorityid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tbltickets_priorities`
--

LOCK TABLES `techdotbit_tbltickets_priorities` WRITE;
/*!40000 ALTER TABLE `techdotbit_tbltickets_priorities` DISABLE KEYS */;
INSERT INTO `techdotbit_tbltickets_priorities` VALUES
(1,'Low'),
(2,'Medium'),
(3,'High');
/*!40000 ALTER TABLE `techdotbit_tbltickets_priorities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tbltickets_status`
--

DROP TABLE IF EXISTS `techdotbit_tbltickets_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tbltickets_status` (
  `ticketstatusid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `isdefault` int(11) NOT NULL DEFAULT 0,
  `statuscolor` varchar(7) DEFAULT NULL,
  `statusorder` int(11) DEFAULT NULL,
  PRIMARY KEY (`ticketstatusid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tbltickets_status`
--

LOCK TABLES `techdotbit_tbltickets_status` WRITE;
/*!40000 ALTER TABLE `techdotbit_tbltickets_status` DISABLE KEYS */;
INSERT INTO `techdotbit_tbltickets_status` VALUES
(1,'Open',1,'#ff2d42',1),
(2,'In progress',1,'#22c55e',2),
(3,'Answered',1,'#2563eb',3),
(4,'On Hold',1,'#64748b',4),
(5,'Closed',1,'#03a9f4',5);
/*!40000 ALTER TABLE `techdotbit_tbltickets_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tbltodos`
--

DROP TABLE IF EXISTS `techdotbit_tbltodos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tbltodos` (
  `todoid` int(11) NOT NULL AUTO_INCREMENT,
  `description` mediumtext NOT NULL,
  `staffid` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  `finished` tinyint(1) NOT NULL,
  `datefinished` datetime DEFAULT NULL,
  `item_order` int(11) DEFAULT NULL,
  PRIMARY KEY (`todoid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tbltodos`
--

LOCK TABLES `techdotbit_tbltodos` WRITE;
/*!40000 ALTER TABLE `techdotbit_tbltodos` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tbltodos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tbltracked_mails`
--

DROP TABLE IF EXISTS `techdotbit_tbltracked_mails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tbltracked_mails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` varchar(32) NOT NULL,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(40) NOT NULL,
  `date` datetime NOT NULL,
  `email` varchar(100) NOT NULL,
  `opened` tinyint(1) NOT NULL DEFAULT 0,
  `date_opened` datetime DEFAULT NULL,
  `subject` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tbltracked_mails`
--

LOCK TABLES `techdotbit_tbltracked_mails` WRITE;
/*!40000 ALTER TABLE `techdotbit_tbltracked_mails` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tbltracked_mails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tbltwocheckout_log`
--

DROP TABLE IF EXISTS `techdotbit_tbltwocheckout_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tbltwocheckout_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference` varchar(64) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `amount` varchar(25) NOT NULL,
  `created_at` datetime NOT NULL,
  `attempt_reference` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `invoice_id` (`invoice_id`),
  CONSTRAINT `techdotbit_tbltwocheckout_log_ibfk_1` FOREIGN KEY (`invoice_id`) REFERENCES `techdotbit_tblinvoices` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tbltwocheckout_log`
--

LOCK TABLES `techdotbit_tbltwocheckout_log` WRITE;
/*!40000 ALTER TABLE `techdotbit_tbltwocheckout_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tbltwocheckout_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tbluser_auto_login`
--

DROP TABLE IF EXISTS `techdotbit_tbluser_auto_login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tbluser_auto_login` (
  `key_id` char(32) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_agent` varchar(150) NOT NULL,
  `last_ip` varchar(40) NOT NULL,
  `last_login` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `staff` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tbluser_auto_login`
--

LOCK TABLES `techdotbit_tbluser_auto_login` WRITE;
/*!40000 ALTER TABLE `techdotbit_tbluser_auto_login` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tbluser_auto_login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tbluser_meta`
--

DROP TABLE IF EXISTS `techdotbit_tbluser_meta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tbluser_meta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `staff_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `client_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `contact_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(191) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`umeta_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tbluser_meta`
--

LOCK TABLES `techdotbit_tbluser_meta` WRITE;
/*!40000 ALTER TABLE `techdotbit_tbluser_meta` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tbluser_meta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblvault`
--

DROP TABLE IF EXISTS `techdotbit_tblvault`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblvault` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `server_address` varchar(191) NOT NULL,
  `port` int(11) DEFAULT NULL,
  `username` varchar(191) NOT NULL,
  `password` mediumtext NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `creator` int(11) NOT NULL,
  `creator_name` varchar(100) DEFAULT NULL,
  `visibility` tinyint(1) NOT NULL DEFAULT 1,
  `share_in_projects` tinyint(1) NOT NULL DEFAULT 0,
  `last_updated` datetime DEFAULT NULL,
  `last_updated_from` varchar(100) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblvault`
--

LOCK TABLES `techdotbit_tblvault` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblvault` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblvault` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblviews_tracking`
--

DROP TABLE IF EXISTS `techdotbit_tblviews_tracking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblviews_tracking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(40) NOT NULL,
  `date` datetime NOT NULL,
  `view_ip` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblviews_tracking`
--

LOCK TABLES `techdotbit_tblviews_tracking` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblviews_tracking` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblviews_tracking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `techdotbit_tblweb_to_lead`
--

DROP TABLE IF EXISTS `techdotbit_tblweb_to_lead`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `techdotbit_tblweb_to_lead` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `form_key` varchar(32) NOT NULL,
  `lead_source` int(11) NOT NULL,
  `lead_status` int(11) NOT NULL,
  `notify_lead_imported` int(11) NOT NULL DEFAULT 1,
  `notify_type` varchar(20) DEFAULT NULL,
  `notify_ids` longtext DEFAULT NULL,
  `responsible` int(11) NOT NULL DEFAULT 0,
  `name` varchar(191) NOT NULL,
  `form_data` longtext DEFAULT NULL,
  `recaptcha` int(11) NOT NULL DEFAULT 0,
  `submit_btn_name` varchar(40) DEFAULT NULL,
  `submit_btn_text_color` varchar(10) DEFAULT '#ffffff',
  `submit_btn_bg_color` varchar(10) DEFAULT '#84c529',
  `success_submit_msg` mediumtext DEFAULT NULL,
  `submit_action` int(11) DEFAULT 0,
  `lead_name_prefix` varchar(255) DEFAULT NULL,
  `submit_redirect_url` longtext DEFAULT NULL,
  `language` varchar(40) DEFAULT NULL,
  `allow_duplicate` int(11) NOT NULL DEFAULT 1,
  `mark_public` int(11) NOT NULL DEFAULT 0,
  `track_duplicate_field` varchar(20) DEFAULT NULL,
  `track_duplicate_field_and` varchar(20) DEFAULT NULL,
  `create_task_on_duplicate` int(11) NOT NULL DEFAULT 0,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techdotbit_tblweb_to_lead`
--

LOCK TABLES `techdotbit_tblweb_to_lead` WRITE;
/*!40000 ALTER TABLE `techdotbit_tblweb_to_lead` DISABLE KEYS */;
/*!40000 ALTER TABLE `techdotbit_tblweb_to_lead` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-02  6:00:50
